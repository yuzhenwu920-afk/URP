"""Equal actual-ET diagnostic points; not a new optimization experiment."""
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from audit_engine import ROOT,AuditEngine,write
from constrained_demonstration import POLICIES

def main():
    engine=AuditEngine();summary=pd.read_csv(ROOT/'tables/Scenario_summary.csv')
    best=pd.read_csv(ROOT/'tables/Constrained_best_found_candidates.csv');rows=[]
    for year in [2020,2021]:
        baseline=summary[(summary.Year==year)&(summary.Scenario=='DI')].iloc[0]
        target=baseline.ET_mm;names=engine.specs[year]['names']
        for policy in POLICIES:
            point=best[(best.Year==year)&(best.Policy==policy)].iloc[0]
            a=pd.concat([pd.read_csv(p) for p in (ROOT/'constrained_runs'/str(year)/policy).glob('seed*/evaluations.csv.gz')])
            uppers=a[(a.Feasible)&(a.ET_mm>=target-1e-8)].sort_values('Irrigation_mm')
            lower=point[names].to_numpy(float)
            x=None
            # Feasible endpoints alone do not guarantee a feasible nonlinear
            # interpolation. Check actual storage after solving the ET equation.
            for _,upper in uppers.head(30).iterrows():
                high=upper[names].to_numpy(float)
                if upper.ET_mm<=target+1e-8:trial=high
                else:
                    t=brentq(lambda t:engine.basic(year,(1-t)*lower+t*high)['ET_mm']-target,0,1,xtol=1e-11)
                    trial=(1-t)*lower+t*high
                checked=engine.basic(year,trial)
                if pd.isna(point.Storage_floor_mm) or checked['Profile_final_mm']>=point.Storage_floor_mm-1e-7:
                    x=trial;break
            if x is None:
                # DI itself is a known feasible equal-ET fallback, never fabricate
                # a supposedly improved point if the search does not provide one.
                x=np.array(engine.specs[year]['baseline_amounts'])
            label='ETfixed_'+policy
            r,d,l,stress=engine.trace(year,label,x)
            assert abs(r['ET_mm']-target)<1e-5
            assert r['Maximum_single_actual_irrigation_mm']<=point.Event_cap_mm+1e-8
            assert r['Y_13pct']>=.95*baseline.Observed_Y13-1e-7
            if pd.notna(point.Storage_floor_mm):assert r['Profile_final_mm']>=point.Storage_floor_mm-1e-7
            r.update(Policy=policy,ET_target_mm=target,ET_difference_mm=r['ET_mm']-target,
                Storage_floor_mm=point.Storage_floor_mm if pd.notna(point.Storage_floor_mm) else None,
                Irrigation_reduction_pct=100*(1-r['Irrigation_mm']/baseline.Irrigation_mm),
                Interpretation='model-interpolated equal-ET diagnostic; original per-event setting fixed; not minimum-water proof')
            rows.append(r);d.to_csv(ROOT/'tables'/f'daily_{year}_{label}.csv',index=False)
    pd.DataFrame(rows).to_csv(ROOT/'tables/Equal_ET_fixed_management_diagnostics.csv',index=False)
    write(ROOT/'verification/Equal_ET_checks.json',engine.verify_frozen())
    print(pd.DataFrame(rows)[['Year','Policy','Irrigation_mm','ET_mm','Profile_final_mm','Irrigation_reduction_pct']].to_string(index=False))

if __name__=='__main__':main()
