"""Package verified results without caches or working profiles."""
import hashlib,json,zipfile,shutil
from pathlib import Path
import fitz
from docx import Document
from audit_engine import ROOT

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def files():
    paths=[]
    for folder in ['code','tables','figures','verification','model_snapshots','constrained_runs']:
        for path in sorted((ROOT/folder).rglob('*')):
            if not path.is_file() or '__pycache__' in path.parts or path.suffix in ['.pyc','.lock']:continue
            paths.append(path)
    for name in ['README.md','FIGURE_INTERPRETATIONS.json','URP_Optimization_Mechanism_Report.docx',
        'URP_Optimization_Mechanism_Report.pdf','URP_Optimization_Mechanism_Report.md','URP_Optimization_Mechanism_Data.xlsx']:
        paths.append(ROOT/name)
    return sorted(paths)

def main():
    document=Document(ROOT/'URP_Optimization_Mechanism_Report.docx');pdf=fitz.open(ROOT/'URP_Optimization_Mechanism_Report.pdf')
    assert len(document.inline_shapes)==9 and len(pdf)==15
    assert all(len(p.get_text())>200 for p in pdf)
    # Refresh a final-page rendering for a reviewable, current table layout.
    pdf[10].get_pixmap(matrix=fitz.Matrix(1.2,1.2)).save(ROOT/'verification/candidate_table_page.png')
    paths=files();manifest=dict(version='2026-10-20',parent_repo_commit='06f568294eaf86240f49140ef8e820b259c4f764',
        scope='four-year original replays; 2020/2021 mechanism audit and diagnostic constraints; no MCMC resampling',
        user_clarification='mulch effectiveness switch is not physical intactness; irrigation guards are not equipment limits',
        report_pages=len(pdf),English_figure_groups=9,Word_figures=9,actual_constrained_search_evaluations=38400,
        files=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in paths])
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    paths.append(ROOT/'MANIFEST.json')
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+str(p.relative_to(ROOT)) for p in paths)+'\n')
    paths.append(ROOT/'SHA256SUMS.txt')
    archive=ROOT.parent/'URP_Optimization_Mechanism_Audit_20261020.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in paths:z.write(path,'URP_Optimization_Mechanism_Audit/'+str(path.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(paths)
        for entry in manifest['files']:
            assert hashlib.sha256(z.read('URP_Optimization_Mechanism_Audit/'+entry['path'])).hexdigest()==entry['sha256']
    out=Path('/workspace/URP/deliverables/2026-10-20-optimization-diagnosis');out.mkdir(exist_ok=True)
    for p in [archive,ROOT/'URP_Optimization_Mechanism_Report.docx',ROOT/'URP_Optimization_Mechanism_Report.pdf',ROOT/'README.md',ROOT/'MANIFEST.json']:
        shutil.copy2(p,out/p.name)
    summary=dict(status='PASS',archive=archive.name,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),
        files_in_archive=len(paths),zip_crc='PASS',all_manifest_hashes='PASS',report_pages=15,
        prior_outputs_overwritten=False,MCMC_reruns=0)
    (out/'PACKAGE_CHECK.json').write_text(json.dumps(summary,indent=2))
    (out/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt')+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
