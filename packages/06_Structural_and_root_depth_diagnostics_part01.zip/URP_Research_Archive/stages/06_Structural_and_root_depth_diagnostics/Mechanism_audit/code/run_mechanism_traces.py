from pathlib import Path
import json,shutil,sys
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from audit_engine import AuditEngine,ROOT,PROJECT,write,sha

PUB=PROJECT/'actual_publication_20261019/tables'
FULL=ROOT/'tables/Source_Full_range_best_found_front.csv'

def source(name):
    p=PUB/name
    return p if p.exists() else ROOT/'tables'/('Source_'+name)


def periods(daily,meta):
    d=daily.copy();dates=pd.to_datetime(d.Date)
    first=pd.Timestamp(meta['First_irrigation_date']);switch=pd.Timestamp(meta['WP_switch'])
    flower_end=switch+pd.Timedelta(days=meta['FloweringCD']+1)
    hiend=pd.Timestamp(meta['Plant'])+pd.Timedelta(days=meta['HIend'])
    labels=['1 Before first irrigation','2 First irrigation to HI onset','3 Model flowering window',
            '4 Remaining yield formation','5 Terminal calendar window']
    d['Period']=np.select([dates<first,dates<switch,dates<flower_end,dates<hiend],[*labels[:4]],default=labels[4])
    rows=[]
    for label,a in d.groupby('Period',sort=True):
        e=dict(Year=int(a.Year.iloc[0]),Scenario=a.Scenario.iloc[0],Period=label,
            Start_date=a.Date.iloc[0],End_date=a.Date.iloc[-1],Days=len(a),
            Irrigation_mm=a.IrrDay.sum(),Rain_mm=a.Rain_mm.sum(),Tr_mm=a.Tr.sum(),Es_mm=a.Es.sum(),ET_mm=a.ET_mm.sum(),
            Runoff_mm=a.Runoff.sum(),Deep_percolation_mm=a.DeepPerc.sum(),Storage_change_mm=a.Storage_change_mm.sum(),
            Profile_start_mm=a.Profile_start_mm.iloc[0],Profile_end_mm=a.Profile_end_mm.iloc[-1],
            Max_CC=a.CC.max(),Mean_CC=a.CC.mean(),Final_root_depth_m=a.Root_depth_m.iloc[-1],
            Final_biomass_t_ha=a.Biomass_t_ha.iloc[-1],Final_HI_adj=a.HI_adj.iloc[-1],
            Mean_CC_expansion_Ks=a.CC_Ks_exp.mean(),
            Mean_stomatal_Ks=a.Tr_Ks_sto_lin.mean(),Mean_pollination_Ks=a.HI_Ks_pol.mean(),
            Stomatal_stress_days=int((a.Tr_Ks_sto_lin<.99).sum()),
            Aeration_stress_days=int((a.Tr_Ks_aeration<.99).sum()))
        rows.append(e)
    return pd.DataFrame(rows)


def main():
    engine=AuditEngine();chosen=pd.read_csv(source('NSGA_main_candidates.csv'),float_precision='round_trip').set_index('Year')
    front=pd.read_csv(FULL,float_precision='round_trip');screen=pd.read_csv(source('Terminal_storage_screening.csv'),float_precision='round_trip')
    all_summary=[];all_period=[];all_daily=[];all_layers=[];configs=[];soil=[];scenarios=[];comparisons=[];ET_status=[]
    for year in [2019,2020,2021,2022]:
        meta,prof=engine.configuration(year);spec=engine.specs[year]
        meta['First_irrigation_date']=spec['event_dates'][0];configs.append(meta);soil.append(prof)
        base=np.array(spec['baseline_amounts']);candidate=chosen.loc[year,spec['names']].to_numpy(float)
        available=front[(front.Year==year)&(front.Y_13pct>=chosen.loc[year].Model_baseline_Y13)].sort_values('Irrigation_mm')
        cases=[('DI',base,None),('C1',candidate,None),('Uniform_half_DI',.5*base,None)]
        if len(available):cases.append(('Minimum_water_at_model_DI_yield',available.iloc[0][spec['names']].to_numpy(float),None))
        if year in [2020,2021]:
            cap=meta['Baseline_MaxIrr_mm']
            limits=np.array([min(cap/w for j,w in zip(spec['event_stages'],spec['event_weights']) if j==i) for i in range(4)])
            cases.extend([('Uniform_at_C1_total',base*candidate.sum()/base.sum(),None),
                          ('C1_repaired_event_cap',np.minimum(candidate,limits),None)])
            a=front[front.Year==year].sort_values('Irrigation_mm');maxy=a.Y_13pct.max()
            cases.append(('Near_plateau_99p9',a[a.Y_13pct>=.999*maxy].iloc[0][spec['names']].to_numpy(float),None))
            for filter_name,label in [('same_baseline_end_storage','Existing_storage_at_DI'),('no_net_initial_storage_depletion','Existing_no_net_depletion')]:
                point=screen[(screen.Year==year)&(screen.Screen==filter_name)]
                if len(point) and point.Irrigation_mm.notna().all():cases.append((label,point.iloc[0][spec['names']].to_numpy(float),None))
        for label,x,root in cases:
            result,daily,layers,stress=engine.trace(year,label,x,root)
            result['Observed_Y13']=float(chosen.loc[year].Observed_Y13)
            result['Yield_pct_change_vs_observed']=100*(result['Y_13pct']/result['Observed_Y13']-1)
            result['Irrigation_reduction_pct']=100*(1-result['Irrigation_mm']/base.sum())
            result['Baseline_MaxIrr_mm']=meta['Baseline_MaxIrr_mm']
            result['Violates_original_event_cap']=result['Maximum_single_actual_irrigation_mm']>meta['Baseline_MaxIrr_mm']+1e-9
            all_summary.append(result);all_daily.append(daily);all_layers.append(layers)
            all_period.append(periods(daily,meta));scenarios.append(dict(Year=year,Scenario=label,Controls=x.tolist()))
            daily.to_csv(ROOT/'tables'/f'daily_{year}_{label}.csv',index=False)
            layers.to_csv(ROOT/'tables'/f'layers_{year}_{label}.csv.gz',index=False,compression='gzip')
            stress.to_csv(ROOT/'tables'/f'stress_{year}_{label}.csv.gz',index=False,compression='gzip')
            if label=='C1':
                canonical_w=pd.read_csv(source(f'Candidate_{year}_daily_water.csv'),float_precision='round_trip')
                canonical_g=pd.read_csv(source(f'Candidate_{year}_daily_growth.csv'),float_precision='round_trip')
                np.testing.assert_allclose(daily[['IrrDay','Tr','Es']].to_numpy(),canonical_w[['IrrDay','Tr','Es']].to_numpy(),atol=1e-10,rtol=0)
                np.testing.assert_allclose(daily[['Root_depth_m','CC','Biomass_t_ha']].to_numpy(),
                    np.c_[canonical_g.z_root,canonical_g.canopy_cover,canonical_g.biomass/100],atol=1e-10,rtol=0)
                comparisons.append(dict(Year=year,Canonical_candidate_daily_reproduction='PASS',Days=len(daily)))
            if label=='DI':
                ref=engine.study['baseline_reference'][str(year)]
                for key in ['Y_13pct','ET_mm','Tr_mm','Es_mm']:np.testing.assert_allclose(result[key],ref[key],atol=1e-7,rtol=0)
            print(year,label,'Y=',round(result['Y_13pct'],4),'I=',round(result['Irrigation_mm'],2),flush=True)

        if year in [2020,2021]:
            baseline=next(s for s in all_summary if s['Year']==year and s['Scenario']=='DI')
            # A diagnostic equal-ET comparison, never a forced rewrite of model ET.
            rng=np.random.default_rng(20261020+year);anchors=[base]
            for _ in range(128):
                a=rng.uniform(.45,1.0,4)*limits
                if a.sum()>base.sum():a*=base.sum()/a.sum()
                anchors.append(a)
            attempts=[(engine.basic(year,x),x) for x in anchors]
            positive=[(s,x) for s,x in attempts if s['ET_mm']>=baseline['ET_mm']+1e-6]
            if positive:
                response,anchor=min(positive,key=lambda item:item[0]['Irrigation_mm'])
                et_target=baseline['ET_mm']
                def residual(t):return engine.basic(year,(1-t)*candidate+t*anchor)['ET_mm']-et_target
                t=brentq(residual,0,1,xtol=1e-11)
                x=(1-t)*candidate+t*anchor
                result,daily,layers,stress=engine.trace(year,'ET_matched_diagnostic',x)
                assert abs(result['ET_mm']-et_target)<1e-5
                all_summary.append(result);all_daily.append(daily);all_layers.append(layers);all_period.append(periods(daily,meta))
                daily.to_csv(ROOT/'tables'/f'daily_{year}_ET_matched_diagnostic.csv',index=False)
                layers.to_csv(ROOT/'tables'/f'layers_{year}_ET_matched_diagnostic.csv.gz',index=False,compression='gzip')
                ET_status.append(dict(Year=year,Status='ET_MATCHED_BY_MODEL',ET_target_mm=et_target,ET_actual_mm=result['ET_mm'],Irrigation_mm=result['Irrigation_mm'],
                    Label='diagnostic interpolation; not newly optimized; event-cap feasibility checked separately',Max_single_event=result['Maximum_single_actual_irrigation_mm']))
            else:ET_status.append(dict(Year=year,Status='NO_ABOVE_TARGET_ANCHOR_FOUND_IN_129_PROBES',ET_target_mm=baseline['ET_mm']))

    # Root depth is varied only in a separately labeled one-factor hypothesis test.
    root_summary=[]
    for year in [2020,2021]:
        spec=engine.specs[year];base=np.array(spec['baseline_amounts']);candidate=chosen.loc[year,spec['names']].to_numpy(float)
        for depth in [.6,1.,1.5]:
            for label,x in [('DI',base),('C1',candidate)]:
                result,daily,layers,stress=engine.trace(year,f'Root{depth:g}_{label}',x,depth)
                root_summary.append(result)
                daily.to_csv(ROOT/'tables'/f'root_depth_test_{year}_{depth:g}_{label}.csv',index=False)
        for label in ['DI','C1']:
            result=next(s.copy() for s in all_summary if s['Year']==year and s['Scenario']==label)
            result['Root_depth_override_m']=2.3;root_summary.append(result)
    summary=pd.DataFrame(all_summary);summary.to_csv(ROOT/'tables/Scenario_summary.csv',index=False)
    pd.concat(all_daily,ignore_index=True).to_csv(ROOT/'tables/All_daily_traces.csv.gz',index=False,compression='gzip')
    pd.concat(all_layers,ignore_index=True).to_csv(ROOT/'tables/All_layer_traces.csv.gz',index=False,compression='gzip')
    pd.concat(all_period,ignore_index=True).to_csv(ROOT/'tables/Period_water_canopy_stress.csv',index=False)
    pd.DataFrame(root_summary).to_csv(ROOT/'tables/Root_depth_hypothesis_test.csv',index=False)
    pd.DataFrame(configs).to_csv(ROOT/'tables/Original_configuration.csv',index=False)
    pd.concat(soil,ignore_index=True).to_csv(ROOT/'tables/Soil_layers_and_initial_water.csv',index=False)
    pd.DataFrame(ET_status).to_csv(ROOT/'tables/ET_matching_diagnostic.csv',index=False)
    write(ROOT/'verification/Replay_scenarios.json',scenarios)
    write(ROOT/'verification/Canonical_daily_checks.json',comparisons)
    write(ROOT/'verification/Frozen_inputs_after_replay.json',engine.verify_frozen())
    for name in ['NSGA_main_candidates.csv','NSGA_event_schedules.csv','Irrigation_saving_decomposition.csv','Terminal_storage_screening.csv']:
        src=source(name);dest=ROOT/'tables'/('Source_'+name)
        if src.resolve()!=dest.resolve():shutil.copyfile(src,dest)
    initial=PROJECT/'frozen_inputs/inputs/DI_2019_2022_AquaCrop_InitialWater_FIELD_LOCKED.csv'
    shutil.copyfile(initial,ROOT/'tables/Source_initial_water_with_provenance_notes.csv')
    write(ROOT/'verification/TRACES_COMPLETE.json',dict(status='COMPLETE',scenarios=len(summary),root_depth_tests=len(root_summary),
        model_calls=engine.model_calls,canonical_daily_checks='PASS',initial_conditions_weather_film_central_params_unchanged=True,
        root_depth_changes_limited_to_separate_hypothesis_test=True,MCMC_runs=0))

if __name__=='__main__':main()
