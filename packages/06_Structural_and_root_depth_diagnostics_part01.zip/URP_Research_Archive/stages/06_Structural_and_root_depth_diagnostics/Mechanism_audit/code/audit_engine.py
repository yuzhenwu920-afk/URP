"""Read-only observers for the exact original annual AquaCrop engines.

Observers copy state and return the original functions' unmodified results.
No MCMC, crop equation or frozen input file is changed.
"""
from pathlib import Path
import contextlib,copy,functools,hashlib,importlib,inspect,json,sys,fcntl,os
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
PROJECT=Path(os.environ.get('URP_PROJECT','/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED'))
sys.path.insert(0,str(PROJECT))
from model_adapter import RealModel,load_study,management,validate_output


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False))


class AuditEngine:
    def __init__(self,accelerated=True):
        self.study=load_study();self.real=RealModel(self.study);self.adapter=self.real.module
        self.accelerated=accelerated
        # Original drivers write common audit-log temporary files when loading.
        # Serialize initialization only; simulation equations and data are untouched.
        with (ROOT/'verification/input_load.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            with (ROOT/'verification/input_loading.log').open('a') as log,contextlib.redirect_stdout(log):
                for year in self.study['years']:self.adapter._load(year)
            fcntl.flock(lock,fcntl.LOCK_UN)
        if accelerated:
            sys.path.insert(0,str(PROJECT/'real_model'))
            importlib.import_module('numerical_acceleration').install()
        self.identities=self.study['_frozen_hashes'].copy()
        self.identities['real_model/four_year_adapter.py']=sha(PROJECT/'real_model/four_year_adapter.py')
        self.specs={y:self.real.management_space(y) for y in self.study['years']}
        self.model_calls=0

    def basic(self,year,x):
        self.model_calls+=1
        raw=self.adapter.simulate(params=self.study['_centers'][year],year=year,
            management=management(self.specs[year],np.asarray(x,float)),accelerate=self.accelerated)
        return validate_output(raw,self.study['water_balance_atol_mm'])

    def configuration(self,year):
        mod,data=self.adapter._load(year)
        template=self.adapter._template(year,tuple(self.study['_centers'][year][k] for k in self.adapter.NAMES))
        p=data['soil'].profile.copy();p['Year']=year;p['Initial_theta']=data['theta']
        p['Initial_storage_mm']=p.Initial_theta*p.dz*1000
        p['Initial_available_above_WP_mm']=np.maximum(0,p.Initial_theta-p.th_wp)*p.dz*1000
        p['Soil_property_source']=np.where(p.zMid<=1,'0–1m texture-based soil properties','last 0–1m soil layer extended downward')
        sc=template._param_struct.Seasonal_Crop_List[0];fm=template._param_struct.FieldMngt;im=template._param_struct.IrrMngt
        meta=dict(Year=year,Plant=str(mod.PLANT.date()),Calendar_end=str(mod.DATES[-1].date()),WP_switch=str(mod.SWITCH.date()),
            Mulches=bool(fm.mulches),MulchPct=float(fm.mulch_pct),fMulch=float(fm.f_mulch),
            Mulch_Es_multiplier_if_no_ponding=1-float(fm.f_mulch)*float(fm.mulch_pct)/100,
            WetSurf_pct=float(im.WetSurf),AppEff_pct=float(im.AppEff),Baseline_MaxIrr_mm=float(im.MaxIrr),
            Zmin_m=float(sc.Zmin),Zmax_m=float(sc.Zmax),HIstartCD=float(sc.HIstartCD),
            FloweringCD=float(sc.FloweringCD),HIend=float(sc.HIend),Maturity=float(sc.Maturity),
            Initial_profile_storage_mm=float(p.Initial_storage_mm.sum()),
            Initial_available_above_WP_mm=float(p.Initial_available_above_WP_mm.sum()),
            Soil_depth_m=float(p.dz.sum()),Soil_compartments=len(p),
            Weather_sha256=hashlib.sha256(pd.util.hash_pandas_object(data['weather'],index=True).values.tobytes()).hexdigest(),
            Initial_theta_sha256=hashlib.sha256(np.asarray(data['theta'],float).tobytes()).hexdigest(),
            Parameters_sha256=hashlib.sha256(json.dumps(self.study['_centers'][year],sort_keys=True).encode()).hexdigest())
        return meta,p

    def trace(self,year,label,x,root_depth_override=None):
        mod,data=self.adapter._load(year);spec=self.specs[year]
        # Independent initialization provides the complete prefix for each observer run.
        self.adapter._template.cache_clear()
        step=importlib.import_module('aquacrop.timestep.run_single_timestep')
        cls=mod.AquaCropModel
        old_perform=cls._perform_timestep
        old_tr=step.transpiration;old_evap=step.soil_evaporation;old_infil=step.infiltration
        old_crop=mod.crop_for
        records=[];layer_records=[];stress_records=[];ctx={};replacements=[]
        prof=data['soil'].profile;dz=prof.dz.to_numpy(float);thwp=prof.th_wp.to_numpy(float);thfc=prof.th_fc.to_numpy(float)
        tr_module=importlib.import_module('aquacrop.solution.transpiration')
        old_aer=tr_module.aeration_stress
        @functools.wraps(old_aer)
        def aeration(*args,**kwargs):
            result=old_aer(*args,**kwargs)
            if ctx:ctx['row']['Tr_Ks_aeration']=float(result[0])
            return result
        tr_module.aeration_stress=aeration

        for stage,module_name in [('CC','canopy_cover'),('Tr','transpiration'),('HI','harvest_index')]:
            module=importlib.import_module('aquacrop.solution.'+module_name)
            original=module.water_stress
            def factory(fn,prefix):
                @functools.wraps(fn)
                def observed(*args,**kwargs):
                    result=fn(*args,**kwargs)
                    if ctx:
                        row=ctx['row'];count=int(row.get(prefix+'_stress_calls',0))+1
                        row[prefix+'_stress_calls']=count
                        for key,value in zip(['exp','sto','sen','pol','sto_lin'],result):
                            row[prefix+'_Ks_'+key]=float(value)
                            if count==1:row[prefix+'_Ks_'+key+'_first']=float(value)
                        row[prefix+'_Dr_used_mm']=float(args[6]);row[prefix+'_TAW_used_mm']=float(args[7])
                        stress_records.append(dict(Year=year,Scenario=label,Date=row['Date'],Function=prefix,
                            Call=count,Dr_mm=float(args[6]),TAW_mm=float(args[7]),
                            Ks_exp=float(result[0]),Ks_sto=float(result[1]),Ks_sen=float(result[2]),
                            Ks_pol=float(result[3]),Ks_sto_lin=float(result[4]),Beta=bool(args[9])))
                    return result
                return observed
            replacements.append((module,original));module.water_stress=factory(original,stage)

        @functools.wraps(old_tr)
        def transpiration(*args,**kwargs):
            cond=args[6];before=np.array(cond.th,copy=True);surface=float(cond.surface_storage)
            rz=step.root_zone_water(args[0],float(cond.z_root),cond.th,args[2],float(args[3].Zmin),args[3].Aer)
            ctx['row'].update(Tr_root_Dr_before_mm=float(rz[2]),Tr_root_TAW_before_mm=float(rz[4]),
                Tr_top_Dr_before_mm=float(rz[1]),Tr_top_TAW_before_mm=float(rz[3]))
            result=old_tr(*args,**kwargs);after=result[3]
            uptake=(before-np.asarray(after.th))*dz*1000
            ctx['uptake']=uptake
            ctx['row'].update(Tr_actual_mm=float(result[0]),Tr_potential_no_stress_mm=float(result[1]),
                Tr_potential_actual_canopy_mm=float(result[2]),Surface_uptake_mm=surface-float(after.surface_storage))
            np.testing.assert_allclose(uptake.sum()+surface-float(after.surface_storage),result[0],atol=1e-8,rtol=0)
            return result

        evap_sig=inspect.signature(old_evap)
        @functools.wraps(old_evap)
        def evaporation(*args,**kwargs):
            a=evap_sig.bind(*args,**kwargs).arguments
            before=np.array(a['NewCond_th'],copy=True)
            result=old_evap(*args,**kwargs)
            ctx['evap']=(before-np.asarray(result[1]))*dz*1000
            ctx['row'].update(MulchPct_runtime=float(a['FieldMngt_MulchPct']),
                fMulch_runtime=float(a['FieldMngt_fMulch']),Mulches_runtime=bool(a['FieldMngt_Mulches']),
                WetSurf_runtime=float(a['IrrMngt_WetSurf']),Es_actual_mm=float(result[7]),
                Es_potential_mm=float(result[8]),ETo_mm=float(a['et0']))
            return result

        @functools.wraps(old_infil)
        def infiltration(*args,**kwargs):
            before=np.array(args[3],copy=True);result=old_infil(*args,**kwargs)
            ctx['infil']=(np.asarray(result[0])-before)*dz*1000
            return result

        def perform(m):
            date=pd.Timestamp(m._clock_struct.step_start_time);idx=int(m._clock_struct.time_step_counter)
            before=np.array(m._init_cond.th,copy=True);s0=float(np.sum(before*dz)*1000);surf0=float(m._init_cond.surface_storage)
            ctx.clear();ctx.update(row=dict(Year=year,Scenario=label,Date=date.strftime('%Y-%m-%d'),Step=idx,
                Profile_start_mm=s0,Surface_start_mm=surf0),uptake=np.zeros(len(dz)),evap=np.zeros(len(dz)),infil=np.zeros(len(dz)))
            result=old_perform(m);clock,cond,param,out=result
            after=np.array(cond.th,copy=True);rz=step.root_zone_water(param.Soil.Profile,float(cond.z_root),after,param.Soil.z_top,
                float(param.Seasonal_Crop_List[0].Zmin),param.Seasonal_Crop_List[0].Aer)
            row=ctx['row'];row.update(DAP=float(cond.dap),Growing_season=bool(cond.growing_season),
                Root_depth_m=float(cond.z_root),CC=float(cond.canopy_cover),CC_no_stress=float(cond.canopy_cover_ns),
                Biomass_t_ha=float(cond.biomass/100),HI_adj=float(cond.harvest_index_adj),
                f_pre=float(cond.f_pre),f_post=float(cond.f_post),f_pol=float(cond.f_pol),
                Aeration_stress_days=float(cond.aer_days),Premature_senescence=bool(cond.premat_senes),
                Early_senescence_days=float(cond.t_early_sen),
                Y13_daily=float(cond.DryYield/.87),Profile_end_mm=float(np.sum(after*dz)*1000),
                Surface_end_mm=float(cond.surface_storage),Root_zone_water_end_mm=float(rz[0]),
                Root_zone_Dr_end_mm=float(rz[2]),Root_zone_TAW_end_mm=float(rz[4]),
                Root_zone_relative_depletion_end=float(rz[2]/rz[4]),
                AppEff_runtime=float(param.IrrMngt.AppEff),MaxIrr_runtime_mm=float(param.IrrMngt.MaxIrr))
            for depth in [.3,1.,1.5,2.3,2.4]:
                weights=np.clip(depth-prof.z_top.to_numpy(float),0,dz)
                suffix=str(depth).replace('.','p')
                row['Storage_0_'+suffix+'_m_mm']=float(np.sum(after*weights)*1000)
                row['Available_0_'+suffix+'_m_mm']=float(np.sum(np.maximum(after-thwp,0)*weights)*1000)
            records.append(row)
            for j in range(len(dz)):
                layer_records.append(dict(Year=year,Scenario=label,Date=row['Date'],Compartment=j+1,
                    Depth_top_m=float(prof.z_top.iloc[j]),Depth_bottom_m=float(prof.dzsum.iloc[j]),
                    theta_start=float(before[j]),theta_end=float(after[j]),theta_FC=float(thfc[j]),theta_WP=float(thwp[j]),
                    Relative_available_end=float((after[j]-thwp[j])/(thfc[j]-thwp[j])),
                    Storage_change_mm=float((after[j]-before[j])*dz[j]*1000),
                    Transpiration_uptake_mm=float(ctx['uptake'][j]),Evaporation_uptake_mm=float(ctx['evap'][j]),
                    Infiltration_storage_increment_mm=float(ctx['infil'][j])))
            return result

        if root_depth_override is not None:
            def crop(v):
                c=old_crop(v);c.Zmax=float(root_depth_override);return c
            mod.crop_for=crop
        cls._perform_timestep=perform;step.transpiration=transpiration;step.soil_evaporation=evaporation;step.infiltration=infiltration
        try:
            self.model_calls+=1
            summary,water,growth=self.adapter.simulate(params=self.study['_centers'][year],year=year,
                management=management(spec,np.asarray(x,float)),details=True,accelerate=self.accelerated)
        finally:
            cls._perform_timestep=old_perform;step.transpiration=old_tr;step.soil_evaporation=old_evap;step.infiltration=old_infil
            for module,original in replacements:module.water_stress=original
            mod.crop_for=old_crop;self.adapter._template.cache_clear()
            tr_module.aeration_stress=old_aer
        daily=pd.DataFrame(records);layers=pd.DataFrame(layer_records);stress=pd.DataFrame(stress_records)
        assert len(daily)==len(mod.DATES) and not daily.Date.duplicated().any()
        assert daily.MulchPct_runtime.eq(75).all() and daily.fMulch_runtime.eq(0).all()
        assert daily.AppEff_runtime.eq(100).all() and daily.WetSurf_runtime.eq(100).all()
        water=water.copy();water['Date']=water.Date.dt.strftime('%Y-%m-%d')
        for key in ['IrrDay','Tr','TrPot','Es','EsPot','Runoff','DeepPerc','TileDrain','CR','GwIn']:
            daily[key]=water[key].to_numpy()
        weather=data['weather'].set_index('Date').loc[mod.DATES]
        daily['Rain_mm']=weather.Precipitation.to_numpy();daily['ET_mm']=daily.Tr+daily.Es
        daily['Storage_change_mm']=daily.Profile_end_mm-daily.Profile_start_mm+daily.Surface_end_mm-daily.Surface_start_mm
        daily['Water_balance_residual_mm']=daily.Rain_mm+daily.IrrDay+daily.CR+daily.GwIn-daily.ET_mm-daily.Runoff-daily.DeepPerc-daily.TileDrain-daily.Storage_change_mm
        assert daily.Water_balance_residual_mm.abs().max()<1e-7
        assert np.isclose(layers.Transpiration_uptake_mm.sum()+daily.Surface_uptake_mm.sum(),summary['Tr_mm'],atol=1e-7)
        raw=validate_output(summary,self.study['water_balance_atol_mm'])
        raw.update(Year=year,Scenario=label,Root_depth_override_m=root_depth_override,
            Maximum_single_actual_irrigation_mm=float(water.IrrDay.max()),
            Invariant_scope='all original conditions' if root_depth_override is None else 'separate root-depth hypothesis test; not a corrected calibration',
            **{k:float(v) for k,v in zip(spec['names'],x)})
        return raw,daily,layers,stress

    def verify_frozen(self):
        for path,digest in self.identities.items():assert sha(PROJECT/path)==digest,path
        return dict(status='PASS',hashes=self.identities,model_calls=self.model_calls,MCMC_runs=0)
