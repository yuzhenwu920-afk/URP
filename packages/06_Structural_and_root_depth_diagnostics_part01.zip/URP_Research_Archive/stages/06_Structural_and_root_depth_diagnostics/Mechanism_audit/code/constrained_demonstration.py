"""Actual-model NSGA-III diagnostic reruns with explicit management limits.

The original single-event setting is a controlled-comparison cap, not an
independently measured equipment capacity. Storage floors are diagnostic
comparators, not newly established field sustainability thresholds.
"""
from pathlib import Path
import concurrent.futures,contextlib,json,time
import numpy as np
import pandas as pd
from pymoo.core.problem import Problem
from pymoo.core.repair import Repair
from pymoo.core.callback import Callback
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.optimize import minimize
from pymoo.util.ref_dirs import get_reference_directions
from audit_engine import AuditEngine,ROOT,PROJECT,write

OUT=ROOT/'constrained_runs'
POP,GEN,SEEDS=64,50,[31,73]
POLICIES=['fixed_event_setting_only','fixed_event_no_net_depletion','fixed_event_same_DI_final_storage']


class RepairControls(Repair):
    def _do(self,problem,X,**kwargs):
        a=np.clip(X,0,problem.xu)
        total=a.sum(axis=1)
        scale=np.ones(len(a));mask=total>problem.cap;scale[mask]=problem.cap/total[mask]
        return a*scale[:,None]


class ManagementProblem(Problem):
    def __init__(self,engine,year,policy,folder):
        self.engine,self.year,self.policy,self.folder=engine,year,policy,folder
        self.spec=engine.specs[year];self.base=np.array(self.spec['baseline_amounts'])
        self.cap=float(self.base.sum());self.observed=engine.study['observed_Y13'][str(year)]
        self.gate=.95*self.observed
        self.meta,_=engine.configuration(year);self.event_cap=self.meta['Baseline_MaxIrr_mm']
        upper=np.array([min(self.event_cap/w for j,w in zip(self.spec['event_stages'],self.spec['event_weights']) if j==i) for i in range(4)])
        baseline=engine.basic(year,self.base)
        self.storage_floor=(None if policy==POLICIES[0] else self.meta['Initial_profile_storage_mm'] if policy==POLICIES[1] else baseline['Profile_final_mm'])
        self.rows=[];self.baseline=baseline
        super().__init__(n_var=4,n_obj=2,n_ieq_constr=2+(self.storage_floor is not None),xl=np.zeros(4),xu=upper)

    def _evaluate(self,X,out,*args,**kwargs):
        fs=[];gs=[]
        for x in X:
            r=self.engine.basic(self.year,x)
            maxevent=max(e['mm'] for e in r['irrigation_events'])
            assert maxevent<=self.event_cap+1e-9
            assert r['Irrigation_mm']<=self.cap+1e-9
            delta=[r['Irrigation_mm']-self.cap,self.gate-r['Y_13pct']]
            limits=[self.cap,self.observed]
            if self.storage_floor is not None:
                delta.append(self.storage_floor-r['Profile_final_mm']);limits.append(self.storage_floor)
            g=[0. if abs(d)<=64*np.finfo(float).eps*max(1,lim) else d/lim for d,lim in zip(delta,limits)]
            fs.append([-r['Y_13pct'],r['Irrigation_mm']]);gs.append(g)
            self.rows.append(dict(Evaluation=len(self.rows),Year=self.year,Policy=self.policy,
                **{k:float(v) for k,v in zip(self.spec['names'],x)},
                **{k:r[k] for k in ['Y_13pct','Irrigation_mm','Tr_mm','Es_mm','ET_mm','Profile_initial_mm','Profile_final_mm','Runoff_mm','DeepPerc_mm','Water_balance_residual_mm']},
                Max_single_event_mm=maxevent,Event_cap_mm=self.event_cap,
                Storage_floor_mm=self.storage_floor,Feasible=bool(max(g)<=0),Maximum_scaled_violation=float(max(g))))
        out['F']=np.array(fs);out['G']=np.array(gs)


class History(Callback):
    def __init__(self,problem):super().__init__();self.problem=problem;self.rows=[]
    def notify(self,algorithm):
        gen=int(algorithm.n_gen);pop=algorithm.pop
        X,F,G,CV=pop.get('X'),pop.get('F'),pop.get('G'),pop.get('CV')
        np.savez_compressed(self.problem.folder/f'generation_{gen:04d}.npz',X=X,F=F,G=G,CV=CV)
        feasible=CV[:,0]<=0
        row=dict(Generation=gen,Evaluations=len(self.problem.rows),Feasible_individuals=int(feasible.sum()),
            Minimum_irrigation_mm=float(F[feasible,1].min()) if feasible.any() else None,
            Minimum_constraint_violation=float(CV.min()))
        self.rows.append(row)
        if gen%5==0 or gen==1:write(self.problem.folder/'progress.json',dict(status='RUNNING',**row))


def run_one(year,policy,seed):
    folder=OUT/str(year)/policy/f'seed{seed}';folder.mkdir(parents=True,exist_ok=True)
    if (folder/'run.json').exists():
        existing=json.loads((folder/'run.json').read_text())
        if existing['status']=='COMPLETE' and existing['Evaluations']==POP*GEN:return existing
        raise FileExistsError('Do not overwrite an incomplete or incompatible diagnostic search')
    start=time.monotonic();engine=AuditEngine();problem=ManagementProblem(engine,year,policy,folder)
    # Hold both original runtime irrigation settings fixed, rather than allowing
    # the simulator to enlarge MaxIrr for a large proposed event.
    mod,_=engine.adapter._load(year);cls=mod.AquaCropModel;original=cls._perform_timestep
    def fixed_limits(model):
        model._param_struct.IrrMngt.MaxIrr=problem.event_cap
        model._param_struct.IrrMngt.MaxIrrSeason=problem.cap+.1
        return original(model)
    cls._perform_timestep=fixed_limits;engine.adapter._template.cache_clear()
    rng=np.random.default_rng(seed)
    initial=rng.uniform(0,1,(POP,4))*problem.xu
    initial[0]=problem.base
    for i in range(1,POP//2):initial[i]=problem.base*(1+rng.normal(0,.06,4))
    repair=RepairControls();initial=repair._do(problem,initial)
    callback=History(problem)
    algorithm=NSGA3(pop_size=POP,ref_dirs=get_reference_directions('das-dennis',2,n_partitions=POP-1),
        sampling=initial,repair=repair,eliminate_duplicates=True)
    try:
        result=minimize(problem,algorithm,('n_gen',GEN),seed=seed,callback=callback,verbose=False)
    finally:
        cls._perform_timestep=original;engine.adapter._template.cache_clear()
    evaluations=pd.DataFrame(problem.rows)
    assert len(evaluations)==POP*GEN
    evaluations.to_csv(folder/'evaluations.csv.gz',index=False,compression='gzip')
    pd.DataFrame(callback.rows).to_csv(folder/'history.csv',index=False)
    eligible=evaluations[evaluations.Feasible]
    if len(eligible):
        point=eligible.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False]).iloc[0].to_dict()
        point['Seed']=seed
    else:point=None
    summary=dict(status='COMPLETE',Year=year,Policy=policy,Seed=seed,Population=POP,Generations=GEN,
        Evaluations=len(evaluations),Seconds=time.monotonic()-start,Candidate=point,
        Best_found_not_global=True,Original_single_event_setting_mm=problem.event_cap,
        Storage_floor_mm=problem.storage_floor,
        Definition='conditional actual-model diagnostic; unchanged film/weather/initial soil/crop centers; not full formal rerun',
        Frozen_input_check=engine.verify_frozen())
    write(folder/'run.json',summary);write(folder/'progress.json',dict(status='COMPLETE',Evaluations=len(evaluations)))
    return summary


def main():
    OUT.mkdir(exist_ok=True)
    jobs=[(y,p,s) for y in [2020,2021] for p in POLICIES for s in SEEDS]
    write(ROOT/'verification/CONSTRAINED_RUN_STATUS.json',dict(status='RUNNING',jobs=len(jobs),population=POP,generations=GEN,seeds=SEEDS,
        planned_evaluations=len(jobs)*POP*GEN,policies=POLICIES,
        actual_ET_is_response=True,ETo_drivers_unchanged=True,film_unchanged=True,
        cap_is_original_model_setting_not_measured_hardware=True))
    results=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(run_one,*j) for j in jobs]
        for future in concurrent.futures.as_completed(futures):
            r=future.result();results.append(r)
            print(r['Year'],r['Policy'],r['Seed'],'COMPLETE',r['Candidate']['Irrigation_mm'] if r['Candidate'] else 'no candidate',flush=True)
    write(ROOT/'verification/Constrained_search_jobs.json',results)
    points=[r['Candidate'] for r in results if r['Candidate'] is not None]
    pd.DataFrame(points).to_csv(ROOT/'tables/Constrained_seed_candidates.csv',index=False)
    records=[]
    for (year,policy),a in pd.DataFrame(points).groupby(['Year','Policy']):
        selected=a.sort_values('Irrigation_mm').iloc[0].to_dict()
        selected['Irrigation_reduction_pct']=100*(1-selected['Irrigation_mm']/({2020:559.76,2021:633.47}[year]))
        selected['Interpretation']='best observed feasible evaluation from two diagnostic seeds; not proven global optimum'
        records.append(selected)
    pd.DataFrame(records).to_csv(ROOT/'tables/Constrained_best_found_candidates.csv',index=False)
    write(ROOT/'verification/CONSTRAINED_RUN_STATUS.json',dict(status='COMPLETE',jobs=len(results),evaluations=sum(r['Evaluations'] for r in results),
        population=POP,generations=GEN,seeds=SEEDS,policies=POLICIES,cap_is_original_model_setting_not_measured_hardware=True,
        original_formal_experiment_unchanged=True,MCMC_runs=0))

if __name__=='__main__':main()
