"""Derive auditable mechanism tables and publication-size English figures."""
from pathlib import Path
import ast,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from audit_engine import ROOT

T=ROOT/'tables';F=ROOT/'figures'
YEARS=[2019,2020,2021,2022];FOCUS=[2020,2021]
COL={'DI':'#344955','C1':'#C16B26'}
YEARCOL={2019:'#0072B2',2020:'#D55E00',2021:'#009E73',2022:'#A45A9D'}
POL=['fixed_event_setting_only','fixed_event_no_net_depletion','fixed_event_same_DI_final_storage']
POL_LABEL=['Event setting\nonly','No net initial\nstorage loss','Same DI final\nstorage']
REG=[]

def read(name):return pd.read_csv(T/(name+'.csv'),float_precision='round_trip')
def save(fig,name,title,sources,meaning,limit):
    fig.savefig(F/(name+'.png'),dpi=600,bbox_inches='tight',facecolor='white')
    fig.savefig(F/(name+'.pdf'),bbox_inches='tight',facecolor='white')
    fig.savefig(F/(name+'.svg'),bbox_inches='tight',facecolor='white')
    plt.close(fig)
    REG.append(dict(ID=name,Title=title,Source_tables=sources,Interpretation=meaning,Boundary=limit))
def dates(ax):
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
def clean(ax):
    ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.17,zorder=0)
def panel(ax,label):ax.text(0,1.035,label,transform=ax.transAxes,fontweight='bold',fontsize=11)

def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.labelsize':12,'axes.titlesize':13,
        'xtick.labelsize':10.5,'ytick.labelsize':10.5,'legend.fontsize':10,'axes.linewidth':.8,
        'svg.fonttype':'none','pdf.fonttype':42})
    s=read('Scenario_summary');cfg=read('Original_configuration').set_index('Year')
    d=pd.read_csv(T/'All_daily_traces.csv.gz');d['Time']=pd.to_datetime(d.Date)
    layers=pd.read_csv(T/'All_layer_traces.csv.gz');layers['Time']=pd.to_datetime(layers.Date)
    period=read('Period_water_canopy_stress');depth=read('Root_depth_hypothesis_test')
    best=read('Constrained_best_found_candidates');seeds=read('Constrained_seed_candidates')
    eq=read('Equal_ET_fixed_management_diagnostics')
    s0=s[s.Scenario.isin(['DI','C1'])].copy()
    overview=[];balances=[];bio=[];uptake=[];events=[];bounds=[]
    for y in YEARS:
        b=s0[(s0.Year==y)&(s0.Scenario=='DI')].iloc[0];c=s0[(s0.Year==y)&(s0.Scenario=='C1')].iloc[0]
        di=b.Irrigation_mm-c.Irrigation_mm;de=b.ET_mm-c.ET_mm;ds=b.Profile_final_mm-c.Profile_final_mm
        dl=(b.Runoff_mm+b.DeepPerc_mm+b.TileDrain_mm)-(c.Runoff_mm+c.DeepPerc_mm+c.TileDrain_mm)
        overview.append(dict(Year=y,Observed_Y13=b.Observed_Y13,DI_Y13=b.Y_13pct,C1_Y13=c.Y_13pct,
            DI_Irrigation_mm=b.Irrigation_mm,C1_Irrigation_mm=c.Irrigation_mm,Irrigation_reduction_pct=100*di/b.Irrigation_mm,
            C1_yield_change_vs_DI_pct=100*(c.Y_13pct/b.Y_13pct-1),C1_yield_change_vs_observed_pct=100*(c.Y_13pct/b.Observed_Y13-1),
            DI_ET_mm=b.ET_mm,C1_ET_mm=c.ET_mm,DI_final_storage_mm=b.Profile_final_mm,C1_final_storage_mm=c.Profile_final_mm))
        balances.append(dict(Year=y,Rain_mm=b.Rain_mm,Initial_storage_mm=b.Profile_initial_mm,
            DI_storage_change_mm=b.Profile_final_mm-b.Profile_initial_mm,C1_storage_change_mm=c.Profile_final_mm-c.Profile_initial_mm,
            Irrigation_reduction_mm=di,ET_reduction_mm=de,Final_storage_difference_mm=ds,Loss_reduction_mm=dl,
            Storage_difference_share_pct=100*ds/di,Closure_residual_mm=di-de-ds-dl,
            Remainder_after_storage_difference_mm=di-ds,Remainder_vs_DI_irrigation_pct=100*(di-ds)/b.Irrigation_mm,
            ET_reduction_pct=100*de/b.ET_mm))
        bounds.append(dict(Year=y,Fixed_ET_target_mm=b.ET_mm,Rain_mm=b.Rain_mm,
            Minimum_I_from_fixed_ET_and_no_initial_depletion_mm=b.ET_mm-b.Rain_mm,
            Maximum_reduction_pct_necessary_bound=100*(1-(b.ET_mm-b.Rain_mm)/b.Irrigation_mm),
            Definition='necessary water-balance bound with runoff/drainage set to zero; not a feasible optimized policy'))
        for label in ['DI','C1']:
            q=d[(d.Year==y)&(d.Scenario==label)];a=layers[(layers.Year==y)&(layers.Scenario==label)]
            active=q[q.CC>.1];fl=period[(period.Year==y)&(period.Scenario==label)&period.Period.str.startswith('3')]
            bio.append(dict(Year=y,Scenario=label,Max_CC=q.CC.max(),Final_biomass_t_ha=q.Biomass_t_ha.iloc[-1],
                Maximum_root_depth_m=q.Root_depth_m.max(),First_1m_root_date=q.loc[q.Root_depth_m>=1,'Date'].iloc[0],
                Stomatal_Ks_active_mean=active.Tr_Ks_sto_lin.mean(),Stomatal_days_Ks_below_0p99=int((active.Tr_Ks_sto_lin<.99).sum()),
                Flowering_mean_pollination_Ks=float(fl.Mean_pollination_Ks.iloc[0]),Aeration_stress_days=int((q.Tr_Ks_aeration<.99).sum()),
                Max_water_balance_error_mm=q.Water_balance_residual_mm.abs().max()))
            for top,bot in [(0,1),(1,2.4)]:
                subset=a[(a.Depth_top_m>=top-1e-8)&(a.Depth_bottom_m<=bot+1e-8)]
                uptake.append(dict(Year=y,Scenario=label,Depth_band='0–1 m' if top==0 else '1–2.4 m',
                    Transpiration_uptake_mm=subset.Transpiration_uptake_mm.sum(),Net_storage_change_mm=subset.Storage_change_mm.sum(),
                    Definition='direct modeled uptake and net stock change are different quantities; no source-water tagging'))
            row=s0[(s0.Year==y)&(s0.Scenario==label)].iloc[0]
            for e in ast.literal_eval(row.irrigation_events):
                events.append(dict(Year=y,Scenario=label,Date=e['date'],Irrigation_mm=e['mm'],Control_window=e['stage']+1,
                    Original_event_setting_mm=cfg.loc[y].Baseline_MaxIrr_mm,
                    Exceeds_original_setting=e['mm']>cfg.loc[y].Baseline_MaxIrr_mm+1e-9))
    period_layers=[]
    for _,row in period[period.Scenario.isin(['DI','C1'])].iterrows():
        a=layers[(layers.Year==row.Year)&(layers.Scenario==row.Scenario)&(layers.Date>=row.Start_date)&(layers.Date<=row.End_date)]
        for compartment,q in a.groupby('Compartment'):
            q=q.sort_values('Date')
            period_layers.append(dict(Year=row.Year,Scenario=row.Scenario,Period=row.Period,Compartment=compartment,
                Depth_top_m=q.Depth_top_m.iloc[0],Depth_bottom_m=q.Depth_bottom_m.iloc[0],
                Theta_start=q.theta_start.iloc[0],Theta_end=q.theta_end.iloc[-1],Theta_mean=q.theta_end.mean(),
                Relative_available_mean=q.Relative_available_end.mean(),Net_storage_change_mm=q.Storage_change_mm.sum(),
                Transpiration_uptake_mm=q.Transpiration_uptake_mm.sum(),Evaporation_uptake_mm=q.Evaporation_uptake_mm.sum()))
    pd.DataFrame(period_layers).to_csv(T/'Period_soil_water_by_layer.csv',index=False)
    ov=pd.DataFrame(overview);bal=pd.DataFrame(balances);bio=pd.DataFrame(bio);up=pd.DataFrame(uptake);ev=pd.DataFrame(events)
    for name,frame in [('Four_year_DI_C1_comparison',ov),('Water_reduction_accounting',bal),('Canopy_stress_diagnostics',bio),
        ('Depth_uptake_and_net_storage',up),('Actual_event_schedules_DI_C1',ev),('Fixed_ET_water_balance_necessary_bounds',pd.DataFrame(bounds))]:frame.to_csv(T/(name+'.csv'),index=False)
    comparison=[]
    for y in FOCUS:
        b=s0[(s0.Year==y)&(s0.Scenario=='DI')].iloc[0]
        for label in ['DI','C1','Uniform_half_DI','Uniform_at_C1_total','Minimum_water_at_model_DI_yield']:
            r=s[(s.Year==y)&(s.Scenario==label)].iloc[0]
            comparison.append(dict(Year=y,Case=label,Irrigation_mm=r.Irrigation_mm,Y13_t_ha=r.Y_13pct,ET_mm=r.ET_mm,
                Final_storage_mm=r.Profile_final_mm,Reduction_pct=100*(1-r.Irrigation_mm/b.Irrigation_mm),
                Yield_change_vs_DI_pct=100*(r.Y_13pct/b.Y_13pct-1),Type='original-settings replay'))
        for _,r in best[best.Year==y].iterrows():
            comparison.append(dict(Year=y,Case=r.Policy,Irrigation_mm=r.Irrigation_mm,Y13_t_ha=r.Y_13pct,ET_mm=r.ET_mm,
                Final_storage_mm=r.Profile_final_mm,Reduction_pct=r.Irrigation_reduction_pct,
                Yield_change_vs_DI_pct=100*(r.Y_13pct/b.Y_13pct-1),Type='new constrained diagnostic search'))
    pd.DataFrame(comparison).to_csv(T/'Focus_case_comparison.csv',index=False)

    # D01: the identity behind apparent irrigation savings, all four years.
    fig,axs=plt.subplots(1,2,figsize=(10.4,4),layout='constrained')
    x=np.arange(4);bottom=np.zeros(4)
    for key,label,color in [('Final_storage_difference_mm','Lower final soil storage','#D99B4E'),('ET_reduction_mm','Lower actual ET','#3C8DAD'),('Loss_reduction_mm','Lower runoff / drainage','#7F8E91')]:
        v=bal[key].to_numpy();axs[0].bar(x,v,bottom=bottom,color=color,width=.6,label=label,zorder=3);bottom+=v
    for i,r in bal.iterrows():axs[0].text(i,bottom[i]+6,f'{r.Storage_difference_share_pct:.1f}%\nfrom storage',ha='center',fontsize=9)
    axs[0].set(xticks=x,xticklabels=YEARS,ylabel='Reduction relative to DI (mm)',ylim=(0,bottom.max()*1.23))
    axs[0].legend(loc='upper left',fontsize=8);panel(axs[0],'(a) Irrigation reduction accounting')
    for j,label in enumerate(['DI','C1']):
        vals=[s0[(s0.Year==y)&(s0.Scenario==label)].iloc[0].Profile_final_mm-s0[(s0.Year==y)&(s0.Scenario==label)].iloc[0].Profile_initial_mm for y in YEARS]
        axs[1].bar(x+(j-.5)*.3,vals,width=.29,color=COL[label],label='Original DI' if label=='DI' else 'Original C1',zorder=3)
    axs[1].axhline(0,color='.35',lw=.8);axs[1].set(xticks=x,xticklabels=YEARS,ylabel='Seasonal soil storage change (mm)')
    panel(axs[1],'(b) Recharge versus depletion');axs[1].legend()
    for ax in axs:clean(ax)
    save(fig,'D01_Water_accounting_four_years','Apparent irrigation reductions and soil-storage accounting',
        ['Water_reduction_accounting.csv'],'2020/2021年季末储水差解释灌水减少量的93.3%/97.4%；原DI增储而C1耗储。',
        '季末储水差不是全部来自初始深层水；该图不证明盆地尺度净节水。')

    # D02: canopy, plant-water stress and daily profile storage.
    fig,axs=plt.subplots(3,2,figsize=(10.2,8.2),sharex='col',layout='constrained')
    fields=[('Profile_end_mm','Profile water storage (mm)'),('CC','Canopy cover (fraction)'),('Tr_Ks_sto_lin','Stomatal stress coefficient')]
    for col,y in enumerate(FOCUS):
        for row,(field,ylab) in enumerate(fields):
            ax=axs[row,col]
            for label in ['DI','C1']:
                a=d[(d.Year==y)&(d.Scenario==label)]
                ax.plot(a.Time,a[field],color=COL[label],lw=1.8,label='Original DI' if label=='DI' else 'Original C1')
            sw=pd.Timestamp(cfg.loc[y].WP_switch);ax.axvspan(sw,sw+pd.Timedelta(days=cfg.loc[y].FloweringCD),color='#AABFC2',alpha=.2)
            if row==0:
                ax.axhline(cfg.loc[y].Initial_profile_storage_mm,color='.55',ls=':',lw=1,label='Initial storage')
                panel(ax,f'({chr(97+col)}) {y}')
            if row==1:ax.set_ylim(0,1.02)
            if row==2:ax.set_ylim(-.03,1.04);dates(ax)
            if col==0:ax.set_ylabel(ylab)
            clean(ax)
    axs[0,0].legend(loc='upper left',fontsize=8);axs[2,0].set_xlabel('Date');axs[2,1].set_xlabel('Date')
    save(fig,'D02_Daily_storage_canopy_stress','Daily water storage, canopy and stomatal response',
        ['All_daily_traces.csv.gz','Canopy_stress_diagnostics.csv'],'C1的主要差异出现在季末储水；冠层峰值接近，模型开花窗口内授粉胁迫系数接近1。',
        '灰色窗为模型日历开花窗口，并非独立田间物候观测；K=1表示该项水分胁迫未触发。')

    # D03: soil moisture at 24 original compartments.
    fig,axs=plt.subplots(2,2,figsize=(10.4,6.3),layout='constrained',sharey=True)
    for row,y in enumerate(FOCUS):
        for col,label in enumerate(['DI','C1']):
            ax=axs[row,col];a=layers[(layers.Year==y)&(layers.Scenario==label)]
            p=a.pivot(index='Depth_top_m',columns='Time',values='Relative_available_end').sort_index()
            times=mdates.date2num(pd.to_datetime(p.columns));edges=np.r_[times-.5,times[-1]+.5]
            zz=np.r_[p.index.to_numpy(),2.4]
            im=ax.pcolormesh(edges,zz,p.to_numpy(),vmin=0,vmax=1.2,cmap='YlGnBu',rasterized=True)
            q=d[(d.Year==y)&(d.Scenario==label)];ax.plot(q.Time,q.Root_depth_m,color='#A83625',lw=1.3,ls='--')
            ax.axhline(1,color='white',lw=.8,ls=':');ax.set_ylim(2.4,0);dates(ax)
            panel(ax,f'({chr(97+row*2+col)}) {y} | '+('Original DI' if label=='DI' else 'Original C1'))
            if col==0:ax.set_ylabel('Depth (m)')
            if row==1:ax.set_xlabel('Date')
    cb=fig.colorbar(im,ax=axs,shrink=.8,pad=.015);cb.set_label(r'Relative available water, $(\theta-\theta_{WP})/(\theta_{FC}-\theta_{WP})$')
    axs[0,0].legend(handles=[Line2D([],[],color='#A83625',ls='--',label='Modeled root depth')],loc='lower left',fontsize=8)
    save(fig,'D03_Layer_moisture_and_roots','Soil moisture redistribution and modeled root depth',
        ['All_layer_traces.csv.gz','All_daily_traces.csv.gz'],'深层在原DI中有显著补蓄；C1减轻补蓄，同时降低表层含水。',
        '色标为田间持水量与萎蔫点之间的相对可利用水，不是饱和度；色标截在0与1.2；深层土壤性质与初始水仍需现场证据。')

    # D04: calendar-defined periods: I, Tr, Es, storage.
    fig,axs=plt.subplots(3,2,figsize=(10.4,8.4),layout='constrained',sharex=True)
    ticks=['Pre-I','Pre-HI','Flowering','Yield form.','Terminal'];x=np.arange(5)
    for col,y in enumerate(FOCUS):
        for j,label in enumerate(['DI','C1']):
            q=period[(period.Year==y)&(period.Scenario==label)].sort_values('Period');xx=x+(j-.5)*.34
            axs[0,col].bar(xx,q.Irrigation_mm,width=.32,color=COL[label],label='Original DI' if label=='DI' else 'Original C1',zorder=3)
            axs[1,col].bar(xx,q.Tr_mm,width=.32,color=COL[label],zorder=3)
            axs[1,col].bar(xx,q.Es_mm,bottom=q.Tr_mm,width=.32,color=COL[label],alpha=.38,hatch='///',zorder=3)
            axs[2,col].bar(xx,q.Storage_change_mm,width=.32,color=COL[label],zorder=3)
        panel(axs[0,col],f'({chr(97+col)}) {y}');axs[2,col].axhline(0,color='.3',lw=.8)
        axs[2,col].set(xticks=x,xticklabels=ticks)
        for row in range(3):clean(axs[row,col])
    axs[0,0].set_ylabel('Irrigation (mm)');axs[1,0].set_ylabel('ET (Tr + Es; mm)');axs[2,0].set_ylabel('Storage change (mm)')
    axs[0,0].legend(fontsize=8);axs[1,0].legend(handles=[Patch(facecolor='.5',label='Transpiration'),Patch(facecolor='.8',hatch='///',label='Soil evaporation')],fontsize=8)
    save(fig,'D04_Period_water_budgets','Water allocation over model calendar periods',
        ['Period_water_canopy_stress.csv'],'2020年C1几乎全部灌水前置，生殖期依赖储水；2021年原DI后期灌水相当一部分留在土壤。',
        '五个诊断日历时期与四个优化决策窗口不同；不得直接解释成五次田间灌水。')

    # D05: event limits originally expanded by the optimizer adapter.
    fig,axs=plt.subplots(2,1,figsize=(10.2,6.5),layout='constrained')
    for ax,y in zip(axs,FOCUS):
        q=ev[ev.Year==y];days=sorted(q.Date.unique());x=np.arange(len(days))
        for j,label in enumerate(['DI','C1']):
            a=q[q.Scenario==label].set_index('Date').loc[days]
            ax.bar(x+(j-.5)*.34,a.Irrigation_mm,width=.32,color=COL[label],label='Original DI' if label=='DI' else 'Original C1',zorder=3)
        ax.axhline(cfg.loc[y].Baseline_MaxIrr_mm,color='#973C3C',ls='--',lw=1.1,label='Original single-event setting')
        ax.set(xticks=x,xticklabels=[v[5:] for v in days],ylabel='Actual irrigation (mm)');panel(ax,str(y));clean(ax)
    axs[0].legend(ncol=3,loc='upper right',fontsize=8);axs[1].set_xlabel('Irrigation date (month–day)')
    save(fig,'D05_Event_allocation_and_original_setting','Actual irrigation events and the original per-event setting',
        ['Actual_event_schedules_DI_C1.csv','Original_configuration.csv'],'原接口随候选调大MaxIrr，2020年C1单次约180mm超过原日程执行设置84.88mm。',
        '用户已确认原MaxIrr是保障实测日程执行的数值上限，并非设备极限；固定原上限只是受控诊断，不能凭此认定原接口错误。')

    # D06: independent one-factor hypothesis test, never label as recalibration.
    fig,axs=plt.subplots(1,2,figsize=(10,3.8),layout='constrained',sharey=True)
    for ax,y in zip(axs,FOCUS):
        for label in ['DI','C1']:
            q=depth[(depth.Year==y)&depth.Scenario.str.endswith(label)].sort_values('Root_depth_override_m')
            ax.plot(q.Root_depth_override_m,q.Y_13pct,'o-',lw=1.7,color=COL[label],label='Original DI schedule' if label=='DI' else 'Original C1 schedule')
        ax.axvline(2.3,ls=':',color='.4');ax.set(xticks=[.6,1,1.5,2.3],xlabel='Maximum root depth in hypothesis test (m)',ylim=(0,18));panel(ax,str(y));clean(ax)
    axs[0].set_ylabel(r'Grain yield at 13% moisture (t ha$^{-1}$)');axs[0].legend(fontsize=8,loc='lower right')
    save(fig,'D06_Root_depth_hypothesis_test','Root-depth sensitivity of fixed irrigation schedules',
        ['Root_depth_hypothesis_test.csv'],'原DI拟合良好并不能保证亏缺灌溉外推合理；2020年C1对2.3m根深假设非常敏感。',
        '缩短根深仅是单因素诊断，未重校准；不能选一个更悲观根深充当真实根深。')

    # D07: actual uptake is not the same as the net change in deep storage.
    fig,axs=plt.subplots(2,2,figsize=(10,6.3),layout='constrained')
    for col,y in enumerate(FOCUS):
        x=np.arange(2)
        for j,label in enumerate(['DI','C1']):
            q=up[(up.Year==y)&(up.Scenario==label)]
            for row,field in enumerate(['Transpiration_uptake_mm','Net_storage_change_mm']):
                axs[row,col].bar(x+(j-.5)*.33,q[field],width=.31,color=COL[label],label='Original DI' if label=='DI' else 'Original C1',zorder=3)
        for row in range(2):axs[row,col].set(xticks=x,xticklabels=['0–1 m','1–2.4 m']);clean(axs[row,col])
        axs[1,col].axhline(0,color='.4',lw=.8);panel(axs[0,col],str(y))
    axs[0,0].set_ylabel('Transpiration uptake (mm)');axs[1,0].set_ylabel('Net storage change (mm)');axs[0,0].legend(fontsize=8)
    save(fig,'D07_Depth_uptake_and_storage_change','Depth-resolved uptake and net soil-water storage change',
        ['Depth_uptake_and_net_storage.csv'],'2020年C1在1m以下取水152.8mm，但深层季净储水仍增加22.2mm；不能把深层取水量全部认定为开采初始水。',
        '逐层取水由原引擎蒸腾步骤前后含水差直接记录；未做雨水、灌水、初始水示踪。')

    # D08: diagnostic searches under explicit control and carryover conditions.
    fig,axs=plt.subplots(2,2,figsize=(10.5,6.9),layout='constrained')
    labels=['Original\nC1']+POL_LABEL;pc=['#C16B26','#729BA6','#338866','#775BA0']
    for col,y in enumerate(FOCUS):
        c=s0[(s0.Year==y)&(s0.Scenario=='C1')].iloc[0];b=s0[(s0.Year==y)&(s0.Scenario=='DI')].iloc[0]
        q=best[best.Year==y].set_index('Policy').loc[POL]
        values=np.r_[c.Irrigation_mm,q.Irrigation_mm.to_numpy()];stores=np.r_[c.Profile_final_mm,q.Profile_final_mm.to_numpy()]
        axs[0,col].bar(np.arange(4),values,color=pc,zorder=3)
        for k,val in enumerate(values):axs[0,col].text(k,val+9,f'{100*(1-val/b.Irrigation_mm):.1f}%',ha='center',fontsize=9)
        for k,p in enumerate(POL,1):
            a=seeds[(seeds.Year==y)&(seeds.Policy==p)]
            axs[0,col].scatter(np.full(len(a),k),a.Irrigation_mm,marker='_',s=100,color='black',zorder=5)
        axs[0,col].axhline(b.Irrigation_mm,color=COL['DI'],ls=':',lw=1)
        axs[0,col].set_ylim(0,760);panel(axs[0,col],str(y))
        axs[1,col].bar(np.arange(4),stores,color=pc,zorder=3)
        axs[1,col].axhline(b.Profile_initial_mm,color='#338866',ls='--',lw=1,label='Initial storage')
        axs[1,col].axhline(b.Profile_final_mm,color=COL['DI'],ls=':',lw=1,label='DI final storage')
        for row in range(2):axs[row,col].set(xticks=np.arange(4),xticklabels=labels);clean(axs[row,col])
    axs[0,0].set_ylabel('Irrigation (mm); label = reduction');axs[1,0].set_ylabel('Final profile storage (mm)');axs[1,1].legend(fontsize=8,loc='upper left')
    save(fig,'D08_Constrained_search_comparison','Diagnostic constrained searches and soil-water carryover',
        ['Constrained_best_found_candidates.csv','Constrained_seed_candidates.csv'],'控制原单次灌水设置后，若不允许消耗初始储水，2020/2021年最少灌水候选的降幅收敛至12.4%/27.4%。',
        '每年每策略两种子×64个体×50代；黑短线表示种子候选，不是置信区间。仍采用95%观测产量门槛，实际ET可响应变化。')

    # D09: exact seasonal ET diagnostic, same management settings.
    fig,axs=plt.subplots(1,2,figsize=(10.3,4.2),layout='constrained',sharey=True)
    for ax,y in zip(axs,FOCUS):
        b=s0[(s0.Year==y)&(s0.Scenario=='DI')].iloc[0];q=eq[eq.Year==y].set_index('Policy').loc[POL]
        vals=q.Irrigation_mm.to_numpy();ax.bar(np.arange(3),vals,color=['#729BA6','#338866','#775BA0'],zorder=3)
        for i,r in enumerate(q.itertuples()):ax.text(i,r.Irrigation_mm+9,f'{r.Irrigation_reduction_pct:.1f}%',ha='center')
        ax.axhline(b.Irrigation_mm,color=COL['DI'],ls=':',lw=1,label='DI irrigation')
        ax.set(xticks=np.arange(3),xticklabels=POL_LABEL,ylim=(0,730));panel(ax,f'{y} | ET = {b.ET_mm:.2f} mm');clean(ax)
    axs[0].set_ylabel('Irrigation at unchanged seasonal actual ET (mm)');axs[0].legend(loc='upper left',fontsize=8)
    save(fig,'D09_Equal_ET_diagnostics','Equal actual-ET comparisons with fixed per-event settings',
        ['Equal_ET_fixed_management_diagnostics.csv'],'将季节实际ET精确匹配原DI后，兼顾季末不低于初始储水的诊断点降幅为11.1%/26.8%；保持原DI季末储水时回到原DI。',
        '这些是经模型求根得到的可行对照点，不是新的最小灌水全局最优；只匹配季总ET，不强制每日ET轨迹相同。')
    (ROOT/'FIGURE_INTERPRETATIONS.json').write_text(json.dumps(REG,ensure_ascii=False,indent=2))
    print('Created',len(REG),'figure groups and 9 mechanism tables')

if __name__=='__main__':main()
