"""Collect completed searches without rerunning them, then independently replay winners."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from audit_engine import ROOT,AuditEngine,write
from constrained_demonstration import OUT,POP,GEN,SEEDS,POLICIES
from run_mechanism_traces import periods

def main():
    results=[];checks=[]
    for year in [2020,2021]:
        for policy in POLICIES:
            for seed in SEEDS:
                folder=OUT/str(year)/policy/f'seed{seed}'
                r=json.loads((folder/'run.json').read_text());a=pd.read_csv(folder/'evaluations.csv.gz')
                assert r['status']=='COMPLETE' and len(a)==POP*GEN
                assert len(list(folder.glob('generation_*.npz')))==GEN
                assert a.Max_single_event_mm.max()<=r['Original_single_event_setting_mm']+1e-8
                assert a.Water_balance_residual_mm.abs().max()<1e-7
                for generation in range(1,GEN+1):
                    p=np.load(folder/f'generation_{generation:04d}.npz')
                    assert p['X'].shape==(POP,4) and p['F'].shape==(POP,2)
                    assert np.isfinite(p['X']).all() and np.isfinite(p['F']).all()
                    feasible=p['CV'][:,0]<=0
                    assert np.array_equal(feasible,np.maximum(p['G'],0).sum(axis=1)<=0)
                results.append(r);checks.append(dict(Year=year,Policy=policy,Seed=seed,Evaluations=len(a),Generation_files=GEN,Status='PASS'))
    write(ROOT/'verification/Constrained_search_jobs.json',results)
    pd.DataFrame(checks).to_csv(ROOT/'verification/Constrained_record_checks.csv',index=False)
    points=pd.DataFrame([r['Candidate'] for r in results if r['Candidate'] is not None])
    points.to_csv(ROOT/'tables/Constrained_seed_candidates.csv',index=False)
    rows=[]
    for (year,policy),a in points.groupby(['Year','Policy']):
        s=a.sort_values('Irrigation_mm').iloc[0].to_dict()
        s['Irrigation_reduction_pct']=100*(1-s['Irrigation_mm']/{2020:559.76,2021:633.47}[year])
        s['Interpretation']='best found from two diagnostic seeds; not proven global optimum'
        rows.append(s)
    best=pd.DataFrame(rows);best.to_csv(ROOT/'tables/Constrained_best_found_candidates.csv',index=False)
    engine=AuditEngine();replays=[];daily_all=[];layer_all=[];period_all=[]
    for _,row in best.iterrows():
        year=int(row.Year);label='New_'+row.Policy
        x=row[engine.specs[year]['names']].to_numpy(float)
        result,daily,layers,stress=engine.trace(year,label,x)
        for field in ['Irrigation_mm','Y_13pct','ET_mm','Profile_final_mm']:
            np.testing.assert_allclose(result[field],row[field],atol=1e-7,rtol=0)
        assert result['Maximum_single_actual_irrigation_mm']<=row.Event_cap_mm+1e-8
        if pd.notna(row.Storage_floor_mm):assert result['Profile_final_mm']>=row.Storage_floor_mm-1e-8
        replays.append(result);daily_all.append(daily);layer_all.append(layers)
        meta,_=engine.configuration(year);meta['First_irrigation_date']=engine.specs[year]['event_dates'][0]
        period_all.append(periods(daily,meta))
        daily.to_csv(ROOT/'tables'/f'daily_{year}_{label}.csv',index=False)
        stress.to_csv(ROOT/'tables'/f'stress_{year}_{label}.csv.gz',index=False,compression='gzip')
    pd.DataFrame(replays).to_csv(ROOT/'tables/Constrained_replay_summary.csv',index=False)
    pd.concat(daily_all).to_csv(ROOT/'tables/Constrained_daily_traces.csv.gz',index=False,compression='gzip')
    pd.concat(layer_all).to_csv(ROOT/'tables/Constrained_layer_traces.csv.gz',index=False,compression='gzip')
    pd.concat(period_all).to_csv(ROOT/'tables/Constrained_period_budgets.csv',index=False)
    write(ROOT/'verification/CONSTRAINED_RUN_STATUS.json',dict(status='COMPLETE',jobs=len(results),evaluations=sum(r['Evaluations'] for r in results),
        population=POP,generations=GEN,seeds=SEEDS,policies=POLICIES,cap_is_original_model_setting_not_measured_hardware=True,
        selected_candidate_independent_replays=len(replays),original_formal_experiment_unchanged=True,MCMC_runs=0,
        initialization_retry='One initialization audit-log temporary-file race was retried once in isolation before any evaluations; loader now serialized. All 12 complete run records verified.',
        frozen_input_check=engine.verify_frozen()))
    print(best[['Year','Policy','Irrigation_mm','Y_13pct','ET_mm','Profile_final_mm','Irrigation_reduction_pct']].to_string(index=False))

if __name__=='__main__':main()
