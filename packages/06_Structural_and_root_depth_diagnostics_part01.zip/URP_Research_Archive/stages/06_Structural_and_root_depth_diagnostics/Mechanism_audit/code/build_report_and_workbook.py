"""Editable Chinese mechanism report with English figures and source-linked tables."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl.styles import Font,PatternFill,Alignment
from audit_engine import ROOT,PROJECT,AuditEngine,write

T=ROOT/'tables';REG=json.loads((ROOT/'FIGURE_INTERPRETATIONS.json').read_text())
def read(name):return pd.read_csv(T/(name+'.csv'),float_precision='round_trip')
def rows(df,year):return df[df.Year==year]
def case(s,year,label):return s[(s.Year==year)&(s.Scenario==label)].iloc[0]

DICTIONARY=[
('Y_13pct / Y13_t_ha','13%含水率籽粒产量','t/ha','模型量；Observed_Y13才是文献观测产量。'),
('Irrigation_mm / IrrDay','实际进入模拟的灌水量','mm','IrrDay为日量；计划灌水与实际施灌分列，不能只用决策量求和。'),
('ETo_mm','参考作物蒸散输入','mm/d','固定天气输入及原ETo订正；不是实际ET。'),
('ET_mm','实际蒸散：Tr + Es','mm','模型输出；严格等ET对照单独求根，不回写ET。'),
('Tr / Tr_mm','植物蒸腾','mm','由根系逐层提取及可能的地表水提取组成。'),
('Es / Es_mm','土壤蒸发','mm','保留原覆膜与实际冠层蒸发结构。'),
('Profile_initial_mm / Profile_final_mm','0–2.4m土壤总储水','mm','不是全部可利用水；对比采用相同剖面和起止日。'),
('Storage_change_mm','期末减期初的储水变化','mm','日预算另含地表水变化；本次地表期初、期末均为0。'),
('Root_depth_m','模型有效根深','m','默认最大2.3m；缩根对照独立标为假设检验。'),
('CC','模型冠层覆盖度','0–1','表征冠层投影覆盖，不等于LAI。'),
('Tr_Ks_sto_lin','蒸腾模块调用的线性气孔胁迫系数','0–1','本模型实际用于限制潜在蒸腾；1代表该项无水分胁迫。'),
('CC_Ks_exp / HI_Ks_pol','冠层扩展 / 授粉水分胁迫系数','0–1','由原模型函数直接记录；不冒充实测生理指标。'),
('Relative_available_end','(θ−WP)/(FC−WP)','无量纲','不是饱和度；可能大于1；图色标截在0与1.2。'),
('Transpiration_uptake_mm','原蒸腾步骤从该层提取的水','mm','是通量，不能当成该层净储水减少，更不能当成初始水来源示踪。'),
('Infiltration_storage_increment_mm','入渗步骤该层净储水增量','mm','不是层界面总穿透通量；层间上下流不可由该列直接恢复。'),
('Original_event_setting_mm / Event_cap_mm','原日程执行单次上限','mm/次','用户确认是原最大实测量+0.10；不代表设备能力，也不是MCMC校准参数。'),
('MulchPct / fMulch','覆膜覆盖率 / 原蒸发抑制系数','% / 无量纲','原设置75% / 0；本轮不改膜面积和效力参数。'),
('Window1_mm…Window4_mm','四个灌水决策窗口总量','mm','原灌水日期和窗口内分配权重固定；不是四个生育阶段的田间实测量。'),
('Period','五个模型日历诊断时期','文本','与四个决策窗口不同；详见Period_definitions.csv。'),
('Feasible / Maximum_scaled_violation','约束可行性 / 最大归一化违约','布尔 / 无量纲','G≤0且实际单次量与季总量核对通过才算可行。'),
('Seed','诊断搜索随机种子','整数','31、73两重复的范围不是置信区间。'),
('Initial_theta / Initial_theta_m3m3','播种日体积含水率','m³/m³','0–1m由原论文图近似读取，深层ERA5-Land；不等于原始实测表。'),
]

def workbook():
    pd.DataFrame(DICTIONARY,columns=['Field','Meaning_CN','Unit','Interpretation_boundary']).to_csv(T/'Data_dictionary.csv',index=False)
    p=read('Period_water_canopy_stress')[['Year','Period','Start_date','End_date','Days']].drop_duplicates().sort_values(['Year','Period'])
    p.to_csv(T/'Period_definitions.csv',index=False)
    selected=[('Overview','Four_year_DI_C1_comparison'),('Water_account','Water_reduction_accounting'),
        ('Focus_cases','Focus_case_comparison'),('Constrained_best','Constrained_best_found_candidates'),
        ('Two_seed_results','Constrained_seed_candidates'),('Equal_ET','Equal_ET_fixed_management_diagnostics'),
        ('ET_lower_bounds','Fixed_ET_water_balance_necessary_bounds'),('Five_periods','Period_water_canopy_stress'),
        ('New_policy_periods','Constrained_period_budgets'),('Period_x_layer_water','Period_soil_water_by_layer'),('Canopy_stress','Canopy_stress_diagnostics'),
        ('Depth_uptake_storage','Depth_uptake_and_net_storage'),('Event_schedules','Actual_event_schedules_DI_C1'),
        ('Root_depth_test','Root_depth_hypothesis_test'),('Original_settings','Original_configuration'),
        ('24_soil_cells','Soil_layers_and_initial_water'),('Initial_water_provenance','Source_initial_water_with_provenance_notes'),
        ('User_confirmed_settings','User_confirmed_common_settings'),('Period_definitions','Period_definitions'),('Data_dictionary','Data_dictionary')]
    with pd.ExcelWriter(ROOT/'URP_Optimization_Mechanism_Data.xlsx',engine='openpyxl') as writer:
        pd.DataFrame([dict(Sheet=k,Source_CSV='tables/'+v+'.csv',Rows=len(read(v))) for k,v in selected]).to_excel(writer,sheet_name='INDEX',index=False)
        for sheet,name in selected:
            a=read(name)
            for col in a.columns:
                if a[col].dtype==object:a[col]=a[col].map(lambda x:str(x)[:1000] if pd.notna(x) else x)
            a.to_excel(writer,sheet_name=sheet,index=False)
        pd.DataFrame(REG).assign(Source_tables=lambda a:a.Source_tables.map('; '.join)).to_excel(writer,sheet_name='Figure_interpretations',index=False)
        for ws in writer.book.worksheets:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.showGridLines=False;ws.row_dimensions[1].height=38
            for cell in ws[1]:
                cell.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='275767')
                cell.alignment=Alignment(wrap_text=True,vertical='center')
            for col in ws.columns:
                width=min(46,max(12,max(len(str(c.value or '')) for c in list(col)[:40])+2))
                ws.column_dimensions[col[0].column_letter].width=width
                for c in list(col)[1:]:
                    c.font=Font(name='Calibri',size=10)
                    if isinstance(c.value,float):c.number_format='0.0000'
                    if c.row%2==0:c.fill=PatternFill('solid',fgColor='F1F5F6')
                    if ws.title in ['Data_dictionary','Figure_interpretations']:c.alignment=Alignment(wrap_text=True,vertical='top')
            if ws.title=='Data_dictionary':
                for i in range(2,ws.max_row+1):ws.row_dimensions[i].height=46
    return selected

def document():
    s=read('Scenario_summary');ov=read('Four_year_DI_C1_comparison');bal=read('Water_reduction_accounting')
    best=read('Constrained_best_found_candidates');eq=read('Equal_ET_fixed_management_diagnostics');per=read('Period_water_canopy_stress')
    doc=Document();sec=doc.sections[0];sec.left_margin=sec.right_margin=Cm(1.7);sec.top_margin=sec.bottom_margin=Cm(1.6)
    sec.page_width=Cm(21);sec.page_height=Cm(29.7)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
        st=doc.styles[name];st.font.name='DejaVu Sans';st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    normal=doc.styles['Normal'];normal.font.size=Pt(10.5);normal.paragraph_format.line_spacing=1.14;normal.paragraph_format.space_after=Pt(6)
    doc.styles['Title'].font.size=Pt(23);doc.styles['Heading 1'].font.size=Pt(15);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('275767')
    doc.styles['Heading 2'].font.size=Pt(11.5);doc.styles['Caption'].font.size=Pt(9);doc.styles['Caption'].font.italic=False
    doc.styles['Caption'].paragraph_format.line_spacing=1.05
    footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER;footer.add_run('URP · 灌溉优化机制审计 · ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    md=[]
    def para(text,style=None):doc.add_paragraph(text,style);md.append(text+'\n')
    def heading(text,new=True):
        p=doc.add_heading(text,1);p.paragraph_format.page_break_before=new;md.append('\n## '+text+'\n')
    def sub(text):doc.add_heading(text,2);md.append('\n### '+text+'\n')
    def table(title,frame,cols):
        sub(title);a=doc.add_table(rows=1,cols=len(cols));a.style='Light Shading Accent 1'
        h=OxmlElement('w:tblHeader');a.rows[0]._tr.get_or_add_trPr().append(h)
        for c,(_,label,_) in zip(a.rows[0].cells,cols):c.text=label
        body=[]
        for _,row in frame.iterrows():
            vals=[]
            for key,_,digits in cols:
                v=row[key];vals.append('—' if pd.isna(v) else str(v) if digits is None else f'{v:.{digits}f}')
            for c,v in zip(a.add_row().cells,vals):c.text=v
            body.append(vals)
        for row in a.rows:
            no=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(no)
            for c in row.cells:
                for p in c.paragraphs:
                    p.paragraph_format.space_after=Pt(3)
                    for r in p.runs:r.font.size=Pt(8.5)
        md.append('| '+' | '.join(label for _,label,_ in cols)+' |\n| '+' | '.join('---' for _ in cols)+' |')
        md.extend('| '+' | '.join(vals)+' |' for vals in body);md.append('')
    def figure(i,height=12.5):
        reg=REG[i-1];path=ROOT/'figures'/(reg['ID']+'.png');im=Image.open(path);w,h=im.size
        width=min(17.5,height*w/h)
        p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run().add_picture(str(path),width=Cm(width))
        para(f"图D{i:02d} · {reg['Title']}",'Caption')
        para('图解：'+reg['Interpretation'])
        para('解释边界：'+reg['Boundary'],'Caption')
        para('数据：'+', '.join(reg['Source_tables']),'Caption')
        md.append(f"![{reg['Title']}](figures/{reg['ID']}.png)\n")

    doc.add_heading('为什么少灌一半水\n仍能得到接近原方案的产量？',0)
    para('URP 2019—2022年DI玉米 · NSGA-III优化机制追溯与约束修正',style='Subtitle')
    para('重点：2020、2021年；四年原方案均回放。版本：2026-10-20。')
    para('核心判断：原结果在当前模型内可以复现，但不能据此认定田间可以稳定节水44%—58%。主要原因是优化只约束当季产量与灌水量，没有为季末土壤储水定价或设限，叠加根域与初始土壤水证据不足。原优化允许部分单次灌水高于原日程数值上限，这是控制范围差异，不据此单独认定程序错误。')
    para('本轮保留原覆膜面积、蒸发参数、天气/ETo、初始含水和年别校准参数，记录逐日冠层及胁迫、24层土壤含水和取水，完成38,400次带约束的实际模型评价。没有为了让曲线“可信”而压低产量，也没有重跑或替换MCMC。')
    table('先看关键对照',pd.DataFrame([
        {'Year':2020,'Old':44.1864,'Cap':42.8846,'NoLoss':12.3763,'EqualET':11.0615},
        {'Year':2021,'Old':57.8046,'Cap':57.7547,'NoLoss':27.3769,'EqualET':26.8210}]),
        [('Year','年份',0),('Old','原C1减灌%',1),('Cap','原单次设置%',1),('NoLoss','再加不耗初始储水%',1),('EqualET','再匹配原季节ET%',1)])
    para('后三列依次为不同诊断条件，不能写成已完成的田间节水试验。前两组新搜索保留95%观测产量门槛；最后一列为求根获得的等ET可行点，并未证明最少灌水。季末不耗初始储水也不是已确立的最优农艺阈值。')
    para('交付内容：9组英文图（600 dpi PNG、PDF、SVG）、中文逐图解释、原精度CSV/逐日逐层记录、Excel数据册、12组搜索的逐次评价和逐代种群、可复核代码与本报告。')

    heading('1 先锁定不变条件与比较对象')
    para('人工条件不变：mulch_pct=75%、mulches=True、f_mulch=0，WetSurf=100%、AppEff=100%；原灌水日期及四个窗口内的事件权重不变。f_mulch=0是原Modified_DI_Model明确记录的结构设置，本轮原样保留；该设置下覆膜显式蒸发乘子为1，不能将75%覆膜直接解释为75%的蒸发削减。')
    para('用户补充确认：fMulch=0表示关闭代码中额外的地膜蒸发抑制，绝不等于田间地膜完好率为0%。Zmin=0.30m、Zmax=2.30m是四年共同沿用的AquaCrop默认动态根深设置。原单次/季节上限分别按当年最大单次实测灌水量+0.10mm、季节实测总量+0.10mm设定，只保证原日程完整执行，不是MCMC参与校准的参数，更不是设备能力的实测结论。')
    table('四年共同设置与原日程执行上限',read('User_confirmed_common_settings'),[('Year','年份',0),('MulchPct','覆膜率%',0),('fMulch','fMulch',1),('Zmax_m','Zmax m',2),('MaxIrr_mm','单次上限mm',2),('MaxIrrSeason_mm','季节上限mm',2)])
    para('自然边界不变：使用原年别天气与原ETo订正，土壤24×0.1m、初始含水、原中央参数及原作物模型不变。年内各方案天气和初始土壤水完全相同。ETo是输入，实际ET是冠层和土壤含水共同决定的输出。报告另设置“季节实际ET等于原DI”的严格对照，不把ET当成可直接改写的常数。')
    para('比较对象：DI表示原实际灌水制度在模型中的回放；C1表示原95%观测产量门槛下的NSGA-III主候选。DI模型产量与文献实测产量不同。图中的星号是模型基线，不是实测值；“达到实际情况产量”必须按这一区别改写。')
    table('四年原DI与C1（产量单位t/ha；灌水单位mm）',ov,[('Year','年份',0),('Observed_Y13','观测产量',2),('DI_Y13','DI模型产量',2),('C1_Y13','C1产量',2),('DI_Irrigation_mm','DI灌水',1),('C1_Irrigation_mm','C1灌水',1)])
    para('2020/2021年的观测产量为17.29/15.86，模型DI为16.804/15.197，C1为16.426/15.067。C1接近95%观测门槛，分别比模型DI低2.25%/0.86%；它们并没有达到观测产量。补充全范围搜索找到的最高产量约16.938/15.250，仍低于观测。')
    para('即便要求匹配模型DI产量，既有全范围前沿也找到2020年337.31mm、2021年278.34mm的候选。故过度乐观现象不只是95%门槛带来的表述问题，必须进一步检查水量与根区过程。')

    heading('2 水量闭合：减下来的水主要去了哪里？')
    para('逐日按 P + I + CR + GW = Tr + Es + Runoff + DeepPerc + TileDrain + ΔS 核对。每年原DI和C1的降水、初始水、地下水条件相同；两者相减得到：减灌量 = ET减少量 + 季末储水差 + 径流/排水减少量。日残差约10⁻¹³mm，表明数值账目闭合；这不是模型结构正确性的证明。')
    figure(1,height=10)
    table('2020/2021年减灌量分解（mm）',rows(bal,2020)._append(rows(bal,2021),ignore_index=True),
        [('Year','年份',0),('Irrigation_reduction_mm','减灌量',2),('ET_reduction_mm','ET减少',2),('Final_storage_difference_mm','季末储水差',2),('Loss_reduction_mm','径流排水差',2),('Storage_difference_share_pct','储水占比%',1)])
    para('2020年原DI季内增储61.92mm，C1耗储168.83mm，合成230.75mm季末差；2021年则是原DI增储169.97mm、C1耗储186.74mm，合成356.71mm差。它既包含“少向土壤补蓄”，也包含“额外动用已有储水”，不能全部称为开采初始深层水。')
    para('剔除季末储水差后，减灌账中剩余仅16.59/9.46mm，约为原灌水量的2.96%/1.49%。这只是水量账差额，不能直接当作真实可持续节水率：径流、回归水和季后补蓄尚未做完整水文周期核算。')

    heading('3 冠层与胁迫：产量为什么没有随灌水减半？')
    figure(2,height=15)
    para('2020年原DI/C1冠层峰值为0.925/0.937，C1因前期集中供水甚至略高；2021年两者均为0.953。冠层没有显著损失，开花模型窗口的授粉水分胁迫系数均为1。原DI在冠层>0.1期间没有气孔水分胁迫；C1只有后期部分日子触发，平均线性气孔胁迫系数仍为0.973/0.992。')
    para('因而模型仍能维持大部分蒸腾，生物量略减，产量变化很小。本轮没有发现可用来解释原DI低产的缺氧胁迫；两年相应系数均未触发。不能在论文中把“优化避免了水涝”写成已证实原因。')
    para('尤其2021年，把每次原灌水直接减半、不运行遗传算法，灌水316.74mm时模型产量仍有15.134t/ha，仅比原DI低0.42%。这说明2021年的高节水潜力首先来自模型的供水—胁迫响应及原制度补蓄，而不只是NSGA-III找到了巧妙时机。2020年同样减半则降产11.73%，对灌水分配更敏感。')

    heading('4 湿度分配：24个土层的水怎样被利用？')
    figure(3,height=12.2)
    para('模型默认最大根深2.3m，2020/2021年分别于5月22日、5月29日即超过1m，首次灌水前已有约1.32/1.28m根深。深根域参与储水可用性与水分胁迫判断，使减少后期灌水仍可能维持冠层与蒸腾。这里描述的是模型根深，不是已被田间根系采样证实的根深。')
    para('证据弱点在于：土壤水力性质原资料仅支持到1m，1–2.4m沿用末层性质；播种日0–1m初始含水是论文图的近似读取，深层来自ERA5-Land。文件中的LOCKED/FIELD命名表示复现冻结，不等于这些含水已经由原始实测表验证。')
    para('若真实滴灌湿润体积、根系分布或限制层不同，模型用整个等效剖面的水支撑冠层，就会高估亏缺灌溉外推能力。AppEff=100%、WetSurf=100%也是原输入约定，不能在没有水表和湿润体调查的情况下当成真实田间效率与滴灌湿润范围。')

    heading('5 逐时期水量：两年的机制不同')
    figure(4,height=12.6)
    para('2020：C1在首次灌水至模型收获指数起始前投入311.85mm，已占全年312.42mm的99.8%；开花窗口仅0.55mm，后续产量形成期约0.02mm。对应开花窗口和后续产量形成期的储水分别减少62.68、176.36mm。它实际上先把水集中存进剖面，再靠根域储水维持生殖期。')
    para('2021：开花窗口原DI灌水76.60mm，C1为0；后续产量形成期原DI灌水292.28mm，C1仅87.57mm，而该期原DI储水增加149.38mm、C1减少49.51mm。两者该期蒸腾仍为209.60/205.52mm，模型因此允许大幅削减灌水而几乎不减产。')
    para('这里按五个固定模型日历时期对账，不是重定义灌水决策变量。时期从首次灌水、原HI起始、原开花时长与原HIend确定；并非新获得的田间物候记录。完整起止日期与雨、灌、Tr、Es、径流、深渗、ΔS见Excel的Five_periods与Period_definitions页；Period_x_layer_water页另有四年DI/C1每时期×24层的期初、期末、平均含水和取水，共960条记录。')

    heading('6 单次施灌设置：区分日程数值上限与田间能力')
    figure(5,height=12)
    para('原four_year_adapter.py第149行把MaxIrr设成候选最大单次灌水加0.1mm，也把季总数值上限随候选调整。2020年C1的最大单次179.89mm因此可以执行，而原DI上限为84.88mm。用户已经确认，这些上限用于保证给定日程完整执行，不是已知现场能力约束；若优化允许改变事件量，随新日程调整执行上限本身不能据此判定为错误。')
    para('本轮额外固定原上限，作为“保持原执行设置”的受控敏感性诊断。实现上同时约束候选事件量并核对实际施灌，避免靠模型内部截断、却仍拿计划量作横轴。若研究目的要求现实可实施性，最终应使用由流量、时长、面积及土壤入渗能力证实的上限，不能直接把原实测最大量当成真实设备极限。')
    para('固定这组原数值上限后，2020/2021年的诊断减灌比例仍为42.9%/57.8%，储水边界仍是主导因素。2020年180mm集中早灌是否可实施，当前只能标为待核实；只裁掉原候选的大事件而不重新优化，也不能代表有约束条件下的最优结果。')

    heading('7 根深诊断：原方案拟合不能验证减灌外推')
    figure(6,height=9.6)
    para('独立把Zmax设为0.6、1.0、1.5m，与原2.3m比较，其他参数和灌水制度不动。这只是假设敏感性检验，未重校准，也未据此认定真实根深。')
    para('2020年Zmax=1m时，原DI仍能得到16.43t/ha，但同一个C1只剩8.38t/ha；原2.3m时两者为16.80/16.43。2021年1m时原DI为14.96，C1为12.57；2.3m时为15.20/15.07。原DI条件下产量拟合尚可，不能排除根域假设对亏缺灌溉外推造成很大偏差。')
    para('可辨识性也有缺口：原八个MCMC参数为CCx、CGC_CD、CDC_CD、SenescenceCD、Kcb、WP_early、WP_late、HI0，不包括根深、根系分布和主要水分胁迫阈值/形状。原DI生长活跃期的气孔胁迫系数均为1，现有充分供水数据不能独立验证亏缺灌溉时这些默认响应是否正确。拟合冠层、生物量和产量通过，并不意味着减灌外推也通过。')
    para('因此应优先补有效根深、深层土壤性质、田间含水时序与含水下限证据。没有这些数据时，可以把多个有农艺依据的根域情景作为结构不确定性报告；不能为了得到较小的节水率，直接把根深改成1m并沿用原校准参数做最终结论。')

    heading('8 取水通量与净储水：避免新的误判')
    figure(7,height=11.4)
    para('逐层取水直接记录于原蒸腾函数前后：2020年C1在1m以下累计取水152.82mm，但该深度带季内净储水仍增加22.20mm，说明前期水分向下补给与后期深层取水同时存在。不能把152.82mm全部认定为对初始深层水的开采。')
    para('2021年C1的1m以下累计取水只有15.36mm，其0–1m净耗储达228.65mm。原DI的深层净增储则达216.33mm；2021年的核心更接近“避免深层补蓄，同时使用上层已有水”，不能简单复制2020年的深层取水解释。')
    para('本次追踪能区分层位、通量、时序与净变化，未做灌水/雨水/初始水分子来源示踪。深根也会改变根区总体Dr/TAW和胁迫判断，所以少量直接深层取水不代表根深假设对2021年无影响。')

    heading('9 已完成的约束优化：结果如何收敛？')
    figure(8,height=10.8)
    para('新诊断保持两目标：最大化模型产量、最小化实际灌水；仍以Y≥0.95×文献观测产量及季总灌水≤原DI为共同约束。增加原单次灌水设置后，分别比较无季末储水底线、季末不低于初始储水、季末不低于原DI储水三种条件。')
    heading('9.1 诊断搜索设置与完整候选表')
    para('2020/2021×3种条件×2个种子，共12组实际NSGA-III搜索，每组64个体×50代=3,200次，总计38,400次。每次评价、每代种群X/F/G/CV均保存；六个最少灌水候选另逐日独立回放。它们是有限预算下找到的可行解，不是全局最优证明，也不是原正式100×100×5实验的替代品。')
    labels={'fixed_event_setting_only':'原事件上限','fixed_event_no_net_depletion':'不耗初始水','fixed_event_same_DI_final_storage':'同DI期末水'}
    display=best.copy();display['Policy_order']=display.Policy.map({p:i for i,p in enumerate(labels)})
    display=display.sort_values(['Year','Policy_order']);display['Policy_CN']=display.Policy.map(labels)
    table('六组最佳已找到候选',display,[('Year','年',0),('Policy_CN','条件',None),('Irrigation_mm','灌水mm',2),('Y_13pct','产量t/ha',3),('ET_mm','ET mm',2),('Profile_final_mm','季末储水mm',2),('Irrigation_reduction_pct','减灌%',2)])
    para('原DI季末储水底线把减灌比例压到0.39%/0.01%，这是有意设置的同储水诊断，不表示真实田间没有节水空间。原DI可能在季末留了过多水，部分水也可能在本模拟日历之后排走；应该按后茬、冬季补蓄和全年水量确定合理储水目标，而不是机械照搬原DI的高储水。')
    para('两个种子的最少灌水候选范围也需保留：2020年仅固定事件设置为319.71—320.09mm、不耗初始储水为490.48—496.44mm、同原DI期末储水为557.60—559.51mm；2021年对应267.61—268.79、460.05—461.87、633.395—633.399mm。它们描述本预算下的种子差异，不能当作置信区间或收敛误差上界。')
    para('选择标准是先满足共同产量门槛和所列储水条件，再从所有已评价可行点中取实际灌水最少者。因此不同策略的产量与ET不必完全相等；需要排除ET响应差异时，应改看下一节的等ET对照，而不是直接把本表各减灌比例理解为同耗水、同产量下的效率改善。')

    heading('10 按要求保持实际蒸散量相同')
    figure(9,height=10)
    para('从新搜索的可行控制量中选锚点，用实际模型求根，令季节ET等于原DI：2020为609.96193mm、2021为605.14336mm。地膜、天气、初始含水、原单次设置不变，另核对产量门槛与储水底线；ET误差小于10⁻⁵mm。这里只匹配季总ET，不宣称每日ET相同。')
    e=eq.copy();e['Policy_CN']=e.Policy.map(labels)
    table('相同实际ET下的诊断点',e,[('Year','年',0),('Policy_CN','储水条件',None),('Irrigation_mm','灌水mm',2),('Y_13pct','产量t/ha',3),('Profile_final_mm','季末储水mm',2),('Irrigation_reduction_pct','减灌%',2)])
    para('等ET本身仍不能消除储水贡献：只有原单次设置时，两年仍能找到减少22.7%/36.5%灌水的等ET点，但季末储水低于原DI。加上不耗初始储水后，得到497.84/463.57mm、减灌11.06%/26.82%的点；若保留原DI季末储水，本次对照回到原DI点。')
    para('水量必要下界I≥ET−P为496.50/461.82mm（固定ET、不耗初始储水、忽略排水径流），也支持约11%/27%的数量级，但它不是可行最优解。')

    heading('11 原因排序与可执行的解决方案')
    sub('第一优先：修正优化目标与水量记账')
    para('把旧C1重新定位为“允许动用土壤储水的单季模型候选”，暂停用其44%—58%减灌比例作已验证田间节水结论。所有候选同时报告I、Tr、Es、ΔS、径流和深渗。将产量比较基准明确写为观测门槛或模型DI，不再混用。')
    para('先声明优化允许的管理范围：保持原日程执行上限只是一种受控比较；若允许改变灌水量和时长，按核实的流量、面积、入渗和管理能力设事件限制，并使模拟器执行设置与该限制一致。保留实际施灌与计划量双向核对。新增季末储水或全水文年水量约束，目标由田间起止含水、后茬需求和冬季有效降水决定。原DI期末储水可作为严格对照，不应自动成为唯一推荐底线。')
    sub('第二优先：验证根域、湿润体和初始水，而非调漂亮曲线')
    para('核实有效根深、限制层、0–1m及更深层土壤水力性质；收集各灌水周期前后至少0–20、20–40、40–60、60–100cm以及实际根域内深层含水。核实水表流量×时长/面积与灌水记录，确认净灌水或毛灌水口径。测定滴灌湿润比例、膜完整率及覆盖率；保留地膜面积约束。')
    para('若实证要求改变根深、深层土壤、湿润比例、膜效力或灌溉效率，先更新所有方案共同使用的物理模型，再一致地重校准MCMC阶段1和阶段2，并重做Sobol与优化。不能只在优化阶段改参数，也不能凭直觉把f_mulch、ET或WP改成能得到目标节水率的数值。')
    sub('第三优先：检验亏缺灌溉外推与风险')
    para('用独立亏缺灌溉处理验证冠层、分层含水、ET和产量；原DI拟合只能说明原供水条件下的拟合。若有独立ET观测，以误差范围设ET一致性约束；若仅有ETo，则保持ETo固定并报告ET响应。需要跨季可持续结论时，扩展至冬季/下一播种日，再检验储水回补是否抵消当季减灌。')
    para('储水阈值与现场限制明确后，再按原正式预算100个体×100代×5种子、四年运行；参数不确定性与根域结构情景分开评估，可用Pr(Y≥目标)及Pr(S_end≥阈值)表达风险。此处是下一步方案，不冒充本次已完成的稳健优化。')
    sub('现在可以支持的结论')
    para('已有证据足以判定原减灌比例含有显著储水边界收益；2020年的集中施灌还需要现实可执行性验证。原日程数值上限不是硬件极限，其随新日程变化不能单独定性为程序错误。证据尚不足以判定真实田间最终节水率。11%/27%等新数值是固定模型、特定储水/ET条件下的诊断结果，不是通过调低曲线获得的“修正实测”。')

    heading('12 论文中怎样改写这一部分')
    para('建议把本节题目改为“灌溉优化的水量分配机制与边界敏感性”，按“产量—灌水前沿 → 水量账分解 → 冠层与分层水分机制 → 约束诊断 → 适用范围”组织。旧R03/N01保留为原条件搜索结果，图注补足允许土壤耗储及单次设置说明；D01、D02、D03、D08是主文优先，D04—D07和D09作为机制补充或附录。')
    sub('可扩写的结果段落')
    para('“在原单季目标下，2020和2021年主候选的季节灌水量分别减少247.34和366.17mm，而实际蒸散仅减少15.25和8.63mm。两方案相同初始和外部水量条件下，季末土壤储水差分别占减灌量的93.3%和97.4%。因此，原始减灌比例主要反映了土壤水分跨期分配差异，而不能直接等同为耗水减少。逐日回放显示，候选冠层峰值与原制度接近、模型开花窗口未触发授粉水分胁迫，解释了产量对减灌的弱响应。”')
    para('“保持原单次灌水设置并增加季末储水不低于初始值的约束后，有限预算的NSGA-III诊断搜索分别得到12.4%和27.4%的最少灌水候选；进一步匹配原制度季节实际ET后，可行对照点的减灌比例为11.1%和26.8%。这些结果展示了节水评估对储水边界的敏感性，仍需独立根域与亏缺灌溉试验验证，不能视为田间推荐的已验证节水幅度。”')
    sub('必须避免的推断')
    para('不写“同产量节水一半已获证明”；不把星号叫实测；不把深层取水通量都叫初始水开采；不把根深假设试验叫重新校准；不把同储水诊断的近零收益当作真实无节水空间；不将原固定膜效力假设写成优化时改变了地膜。')

    heading('附录：可复核记录与复现范围')
    para('原始逐日/逐层观测器只复制模型状态并返回原函数结果，原作物方程不变。8组原DI/C1用未加速引擎复核，全部逐日一致，标量最大差1.14×10⁻¹³；四年原C1的日水量与生长序列与既有正式输出一致。加速或新增记录器不是乐观响应的来源。')
    para('保留原冻结中央参数、后验样本和four_year_adapter.py的SHA256：验证文件Frozen_inputs_after_replay.json、ACCELERATION_AND_OBSERVER_CHECK.json、CONSTRAINED_RUN_STATUS.json、Equal_ET_checks.json可查看。原正式结果、MCMC文件和主分支均未覆盖。本轮MCMC重新运行次数为0。')
    para('ROOT/code含观测器、28组原条件场景及16组根深对照、12组实际搜索、独立回放、等ET求根、图表和本报告生成代码。constrained_runs保存38,400条评价记录、600个逐代种群文件及日志。新约束最小点是每组两个种子中已找到的最佳可行评价，种子间范围不作统计置信区间。')
    para('一个并行任务在模型尚未开始评价前遇到原输入审计临时文件竞争，已单独重试并完成；现已序列化初始化写日志，原模型与输入不变。12个完成记录和每代种群均核验通过。')
    para('尚需田间信息：有效根深及限制层、原始分层含水实测表、覆膜实际覆盖/完好程度和蒸发证据、灌溉流量时长与效率口径、独立ET或水量观测、亏缺处理产量/冠层，以及收获后至下一播种前的水分回补。缺失数据应明示，不能用图形美化代替验证。')
    doc.save(ROOT/'URP_Optimization_Mechanism_Report.docx')
    (ROOT/'URP_Optimization_Mechanism_Report.md').write_text('\n'.join(md))
    print('Word report created with',len(doc.inline_shapes),'figures and',len(doc.tables),'tables')

if __name__=='__main__':
    workbook();document()
