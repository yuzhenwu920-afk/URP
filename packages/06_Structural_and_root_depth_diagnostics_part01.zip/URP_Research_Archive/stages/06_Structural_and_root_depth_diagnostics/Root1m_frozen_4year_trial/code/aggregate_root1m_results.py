"""Combine all actual evaluations, choose transparent targets, replay selections."""
import json
import numpy as np
import pandas as pd
from audit_engine import ROOT,write
from root1m_engine import RootOneMetre
from run_root1m_optimization import nondominated,POP,GEN,SEEDS

def main():
    status=json.loads((ROOT/'verification/OPTIMIZATION_STATUS.json').read_text())
    assert status['Status']=='COMPLETE'
    baseline=pd.read_csv(ROOT/'tables/Baseline_and_zero_replays.csv',float_precision='round_trip')
    obs=pd.read_csv(ROOT/'tables/Thesis_DI_observed_summary.csv').set_index('Year')
    fronts=[];all_seed_fronts=[];history=[];seed_rows=[];index=[];selected=[];targets=[];summary=[]
    for year in [2019,2020,2021,2022]:
        annual=[]
        base=baseline[(baseline.Year==year)&(baseline.Scenario=='Root1m_DI')].iloc[0]
        old=baseline[(baseline.Year==year)&(baseline.Scenario=='Original_Zmax_2p3m_DI')].iloc[0]
        zero=baseline[(baseline.Year==year)&(baseline.Scenario=='Root1m_zero')].iloc[0]
        for seed in SEEDS:
            folder=ROOT/'runs'/str(year)/f'seed{seed}';r=json.loads((folder/'run.json').read_text())
            assert r['Status']=='COMPLETE' and r['Actual_evaluations']==POP*GEN
            a=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip');assert len(a)==POP*GEN
            assert np.isfinite(a[['Y_13pct','Irrigation_mm','ET_mm','Window1_mm','Window2_mm','Window3_mm','Window4_mm']]).all().all()
            assert a.Water_balance_residual_mm.abs().max()<1e-7 and a.Max_daily_balance_residual_mm.max()<1e-7
            assert a.Irrigation_mm.max()<=base.Irrigation_mm+1e-8
            annual.append(a);f=nondominated(a);all_seed_fronts.append(f)
            h=pd.read_csv(folder/'history.csv');assert len(h)==GEN and h.Population.eq(POP).all() and h.Evaluations.iloc[-1]==POP*GEN
            history.append(h)
            eligible=f[f.Y_13pct>=base.Y_13pct-1e-10]
            seed_rows.append(dict(Year=year,Seed=seed,Evaluations=len(a),Front_points=len(f),
                Maximum_Y13_t_ha=float(f.Y_13pct.max()),Minimum_I_to_model_DI_yield_mm=float(eligible.Irrigation_mm.min()),
                Final_population_HV=float(h.Normalized_hypervolume.iloc[-1]),
                HV_gain_generation80_to100_pct=100*(h.Normalized_hypervolume.iloc[-1]/h.Normalized_hypervolume.iloc[79]-1)))
            index.append(dict(Year=year,Seed=seed,Evaluations=len(a),File=str((folder/'evaluations.csv.gz').relative_to(ROOT)),Generations=GEN))
        combined=pd.concat(annual,ignore_index=True);front=nondominated(combined)
        front['Front_point_id']=[f'{year}_R1_P{i+1:04d}' for i in range(len(front))]
        fronts.append(front)
        high=front.sort_values(['Y_13pct','Irrigation_mm'],ascending=[False,True]).iloc[0].copy()
        high['Selection']='Maximum_found_yield';selected.append(high)
        for name,target in [('Match_root1m_DI_yield',base.Y_13pct),('At_least_95pct_observed',.95*obs.loc[year].Observed_Y13_t_ha),('Match_observed_yield',obs.loc[year].Observed_Y13_t_ha)]:
            eligible=front[front.Y_13pct>=target-1e-10].sort_values('Irrigation_mm')
            row=dict(Year=year,Target=name,Target_Y13_t_ha=float(target),Maximum_found_Y13_t_ha=float(high.Y_13pct),
                Status='FOUND' if len(eligible) else 'NOT_FOUND_IN_SEARCH',Irrigation_mm=None,Y13_t_ha=None,Reduction_vs_DI_pct=None,Front_point_id=None)
            if len(eligible):
                point=eligible.iloc[0].copy();point['Selection']=name;selected.append(point)
                row.update(Irrigation_mm=float(point.Irrigation_mm),Y13_t_ha=float(point.Y_13pct),
                    Reduction_vs_DI_pct=100*(1-point.Irrigation_mm/base.Irrigation_mm),Front_point_id=point.Front_point_id)
            targets.append(row)
        matched=front[front.Y_13pct>=base.Y_13pct-1e-10].iloc[0]
        summary.append(dict(Year=year,Observed_Y13_t_ha=obs.loc[year].Observed_Y13_t_ha,Observed_ET_mm=obs.loc[year].Observed_ET_mm,
            DI_irrigation_mm=base.Irrigation_mm,Original_root2p3_DI_Y13_t_ha=old.Y_13pct,Root1m_DI_Y13_t_ha=base.Y_13pct,
            Root1m_DI_ET_mm=base.ET_mm,Root1m_DI_yield_bias_vs_observed_pct=100*(base.Y_13pct/obs.loc[year].Observed_Y13_t_ha-1),
            Root1m_zero_Y13_t_ha=zero.Y_13pct,Maximum_found_Y13_t_ha=high.Y_13pct,I_at_maximum_yield_mm=high.Irrigation_mm,
            Minimum_I_to_root1m_DI_yield_mm=matched.Irrigation_mm,Reduction_to_root1m_DI_yield_pct=100*(1-matched.Irrigation_mm/base.Irrigation_mm),
            Front_points=len(front),Search_evaluations=len(combined),Uncertainty='frozen original MCMC centers; no recalibration or field validation'))
    front=pd.concat(fronts,ignore_index=True);choices=pd.DataFrame(selected)
    front.to_csv(ROOT/'tables/Root1m_best_found_front.csv',index=False)
    pd.concat(all_seed_fronts,ignore_index=True).to_csv(ROOT/'tables/Root1m_all_seed_fronts.csv',index=False)
    pd.concat(history,ignore_index=True).to_csv(ROOT/'tables/Convergence_all_seeds.csv',index=False)
    pd.DataFrame(seed_rows).to_csv(ROOT/'tables/Seed_stability_summary.csv',index=False)
    pd.DataFrame(index).to_csv(ROOT/'tables/Actual_evaluation_file_index.csv',index=False)
    choices.to_csv(ROOT/'tables/Selected_root1m_front_points.csv',index=False)
    pd.DataFrame(targets).to_csv(ROOT/'tables/Target_feasibility.csv',index=False)
    pd.DataFrame(summary).to_csv(ROOT/'tables/Four_year_root1m_summary.csv',index=False)
    # Independent daily process replay for maximum yield and matched-model yield.
    engine=RootOneMetre();replays=[];dailies=[];layers=[];events=[]
    selected_for_replay=choices[choices.Selection.isin(['Maximum_found_yield','Match_root1m_DI_yield'])]
    for _,point in selected_for_replay.iterrows():
        year=int(point.Year);label=point.Selection;x=point[engine.specs[year]['names']].to_numpy(float)
        r,d,l,k=engine.trace_root(year,label,x)
        for field in ['Y_13pct','Irrigation_mm','ET_mm','Profile_final_mm']:
            np.testing.assert_allclose(r[field],point[field],atol=1e-7,rtol=0)
        r['Front_point_id']=point.Front_point_id;replays.append(r);dailies.append(d);layers.append(l)
        d.to_csv(ROOT/'tables'/f'daily_{year}_{label}.csv',index=False)
        for event in r['irrigation_events']:events.append(dict(Year=year,Selection=label,Date=event['date'],Actual_irrigation_mm=event['mm'],Control_window=event['stage']+1))
    pd.DataFrame(replays).to_csv(ROOT/'tables/Selected_independent_replay_summary.csv',index=False)
    pd.concat(dailies,ignore_index=True).to_csv(ROOT/'tables/Selected_daily_traces.csv.gz',index=False,compression='gzip')
    pd.concat(layers,ignore_index=True).to_csv(ROOT/'tables/Selected_layer_traces.csv.gz',index=False,compression='gzip')
    pd.DataFrame(events).to_csv(ROOT/'tables/Selected_actual_event_schedules.csv',index=False)
    write(ROOT/'verification/AGGREGATION_AND_REPLAY_CHECK.json',dict(Status='PASS',Searches=len(index),Actual_evaluations=sum(x['Evaluations'] for x in index),
        Independent_selected_replays=len(replays),Root_max_m=1.,Root_uptake_below_1m_mm=0.,Frozen_inputs=engine.verify_frozen(),
        Observed_target_absence='NOT_FOUND means absent among finite searched evaluations, not proof of mathematical infeasibility'))
    print(pd.DataFrame(summary).to_string(index=False))

if __name__=='__main__':main()
