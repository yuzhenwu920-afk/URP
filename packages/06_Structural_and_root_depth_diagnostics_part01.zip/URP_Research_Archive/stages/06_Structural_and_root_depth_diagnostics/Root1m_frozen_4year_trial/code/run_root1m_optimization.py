"""Four-year full-range NSGA-III experiment, with maximum root depth 1.00 m.

Two objectives: maximize Y13 and minimize actual irrigation. No minimum-yield
gate, extra storage floor or new per-event equipment limit is imposed. This
isolates the root-depth change from the previous full-range experiment.
"""
from pathlib import Path
import concurrent.futures,json,time
import numpy as np
import pandas as pd
from pymoo.core.problem import Problem
from pymoo.core.sampling import Sampling
from pymoo.core.repair import Repair
from pymoo.core.callback import Callback
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.optimize import minimize
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.indicators.hv import HV
from root1m_engine import RootOneMetre
from audit_engine import ROOT,write

POP,GEN,SEEDS=100,100,[31,73,109,151,199]
FIELDS=['Y_13pct','B_t_ha','Tr_mm','Es_mm','ET_mm','MaxCC','Irrigation_mm','Rain_mm',
    'Runoff_mm','DeepPerc_mm','TileDrain_mm','CR_mm','GwIn_mm','Profile_initial_mm','Profile_final_mm',
    'Surface_initial_mm','Surface_final_mm','Water_balance_residual_mm','Max_daily_balance_residual_mm',
    'Y_dry','Harvest_date','Growing_days','Calendar_days','Early_termination','Crop_dead',
    'Planned_irrigation_mm','Cancelled_irrigation_mm']

def nondominated(frame):
    if frame.empty:return frame.copy()
    # Exact two-objective minimization in I and maximization in Y; no smoothing.
    a=frame.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False]).drop_duplicates(['Irrigation_mm','Y_13pct'])
    record=-np.inf;keep=[]
    for idx,row in a.iterrows():
        if row.Y_13pct>record:keep.append(idx);record=row.Y_13pct
    return a.loc[keep].reset_index(drop=True)

class CapRepair(Repair):
    def _do(self,problem,X,**kwargs):
        a=np.clip(X,0,problem.cap);s=a.sum(axis=1)
        scale=np.ones(len(a));over=s>problem.cap;scale[over]=problem.cap/s[over]
        return a*scale[:,None]

class FullSampling(Sampling):
    def __init__(self):super().__init__();self.used_anchors=False
    def _do(self,problem,n_samples,random_state=None,**kwargs):
        rng=random_state if random_state is not None else np.random.default_rng(0)
        X=rng.dirichlet(np.ones(4),size=n_samples)*rng.uniform(0,1,n_samples)[:,None]*problem.cap
        if not self.used_anchors:
            anchors=[np.zeros(4),problem.base]
            anchors.extend(problem.base*f for f in np.linspace(.05,.95,19))
            anchors.extend(np.eye(4)*problem.cap*.5)
            parent=problem.parent
            if len(parent):anchors.extend(parent[np.unique(np.linspace(0,len(parent)-1,min(20,len(parent)),dtype=int))])
            # Parent fronts include zero irrigation as well. Remove repeated
            # anchors before handing them to pymoo, which otherwise drops the
            # repeated individual and starts with a 99-member first generation.
            unique=[];seen=set()
            for a in anchors:
                a=np.asarray(a,float);a=a*min(1.,problem.cap/max(a.sum(),1e-100))
                key=tuple(np.round(a,10))
                if key not in seen:seen.add(key);unique.append(a)
            for j,x in enumerate(unique[:n_samples]):X[j]=x
            self.used_anchors=True
        return X

class RootProblem(Problem):
    def __init__(self,engine,year,seed,folder):
        self.engine,self.year,self.seed,self.folder=engine,year,seed,folder;self.spec=engine.specs[year]
        self.cap=float(sum(self.spec['baseline_amounts']));self.base=np.array(self.spec['baseline_amounts'])
        self.obs=engine.study['observed_Y13'][str(year)]
        parent=pd.read_csv(ROOT/'sources/Original_full_range_2p3m_front.csv')
        parent=parent[parent.Year==year].sort_values('Irrigation_mm')
        self.parent=parent[self.spec['names']].to_numpy(float)
        self.n_evaluated=0
        super().__init__(n_var=4,n_obj=2,n_ieq_constr=1,xl=np.zeros(4),xu=np.full(4,self.cap))

    def _evaluate(self,X,out,*args,**kwargs):
        fs=[];gs=[];rows=[]
        for x in X:
            r=self.engine.basic(self.year,x);self.n_evaluated+=1
            assert r['Irrigation_mm']<=self.cap+1e-8
            assert r['Planned_irrigation_mm']<=self.cap+1e-8
            delta=r['Irrigation_mm']-self.cap
            g=0. if abs(delta)<=64*np.finfo(float).eps*max(1,self.cap) else delta/self.cap
            fs.append([-r['Y_13pct'],r['Irrigation_mm']]);gs.append([g])
            rows.append(dict(Evaluation=self.n_evaluated,Year=self.year,Seed=self.seed,Zmax_m=1.,
                **dict(zip(self.spec['names'],map(float,x))),**{k:r[k] for k in FIELDS},
                Max_actual_event_mm=max(e['mm'] for e in r['irrigation_events']),
                Gate_95pct_observed_met=bool(r['Y_13pct']>=.95*self.obs),G_irrigation=g))
        out['F']=np.array(fs);out['G']=np.array(gs)
        file=self.folder/'evaluations.csv.gz'
        pd.DataFrame(rows).to_csv(file,index=False,mode='a',header=not file.exists(),compression='gzip')

class History(Callback):
    def __init__(self,problem):super().__init__();self.problem=problem;self.rows=[]
    def notify(self,algorithm):
        p=self.problem;gen=int(algorithm.n_gen);pop=algorithm.pop
        X,F,G,CV=pop.get('X'),pop.get('F'),pop.get('G'),pop.get('CV')
        assert len(X)==POP, 'Population must contain all 100 distinct controls'
        np.savez_compressed(p.folder/f'generation_{gen:04d}.npz',X=X,F=F,G=G,CV=CV)
        normalized=np.c_[F[:,0]/p.obs,F[:,1]/p.cap]
        row=dict(Year=p.year,Seed=p.seed,Generation=gen,Evaluations=p.n_evaluated,
            Population=len(X),Maximum_yield_t_ha=float(-F[:,0].min()),Minimum_irrigation_mm=float(F[:,1].min()),
            Normalized_hypervolume=float(HV(ref_point=np.array([0.,1.05]))(normalized)),
            Feasible_individuals=int((CV.ravel()<=0).sum()))
        self.rows.append(row)
        if gen==1 or gen%5==0:
            pd.DataFrame(self.rows).to_csv(p.folder/'history.csv',index=False)
            write(p.folder/'progress.json',dict(Status='RUNNING',**row))
        if gen%20==0:print(f'{p.year} seed {p.seed}: generation {gen}/{GEN}, evaluations {p.n_evaluated}',flush=True)

def run_seed(engine,year,seed):
    folder=ROOT/'runs'/str(year)/f'seed{seed}';folder.mkdir(parents=True,exist_ok=True);state=folder/'run.json'
    if state.exists():
        previous=json.loads(state.read_text())
        if previous['Status']=='COMPLETE':return previous
        raise RuntimeError(f'Preserve incomplete run {folder}; choose a new output directory')
    p=RootProblem(engine,year,seed,folder)
    identity=dict(Year=year,Seed=seed,Population=POP,Generations=GEN,Root_min_m=.3,Root_max_m=1.,
        Objectives=['maximize grain yield at 13% moisture','minimize actual seasonal irrigation'],
        Yield_gate_enforced=False,Storage_floor_enforced=False,Additional_event_hardware_cap_enforced=False,
        Seasonal_planned_cap_mm=p.cap,Control=p.spec,Film_coverage_pct=75.,fMulch=0.,
        Root_change_only=True,Recalibrated_MCMC=False,Hydrological_profile_depth_m=2.4)
    write(state,dict(Status='RUNNING',Identity=identity));start=time.monotonic()
    try:
        callback=History(p)
        algo=NSGA3(pop_size=POP,ref_dirs=get_reference_directions('das-dennis',2,n_partitions=POP-1),
            sampling=FullSampling(),repair=CapRepair(),eliminate_duplicates=True)
        result=minimize(p,algo,('n_gen',GEN),seed=seed,callback=callback,verbose=False)
        a=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip')
        assert len(a)==POP*GEN==result.algorithm.evaluator.n_eval
        assert len(callback.rows)==GEN
        front=nondominated(a[a.G_irrigation<=0]);front.to_csv(folder/'all_evaluated_front.csv',index=False)
        pd.DataFrame(callback.rows).to_csv(folder/'history.csv',index=False)
        summary=dict(Status='COMPLETE',Identity=identity,Actual_evaluations=len(a),
            Seconds=time.monotonic()-start,Front_points=len(front),Best_found_not_global=True,
            Maximum_yield=float(a.Y_13pct.max()),Frozen_input_check=engine.verify_frozen())
        write(state,summary);write(folder/'progress.json',dict(Status='COMPLETE',Evaluations=len(a)))
        return summary
    except Exception as e:
        write(state,dict(Status='FAILED',Identity=identity,Error=repr(e)));raise

def run_year(year):
    engine=RootOneMetre();engine.check_roots(year)
    return [run_seed(engine,year,s) for s in SEEDS]

def main():
    path=ROOT/'verification/OPTIMIZATION_STATUS.json'
    status=dict(Status='RUNNING',Years=[2019,2020,2021,2022],Population=POP,Generations=GEN,Seeds=SEEDS,
        Planned_actual_evaluations=4*POP*GEN*len(SEEDS),Root_max_m=1.,Runs=[])
    write(path,status)
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(run_year,y):y for y in status['Years']}
        for future in concurrent.futures.as_completed(futures):
            status['Runs'].extend(future.result());write(path,status)
    assert sum(x['Actual_evaluations'] for x in status['Runs'])==status['Planned_actual_evaluations']
    status['Status']='COMPLETE';status['Actual_evaluations']=status['Planned_actual_evaluations'];write(path,status)
    print('COMPLETE:',status['Actual_evaluations'],'actual root-1m evaluations',flush=True)

if __name__=='__main__':main()
