"""Editable result report and workbook; distinguish observed and model targets."""
import json
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl.styles import Font,PatternFill,Alignment
from audit_engine import ROOT

T=ROOT/'tables'
def read(name):return pd.read_csv(T/(name+'.csv'),float_precision='round_trip')

def workbook():
    entries=[('Four_year_summary','Four_year_root1m_summary'),('Target_feasibility','Target_feasibility'),
        ('Selected_points','Selected_root1m_front_points'),('Baselines_zero','Baseline_and_zero_replays'),
        ('Paired_dose_paths','Paired_fixed_proportion_response'),('Seed_stability','Seed_stability_summary'),
        ('Convergence','Convergence_all_seeds'),('Selected_events','Selected_actual_event_schedules'),
        ('Rootzone_water','Rootzone_storage_and_shallow_drainage'),('Water_tradeoff','Matched_yield_water_tradeoff'),
        ('DI_soil_source','Thesis_DI_soil_texture'),('DI_event_source','Thesis_DI_irrigation_events'),
        ('Observed_DI','Thesis_DI_observed_summary'),('Source_audit','Thesis_input_comparison'),
        ('Root1m_settings','Root1m_original_conditions'),('Soil_profile','Hydrological_soil_profile_retained'),
        ('Soil_boundary_check','Secondary_soil_domain_1p1m_baseline_check'),('Evaluation_index','Actual_evaluation_file_index')]
    with pd.ExcelWriter(ROOT/'URP_Root1m_FourYear_Data.xlsx',engine='openpyxl') as writer:
        index=[]
        for sheet,name in entries:
            a=read(name);a.to_excel(writer,sheet_name=sheet,index=False)
            index.append(dict(Sheet=sheet,CSV='tables/'+name+'.csv',Rows=len(a),Note='complete CSV columns'))
        front=read('Root1m_best_found_front')
        columns=['Front_point_id','Year','Seed','Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','MaxCC',
            'Window1_mm','Window2_mm','Window3_mm','Window4_mm','Max_actual_event_mm','Profile_final_mm','Planned_irrigation_mm','Cancelled_irrigation_mm']
        for year in [2019,2020,2021,2022]:
            a=front[front.Year==year];sheet='Front_'+str(year);a[columns].to_excel(writer,sheet_name=sheet,index=False)
            index.append(dict(Sheet=sheet,CSV='tables/Root1m_best_found_front.csv',Rows=len(a),Note='selected columns; full precision and all columns in CSV'))
        pd.DataFrame(index).to_excel(writer,sheet_name='INDEX',index=False);writer.book._sheets.insert(0,writer.book._sheets.pop())
        for ws in writer.book.worksheets:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.showGridLines=False;ws.row_dimensions[1].height=37
            for cell in ws[1]:
                cell.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='275767');cell.alignment=Alignment(wrap_text=True,vertical='center')
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width=min(45,max(13,max(len(str(c.value or '')) for c in list(col)[:40])+2))
                for c in list(col)[1:]:
                    c.font=Font(name='Calibri',size=10)
                    if isinstance(c.value,float):c.number_format='0.0000'
                    if c.row%2==0:c.fill=PatternFill('solid',fgColor='F1F5F6')

def document():
    reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text());s=read('Four_year_root1m_summary')
    targets=read('Target_feasibility');stability=read('Seed_stability_summary');source=read('Thesis_input_comparison')
    soil=read('Thesis_DI_soil_texture');water=read('Rootzone_storage_and_shallow_drainage');trade=read('Matched_yield_water_tradeoff')
    boundary=json.loads((ROOT/'verification/ALL_FRONT_SHALLOW_DOMAIN_CHECK.json').read_text())
    doc=Document();sec=doc.sections[0];sec.left_margin=sec.right_margin=Cm(1.65);sec.top_margin=sec.bottom_margin=Cm(1.55)
    sec.page_width=Cm(21);sec.page_height=Cm(29.7)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
        st=doc.styles[name];st.font.name='DejaVu Sans';st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.styles['Normal'].font.size=Pt(10.5);doc.styles['Normal'].paragraph_format.line_spacing=1.14;doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    doc.styles['Title'].font.size=Pt(22);doc.styles['Heading 1'].font.size=Pt(15);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('275767')
    doc.styles['Heading 2'].font.size=Pt(11.5);doc.styles['Caption'].font.size=Pt(9);doc.styles['Caption'].font.italic=False;doc.styles['Caption'].paragraph_format.line_spacing=1.05
    footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER;footer.add_run('URP · 最大根深1m试验 · ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    md=[]
    def p(text,style=None):doc.add_paragraph(text,style);md.append(text+'\n')
    def h(text):
        paragraph=doc.add_heading(text,1);paragraph.paragraph_format.page_break_before=True;md.append('\n## '+text+'\n')
    def sub(text):doc.add_heading(text,2);md.append('\n### '+text+'\n')
    def table(title,a,columns):
        sub(title);tab=doc.add_table(rows=1,cols=len(columns));tab.style='Light Shading Accent 1'
        flag=OxmlElement('w:tblHeader');tab.rows[0]._tr.get_or_add_trPr().append(flag)
        for cell,(_,label,_) in zip(tab.rows[0].cells,columns):cell.text=label
        for _,row in a.iterrows():
            for cell,(key,_,digits) in zip(tab.add_row().cells,columns):
                v=row[key];cell.text='未找到' if pd.isna(v) else str(v) if digits is None else f'{v:.{digits}f}'
        for row in tab.rows:
            flag=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(flag)
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.space_after=Pt(3)
                    for run in paragraph.runs:run.font.size=Pt(8.5)
        md.append(a[[k for k,_,_ in columns]].to_csv(index=False))
    def fig(number,maxheight=12.6):
        r=reg[number-1];path=ROOT/'figures'/(r['ID']+'.png');im=Image.open(path);w,hh=im.size
        width=min(17.6,maxheight*w/hh);paragraph=doc.add_paragraph();paragraph.alignment=WD_ALIGN_PARAGRAPH.CENTER
        paragraph.add_run().add_picture(str(path),width=Cm(width))
        p(f"图R1-{number:02d} · {r['Title']}",'Caption');p('解析：'+r['Interpretation_CN']);p('解释边界：'+r['Boundary_CN'],'Caption')
        p('数据：'+', '.join(r['Source_tables']),'Caption');md.append(f"![{r['Title']}](figures/{r['ID']}.png)\n")

    doc.add_heading('最大根深1m\n四年DI玉米灌溉优化试验',0)
    p('2019—2022 · 产量—灌水量关系与NSGA-III帕累托前沿',style='Subtitle')
    p('依据王尚今（2023）学位论文DI表格核对输入。版本：2026-10-20。')
    p('试验问题：原最大根深2.30m超出了文献土壤质地资料的1m范围，是否使模型过度利用深层储水？本轮把四年Zmax统一改为1.00m、保留Zmin=0.30m，并重新搜索原DI日期上的水量分配。')
    p('性质：改变根深并重新优化的单因素对照。原MCMC八参数中央值、原天气/ETo、原初始含水与土壤水力转换、地膜管理不变；没有在1m根深下重校准MCMC。因此图中的模型产量不等于新的田间预测定论。')
    p('已完成：4年×5种子×100个体×100代=200,000次实际模型优化评价；每次响应及每代种群保存。另有原DI/零灌水、相同比例灌水的1m/2.3m配对响应、未加速原引擎复核及最浅计算域复核。')
    table('四年关键结果概览',s,[('Year','年',0),('Root1m_DI_Y13_t_ha','1m原DI产量',3),('Maximum_found_Y13_t_ha','最高找到产量',3),('Root1m_zero_Y13_t_ha','零灌水产量',3),('Minimum_I_to_root1m_DI_yield_mm','匹配1m DI最少灌水mm',2)])
    p('产量单位t/ha，均为13%含水率籽粒产量；“最少”限定为本次已评价非支配点中满足对应目标者，不证明全局最优。')

    h('1 文献DI输入核对与来源')
    p('来源为王尚今《不同灌溉方式下覆膜玉米田水热氮传输及作物生长的观测与模拟》，中国农业大学硕士学位论文，2023。表2-1（PDF第19页、正文第9页）DI土壤共六层：0—10、10—20、20—40、40—60、60—80、80—100cm。原四年驱动的砂粒、黏粒与六层厚度逐项一致。')
    table('表2-1 DI土壤质地（%）',soil,[('Top_m','上界m',1),('Bottom_m','下界m',1),('Sand_pct','砂粒%',2),('Silt_pct','粉粒%',2),('Clay_pct','黏粒%',2)])
    p('现有AquaCrop以DI砂/黏含量及原固定OrgMat=2%转换水力参数，本试验保持该转换不变。表5-1是WHCNS使用的van Genuchten参数，不能不经说明就直接替代AquaCrop的FC/WP等参数。表中容重数值完整抄录于CSV，未在本轮新增为AquaCrop校准量。')
    table('表2-3 DI逐次灌水核对',source,[('Year','年',0),('DI_event_count','次数',0),('DI_event_sum_mm','逐次合计mm',2),('Table4_1_irrigation_mm','表4-1总量mm',2),('Difference_mm','差mm',2)])
    p('表2-3（PDF第21页、正文第11页）确定灌水日期和逐次水量；2021年逐次合计633.47mm，而表4-1为633.46mm，保留原逐次记录并注明0.01mm差异。观测产量和ET来自表4-1（PDF第63页、正文第53页），未把原模型产量冒充观测。')
    p('表5-2（PDF第68页、正文第58页）WHCNS校准后的Rmax=100cm，为本次试验提供另一模型中的设定依据；它不是直接测定的AquaCrop有效根深，也不能仅凭土壤采样止于1m就断言田间根系绝不超过1m。')

    h('2 试验设计与比较边界')
    p('根系：仅将最大根深从2.30改为1.00m，最小根深0.30m；根深仍随生长动态变化，并不是播种即固定为1m。四年所有新评价采用相同根深设置，逐日回放确认根深不超1m、1m以下根系取水为0。')
    p('固定：MulchPct=75%、fMulch=0、WetSurf=100%、AppEff=100%，原ETo及气象、年别校准中央参数、原初始含水及现有土壤转换不变。fMulch=0只表示关闭代码中额外减蒸效应，不表示田间膜完好率为0%。原2022初始化先按原模型完成，再覆盖根深，避免改变根深时同时改变初始水映射。')
    p('决策：四个按原事件次序划分的窗口总水量。各次灌水日期与同一窗口内原比例不变；窗口不是重新识别的四个田间生育期。目标为最大化模型Y13、最小化实际季节灌水量，使用NSGA-III；没有虚构产量不确定性第三目标。')
    p('约束：计划季总灌水不超过文献逐次合计。为得到含零灌水的完整曲线，本次不加95%观测产量门槛、不新增季末储水底线或现场单次能力限制。95%线仅作参照，并另检查搜索记录中是否找到满足该目标的点。原MaxIrr/MaxIrrSeason只是日程执行上限，随候选日程设置，不能当成已知设备能力。')
    p('预算：每年100个体、100代、种子31/73/109/151/199。前沿取该年全部50,000次实际评价的非支配并集，而非只取最后一代。种子差异、完整逐代X/F/G/CV及实际评价全部保存。连接前沿点仅作显示，不用平滑拟合生成新产量。')
    p('根深与计算剖面不同：主试验保留原2.4m水文计算网格以隔离根深效应，但根只能在0—1m取水。另将计算域缩至1.1m（AquaCrop要求根底以下0.1m缓冲层），逐点复核最终前沿，检验结果是否仍依赖更深层计算域。')

    h('3 四年数值结果与观测对照')
    table('原DI日程下的根深对照',s,[('Year','年',0),('Observed_Y13_t_ha','观测产量',2),('Original_root2p3_DI_Y13_t_ha','2.3m模型',3),('Root1m_DI_Y13_t_ha','1m模型',3),('Root1m_DI_yield_bias_vs_observed_pct','1m观测偏差%',2),('Root1m_DI_ET_mm','1m ET mm',2)])
    table('重新优化后找到的最高产量及对应水量',s,[('Year','年',0),('Maximum_found_Y13_t_ha','最高找到产量',3),('I_at_maximum_yield_mm','对应灌水mm',2),('DI_irrigation_mm','原DI灌水mm',2),('Front_points','前沿点数',0)])
    for _,r in s.iterrows():p(f"{int(r.Year)}年：零灌水产量{r.Root1m_zero_Y13_t_ha:.3f}t/ha，原DI日程下1m根深产量{r.Root1m_DI_Y13_t_ha:.3f}t/ha；重新分配灌水后最高找到{r.Maximum_found_Y13_t_ha:.3f}t/ha。匹配1m模型原DI产量的最少已找到实际灌水为{r.Minimum_I_to_root1m_DI_yield_mm:.2f}mm，比原日程少{r.Reduction_to_root1m_DI_yield_pct:.2f}%。")
    p('上述最高产量是有限搜索内的模型结果。根深缩短以后，原参数的拟合偏差也可能变化；不能因为曲线更保守就认为1m模型已经校准成功。')
    p('后文表中的“本次未找到”只表示有限搜索记录中没有满足目标的点，不等于数学上证明无解；相应结果保留未找到标记。')

    h('4 四年最优产量—灌水量关系图')
    fig(1,maxheight=11.4)
    p('读取顺序：先看零灌水截距，再看灌水增加后的增产区与平台，最后比较平台与原DI模型星号、文献观测方框的位置。平台意味着当前模型条件下增加灌水已难明显增产，不意味着在田间已证实无需这些水。')
    p('曲线只显示已找到的非支配点，平台后的更高灌水、同等或更低产量点会被支配，所以前沿不一定延伸到原DI总量。原DI参考点仍完整显示，没有删除“看起来不好”的结果。')
    example=s[s.Year==2020].iloc[0]
    p(f"例如2020年最高找到产量仅比1m原DI模型高{example.Maximum_found_Y13_t_ha-example.Root1m_DI_Y13_t_ha:.4f}t/ha。严格最大产量点可能对应很小的末端增产收益，应同时报告前沿、水量及目标阈值，不能自动把该点当成田间推荐制度。")

    h('5 四年NSGA-III帕累托前沿图')
    fig(2,maxheight=13.4)
    p('灰色显示点从完整搜索记录中均匀抽取以避免拥挤；前沿本身使用全部评价计算。各面板统一绝对坐标尺度，保留低水区和零灌水，不通过缩窄纵轴掩盖差异。')
    t=targets[targets.Target=='At_least_95pct_observed'].copy();t['Status_CN']=t.Status.map({'FOUND':'已找到','NOT_FOUND_IN_SEARCH':'本次未找到'})
    table('95%观测产量参照的可达性',t,[('Year','年',0),('Target_Y13_t_ha','95%目标',3),('Maximum_found_Y13_t_ha','最高找到',3),('Status_CN','状态',None),('Irrigation_mm','最少已找到灌水mm',2)])

    h('6 根深变化与水量分配收益分开看')
    fig(3,maxheight=13)
    p('灰色两种线型来自同一原灌水日程按0—100%比例缩放，两组只改变Zmax，因此可以比较根深效应。彩色线则允许在四窗口间重新分配总量，体现本次优化额外获得的配置收益。')
    p('如果固定比例1m曲线下降，而1m优化仍能明显减灌，并不构成矛盾：优化可能避免无效渗漏或改变储水消耗。本次没有新增储水底线，不能预先要求所有减灌空间消失，也不能据此认定田间高节水已获验证。')

    h('7 同模型产量下的减灌与实测产量边界')
    fig(4,maxheight=9)
    table('匹配1m原DI模型产量的候选',s,[('Year','年',0),('Root1m_DI_Y13_t_ha','模型目标t/ha',3),('Minimum_I_to_root1m_DI_yield_mm','灌水mm',2),('Reduction_to_root1m_DI_yield_pct','减灌%',2),('Observed_Y13_t_ha','文献观测t/ha',2)])
    p('这个比较的目标是1m根深下原DI的模型产量，不能改写成“达到文献实测产量”。表中仍有减灌时，应结合0—1m根域储水与根区以下深渗查看其来源。')
    h('7.1 根深缩短后仍存在减灌，来源是什么？')
    w=water[water.Scenario.isin(['Root1m_DI','Match_root1m_DI_yield'])].copy()
    w['Scheme_CN']=w.Scenario.map({'Root1m_DI':'原DI','Match_root1m_DI_yield':'匹配模型产量'})
    table('根域储水与根区以下排水（mm）',w,[('Year','年',0),('Scheme_CN','方案',None),('Irrigation_mm','灌水',2),('ET_mm','ET',2),('Rootzone_storage_change_mm','0—1m储水变化',2),('Drainage_at_1p1m_mm','1.1m排水',2)])
    table('匹配模型产量后的水量差（mm）',trade,[('Year','年',0),('Irrigation_reduction_mm','减灌',2),('ET_reduction_mm','ET减少',2),('Rootzone_final_storage_difference_mm','0—1m季末储水差',2),('Drainage_reduction_at_1p1m_mm','1.1m排水减少',2)])
    for year in [2020,2021]:
        a=w[(w.Year==year)&(w.Scenario=='Root1m_DI')].iloc[0];b=w[(w.Year==year)&(w.Scenario=='Match_root1m_DI_yield')].iloc[0]
        p(f"{year}年原DI在最浅计算域的模型排水为{a.Drainage_at_1p1m_mm:.2f}mm，新匹配产量候选为{b.Drainage_at_1p1m_mm:.2f}mm；两者0—1m根域季内储水变化分别为{a.Rootzone_storage_change_mm:.2f}、{b.Rootzone_storage_change_mm:.2f}mm。重新优化仍可利用避免排水及改变储水消耗的收益，不能仅凭根深改为1m就要求减灌空间全部消失。")
    p('储水在0—1m根域核算，排水在1.1m最浅计算域底边界核算；两者之间有0.1m非根区缓冲层，以上分量不单独构成0—1m闭合式。完整1.1m域水量账另经模型验证，避免把2.4m内根域外存水全当作下季作物可用水。')
    p('排水与储水差在此均为模型输出，不是新增田间实测证据。真实剩余节水空间仍需由分层含水、施灌效率和跨季回补核实；原初始含水重建和亏缺胁迫响应的证据边界也仍然存在。')

    h('8 新候选的逐次灌水量')
    fig(5,maxheight=12)
    p('此处展示匹配1m原DI模型产量的候选。所有实际施灌量来自原引擎逐日回放；若模型提前终止作物生长，之后计划灌水取消，原计划量和实际量分别保存，横轴与目标均采用实际水量。')
    p('日期完全采用文献表2-3：2019/2020各8次，2021年7次，2022年5次。优化窗口按原事件次序分成四组，并非改变灌水日期。最高产量候选与各产量目标候选的完整窗口量、最大单次量和逐次方案在Excel/CSV中提供。')
    p('新候选中若出现超过原实测最大单次量的事件，当前只能说明模型允许该日程，不能直接视为可实施滴灌推荐。需要以流量、时长、面积和入渗/湿润体条件进一步约束。')

    h('9 五种子搜索稳定性与复核')
    fig(6,maxheight=12)
    a=stability.groupby('Year').agg(Max_yield_min=('Maximum_Y13_t_ha','min'),Max_yield_max=('Maximum_Y13_t_ha','max'),
        Match_I_min=('Minimum_I_to_model_DI_yield_mm','min'),Match_I_max=('Minimum_I_to_model_DI_yield_mm','max')).reset_index()
    table('五种子结果范围',a,[('Year','年',0),('Max_yield_min','最高产量最小值',4),('Max_yield_max','最高产量最大值',4),('Match_I_min','匹配产量最少I',2),('Match_I_max','匹配产量最多I',2)])
    p('种子范围不是统计置信区间；当前种群超体积稳定，也不证明全局最优。本报告称“最高找到”“已找到的最少灌水”，不作超出有限搜索证据的断言。')
    p(f"最浅计算域复核：{boundary['Status']}，共回放{boundary['Total_front_point_replays']:,}个最终前沿点；完整逐点差异与阈值见ALL_FRONT_SHALLOW_DOMAIN_CHECK.json及四个Shallow_domain_front_check年度表。主试验根系取水域已限制为0—1m，不是仅修改图注。")

    h('10 这轮试验能回答什么，下一步怎样做')
    p('可以回答：在原年别参数与原DI资料不变的条件下，把根深上限缩到1m，会怎样改变零灌水、固定日程减灌、重新优化后的产量—水量关系；哪些原产量门槛仍有找到的可行点；配置收益中还存在多少根域储水与根区以下渗漏差异。')
    p('不能直接回答：真实田间根深是否严格等于1m、最终可推广的节水率、1m模型重校准后的参数后验及预测区间。土壤质地只测到1m不证明根系物理上不能更深；文献WHCNS的1m参数是设定依据，不能冒充实测根系剖面。')
    p('这轮没有重新拟合MCMC。原八个参数不包含根深及主要水分胁迫阈值，根深变化会改变冠层和生物量拟合条件。若最终采用1m作为正式模型，应在该结构下重新完成阶段1与阶段2校准，核查链诊断与拟合，再做Sobol及优化；不能沿用旧后验却标注“1m模型已校准”。')
    p('初始含水仍沿用冻结重建资料，并非由本篇文献表格新获得的完整播种日实测剖面；0—1m土壤水时序、有效根深、滴灌湿润体与独立ET是优先补充的检验数据。参考蒸散ETo保持原输入，实际ET随根深和胁迫响应，不被直接改写成指定常数。')
    p('论文可将本试验放入“根域结构敏感性与优化外推边界”小节，主文优先图R1-01与R1-02，配四年摘要和目标可达性表；图R1-03解释根深/配置机制，R1-04区分模型与观测目标，R1-05和R1-06可作补充材料。')

    h('附录 数据、代码与参考文献')
    p('参考文献：王尚今，2023。不同灌溉方式下覆膜玉米田水热氮传输及作物生长的观测与模拟。中国农业大学硕士学位论文。关键DI表2-1、2-3、4-1及WHCNS表5-2均按原PDF页码保存截图、文本与来源哈希。')
    p('表图原精度数据在tables，全部逐次模型评价在runs/年份/seed目录，100代X/F/G/CV与history均保留。Excel提供四年前沿的主要列与全部摘要，完整原始列以CSV为准。6组图均有600dpi PNG、PDF、SVG，Word逐图给出解释边界。')
    p('verification包含DI逐项输入核对、冻结文件哈希、8组未加速原引擎逐日对照、最浅水文域复核、20个完整搜索记录及逐代种群对照检查。所有最终结果来自实际模型调用，没有用插值生成新的模拟点。')
    p('复现入口：prepare_thesis_inputs.py → run_root1m_optimization.py → aggregate_root1m_results.py → check_all_fronts_shallow_domain.py → summarize_rootzone_water.py → plot_root1m_figures.py → build_root1m_report.py。参考路径与基线边界检查另由reference_and_validation.py、check_hydrological_boundary.py生成。原MCMC与旧结果不覆盖。')
    doc.save(ROOT/'URP_Root1m_FourYear_Report.docx');(ROOT/'URP_Root1m_FourYear_Report.md').write_text('\n'.join(md))
    print('Word created:',len(doc.inline_shapes),'figures,',len(doc.tables),'tables')

if __name__=='__main__':workbook();document()
