"""English publication figures from actual root-1m model evaluations only."""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from audit_engine import ROOT

T=ROOT/'tables';F=ROOT/'figures';YEARS=[2019,2020,2021,2022]
C={2019:'#0072B2',2020:'#D55E00',2021:'#009E73',2022:'#A45A9D'}
REG=[]
def read(name):return pd.read_csv(T/(name+'.csv'),float_precision='round_trip')
def style(ax):ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.16,axis='both',zorder=0)
def axes(ax):
    ax.set_xlim(-12,670);ax.set_ylim(0,18.3);ax.set_xticks([0,150,300,450,600]);ax.set_yticks([0,5,10,15])
    style(ax)
def save(fig,name,title,sources,interpretation,boundary):
    for ext in ['png','pdf','svg']:fig.savefig(F/(name+'.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig);REG.append(dict(ID=name,Title=title,Source_tables=sources,Interpretation_CN=interpretation,Boundary_CN=boundary))

def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.labelsize':12,'axes.titlesize':13,
        'xtick.labelsize':10.5,'ytick.labelsize':10.5,'legend.fontsize':10,'axes.linewidth':.8,'pdf.fonttype':42,'svg.fonttype':'none'})
    front=read('Root1m_best_found_front');base=read('Baseline_and_zero_replays');obs=read('Thesis_DI_observed_summary').set_index('Year')
    summary=read('Four_year_root1m_summary').set_index('Year');choices=read('Selected_root1m_front_points')
    def baseline(y):return base[(base.Year==y)&(base.Scenario=='Root1m_DI')].iloc[0]
    def zero(y):return base[(base.Year==y)&(base.Scenario=='Root1m_zero')].iloc[0]
    def selected(y,label):return choices[(choices.Year==y)&(choices.Selection==label)].iloc[0]
    # Main deliverable 1: a common scale and explicitly distinct observed/model points.
    fig,ax=plt.subplots(figsize=(9.3,5.6),layout='constrained')
    for y in YEARS:
        a=front[front.Year==y].sort_values('Irrigation_mm');b=baseline(y);z=zero(y)
        ax.plot(a.Irrigation_mm,a.Y_13pct,color=C[y],lw=2,label=str(y),zorder=3)
        ax.scatter([z.Irrigation_mm],[z.Y_13pct],s=55,facecolor='white',edgecolor=C[y],lw=1.5,zorder=5)
        ax.scatter([b.Irrigation_mm],[b.Y_13pct],s=135,marker='*',color=C[y],edgecolor='#263A44',lw=.7,zorder=5)
        ax.scatter([obs.loc[y].Published_Irrigation_mm],[obs.loc[y].Observed_Y13_t_ha],s=47,marker='s',facecolor='none',edgecolor='#273E49',lw=1.1,zorder=6)
    handles,labels=ax.get_legend_handles_labels()
    handles.extend([Line2D([],[],ls='none',marker='o',mfc='white',mec='.3',label='Zero irrigation'),
        Line2D([],[],ls='none',marker='*',ms=11,color='#344955',label='DI model baseline, 1 m'),
        Line2D([],[],ls='none',marker='s',mfc='none',mec='#273E49',label='Observed DI yield')])
    ax.legend(handles=handles,ncol=2,loc='upper left',fontsize=9.5,frameon=True)
    axes(ax);ax.set(xlabel='Actual seasonal irrigation (mm)',ylabel=r'Grain yield at 13% moisture (t ha$^{-1}$)',title=r'Four-year best-found yield–irrigation trade-offs | $Z_{max}$ = 1.00 m')
    save(fig,'R1_01_Four_year_yield_irrigation','Four-year best-found yield–irrigation trade-offs with maximum root depth 1 m',
        ['Root1m_best_found_front.csv','Baseline_and_zero_replays.csv','Thesis_DI_observed_summary.csv'],
        '用户要求的四年合并产量—灌水量图。空心圆为零灌水，星号为1m根深下原DI日程的模型回放，空心方框为文献DI观测产量。',
        '折线连接实际评价得到的非支配点；不是固定比例减灌曲线，也不证明全局最优。原MCMC参数冻结，未在1m根深下重校准。')

    # Main deliverable 2: search cloud and nondominated sets, all four years.
    fig,axs=plt.subplots(2,2,figsize=(10.7,7.9),sharex=True,sharey=True,layout='constrained')
    for ax,y in zip(axs.ravel(),YEARS):
        cloud=[]
        for seed in [31,73,109,151,199]:
            p=ROOT/'runs'/str(y)/f'seed{seed}'/'evaluations.csv.gz'
            a=pd.read_csv(p,usecols=['Irrigation_mm','Y_13pct']);cloud.append(a.iloc[np.linspace(0,len(a)-1,600,dtype=int)])
        cloud=pd.concat(cloud);f=front[front.Year==y].sort_values('Irrigation_mm');b=baseline(y);z=zero(y)
        ax.scatter(cloud.Irrigation_mm,cloud.Y_13pct,s=3,color='#B6C1C7',alpha=.19,rasterized=True,zorder=1)
        ax.plot(f.Irrigation_mm,f.Y_13pct,color=C[y],lw=1.4,zorder=3)
        ids=np.unique(np.linspace(0,len(f)-1,min(45,len(f)),dtype=int));q=f.iloc[ids]
        ax.scatter(q.Irrigation_mm,q.Y_13pct,s=12,color=C[y],zorder=4)
        ax.scatter([b.Irrigation_mm],[b.Y_13pct],s=115,marker='*',color=C[y],edgecolor='#263A44',lw=.7,zorder=5)
        ax.scatter([0],[z.Y_13pct],s=42,facecolor='white',edgecolor=C[y],lw=1.3,zorder=6)
        ax.axhline(obs.loc[y].Observed_Y13_t_ha,color='#435A66',ls='--',lw=.9,zorder=2)
        ax.axhline(.95*obs.loc[y].Observed_Y13_t_ha,color='#AF7C56',ls=':',lw=1,zorder=2)
        axes(ax);ax.set_title(f'{y} | {len(f):,} nondominated points',loc='left',fontsize=12)
    for ax in axs[-1,:]:ax.set_xlabel('Actual seasonal irrigation (mm)')
    for ax in axs[:,0]:ax.set_ylabel(r'Grain yield (t ha$^{-1}$)')
    handles=[Line2D([],[],color='.55',marker='.',ls='none',label='Evaluated controls (sample)'),
        Line2D([],[],color='.2',lw=1.6,marker='o',ms=3,label='Best-found Pareto front'),
        Line2D([],[],ls='none',marker='*',ms=10,color='#344955',label='DI model baseline, 1 m'),
        Line2D([],[],ls='none',marker='o',mfc='white',mec='.3',label='Zero irrigation'),
        Line2D([],[],color='#435A66',ls='--',label='Observed DI yield'),
        Line2D([],[],color='#AF7C56',ls=':',label='95% observed (reference)')]
    fig.legend(handles=handles,loc='outside upper center',ncol=3,fontsize=9.5)
    save(fig,'R1_02_Pareto_fronts_2x2','Four-year NSGA-III Pareto fronts under a 1 m maximum root depth',
        ['Root1m_best_found_front.csv','Actual_evaluation_file_index.csv','Thesis_DI_observed_summary.csv'],
        '用户要求的四年2×2帕累托图，灰点为实际搜索记录的显示抽样，彩色前沿取各年全部五种子、所有代的实际评价并集；星号为1m模型原DI日程，空心圆为零灌水。',
        '模型优化只有产量与实际灌水量两个目标。95%产量线仅作参照，未用于截断搜索；显示抽样不影响前沿计算。')

    # Matched controls isolate root depth without comparing different search budgets.
    dose=read('Paired_fixed_proportion_response')
    fig,axs=plt.subplots(2,2,figsize=(10.5,7.5),sharex=True,sharey=True,layout='constrained')
    for ax,y in zip(axs.ravel(),YEARS):
        f=front[front.Year==y];a=dose[(dose.Year==y)&(dose.Zmax_m==1.)];b=dose[(dose.Year==y)&(dose.Zmax_m==2.3)]
        ax.plot(b.Irrigation_mm,b.Y_13pct,color='#586F7B',ls='--',lw=1.6)
        ax.plot(a.Irrigation_mm,a.Y_13pct,color='#999999',ls=':',lw=1.7)
        ax.plot(f.Irrigation_mm,f.Y_13pct,color=C[y],lw=1.8)
        axes(ax);ax.set_title(str(y),loc='left')
    for ax in axs[-1,:]:ax.set_xlabel('Actual seasonal irrigation (mm)')
    for ax in axs[:,0]:ax.set_ylabel(r'Grain yield (t ha$^{-1}$)')
    fig.legend(handles=[Line2D([],[],color='.2',lw=1.8,label='1.0 m: best-found allocations'),
        Line2D([],[],color='#999999',ls=':',lw=1.7,label='1.0 m: proportional DI doses'),
        Line2D([],[],color='#586F7B',ls='--',lw=1.6,label='2.3 m: proportional DI doses')],loc='outside upper center',ncol=1,fontsize=9.5)
    save(fig,'R1_03_Root_depth_and_allocation','Root-depth effects separated from irrigation-allocation effects',
        ['Root1m_best_found_front.csv','Paired_fixed_proportion_response.csv'],
        '两条比例减灌曲线采用完全相同的日期、窗口比例和总量，仅改变根深；与新1m前沿的差别反映重新分配灌水的收益。',
        '固定比例路径不是优化前沿；此图不把旧2.3m不同搜索预算的前沿当成严格配对实验。')

    # Same-model-yield irrigation comparison; no claim of matching observed yield.
    fig,axs=plt.subplots(1,2,figsize=(10.7,4.7),layout='constrained');x=np.arange(4)
    original=np.array([baseline(y).Irrigation_mm for y in YEARS]);minimum=np.array([selected(y,'Match_root1m_DI_yield').Irrigation_mm for y in YEARS])
    axs[0].bar(x-.17,original,width=.32,color='#CAD3D8',label='Original DI schedule',zorder=3)
    axs[0].bar(x+.17,minimum,width=.32,color=[C[y] for y in YEARS],label='Match 1 m DI model yield',zorder=3)
    for j,y in enumerate(YEARS):axs[0].text(j+.17,minimum[j]+12,f'{100*(1-minimum[j]/original[j]):.1f}%',ha='center',fontsize=10)
    axs[0].set(xticks=x,xticklabels=YEARS,ylabel='Actual seasonal irrigation (mm)',ylim=(0,730),title='Irrigation at matched 1 m DI model yield');axs[0].legend(fontsize=9,loc='upper left')
    for j,y in enumerate(YEARS):
        axs[1].scatter(j-.18,baseline(y).Y_13pct,marker='D',s=43,color='#8D9EA6',zorder=3)
        axs[1].scatter(j,selected(y,'Maximum_found_yield').Y_13pct,marker='o',s=47,color=C[y],zorder=3)
        axs[1].scatter(j+.18,obs.loc[y].Observed_Y13_t_ha,marker='_',s=160,color='#273E49',zorder=3)
    axs[1].set(xticks=x,xticklabels=YEARS,ylabel=r'Grain yield (t ha$^{-1}$)',ylim=(13,18),title='Observed yield and 1 m model responses')
    axs[1].legend(handles=[Line2D([],[],ls='none',marker='D',color='#8D9EA6',label='DI model baseline, 1 m'),
        Line2D([],[],ls='none',marker='o',color='.35',label='Maximum found yield, 1 m'),Line2D([],[],ls='none',marker='_',color='#273E49',label='Observed DI yield')],fontsize=9,loc='upper right')
    for ax in axs:style(ax)
    save(fig,'R1_04_Matched_yield_and_observations','Matched-model-yield irrigation reductions and observed-yield comparison',
        ['Selected_root1m_front_points.csv','Four_year_root1m_summary.csv','Thesis_DI_observed_summary.csv'],
        '左图以1m根深下原DI模型产量为相同目标，右图单列文献实测与模型最高找到产量，避免把同模型产量说成同实测产量。',
        '减灌比例仍可能包含土壤耗储；未设置季末储水约束，不能直接等同耗水减少或田间推荐节水率。')

    events=read('Selected_actual_event_schedules');source=read('Thesis_DI_irrigation_events')
    fig,axs=plt.subplots(2,2,figsize=(10.8,7.2),layout='constrained')
    vmax=max(source.Irrigation_mm.max(),events[events.Selection=='Match_root1m_DI_yield'].Actual_irrigation_mm.max())*1.18
    for ax,y in zip(axs.ravel(),YEARS):
        a=source[source.Year==y];b=events[(events.Year==y)&(events.Selection=='Match_root1m_DI_yield')].set_index('Date').loc[a.Date]
        x=np.arange(len(a));ax.bar(x-.17,a.Irrigation_mm,width=.32,color='#CAD3D8',zorder=3)
        ax.bar(x+.17,b.Actual_irrigation_mm,width=.32,color=C[y],zorder=3)
        ax.set(xticks=x,xticklabels=[v[5:] for v in a.Date],ylim=(0,vmax),title=str(y),ylabel='Actual irrigation (mm)')
        ax.tick_params(axis='x',rotation=40);style(ax)
    fig.legend(handles=[Patch(facecolor='#CAD3D8',label='Published DI schedule'),Patch(facecolor='#557D8A',label='1 m candidate matching DI model yield')],loc='outside upper center',ncol=2,fontsize=9.5)
    save(fig,'R1_05_Selected_irrigation_schedules','Actual event schedules at matched 1 m DI model yield',
        ['Selected_actual_event_schedules.csv','Thesis_DI_irrigation_events.csv'],
        '保留文献原DI灌水日期，比较原水量与新候选实际执行量；四个优化窗口内的原事件比例保持不变。',
        '原执行上限不是设备极限，本根深单因素试验未新加硬件事件限制；大单次量的现场可实施性仍需核实。')

    history=read('Convergence_all_seeds')
    fig,axs=plt.subplots(2,2,figsize=(10.4,6.8),layout='constrained')
    for ax,y in zip(axs.ravel(),YEARS):
        a=history[history.Year==y].pivot(index='Generation',columns='Seed',values='Normalized_hypervolume')
        for seed in a:ax.plot(a.index,a[seed],color=C[y],lw=.6,alpha=.5)
        ax.fill_between(a.index,a.min(axis=1),a.max(axis=1),color=C[y],alpha=.14)
        ax.plot(a.index,a.median(axis=1),color=C[y],lw=1.8)
        ax.set(xlim=(1,100),title=str(y),xlabel='Generation',ylabel='Normalized population hypervolume');style(ax)
    fig.legend(handles=[Line2D([],[],color='.3',lw=1.8,label='Median across five seeds'),Patch(facecolor='.7',alpha=.4,label='Minimum–maximum across seeds')],loc='outside upper center',ncol=2,fontsize=9.5)
    save(fig,'R1_06_Seeded_convergence','Five-seed convergence records for the root-depth experiment',
        ['Convergence_all_seeds.csv','Seed_stability_summary.csv'],
        '展示五种子各代种群超体积、种子中位数与范围，数据来自完整100代记录。',
        '阴影不是置信区间；当前种群指标可波动，指标稳定也不证明全局最优。前沿计算另保留所有已评价非支配点。')
    (ROOT/'FIGURE_REGISTRY.json').write_text(json.dumps(REG,ensure_ascii=False,indent=2))
    print('Created',len(REG),'English figure groups')

if __name__=='__main__':main()
