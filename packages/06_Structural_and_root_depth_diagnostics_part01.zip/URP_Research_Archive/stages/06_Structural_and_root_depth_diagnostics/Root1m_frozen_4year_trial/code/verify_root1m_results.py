"""Match all generation members to actual evaluations and verify root bounds."""
import json,re
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
from audit_engine import ROOT,write
from run_root1m_optimization import nondominated,POP,GEN,SEEDS

def main():
    checks=[];total=0
    for year in [2019,2020,2021,2022]:
        for seed in SEEDS:
            folder=ROOT/'runs'/str(year)/f'seed{seed}'
            a=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip')
            meta=json.loads((folder/'run.json').read_text());assert meta['Status']=='COMPLETE'
            assert len(a)==POP*GEN==meta['Actual_evaluations'];assert a.Evaluation.tolist()==list(range(1,POP*GEN+1))
            assert a.Zmax_m.eq(1.).all();assert a.Water_balance_residual_mm.abs().max()<1e-7
            names=[f'Window{i}_mm' for i in range(1,5)]
            lookup={tuple(row[names].to_numpy(float)):row for _,row in a.iterrows()}
            files=sorted(folder.glob('generation_*.npz'));assert len(files)==GEN
            for i,file in enumerate(files,1):
                data=np.load(file);assert data['X'].shape==(POP,4)
                assert data['F'].shape==(POP,2) and data['G'].shape==(POP,1)
                assert np.isfinite(data['X']).all() and np.isfinite(data['F']).all()
                for x,F,G,CV in zip(data['X'],data['F'],data['G'],data['CV']):
                    row=lookup[tuple(x)]
                    np.testing.assert_allclose(F,[-row.Y_13pct,row.Irrigation_mm],atol=1e-7,rtol=0)
                    np.testing.assert_allclose(G,[row.G_irrigation],atol=1e-10,rtol=0)
                    assert np.isclose(np.maximum(G,0).sum(),CV[0],atol=1e-12)
            total+=len(a);checks.append(dict(Year=year,Seed=seed,Evaluations=len(a),Generation_files=len(files),Population_members_verified=POP*GEN,Status='PASS'))
    front=pd.read_csv(ROOT/'tables/Root1m_best_found_front.csv',float_precision='round_trip')
    assert set(front.Year)=={2019,2020,2021,2022} and not front.Front_point_id.duplicated().any()
    for year,a in front.groupby('Year'):
        assert a.Y_13pct.is_monotonic_increasing and a.Irrigation_mm.is_monotonic_increasing
        assert (a.Y_13pct.diff().iloc[1:]>0).all()
        assert len(nondominated(a))==len(a)
    for name in ['Baseline_daily_traces.csv.gz','Selected_daily_traces.csv.gz']:
        d=pd.read_csv(ROOT/'tables'/name);assert d.Root_depth_m.max()<=1.+1e-9
        assert d.MulchPct_runtime.eq(75.).all() and d.fMulch_runtime.eq(0.).all()
        assert d.Water_balance_residual_mm.abs().max()<1e-7
    for name in ['Baseline_layer_traces.csv.gz','Selected_layer_traces.csv.gz']:
        l=pd.read_csv(ROOT/'tables'/name)
        assert abs(l[l.Depth_top_m>=1.-1e-8].Transpiration_uptake_mm.sum())<1e-7
    reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text());assert len(reg)==6
    for r in reg:
        for ext in ['png','pdf','svg']:assert (ROOT/'figures'/(r['ID']+'.'+ext)).stat().st_size>1000
        assert not re.search('[\u4e00-\u9fff]',(ROOT/'figures'/(r['ID']+'.svg')).read_text())
        assert min(Image.open(ROOT/'figures'/(r['ID']+'.png')).info['dpi'])>590
        for table in r['Source_tables']:assert (ROOT/'tables'/table).exists()
    assert total==200000
    pd.DataFrame(checks).to_csv(ROOT/'verification/Generation_to_actual_evaluation_checks.csv',index=False)
    write(ROOT/'verification/FINAL_DATA_CHECK.json',dict(Status='PASS',Actual_optimization_evaluations=total,
        Generation_files=2000,Population_members_matched=total,Years=[2019,2020,2021,2022],
        Root_max_m=1.,Root_uptake_below_1m_mm=0.,English_figure_groups=6,PNG_dpi=600,MCMC_reruns=0,
        Published_target_rule='missing targets retained as NOT_FOUND_IN_SEARCH; no invented intersection'))
    print('PASS:',total,'evaluations,2000 generations,6 English figure groups,root and water-balance checks')

if __name__=='__main__':main()
