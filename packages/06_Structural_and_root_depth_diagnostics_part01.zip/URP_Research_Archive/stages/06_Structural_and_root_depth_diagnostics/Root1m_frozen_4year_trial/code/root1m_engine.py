"""One-factor root-depth experiment using the frozen four-year DI engines."""
import functools
import numpy as np
from audit_engine import AuditEngine,ROOT,PROJECT,write

class RootOneMetre(AuditEngine):
    def __init__(self,accelerated=True):
        # Preserve original 2022 initialization: prepare all frozen soil/initial
        # profiles BEFORE changing crop root depth. This avoids changing two factors.
        super().__init__(accelerated=accelerated)
        self.original_crop={}
        for year in self.study['years']:
            mod,_=self.adapter._load(year);original=mod.crop_for;self.original_crop[year]=original
            def make(fn):
                @functools.wraps(fn)
                def crop(values):
                    c=fn(values);c.Zmin=.30;c.Zmax=1.00;return c
                return crop
            mod.crop_for=make(original)
        self.adapter._template.cache_clear()

    def restore(self):
        for year,fn in self.original_crop.items():self.adapter._load(year)[0].crop_for=fn
        self.adapter._template.cache_clear()

    def check_roots(self,year):
        meta,soil=self.configuration(year)
        assert meta['Zmax_m']==1. and meta['Zmin_m']==.3
        assert meta['MulchPct']==75. and meta['fMulch']==0.
        return meta,soil

    def trace_root(self,year,label,x):
        r,d,l,k=super().trace(year,label,x)
        assert d.Root_depth_m.max()<=1.+1e-9
        assert abs(l.loc[l.Depth_top_m>=1.-1e-8,'Transpiration_uptake_mm'].sum())<1e-8
        r.update(Experiment='Zmax_1m_one_factor',Maximum_root_depth_m=float(d.Root_depth_m.max()),
            Root_depth_override_m=1.,Invariant_scope='root depth changed; original centers/weather/soil/initial water/film retained')
        return r,d,l,k
