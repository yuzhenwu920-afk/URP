"""Finish numerical postprocessing when the already-running searches complete.

The caller uses a yielding exec session; this helper does not block chat or
request user approval. Packaging is deliberately separate for visual review.
"""
import json,os,subprocess,sys,time
from pathlib import Path
from audit_engine import ROOT,write

def main():
    state=ROOT/'verification/POSTPROCESS_STATUS.json';stages=[]
    write(state,dict(Status='WAITING_FOR_OPTIMIZATION',Stages=stages))
    while True:
        status=json.loads((ROOT/'verification/OPTIMIZATION_STATUS.json').read_text())
        if status['Status']=='COMPLETE':break
        failed=[]
        for p in (ROOT/'runs').glob('*/*/run.json'):
            a=json.loads(p.read_text())
            if a['Status']=='FAILED':failed.append(str(p))
        if failed:raise RuntimeError('Failed search records: '+','.join(failed))
        time.sleep(10)
    commands=[('aggregate_root1m_results',[sys.executable,'code/aggregate_root1m_results.py']),
        ('check_all_fronts_shallow_domain',[sys.executable,'code/check_all_fronts_shallow_domain.py']),
        ('summarize_rootzone_water',[sys.executable,'code/summarize_rootzone_water.py']),
        ('plot_root1m_figures',[sys.executable,'code/plot_root1m_figures.py']),
        ('build_root1m_report',[sys.executable,'code/build_root1m_report.py']),
        ('write_root1m_readme',[sys.executable,'code/write_root1m_readme.py']),
        ('verify_root1m_results',[sys.executable,'code/verify_root1m_results.py']),
        ('convert_word_to_pdf',['soffice','-env:UserInstallation=file://'+str(ROOT/'lo_profile'),'--headless','--convert-to','pdf','--outdir',str(ROOT),str(ROOT/'URP_Root1m_FourYear_Report.docx')])]
    for name,command in commands:
        write(state,dict(Status='RUNNING',Current=name,Stages=stages));print('START',name,flush=True);start=time.monotonic()
        with (ROOT/'verification'/(name+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:
            write(state,dict(Status='FAILED',Current=name,Returncode=result.returncode,Stages=stages));raise RuntimeError(name+' failed; inspect its log')
        stages.append(dict(Stage=name,Status='COMPLETE',Seconds=time.monotonic()-start));print('COMPLETE',name,flush=True)
    write(state,dict(Status='COMPLETE_AWAITING_VISUAL_REVIEW',Stages=stages));print('READY FOR VISUAL REVIEW',flush=True)

if __name__=='__main__':main()
