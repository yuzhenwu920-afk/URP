"""Package the verified root-depth trial and stage a new delivery folder."""
import hashlib,json,shutil,zipfile
from pathlib import Path
import fitz
from docx import Document
from audit_engine import ROOT

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    check=json.loads((ROOT/'verification/FINAL_DATA_CHECK.json').read_text());assert check['Status']=='PASS'
    pdf=fitz.open(ROOT/'URP_Root1m_FourYear_Report.pdf');doc=Document(ROOT/'URP_Root1m_FourYear_Report.docx')
    assert len(doc.inline_shapes)==6 and all(len(p.get_text())>160 for p in pdf)
    selected=[]
    for folder in ['code','tables','figures','sources','verification','runs','model_snapshots']:
        selected.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts
            and p.suffix not in ['.pyc','.lock'] and p.name!='thesis_text.txt')
    selected.extend(ROOT/name for name in ['README.md','FIGURE_REGISTRY.json','URP_Root1m_FourYear_Data.xlsx',
        'URP_Root1m_FourYear_Report.docx','URP_Root1m_FourYear_Report.pdf','URP_Root1m_FourYear_Report.md'])
    selected=sorted(selected)
    manifest=dict(Version='2026-10-20',Scope='four-year maximum-root-depth1m conditional experiment; frozen original MCMC centers',
        MCMC_reruns=0,Actual_optimization_evaluations=200000,Searches=20,Generation_files=2000,
        English_figure_groups=6,Report_pages=len(pdf),Files=[dict(Path=str(p.relative_to(ROOT)),Bytes=p.stat().st_size,SHA256=sha(p)) for p in selected])
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));selected.append(ROOT/'MANIFEST.json')
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+str(p.relative_to(ROOT)) for p in selected)+'\n');selected.append(ROOT/'SHA256SUMS.txt')
    archive=ROOT.parent/'URP_Root1m_FourYear_Experiment_20261020.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in selected:z.write(p,'URP_Root1m_Experiment/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for f in manifest['Files']:assert hashlib.sha256(z.read('URP_Root1m_Experiment/'+f['Path'])).hexdigest()==f['SHA256']
    out=Path('/workspace/URP/deliverables/2026-10-20-root1m-experiment');out.mkdir(exist_ok=True)
    for p in [archive,ROOT/'URP_Root1m_FourYear_Report.docx',ROOT/'URP_Root1m_FourYear_Report.pdf',ROOT/'README.md',
        ROOT/'figures/R1_01_Four_year_yield_irrigation.png',ROOT/'figures/R1_02_Pareto_fronts_2x2.png',
        ROOT/'tables/Four_year_root1m_summary.csv',ROOT/'verification/FINAL_DATA_CHECK.json']:
        shutil.copy2(p,out/p.name)
    report=dict(Status='PASS',Archive=archive.name,Archive_bytes=archive.stat().st_size,Archive_SHA256=sha(archive),
        Files_in_archive=len(selected),Report_pages=len(pdf),ZIP_CRC='PASS',Manifest_hashes='PASS',Prior_outputs_overwritten=False,MCMC_reruns=0)
    (out/'PACKAGE_CHECK.json').write_text(json.dumps(report,indent=2))
    (out/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt')+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
