"""Root-domain storage and drainage below the root domain, kept distinct."""
import numpy as np
import pandas as pd
from audit_engine import ROOT

def main():
    soil=pd.read_csv(ROOT/'tables/Hydrological_soil_profile_retained.csv')
    base=pd.read_csv(ROOT/'tables/Baseline_and_zero_replays.csv');choices=pd.read_csv(ROOT/'tables/Selected_root1m_front_points.csv')
    shallowbase=pd.read_csv(ROOT/'tables/Secondary_soil_domain_1p1m_baseline_check.csv')
    records=[]
    for year in [2019,2020,2021,2022]:
        rootinitial=soil[(soil.Year==year)&(soil.zMid<1)].Initial_storage_mm.sum()
        for label in ['Root1m_DI','Match_root1m_DI_yield','Maximum_found_yield']:
            d=pd.read_csv(ROOT/'tables'/f'daily_{year}_{label}.csv')
            if label=='Root1m_DI':
                r=base[(base.Year==year)&(base.Scenario==label)].iloc[0]
                shallow=shallowbase[(shallowbase.Year==year)&(shallowbase.Scenario==label)].iloc[0]
            else:
                r=choices[(choices.Year==year)&(choices.Selection==label)].iloc[0]
                checks=pd.read_csv(ROOT/'tables'/f'Shallow_domain_front_check_{year}.csv')
                shallow=checks[checks.Front_point_id==r.Front_point_id].iloc[0]
            records.append(dict(Year=year,Scenario=label,Y13_t_ha=r.Y_13pct,Irrigation_mm=r.Irrigation_mm,
                Tr_mm=r.Tr_mm,Es_mm=r.Es_mm,ET_mm=r.ET_mm,Rain_mm=r.Rain_mm,
                Rootzone_initial_0_1m_mm=rootinitial,Rootzone_final_0_1m_mm=d.Storage_0_1p0_m_mm.iloc[-1],
                Rootzone_storage_change_mm=d.Storage_0_1p0_m_mm.iloc[-1]-rootinitial,
                Drainage_at_1p1m_mm=shallow.DeepPerc_at_1p1m_mm,
                Rootzone_note='0–1m storage; drainage reported at1.1m soil boundary including0.1m non-root numerical buffer'))
    frame=pd.DataFrame(records);frame.to_csv(ROOT/'tables/Rootzone_storage_and_shallow_drainage.csv',index=False)
    rows=[]
    for year in [2019,2020,2021,2022]:
        a=frame[(frame.Year==year)&(frame.Scenario=='Root1m_DI')].iloc[0]
        b=frame[(frame.Year==year)&(frame.Scenario=='Match_root1m_DI_yield')].iloc[0]
        rows.append(dict(Year=year,Irrigation_reduction_mm=a.Irrigation_mm-b.Irrigation_mm,
            ET_reduction_mm=a.ET_mm-b.ET_mm,Rootzone_final_storage_difference_mm=a.Rootzone_final_0_1m_mm-b.Rootzone_final_0_1m_mm,
            Drainage_reduction_at_1p1m_mm=a.Drainage_at_1p1m_mm-b.Drainage_at_1p1m_mm,
            Note='components do not alone close0–1m balance: drainage boundary1.1m includes0.1m buffer; full1.1m closure checked separately'))
    pd.DataFrame(rows).to_csv(ROOT/'tables/Matched_yield_water_tradeoff.csv',index=False)

if __name__=='__main__':main()
