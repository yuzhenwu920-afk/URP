"""Transcribed DI cells checked against rendered thesis pages 19,21,63,68."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from audit_engine import AuditEngine,ROOT,PROJECT,write,sha
from root1m_engine import RootOneMetre

SCHEDULES={
2019:[('06-06',64.62),('06-18',67.71),('07-06',63.35),('07-18',58.18),('07-27',62.17),('08-10',63.18),('08-23',30.02),('08-26',36.04)],
2020:[('06-08',81.92),('06-22',59.89),('07-03',71.16),('07-16',84.78),('07-27',64.67),('08-06',72.67),('08-21',63.90),('08-31',60.77)],
2021:[('06-13',93.11),('06-30',86.91),('07-09',84.57),('07-20',76.60),('07-30',114.80),('08-11',89.54),('08-23',87.94)],
2022:[('06-09',84.36),('06-22',77.12),('07-03',80.73),('07-24',76.78),('08-09',85.85)]}
TEXTURE=[(0,.1,29.70,59.66,10.64,1.65),(.1,.2,30.81,58.67,10.52,1.65),(.2,.4,19.43,68.25,12.32,1.69),
    (.4,.6,13.22,70.58,16.20,1.29),(.6,.8,10.38,74.87,14.75,1.48),(.8,1.,11.81,76.53,11.66,1.45)]
OBS={2019:(16.55,661.45,445.27),2020:(17.29,637.03,559.76),2021:(15.86,626.81,633.46),2022:(14.08,584.11,404.84)}

def main():
    events=pd.DataFrame([dict(Year=y,Date=f'{y}-{day}',Irrigation_mm=mm,Source='Table 2-3 DI',PDF_page=21,Printed_page=11) for y,v in SCHEDULES.items() for day,mm in v])
    events.to_csv(ROOT/'tables/Thesis_DI_irrigation_events.csv',index=False)
    texture=pd.DataFrame(TEXTURE,columns=['Top_m','Bottom_m','Sand_pct','Silt_pct','Clay_pct','Bulk_density_as_reported'])
    texture['Source']='Table 2-1 DI, PDF page19 / printed9';texture['Density_note']='printed unit g m-3; numerical values transcribed; density not separately used by original AquaCrop texture conversion'
    texture.to_csv(ROOT/'tables/Thesis_DI_soil_texture.csv',index=False)
    obs=pd.DataFrame([dict(Year=y,Observed_Y13_t_ha=v[0],Observed_ET_mm=v[1],Published_Irrigation_mm=v[2],Source='Table 4-1 DI, PDF page63 / printed53') for y,v in OBS.items()])
    obs.to_csv(ROOT/'tables/Thesis_DI_observed_summary.csv',index=False)
    original=AuditEngine();baseline=[];audits=[]
    for y in original.study['years']:
        mod,data=original.adapter._load(y);spec=original.specs[y]
        requested=events[events.Year==y]
        assert spec['event_dates']==requested.Date.tolist()
        np.testing.assert_allclose(data['schedule'].Depth,requested.Irrigation_mm,atol=1e-10,rtol=0)
        np.testing.assert_allclose(np.array(mod.SOIL_LAYERS),np.array([(r[1]-r[0],r[2],r[4]) for r in TEXTURE]),atol=1e-10,rtol=0)
        r=original.basic(y,spec['baseline_amounts']);r.update(Year=y,Scenario='Original_Zmax_2p3m_DI',Zmax_m=2.3);baseline.append(r)
        audits.append(dict(Year=y,DI_event_count=len(requested),DI_event_sum_mm=requested.Irrigation_mm.sum(),
            Table4_1_irrigation_mm=OBS[y][2],Difference_mm=requested.Irrigation_mm.sum()-OBS[y][2],
            Dates_and_depths_match_original='PASS',Six_DI_texture_layers_match_original='PASS'))
    write(ROOT/'verification/Original_frozen_inputs.json',original.verify_frozen())
    del original
    model=RootOneMetre();soil_all=[];configs=[];dailies=[];layers_all=[]
    for y in model.study['years']:
        meta,soil=model.check_roots(y);configs.append(meta);soil_all.append(soil)
        for label,x in [('Root1m_DI',model.specs[y]['baseline_amounts']),('Root1m_zero',np.zeros(4))]:
            r,d,l,k=model.trace_root(y,label,x);r.update(Zmax_m=1.);baseline.append(r);dailies.append(d);layers_all.append(l)
            d.to_csv(ROOT/'tables'/f'daily_{y}_{label}.csv',index=False)
            print(y,label,'Y',r['Y_13pct'],'I',r['Irrigation_mm'],'ET',r['ET_mm'],flush=True)
    pd.DataFrame(baseline).to_csv(ROOT/'tables/Baseline_and_zero_replays.csv',index=False)
    pd.DataFrame(audits).to_csv(ROOT/'tables/Thesis_input_comparison.csv',index=False)
    pd.DataFrame(configs).to_csv(ROOT/'tables/Root1m_original_conditions.csv',index=False)
    pd.concat(soil_all).to_csv(ROOT/'tables/Hydrological_soil_profile_retained.csv',index=False)
    pd.concat(dailies).to_csv(ROOT/'tables/Baseline_daily_traces.csv.gz',index=False,compression='gzip')
    pd.concat(layers_all).to_csv(ROOT/'tables/Baseline_layer_traces.csv.gz',index=False,compression='gzip')
    write(ROOT/'verification/THESIS_INPUT_AUDIT.json',dict(Status='PASS',DI_table_2_1_checked=True,DI_table_2_3_checked=True,DI_table_4_1_checked=True,
        WHCNS_table5_2_Rmax_cm=100,WHCNS_Rmax_not_direct_root_measurement=True,
        Root_depth_changed_only=True,Original_hydrological_depth_m=2.4,Root_uptake_below_1m_mm=0,
        Hydraulic_parameters='original AquaCrop conversion from DI sand/clay; WHCNS VG parameters not substituted',
        Original_2022_initialization_completed_before_root_override=True,MCMC_reruns=0,Frozen_input_check=model.verify_frozen()))

if __name__=='__main__':main()
