"""Independent original-engine replay and same-schedule dose references."""
import numpy as np
import pandas as pd
from audit_engine import ROOT,AuditEngine,write
from root1m_engine import RootOneMetre

def main():
    original=pd.read_csv(ROOT/'tables/Baseline_and_zero_replays.csv',float_precision='round_trip')
    engine=RootOneMetre(accelerated=False);checks=[]
    for year in engine.study['years']:
        for label,x in [('Root1m_DI',engine.specs[year]['baseline_amounts']),('Root1m_zero',np.zeros(4))]:
            r,d,l,k=engine.trace_root(year,'Unaccelerated_'+label,x)
            reference=original[(original.Year==year)&(original.Scenario==label)].iloc[0]
            differences=[]
            for field in ['Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','Profile_final_mm']:
                np.testing.assert_allclose(r[field],reference[field],atol=1e-7,rtol=0);differences.append(abs(r[field]-reference[field]))
            daily=pd.read_csv(ROOT/'tables'/f'daily_{year}_{label}.csv')
            np.testing.assert_allclose(d[['CC','Root_depth_m','Tr','Es','IrrDay']].to_numpy(),daily[['CC','Root_depth_m','Tr','Es','IrrDay']].to_numpy(),atol=1e-8,rtol=0)
            checks.append(dict(Year=year,Scenario=label,Status='PASS',Max_scalar_difference=max(differences),Root_uptake_below_1m_mm=float(l.loc[l.Depth_top_m>=1.-1e-8,'Transpiration_uptake_mm'].sum())))
            print('Original-engine check',year,label,'PASS',flush=True)
    engine.restore();write(ROOT/'verification/UNACCELERATED_ROOT1M_CHECK.json',dict(Status='PASS',Comparisons=checks,Frozen=engine.verify_frozen()))
    dose=[]
    for depth,engine in [(2.3,AuditEngine()),(1.,RootOneMetre())]:
        for year in engine.study['years']:
            base=np.array(engine.specs[year]['baseline_amounts'])
            for f in np.linspace(0,1,41):
                x=base*f;r=engine.basic(year,x)
                dose.append(dict(Year=year,Zmax_m=depth,Baseline_fraction=float(f),
                    **dict(zip(engine.specs[year]['names'],map(float,x))),
                    **{k:r[k] for k in ['Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','Profile_initial_mm','Profile_final_mm','MaxCC','Water_balance_residual_mm']}))
        if isinstance(engine,RootOneMetre):engine.restore()
    pd.DataFrame(dose).to_csv(ROOT/'tables/Paired_fixed_proportion_response.csv',index=False)
    write(ROOT/'verification/REFERENCE_RUNS_COMPLETE.json',dict(Status='COMPLETE',Same_schedule_model_evaluations=len(dose),Unaccelerated_replays=8,MCMC_reruns=0))
    print('COMPLETE',len(dose),'paired proportional reference evaluations',flush=True)

if __name__=='__main__':main()
