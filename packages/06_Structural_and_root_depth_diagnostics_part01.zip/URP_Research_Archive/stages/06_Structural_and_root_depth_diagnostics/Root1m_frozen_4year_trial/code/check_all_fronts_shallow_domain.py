"""Independently replay final front controls in the minimal 1.1 m soil domain."""
import concurrent.futures
import numpy as np
import pandas as pd
from audit_engine import ROOT,write
from root1m_engine import RootOneMetre
from check_hydrological_boundary import truncate,restore

def run_year(year):
    engine=RootOneMetre();front=pd.read_csv(ROOT/'tables/Root1m_best_found_front.csv',float_precision='round_trip')
    front=front[front.Year==year];data,saved=truncate(engine,year);rows=[]
    try:
        meta,soil=engine.configuration(year)
        assert np.isclose(meta['Soil_depth_m'],1.1) and np.allclose(soil.dz,.1)
        for n,(_,p) in enumerate(front.iterrows(),1):
            r=engine.basic(year,p[engine.specs[year]['names']].to_numpy(float))
            rows.append(dict(Year=year,Front_point_id=p.Front_point_id,
                Soil_domain_depth_m=1.1,Root_max_m=1.,Y13_shallow=r['Y_13pct'],ET_shallow_mm=r['ET_mm'],Irrigation_shallow_mm=r['Irrigation_mm'],
                DeepPerc_at_1p1m_mm=r['DeepPerc_mm'],Runoff_mm=r['Runoff_mm'],
                Profile_initial_0_1p1m_mm=r['Profile_initial_mm'],Profile_final_0_1p1m_mm=r['Profile_final_mm'],
                Delta_Y13=r['Y_13pct']-p.Y_13pct,Delta_ET_mm=r['ET_mm']-p.ET_mm,Delta_Irrigation_mm=r['Irrigation_mm']-p.Irrigation_mm,
                Water_balance_error_mm=r['Water_balance_residual_mm']))
            if n%500==0:print(year,'shallow-domain checks',n,'/',len(front),flush=True)
    finally:restore(engine,data,saved)
    pd.DataFrame(rows).to_csv(ROOT/'tables'/f'Shallow_domain_front_check_{year}.csv',index=False)
    return dict(Year=year,Points=len(rows),Max_abs_yield_difference=max(abs(r['Delta_Y13']) for r in rows),
        Max_abs_ET_difference_mm=max(abs(r['Delta_ET_mm']) for r in rows),
        Max_abs_Irrigation_difference_mm=max(abs(r['Delta_Irrigation_mm']) for r in rows),Frozen=engine.verify_frozen())

def main():
    checks=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        for result in pool.map(run_year,[2019,2020,2021,2022]):checks.append(result)
    equal=all(max(r['Max_abs_yield_difference'],r['Max_abs_ET_difference_mm'],r['Max_abs_Irrigation_difference_mm'])<1e-7 for r in checks)
    write(ROOT/'verification/ALL_FRONT_SHALLOW_DOMAIN_CHECK.json',dict(Status='ALL_WITHIN_TOLERANCE' if equal else 'DIFFERENCES_FOUND',
        Tolerance=1e-7,Years=checks,Total_front_point_replays=sum(x['Points'] for x in checks),
        Note='Primary domain2.4m; secondary1.1m includes minimum0.1m non-root buffer required by AquaCrop; no MCMC resampling'))
    print('Shallow-domain front checks complete:',equal,sum(x['Points'] for x in checks),flush=True)

if __name__=='__main__':main()
