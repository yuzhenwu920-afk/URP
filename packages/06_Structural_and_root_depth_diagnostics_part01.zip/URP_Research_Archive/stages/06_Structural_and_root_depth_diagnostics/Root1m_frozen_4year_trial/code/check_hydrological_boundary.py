"""Secondary diagnostic: root depth vs. bottom-boundary depth are distinct.

The primary experiment changes roots only. This comparison truncates the
soil domain to 1.1 m: AquaCrop requires 0.1 m below Zmax as a numerical buffer.
The buffer is outside the root domain; its properties are still extrapolated.
"""
import copy
import numpy as np
import pandas as pd
from root1m_engine import RootOneMetre
from audit_engine import ROOT,write

def truncate(engine,year):
    mod,data=engine.adapter._load(year)
    saved={k:data[k] for k in ['soil','theta','mid']}
    soil=copy.deepcopy(data['soil']);soil.profile=soil.profile.iloc[:11].copy().reset_index(drop=True)
    soil.nComp=11;soil.nLayer=int(soil.profile.Layer.max());soil.zSoil=1.1;soil.fill_nan()
    data['soil']=soil;data['theta']=data['theta'][:11].copy();data['mid']=data['mid'][:11].copy()
    engine.adapter._template.cache_clear()
    return data,saved

def restore(engine,data,saved):
    data.update(saved);engine.adapter._template.cache_clear()

def main():
    engine=RootOneMetre();records=[]
    original=pd.read_csv(ROOT/'tables/Baseline_and_zero_replays.csv')
    for year in engine.study['years']:
        data,saved=truncate(engine,year)
        try:
            for label,x in [('Root1m_DI',engine.specs[year]['baseline_amounts']),('Root1m_zero',np.zeros(4))]:
                r,d,l,k=engine.trace_root(year,'Shallow_soil_'+label,x)
                base=original[(original.Year==year)&(original.Scenario==label)].iloc[0]
                row=dict(Year=year,Scenario=label,Root_depth_m=1.,Soil_domain_depth_m=1.1,
                    Y13_t_ha=r['Y_13pct'],ET_mm=r['ET_mm'],Irrigation_mm=r['Irrigation_mm'],
                    Delta_Y13_vs_2p4m_domain=r['Y_13pct']-base.Y_13pct,Delta_ET_vs_2p4m_domain_mm=r['ET_mm']-base.ET_mm,
                    DeepPerc_at_1p1m_mm=r['DeepPerc_mm'],Profile_initial_0_1p1m_mm=r['Profile_initial_mm'],Profile_final_0_1p1m_mm=r['Profile_final_mm'])
                records.append(row);print(year,label,row['Delta_Y13_vs_2p4m_domain'],row['Delta_ET_vs_2p4m_domain_mm'],flush=True)
        finally:restore(engine,data,saved)
    pd.DataFrame(records).to_csv(ROOT/'tables/Secondary_soil_domain_1p1m_baseline_check.csv',index=False)
    write(ROOT/'verification/SOIL_DOMAIN_BOUNDARY_CHECK.json',dict(Status='COMPLETE',
        Definition='secondary diagnostic truncates hydraulic domain to1.1m including required0.1m non-root buffer; separate from root-only experiment',
        Maximum_yield_difference=float(max(abs(r['Delta_Y13_vs_2p4m_domain']) for r in records)),
        Maximum_ET_difference_mm=float(max(abs(r['Delta_ET_vs_2p4m_domain_mm']) for r in records)),Frozen_input_check=engine.verify_frozen()))

if __name__=='__main__':main()
