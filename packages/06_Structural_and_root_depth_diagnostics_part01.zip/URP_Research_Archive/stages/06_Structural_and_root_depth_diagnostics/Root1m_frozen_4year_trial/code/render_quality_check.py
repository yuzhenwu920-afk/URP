"""Render contact sheets and check document/figure coverage before packaging."""
import json,re
from pathlib import Path
import fitz
from PIL import Image,ImageDraw
from docx import Document
from openpyxl import load_workbook
from audit_engine import ROOT,write

def main():
    pdf=fitz.open(ROOT/'URP_Root1m_FourYear_Report.pdf');doc=Document(ROOT/'URP_Root1m_FourYear_Report.docx')
    pages=[];report_tiles=[]
    for i,page in enumerate(pdf):
        text=page.get_text();assert '\ufffd' not in text
        assert len(text)>160,('sparse page',i+1,len(text))
        pages.append(dict(Page=i+1,Text_characters=len(text),Images=len(page.get_images())))
        pix=page.get_pixmap(matrix=fitz.Matrix(.65,.65));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
        tile=Image.new('RGB',(415,585),'white');tile.paste(im,((415-im.width)//2,8));ImageDraw.Draw(tile).text((10,566),str(i+1),fill='black');report_tiles.append(tile)
    sheet=Image.new('RGB',(1660,585*((len(report_tiles)+3)//4)),'#bbbbbb')
    for i,tile in enumerate(report_tiles):sheet.paste(tile,((i%4)*415,(i//4)*585))
    sheet.save(ROOT/'verification/report_contact_sheet.jpg')
    tiles=[]
    for p in sorted((ROOT/'figures').glob('*.png')):
        im=Image.open(p).convert('RGB');im.thumbnail((820,650));tile=Image.new('RGB',(850,700),'white');tile.paste(im,((850-im.width)//2,15));ImageDraw.Draw(tile).text((10,677),p.stem,fill='black');tiles.append(tile)
    sheet=Image.new('RGB',(1700,700*((len(tiles)+1)//2)),'#bbbbbb')
    for i,tile in enumerate(tiles):sheet.paste(tile,((i%2)*850,(i//2)*700))
    sheet.save(ROOT/'verification/figure_contact_sheet.jpg')
    assert len(doc.inline_shapes)==6
    for name in ['R1_01_Four_year_yield_irrigation','R1_02_Pareto_fronts_2x2']:
        svg=(ROOT/'figures'/(name+'.svg')).read_text()
        assert all(str(y) in svg for y in [2019,2020,2021,2022])
        assert not re.search('[\u4e00-\u9fff]',svg)
    wb=load_workbook(ROOT/'URP_Root1m_FourYear_Data.xlsx',read_only=True)
    assert all('Front_'+str(y) in wb.sheetnames for y in [2019,2020,2021,2022])
    write(ROOT/'verification/DOCUMENT_QUALITY.json',dict(Status='PASS_PENDING_VISUAL_REVIEW',Report_pages=len(pdf),
        Word_figures=len(doc.inline_shapes),Word_tables=len(doc.tables),Workbook_sheets=len(wb.sheetnames),
        Main_figures_include_all_four_years=True,PNG_native_dpi=600,Pages=pages))
    print('Rendered',len(pdf),'report pages and',len(tiles),'figure groups')

if __name__=='__main__':main()
