# 2021 原模型30分钟 MCMC 验证试验

本轮以刚完成诊断的历史2021年模型为对象，保持原先验密度、参数范围、观测误差、根系、地膜、初始水和DI日程。不是后来的1m/fMulch短链，也不通过调整边界来让诊断通过。

## 设计

- 第一阶段：4组原2000步×32 walkers的链，从原位置、似然与MT19937状态延续。
- 第二阶段：延续原一组，并按原初始化策略补3组独立随机种子，均使用原第一阶段保留均值作为固定交接。
- 两阶段8组ensemble并行共享4核配额，统一墙钟1800秒截止，允许当前完整迭代结束；每组所有实际新状态都保留。
- 主要阶段一比较：原完整前缀＋最短共同新段，固定丢弃347步。
- 主要阶段二比较：4组最短共同新段，固定丢弃每段前239步；不把旧2000步复制到新初始化链。
- 固定中心似然切片：CDC_CD、SenescenceCD、Kcb与局部CCx网格；WP_late–HI0条件二维网格；同一整数物候日的5个连续输入。

## 结果文件

- `RESULT_SUMMARY.json` 与 `docs/RESULTS_CN.md`：实际结果摘要。
- `docs/URP_2021_30min_MCMC_Validation_CN.docx`、同名PDF：方法、实际步数、指标变化、机制检查、CC/产量中心对照及解释边界。
- `figures/`：6组英文PNG与矢量PDF；`docs/English_Figure_Atlas.pdf`：六页图册。
- `tables/Timed_MCMC_2021_validation.xlsx`、CSV与`tables/progress/`：阶段指标、相关、网格与时间快照。
- `runs/phase1`、`runs/phase2`：8组实际新链、似然、接受记录、RNG状态、初始位置、进程日志与计数。
- `runs/ANALYSIS_ARRAYS.npz`：明确命名的原链、共同新段与分析数组；两阶段分别存储。
- `source/original_checkpoints/`：5份原正式完整链；`source/model_2021/`：匹配代码与输入快照。
- `verification/`：旧似然复现、数值核等价、原采样器前两步逐项复演、计算次数、源文件哈希与最终QA。

`history` 在新链文件中仅表示**新增**时间段；原前缀位于`source/original_checkpoints`，基准步数见各文件的`original_base_steps`。分析比较为共同长度而截短，不会删除每组实际完成的新状态。

## 科学解释

R̂/ESS以独立ensemble为重复单位，同一walker编号跨4个ensemble构成诊断组；32组相互依赖，ESS不相加。原阶段二仍只有1组，其原R̂保留为空；新阶段二R̂只对应本轮4组新增时间段。

新阶段二短段未通过诊断，不能倒推为原2000步条件链已被证明不收敛；原结果缺少独立重复认证与本轮新链的有限混合是两项不同判断。

短试验未通过标准时，不把它改写为收敛；通过完整性QA也不意味着后验收敛。固定中心切片不是干扰参数优化后的profile likelihood；局部平坦不等同于全局不可辨识。均值组合只作确定性拟合检查，不拼成八参数联合后验，不证明无偏。

## 复算

Python3.12，版本见`requirements.txt`。重算数据分析与文档：

```bash
python code/analyze_trial.py --final
python code/export_fit_checks.py
python code/make_outputs.py
python code/build_report.py
```

若需要重新采样，应复制为新的实验目录并明确保存既有结果，再运行预检与`run_timed_trial.py --seconds 1800`；该命令本身不是对现有短试验的续跑入口，不能用来覆盖原试验记录。`URP_EXACT_KERNELS`可指向包内`source/kernels`。原模型物理参数保持Zmax=2.3m、75%覆盖、fMulch=0，仅作为明确的历史结构基线。
