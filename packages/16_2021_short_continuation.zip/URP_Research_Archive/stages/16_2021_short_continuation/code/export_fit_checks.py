"""Deterministic center fits after the trial; do not manufacture an 8D posterior."""
import json
import numpy as np
import pandas as pd
from experiment_engine import ROOT,load,checkpoint,dump

def metrics(obs,sim):
    a,b=np.asarray(obs),np.asarray(sim);return dict(N=len(a),RMSE=float(np.sqrt(np.mean((a-b)**2))),
        R2=float(1-np.sum((a-b)**2)/np.sum((a-a.mean())**2)))

def main():
    _,m,data,start=load(True,'center_fits');names1=m.PHASE1_NAMES;names2=m.PHASE2_NAMES
    with np.load(checkpoint('phase2')) as z:
        c=json.loads(z['contract'].item());oldp2=z['history'][239:].mean((0,1))
    d=pd.read_csv(ROOT/'tables/Final_parameter_diagnostics.csv')
    p1=d.query('Phase=="phase1" and Comparison=="Extended_original_target"').set_index('Parameter').Mean.to_dict()
    p2=d.query('Phase=="phase2" and Comparison=="Four_independent_conditional_new_segments"').set_index('Parameter').Mean.to_dict()
    base=dict(c['fixed'],**dict(zip(names2,map(float,oldp2))))
    cases={'Original_centers':base,'Extended_phase1_center_old_phase2':dict(base,**p1)}
    if len(p2)==3:cases['Original_phase1_new_conditional_phase2']=dict(base,**p2)
    rows=[];ccrows=[];brows=[];calls=0
    for label,p in cases.items():
        s,g,cc,b=m.simulate(data,p);calls+=1
        rows.append(dict(s,Case=label,Observed_Y13=float(m.Y13_PUBLISHED),Yield_difference_t_ha=s['Y_13pct']-m.Y13_PUBLISHED,
            Yield_difference_pct=100*(s['Y_13pct']/m.Y13_PUBLISHED-1),CC_R2=metrics(cc.Observed_CC,cc.canopy_cover)['R2'],
            CC_RMSE=metrics(cc.Observed_CC,cc.canopy_cover)['RMSE'],Scope='Deterministic center check, not posterior predictive uncertainty or an 8D joint draw'))
        cc['Case']=label;b['Case']=label;ccrows.append(cc);brows.append(b)
        g['Case']=label;g.to_csv(ROOT/'tables'/f'{label}_daily_growth.csv',index=False)
    pd.DataFrame(rows).to_csv(ROOT/'tables/Center_fit_comparison.csv',index=False)
    pd.concat(ccrows).to_csv(ROOT/'tables/Center_CC_pairs.csv',index=False)
    pd.concat(brows).to_csv(ROOT/'tables/Center_biomass_pairs.csv',index=False)
    dump(ROOT/'verification/CENTER_FIT_CALLS.json',dict(Actual_model_calls=calls,No_refit_performed=True,Not_joint_8D_posterior=True))
    with pd.ExcelWriter(ROOT/'tables/Timed_MCMC_2021_validation.xlsx',engine='openpyxl',mode='a',if_sheet_exists='replace') as w:
        for name in ['Center_fit_comparison','Center_CC_pairs','Center_biomass_pairs']:
            pd.read_csv(ROOT/'tables'/f'{name}.csv').to_excel(w,sheet_name=name[:31],index=False)
    print(pd.DataFrame(rows)[['Case','Y_13pct','Yield_difference_pct','CC_R2','CC_RMSE']].to_string(index=False))
if __name__=='__main__':main()
