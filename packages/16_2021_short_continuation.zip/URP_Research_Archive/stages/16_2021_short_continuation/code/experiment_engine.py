"""Unchanged historical 2021 likelihood; no 1 m or mulch overrides."""
from pathlib import Path
import functools,hashlib,importlib.util,json,os,sys,time
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
SOURCE=ROOT/'source/model_2021/DI_2021_MCMC_ONE_CLICK.py'
KERNELS=Path(os.environ.get('URP_EXACT_KERNELS','/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/real_model'))
import numpy as np

def dump(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(tmp,p)

def load(accelerated=True,tag='default'):
    spec=importlib.util.spec_from_file_location('original2021_driver_timed',SOURCE)
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    for name in ['sampler','diagnostics','audit_hooks','ensemble_pipeline']:driver._embedded_module(name)
    m=driver._embedded_module('model',SOURCE.parent/'data/model.py')
    m.OUTPUT_DIR=ROOT/'verification/input_audit'/tag;m.OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
    data=m.load_inputs();m.prepare_soil(data)
    start=json.loads((SOURCE.parent/'data/start.json').read_text())
    m.PRIOR_BOUNDS.update(WP_early=(10.,40.),WP_late=(10.,40.),HI0=(.35,.60))
    m.NORMAL_PRIORS={'CDC_CD','SenescenceCD'};data['center'].update(WP_early=25.,WP_late=25.)
    m.effective_wp=functools.lru_cache(maxsize=4096)(m.effective_wp)
    if accelerated:install_kernels()
    return driver,m,data,start

def install_kernels():
    p=KERNELS if KERNELS.exists() else ROOT/'source/kernels'
    sys.path.insert(0,str(p));import numerical_acceleration;numerical_acceleration.install()

def checkpoint(phase,e=1):return ROOT/'source/original_checkpoints'/phase/f'ensemble_{e}.npz'

def verify_contract(m,data,c):
    assert c['priors']=={k:list(v) for k,v in m.PRIOR_BOUNDS.items()}
    assert c['normal_priors']==sorted(m.NORMAL_PRIORS)
    assert c['prior_sd']==m.PRIOR_SD
    assert c['center']==data['center']
    assert c['sigmas']==[m.SIGMA_CC,m.SIGMA_TR,m.SIGMA_ES,m.SIGMA_Y]
    assert c['targets']==[m.TR_TARGET,m.ES_TARGET,m.YDRY_TARGET]
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==c['files'][SOURCE.name]
    test=m.crop_for(c['fixed']);fm=m.field_management()
    assert test.Zmin==.3 and test.Zmax==2.3 and fm.mulch_pct==75. and fm.f_mulch==0.

def preflight():
    driver,m,data,start=load(False,'preflight')
    refs=[];checks=[]
    for phase in ['phase1','phase2']:
        with np.load(checkpoint(phase),allow_pickle=False) as z:
            c=json.loads(z['contract'].item());verify_contract(m,data,c)
            for step,w in [(0,0),(-1,0),(-1,int(np.argmax(z['logs'][-1])))]:
                v=z['history'][step,w];t=time.monotonic();actual=m.logprob(v,c['names'],c['fixed'],c['phase'],data)
                diff=abs(float(actual)-float(z['logs'][step,w]));assert diff<1e-8,(phase,step,w,diff)
                refs.append((phase,c,v.copy(),actual));checks.append(dict(Phase=phase,Step=step,Walker=w,Unaccelerated_logp=actual,Stored_logp=float(z['logs'][step,w]),Difference=diff,Seconds=time.monotonic()-t))
    install_kernels();timings=[]
    for phase,c,v,ref in refs:
        t=time.monotonic();value=m.logprob(v,c['names'],c['fixed'],c['phase'],data);timings.append(time.monotonic()-t)
        assert abs(value-ref)<1e-8,(phase,value,ref)
    with np.load(checkpoint('phase1'),allow_pickle=False) as z:
        c=json.loads(z['contract'].item());X=z['history'][-1]
    t=time.monotonic()
    for v in X[:12]:m.logprob(v,c['names'],c['fixed'],c['phase'],data)
    per=(time.monotonic()-t)/12
    out=dict(Status='PASS',Year=2021,Zmin_m=.3,Zmax_m=2.3,MulchPct=75.,fMulch=0.,
        Priors_unchanged=True,Observation_likelihood_unchanged=True,Checks=checks,
        Acceleration_absolute_logp_differences=[abs(float(m.logprob(v,c0['names'],c0['fixed'],c0['phase'],data))-ref) for ph,c0,v,ref in refs],
        Accelerated_seconds=timings,Seconds_per_in_support_model_evaluation=per)
    dump(ROOT/'verification/PREFLIGHT.json',out);print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':preflight()
