"""Periodic snapshots during the same running timed experiment."""
from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'verification/TRIAL_DESIGN.json').read_text());start=d['Start_epoch'];deadline=d['Deadline_epoch']
next_t=300
while time.time()<deadline:
    elapsed=time.time()-start
    if elapsed>=next_t:
        with (ROOT/'verification/progress_analysis.log').open('a') as f:
            subprocess.run([sys.executable,str(ROOT/'code/analyze_trial.py')],stdout=f,stderr=f,check=True)
        next_t+=180
    time.sleep(min(10,max(0,deadline-time.time())))
