"""Replay first two iterations using the original sampler, not the new harness."""
from pathlib import Path
import json,shutil,sys,tempfile
import numpy as np
from experiment_engine import ROOT,checkpoint,load,dump

def main():
    _,m,data,start=load(True,'exact_continuation_replay');counts={'Model_calls':0}
    orig=m.simulate
    def sim(*args,**kwargs):counts['Model_calls']+=1;return orig(*args,**kwargs)
    m.simulate=sim;records=[]
    with tempfile.TemporaryDirectory(prefix='urp_30min_exact_replay_') as tmp:
        for ph,e,resume in [('phase1',1,True),('phase2',1,True),('phase2',2,False)]:
            with np.load(checkpoint(ph,1),allow_pickle=False) as z:c=json.loads(z['contract'].item())
            names=c['names'];bounds=np.array([c['priors'][k] for k in names]);path=Path(tmp)/f'{ph}_{e}.npz'
            if resume:shutil.copyfile(checkpoint(ph,1),path)
            steps=2002 if resume else 2
            seed=42+2021*100+(e-1)+(100000 if ph=='phase2' else 0)
            history,logs,accepted=sys.modules['_di_2021_sampler'].run_ensemble(
                lambda v:m.logprob(v,names,c['fixed'],c['phase'],data),
                np.array([c['fixed'][k] for k in names]),bounds[:,0],bounds[:,1],steps,32,seed,path,c,25)
            with np.load(ROOT/'runs'/ph/f'ensemble_{e}_extension.npz',allow_pickle=False) as z:
                new=z['history'][:2];lp=z['logs'][:2];a=z['accepted'][:2]
            ref=history[-2:];rl=logs[-2:];ra=accepted[-2:]
            assert np.array_equal(new,ref) and np.array_equal(lp,rl) and np.array_equal(a,ra),(ph,e)
            records.append(dict(Phase=ph,Ensemble=e,Original_sampler_reference=True,
                First_two_new_iterations_bitwise_match=True,Coords_max_difference=float(np.max(abs(new-ref))),
                Logp_max_difference=float(np.max(abs(lp-rl))),Acceptance_identical=True,Resume=resume))
    dump(ROOT/'verification/EXACT_SAMPLER_REPLAY.json',dict(Status='PASS',Records=records,Counts=counts))
    print('PASS: exact original sampler replay, both continuations and fresh phase2 initialization.',counts,flush=True)
if __name__=='__main__':main()
