"""Small fixed-center likelihood slices; diagnostic, not optimization or refit."""
import json,time
import numpy as np
import pandas as pd
from experiment_engine import ROOT,load,checkpoint,dump

def main():
    _,m,data,start=load(True,'controlled_profiles');t0=time.time()
    with np.load(checkpoint('phase1'),allow_pickle=False) as z:c1=json.loads(z['contract'].item())
    with np.load(checkpoint('phase2'),allow_pickle=False) as z:
        c2=json.loads(z['contract'].item());p2mean=z['history'][239:].mean((0,1))
    fixed1=dict(c1['fixed'],**{k:c2['fixed'][k] for k in c1['names']})
    fixed2=dict(c2['fixed'],**dict(zip(c2['names'],map(float,p2mean))))
    counts=dict(Logp_queries=0,Actual_model_calls=0)
    orig=m.simulate
    def sim(*args,**kwargs):counts['Actual_model_calls']+=1;return orig(*args,**kwargs)
    m.simulate=sim
    def score(p,names,c):
        counts['Logp_queries']+=1;v=np.array([p[k] for k in names]);lp=m.logprob(v,names,c['fixed'],c['phase'],data)
        prior=sum(-.5*((p[k]-data['center'][k])/m.PRIOR_SD[k])**2 for k in names if k in m.NORMAL_PRIORS)
        return lp,prior,lp-prior
    rows=[]
    for k,grid in [('CDC_CD',np.linspace(.03,.12,41)),('SenescenceCD',np.linspace(125.,145.,101)),('Kcb',np.linspace(1.05,1.60,41)),('CCx',np.linspace(.90,.99,41))]:
        for v in grid:
            p=dict(fixed1,**{k:float(v)});lp,pr,ll=score(p,c1['names'],c1)
            rows.append(dict(Parameter=k,Value=v,Rounded_senescence_day=round(p['SenescenceCD']),Log_posterior=lp,Log_prior=pr,Log_likelihood=ll,
                Scope='Fixed nuisance parameters at original phase1 retained mean; not profile-optimized likelihood'))
    pd.DataFrame(rows).to_csv(ROOT/'tables/Fixed_center_parameter_likelihood_slices.csv',index=False)
    pair=[]
    for wp in np.linspace(18.,27.,21):
        for hi in np.linspace(.50,.60,21):
            p=dict(fixed2,WP_late=float(wp),HI0=float(hi));lp,pr,ll=score(p,c2['names'],c2)
            pair.append(dict(WP_late=wp,HI0=hi,WP_early_fixed=fixed2['WP_early'],Log_posterior=lp,Log_prior=pr,Log_likelihood=ll,
                Scope='Original conditional phase2 target, WP_early held at original retained mean'))
    pd.DataFrame(pair).to_csv(ROOT/'tables/WP_HI_fixed_center_likelihood_grid.csv',index=False)
    rounded=[];daily=[]
    for sen in [134.55,134.75,134.95,135.15,135.35]:
        p=dict(fixed1,SenescenceCD=sen);s,g,cc,bio=m.simulate(data,p);lp,pr,ll=score(p,c1['names'],c1)
        rounded.append(dict(SenescenceCD_continuous=sen,Runtime_rounded_day=round(sen),Y13=s['Y_13pct'],Tr_mm=s['Tr_mm'],Es_mm=s['Es_mm'],Log_likelihood=ll,Log_prior=pr,Log_posterior=lp))
        daily.append(g.canopy_cover.to_numpy())
    pd.DataFrame(rounded).to_csv(ROOT/'tables/Subday_senescence_mechanism_check.csv',index=False)
    dif=float(np.max(np.ptp(np.array(daily),axis=0)));assert dif<1e-12
    dump(ROOT/'verification/CONTROLLED_PROFILE_COMPUTATION.json',dict(Status='COMPLETE',Counts=counts,
        Phase1_slice_points=len(rows),Phase2_grid_points=len(pair),Subday_checks=len(rounded),
        Subday_maximum_daily_CC_difference=dif,Runtime_seconds=time.time()-t0,
        Note='Conditional fixed-center likelihood slices; not refitting, nuisance profiling, global identifiability proof or unbiasedness test'))
    print('PROFILES COMPLETE',counts,flush=True)
if __name__=='__main__':main()
