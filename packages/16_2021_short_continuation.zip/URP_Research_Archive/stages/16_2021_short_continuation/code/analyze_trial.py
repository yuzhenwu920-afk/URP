"""Compare equal-time extensions without changing targets or selecting burn-in."""
from pathlib import Path
import argparse,json,time,warnings
import numpy as np
import pandas as pd
import arviz as az
from emcee.autocorr import integrated_time
from experiment_engine import ROOT,checkpoint,dump

def metric(raw,names,burn,label,phase,elapsed):
    E,T,W,D=raw.shape
    if T-burn<8:return [],[]
    ret=raw[:,burn:];v=ret.reshape(-1,D);rows=[];groups=[]
    tau=[]
    for x in raw:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore');tau.append(integrated_time(x,tol=0,quiet=True))
    tau=np.array(tau)
    with np.load(checkpoint(phase)) as z:c=json.loads(z['contract'].item())
    for j,k in enumerate(names):
        ds=[]
        if E>=4:
            for w in range(W):
                x=ret[:,:,w,j];q=dict(Rhat=float(az.rhat(x,method='rank')),ESS_bulk=float(az.ess(x,method='bulk')),ESS_tail=float(az.ess(x,method='tail')))
                groups.append(dict(Comparison=label,Phase=phase,Parameter=k,Walker_index=w,Elapsed_seconds=elapsed,**q));ds.append(q)
        a=v[:,j];lo,hi=c['priors'][k];width=hi-lo
        row=dict(Comparison=label,Phase=phase,Parameter=k,Independent_ensembles=E,Raw_time_steps=T,Fixed_discard_steps=burn,
            Retained_time_steps=T-burn,Stored_correlated_rows=len(a),Mean=a.mean(),SD=a.std(ddof=1),
            Q025=np.quantile(a,.025),Median=np.median(a),Q975=np.quantile(a,.975),
            Lower_1pct_mass=np.mean(a<=lo+.01*width),Upper_1pct_mass=np.mean(a>=hi-.01*width),
            Lower_5pct_mass=np.mean(a<=lo+.05*width),Upper_5pct_mass=np.mean(a>=hi-.05*width),
            Prior_low=lo,Prior_high=hi,Tau_max=tau[:,j].max(),Steps_over_tau=T/tau[:,j].max(),
            Rhat_max=max(d['Rhat'] for d in ds) if ds else np.nan,
            Rhat_median=np.median([d['Rhat'] for d in ds]) if ds else np.nan,
            ESS_bulk_min=min(d['ESS_bulk'] for d in ds) if ds else np.nan,
            ESS_tail_min=min(d['ESS_tail'] for d in ds) if ds else np.nan,
            Elapsed_seconds=elapsed,
            Status='SHORT_WINDOW_NOT_FORMAL' if T-burn<100 else 'SINGLE_ENSEMBLE_NO_INDEPENDENT_RHAT' if E<4 else 'DIAGNOSTICS_COMPUTABLE')
        row['Criteria_met']=bool(E>=4 and T>=2000 and T-burn>=100 and row['Rhat_max']<1.01 and row['ESS_bulk_min']>=400 and row['ESS_tail_min']>=400 and T>=50*row['Tau_max'])
        rows.append(row)
    return rows,groups

def main(final=False):
    if final and not (ROOT/'verification/TRIAL_COMPLETION.json').exists():
        raise RuntimeError('The timed sampler has not completed; do not label a partial snapshot final.')
    design=json.loads((ROOT/'verification/TRIAL_DESIGN.json').read_text());elapsed=time.time()-design['Start_epoch']
    rows=[];groups=[];chainmap={};counts=[];correlations=[]
    for ph in ['phase1','phase2']:
        originals=[]
        for e in range(1,5 if ph=='phase1' else 2):
            with np.load(checkpoint(ph,e)) as z:originals.append(z['history'].copy());c=json.loads(z['contract'].item())
        base=np.array(originals);names=c['names'];burn=347 if ph=='phase1' else 239
        rr,gg=metric(base,names,burn,'Original_2000',ph,0);rows+=rr;groups+=gg;chainmap[ph+'_original']=base
        ext=[]
        for e in range(1,5):
            p=ROOT/'runs'/ph/f'ensemble_{e}_extension.npz'
            if not p.exists():break
            with np.load(p,allow_pickle=False) as z:
                h=z['history'].copy();assert np.isfinite(h).all();ext.append(h)
            counts.append(json.loads((p.parent/f'ensemble_{e}_status.json').read_text()))
        if len(ext)!=4:continue
        common=min(len(h) for h in ext)
        if not common:continue
        extra=np.stack([h[:common] for h in ext]);chainmap[ph+'_common_new']=extra
        if ph=='phase1':x=np.concatenate([base,extra],axis=1);label='Extended_original_target'
        else:x=extra;label='Four_independent_conditional_new_segments'
        rr,gg=metric(x,names,burn,label,ph,elapsed);rows+=rr;groups+=gg;chainmap[ph+'_analysis']=x
        if len(x[0])>burn:
            a=x[:,burn:].reshape(-1,len(names));corr=np.corrcoef(a.T)
            for i,k in enumerate(names):
                for j,l in enumerate(names):correlations.append(dict(Phase=ph,Parameter_1=k,Parameter_2=l,Pearson_r=corr[i,j],Common_new_steps=common))
    d=pd.DataFrame(rows);g=pd.DataFrame(groups)
    d.to_csv(ROOT/'tables/Current_parameter_diagnostics.csv',index=False)
    g.to_csv(ROOT/'tables/Current_matched_walker_groups.csv',index=False)
    pd.DataFrame(correlations).to_csv(ROOT/'tables/Current_within_phase_correlations.csv',index=False)
    snapshot=ROOT/'tables/progress';snapshot.mkdir(exist_ok=True)
    d.to_csv(snapshot/f'diagnostics_at_{round(elapsed):05d}s.csv',index=False)
    summary=[]
    for (ph,label),r in d.groupby(['Phase','Comparison'],sort=False):
        summary.append(dict(Phase=ph,Comparison=label,Time_steps=int(r.Raw_time_steps.iloc[0]),Fixed_discard=int(r.Fixed_discard_steps.iloc[0]),
            Retained_steps=int(r.Retained_time_steps.iloc[0]),Worst_Rhat=float(r.Rhat_max.max()) if r.Rhat_max.notna().any() else None,
            Minimum_bulk_ESS=float(r.ESS_bulk_min.min()) if r.ESS_bulk_min.notna().any() else None,
            All_parameter_criteria_met=bool(r.Criteria_met.all()),Status=r.Status.iloc[0]))
    out=dict(Final=final,Elapsed_seconds=elapsed,Summary=summary,Actual_new_steps_per_ensemble=[dict(Phase=r['Phase'],Ensemble=r['Ensemble'],Steps=r['New_steps']) for r in counts])
    dump(ROOT/'verification/CURRENT_DIAGNOSTICS.json',out)
    if final:
        np.savez_compressed(ROOT/'runs/ANALYSIS_ARRAYS.npz',**chainmap)
        d.to_csv(ROOT/'tables/Final_parameter_diagnostics.csv',index=False);g.to_csv(ROOT/'tables/Final_matched_walker_groups.csv',index=False)
        pd.DataFrame(correlations).to_csv(ROOT/'tables/Final_within_phase_correlations.csv',index=False)
        with pd.ExcelWriter(ROOT/'tables/Timed_MCMC_2021_validation.xlsx',engine='openpyxl') as w:
            for name in ['Final_parameter_diagnostics','Final_matched_walker_groups','Final_within_phase_correlations','Fixed_center_parameter_likelihood_slices','WP_HI_fixed_center_likelihood_grid','Subday_senescence_mechanism_check']:
                p=ROOT/'tables'/f'{name}.csv'
                if p.exists():pd.read_csv(p).to_excel(w,sheet_name=name[:31],index=False)
        from export_raw_draws import main as export_all_new_draws
        export_all_new_draws()
    print(json.dumps(out,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');main(p.parse_args().final)
