"""Export every actually generated state, separately for the two stages."""
import json
import numpy as np
import pandas as pd
from experiment_engine import ROOT
def main():
    counts={}
    for ph in ['phase1','phase2']:
        frames=[]
        for e in range(1,5):
            with np.load(ROOT/'runs'/ph/f'ensemble_{e}_extension.npz',allow_pickle=False) as z:
                h=z['history'];lp=z['logs'];a=z['accepted'];c=json.loads(z['contract'].item())
                t,w,d=h.shape;f=pd.DataFrame(h.reshape(-1,d),columns=c['Original_contract']['names'])
                f.insert(0,'Walker_index',np.tile(np.arange(w),t));f.insert(0,'Iteration_1based',np.repeat(np.arange(t)+c['Base_steps']+1,w))
                f.insert(0,'New_step_zero_based',np.repeat(np.arange(t),w));f.insert(0,'Ensemble',e)
                f['Log_posterior']=lp.ravel();f['Accepted']=a.ravel();frames.append(f)
        combined=pd.concat(frames,ignore_index=True);counts[ph]=len(combined)
        combined.to_csv(ROOT/'tables'/f'{ph}_ALL_actual_new_draws.csv.gz',index=False,compression={'method':'gzip','compresslevel':6})
    completion=json.loads((ROOT/'verification/TRIAL_COMPLETION.json').read_text());assert sum(counts.values())==completion['Total_new_stored_states']
    (ROOT/'verification/RAW_EXPORT_COUNTS.json').write_text(json.dumps(counts,indent=2),encoding='utf-8')
    print('All actual new states exported:',counts)
if __name__=='__main__':main()
