"""Write the completed timed-trial results without promising convergence."""
from pathlib import Path
import json,datetime
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
import fitz
from docx import Document
from docx.shared import Cm,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parents[1]
def load(n):return pd.read_csv(ROOT/'tables'/f'{n}.csv')
def font(r,size=10.5,bold=False):
    r.font.name='Noto Serif CJK SC';r.font.size=Pt(size);r.bold=bold;r._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC');return r
def para(d,s,size=10.5,bold=False,keep=False):
    p=d.add_paragraph();p.paragraph_format.space_after=Pt(6);p.paragraph_format.line_spacing=1.25;p.paragraph_format.keep_with_next=keep;font(p.add_run(s),size,bold);return p
def head(d,s):
    p=d.add_paragraph(style='Heading 1');p.paragraph_format.space_before=Pt(9);font(p.add_run(s),13,True)
def table(d,title,heads,rows):
    para(d,title,10,True,True);t=d.add_table(rows=1,cols=len(heads))
    for c,s in zip(t.rows[0].cells,heads):c.text=str(s)
    for row in rows:
        for c,s in zip(t.add_row().cells,row):c.text=str(s)
    bs=OxmlElement('w:tblBorders')
    for edge in ['top','bottom','left','right','insideH','insideV']:
        b=OxmlElement('w:'+edge);b.set(qn('w:val'),'single' if edge in ['top','bottom'] else 'nil');b.set(qn('w:sz'),'8');bs.append(b)
    t._tbl.tblPr.append(bs)
    for i,row in enumerate(t.rows):
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        if i==0:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        for c in row.cells:
            if i==0:
                bs=OxmlElement('w:tcBorders');b=OxmlElement('w:bottom');b.set(qn('w:val'),'single');b.set(qn('w:sz'),'5');bs.append(b);c._tc.get_or_add_tcPr().append(bs)
            for p in c.paragraphs:
                p.paragraph_format.space_after=Pt(3)
                for r in p.runs:font(r,8.5,i==0)
def figure(d,stem,num,cn,cap):
    p=d.add_paragraph();p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(ROOT/'figures'/f'{stem}.png'),width=Cm(16.5))
    p=para(d,f'Figure {num}. {cap[stem]}',9);p.paragraph_format.keep_together=True
    para(d,'解析：'+cn,10)

def main():
    completion=json.loads((ROOT/'verification/TRIAL_COMPLETION.json').read_text())
    design=json.loads((ROOT/'verification/TRIAL_DESIGN.json').read_text());df=load('Final_parameter_diagnostics')
    cap=json.loads((ROOT/'figures/FIGURE_CAPTIONS_EN.json').read_text());profile=load('Fixed_center_parameter_likelihood_slices')
    fits=load('Center_fit_comparison');old=df.query('Phase=="phase1" and Comparison=="Original_2000"');new=df.query('Phase=="phase1" and Comparison=="Extended_original_target"')
    p2=df.query('Phase=="phase2" and Comparison=="Four_independent_conditional_new_segments"')
    oldrh=float(old.Rhat_max.max());newrh=float(new.Rhat_max.max());olde=float(old.ESS_bulk_min.min());newe=float(new.ESS_bulk_min.min())
    shifts=old[['Parameter','Mean','SD']].merge(new[['Parameter','Mean']],on='Parameter',suffixes=('_original','_extended'))
    shifts['Center_shift_in_original_SD']=(shifts.Mean_extended-shifts.Mean_original)/shifts.SD
    shifts.to_csv(ROOT/'tables/Phase1_center_shifts.csv',index=False)
    maxshift=float(shifts.Center_shift_in_original_SD.abs().max())
    n=int(new.Raw_time_steps.iloc[0]);p2n=int(p2.Raw_time_steps.iloc[0]) if len(p2) else 0
    llrange={k:float(g.Log_likelihood.max()-g.Log_likelihood.min()) for k,g in profile.groupby('Parameter')}
    start=datetime.datetime.fromtimestamp(completion['Start_epoch'],ZoneInfo('Asia/Shanghai'));end=datetime.datetime.fromtimestamp(completion['End_epoch'],ZoneInfo('Asia/Shanghai'))
    p2rh=float(p2.Rhat_max.max()) if len(p2) else None;p2ess=float(p2.ESS_bulk_min.min()) if len(p2) else None
    p2text=f'四组新共同段每组{p2n}步，丢弃239步后保留{p2n-239}步；最差R̂={p2rh:.3f}，最小组内bulk ESS={p2ess:.1f}。' if p2rh is not None else '新共同段尚短，不能完成预设丢弃段后的独立链诊断。'
    result=dict(Year=2021,Original_phase1_worst_Rhat=oldrh,Extended_phase1_worst_Rhat=newrh,
        Original_phase1_minimum_group_bulk_ESS=olde,Extended_phase1_minimum_group_bulk_ESS=newe,
        Phase1_common_total_steps=n,Phase2_common_new_steps=p2n,Phase2_worst_Rhat=p2rh,Phase2_minimum_group_bulk_ESS=p2ess,
        Phase1_all_strict_criteria_met=bool(new.Criteria_met.all()),Phase2_all_strict_criteria_met=bool(p2.Criteria_met.all()) if len(p2) else False,
        CDC_fixed_center_data_loglike_range=llrange['CDC_CD'],Actual_sampling_wall_seconds=completion['Actual_wall_seconds'],
        Stored_new_states=completion['Total_new_stored_states'],Worker_model_calls=completion['Total_model_calls_in_workers'],
        Phase1_maximum_absolute_center_shift_in_original_SD=maxshift,
        Physical_or_prior_retuning_performed=False,Unbiasedness_proven=False)
    (ROOT/'RESULT_SUMMARY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    d=Document();sec=d.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=sec.right_margin=Cm(2.1);sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.8)
    for sty in ['Normal','Body Text']:
        d.styles[sty].font.name='Noto Serif CJK SC';d.styles[sty].font.size=Pt(10.5);d.styles[sty]._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC')
    h=sec.header.paragraphs[0];h.alignment=WD_ALIGN_PARAGRAPH.RIGHT;font(h.add_run('URP | 2021 original-target MCMC | 30-minute trial'),8)
    f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER;q=OxmlElement('w:fldSimple');q.set(qn('w:instr'),'PAGE');f._p.append(q)
    d.core_properties.title='2021年原模型半小时MCMC验证试验';d.core_properties.author='URP研究小组'
    para(d,'2021年原模型半小时 MCMC 验证\n链长、后期信息与参数补偿',19,True)
    para(d,f'采样时间（北京时间）：{start:%Y-%m-%d %H:%M:%S}—{end:%H:%M:%S}；实际墙钟{completion["Actual_wall_seconds"]/60:.2f}分钟。',10)
    para(d,f'本轮实际新增{completion["Total_new_stored_states"]:,}行walker状态，采样进程实际前向模型调用{completion["Total_model_calls_in_workers"]:,}次。8组ensemble共享4核配额，采用统一30分钟截止时间，所有实际步数保留。原始资料、代码、链和既有论文均未覆盖。',10.5)
    head(d,'一、试验回答了什么')
    para(d,f'第一阶段在同一目标下，从原2000步延续至{n}个共同时间步。最差R̂由{oldrh:.3f}变为{newrh:.3f}，最小组内bulk ESS由{olde:.1f}变为{newe:.1f}。严格标准是否全部满足：{"是" if new.Criteria_met.all() else "否"}。这说明半小时内的真实变化，不能外推成“只要延长就必然收敛”。',11,True)
    para(d,f'五个阶段一参数的保留样本均值，最大改变为原样本标准差的{maxshift:.3f}倍。均值位置较稳定与严格混合标准未满足可以同时发生；小中心移动不是参数无偏的证明，也不构成尾部或可信区间已可靠的认证。')
    para(d,'第二阶段补了三组独立初始化，并延续原一组，固定原第一阶段交接均值，避免改变条件目标。'+p2text)
    para(d,'第二阶段本轮独立比较使用的是较短的新段，不能把它未通过诊断直接倒推为原2000步条件链已经被证明不收敛。原链缺少独立重复认证与新短链没有充分混合，需要分别陈述。')
    para(d,f'机制切片提供了更直接的补充证据：固定其余参数时，CDC_CD在[0.03,0.12]内的数据对数似然总变化仅{llrange["CDC_CD"]:.3f}；5个连续衰老时间值都映射到第135天，所有每日CC完全相同。它们支持局部弱信息和整日物候响应的解释，但不能量化每种机制对全部未收敛的贡献，也不能证明参数无偏。')
    head(d,'二、保持不变的条件与可复现性')
    para(d,'对应刚才诊断的历史2021年模型：Zmin=0.30m、Zmax=2.30m、MulchPct=75%、fMulch=0，原2.4m土壤剖面、天气、初始水、DI日程、观测误差及先验密度不变；不混入后来1m与fMulch=0.50/0.75/0.85短链。32个walkers和默认emcee提议保持原样。')
    para(d,'阶段一4组从原位置、原似然值、原MT19937状态继续；阶段二原ensemble继续，另3组用不同种子按原6%支持域扰动策略初始化。该初始化靠近原确定性起点，并非刻意广泛覆盖先验，故隐藏模态不能排除。')
    para(d,'原链6个状态的未加速似然重算与存储值完全一致；加速核与原实现的对应似然差为0。另直接调用原采样器重放最初两步，阶段一续链、阶段二续链和一组阶段二新初始化的参数位置、似然与接受记录均逐项完全一致。测试未使用替代响应模型。')
    table(d,'表1 各ensemble的实际计算量',['阶段','组','原步数','新步数','总步数','前向调用','接受率'],
        [[r['Phase'][-1],r['Ensemble'],r['Total_steps']-r['New_steps'],r['New_steps'],r['Total_steps'],r['Counts']['Model_calls'],f"{r['Acceptance']:.1%}"] for r in completion['Results']])
    para(d,'墙钟预算包含进程载入、初始化、采样与存盘；截止时允许当前完整迭代结束。步数并不完全相同。主分析用最短共同新段，全部原始新段仍逐份保存。额外的复现与机制检查计数单列，不冒充新增后验样本。',9)
    head(d,'三、链长试验：哪些指标改变，哪些没有')
    table(d,'表2 第一阶段原链与续链比较',['参数','原R̂','续R̂','原bulk ESS','续bulk ESS','续τ'],
        [[k,f'{old.set_index("Parameter").loc[k,"Rhat_max"]:.3f}',f'{new.set_index("Parameter").loc[k,"Rhat_max"]:.3f}',f'{old.set_index("Parameter").loc[k,"ESS_bulk_min"]:.1f}',f'{new.set_index("Parameter").loc[k,"ESS_bulk_min"]:.1f}',f'{new.set_index("Parameter").loc[k,"Tau_max"]:.1f}'] for k in ['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb']])
    para(d,'沿用原正式标准：每组至少2000个总时间步，秩归一化、折叠、分裂R̂<1.01，bulk/tail ESS≥400，时间长度≥50τ。每个诊断组来自同一walker编号跨四个独立ensemble；32个组相互依赖，ESS不可求和，也不是全部存储行的总ESS。阶段一固定丢弃347步，第二阶段固定丢弃每组新段的前239步；不事后选择能“过关”的窗口。')
    figure(d,'V01_Diagnostic_evolution_EN',1,'指标随时间可上下波动。暂时改善只代表有限样本行为，不意味着已经认证后验。第二阶段只在预设起步段后确有样本时显示结果；起步段过短的时间点不拿来作正式判断。',cap)
    figure(d,'V02_Phase1_before_after_EN',2,f'相同目标下实际共同总长度为{n}步。原与续链按同一丢弃规则比较，不能将有限时间试验的差异解释为估计偏差消失。',cap)
    head(d,'四、弱信息、取整与补偿的独立机制检查')
    para(d,f'固定其他参数的切片中，CDC_CD的数据对数似然范围为{llrange["CDC_CD"]:.3f}，SenescenceCD在125–145天内为{llrange["SenescenceCD"]:.3f}；这与原CDC_CD分布接近先验宽度相一致。这里没有优化其余干扰参数，因此应称“固定中心似然切片”，不能当成剖面优化似然、全局不可辨识证明或参数真值估计。CCx只检查0.90–0.99，未扫完整0.60–0.99支持域。')
    figure(d,'V03_Likelihood_slices_EN',3,'数据似然与后验曲线分别平移到各自最大值。CDC_CD的数据曲线较平，而先验项仍能约束后验形状；衰老日切片具有与代码取整一致的台阶结构。',cap)
    para(d,'WP_late–HI0的21×21网格固定WP_early为原保留均值、阶段一为原交接值；只在原支持域内评价。若等高线形成倾斜脊，与新条件样本的负相关共同支持“部分参数可互相补偿”的解释。这不是新的优化前沿，也未把生物量和产量观测换成新目标。')
    figure(d,'V04_WP_HI_compensation_EN',4,'左侧由真实原模型逐点评价；右侧是新增条件链的经验密度。样本仍有限，其相关系数不附加独立样本显著性检验，也不等同于已收敛后验相关。',cap)
    figure(d,'V05_Boundary_and_rounding_checks_EN',5,'检查边界邻域是否在同一目标下持续存在。整日物候检查中，模型响应完全相同，但连续正态先验项仍随参数变化；确认机制不等于确认它是主要数值瓶颈。',cap)
    head(d,'五、拟合会不会因此明显改变')
    para(d,'分别检查三种确定性中心组合：原两阶段中心；仅更新阶段一均值而固定旧阶段二中心；仅更新条件阶段二均值而固定原阶段一均值。后两者用于隔离影响，并不组成经过完整不确定性传播的八维联合后验。')
    table(d,'表3 中心预测的校准对照',['中心组合','CC R²','CC RMSE','Y13(t/ha)','相对观测差'],
        [[r.Case.replace('Original_centers','原中心').replace('Extended_phase1_center_old_phase2','只更新阶段一').replace('Original_phase1_new_conditional_phase2','只更新条件阶段二'),f'{r.CC_R2:.4f}',f'{r.CC_RMSE:.4f}',f'{r.Y_13pct:.3f}',f'{r.Yield_difference_pct:+.2f}%'] for r in fits.itertuples()])
    figure(d,'V06_CC_and_yield_center_fits_EN',6,'拟合较好与后验收敛是不同的检查。这里的CC、生物量与产量仍是参与校准的数据，不属于独立田间验证；中心变化也不代表参数有偏或无偏。',cap)
    head(d,'六、可以得出的结论与下一步')
    para(d,'已直接验证：原模型及旧状态可以复现；续链与新初始化符合原采样器；局部CDC_CD数据方向弱、整日衰老机制确实存在；新增独立条件ensemble提供了原第二阶段所缺的跨链检查。')
    para(d,f'尚未认证：第一阶段严格收敛={bool(new.Criteria_met.all())}，第二阶段严格收敛={bool(p2.Criteria_met.all()) if len(p2) else False}。若仍未通过，这个半小时试验只能说明预算内尚未解决，不证明无限延链必然有效或必然无效；也不能据此证明参数无偏、真实生理值正确或田间减灌方案可靠。',11,True)
    para(d,'如继续，应先按同一目标保留并延续独立链，充分观察慢方向、尾部与ESS，再决定是否有必要处理物候参数化、观测误差或物理结构。参数域不应只为让诊断通过而改动。阶段二最终正式推断还需传播阶段一不确定性；本轮为隔离问题，特意固定了原交接值。')
    head(d,'方法参考')
    for ref in ['Vehtari A, et al. 2021. Rank-normalization, folding, and localization: An improved R-hat for assessing convergence of MCMC. Bayesian Analysis 16(2):667–718. doi:10.1214/20-BA1221.',
                'Foreman-Mackey D, et al. 2013. emcee: The MCMC Hammer. PASP 125:306–312. doi:10.1086/670067.',
                'ArviZ 0.22.0: arviz.rhat and arviz.ess; emcee 3.1.6 integrated autocorrelation diagnostics. Actual versions and input hashes are archived.']:
        para(d,ref,9)
    d.save(ROOT/'docs/URP_2021_30min_MCMC_Validation_CN.docx')
    pdf=fitz.open()
    for k in sorted(cap):
        with fitz.open(ROOT/'figures'/f'{k}.pdf') as src:pdf.insert_pdf(src)
    pdf.save(ROOT/'docs/English_Figure_Atlas.pdf',garbage=4,deflate=True)
    md=['# 2021年原模型半小时验证','',f'实际采样墙钟：{completion["Actual_wall_seconds"]/60:.2f}分钟；新增状态：{completion["Total_new_stored_states"]:,}。','',
        f'第一阶段：2000→{n}共同步，最差R̂ {oldrh:.3f}→{newrh:.3f}，最小组内bulk ESS {olde:.1f}→{newe:.1f}。','',
        '第二阶段：'+p2text,'',f'固定中心CDC_CD数据对数似然变化范围={llrange["CDC_CD"]:.3f}；5个同整数日的衰老输入得到完全相同的每日CC。','',
        '未改模型、支持域、先验密度或观测权重。原fMulch=0、Zmax=2.3m；不混入后期1m/覆膜短链。','',
        '原第二阶段只有一独立ensemble；本轮补三组并固定原交接值。两阶段不拼成八维后验，不作无偏性证明。']
    (ROOT/'docs/RESULTS_CN.md').write_text('\n'.join(md),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
