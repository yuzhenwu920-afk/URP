"""English diagnostics plots from the completed thirty-minute experiment."""
from pathlib import Path
import json,os
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
COLORS=['#0072B2','#D55E00','#009E73','#A45A9F']
P1=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb'];P2=['WP_early','WP_late','HI0']
LABEL={'CCx':r'$CC_x$','CGC_CD':r'$CGC_{CD}$','CDC_CD':r'$CDC_{CD}$','SenescenceCD':r'$Senescence_{CD}$','Kcb':r'$K_{cb}$','WP_early':r'$WP_{early}$','WP_late':r'$WP_{late}$','HI0':r'$HI_0$'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':12,'axes.labelsize':11.5,
 'xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':9.5,'axes.spines.top':False,'axes.spines.right':False,
 'grid.alpha':.22,'grid.color':'#b8c5cd','pdf.fonttype':42})
CAP={}
def tab(n):return pd.read_csv(ROOT/'tables'/f'{n}.csv')
def save(f,name,caption):
    f.savefig(ROOT/'figures'/f'{name}.png',dpi=320,bbox_inches='tight',facecolor='white')
    f.savefig(ROOT/'figures'/f'{name}.pdf',bbox_inches='tight',facecolor='white');plt.close(f);CAP[name]=caption
def grid(a):a.grid(True,linewidth=.7);a.set_axisbelow(True)
def foot(f,s):f.text(.5,.01,s,ha='center',va='bottom',fontsize=9,color='#405561')

def plot_progress():
    allframes=[pd.read_csv(p) for p in sorted((ROOT/'tables/progress').glob('diagnostics*.csv'))]
    d=pd.concat(allframes,ignore_index=True);d=d.drop_duplicates(['Phase','Comparison','Parameter','Elapsed_seconds'])
    f,axs=plt.subplots(2,2,figsize=(11.5,8));f.subplots_adjust(top=.9,bottom=.12,hspace=.38,wspace=.3)
    for col,(ph,names,label) in enumerate([('phase1',P1,'Phase 1: original chains extended'),('phase2',P2,'Phase 2: four conditional ensembles')]):
        z=d[(d.Phase==ph)&(d.Comparison!='Original_2000')&(d.Retained_time_steps>=100)]
        for j,k in enumerate(names):
            r=z[z.Parameter==k].sort_values('Elapsed_seconds');color=plt.cm.tab10(j)
            for row,metric in enumerate(['Rhat_max','ESS_bulk_min']):
                axs[row,col].plot(r.Elapsed_seconds/60,r[metric],marker='o',ms=3.5,lw=1.4,color=color,label=LABEL[k])
        axs[0,col].axhline(1.01,ls='--',color='#4c606a',lw=1);axs[0,col].set_title(label);axs[0,col].set_ylabel('Worst matched-group rank R-hat')
        axs[1,col].axhline(400,ls='--',color='#4c606a',lw=1);axs[1,col].set(ylabel='Minimum matched-group bulk ESS',xlabel='Elapsed sampling wall time (min)')
        axs[1,col].set_yscale('log');axs[0,col].legend(ncol=2,fontsize=8.5,loc='upper right')
        for a in axs[:,col]:a.set_xlim(0,31);grid(a)
    f.suptitle('2021 unchanged-target MCMC: diagnostic evolution during a 30-minute trial',fontsize=15)
    foot(f,'Fixed discards: phase 1 = 347; phase 2 NEW segments = 239. Only windows with at least 100 retained steps are plotted.')
    save(f,'V01_Diagnostic_evolution_EN','Rank-normalized folded split R-hat and bulk ESS over wall-clock time. Each matched-walker group compares four independent ensembles; minima/maxima over 32 dependent groups are shown and ESS is not summed. Phase 1 appends an equal-length common extension to the original 2000 steps and keeps burn-in 347. Phase 2 uses common new segments with discard 239; it is conditional on the unchanged original phase-1 handoff. Short windows do not establish convergence, and diagnostics need not improve monotonically.')

def plot_final_comparison():
    d=tab('Final_parameter_diagnostics');f,axs=plt.subplots(1,2,figsize=(11.5,4.7));f.subplots_adjust(top=.82,bottom=.24,wspace=.3)
    b=d.query('Phase=="phase1" and Comparison=="Original_2000"').set_index('Parameter').loc[P1]
    a=d.query('Phase=="phase1" and Comparison=="Extended_original_target"').set_index('Parameter').loc[P1]
    x=np.arange(5)
    for ax,metric,title in [(axs[0],'Rhat_max','(a) Rank R-hat'),(axs[1],'ESS_bulk_min','(b) Bulk effective sample size')]:
        ax.plot(x,b[metric],color='#7f929e',marker='s',ls='--',label='Original 2000 steps')
        ax.plot(x,a[metric],color=COLORS[0],marker='o',label=f'Extended to {int(a.Raw_time_steps.iloc[0])} common steps')
        ax.set(xticks=x,xticklabels=[LABEL[k] for k in P1],title=title);ax.tick_params(axis='x',rotation=22);grid(ax)
        ax.axhline(1.01 if metric=='Rhat_max' else 400,color='#5a6871',ls=':',lw=1)
    axs[1].set_yscale('log');axs[0].legend(loc='upper right',fontsize=8.5)
    f.suptitle('2021 phase 1: before and after a fixed-target continuation',fontsize=15)
    foot(f,'Same original 32 walkers, priors, physical settings and burn-in. Every comparison uses the shortest complete common continuation.')
    save(f,'V02_Phase1_before_after_EN','Original and extended phase-1 diagnostics using the same original target, 32 walkers and burn-in 347. Unequal worker run lengths are truncated only for equal-length analysis; every actual state is retained in its checkpoint. Any reduction in R-hat or increase in ESS is evidence about finite sampling behavior, not proof of an unbiased physical parameter estimator.')

def plot_slices():
    d=tab('Fixed_center_parameter_likelihood_slices');f,axs=plt.subplots(2,2,figsize=(10.6,7.3));f.subplots_adjust(top=.87,bottom=.13,hspace=.35,wspace=.29)
    for ax,k in zip(axs.ravel(),['CDC_CD','SenescenceCD','Kcb','CCx']):
        z=d[d.Parameter==k];ax.plot(z.Value,z.Log_likelihood-z.Log_likelihood.max(),color=COLORS[0],lw=2,label='Data log likelihood')
        ax.plot(z.Value,z.Log_posterior-z.Log_posterior.max(),color=COLORS[1],ls='--',lw=1.5,label='Log posterior')
        ax.set(xlabel=LABEL[k],ylabel='Shifted log score',title=LABEL[k]);grid(ax)
        if k=='CDC_CD':ax.legend(loc='lower center',fontsize=9)
    f.suptitle('2021 fixed-center score slices: limited late-season data information',fontsize=15)
    foot(f,'Other parameters are fixed. Each curve is shifted to its own maximum; this is not nuisance-optimized profile likelihood.')
    save(f,'V03_Likelihood_slices_EN','Conditional likelihood slices under the unchanged original model, holding other parameters at the original phase-1 retained mean and keeping the original target. CDC_CD, SenescenceCD and Kcb span their stated grids; CCx is examined only over 0.90–0.99, a subset of its 0.60–0.99 support. The data-likelihood and posterior curves are separately shifted to their own maxima. A weak fixed-center slice supports limited information locally but is not a global identifiability proof.')

def plot_compensation():
    d=tab('WP_HI_fixed_center_likelihood_grid');x=np.sort(d.WP_late.unique());y=np.sort(d.HI0.unique());a=d.pivot(index='HI0',columns='WP_late',values='Log_likelihood').loc[y,x].to_numpy();a-=a.max()
    f,axs=plt.subplots(1,2,figsize=(11,4.8));f.subplots_adjust(top=.86,bottom=.2,wspace=.3)
    c=axs[0].contourf(x,y,a,levels=[-25,-15,-10,-6,-3,-1.5,-.5,0],cmap='Blues_r',extend='min');axs[0].contour(x,y,a,levels=[-6,-3,-1.5,-.5],colors='#45606d',linewidths=.7)
    f.colorbar(c,ax=axs[0],label='Data log likelihood minus grid maximum',shrink=.85)
    axs[0].set(xlabel=LABEL['WP_late'],ylabel=LABEL['HI0'],title='(a) Fixed-center conditional likelihood ridge')
    with np.load(ROOT/'runs/ANALYSIS_ARRAYS.npz') as z:
        s=z['phase2_analysis'][:,239:].reshape(-1,3) if z['phase2_analysis'].shape[1]>239 else np.empty((0,3))
    if len(s):
        axs[1].hexbin(s[::3,1],s[::3,2],gridsize=35,mincnt=1,cmap='Blues');corr=np.corrcoef(s.T)[1,2];axs[1].set_title(f'(b) New conditional samples | r = {corr:.3f}')
    axs[1].set(xlabel=LABEL['WP_late'],ylabel=LABEL['HI0']);grid(axs[1])
    f.suptitle('2021 phase 2: late productivity and harvest-index compensation',fontsize=15)
    foot(f,'The original phase-1 mean is fixed in all four ensembles. New-sample density is empirical and not certified as a converged posterior.')
    save(f,'V04_WP_HI_compensation_EN','A 21x21 conditional likelihood grid fixes WP_early at its original retained mean and leaves the phase-1 handoff unchanged. The right panel uses all retained common new phase-2 segments, with a deterministic plotting stride of three. Its Pearson correlation uses all retained rows. Likelihood contours and sampled dependence test the compensation mechanism without refitting or changing parameter supports.')

def plot_boundaries_and_rounding():
    d=tab('Final_parameter_diagnostics');f,axs=plt.subplots(1,2,figsize=(11,4.8));f.subplots_adjust(top=.85,bottom=.24,wspace=.34)
    chosen=[('phase1','CCx','upper'),('phase1','CDC_CD','lower'),('phase2','WP_early','lower'),('phase2','HI0','upper')]
    for j,(ph,k,edge) in enumerate(chosen):
        z=d[(d.Phase==ph)&(d.Parameter==k)];old=z[z.Comparison=='Original_2000'].iloc[0];new=z[z.Comparison!='Original_2000']
        col='Lower_1pct_mass' if edge=='lower' else 'Upper_1pct_mass'
        axs[0].bar(j-.17,old[col]*100,.3,color='#8c9da7',label='Original' if j==0 else None)
        if len(new):axs[0].bar(j+.17,new.iloc[0][col]*100,.3,color=COLORS[0],label='Trial' if j==0 else None)
    axs[0].set(xticks=range(4),xticklabels=[r'$CC_x$ upper',r'$CDC_{CD}$ lower',r'$WP_{early}$ lower',r'$HI_0$ upper'],ylabel='Mass in 1% support band (%)',title='(a) Selected boundary neighborhoods');axs[0].tick_params(axis='x',rotation=22);axs[0].legend();grid(axs[0])
    r=tab('Subday_senescence_mechanism_check');axs[1].plot(r.SenescenceCD_continuous,r.Y13,color=COLORS[2],marker='o',lw=2)
    axs[1].set(xlabel=r'Continuous $Senescence_{CD}$ input (days)',ylabel=r'Simulated grain yield (t ha$^{-1}$)',title='(b) Five inputs, one rounded phenological day');axs[1].ticklabel_format(axis='y',style='plain',useOffset=False);grid(axs[1])
    f.suptitle('2021 mechanism checks: boundary mass and integer-day senescence',fontsize=15)
    foot(f,'Boundary masses are descriptive, from phase-specific correlated samples. Integer rounding changes model responses, not the continuous prior.')
    save(f,'V05_Boundary_and_rounding_checks_EN','Selected original and trial boundary-band masses remain tied to each parameter\'s recorded support. Phase-1 trial samples include the original prefix; phase-2 trial samples use the common new windows after discard 239, so comparisons have different precision. Five SenescenceCD inputs from 134.55 to 135.35 all round to day135; their full daily CC trajectories are identical. The Gaussian prior term can still vary within the bin. This confirms the implementation mechanism but does not quantify its share of convergence failure.')

def plot_fits():
    d=tab('Center_fit_comparison');c=tab('Center_CC_pairs');f,axs=plt.subplots(1,2,figsize=(11,4.8));f.subplots_adjust(top=.84,bottom=.26,wspace=.3)
    styles=[('Original_centers','Original centers',COLORS[0]),('Extended_phase1_center_old_phase2','Extended phase-1 center',COLORS[1]),('Original_phase1_new_conditional_phase2','New conditional phase-2 center',COLORS[2])]
    for name,label,color in styles:
        p=ROOT/'tables'/f'{name}_daily_growth.csv'
        if p.exists():
            g=pd.read_csv(p);axs[0].plot(pd.to_datetime(g.Date),g.canopy_cover,color=color,label=label,lw=1.6)
    obs=c[c.Case.eq('Original_centers')];axs[0].scatter(pd.to_datetime(obs.Date),obs.Observed_CC,facecolors='white',edgecolors='#304e5a',s=35,zorder=4,label='Observed DI CC')
    import matplotlib.dates as mdates
    axs[0].xaxis.set_major_locator(mdates.MonthLocator());axs[0].xaxis.set_major_formatter(mdates.DateFormatter('%b'));axs[0].set(ylabel='Canopy cover (fraction)',title='(a) Deterministic center calibration fits');grid(axs[0])
    for i,(name,label,color) in enumerate(styles):
        z=d[d.Case.eq(name)]
        if len(z):axs[1].bar(i,z.Y_13pct.iloc[0],color=color,width=.58);axs[1].text(i,z.Y_13pct.iloc[0]+.07,f'{z.Y_13pct.iloc[0]:.3f}',ha='center')
    axs[1].axhline(d.Observed_Y13.iloc[0],ls='--',color='#344b57',label='Observed yield');axs[1].set(xticks=range(3),xticklabels=['Original','Extended P1','New P2 conditional'],ylabel=r'Yield at 13% moisture (t ha$^{-1}$)',title='(b) In-sample yield agreement',ylim=(0,18));axs[1].tick_params(axis='x',rotation=15);axs[1].legend(loc='upper right',fontsize=9);grid(axs[1])
    h,l=axs[0].get_legend_handles_labels();f.legend(h,l,loc='lower center',bbox_to_anchor=(.5,.055),ncol=2,frameon=False,fontsize=9)
    f.suptitle('2021 calibration fit checks after the unchanged-target trial',fontsize=15)
    foot(f,'Center predictions are deterministic checks, not posterior predictive bands or independent field validation.')
    save(f,'V06_CC_and_yield_center_fits_EN','Original center predictions are compared with two controlled alternatives: extended phase-1 means holding the old phase-2 center, and new conditional phase-2 means holding the original phase-1 center. These are deterministic combinations of stage-specific centers, not sampled eight-dimensional joint draws. Observations were used for calibration; close fit does not establish convergence, unbiasedness or out-of-sample accuracy.')

def main():
    plot_progress();plot_final_comparison();plot_slices();plot_compensation();plot_boundaries_and_rounding();plot_fits()
    (ROOT/'figures/FIGURE_CAPTIONS_EN.json').write_text(json.dumps(CAP,indent=2),encoding='utf-8');print('Six English PNG + PDF diagnostic groups written.')
if __name__=='__main__':main()
