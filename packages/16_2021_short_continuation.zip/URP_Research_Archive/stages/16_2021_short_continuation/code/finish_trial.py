"""Wait for the timed sampler to finish, then export factual results."""
from pathlib import Path
import os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
while not (ROOT/'verification/TRIAL_COMPLETION.json').exists():time.sleep(10)
for name,args in [('analyze_trial.py',['--final']),('export_fit_checks.py',[]),('make_outputs.py',[]),('build_report.py',[])]:
    print('BUILD',name,flush=True)
    subprocess.run([sys.executable,str(ROOT/'code'/name),*args],check=True)
env=os.environ.copy();env['XDG_CACHE_HOME']=str(ROOT/'.cache');Path(env['XDG_CACHE_HOME']).mkdir(exist_ok=True)
subprocess.run(['soffice','-env:UserInstallation=file:///tmp/urp2021_timedtrial_lo_20261022','--headless','--convert-to','pdf','--outdir',str(ROOT/'docs'),str(ROOT/'docs/URP_2021_30min_MCMC_Validation_CN.docx')],env=env,check=True)
subprocess.run([sys.executable,str(ROOT/'code/verify_results.py')],check=True)
print('POSTPROCESS_COMPLETE',flush=True)
