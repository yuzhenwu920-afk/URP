"""Thirty-minute, unchanged-target experiment; original checkpoints are read-only.

Phase 1: exact-RNG continuation of four original 2000 x 32 ensembles.
Phase 2: exact-RNG continuation of the one original ensemble + three new,
independently seeded ensembles, with the ORIGINAL phase-1 mean fixed throughout.
The target and prior are not retuned to improve convergence diagnostics.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import argparse,contextlib,datetime,hashlib,json,multiprocessing as mp,os,sys,time
import numpy as np
import emcee
from experiment_engine import ROOT,load,checkpoint,verify_contract,dump

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def worker(task):
    ph,e,deadline,start_epoch=task
    out=ROOT/'runs'/ph;out.mkdir(exist_ok=True,parents=True)
    with (out/f'ensemble_{e}.log').open('w',buffering=1) as f,contextlib.redirect_stdout(f),contextlib.redirect_stderr(f):
        _,m,data,start=load(True,f'{ph}_{e}')
        original_path=checkpoint(ph,e if ph=='phase1' else 1)
        with np.load(original_path,allow_pickle=False) as z:
            c=json.loads(z['contract'].item());verify_contract(m,data,c)
            x0=z['position'].copy();lp0=z['logp'].copy();old_rng=str(z['rng_state'].item())
        counts=dict(Logp_queries=0,Model_calls=0,Out_of_support_queries=0)
        simulate=m.simulate
        def counted_sim(*args,**kwargs):
            counts['Model_calls']+=1
            return simulate(*args,**kwargs)
        m.simulate=counted_sim
        names=c['names'];fixed=c['fixed'];bounds=np.array([c['priors'][k] for k in names]);low,high=bounds.T
        def logp(v):
            counts['Logp_queries']+=1
            if np.any(v<low) or np.any(v>high):counts['Out_of_support_queries']+=1
            return m.logprob(v,names,fixed,c['phase'],data)
        resumed=ph=='phase1' or e==1
        if resumed:
            # Re-evaluate one terminal state and reuse the exact stored RNG and
            # log-posterior vector, after the shared preflight reproduction.
            j=int(np.argmax(lp0));actual=logp(x0[j]);assert abs(actual-lp0[j])<1e-8
            rng=sys.modules['_di_2021_sampler'].decode_rng(old_rng)
            state=emcee.State(x0,log_prob=lp0,random_state=rng)
            base_steps=2000
            init_kind='Exact original terminal positions/logp/MT19937 continuation'
        else:
            seed=42+2021*100+(e-1)+100000
            random=np.random.RandomState(seed);coords=[];probs=[];attempts=0
            center=np.array([fixed[k] for k in names])
            while len(coords)<32:
                v=center+random.normal(0,.06,len(names))*(high-low);attempts+=1
                if np.any(v<low) or np.any(v>high):continue
                p=logp(v)
                if np.isfinite(p):coords.append(v);probs.append(p)
                if attempts>100000:raise RuntimeError('Initialization failed')
            state=emcee.State(np.array(coords),log_prob=np.array(probs),random_state=random.get_state())
            base_steps=0;init_kind='Original initialization policy, independent seed '+str(seed)
        metadata=dict(Experiment='2021 original-target 30-minute MCMC validation',Phase=ph,Ensemble=e,
            Original_contract=c,Original_checkpoint_SHA256=hashlib.sha256(original_path.read_bytes()).hexdigest(),
            Initialization=init_kind,Base_steps=base_steps,Walkers=32,Start_UTC=utc(),Global_start_epoch=start_epoch,
            Global_deadline_epoch=deadline,Scope='5D phase1 or 3D conditional phase2; no joint 8D posterior',
            Phase2_target='original phase1 retained mean held fixed; not updated from extended phase1',
            Physical_settings=dict(Zmax_m=2.3,Zmin_m=.3,MulchPct=75.,fMulch=0.),Independent_ensembles_this_phase=4)
        dump(out/f'ensemble_{e}_design.json',metadata)
        history=[];logs=[];accepted=[];initial=state.coords.copy();prev=initial.copy()
        sampler=emcee.EnsembleSampler(32,len(names),logp)
        t0=time.monotonic();last_save=t0
        def save(final=False):
            path=out/f'ensemble_{e}_extension.npz';tmp=path.with_suffix('.tmp')
            with tmp.open('wb') as z:
                np.savez_compressed(z,history=np.array(history).reshape(-1,32,len(names)),logs=np.array(logs).reshape(-1,32),
                    accepted=np.array(accepted,bool).reshape(-1,32),position=state.coords,logp=state.log_prob,
                    initial_positions=initial,rng_state=sys.modules['_di_2021_sampler'].encode_rng(state.random_state),
                    original_base_steps=base_steps,contract=json.dumps(metadata,sort_keys=True,allow_nan=False))
            os.replace(tmp,path)
            report=dict(Phase=ph,Ensemble=e,New_steps=len(history),Total_steps=base_steps+len(history),
                Counts=counts.copy(),Elapsed_seconds_since_global_start=time.time()-start_epoch,
                Acceptance=float(np.mean(accepted)) if accepted else None,Final=final,Updated_UTC=utc())
            dump(out/f'ensemble_{e}_status.json',report)
            return report
        while time.time()<deadline:
            # Commit only complete ensemble iterations. At most one iteration
            # extends beyond the common wall-clock deadline.
            state=next(sampler.sample(state,iterations=1,store=False))
            accepted.append(np.any(state.coords!=prev,axis=1));prev=state.coords.copy()
            history.append(prev.copy());logs.append(state.log_prob.copy())
            if len(history)%10==0 or time.monotonic()-last_save>=30:
                save();last_save=time.monotonic()
        result=save(True);print('COMPLETE',json.dumps(result),flush=True);return result

def main(seconds):
    if list((ROOT/'runs').glob('phase*/ensemble_*_extension.npz')):
        raise FileExistsError('Existing timed-trial chains must not be overwritten. Copy inputs to a new experiment directory for a separate run.')
    assert json.loads((ROOT/'verification/PREFLIGHT.json').read_text())['Status']=='PASS'
    start=time.time();deadline=start+seconds
    design=dict(Status='RUNNING',Sampling_budget_seconds=seconds,Start_UTC=utc(),Start_epoch=start,Deadline_epoch=deadline,
        Workers=8,Available_CPU_quota_cores=4,Phases_parallel=True,Ensembles_per_phase=4,Walkers_per_ensemble=32,
        Original_phase1_burn_preserved_for_primary_comparison=347,Phase2_fixed_discard_new_window=239,
        Primary_phase1_analysis='Original 2000-step prefixes plus shortest common continuation; burn 347',
        Primary_phase2_analysis='Shortest common NEW segment across all four independent ensembles; discard first239 of each new segment',
        Original_model_and_priors_unchanged=True,Phase2_original_handoff_frozen=True,
        No_convergence_promise=True,Stop_policy='Complete current iteration at deadline, retain every actual state')
    dump(ROOT/'verification/TRIAL_DESIGN.json',design)
    tasks=[(ph,e,deadline,start) for ph in ['phase1','phase2'] for e in range(1,5)]
    with ProcessPoolExecutor(max_workers=8,mp_context=mp.get_context('spawn')) as pool:
        futures=[pool.submit(worker,t) for t in tasks]
        for future in futures:
            result=future.result();print(json.dumps(result),flush=True)
    results=[json.loads((ROOT/'runs'/ph/f'ensemble_{e}_status.json').read_text()) for ph in ['phase1','phase2'] for e in range(1,5)]
    dump(ROOT/'verification/TRIAL_COMPLETION.json',dict(Status='COMPLETE',Start_epoch=start,End_epoch=time.time(),
        Actual_wall_seconds=time.time()-start,Budget_seconds=seconds,Results=results,
        Total_new_stored_states=sum(r['New_steps']*32 for r in results),
        Total_model_calls_in_workers=sum(r['Counts']['Model_calls'] for r in results),
        Total_logp_queries=sum(r['Counts']['Logp_queries'] for r in results)))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seconds',type=int,default=1800);a=p.parse_args();main(a.seconds)
