"""Scientific provenance and completed-trial integrity checks."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
import fitz
from docx import Document
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    completion=json.loads((ROOT/'verification/TRIAL_COMPLETION.json').read_text())
    assert completion['Status']=='COMPLETE'
    assert 1800<=completion['Actual_wall_seconds']<=1860,completion['Actual_wall_seconds']
    replay=json.loads((ROOT/'verification/EXACT_SAMPLER_REPLAY.json').read_text());assert replay['Status']=='PASS'
    pre=json.loads((ROOT/'verification/PREFLIGHT.json').read_text());assert pre['Status']=='PASS'
    assert max(pre['Acceleration_absolute_logp_differences'])<1e-8
    expected=json.loads((ROOT/'verification/SOURCE_MANIFEST.json').read_text());assert all(sha(ROOT/row['Path'])==row['SHA256'] for row in expected)
    records=[];total=0
    for ph in ['phase1','phase2']:
        for e in range(1,5):
            p=ROOT/'runs'/ph/f'ensemble_{e}_extension.npz'
            with np.load(p,allow_pickle=False) as z:
                h=z['history'];a=z['accepted'];c=json.loads(z['contract'].item());lc=c['Original_contract']
                assert h.shape[1:]==(32,5 if ph=='phase1' else 3)
                assert np.isfinite(h).all() and np.isfinite(z['logs']).all()
                assert len(h)>0 and np.array_equal(z['position'],h[-1]) and np.array_equal(z['logp'],z['logs'][-1])
                lo=np.array([lc['priors'][k][0] for k in lc['names']]);hi=np.array([lc['priors'][k][1] for k in lc['names']])
                assert np.all(h>=lo) and np.all(h<=hi)
                status=json.loads((p.parent/f'ensemble_{e}_status.json').read_text());assert status['Final'] and len(h)==status['New_steps']
                if ph=='phase1' or e==1:
                    with np.load(ROOT/'source/original_checkpoints'/ph/f'ensemble_{e if ph=="phase1" else 1}.npz') as ref:
                        assert np.array_equal(z['initial_positions'],ref['position'])
                total+=len(h)*32
                records.append(dict(Phase=ph,Ensemble=e,New_steps=len(h),SHA256=sha(p),All_finite=True,Inside_original_support=True,Endpoint_matches=True,Final_checkpoint=True))
    assert total==completion['Total_new_stored_states']
    exported=json.loads((ROOT/'verification/RAW_EXPORT_COUNTS.json').read_text())
    assert sum(exported.values())==total
    for ph in ['phase1','phase2']:
        flat=pd.read_csv(ROOT/'tables'/f'{ph}_ALL_actual_new_draws.csv.gz')
        assert len(flat)==exported[ph]
        assert not ({'CCx','HI0'}<=set(flat.columns)), 'Stages must remain separate in the flat exports'
    profiles=json.loads((ROOT/'verification/CONTROLLED_PROFILE_COMPUTATION.json').read_text());assert profiles['Subday_maximum_daily_CC_difference']==0
    d=pd.read_csv(ROOT/'tables/Final_parameter_diagnostics.csv')
    # The original conditional phase2 still has no independent-chain Rhat;
    # newly computed phase2 Rhat is explicitly for four NEW independent runs.
    assert d.query('Phase=="phase2" and Comparison=="Original_2000"').Rhat_max.isna().all()
    assert np.allclose(d.query('Phase=="phase1" and Comparison=="Original_2000"').Rhat_max.max(),1.123921405398829)
    caps=json.loads((ROOT/'figures/FIGURE_CAPTIONS_EN.json').read_text());assert len(caps)==6
    for stem in caps:
        assert (ROOT/'figures'/f'{stem}.png').exists()
        with fitz.open(ROOT/'figures'/f'{stem}.pdf') as p:assert len(p)==1 and p[0].get_text().strip()
    doc=Document(ROOT/'docs/URP_2021_30min_MCMC_Validation_CN.docx');assert len(doc.inline_shapes)==6 and len(doc.tables)==3
    with fitz.open(ROOT/'docs/URP_2021_30min_MCMC_Validation_CN.pdf') as p:
        pages=len(p);assert pages>=5
        assert all('\ufffd' not in page.get_text() for page in p)
    with fitz.open(ROOT/'docs/English_Figure_Atlas.pdf') as p:assert len(p)==6
    out=dict(Status='PASS',Sampling_wall_seconds=completion['Actual_wall_seconds'],Actual_new_states=total,
        Sampling_process_forward_calls=completion['Total_model_calls_in_workers'],
        Additional_controlled_slice_forward_calls=profiles['Counts']['Actual_model_calls'],
        Additional_original_sampler_replay_forward_calls=replay['Counts']['Model_calls'],
        Additional_preflight_forward_calls=30,
        Additional_center_fit_forward_calls=json.loads((ROOT/'verification/CENTER_FIT_CALLS.json').read_text())['Actual_model_calls'],
        Report_pages=pages,English_figure_groups=6,Original_checkpoints_read_only=True,
        All_new_checkpoints=records,Independent_ensembles_each_phase=4,Joint_8D_posterior_constructed=False,
        Priors_or_physics_tuned_to_improve_diagnostics=False,
        Note='QA pass certifies integrity and declared protocol, not posterior convergence')
    recovery=ROOT/'verification/POSTPROCESS_RECOVERY.json'
    out['Additional_forward_calls_in_recovered_export']=json.loads(recovery.read_text())['Additional_forward_calls_in_failed_export'] if recovery.exists() else 0
    out['All_experiment_forward_calls_including_validation']=out['Sampling_process_forward_calls']+sum(v for k,v in out.items() if k.startswith('Additional_') and isinstance(v,int))
    (ROOT/'verification/FINAL_QA.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
