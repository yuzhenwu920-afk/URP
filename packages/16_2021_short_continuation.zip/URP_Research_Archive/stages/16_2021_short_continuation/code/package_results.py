"""Package a new dated supplement; never overwrite prior deliverables."""
from pathlib import Path
import argparse,csv,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
DEFAULT=Path('/workspace/URP/deliverables/2026-10-22-2021-mcmc-30min-validation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main(out):
    assert json.loads((ROOT/'verification/FINAL_QA.json').read_text())['Status']=='PASS'
    out.mkdir(parents=True,exist_ok=True)
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and not any(s in p.parts for s in ['.cache','__pycache__']) and p.name not in ['FILE_MANIFEST.csv','SHA256SUMS.txt'])
    rows=[dict(Path=str(p.relative_to(ROOT)),Bytes=p.stat().st_size,SHA256=sha(p)) for p in files]
    with (ROOT/'FILE_MANIFEST.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['Path','Bytes','SHA256']);w.writeheader();w.writerows(rows)
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(f"{r['SHA256']}  {r['Path']}" for r in rows)+'\n'+sha(ROOT/'FILE_MANIFEST.csv')+'  FILE_MANIFEST.csv\n',encoding='utf-8')
    archive=out/'URP_2021_MCMC_30min_Validation_20261022.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for p in files+[ROOT/'FILE_MANIFEST.csv',ROOT/'SHA256SUMS.txt']:z.write(p,arcname='URP_2021_MCMC_30min_Validation_20261022/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for r in rows:assert hashlib.sha256(z.read('URP_2021_MCMC_30min_Validation_20261022/'+r['Path'])).hexdigest()==r['SHA256']
    assert archive.stat().st_size<95*2**20
    for p in [ROOT/'docs/URP_2021_30min_MCMC_Validation_CN.docx',ROOT/'docs/URP_2021_30min_MCMC_Validation_CN.pdf',ROOT/'docs/English_Figure_Atlas.pdf',
              ROOT/'tables/Timed_MCMC_2021_validation.xlsx',ROOT/'RESULT_SUMMARY.json',ROOT/'docs/RESULTS_CN.md',ROOT/'verification/FINAL_QA.json']:
        shutil.copyfile(p,out/p.name)
    out.joinpath('SHA256SUMS.txt').write_text('\n'.join(f'{sha(p)}  {p.name}' for p in sorted(out.iterdir()) if p.is_file() and p.suffix in ['.zip','.docx','.pdf','.xlsx'])+'\n',encoding='utf-8')
    info=dict(File=archive.name,Bytes=archive.stat().st_size,SHA256=sha(archive),Files=len(files)+2,All_CRC_and_manifest_hashes_pass=True)
    (out/'PACKAGE_VERIFICATION.json').write_text(json.dumps(info,indent=2),encoding='utf-8');print(json.dumps(info,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=DEFAULT);main(p.parse_args().out)
