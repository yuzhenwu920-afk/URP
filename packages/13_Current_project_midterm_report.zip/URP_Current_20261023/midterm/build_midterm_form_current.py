def build():
    # Keep the institution logo and all original cover field labels.
    template=ROOT/'template'/'converted_midterm_template.docx'
    d=Document(template)
    d.core_properties.title='创新训练项目中期报告书（URP研究内容已填写稿）'
    d.core_properties.subject='2019—2022年滴灌玉米；截至2026-10-23的五生育期优化及诊断成果'
    d.core_properties.author='吴雨臻、李承昊、段璞'
    d.core_properties.keywords='中期报告;滴灌玉米;AquaCrop;MCMC;Sobol;NSGA-III'
    sec=d.sections[0];sec.top_margin=Cm(2.1);sec.bottom_margin=Cm(2.0)
    sec.left_margin=Cm(2.15);sec.right_margin=Cm(2.15)
    sec.header_distance=Cm(.8);sec.footer_distance=Cm(.9)
    sec.different_first_page_header_footer=True
    grid=sec._sectPr.find(qn('w:docGrid'))
    if grid is not None:sec._sectPr.remove(grid)
    normal=d.styles['Normal'];normal.font.name=BODY;normal.font.size=Pt(11)
    normal._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),BODY)
    normal.paragraph_format.line_spacing=1.35
    # Replace the old positioned page-number shape with a normal PAGE field.
    for ft in (sec.footer,sec.first_page_footer):
        for e in list(ft._element):ft._element.remove(e)
    p=sec.first_page_footer.add_paragraph('中国农业大学 制表');fmt(p,9,after=0,align=WD_ALIGN_PARAGRAPH.RIGHT)
    p=sec.footer.add_paragraph();fmt(p,9,after=0,align=WD_ALIGN_PARAGRAPH.CENTER)
    r=p.add_run();field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');r._r.addnext(field)
    ps=d.paragraphs
    ps[0].runs[1].text='      '
    ps[0].runs[2].text='项目编号：'+PROJECT_NUMBER
    fmt(ps[0],11,after=8,align=WD_ALIGN_PARAGRAPH.LEFT)
    ps[0].paragraph_format.line_spacing=1.0
    fmt(ps[1],4,after=9,line=1)
    for i in (2,3):
        fmt(ps[i],24,before=4,after=6,line=1.25,align=WD_ALIGN_PARAGRAPH.CENTER)
        for r in ps[i].runs:font_run(r,24,True,True)
    fmt(ps[4],4,after=5,line=1)
    cover=d.tables[0]
    # Remove only the blank remainder of the original form; reconstruct its
    # seven numbered sections below with controlled, readable pagination.
    after=False
    for e in list(d._element.body):
        if e is cover._tbl:after=True;continue
        if after and e.tag!=qn('w:sectPr'):d._element.body.remove(e)
    # Clear floating table placement and scale the original merged grid.
    pr=cover._tbl.tblPr
    for k in ('tblpPr','tblOverlap'):
        e=pr.find(qn('w:'+k))
        if e is not None:pr.remove(e)
    widths=[col.width for col in cover.columns]
    ratio=Cm(16.7)/sum(widths)
    for col,w in zip(cover.columns,widths):col.width=int(w*ratio)
    seen=set()
    for row in cover.rows:
        row.height_rule=WD_ROW_HEIGHT_RULE.AT_LEAST;row.height=Cm(.63)
        for c in row.cells:
            if c._tc in seen:continue
            seen.add(c._tc)
            c.width=int(c.width*ratio);margins(c,60)
            c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    fields={
        (0,2):TITLE,
        (1,2):'2026年', (1,6):'3人',
        (2,2):'吴雨臻', (2,5):'2024321010307', (3,5):'土地科学与技术学院243班',
        (4,2):'17624057163', (4,5):'yuzhenAva@163.com',
        (5,2):'李承昊', (5,5):'2024321010302', (6,5):'土地科学与技术学院243班',
        (7,2):'段璞', (7,5):'2024321010208', (8,5):'土地科学与技术学院242班',
        (9,2):'廖人宽', (9,5):'教授',
        (10,2):'18600795649', (10,5):'renkuanliao@163.com',
        (11,2):'2026年10月23日（请按实际提交日核定）', (13,0):INTRO,
    }
    for (ri,ci),text in fields.items():cover.cell(ri,ci).text=text
    for ri,row in enumerate(cover.rows):
        handled=set()
        for c in row.cells:
            if c._tc in handled:continue
            handled.add(c._tc)
            for p in c.paragraphs:
                fmt(p,10.5,after=0,line=1.25,align=WD_ALIGN_PARAGRAPH.CENTER if ri!=13 else WD_ALIGN_PARAGRAPH.LEFT)
                for r in p.runs:font_run(r,10.5)
        if ri==0:row.height=Cm(1.65)
        if ri==1:row.height=Cm(.9)
        if ri in (11,12):row.height=Cm(.8)
        if ri==13:row.height=Cm(2.25)
    set_borders(cover)
    para(d,'基本信息据立项材料；项目编号与成员分工据项目组补充说明。',9.5,after=0)

    # Page 2: member fields and research progress.
    c=page_box(d)
    small_table(c,['项目组成员','具体分工','个人完成情况及对项目的贡献'],MEMBERS,[3.1,4.1,8.3],10)
    para(c,'成员围绕模型分析、数据可视化和资料整理协作推进，下述为项目整体进展。',9.5,after=6)
    heading(c,'一、项目研究进展情况（研究内容、方法、进度等）')
    block(c,PROGRESS)

    # Page 3: achievements and evidence-backed numbers.
    c=page_box(d)
    heading(c,'二、项目研究已取得阶段性成果和收获（须提供相关证明材料）')
    block(c,RESULTS)
    heading(c,'表1  四年校准拟合指标',11)
    m=pd.read_csv(ROOT/'evidence'/'calibration_metrics_recomputed.csv')
    y=pd.read_csv(ROOT/'evidence'/'observed_yield_gate_headroom.csv').set_index('Year')
    rows=[]
    for year in YEARS:
        cc=m[(m.Year==year)&(m.Variable=='CC')].iloc[0]
        b=m[(m.Year==year)&(m.Variable=='Biomass')].iloc[0]
        rows.append([year,f'{int(cc.N)}/{int(b.N)}',f'{cc.R2:.4f}',f'{cc.RMSE:.4f}',f'{b.R2:.4f}',f'{b.RMSE:.4f}',f'{y.loc[year,"Baseline_bias_pct_vs_observed"]:+.2f}'])
    small_table(c,['年份','配对数\nCC/B','CC\nR²','CC\nRMSE','生物量\nR²','生物量\nRMSE','产量\n误差%'],rows,[1.3,1.8,2.0,2.1,2.1,2.5,2.1],10)
    para(c,'注：B为地上干生物量；CC为比例，生物量RMSE单位为t/ha。R²=1−SSE/SST；产量统一为13%含水率，误差=(模拟−观测)/观测×100%。单年仅一个产量配对，不计算单年产量R²。',9.5,after=7)
    heading(c,'证明材料对应关系',11)
    para(c,'附件1—6展示四年CC、生物量、Sobol、五期前沿、逐次灌水及水量来源。论文图表、逐代种群、逐次查询、日程与日水量账均在本版分阶段归档及统一索引中提供。',10.5,after=5)

    # Page 4: remaining scientific issues and milestone-based plan.
    c=page_box(d)
    heading(c,'三、项目研究存在的主要问题及应对思路与措施')
    block(c,PROBLEMS,10.7,after=6)
    heading(c,'四、项目研究下阶段主要任务及时间进程安排')
    para(c,'主要计算模块已完成，以下安排侧重证据补强、导师审阅、实施条件细化及结题表达，按学校节点核定。',10.5,after=6)
    small_table(c,['相对进程','主要任务','交付与检查'],SCHEDULE,[2.2,7.5,5.8],10)
    para(c,'四年真实模型、敏感性及五期优化均已完成；后续以设备能力、墒情与季末储水要求细化实施方案。',10,after=5)

    # Page 5: financial form and authorized reviewers' own fields.
    c=page_box(d)
    heading(c,'五、项目经费使用情况')
    para(c,'申请预算5000元；已报销经费：____________元。',11,after=8)
    small_table(c,['申请预算科目','预算（元）','实际报销（元）','凭证/日期'],[
        ['文献检索与资料费','500','',''],
        ['遥感数据获取及处理费','2000','',''],
        ['数据存储与打印耗材费','800','',''],
        ['实地考察与调研费','1200','',''],
        ['成果整理及论文发表辅助费','500','',''],
        ['合计','5000','',''],
    ],[6.3,2.2,3.2,3.8],10)
    para(c,'注：预算据立项申请书，不代表核定经费或已发生支出；实际使用清单请依财务凭证核对。',9.5,after=6)
    heading(c,'六、指导教师意见',12.5)
    para(c,'（从研究内容和进展、阶段性成果、存在问题和建议等加以评价）',10.5,after=5)
    para(c,'【请指导教师本人填写意见并签名】',11,after=0)
    p=para(c,'',11,after=0);p.paragraph_format.space_after=Pt(35)
    para(c,'签名：________________        年    月    日',11,after=18,align=WD_ALIGN_PARAGRAPH.RIGHT)
    heading(c,'七、专家组意见',12.5)
    para(c,'【请专家组填写意见并签名】',11,after=0)
    p=para(c,'',11,after=0);p.paragraph_format.space_after=Pt(35)
    para(c,'专家组成员签名：________________',11,after=12,align=WD_ALIGN_PARAGRAPH.RIGHT)
    para(c,'年    月    日',11,after=5,align=WD_ALIGN_PARAGRAPH.RIGHT)

    # Two readable evidence pages: report-specific layouts with four years.
    for kind,title,caption in [
        ('CC','附件1  四年冠层覆盖度校准过程',
         '图1  实线为模型逐日输出，空心点为用于校准的田间LAI换算CC。各面板采用相同坐标范围；2019蓝、2020橙、2021绿、2022紫。R²及RMSE据全部校准配对复算。'),
        ('biomass','附件2  四年地上干生物量校准过程',
         '图2  四年观测与模拟生物量散点，虚线为1:1关系；单位为t/ha，R²cal与RMSE按全部37个配对计算。')]:
        d.add_page_break()
        para(d,title,14,True,after=12,keep=True)
        p=d.add_paragraph();fmt(p,10,after=6,align=WD_ALIGN_PARAGRAPH.CENTER)
        filename='midterm_CC_four_years.png' if kind=='CC' else 'midterm_biomass_four_years.png'
        p.add_run().add_picture(str(ROOT/'figures'/filename),width=Cm(16.5))
        p.paragraph_format.line_spacing=1.0
        p.paragraph_format.keep_with_next=True
        para(d,caption,10.5,after=10)
        para(d,'证据口径：四年原模型中心与源数据均已核对，本图报告校准配对及均值轨迹；采样精度由独立诊断另行量化。',10.5,after=10)
        if kind=='CC':
            heading(d,'来源与检查',11)
            para(d,'四年48个CC配对均有对应日期的模型输出，图件含全部年度。数据来源与数值见本版工作簿及年度模型档案。',11)
        else:
            heading(d,'生物量评价与后续分析',11)
            para(d,'四年37个生物量配对描述主要生长过程。正式Sobol、五期逐次日程优化与水量核算均已完成，结果见后附英文图及中英文稿。',11)
    d.save(ROOT/'URP_midterm_report.docx')

    # Plain text counterpart for direct copying into other administrative forms.
    lines=['# 创新训练项目中期报告书（研究内容已填写稿）','',f'项目名称：{TITLE}',
        f'编号：{PROJECT_NUMBER}；执行期：2026年；负责人：吴雨臻；成员：李承昊、段璞；导师：廖人宽教授。','',f'项目简介（{len(INTRO)}字，含标点）：{INTRO}','',
        '## 项目组成员分工与贡献','']
    for row in MEMBERS:lines += ['：'.join(row),'']
    lines += ['## 一、项目研究进展情况','']
    for h,b in PROGRESS:lines += [h+' '+b,'']
    lines += ['## 二、项目研究已取得阶段性成果和收获','']
    for h,b in RESULTS:lines += [h+' '+b,'']
    lines += ['|年份|CC/B配对数|CC R²|CC RMSE|生物量R²|生物量RMSE t/ha|产量误差%|','|---|---|---|---|---|---|---|']
    lines += ['|'+'|'.join(map(str,r))+'|' for r in rows]
    lines += ['','## 三、项目研究存在的主要问题及应对思路与措施','']
    for h,b in PROBLEMS:lines += [h+' '+b,'']
    lines += ['## 四、项目研究下阶段主要任务及时间进程安排','','对照立项书11—12月成果总结阶段拟定；按学校节点核定日期。','']
    for row in SCHEDULE:lines += ['；'.join(row),'']
    lines += ['## 五、项目经费使用情况','','申请预算5000元（非实报销额）；已报销经费：____________元。实际报销金额、凭证与日期按用户要求留空。','',
        '## 六、指导教师意见','','由指导教师本人填写并签名。','','## 七、专家组意见','','由专家组填写并签名。','',
        '## 附件','','![四年CC](figures/midterm_CC_four_years.png)','','![四年生物量](figures/midterm_biomass_four_years.png)','',
        '四年校准配对和均值轨迹已核对；当前五期优化与水量核算另附证据。']
    (ROOT/'URP_midterm_report_text.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (ROOT/'evidence'/'report_content_checks.json').write_text(json.dumps({'intro_characters':len(INTRO),
        'template_sections_preserved':7,'official_project_title_confirmed':True,
        'MCMC_rerun_in_this_document_update':False,'full_real_Sobol_or_optimization_completed':True,'five_stage_optimization_completed':True,
        'year_coverage':YEARS,'project_number':PROJECT_NUMBER,
        'member_contribution_allocation':'Drafted per user instruction: leader, Li, Duan in descending contribution order; no percentages invented.',
        'admin_fields':'Official information and project number filled; actual reimbursement intentionally blank; reviewer opinions and signatures reserved.'},ensure_ascii=False,indent=2),encoding='utf-8')
