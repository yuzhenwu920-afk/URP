"""Build the filled CAU midterm form and report-sized figures from frozen evidence.

Requires python-docx, numpy, pandas and matplotlib. Conversion of the original
.doc template to .docx, and Word/PDF export, use LibreOffice outside this script.
"""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.mplcache'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT, WD_ROW_HEIGHT_RULE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

YEARS = [2019, 2020, 2021, 2022]
COLORS = {2019:'#0072B2', 2020:'#D55E00', 2021:'#009E73', 2022:'#A85AA0'}
BODY = 'Noto Serif CJK SC'
SANS = 'Noto Sans CJK SC'
TITLE = '基于马尔科夫链的不同灌溉方式灌溉制度优化'
PROJECT_NUMBER = 'X2026100190937'
MEMBERS = [
    ['吴雨臻（组长）','项目统筹、核心模型复核与研究方案设计',
     '统筹四年研究路线与技术衔接，负责分阶段MCMC成果复核、2022模型复现和敏感性及优化方案设计，整合核心结果与报告。'],
    ['李承昊','四年数据处理、拟合指标与图表整理',
     '整理气象、冠层和生物量资料，协助配对核对与拟合指标复算，承担四年图表规范化和结果表整理，支持模型分析。'],
    ['段璞','文献资料、成果归档与报告辅助',
     '协助查阅研究文献、记录资料来源及归档文件，整理阶段性成果证明材料，参与报告文字校对与格式检查。'],
]
INTRO = '面向玉米节水灌溉，融合田间与遥感资料，利用AquaCrop模型和MCMC开展参数校准及不确定性分析，结合敏感性与多情景模拟优化灌溉制度，为提高农业用水效率、保障作物产量提供依据。'
assert len(INTRO) <= 100

PROGRESS = [
    ('1. 研究内容与立项任务衔接', '本项目依托“吐哈盆地农业水资源节水潜力分析”，围绕不同灌溉方式下的玉米灌溉制度优化展开。目前以2019—2022年滴灌（DI）资料为基础，形成“资料整理—分阶段MCMC校准复核—生长与水量评价—Sobol分析—保产节水优化”路线，为后续不同方式情景比较建立可信基准。'),
    ('2. 四年资料整理与质量核查', '已整理四年气象、田间叶面积指数换算的冠层覆盖度（CC）、地上干生物量、年产量、初始土壤水及灌溉资料，统一日期、单位与产量含水率口径。逐点核对CC及生物量配对值与对应日期的逐日模拟输出；2022年补充资料已齐全，18项原模型与支持资料文件哈希均匹配。'),
    ('3. 既有MCMC成果复核', '复核既有两阶段校准：阶段一为CCx、CGC_CD、CDC_CD、SenescenceCD、Kcb，阶段二为WP_early、WP_late、HI0。四年共16组阶段一、4组阶段二记录，32个年度中心值可追溯。实际为每组32个walker、2000步的ensemble采样，与申请书初拟“三链1000步”有所调整，后续按实际方法报告。本轮未重跑MCMC；两阶段样本不能视作八维联合后验。'),
    ('4. 模型复现与下游计算准备', '已接入2022原模型，完成资料预审及冻结均值点回放；2019—2021采用已核验原输出进行四年比较。已明确Sobol八参数独立物理范围、确定性双目标优化及候选条件扰动方案，准备设计矩阵与自动化接口。完整的新真实模型Sobol及NSGA-III实验尚待执行。'),
    ('5. 当前进度与立项计划比较', '对照立项书2—4月资料、5—7月模型、8—10月参数优化、11—12月总结的安排，现阶段已形成四年校准成果及复核材料；遥感动态同化、滴灌与喷灌对照和正式优化结果仍需补充。本阶段训练集中于数据溯源、统计诊断、模型复现和科研表达，后续工作按原定年末成果整理节点推进。'),
]
RESULTS = [
    ('1. 形成可追溯的四年资料与校准证据', '建立四年逐日输出、校准配对表、参数中心与采样来源记录。四年CC共48对、生物量共37对，均可回到对应日期的模型输出复算；遥感CC仅作辅助参照，未将其作为DI处理的独立验证。'),
    ('2. 获得四年生长过程拟合评价', 'CC的R²为0.9306—0.9932，RMSE为0.0316—0.0596；地上干生物量的R²为0.9685—0.9966，RMSE为0.5562—1.2520 t/ha。四年年产量相对误差均在±5%内，最大绝对误差约4.18%。这些结果说明对现有校准资料的拟合较好，仍需独立数据评价泛化能力。'),
    ('3. 完成2022模型数值复现', '冻结中心点回放得到产量14.0778 t/ha、灌水量404.84 mm、季节蒸散596.7846 mm；与原汇总结果的最大差异小于1.5×10⁻¹⁴，季节水量账残差约10⁻¹² mm。这些结果支持计算复现与内部守恒，不代表田间预测误差为零。'),
    ('4. 形成阶段性成果载体', '形成18组四年比较图（PNG与矢量PDF）、核验工作簿、论文框架和六个同步交付包；18张PNG可由独立交付工程逐字节复现。工程验证共19项通过，其中1项调用2022真实模型检查基准、重复性与灌水量接口。现阶段成果为数据、方法及可复现工程，论文尚处于框架与结果整理阶段。'),
]
PROBLEMS = [
    ('1. 跨年模型调用尚未全部贯通。', '2022资料与原模型已接入，2019—2021原始模型实现仍待补充接入。下一步逐年核对源码、驱动和冻结中心点，完成基准一致性测试后再开展四年真实模型响应计算；当前不将重绘图表表述为四年模型全部重跑。'),
    ('2. 采样诊断与参数补偿限制仍需保留。', '现有阶段一结果尚不能按原严格诊断标准作出全面收敛认证，且两阶段样本不构成八维联合后验。将完整保留诊断与适用边界；候选方案按阶段分别扰动，并保留同阶段样本整行相关，不把相关保留行视作独立样本。'),
    ('3. 敏感性与优化尚缺正式真实模型结果。', '历史代理探索可用于排查流程，不能替代作物模型的敏感性排序、Pareto前沿或节水结论。后续开展重复种子、样本量稳定性和同预算算法对照；有硬约束违反或无可行解时，不输出推荐制度。'),
    ('4. 与原立项范围的衔接需补充。', '当前以DI为主，遥感动态同化、滴灌与喷灌对照尚无可核验的完成证据；将核查相应数据和模型适用性，与导师确认补充任务或范围调整。部分观测来自数字化，校准不等同独立验证。申请书所述效率提升30%以上仍属预期目标，不列为已实现成果。'),
]
SCHEDULE = [
    ['10月下旬—\n11月上旬', '接入2019—2021原模型并复现四年基准；核查遥感同化、滴/喷对照的数据与方法条件。', '年度模型接口、复现记录与范围衔接清单。'],
    ['11月上中旬', '执行8参数独立范围Sobol分析，初始N=128、3个种子；检查样本量和排序稳定性。', '六输出的S1、ST、置信区间与稳定性表。'],
    ['11月中下旬', '执行NSGA-III及同预算NSGA-II对照；产量≥观测95%，灌水≤基准；2022固定原五日期分配水量。', '真实模型前沿、可行性与重复运行记录。'],
    ['12月上旬', '候选真实回代、分阶段条件扰动及完整水量核查；按可用证据完成不同方式情景对照。', '主候选及备选核验表；无可行解不强行推荐。'],
    ['12月中下旬', '完善结果与局限、图表、操作说明及参考文献，整理结题材料和论文初稿。', '研究报告、数据与代码归档、论文初稿。'],
]

def font_run(r, size=11, bold=False, sans=False, color='000000'):
    r.font.name = SANS if sans else BODY
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.color.rgb = RGBColor.from_string(color)
    f = r._element.get_or_add_rPr().get_or_add_rFonts()
    for tag in ('ascii','hAnsi','eastAsia','cs'):
        f.set(qn('w:'+tag), SANS if sans else BODY)
    for bad in list(r._element.get_or_add_rPr().findall(qn('w:w'))):
        bad.getparent().remove(bad)

def fmt(p, size=11, before=0, after=5, line=1.35, align=None):
    f=p.paragraph_format
    f.space_before=Pt(before); f.space_after=Pt(after)
    f.line_spacing=Pt(size*1.45 if line>1 else max(size*1.2,2))
    f.line_spacing_rule=WD_LINE_SPACING.EXACTLY
    f.left_indent=Pt(0); f.right_indent=Pt(0); f.first_line_indent=Pt(0)
    f.widow_control=True
    snap=p._p.get_or_add_pPr().find(qn('w:snapToGrid'))
    if snap is None:snap=OxmlElement('w:snapToGrid');p._p.get_or_add_pPr().append(snap)
    snap.set(qn('w:val'),'false')
    for prop in ('firstLineChars','startChars','endChars'):
        ind = p._p.get_or_add_pPr().find(qn('w:ind'))
        if ind is not None: ind.attrib.pop(qn('w:'+prop), None)
    if align is not None: p.alignment=align
    for r in p.runs: font_run(r,size)
    return p

def para(container, text='', size=11, bold=False, before=0, after=5, align=None, keep=False):
    p=container.add_paragraph()
    fmt(p,size,before,after,align=align)
    p.paragraph_format.keep_with_next=keep
    font_run(p.add_run(text),size,bold,bold)
    return p

def heading(cell, text, size=12.5):
    return para(cell,text,size,True,before=2,after=8,keep=True)

def block(cell, pairs, size=11, after=6):
    for h,b in pairs:
        p=cell.add_paragraph();fmt(p,size,after=after)
        font_run(p.add_run(h+' '),size,True)
        font_run(p.add_run(b),size)

def margins(cell, val=110):
    tcpr=cell._tc.get_or_add_tcPr()
    old=tcpr.find(qn('w:tcMar'))
    if old is not None: tcpr.remove(old)
    m=OxmlElement('w:tcMar')
    for k in ('top','left','bottom','right'):
        e=OxmlElement('w:'+k);e.set(qn('w:w'),str(val));e.set(qn('w:type'),'dxa');m.append(e)
    tcpr.append(m)

def set_borders(tab, color='444444', width=5):
    pr=tab._tbl.tblPr
    old=pr.find(qn('w:tblBorders'))
    if old is not None: pr.remove(old)
    bs=OxmlElement('w:tblBorders')
    for n in ('top','left','bottom','right','insideH','insideV'):
        e=OxmlElement('w:'+n);e.set(qn('w:val'),'single');e.set(qn('w:sz'),str(width));e.set(qn('w:color'),color);bs.append(e)
    pr.append(bs)

def tab_width(tab, widths):
    tab.autofit=False;tab.alignment=WD_TABLE_ALIGNMENT.CENTER
    for c,w in zip(tab.columns,widths): c.width=Cm(w)
    for row in tab.rows:
        for c,w in zip(row.cells,widths):
            c.width=Cm(w);margins(c,85)
            c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def small_table(container, headers, rows, widths, size=10.5):
    tab=container.add_table(rows=1,cols=len(headers))
    for c,text in zip(tab.rows[0].cells,headers):c.text=text
    for values in rows:
        row=tab.add_row()
        for c,text in zip(row.cells,values):c.text=str(text)
    tab_width(tab,widths);set_borders(tab,'999999',4)
    for ri,row in enumerate(tab.rows):
        row.height_rule=WD_ROW_HEIGHT_RULE.AT_LEAST
        row.height=Cm(.75)
        for ci,c in enumerate(row.cells):
            for p in c.paragraphs:
                fmt(p,size,after=2,line=1.2,align=WD_ALIGN_PARAGRAPH.CENTER if ri==0 or len(headers)>3 else WD_ALIGN_PARAGRAPH.LEFT)
                for r in p.runs:font_run(r,size,ri==0,ri==0)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'EEF2F4');c._tc.get_or_add_tcPr().append(sh)
    return tab

def page_box(d):
    d.add_page_break()
    t=d.add_table(rows=1,cols=1);tab_width(t,[16.7]);set_borders(t)
    c=t.cell(0,0);margins(c,130)
    p=c.paragraphs[0];fmt(p,size=1,after=0,line=1);font_run(p.add_run(''),1)
    return c

def new_figures():
    font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    font_manager.fontManager.addfont(font_path)
    actual_font_name=font_manager.FontProperties(fname=font_path).get_name()
    plt.rcParams.update({'font.family':[actual_font_name,'DejaVu Sans'],'font.size':10.5,'axes.titlesize':12,'axes.labelsize':10.5,
        'xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':10.5,'axes.spines.top':False,'axes.spines.right':False,
        'axes.edgecolor':'#8B969D','grid.color':'#E7ECEF','axes.unicode_minus':False,'pdf.fonttype':42})
    source=ROOT/'evidence'/'four_year_source_data'
    metrics=pd.read_csv(ROOT/'evidence'/'calibration_metrics_recomputed.csv')
    receipt=[]
    for kind,oc,gc,yl,lim,fname in [
        ('CC','CC_observed','canopy_cover','冠层覆盖度（比例）',(0,1.07),'midterm_CC_four_years'),
        ('Biomass','B_observed_t_ha','Biomass_t_ha','地上干生物量（t/ha）',(0,40),'midterm_biomass_four_years')]:
        fig,axes=plt.subplots(2,2,figsize=(6.45,5.7),sharex=True,sharey=True)
        fig.subplots_adjust(left=.13,right=.98,bottom=.12,top=.88,hspace=.37,wspace=.17)
        for ax,y in zip(axes.flat,YEARS):
            g=pd.read_csv(source/str(y)/'Daily_growth.csv',parse_dates=['Date'],float_precision='round_trip')
            p=pd.read_csv(source/str(y)/(kind+'_pairs.csv'),parse_dates=['Date'],float_precision='round_trip')
            if 'Included' in p:p=p[p.Included.astype(str).str.lower().eq('true')].copy()
            p=p.rename(columns={'Observed_CC':'CC_observed','canopy_cover':'CC_simulated',
                'Observed_B_t_ha':'B_observed_t_ha','Biomass_t_ha':'B_simulated_t_ha'})
            sc='CC_simulated' if kind=='CC' else 'B_simulated_t_ha'
            np.testing.assert_allclose(p[sc],g.set_index('Date').loc[p.Date,gc],atol=1e-10,rtol=0)
            r2=1-((p[sc]-p[oc])**2).sum()/((p[oc]-p[oc].mean())**2).sum()
            rmse=np.sqrt(((p[sc]-p[oc])**2).mean())
            m=metrics[(metrics.Year==y)&(metrics.Variable==kind)].iloc[0]
            np.testing.assert_allclose([r2,rmse],[m.R2,m.RMSE],atol=1e-12,rtol=0)
            start=g.Date.min()
            ax.plot((g.Date-start).dt.days,g[gc],color=COLORS[y],lw=1.6)
            ax.scatter((p.Date-start).dt.days,p[oc],s=24,fc='white',ec=COLORS[y],lw=1.05,zorder=4)
            ax.set_title(str(y),loc='left',fontweight='bold',color=COLORS[y],pad=6)
            ax.set(xlim=(0,155),ylim=lim,xticks=[0,40,80,120])
            ax.grid(alpha=.85);ax.set_axisbelow(True)
            ax.text(.98,.06,f'R²={r2:.3f}\nRMSE={rmse:.3f}',transform=ax.transAxes,ha='right',fontsize=10,
                    bbox={'fc':'white','ec':'none','alpha':.9},linespacing=1.3)
            receipt.append({'year':y,'variable':kind,'n':len(p),'R2':float(r2),'RMSE':float(rmse)})
        handles=[Line2D([0],[0],color='#6A7680',lw=1.6,label='模型逐日输出'),
                 Line2D([0],[0],marker='o',ls='',mfc='white',mec='#6A7680',label='校准观测')]
        fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.54,.994),ncol=2,frameon=False)
        fig.supxlabel('播后天数（d）',y=.025,fontsize=10.5)
        fig.supylabel(yl,x=.005,fontsize=10.5)
        for ext in ('png','pdf'):fig.savefig(ROOT/'figures'/(fname+'.'+ext),dpi=300,facecolor='white')
        plt.close(fig)
    (ROOT/'evidence'/'report_figure_checks.json').write_text(json.dumps({'years':YEARS,'min_font_at_source_pt':10,
         'figure_width_inches':6.45,'word_figure_width_cm':16.5,'minimum_effective_font_pt':10*16.5/(6.45*2.54),
         'note':'All plotted pairs checked against daily original output; calibration, not independent validation.',
         'metrics':receipt},ensure_ascii=False,indent=2),encoding='utf-8')

def build():
    # Keep the institution logo and all original cover field labels.
    template=ROOT/'template'/'converted_midterm_template.docx'
    d=Document(template)
    d.core_properties.title='创新训练项目中期报告书（URP研究内容已填写稿）'
    d.core_properties.subject='2019—2022年滴灌玉米；截至2026-10-19的已核验成果'
    d.core_properties.author='吴雨臻、李承昊、段璞'
    d.core_properties.keywords='中期报告;滴灌玉米;AquaCrop;MCMC;Sobol;NSGA-III'
    sec=d.sections[0];sec.top_margin=Cm(2.1);sec.bottom_margin=Cm(2.0)
    sec.left_margin=Cm(2.15);sec.right_margin=Cm(2.15)
    sec.header_distance=Cm(.8);sec.footer_distance=Cm(.9)
    sec.different_first_page_header_footer=True
    grid=sec._sectPr.find(qn('w:docGrid'))
    if grid is not None:sec._sectPr.remove(grid)
    normal=d.styles['Normal'];normal.font.name=BODY;normal.font.size=Pt(11)
    normal._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),BODY)
    normal.paragraph_format.line_spacing=1.35
    # Replace the old positioned page-number shape with a normal PAGE field.
    for ft in (sec.footer,sec.first_page_footer):
        for e in list(ft._element):ft._element.remove(e)
    p=sec.first_page_footer.add_paragraph('中国农业大学 制表');fmt(p,9,after=0,align=WD_ALIGN_PARAGRAPH.RIGHT)
    p=sec.footer.add_paragraph();fmt(p,9,after=0,align=WD_ALIGN_PARAGRAPH.CENTER)
    r=p.add_run();field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');r._r.addnext(field)
    ps=d.paragraphs
    ps[0].runs[1].text='      '
    ps[0].runs[2].text='项目编号：'+PROJECT_NUMBER
    fmt(ps[0],11,after=8,align=WD_ALIGN_PARAGRAPH.LEFT)
    ps[0].paragraph_format.line_spacing=1.0
    fmt(ps[1],4,after=9,line=1)
    for i in (2,3):
        fmt(ps[i],24,before=4,after=6,line=1.25,align=WD_ALIGN_PARAGRAPH.CENTER)
        for r in ps[i].runs:font_run(r,24,True,True)
    fmt(ps[4],4,after=5,line=1)
    cover=d.tables[0]
    # Remove only the blank remainder of the original form; reconstruct its
    # seven numbered sections below with controlled, readable pagination.
    after=False
    for e in list(d._element.body):
        if e is cover._tbl:after=True;continue
        if after and e.tag!=qn('w:sectPr'):d._element.body.remove(e)
    # Clear floating table placement and scale the original merged grid.
    pr=cover._tbl.tblPr
    for k in ('tblpPr','tblOverlap'):
        e=pr.find(qn('w:'+k))
        if e is not None:pr.remove(e)
    widths=[col.width for col in cover.columns]
    ratio=Cm(16.7)/sum(widths)
    for col,w in zip(cover.columns,widths):col.width=int(w*ratio)
    seen=set()
    for row in cover.rows:
        row.height_rule=WD_ROW_HEIGHT_RULE.AT_LEAST;row.height=Cm(.63)
        for c in row.cells:
            if c._tc in seen:continue
            seen.add(c._tc)
            c.width=int(c.width*ratio);margins(c,60)
            c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    fields={
        (0,2):TITLE,
        (1,2):'2026年', (1,6):'3人',
        (2,2):'吴雨臻', (2,5):'2024321010307', (3,5):'土地科学与技术学院243班',
        (4,2):'17624057163', (4,5):'yuzhenAva@163.com',
        (5,2):'李承昊', (5,5):'2024321010302', (6,5):'土地科学与技术学院243班',
        (7,2):'段璞', (7,5):'2024321010208', (8,5):'土地科学与技术学院242班',
        (9,2):'廖人宽', (9,5):'教授',
        (10,2):'18600795649', (10,5):'renkuanliao@163.com',
        (11,2):'2026年10月19日（请按实际提交日核定）', (13,0):INTRO,
    }
    for (ri,ci),text in fields.items():cover.cell(ri,ci).text=text
    for ri,row in enumerate(cover.rows):
        handled=set()
        for c in row.cells:
            if c._tc in handled:continue
            handled.add(c._tc)
            for p in c.paragraphs:
                fmt(p,10.5,after=0,line=1.25,align=WD_ALIGN_PARAGRAPH.CENTER if ri!=13 else WD_ALIGN_PARAGRAPH.LEFT)
                for r in p.runs:font_run(r,10.5)
        if ri==0:row.height=Cm(1.65)
        if ri==1:row.height=Cm(.9)
        if ri in (11,12):row.height=Cm(.8)
        if ri==13:row.height=Cm(2.25)
    set_borders(cover)
    para(d,'基本信息据立项材料；项目编号与成员分工据项目组补充说明。',9.5,after=0)

    # Page 2: member fields and research progress.
    c=page_box(d)
    small_table(c,['项目组成员','具体分工','个人完成情况及对项目的贡献'],MEMBERS,[3.1,4.1,8.3],10)
    para(c,'成员围绕模型分析、数据可视化和资料整理协作推进，下述为项目整体进展。',9.5,after=6)
    heading(c,'一、项目研究进展情况（研究内容、方法、进度等）')
    block(c,PROGRESS)

    # Page 3: achievements and evidence-backed numbers.
    c=page_box(d)
    heading(c,'二、项目研究已取得阶段性成果和收获（须提供相关证明材料）')
    block(c,RESULTS)
    heading(c,'表1  四年校准拟合指标',11)
    m=pd.read_csv(ROOT/'evidence'/'calibration_metrics_recomputed.csv')
    y=pd.read_csv(ROOT/'evidence'/'observed_yield_gate_headroom.csv').set_index('Year')
    rows=[]
    for year in YEARS:
        cc=m[(m.Year==year)&(m.Variable=='CC')].iloc[0]
        b=m[(m.Year==year)&(m.Variable=='Biomass')].iloc[0]
        rows.append([year,f'{int(cc.N)}/{int(b.N)}',f'{cc.R2:.4f}',f'{cc.RMSE:.4f}',f'{b.R2:.4f}',f'{b.RMSE:.4f}',f'{y.loc[year,"Baseline_bias_pct_vs_observed"]:+.2f}'])
    small_table(c,['年份','配对数\nCC/B','CC\nR²','CC\nRMSE','生物量\nR²','生物量\nRMSE','产量\n误差%'],rows,[1.3,1.8,2.0,2.1,2.1,2.5,2.1],10)
    para(c,'注：B为地上干生物量；CC为比例，生物量RMSE单位为t/ha。R²=1−SSE/SST；产量统一为13%含水率，误差=(模拟−观测)/观测×100%。单年仅一个产量配对，不计算单年产量R²。',9.5,after=7)
    heading(c,'证明材料对应关系',11)
    para(c,'附件1、2展示四年CC与生物量过程；随附CSV提供逐点来源与复算指标；采样汇总表记录既有两阶段成果；2022接入核验文件和19项验证记录提供复现证明。18组四年图及六包同步记录保存在原交付分支，随附填写说明给出索引。',10.5,after=5)

    # Page 4: remaining scientific issues and milestone-based plan.
    c=page_box(d)
    heading(c,'三、项目研究存在的主要问题及应对思路与措施')
    block(c,PROBLEMS,10.7,after=6)
    heading(c,'四、项目研究下阶段主要任务及时间进程安排')
    para(c,'对照立项书2026年11—12月成果总结阶段拟定下列安排，具体日期按学校节点核定。',10.5,after=6)
    small_table(c,['相对进程','主要任务','交付与检查'],SCHEDULE,[2.2,7.5,5.8],10)
    para(c,'执行顺序以各年模型可调用、基准复现通过为前提；正式敏感性、节水率与推荐灌溉方案须在真实模型实验完成后报告。',10,after=5)

    # Page 5: financial form and authorized reviewers' own fields.
    c=page_box(d)
    heading(c,'五、项目经费使用情况')
    para(c,'申请预算5000元；已报销经费：____________元。',11,after=8)
    small_table(c,['申请预算科目','预算（元）','实际报销（元）','凭证/日期'],[
        ['文献检索与资料费','500','',''],
        ['遥感数据获取及处理费','2000','',''],
        ['数据存储与打印耗材费','800','',''],
        ['实地考察与调研费','1200','',''],
        ['成果整理及论文发表辅助费','500','',''],
        ['合计','5000','',''],
    ],[6.3,2.2,3.2,3.8],10)
    para(c,'注：预算据立项申请书，不代表核定经费或已发生支出；实际使用清单请依财务凭证核对。',9.5,after=6)
    heading(c,'六、指导教师意见',12.5)
    para(c,'（从研究内容和进展、阶段性成果、存在问题和建议等加以评价）',10.5,after=5)
    para(c,'【请指导教师本人填写意见并签名】',11,after=0)
    p=para(c,'',11,after=0);p.paragraph_format.space_after=Pt(35)
    para(c,'签名：________________        年    月    日',11,after=18,align=WD_ALIGN_PARAGRAPH.RIGHT)
    heading(c,'七、专家组意见',12.5)
    para(c,'【请专家组填写意见并签名】',11,after=0)
    p=para(c,'',11,after=0);p.paragraph_format.space_after=Pt(35)
    para(c,'专家组成员签名：________________',11,after=12,align=WD_ALIGN_PARAGRAPH.RIGHT)
    para(c,'年    月    日',11,after=5,align=WD_ALIGN_PARAGRAPH.RIGHT)

    # Two readable evidence pages: report-specific layouts with four years.
    for kind,title,caption in [
        ('CC','附件1  四年冠层覆盖度校准过程',
         '图1  实线为模型逐日输出，空心点为用于校准的田间LAI换算CC。各面板采用相同坐标范围；2019蓝、2020橙、2021绿、2022紫。R²及RMSE据全部校准配对复算。'),
        ('biomass','附件2  四年地上干生物量校准过程',
         '图2  实线为模型逐日输出，空心点为校准生物量资料；单位为t/ha。各面板坐标范围统一，不删去不利于拟合的观测点。颜色与附件1一致。')]:
        d.add_page_break()
        para(d,title,14,True,after=12,keep=True)
        p=d.add_paragraph();fmt(p,10,after=6,align=WD_ALIGN_PARAGRAPH.CENTER)
        filename='midterm_CC_four_years.png' if kind=='CC' else 'midterm_biomass_four_years.png'
        p.add_run().add_picture(str(ROOT/'figures'/filename),width=Cm(16.5))
        p.paragraph_format.line_spacing=1.0
        p.paragraph_format.keep_with_next=True
        para(d,caption,10.5,after=10)
        para(d,'证据口径：2019—2021使用已核验的原始均值点输出，2022使用本轮原模型冻结均值点回放；本图属于校准拟合评价，不是独立验证。',10.5,after=10)
        if kind=='CC':
            heading(d,'来源与检查',11)
            para(d,'48个CC配对均与各年逐日输出对应日期一致。2022资料完整性和原模型预审已通过；四年图均包含真实年度数据，不采用插值补位。源表位于随附evidence/four_year_source_data目录。',11)
        else:
            heading(d,'本阶段结果的适用边界',11)
            para(d,'四年共37个生物量配对。现有拟合支持过程描述与数值复现，不能据此提前给出正式Sobol参数排名、优化节水率、未知年份的普适灌溉制度或独立田间验证结论。下一阶段将完成真实模型敏感性与优化实验，再补充相应图表。',11)
    d.save(ROOT/'URP_midterm_report.docx')

    # Plain text counterpart for direct copying into other administrative forms.
    lines=['# 创新训练项目中期报告书（研究内容已填写稿）','',f'项目名称：{TITLE}',
        f'编号：{PROJECT_NUMBER}；执行期：2026年；负责人：吴雨臻；成员：李承昊、段璞；导师：廖人宽教授。','',f'项目简介（{len(INTRO)}字，含标点）：{INTRO}','',
        '## 项目组成员分工与贡献','']
    for row in MEMBERS:lines += ['：'.join(row),'']
    lines += ['## 一、项目研究进展情况','']
    for h,b in PROGRESS:lines += [h+' '+b,'']
    lines += ['## 二、项目研究已取得阶段性成果和收获','']
    for h,b in RESULTS:lines += [h+' '+b,'']
    lines += ['|年份|CC/B配对数|CC R²|CC RMSE|生物量R²|生物量RMSE t/ha|产量误差%|','|---|---|---|---|---|---|---|']
    lines += ['|'+'|'.join(map(str,r))+'|' for r in rows]
    lines += ['','## 三、项目研究存在的主要问题及应对思路与措施','']
    for h,b in PROBLEMS:lines += [h+' '+b,'']
    lines += ['## 四、项目研究下阶段主要任务及时间进程安排','','对照立项书11—12月成果总结阶段拟定；按学校节点核定日期。','']
    for row in SCHEDULE:lines += ['；'.join(row),'']
    lines += ['## 五、项目经费使用情况','','申请预算5000元（非实报销额）；已报销经费：____________元。实际报销金额、凭证与日期按用户要求留空。','',
        '## 六、指导教师意见','','由指导教师本人填写并签名。','','## 七、专家组意见','','由专家组填写并签名。','',
        '## 附件','','![四年CC](figures/midterm_CC_four_years.png)','','![四年生物量](figures/midterm_biomass_four_years.png)','',
        '2019—2021使用已核验原输出；2022使用本轮原模型冻结均值点回放。以上均为校准拟合。']
    (ROOT/'URP_midterm_report_text.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (ROOT/'evidence'/'report_content_checks.json').write_text(json.dumps({'intro_characters':len(INTRO),
        'template_sections_preserved':7,'official_project_title_confirmed':True,
        'new_MCMC_run':False,'full_real_Sobol_or_optimization_completed':False,
        'year_coverage':YEARS,'project_number':PROJECT_NUMBER,
        'member_contribution_allocation':'Drafted per user instruction: leader, Li, Duan in descending contribution order; no percentages invented.',
        'admin_fields':'Official information and project number filled; actual reimbursement intentionally blank; reviewer opinions and signatures reserved.'},ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':
    new_figures()
    build()
    print('Built filled Word report, copyable text, and two checked four-year figure pairs.')
