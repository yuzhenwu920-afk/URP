# 使用与复现

1. 将各ZIP解压到同一个较短目录。每个包均以`URP_Research_Archive/`为根目录，合并后按`stages/`分阶段；同阶段分卷是独立标准ZIP，不需要特殊分卷工具。
2. 先读总README、阶段README及论文12号包。正式四年、2021条件试验与历史作废探索分开。
3. 运行环境见`verification/BUILD_ENVIRONMENT.json`及各阶段requirements。不要将.venv或字节码视作研究代码。用副本运行重计算，保留冻结记录。
4. 只重绘本轮图：`python code/final_figures.py`。需要04号响应矩阵和11号源表，未新增作物模型计算。
5. 重建中英文论文：`python code/build_manuscripts.py`；重建中期报告：`python code/build_midterm_final.py`。Word/PDF转换采用LibreOffice，PDF也已直接提供。
6. `python code/build_figure_guide.py`重建103组英文图索引与矢量图册；`python code/final_overview_and_workbook.py`生成总工作簿。
7. 四年MCMC：02各年度OneClick入口包含阶段一、二实现，2022还有独立补充阶段二入口。先阅读入口README与--help；保留的旧链不因重绘或归档变为已收敛。
8. 真实模型共享引擎在03，Sobol设计/响应在04，正式及全范围遗传记录在05；紧凑NPZ有LOSSLESS_REPACK.json说明，不是只存图片。新条件校准与每代记录在07/08，多算法每次查询在10。
9. `assemble_stages.py`为原工作区归档来源记录，不是重算模型入口；历史脚本可能保留执行时的绝对路径，使用其自包含模型快照或按MANIFEST查找对应文件。不要在不理解旧脚本写入位置时覆盖冻结输出。
10. 全部CSV/NPZ为计算证据。论文数字化近似、GEE元数据缺项、未取得的原始仪器序列与未认证收敛的结果，均按各阶段说明解释。原始上传ZIP内部命名保留；02解开结果使用短路径，映射见verification/SHORT_PATH_RELOCATIONS.csv。
