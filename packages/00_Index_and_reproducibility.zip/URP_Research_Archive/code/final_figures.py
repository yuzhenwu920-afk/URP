from pathlib import Path
import os,json,shutil
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'stages/11_English_figures_tables_and_interpretations/Final_revision'
for d in ['figures','tables','analysis']: (OUT/d).mkdir(parents=True,exist_ok=True)
os.environ['MPLCONFIGDIR']=str(ROOT/'work/mplcache')
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.stats import linregress,pearsonr
BASE=ROOT/'stages/11_English_figures_tables_and_interpretations'
TB=BASE/'tables'; YEARS=[2019,2020,2021,2022]
C={2019:'#0072B2',2020:'#D55E00',2021:'#009E73',2022:'#A85AA0'}
NAMES=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
LAB=['CCx','CGC','CDC','Senescence','Kcb','Early WP','Late WP','HI0']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.labelsize':11,'axes.titlesize':12,'legend.fontsize':10,
 'xtick.labelsize':10,'ytick.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
REG=[]
def save(fig,name,caption,source):
    for e in ['png','pdf','svg']:fig.savefig(OUT/'figures'/f'{name}.{e}',dpi=600,facecolor='white',bbox_inches='tight')
    REG.append(dict(name=name,caption_EN=caption,sources=source,years=YEARS))
    plt.close(fig)

def pooled_biomass():
    a=pd.read_csv(TB/'F05_Biomass_calibration_pairs.csv')
    x=a.B_observed_t_ha.to_numpy();y=a.B_simulated_t_ha.to_numpy();r=linregress(x,y)
    fig,ax=plt.subplots(figsize=(6.6,5.1),layout='constrained')
    lim=1.04*max(x.max(),y.max()); xx=np.array([0,lim])
    ax.plot(xx,xx,'--',color='#8B999F',lw=1.1,label='1:1 line')
    ax.plot(xx,r.intercept+r.slope*xx,color='#243E4B',lw=1.6,label='Pooled OLS fit')
    for yr in YEARS:
        z=a[a.Year==yr];ax.scatter(z.B_observed_t_ha,z.B_simulated_t_ha,s=43,color=C[yr],ec='white',lw=.6,label=str(yr),zorder=5)
    ax.set(xlim=(0,lim),ylim=(0,lim),xlabel='Observed aboveground dry biomass (t ha$^{-1}$)',ylabel='Simulated aboveground dry biomass (t ha$^{-1}$)')
    ax.text(.045,.95,f'$n$ = {len(a)}\n$y$ = {r.slope:.3f}$x$ {r.intercept:+.3f}\n$R^2$ = {r.rvalue**2:.4f}\nPearson $r$ = {r.rvalue:.4f}',va='top',transform=ax.transAxes,fontsize=11,bbox=dict(fc='white',ec='none',alpha=.9))
    ax.legend(loc='lower right',frameon=False,ncol=2);ax.grid(alpha=.18);ax.set_axisbelow(True)
    a.to_csv(OUT/'tables/Pooled_biomass_observedX_simulatedY_pairs.csv',index=False)
    pd.DataFrame([dict(N=len(a),X='observed aboveground dry biomass',Y='simulated aboveground dry biomass',OLS_slope=r.slope,OLS_intercept=r.intercept,OLS_R2=r.rvalue**2,Pearson_r=r.rvalue,units='t ha-1')]).to_csv(OUT/'tables/Pooled_biomass_OLS_summary.csv',index=False)
    save(fig,'F13_Pooled_biomass_regression_EN','Pooled four-year biomass regression, using all 37 calibration pairs. Observed biomass is on the horizontal axis and simulated biomass on the vertical axis. The solid line is an ordinary least-squares fit; the dashed line is 1:1. OLS R² and Pearson r describe association, not independent validation; repeated dates occur within years. Digitized biomass retains its source uncertainty.',['F05_Biomass_calibration_pairs.csv','Pooled_biomass_OLS_summary.csv'])

def sobol_ci():
    # Resample each complete Saltelli base block independently within each scramble.
    # A block contains A, all eight AB values, and B. No crop-model calls are made.
    rng=np.random.default_rng(20261021);draws=[];rows=[]; maxerr=0.
    old=pd.read_csv(TB/'Sobol_annual_means_and_ranks.csv'); reps=512
    for yr in YEARS:
        seedboot=[]; seedpoint=[]
        for seed in [101,202,303]:
            f=ROOT/f'stages/04_Sobol_real_model/sobol_global_N512/{yr}_seed{seed}/response_matrix.npy'
            y=np.load(f)[:,0];y=(y-y.mean())/y.std();y=y.reshape(512,10)
            A=y[:,0]; B=y[:,-1];AB=y[:,1:9]; v=np.var(np.r_[A,B])
            point=np.stack([np.mean(B[:,None]*(AB-A[:,None]),axis=0)/v,.5*np.mean((A[:,None]-AB)**2,axis=0)/v])
            seedpoint.append(point)
            ix=rng.integers(0,512,size=(reps,512));aa=A[ix];bb=B[ix];ab=AB[ix]
            vv=np.var(np.concatenate([aa,bb],axis=1),axis=1)
            boot=np.stack([np.mean(bb[:,:,None]*(ab-aa[:,:,None]),axis=1)/vv[:,None],.5*np.mean((aa[:,:,None]-ab)**2,axis=1)/vv[:,None]],axis=1)
            seedboot.append(boot)
        est=np.mean(seedpoint,axis=0); boot=np.mean(seedboot,axis=0); half=1.959963984540054*np.std(boot,axis=0,ddof=1)
        ref=old[(old.Year==yr)&(old.Output=='Y_13pct')].set_index('Parameter').loc[NAMES]
        maxerr=max(maxerr,float(np.max(np.abs(est-np.stack([ref.S1_mean,ref.ST_mean])))))
        for j,n in enumerate(NAMES):rows.append(dict(Year=yr,Parameter=n,S1=est[0,j],S1_bootstrap95_halfwidth=half[0,j],ST=est[1,j],ST_bootstrap95_halfwidth=half[1,j],Resamples=reps,Base_samples_per_scramble=512,Scrambles=3))
        draws.append(boot)
    assert maxerr<1e-12,maxerr
    data=pd.DataFrame(rows);data.to_csv(OUT/'tables/R02_annual_scramble_mean_bootstrap.csv',index=False)
    np.savez_compressed(OUT/'tables/R02_complete_block_bootstrap_replicates.npz',years=YEARS,parameters=NAMES,bootstrap_means=np.array(draws))
    fig,axes=plt.subplots(1,2,figsize=(8.2,6.0),sharey=True,layout='constrained')
    yy=np.arange(8)
    for ax,metric,title in zip(axes,['S1','ST'],['(a) First-order sensitivity','(b) Total-effect sensitivity']):
        values=[]
        for j,yr in enumerate(YEARS):
            z=data[data.Year==yr].set_index('Parameter').loc[NAMES];values.append(z[metric].to_numpy())
            ax.errorbar(z[metric],yy+(j-1.5)*.145,xerr=z[metric+'_bootstrap95_halfwidth'],fmt=['o','s','^','v'][j],ms=4,elinewidth=.8,capsize=1.8,c=C[yr])
        values=np.array(values)
        ax.hlines(yy+.40,values.min(axis=0),values.max(axis=0),lw=2,color='#A6B4BC')
        ax.scatter(values.mean(axis=0),yy+.40,s=26,marker='D',color='#263F4A',zorder=5)
        ax.set(title=title,xlabel=f'{metric} index',yticks=yy,yticklabels=LAB,ylim=(7.8,-.6),xlim=(-.06,.60))
        ax.axvline(0,c='#99A6AC',lw=.7);ax.grid(axis='x',alpha=.18)
    hh=[Line2D([],[],marker=['o','s','^','v'][j],c=C[y],ls='',label=str(y)) for j,y in enumerate(YEARS)]
    hh += [Line2D([],[],marker='D',c='#263F4A',ls='',label='Four-year mean'),Line2D([],[],color='#A6B4BC',lw=2,label='Across-year range')]
    fig.legend(handles=hh,loc='outside upper center',ncol=3,frameon=False)
    save(fig,'R02_Sobol_Yield_CI_Four_years_and_mean_EN','Yield sensitivity across 2019–2022. Colored symbols are means over three independently scrambled N=512 Saltelli designs. Error bars are approximate 95% numerical bootstrap intervals for that three-scramble mean, obtained by independently resampling complete A/AB/B base blocks within each scramble (512 resamples; normal half-width 1.96 SD). Diamonds are equal-weight four-year means; gray segments show the across-year minimum–maximum, not a confidence interval. These are independent-uniform-input Sobol estimates, not correlated-posterior indices or field predictive intervals.',['Sobol_all_seed_indices.csv','R02_annual_scramble_mean_bootstrap.csv','R02_complete_block_bootstrap_replicates.npz'])
    (OUT/'R02_DEFINITION_RESOLVED.json').write_text(json.dumps({'user_confirmation':'R02_Sobol_Yield_CI in URP_figures(5).zip','metrics':['S1','ST'],'cat_coc_not_new_variables':True,'resampling_scope':'within-design complete-block numerical bootstrap; no new crop-model evaluations','max_reproduction_error':maxerr},indent=2))

def nondom(g):
    z=g.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False]).drop_duplicates('Irrigation_mm');keep=[];best=-np.inf
    for ix,r in z.iterrows():
        if r.Y_13pct>best+1e-9:keep.append(ix);best=r.Y_13pct
    return z.loc[keep].copy()
def pareto():
    full=pd.read_csv(TB/'Full_range_best_found_front.csv');di=pd.read_csv(TB/'Table5_selected_candidates.csv').set_index('Year')
    shown=[];globalfront=[]
    def panel(ax,yr,prefix=''):
        f=nondom(full[full.Year==yr]);globalfront.append(f)
        # Select exact archived solutions near evenly spaced irrigation levels, no fitted interpolation.
        ix=np.unique([np.argmin(abs(f.Irrigation_mm-v)) for v in np.linspace(0,f.Irrigation_mm.max(),12)])
        z=f.iloc[ix];shown.append(z)
        ax.plot(f.Irrigation_mm,f.Y_13pct,'--',color='#648DDE',lw=1.6,label='Best-found Pareto front')
        ax.scatter(z.Irrigation_mm,z.Y_13pct,c='#D63A3A',s=22,zorder=5,label='Archived solutions')
        ys=di.loc[yr];ax.scatter(ys.Baseline_irrigation_mm,ys.Model_baseline_Y13,marker='*',s=95,c='#29434E',zorder=6,label='DI model baseline')
        ax.axhline(ys.Yield_gate_Y13,color='#A66C68',ls=':',lw=1.0,label='95% observed-yield level')
        labix=np.unique(np.round(np.linspace(0,len(z)-1,6)).astype(int))
        for j,k in enumerate(labix):
            r=z.iloc[k]; amounts=[r[f'Window{i}_mm'] for i in range(1,5)]
            label='('+', '.join(f'{v:.0f}' for v in amounts)+')'
            # Alternate label heights and keep right-most annotations within the axes.
            # Reserved callout lanes avoid overlapping boxes near the plateau.
            slots=[(.02,.14),(.10,.42),(.28,.56),(.40,.76),(.49,.94),(.68,.65)]
            ax.annotate(label,(r.Irrigation_mm,r.Y_13pct),xytext=slots[j],textcoords='axes fraction',ha='left',fontsize=10,bbox=dict(boxstyle='round,pad=.17',fc='white',ec='#B5BEC3',lw=.65,alpha=.97),arrowprops=dict(arrowstyle='-',color='#A4ADB2',lw=.5))
        ax.set(title=f'{prefix}{yr}',xlim=(-.025*ys.Baseline_irrigation_mm,ys.Baseline_irrigation_mm*1.05),ylim=(0,max(ys.Model_baseline_Y13,f.Y_13pct.max())*1.17),xlabel='Actual seasonal irrigation (mm)',ylabel='Grain yield (t ha$^{-1}$)\n13% moisture')
        ax.grid(ls='--',alpha=.20);ax.set_axisbelow(True)
    fig,axes=plt.subplots(2,2,figsize=(11.1,7.0),layout='constrained')
    for i,(ax,yr) in enumerate(zip(axes.flat,YEARS)):panel(ax,yr,f'({chr(97+i)}) ')
    handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=2,frameon=False)
    cap='Four-year full-range, best-found NSGA-III Pareto envelopes. Blue dashed curves join nondominated archived solutions; red dots highlight exact evaluated controls. Labels give rounded allocations (W1, W2, W3, W4; mm), in fixed irrigation-date windows, not soil-moisture thresholds. Stars are original DI model baselines. The 95% observed-yield line is a reference only: it was removed as a constraint for this supplemental full-range search (3 seeds × 80 individuals × 60 generations per year; 57,600 evaluations in total). Four-year historical settings are Zmax=2.30 m and fMulch=0, with 75% cover. The original 400,000-evaluation gated experiment is separate. Curves are finite-search envelopes, not proven optima or independently validated field responses.'
    save(fig,'R03_Pareto_four_years_annotated_EN',cap,['Full_range_best_found_front.csv','Pareto_display_points.csv'])
    pd.concat(shown).drop_duplicates().to_csv(OUT/'tables/Pareto_display_points.csv',index=False)
    pd.concat(globalfront).drop_duplicates().to_csv(OUT/'tables/Pareto_nondominated_exact_solutions.csv',index=False)
    for yr in YEARS:
        fig,ax=plt.subplots(figsize=(7.0,5.1),layout='constrained');panel(ax,yr);ax.legend(loc='lower right',frameon=False,fontsize=8.5)
        save(fig,f'R03_Pareto_{yr}_annotated_EN',cap,['Pareto_display_points.csv'])

if __name__=='__main__':
    pooled_biomass();sobol_ci();pareto()
    (OUT/'FIGURE_REGISTRY.json').write_text(json.dumps(REG,ensure_ascii=False,indent=2))
    (OUT/'analysis/本轮修订说明.md').write_text('R02已依据用户确认的R02_Sobol_Yield_CI原图重构：同图保留四年S1、ST、数值bootstrap区间和等权年度均值，年际范围与数值区间分开。\n\nF13按手写要求重画四年生物量回归，横轴观测、纵轴模拟，R²与Pearson r同时报告；不把未定义Y_catmul/Y_tot强行绑定为新数据。\n\n四年Pareto照示例采用蓝虚线、红实点和四窗口水量注记。标签仅取6个代表解以保证可读性，所有确切解与12个显示点/年见CSV。图为57,600次补充搜索的全范围包络；不能改称400,000次正式有门槛搜索或1m重新校准结果。\n',encoding='utf-8')
    print('Generated',len(REG),'English final figure groups')
