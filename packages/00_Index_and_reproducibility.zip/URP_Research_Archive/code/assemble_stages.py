"""Preserve original files and arrange computed evidence by research stage."""
from pathlib import Path
import shutil, hashlib, zipfile, io, csv, json, sys, re
ROOT=Path(__file__).resolve().parents[1]; ST=ROOT/'stages'; WS=Path('/workspace')
MAN=[]
BAD={'.git','.venv','__pycache__','.cache','.mplcache','node_modules'}
def excluded(p):
    return any(x in BAD or x.startswith('lo_') for x in p.parts) or p.suffix in {'.pyc','.pyo'}
def copy(src,dest):
    src=Path(src); dest=ST/dest
    dest.parent.mkdir(parents=True,exist_ok=True)
    if not dest.exists():shutil.copy2(src,dest)
    MAN.append({'source':str(src),'archive_path':str(dest.relative_to(ST)),'bytes':src.stat().st_size,'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
def tree(src,dest,omit=()):
    src=Path(src)
    for p in sorted(src.rglob('*')):
        if p.is_file() and not excluded(p.relative_to(src)) and not any(x in p.relative_to(src).parts for x in omit) and p.suffix!='.zip':copy(p,Path(dest)/p.relative_to(src))
def nested(z,dest,depth=0):
    # Uploaded archives are trusted as data, never execute their code here.
    dest=ST/dest
    for item in z.infolist():
        if item.is_dir():continue
        path=Path(item.filename)
        if path.is_absolute() or '..' in path.parts:raise ValueError(item.filename)
        data=z.read(item)
        if excluded(path):continue
        if path.suffix=='.zip' and depth<4:
            with zipfile.ZipFile(io.BytesIO(data)) as zz:nested(zz,(dest/path.with_suffix('')).relative_to(ST),depth+1)
        else:
            p=dest/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
            MAN.append({'source':f'uploaded nested zip:{z.filename}:{item.filename}','archive_path':str(p.relative_to(ST)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
def note(stage,title,txt):
    p=ST/stage;p.mkdir(parents=True,exist_ok=True);(p/'README.md').write_text('# '+title+'\n\n'+txt+'\n',encoding='utf-8')

if __name__=='__main__':
    # All available uploaded originals, unique by content; aliases stay in a manifest.
    seen={}; uploaded=[]
    for p in sorted((WS/'attachments').rglob('*')):
        if not p.is_file():continue
        sha=hashlib.sha256(p.read_bytes()).hexdigest(); target=seen.get(sha)
        if target is None:
            # Original archives are kept intact, separately from the unpacked working evidence.
            target=Path('01_Raw_data_and_references/Uploaded_originals')/sha[:10]/p.name
            copy(p,target); seen[sha]=str(target)
        uploaded.append({'original_path':str(p),'original_name':p.name,'sha256':sha,'bytes':p.stat().st_size,'canonical_archive_path':str(target)})
    with (ST/'01_Raw_data_and_references/UPLOAD_ALIASES.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=uploaded[0]);w.writeheader();w.writerows(uploaded)
    for year in range(2019,2023):
        z=next((WS/'attachments').rglob(f'②原始资料包_{year}.zip'))
        with zipfile.ZipFile(z) as f:nested(f,Path(f'02_MCMC_{year}')/'Original_submitted_results')
        tree(WS/f'URP/DI_PHASE3_NEXTGEN_UPDATED/real_model/model_{year}',f'02_MCMC_{year}/OneClick_stage1_and_inputs')
        tree(WS/f'urp_followup_20261016/revision/four_year_source_data/{year}',f'02_MCMC_{year}/Verified_calibration_pairs')
        note(f'02_MCMC_{year}',f'{year}年两阶段MCMC与原始运行结果',
             'Original_submitted_results递归解开原始分年资料包，保留阶段一/二源码、checkpoint和诊断文件。OneClick为后来用户确认的阶段一入口。\n\n'
             '长链设置：32 walkers、2000步；阶段一每年4个ensemble，阶段二每年1个。未把相关walker冒充独立链；未通过全部严格收敛认证。2019压缩包内部名含2020的历史命名保持原样，以所属年度及实际日期为准。\n\n'
             '运行前阅读各入口的help/README，在副本目录运行，避免覆盖冻结结果；不要把早期试跑/补充收敛代码的存在等同于正式后验已收敛。2022新增完整阶段二另见Supplemental_phase2。')
    p2=WS/'urp_run_20261018/phase2/DI_2022_Phase2'
    tree(p2,'02_MCMC_2022/Supplemental_phase2')
    tree(WS/'urp_run_20261018/ready/DI_2022_Sobol_NSGA3_READY_PACKAGE_2026-10-17/04_phase2_review','02_MCMC_2022/Supplemental_phase2_review')
    # Extract searchable climate, RS and field data, not only nested in source ZIPs.
    for year in range(2019,2023):
        inp=WS/f'URP/DI_PHASE3_NEXTGEN_UPDATED/real_model/model_{year}/data'
        tree(inp,f'01_Raw_data_and_references/Model_inputs/{year}')
    tree(WS/'urp_rainfall_audit_20261021/inputs','01_Raw_data_and_references/Latest_uploaded_weather_RS_and_thesis')
    tree(WS/'URP/DI_PHASE3_NEXTGEN_UPDATED/frozen_inputs','03_Model_engine_and_frozen_handoffs/frozen_inputs')
    tree(WS/'URP/DI_PHASE3_NEXTGEN_UPDATED/real_model','03_Model_engine_and_frozen_handoffs/real_model')
    for n in ['project_config.json','model_adapter.py','requirements.txt','FROZEN_INPUTS_MANIFEST.json','ORIGINAL_CODE_SHA256.json','phaseB_sobol.py','phaseC_nsga3.py','validate_candidates.py','run_four_year_experiment.py','tests']:
        p=WS/'URP/DI_PHASE3_NEXTGEN_UPDATED'/n
        if p.is_dir():tree(p,Path('03_Model_engine_and_frozen_handoffs')/n)
        elif p.exists():copy(p,Path('03_Model_engine_and_frozen_handoffs')/n)
    cr=WS/'urp_true_runs_20261019/compact_results'
    for p in cr.iterdir():
        if p.is_dir() and p.name.startswith('sobol'):tree(p,Path('04_Sobol_real_model')/p.name)
    tree(cr/'optimization','05_Genetic_optimization_4years/optimization')
    for n in ['executed_sources','annual_metadata','baseline_reproduction','baseline_reproduction_compiled','baseline_reproduction_extended','replacement_sources','delivery_audit']:
        tree(WS/'urp_true_runs_20261019'/n,Path('03_Model_engine_and_frozen_handoffs/Execution_evidence')/n)
    for p in (WS/'urp_true_runs_20261019').iterdir():
        if p.is_file() and p.suffix in {'.py','.json','.md','.log'}:copy(p,Path('03_Model_engine_and_frozen_handoffs/Execution_evidence')/p.name)
    tree(WS/'urp_paper_revision_20261020/part4_optimization_diagnostic','05_Genetic_optimization_4years/Full_range_supplement')
    tree(WS/'urp_optimization_mechanism_audit_20261020','06_Structural_and_root_depth_diagnostics/Mechanism_audit')
    tree(WS/'urp_root1m_experiment_20261020','06_Structural_and_root_depth_diagnostics/Root1m_frozen_4year_trial')
    for n in ['urp_2021_root1m_mcmc_20261021','urp_2021_water_audit_20261021','urp_2021_nsga3_pilot_20261021','urp_2021_plateau_diagnosis_20261021']:
        tree(WS/n,Path('07_2021_root1m_calibration_water_and_Pareto')/n)
    tree(WS/'urp_2021_fmulch_comparison_20261021','08_2021_mulch_conditional_calibration_and_optimization')
    tree(WS/'urp_rainfall_audit_20261021','09_Rainfall_and_data_provenance_audit')
    tree(WS/'urp_single_objective_comparison_20261021','10_Single_objective_multi_algorithm_validation')
    tree(WS/'urp_paper_revision_20261020/final_english_paper_package','11_English_figures_tables_and_interpretations')
    # Preserve early historical documents/proxy runs and the retired preflight, clearly separated.
    for name in ['urp_review','urp_execution_20261016','urp_followup_20261016','urp_paper_guide_20261019','urp_root1m_initialization_preflight_retired_20261020','urp_missing_results_20261019']:
        tree(WS/name,Path('14_Research_history_NOT_primary_results')/name)
    note('01_Raw_data_and_references','原始资料与文献',
         '完整保留当前能取得的上传原件，按SHA256去除重复版本，UPLOAD_ALIASES.csv记录所有对应关系。四年气象、NDVI/遥感、LAI-CC、初始水、灌水和论文资料另以可检索形式提供。\n\n'
         'ETo为驱动，实际ET及Es/Tr有论文观测汇总与模型输出，须看来源。原始逐日雨量站数据和所有仪器原记录未取得，论文图数字化近似不能冒充原始逐日观测。GEE产品/ROI/时区未核实；遥感部分处理标签BI不能冒充DI。\n\n'
         '三份早期总合并上传包超过32MiB下载限制；分年原件和当前可用工程已分别保存，不能声称这三份大合并ZIP逐字节归档。参考文献PDF仅限用户提供的论文，其他文献给出已核对书目和DOI。')
    note('03_Model_engine_and_frozen_handoffs','真实模型、冻结交接与执行证据','本目录保留原模型、加速实现、相位分开保留样本和数值一致性记录。四年主设定Zmax=2.30m、MulchPct=75%、fMulch=0；各年实际参数见冻结JSON。先安装requirements，再核对命令行--help。两阶段均值拼接不是八维联合后验；original模块仅供复现。')
    note('04_Sobol_real_model','真实模型Sobol','包含N128/256/512递增试验、设计矩阵、响应、种子与区间。正式主分析N512×3scrambles×4年，8参数、6输出；独立均匀输入分布，不是相关MCMC后验。完整结果表与英文图在11号包。')
    note('05_Genetic_optimization_4years','四年遗传优化及全范围补充','正式NSGA-II/III各5种子、100个体×100代、四年，40次搜索400000评估。compact NPZ为无损保存的评估与逐代记录，LOSSLESS_REPACK.json说明恢复。四窗口为固定日期上的水量控制，不是日期优化。全范围补充移除产量门槛，独立标注预算。\n\n主模型fMulch=0、Zmax2.30m。无季末储水约束与设备单次上限，不能作为可实施节水配额。')
    note('06_Structural_and_root_depth_diagnostics','机制及四年根深1m诊断','保留机制追溯、覆膜/根区/水分账及约束试验；四年root1m采用冻结旧参数，未重新校准，因此仅属结构对照。退休初始化preflight另放历史包，不作为有效试验。')
    note('07_2021_root1m_calibration_water_and_Pareto','2021根深1m短链、水分审计与NSGA-III','500步、10walkers试验以及含水量、水分胁迫、储水、逐层取水和原fMulch0 Pareto。短链没有严格收敛认证。后续fMulch.50/.75/.85使用各自条件拟合，见08号。')
    note('08_2021_mulch_conditional_calibration_and_optimization','2021覆膜三情景条件重校准与优化','三个fMulch=.50/.75/.85，rootmax1m、cover75%；每情景两阶段各4ensemble×10walker×500步，完整链、日志和来源均保留。120000MCMC状态评估、90000NSGA-III评估；参数边界/收敛问题仍存在，不能称为物理定值识别。')
    note('09_Rainfall_and_data_provenance_audit','降水及驱动审计','含原论文裁图、逐日近似重建、GEE比较、224次固定参数替换试验。论文数字化非原始站点序列；ERRATA保留观测Es来源修正，不覆盖旧文档。')
    note('10_Single_objective_multi_algorithm_validation','单目标多算法验证','两套模型共7情景：四年历史＋2021三覆膜条件拟合。GA、单目标NSGA-II、模拟退火、DE，3种子；253440目标查询，217084真实模型调用。按产量阈值min灌水；同预算比较与跨阈值档案最小值分表，历史NSGA-III参照预算不等。数值重复性不能替代田间验证。')
    note('11_English_figures_tables_and_interpretations','全部英文图表与逐图解析','保留此前43组英文图、源表、解析和重绘脚本；本轮新增图位于Final_revision。旧论文骨架与旧说明保留日期，当前最终论文见12号。R02确认来自R02_Sobol_Yield_CI，采用明确S1/ST和bootstrap数值区间，不臆造cat/coc变量。')
    note('14_Research_history_NOT_primary_results','研究历程与作废探索（不作正式证据）','此处含早期代理模型、未接入完整模型时的报告、准备性设计以及已作废初始化preflight。保留用于追溯，不与后来真实模型结果合并、不引用其节水率作为正式结论。历史文档中的待办可能已在后来完成。')
    with (ROOT/'verification/ASSEMBLY_SOURCE_MAP.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=MAN[0]);w.writeheader();w.writerows(MAN)
    print('Staged',len(MAN),'files',round(sum(r['bytes'] for r in MAN)/1e6,1),'MB')
