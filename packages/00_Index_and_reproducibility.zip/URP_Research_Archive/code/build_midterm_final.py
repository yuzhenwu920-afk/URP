"""Update the supplied administrative form without inventing signatures or expenses."""
from pathlib import Path
import importlib.util,inspect,shutil,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'stages/13_Project_midterm_report'
for n in ['template','evidence','figures']:(OUT/n).mkdir(parents=True,exist_ok=True)
OLD=Path('/workspace/urp_midterm_20261019/package')
renderer=OUT/'template/original_midterm_renderer.py'
if not renderer.exists():shutil.copy2(OLD/'build_midterm_report.py',renderer)
spec=importlib.util.spec_from_file_location('oldmidterm',renderer);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.ROOT=OUT
if not (OUT/'template/converted_midterm_template.docx').exists():shutil.copy2(ROOT/'work/template_conversion/0102创新训练项目-中期报告书.docx',OUT/'template/converted_midterm_template.docx')
if not (OUT/'template/original_midterm_template.doc').exists():shutil.copy2('/workspace/attachments/4fa018d0-17e2-4980-ab12-9ebfedb7a741/0102创新训练项目-中期报告书.doc',OUT/'template/original_midterm_template.doc')
for f in ['calibration_metrics_recomputed.csv','observed_yield_gate_headroom.csv']:
    if not (OUT/'evidence'/f).exists():shutil.copy2(OLD/'evidence'/f,OUT/'evidence'/f)
for name in ['source_basic_information.docx','source_application.pdf']:
    if not (OUT/'template'/name).exists():shutil.copy2(OLD/'template'/name,OUT/'template'/name)
F=ROOT/'stages/11_English_figures_tables_and_interpretations'
for a,b in [('F02_CC_trajectories_EN.png','midterm_CC_four_years.png'),('F03_Biomass_trajectories_EN.png','midterm_biomass_four_years.png')]:shutil.copy2(F/'figures'/a,OUT/'figures'/b)
m.MEMBERS=[
 ['吴雨臻（组长）','统筹、核心模型与结果解释','统筹四年研究方案，负责MCMC衔接、真实模型敏感性与优化分析，组织根深、覆膜、储水及算法诊断，完成核心论证与成果整合。'],
 ['李承昊','数据处理、评价与图表','整理四年气象、遥感和观测配对资料，复算拟合指标，协助逐日水量核查，制作和规范英文图、数据表及论文图表。'],
 ['段璞','文献、归档与校对','查阅和核对参考文献、试验与土壤资料，整理代码和结果索引，参与成果包归档、报告及中英文稿件校对。']]
m.PROGRESS=[
 ('1. 研究范围与资料基础。','围绕立项的灌溉制度优化问题，目前聚焦甘肃武威2019—2022年DI覆膜玉米，已完成气象、ETo、NDVI/遥感、LAI换算CC、初始水、灌水、生物量和季节产量资料的溯源整理。未将尚未实现的喷灌对照或遥感动态同化列为已完成内容。'),
 ('2. 四年两阶段MCMC成果贯通。','阶段一校准冠层与蒸腾相关5参数，阶段二条件拟合3个生产参数。原每组32 walkers、2000步，四年16组阶段一与4组阶段二检查点已复核，2022完整阶段二已接入。另完成2021根深1 m及覆膜系数三情景的500步条件试验，并检查边界和采样局限。'),
 ('3. 真实模型Sobol与遗传优化。','已完成四年八参数六输出Sobol递增样本及重复种子计算；N512主分析61440次模型评估。NSGA-III/II各5种子、100个体×100代，四年正式搜索400000次评估，另有完整低水量区间补充前沿。全部设计、响应、种子与逐代记录已保存。'),
 ('4. 机制审计与补充验证。','围绕低灌水高产现象，完成根深、覆膜、水分胁迫与分层储水核查、降水替换224次及单目标GA/NSGA-II/退火/差分进化验证。后者含253440次查询、217084次实际优化模型调用。不同算法仍可找到低水量解，解释重点转向季末储水及实施约束。'),
 ('5. 成果整理与当前状态。','主要计算模块已经运行并形成结果；四年英文图表、中英文完整论文初稿和按阶段整理的科研归档已编制。拟合不等于充分收敛或独立田间验证，当前转入证据核对、限制说明、导师讨论及正式成果凝练阶段。')]
m.RESULTS=[
 ('1. 建立完整、可追溯的研究证据链。','四年48个CC、37个生物量配对可回溯至源表及逐日模型。四年原始长链、阶段二、个别补充诊断源码、Sobol矩阵、遗传评估与每代结果均按科研阶段归档，附文件索引和SHA256。'),
 ('2. 获得多输出校准与敏感性结果。','CC的R²cal为0.9306—0.9932，生物量为0.9685—0.9966；年度产量偏差约−4.18%至+0.92%。公共独立参数范围下，晚期WP与HI0为产量主要敏感参数，四年ST描述均值约0.396与0.206。'),
 ('3. 形成灌水—产量前沿及物理解释。','原95%观测门槛候选减灌约35.6%—57.8%，ET仅降1.4%—5.2%；季末储水差解释约83%—97%的减灌量。由此识别单季、无储水底线优化的适用边界，没有将较大的模型减灌百分数等同可推广的田间定额。'),
 ('4. 完成多情景核验和成果表达。','完成2021覆膜三情景条件拟合及90000次NSGA-III评估，形成胁迫、冠层、储水和前沿图；完成四算法单目标验证。中英文论文各含14图、7张三线表，当前为论文初稿，未声称已发表、录用或取得奖项。')]
m.PROBLEMS=[
 ('1. 收敛与边界问题仍需保留。','部分参数在先验边界附近集中，原阶段一未通过全部严格诊断，2021短链试验也不能认证充分收敛。将候选解释为条件模型结果，后续依独立初始化、误差模型和可辨识性开展补强。'),
 ('2. 低灌水候选依赖储水条件。','原搜索没有季末储水底线与额外硬件单次上限，部分方案可能难实施。下一步以实测分层水分和设备能力定义约束，避免为获得预设400 mm而调参。'),
 ('3. 资料来源仍有不确定性。','论文日雨量图是数字化近似而非原始站点记录，GEE导出元数据与遥感处理标签需完善。土壤实测约1 m，更深层外推与初始水需要核查；新覆膜情景Es仍偏低，不能只凭产量选参数。'),
 ('4. 立项范围与成果口径需核定。','本阶段主要完成DI玉米的模型研究，喷灌对照、动态同化、稳健优化与独立田间试验未获完成证据。与导师核定范围及结题表达；申请书预期效率提升30%不能直接列为实绩。')]
m.SCHEDULE=[
 ['10月下旬','完成模型结果、图表、引用和阶段归档的最终交叉核对；与导师确认项目范围。','核定的数据/代码索引与报告。'],
 ['11月上中旬','优先取得分层含水量、日雨量及Es/Tr依据，解释储水与覆膜偏差；核定必要补充分析。','观测核对及限制清单。'],
 ['11月下旬','完善采样和误差诊断；在有依据时定义设备与季末水分约束，补充比较。','诊断材料与修订说明。'],
 ['12月','按学校节点完成论文修改、结题报告、答辩图表与科研资料交接。','中英文稿、最终归档及结题材料。']]

source=inspect.getsource(m.build)
replacements={
 '截至2026-10-19的已核验成果':'截至2026-10-21的计算与诊断成果',
 '2026年10月19日（请按实际提交日核定）':'2026年10月21日（请按实际提交日核定）',
 '附件1、2展示四年CC与生物量过程；随附CSV提供逐点来源与复算指标；采样汇总表记录既有两阶段成果；2022接入核验文件和19项验证记录提供复现证明。18组四年图及六包同步记录保存在原交付分支，随附填写说明给出索引。':'附件1—5展示四年CC、生物量、Sobol、前沿及水量解释。完整结果、逐代/逐查询记录与中英文论文在分阶段科研包内；指标和处理口径以对应源表与README为准。',
 '对照立项书2026年11—12月成果总结阶段拟定下列安排，具体日期按学校节点核定。':'主要模型计算已完成，下面安排侧重核对、必要补强、导师审阅及结题表达；具体日期按学校节点核定。',
 '执行顺序以各年模型可调用、基准复现通过为前提；正式敏感性、节水率与推荐灌溉方案须在真实模型实验完成后报告。':'四年真实模型与正式敏感性/优化均已运行。后续是否补做约束优化依实测与管理依据决定，不将现有候选直接作为田间灌水推荐。',
 '证据口径：2019—2021使用已核验的原始均值点输出，2022使用本轮原模型冻结均值点回放；本图属于校准拟合评价，不是独立验证。':'证据口径：四年原模型已贯通并完成冻结中心复现。图示为原校准配对与中心轨迹，不是独立验证，亦不是后验预测区间。',
 '48个CC配对均与各年逐日输出对应日期一致。2022资料完整性和原模型预审已通过；四年图均包含真实年度数据，不采用插值补位。源表位于随附evidence/four_year_source_data目录。':'48个CC配对均有对应日期的逐日模型结果，四年均有实际年度数据，不插值补位；原始配对位于02号年度包及11号图表包。',
 '四年共37个生物量配对。现有拟合支持过程描述与数值复现，不能据此提前给出正式Sobol参数排名、优化节水率、未知年份的普适灌溉制度或独立田间验证结论。下一阶段将完成真实模型敏感性与优化实验，再补充相应图表。':'四年共37个生物量配对，部分为论文图数字化。正式真实模型Sobol与优化现已完成，见后附图；高拟合仍不能替代独立验证或认证未知年份的普适制度。',
 "'new_MCMC_run':False,'full_real_Sobol_or_optimization_completed':False":"'historical_MCMC_rerun':False,'new_2021_conditional_pilots_completed':True,'full_real_Sobol_or_optimization_completed':True",
 '2019—2021使用已核验原输出；2022使用本轮原模型冻结均值点回放。以上均为校准拟合。':'四年原模型已贯通并复现，以上均为校准拟合。其他实际完成结果见附图与阶段科研包。',
}
for a,b in replacements.items():
    assert a in source,a
    source=source.replace(a,b)
exec(compile(source,str(OUT/'build_midterm_form.py'),'exec'),m.__dict__)
m.build()
from docx import Document
d=Document(OUT/'URP_midterm_report.docx')
attachments=[
 ('附件3  四年Sobol敏感性结果','R01_Sobol_four_outputs_2x2_EN.png','图3  四年八参数的总效应指数，产量、生物量、ET及最大冠层合并2×2。每格为三个N512设计均值，独立均匀输入范围。产量主要受晚期WP与HI0影响，平均排序一致不代表每年的贡献幅度完全相同。'),
 ('附件4  四年完整灌水—产量权衡','R03_full_range_diagnostic_2x2_EN.png','图4  四年全范围补充搜索显示低水量段与零灌溉，实线为最佳已找到包络，虚线为原比例剂量响应；未证明全局最优。原高产门槛局部图不能用来推断零灌溉也能稳产。'),
 ('附件5  减灌水量的来源','S07_Irrigation_reduction_decomposition_EN.png','图5  减灌水量按ET、季末储水与其他损失分解。2021年少灌约366.2 mm中，ET仅少约8.6 mm，主要是季末储水差。模型保产候选不等于已验证的田间节水制度。')]
for title,name,caption in attachments:
    d.add_page_break();m.para(d,title,14,True,after=12,keep=True)
    p=d.add_paragraph();m.fmt(p,10,after=5,align=m.WD_ALIGN_PARAGRAPH.CENTER);p.paragraph_format.line_spacing=1.;p.paragraph_format.keep_with_next=True
    p.add_run().add_picture(str(F/'figures'/name),width=m.Cm(16.5));m.para(d,caption,10.5,after=12)
    m.para(d,'原始结果、图像和逐图解析均按研究阶段提供。图为英文版，中文解释保留变量、单位、比较基准及适用边界。',10.5)
d.core_properties.subject='截至2026-10-21，主要模型计算完成；保留科学限制及待核实行政字段'
d.save(OUT/'URP_midterm_report.docx')
(OUT/'build_midterm_form.py').write_text(source,encoding='utf-8')
shutil.copy2(__file__,OUT/'build_midterm_final.py')
(OUT/'README.md').write_text('使用本次上传的中期报告DOC转换模板，保留封面与七项栏目。项目编号X2026100190937、人员与联系方式按立项文件及用户确认填入；按组长、李、段贡献顺序撰写分工，无虚构贡献百分比。\n\n主要计算模块已完成，报告已更新Sobol、NSGA-III/II、根深/覆膜/降水/水量和单目标验证。未声称所有长链收敛、已开展独立田间验证或已发表论文。\n\n实际报销额及明细、导师与专家意见和签字保留空白。预算5000元仅为申请预算，未当作实际报销。提交日期请按学校实际日期核定。\n',encoding='utf-8')
print('Updated administrative report and five evidence attachments')
