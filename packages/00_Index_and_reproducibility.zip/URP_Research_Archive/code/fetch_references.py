from pathlib import Path
import urllib.request, urllib.parse, json, concurrent.futures, time
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'stages/01_Raw_data_and_references/literature'
OUT.mkdir(parents=True,exist_ok=True)
DOIS=['10.1016/j.agwat.2025.109774','10.2134/agronj2008.0139s','10.2134/agronj2008.0140s','10.1016/j.agwat.2021.106976','10.2140/camcos.2010.5.65','10.1086/670067','10.1214/20-BA1221','10.1016/S0378-4754(00)00270-6','10.1016/j.cpc.2009.09.018','10.1109/4235.996017','10.1109/TEVC.2013.2281535','10.1023/A:1008202821328','10.32614/RJ-2013-002','10.1109/ACCESS.2020.2990567','10.1126/science.aat9314','10.1016/j.rse.2017.06.031']
def get(doi):
    url='https://api.crossref.org/works/'+urllib.parse.quote(doi,safe='')
    for attempt in range(3):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'URP-research-archive/1.0 (bibliography verification)'})
            with urllib.request.urlopen(req,timeout=35) as r: data=json.load(r)
            m=data['message']; (OUT/(doi.replace('/','_')+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
            return dict(doi=doi,title=m['title'][0],authors=[a.get('family','')+', '+a.get('given','') for a in m.get('author',[])],year=m.get('published',m.get('issued'))['date-parts'][0][0],journal=m.get('container-title',[''])[0],volume=m.get('volume',''),pages=m.get('page',m.get('article-number','')),url=m.get('URL',''),verified_from=url,status='verified',retrieved_date='2026-10-21')
        except Exception as e:
            err=str(e); time.sleep(1)
    return dict(doi=doi,status='FAILED',error=err)
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: rows=list(pool.map(get,DOIS))
    (OUT/'verified_references.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    for i,r in enumerate(rows,1):print(i,r.get('year'),r.get('title',r.get('error')))
