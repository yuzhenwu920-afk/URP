"""Short result paths improve Windows extraction; intact source ZIPs are retained."""
from pathlib import Path
import csv,hashlib,json
ROOT=Path(__file__).resolve().parents[1];ST=ROOT/'stages'
rows=[]
for yr in range(2019,2023):
    p=ST/f'02_MCMC_{yr}/Original_submitted_results'
    if not p.exists():continue
    for f in sorted(p.rglob('*')):
        if not f.is_file():continue
        old=f.relative_to(ST);parts=f.relative_to(p).parts
        if 'sampling' in parts:
            k=parts.index('sampling');tail=Path(*parts[k+1:]);dest=ST/f'02_MCMC_{yr}/Submitted_results/phase1'/tail
        elif 'phase2_and_review_results' in parts:
            k=parts.index('phase2_and_review_results');tail=Path(*parts[k+1:]);dest=ST/f'02_MCMC_{yr}/Submitted_results/phase2'/tail
        elif '01_MCMC结果包' in parts:
            dest=ST/f'02_MCMC_{yr}/Submitted_results/review'/f.name
        else:dest=ST/f'02_MCMC_{yr}/Submitted_inputs'/f.name
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():
            if hashlib.sha256(dest.read_bytes()).digest()==hashlib.sha256(f.read_bytes()).digest():f.unlink();continue
            dest=dest.with_name(hashlib.sha256(f.read_bytes()).hexdigest()[:8]+'_'+dest.name)
        f.rename(dest);rows.append({'original_staged_path':str(old),'short_staged_path':str(dest.relative_to(ST))})
    for d in sorted([d for d in p.rglob('*') if d.is_dir()],key=lambda x:len(x.parts),reverse=True):
        try:d.rmdir()
        except OSError:pass
    p.rmdir()
    (ST/f'02_MCMC_{yr}/CODE_ENTRYPOINTS.md').write_text(f'年度{yr}：OneClick_stage1_and_inputs/DI_{yr}_MCMC_ONE_CLICK.py内包含两阶段实现与打包入口，阶段二并非缺少；搜索PHASE2_NAMES、biomass_yield与phase2_handoff查看实现。\n\nSubmitted_results保留原检查点与输出，压缩包内部历史长路径已缩短，根目录verification/SHORT_PATH_RELOCATIONS.csv记录映射；原始上传ZIP完整保留在01号包。补充的2022独立阶段二入口见Supplemental_phase2/DI_2022_PHASE2_ONE_CLICK.py。\n\n2021额外review脚本只复核既有2000步，不意味着延长链或认证收敛。\n',encoding='utf-8')
# Shorten the long 2021 pilot container and each self-contained experiment folder.
p=ST/'07_2021_root1m_calibration_water_and_Pareto'
if p.exists():
    names={'urp_2021_root1m_mcmc_20261021':'Calibration','urp_2021_water_audit_20261021':'Water_audit','urp_2021_nsga3_pilot_20261021':'NSGA3','urp_2021_plateau_diagnosis_20261021':'Plateau_diagnosis'}
    for old,new in names.items():
        q=p/old
        if q.exists():q.rename(p/new);rows.append({'original_staged_path':str(q.relative_to(ST)),'short_staged_path':str((p/new).relative_to(ST))})
    dest=ST/'07_2021_root1m_pilots';p.rename(dest);rows.append({'original_staged_path':str(p.relative_to(ST)),'short_staged_path':str(dest.relative_to(ST))})
if rows:
    with (ROOT/'verification/SHORT_PATH_RELOCATIONS.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print('Shortened',len(rows),'paths; maximum stage-relative path',max(len(str(p.relative_to(ST))) for p in ST.rglob('*') if p.is_file()))
