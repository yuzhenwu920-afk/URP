from pathlib import Path
import json,hashlib,re,csv,zipfile,py_compile
import numpy as np,pandas as pd,fitz
from docx import Document
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parents[1];ST=ROOT/'stages';TB=ST/'11_English_figures_tables_and_interpretations/tables'
checks={}
def record(name,result,**kw):
    checks[name]=dict(passed=bool(result),**kw)
    if not result:raise AssertionError(name+': '+str(kw))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
    # All 20 formal checkpoint byte identities must still be present after extraction.
    expected=pd.read_csv('/workspace/urp_review/artifacts/tables/checkpoint_integrity.csv')
    have={sha(p):p for y in range(2019,2023) for p in (ST/f'02_MCMC_{y}').rglob('*.npz')}
    receipts=[]
    for r in expected.itertuples():
        p=have.get(r.SHA256);record(f'checkpoint_{r.Year}_{r.Phase}_{r.SHA256[:8]}',p is not None)
        with np.load(p,allow_pickle=False) as a:
            ar=a['history'] if 'history' in a.files else a['chain'];record(f'chain_shape_{r.SHA256[:8]}',ar.shape==(2000,32,5 if r.Phase==1 else 3) and np.isfinite(ar).all())
            receipts.append(dict(Year=int(r.Year),Phase=int(r.Phase),shape=list(ar.shape),sha256=r.SHA256,path=str(p.relative_to(ST))))
    record('formal_checkpoints',len(receipts)==20 and sum(r['Phase']==1 for r in receipts)==16)
    (ROOT/'verification/FORMAL_MCMC_CHECKPOINTS.json').write_text(json.dumps(receipts,indent=2))
    # Recompute process metrics from source pairs.
    perf=pd.read_csv(TB/'Table3_calibration_performance.csv').set_index('Year')
    for kind,name,o,s,rm,rr in [('CC','F02_CC_calibration_pairs.csv','CC_observed','CC_simulated','CC_RMSE','CC_R2_cal'),('B','F05_Biomass_calibration_pairs.csv','B_observed_t_ha','B_simulated_t_ha','Biomass_RMSE_t_ha','Biomass_R2_cal')]:
        pairs=pd.read_csv(TB/name)
        for y,g in pairs.groupby('Year'):
            x=g[o].to_numpy();z=g[s].to_numpy();rmse=np.sqrt(np.mean((z-x)**2));r2=1-np.sum((z-x)**2)/np.sum((x-x.mean())**2)
            record(f'calibration_{kind}_{y}',np.allclose([rmse,r2],[perf.loc[y,rm],perf.loc[y,rr]],atol=1e-12,rtol=0),N=len(g),RMSE=float(rmse),R2_cal=float(r2))
    sel=pd.read_csv(TB/'Table5_selected_candidates.csv');bal=sel.ET_reduction_mm+sel.Lower_final_soil_storage_mm+sel.Loss_reduction_mm+sel.Surface_storage_difference_mm+sel.External_inflow_adjustment_mm
    record('water_difference_decomposition',np.max(np.abs(bal-sel.Irrigation_reduction_mm))<1e-6,max_residual_mm=float(np.max(np.abs(bal-sel.Irrigation_reduction_mm))))
    record('storage_share',np.allclose(sel.Storage_difference_share_of_irrigation_reduction_pct,100*sel.Lower_final_soil_storage_mm/sel.Irrigation_reduction_mm,atol=1e-10,rtol=0))
    designs=[]
    for f in (ST/'04_Sobol_real_model/sobol_global_N512').glob('*_seed*/response_matrix.npy'):
        a=np.load(f,allow_pickle=False);record('Sobol_'+f.parent.name,a.shape==(5120,6) and np.isfinite(a).all());designs.append(a.shape[0])
    record('Sobol_final_calls',len(designs)==12 and sum(designs)==61440,actual_responses=sum(designs))
    op=list((ST/'05_Genetic_optimization_4years/optimization').glob('*/NSGA*_seed*/all_evaluations_columns.npz'))
    count=0
    for p in op:
        with np.load(p,allow_pickle=False) as z:
            ns=[v.shape[0] for k in z.files if (v:=z[k]).ndim>=1 and not k.startswith('_')]
            # The lossless archive keeps all evaluation columns, each of length 10,000.
            n=max(ns);record('optimization_'+p.parent.parent.name+'_'+p.parent.name,n==10000,rows=n);count+=n
    record('formal_optimization_calls',len(op)==40 and count==400000,archives=len(op),rows=count)
    figs=json.loads((ST/'11_English_figures_tables_and_interpretations/Final_revision/All_final_figure_interpretations.json').read_text())
    record('figure_coverage',len(figs)==103 and all((ST/f['PNG']).is_file() for f in figs))
    atlas=fitz.open(ST/'11_English_figures_tables_and_interpretations/Final_revision/URP_All_English_Figures_Final.pdf')
    cjk=[]
    for i,page in enumerate(atlas):
        found=re.findall(r'[\u4e00-\u9fff]',page.get_text())
        if found:cjk.append(dict(page=i+1,chars=''.join(found)))
    record('English_vector_figure_labels',not cjk,pages=len(atlas),CJK_text_found=cjk)
    documents=[]
    for lang in ['CN','EN']:
        f=ST/f'12_Chinese_and_English_manuscripts/URP_Manuscript_{lang}.docx';doc=Document(f)
        record('Word_counts_'+lang,len(doc.tables)==7 and len(doc.inline_shapes)==14,tables=len(doc.tables),inline_figures=len(doc.inline_shapes))
        for i,t in enumerate(doc.tables,1):
            b=t._tbl.tblPr.find(qn('w:tblBorders'));good=b is not None
            for edge in ['left','right','insideV','insideH']:good=good and b.find(qn('w:'+edge)).get(qn('w:val'))=='nil'
            for edge in ['top','bottom']:good=good and b.find(qn('w:'+edge)).get(qn('w:val'))=='single'
            good=good and t.cell(0,0)._tc.get_or_add_tcPr().find(qn('w:tcBorders')).find(qn('w:bottom')) is not None
            record('three_line_'+lang+'_'+str(i),good)
        pdf=fitz.open(f.with_suffix('.pdf'));imgs=sum(len(p.get_image_info()) for p in pdf);record('PDF_images_'+lang,imgs==14,actual_images=imgs,pages=len(pdf))
        clips=[]
        for i,p in enumerate(pdf):
            for inf in p.get_image_info():
                b=fitz.Rect(inf['bbox'])
                if b.x0<0 or b.y0<0 or b.x1>p.rect.width+.5 or b.y1>p.rect.height+.5:clips.append(i+1)
        record('PDF_image_bounds_'+lang,not clips,clipped_pages=clips)
        text='\n'.join(p.get_text() for p in pdf)
        record('references_'+lang,all(f'[{i}]' in text for i in range(1,15)))
        record('PDF_no_replacement_glyph_'+lang,'\ufffd' not in text)
        documents.append(dict(file=str(f.relative_to(ST)),pages=len(pdf),figures=imgs,tables=len(doc.tables),sha256=sha(f)))
    mid=Document(ST/'13_Project_midterm_report/URP_midterm_report.docx')
    tx='\n'.join(p.text for p in mid.paragraphs)+'\n'+'\n'.join(c.text for t in mid.tables for row in t.rows for c in row.cells)
    record('midterm_ID','X2026100190937' in tx)
    record('midterm_reimbursement_blank','已报销经费：____________元' in tx)
    record('midterm_completed_real_models','400000' in tx and '217084' in tx and '未将尚未实现' in tx)
    record('midterm_old_wrong_location_removed','吐哈盆地' not in tx)
    for f in (ROOT/'code').glob('*.py'):py_compile.compile(str(f),doraise=True)
    record('new_code_syntax',True)
    (ROOT/'verification/FINAL_SCIENTIFIC_AND_DOCUMENT_QA.json').write_text(json.dumps(dict(status='PASS',checks=checks,documents=documents,new_simulations_in_finalization=False,new_numerical_bootstrap_postprocessing=True),ensure_ascii=False,indent=2))
    print('Passed',len(checks),'checks; documents',documents)
