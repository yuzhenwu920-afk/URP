from pathlib import Path
import json,platform,importlib.metadata,hashlib,csv
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];ST=ROOT/'stages';FIG=ST/'11_English_figures_tables_and_interpretations';FINAL=FIG/'Final_revision'
if __name__=='__main__':
    sheets={}
    for p in sorted((ST/'12_Chinese_and_English_manuscripts/source').glob('Table_*.csv')):sheets[p.stem[:31]]=pd.read_csv(p)
    for name,p in [
        ('R02_year_mean_bootstrap',FINAL/'tables/R02_annual_scramble_mean_bootstrap.csv'),
        ('Pareto_display_points',FINAL/'tables/Pareto_display_points.csv'),
        ('Pareto_all_exact_solutions',FINAL/'tables/Pareto_nondominated_exact_solutions.csv'),
        ('Pooled_B_regression',FINAL/'tables/Pooled_biomass_OLS_summary.csv'),
        ('Pooled_B_all_pairs',FINAL/'tables/Pooled_biomass_observedX_simulatedY_pairs.csv'),
        ('Calibration_source_metrics',FIG/'tables/Table3_calibration_performance.csv'),
        ('Annual_water_budget',FIG/'tables/F09_annual_water_budget.csv'),
        ('MCMC_sampling',FIG/'tables/TableS2_MCMC_sampling.csv'),
        ('MCMC_boundary',FIG/'tables/parameter_intervals_verified.csv'),
        ('Sobol_all_seed_indices',FIG/'tables/Sobol_all_seed_indices.csv'),
        ('Sobol_annual_ranks',FIG/'tables/Sobol_annual_means_and_ranks.csv'),
        ('Sobol_year_rank_comparison',FIG/'tables/Sobol_year_pair_rank_agreement.csv'),
        ('Formal_original_candidates',FIG/'tables/Table5_selected_candidates.csv'),
        ('Original_actual_schedules',FIG/'tables/Original_main_NSGA_event_schedules.csv'),
        ('2021_mulch_calibration',ST/'08_2021_mulch_conditional_calibration_and_optimization/tables/Calibration_fit_metrics.csv'),
        ('2021_mulch_candidates',ST/'08_2021_mulch_conditional_calibration_and_optimization/tables/Selected_front_comparisons.csv'),
        ('Rainfall_four_year_comparison',ST/'09_Rainfall_and_data_provenance_audit/tables/Four_year_rainfall_comparison.csv'),
        ('Scalar_95pct_candidates',ST/'10_Single_objective_multi_algorithm_validation/tables/Overall_best_95pct_candidates.csv'),
        ('Scalar_independent_results',ST/'10_Single_objective_multi_algorithm_validation/tables/Independent_per_target_results.csv'),
        ('Scalar_refinement',ST/'10_Single_objective_multi_algorithm_validation/tables/Refinement_95pct_results.csv'),
        ('Figure_index',FINAL/'All_final_figure_index.csv')]:
        if not p.exists():raise FileNotFoundError(p)
        sheets[name]=pd.read_csv(p)
    with pd.ExcelWriter(FINAL/'URP_Final_Paper_Data.xlsx',engine='openpyxl') as writer:
        for name,df in sheets.items():
            df.to_excel(writer,sheet_name=name,index=False);ws=writer.sheets[name];ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            from openpyxl.styles import Font,Alignment,PatternFill
            for cell in ws[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='264653');cell.alignment=Alignment(wrap_text=True,vertical='center')
            ws.row_dimensions[1].height=36
            for col in ws.columns:
                letter=col[0].column_letter;mx=max([len(str(v.value or '')) for v in col[:80]])
                ws.column_dimensions[letter].width=min(max(mx+2,13),40)
    env={'Python':platform.python_version(),'Platform':platform.platform(),'packages':{}}
    for n in ['aquacrop','emcee','SALib','pymoo','scipy','numpy','pandas','matplotlib','python-docx','openpyxl','PyMuPDF','Pillow']:
        env['packages'][n]=importlib.metadata.version(n)
    (ROOT/'verification/BUILD_ENVIRONMENT.json').write_text(json.dumps(env,indent=2))
    (ROOT/'requirements-document-and-figures.txt').write_text('\n'.join(f'{n}=={v}' for n,v in env['packages'].items())+'\n')
    (ROOT/'USER_FIGURE_REQUIREMENTS.md').write_text('''# 本次用户指定的图表要求与落实

文件2：本次立项申报书PDF；文件4：手写图表要求；文件5：蓝虚线红点、四个水量标签的帕累托示例。原手写/示例像素仅在会话展示，要求在此完整转录，不伪称新上传文件。

- Figure 1：三列、浅底纹；另保留树状备选。正文图1已采用三列原英文矢量版。
- Figure 10环境：保留四年英文驱动，正文图2。
- F02/F04二选一：正文优先F02冠层过程；备选全部保留。
- F03/F05/F06二选一：正文优先F05生物量配对，其他保留补充。
- F07必须保留：正文图5含支持边界与分位区间，按数据披露边界集中，未强写“无撞墙”。
- F09：年度三线表示入流、出流和储水变化ΔS；绝对储水在源表，不与通量混用。
- F13拟合直线：正文图7为全部37个四年生物量配对，X=观测、Y=模拟，报告OLS R²及Pearson r。未定义Y_catmul/Y_tot不臆造新列。
- R01合并2×2：产量、生物量、ET、最大CC，Tr/Es另保留；讨论年度排序和幅度。
- R02：用户最后确认为URP_figures(5).zip/Figures/R02_Sobol_Yield_CI。正文图9合并四年S1/ST、数值区间及等权均值，不再假设cat/coc新变量。
- 优化：正文图10按文件5蓝虚线、红点、四窗口水量注记；四年2×2及四张单年高清版。标签整数仅用于显示，源表保留精确值。横轴mm，不能使用示例不合适的mm/ha。
- 论文：中英文各一份，所有绘图内容和图注为英文，主表三线；主图14组、主表7张。
''',encoding='utf-8')
    (ROOT/'RESEARCH_JOURNEY.md').write_text('''# 留给URP小组的研究记录

项目组把这段过程形容为一个半月内“四次重启、六次诊断”。这是团队对研究历程的回顾，不替代各阶段保存的执行日志或评估次数。

资料曾经缺年、观测与遥感处理标签需要区分，模型结构与水量来源也多次被重新审视。从作物和地点的选择，到气象提取、覆膜设定，再到排查被形容为“永生之地”的土壤水问题，真正留下的不是一条最漂亮的曲线，而是一套能追溯、能质疑、能修正的证据。

归档同时保存了成功计算、未充分收敛的记录、被作废的预检与后续解释。正式结果没有覆盖探索史，探索史也没有冒充正式证据。项目的完成可以包括承认哪些答案仍需要田间资料；这些限制不是要抹去的失败，而是让结论可信的边界。

感谢吴雨臻、李承昊、段璞及指导教师对问题的坚持。AI参与的是计算、整理与讨论；研究的选择、判断和责任属于项目组。愿这份资料能让接手者知道每个结果从何而来，也保留你们一路摸索的珍贵过程。
''',encoding='utf-8')
    (ROOT/'REPRODUCIBILITY.md').write_text('''# 使用与复现

1. 将各ZIP解压到同一个较短目录。每个包均以`URP_Research_Archive/`为根目录，合并后按`stages/`分阶段；同阶段分卷是独立标准ZIP，不需要特殊分卷工具。
2. 先读总README、阶段README及论文12号包。正式四年、2021条件试验与历史作废探索分开。
3. 运行环境见`verification/BUILD_ENVIRONMENT.json`及各阶段requirements。不要将.venv或字节码视作研究代码。用副本运行重计算，保留冻结记录。
4. 只重绘本轮图：`python code/final_figures.py`。需要04号响应矩阵和11号源表，未新增作物模型计算。
5. 重建中英文论文：`python code/build_manuscripts.py`；重建中期报告：`python code/build_midterm_final.py`。Word/PDF转换采用LibreOffice，PDF也已直接提供。
6. `python code/build_figure_guide.py`重建103组英文图索引与矢量图册；`python code/final_overview_and_workbook.py`生成总工作簿。
7. 四年MCMC：02各年度OneClick入口包含阶段一、二实现，2022还有独立补充阶段二入口。先阅读入口README与--help；保留的旧链不因重绘或归档变为已收敛。
8. 真实模型共享引擎在03，Sobol设计/响应在04，正式及全范围遗传记录在05；紧凑NPZ有LOSSLESS_REPACK.json说明，不是只存图片。新条件校准与每代记录在07/08，多算法每次查询在10。
9. `assemble_stages.py`为原工作区归档来源记录，不是重算模型入口；历史脚本可能保留执行时的绝对路径，使用其自包含模型快照或按MANIFEST查找对应文件。不要在不理解旧脚本写入位置时覆盖冻结输出。
10. 全部CSV/NPZ为计算证据。论文数字化近似、GEE元数据缺项、未取得的原始仪器序列与未认证收敛的结果，均按各阶段说明解释。原始上传ZIP内部命名保留；02解开结果使用短路径，映射见verification/SHORT_PATH_RELOCATIONS.csv。
''',encoding='utf-8')
    (ROOT/'MISSING_OR_UNCERTAIN_SOURCES.md').write_text('''# 未取得或待核定的来源，不以模拟补造

- 原始逐日雨量站电子序列与仪器全记录；当前提供GEE、论文图及近似数字化重建。
- 同期0—1m分层含水量原始时序；论文图保留，不声称已完成独立土壤水验证。
- GEE提取产品、ROI与时区完整导出元数据；遥感部分BI/DI处理标签存在差异。
- 全部引用论文的期刊全文：仅归档用户提供的参考论文与学位论文，其他提供书目/DOI和核对依据。
- 三份早期大合并ZIP超过32MiB传输限制，未能取得逐字节原件；已有分年原包、能下载的其他源包和现有工程分别归档，不声称三份大包原件已经复制。
- 最终投稿作者、通讯作者、资助与数据许可由作者确认；报销、导师/专家意见及签名按要求空白。
''',encoding='utf-8')
    print('Wrote workbook',len(sheets),'sheets and final usage/source notes')
