"""Create independent standard ZIPs below GitHub's individual-file limit."""
from pathlib import Path
import zipfile,hashlib,csv,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];ST=ROOT/'stages';DEL=ROOT/'delivery';DEL.mkdir(exist_ok=True)
PREFIX='URP_Research_Archive';LIMIT=90*1024*1024;TARGET=84*1024*1024
ROWS=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files(root):return [p for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}]
def writezip(path,items):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for p in items:z.write(p,PREFIX+'/'+str(p.relative_to(ROOT)))
    return path
def stage_manifest(stage):
    out=stage/'FINAL_PACKAGE_MANIFEST.csv';sums=stage/'FINAL_PACKAGE_SHA256SUMS.txt'
    items=[p for p in files(stage) if p not in [out,sums]]
    rows=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=sha(p)) for p in items]
    with out.open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    sums.write_text('\n'.join(r['sha256']+'  '+r['path'] for r in rows)+'\n')
def packstage(stage):
    stage_manifest(stage);items=files(stage);tmp=DEL/(stage.name+'.zip');writezip(tmp,items)
    if tmp.stat().st_size<LIMIT:
        groups=[(tmp,items)]
    else:
        with zipfile.ZipFile(tmp) as z:compressed={i.filename:i.compress_size+len(i.filename.encode('utf-8'))*2+150 for i in z.infolist()}
        parts=[];cur=[];size=0
        for p in items:
            n=compressed[PREFIX+'/'+str(p.relative_to(ROOT))]
            if cur and size+n>TARGET:parts.append(cur);cur=[];size=0
            cur.append(p);size+=n
        if cur:parts.append(cur)
        tmp.unlink();groups=[]
        for i,group in enumerate(parts,1):
            path=DEL/(stage.name+f'_part{i:02d}.zip');writezip(path,group);assert path.stat().st_size<LIMIT,path
            groups.append((path,group))
    for p,items in groups:
        ROWS.append(dict(stage=stage.name,filename=p.name,bytes=p.stat().st_size,files=len(items),sha256=sha(p)))
        print(p.name,round(p.stat().st_size/1e6,2),'MB',len(items),'files',flush=True)

if __name__=='__main__':
    qa=json.loads((ROOT/'verification/FINAL_SCIENTIFIC_AND_DOCUMENT_QA.json').read_text());assert qa['status']=='PASS'
    for stage in sorted(ST.iterdir()):
        if stage.is_dir():packstage(stage)
    docs=ST/'12_Chinese_and_English_manuscripts';mid=ST/'13_Project_midterm_report';final=ST/'11_English_figures_tables_and_interpretations/Final_revision'
    convenient=[]
    for p in [docs/'URP_Manuscript_CN.docx',docs/'URP_Manuscript_EN.docx',docs/'URP_Manuscript_CN.pdf',docs/'URP_Manuscript_EN.pdf',mid/'URP_midterm_report.docx',mid/'URP_midterm_report.pdf',final/'URP_Final_Paper_Data.xlsx',final/'URP_All_Figure_Interpretations.docx',final/'URP_All_Figure_Interpretations.pdf',final/'URP_All_English_Figures_Final.pdf']:
        shutil.copy2(p,DEL/p.name);convenient.append(p)
    p=writezip(DEL/'URP_Final_Documents_and_Figure_Atlas.zip',convenient);assert p.stat().st_size<LIMIT
    ROWS.append(dict(stage='Convenience copy: documents and atlas',filename=p.name,bytes=p.stat().st_size,files=len(convenient),sha256=sha(p)))
    stats={'scientific_stages':len(list(ST.iterdir())),'stage_files':sum(1 for p in ST.rglob('*') if p.is_file()),'English_figure_groups':103,'vector_atlas_pages':104,'Word_manuscripts':[{'language':'Chinese','figures':14,'three_line_tables':7,'pages':qa['documents'][0]['pages']},{'language':'English','figures':14,'three_line_tables':7,'pages':qa['documents'][1]['pages']}],'midterm_pages':10,'final_workbook_sheets':28,'formal_MCMC_checkpoints':20,'scientific_document_checks_passed':len(qa['checks']),'historical_MCMC_reexecuted_in_finalization':False,'heavy_crop_optimization_reexecuted_in_finalization':False,'new_bootstrap_postprocessing':True}
    (ROOT/'DELIVERY_SUMMARY.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
    (ROOT/'README.md').write_text('''# URP科研收官归档 · 2026-10-21

本套材料整理当前能取得的原始资料、参考论文、四年MCMC两阶段代码/结果、真实模型Sobol、遗传优化、逐代与逐查询记录，以及后续根深/覆膜/储水/降水/算法诊断。完整下载目录在GitHub原交付分支的新日期目录中；主分支不变。

## 先看这些

- 12号包：中英文完整论文初稿，各14组英文图和7张三线表；不是仅有框架。中文24页、英文22页，最终以PDF为准。
- 13号包：按本次模板填写的中期报告，主要模型计算已完成；报销金额、导师/专家意见与签字仍留空。
- 11号包：103组英文图及解析索引，104页矢量图册、600dpi PNG/PDF/SVG、28页签总数据工作簿和原始源表。四年主图均含2019—2022实际年度数据。
- 02各年度包：原正式20组MCMC检查点、两阶段实现和补充诊断。2022完整阶段二已保留。
- 04/05：真实模型设计、响应、正式NSGA-II/III及全范围补充的完整数字记录；不是仅存图片。
- 06—10：结构与根深、2021短链/水分、覆膜三情景、降水及单目标多算法验证。
- 14：额外历史唯一文件、旧版和作废探索，明确不作为正式结果。

## 使用方式

各ZIP为独立标准压缩包；同阶段分卷解压到同一目录，共用`URP_Research_Archive/`根目录。详细入口见REPRODUCIBILITY.md。原始上传版本按SHA256保留，工作资料已做短路径整理与内容去重，全部对应关系在verification清单。

当前目录以FINAL_PACKAGE_MANIFEST/FINAL_PACKAGE_SHA256SUMS及GLOBAL_FILE_MANIFEST为准；旧执行清单保留历史时点，不因归档新增README等而代表当前完整目录。

## 结论边界

四年历史root2.3m/fMulch0与2021 root1m的条件覆膜试验分别报告。部分MCMC未充分收敛、参数有边界邻近集中；95%是产量水平，不是达标概率。大减灌主要对应较低季末储水，不等同等幅ET下降或已验证的田间定额。原始日雨量/仪器资料未取得处及三份超限总合并ZIP在MISSING_OR_UNCERTAIN_SOURCES.md说明，不以模拟补造。当前论文为作者审阅前的完整初稿。

项目组的四次重启、六次诊断等研究回顾保存在RESEARCH_JOURNEY.md；科学结论以可追溯计算记录为准。
''',encoding='utf-8')
    rootitems=[p for p in ROOT.iterdir() if p.is_file() and p.name!='GLOBAL_FILE_MANIFEST.csv']
    indexitems=rootitems+files(ROOT/'code')+files(ROOT/'verification')
    manifestitems=files(ST)+[p for p in indexitems if p.name!='GLOBAL_FILE_MANIFEST.csv']
    with (ROOT/'GLOBAL_FILE_MANIFEST.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['path','bytes','sha256']);w.writeheader()
        for p in sorted(manifestitems):w.writerow(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)))
    indexitems.append(ROOT/'GLOBAL_FILE_MANIFEST.csv')
    p=writezip(DEL/'00_Index_and_reproducibility.zip',indexitems)
    ROWS.insert(0,dict(stage='00_Index_and_reproducibility',filename=p.name,bytes=p.stat().st_size,files=len(indexitems),sha256=sha(p)))
    checks=[]
    for r in ROWS:
        p=DEL/r['filename']
        with zipfile.ZipFile(p) as z:
            err=z.testzip();assert err is None,(p,err)
            assert len(z.infolist())==r['files'];assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
        checks.append(dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p),ZIP_CRC='PASS'))
    (DEL/'ARCHIVE_VALIDATION.json').write_text(json.dumps({'status':'PASS','zip_count':len(checks),'archives':checks,'research_summary':stats},ensure_ascii=False,indent=2))
    with (DEL/'PACKAGE_INDEX.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=ROWS[0]);w.writeheader();w.writerows(ROWS)
    base='https://raw.githubusercontent.com/yuzhenwu920-afk/URP/refs/heads/delivery/urp-review-20261015/deliverables/2026-10-21-final-research-archive/'
    readme=['# URP最终科研资料与论文下载','',f'共{len(ROWS)}个ZIP（含1个文稿速取副本），按17个科研阶段整理；所有压缩包均通过ZIP CRC与SHA256校验。','',
       '**建议先下载：[论文、中期报告与总图册速取包]('+base+'URP_Final_Documents_and_Figure_Atlas.zip)。** 完整研究资料请下载00索引和全部01—14阶段包；速取包不能替代完整阶段数据。','',
       '[中文论文Word]('+base+'URP_Manuscript_CN.docx) · [英文论文Word]('+base+'URP_Manuscript_EN.docx) · [中期报告Word]('+base+'URP_midterm_report.docx)','',
       '[中文PDF]('+base+'URP_Manuscript_CN.pdf) · [英文PDF]('+base+'URP_Manuscript_EN.pdf) · [中期报告PDF]('+base+'URP_midterm_report.pdf)','',
       '[103组英文图册]('+base+'URP_All_English_Figures_Final.pdf) · [逐图解析Word]('+base+'URP_All_Figure_Interpretations.docx) · [28页签数据工作簿]('+base+'URP_Final_Paper_Data.xlsx)','',
       '四年主图均含2019—2022数据；两篇论文各14组图、7张三线表。历史四年设定与后续2021试验分开解释；论文为完整初稿，未认证充分收敛或独立田间适用性。','',
       '各分卷均可独立解压，合并到同一个`URP_Research_Archive`目录。请使用这里的GitHub下载链接，无需聊天构件下载。','',
       '|阶段|压缩包（点击下载）|大小 MB|文件数|','|---|---|---:|---:|']
    for r in ROWS:readme.append(f'|{r["stage"]}|[{r["filename"]}]({base+r["filename"]})|{r["bytes"]/1e6:.1f}|{r["files"]}|')
    readme += ['','文件组成与不足：原件和可追溯模型结果均保留；未取得的原始日雨量/仪器序列与三份超限总合并ZIP在00包说明，不以重建值冒充原始实测。报销与签字意见空白。',
       '','[压缩包校验记录](ARCHIVE_VALIDATION.json) · [文件下载清单](PACKAGE_INDEX.csv) · [SHA256](SHA256SUMS.txt)','',
       '主分支保持不变，交付分支为`delivery/urp-review-20261015`。']
    (DEL/'README.md').write_text('\n'.join(readme)+'\n',encoding='utf-8')
    shutil.copy2(ROOT/'verification/FINAL_SCIENTIFIC_AND_DOCUMENT_QA.json',DEL/'SCIENTIFIC_DOCUMENT_QA.json')
    shutil.copy2(ROOT/'RESEARCH_JOURNEY.md',DEL/'RESEARCH_JOURNEY.md')
    shutil.copy2(final/'figures/R03_Pareto_four_years_annotated_EN.png',DEL/'Preview_Four_year_Pareto_EN.png')
    allfiles=[p for p in files(DEL) if p.name!='SHA256SUMS.txt']
    (DEL/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in allfiles)+'\n')
    print('COMPLETE',len(ROWS),'ZIPs',round(sum(r['bytes'] for r in ROWS)/1e6,1),'MB; all CRC PASS',flush=True)
