"""Keep unique earlier working material once, with a source-to-canonical map."""
from pathlib import Path
import hashlib,csv,shutil,json
ROOT=Path(__file__).resolve().parents[1];ST=ROOT/'stages';WS=Path('/workspace')
BAD={'.git','.venv','__pycache__','.cache','.mplcache','node_modules'}
def bad(p):return any(x in BAD or x.startswith('lo_') for x in p.parts) or p.suffix in {'.pyc','.pyo','.zip'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
    seen={}
    for p in ST.rglob('*'):
        if p.is_file():seen.setdefault(sha(p),str(p.relative_to(ST)))
    roots=sorted([p for p in WS.glob('urp_*') if p.is_dir() and p!=ROOT])
    # Canonical real-model source and execution records are included, while
    # raw journals already preserved in documented lossless NPZ are not duplicated.
    roots.append(WS/'URP/DI_PHASE3_NEXTGEN_UPDATED')
    rows=[];added=0;size=0;skips=[]
    extra=ST/'14_Research_history_NOT_primary_results/Additional_unique_materials'
    for root in roots:
        for p in sorted(root.rglob('*')):
            if not p.is_file() or bad(p.relative_to(root)):continue
            h=sha(p)
            if h in seen:
                rows.append(dict(original_path=str(p),sha256=h,bytes=p.stat().st_size,canonical_stage_path=seen[h],status='same_bytes_present'));continue
            # Full journals can be rebuilt from the lossless compact archive.
            if p.name in {'responses.jsonl','evaluations.jsonl','evaluations.csv'} and '/output_real_20261019/' in str(p):
                skips.append(dict(original_path=str(p),sha256=h,bytes=p.stat().st_size,reason='Numerical records are preserved in documented lossless compact_results NPZ; original encoding omitted to avoid duplicating the same evaluation set.'));continue
            dest=extra/(p.suffix.lstrip('.') or 'no_extension')/(h[:14]+'_'+p.name[:100])
            dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);seen[h]=str(dest.relative_to(ST));added+=1;size+=p.stat().st_size
            rows.append(dict(original_path=str(p),sha256=h,bytes=p.stat().st_size,canonical_stage_path=seen[h],status='additional_unique_history'))
    with (ROOT/'verification/WORKSPACE_SOURCE_COVERAGE.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    (ROOT/'verification/LOSSLESS_EQUIVALENT_JOURNAL_ENCODINGS.json').write_text(json.dumps(skips,indent=2))
    (extra/'README.md').write_text('这里按内容SHA256保存此前工作目录中的其他唯一文件；原路径对应关系见根目录verification/WORKSPACE_SOURCE_COVERAGE.csv。相同字节只保存一份，正式科学结果以相应阶段包为准。\n\n可能包含旧版论文、代理探索、准备性设计、图表草稿与代码版本；不把历史版本的待办/节水率当成当前结论。原始大JSONL已无损编码成NPZ的部分，以LOSSLESS_REPACK.json和紧凑数据为准，避免重复同一数字记录。依赖环境、编译缓存、LibreOffice缓存和已打包交付ZIP未重复归档。\n',encoding='utf-8')
    print('Source files indexed',len(rows),'additional unique',added,'MB',round(size/1e6,1),'lossless journal encodings omitted',len(skips))
