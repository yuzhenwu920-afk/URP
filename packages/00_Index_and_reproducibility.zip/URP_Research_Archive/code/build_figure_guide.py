from pathlib import Path
import json,csv,hashlib,re
import pandas as pd,fitz
from docx import Document
from build_manuscripts import style,para,heading
ROOT=Path(__file__).resolve().parents[1];ST=ROOT/'stages';BASE=ST/'11_English_figures_tables_and_interpretations'
OUT=BASE/'Final_revision';ALL=[];seen=set()
old=json.loads((BASE/'analysis/FIGURE_INTERPRETATIONS.json').read_text());OLD={r['name']:r for r in old}
def add(folder,r):
    name=r.get('name',r.get('ID',r.get('Figure_ID','')))
    png=folder/'figures'/(name+'.png');pdf=png.with_suffix('.pdf')
    if not png.exists():return
    sha=hashlib.sha256(pdf.read_bytes() if pdf.exists() else png.read_bytes()).hexdigest()
    if sha in seen:return
    seen.add(sha)
    o=OLD.get(name,{})
    cap=r.get('caption_EN',r.get('caption',r.get('English_caption',r.get('Caption_EN',''))))
    cn=r.get('Interpretation_CN',r.get('Analysis_CN',r.get('Interpretation',o.get('finding',''))))
    boundary=r.get('Boundary_CN',r.get('Boundary',o.get('limitations','')))
    source=r.get('source_tables',r.get('Source_tables',r.get('sources',o.get('source_tables',[]))))
    if name.startswith('R02_'):boundary=boundary.replace('cat/coc尚无定义。','原图已由用户确认为R02_Sobol_Yield_CI，按S1/ST与数值区间呈现。')
    if not cn:
        if name.startswith('F13_Pooled'):cn='四年37个生物量配对；横轴观测、纵轴模拟，OLS与1:1关系分开。R²和Pearson r反映配对关联，不是独立验证。'
        elif name.startswith('R02_Sobol_Yield_CI_'):cn='四年S1/ST及数值bootstrap区间合并，保留四年等权均值和年际范围；完整响应块重采样，无新增模型调用。'
        elif name.startswith('R03_Pareto'):cn='按示例的蓝虚线、红点和四窗口水量标签整理。采用四年历史参数的全范围补充搜索，不能混称根深1m重校准或正式有门槛搜索。'
        elif '/09_' in str(folder):cn='核对GEE与论文图近似降水，区分原始观测、图数字化和模型水量输入。固定参数替换用于检验驱动敏感性，未重新优化。'
        elif '/10_' in str(folder):cn='比较给定产量门槛下的最小实际灌水；算法预算、三个种子和档案规则按英文图注解释。数值一致不代表物理或田间验证。'
    if not cap:cap=r.get('Title',r.get('title',''))+'. See the associated source tables and stage report for precise definitions.'
    if not boundary:boundary='须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。'
    ALL.append(dict(Figure_ID=name,Stage=str(folder.relative_to(ST)),PNG=str(png.relative_to(ST)),PDF=str(pdf.relative_to(ST)) if pdf.exists() else '',Title=r.get('title',r.get('Title',r.get('English_title',''))),English_caption=cap,Analysis_CN=cn,Boundary_CN=boundary,Source_tables=source))
if __name__=='__main__':
    # Main figure collection first; then original diagnostic sequence, without duplicate PDFs.
    regpaths=[BASE/'FIGURE_REGISTRY.json',OUT/'FIGURE_REGISTRY.json']
    for dr in ['06_Structural_and_root_depth_diagnostics','07_2021_root1m_pilots','08_2021_mulch_conditional_calibration_and_optimization']:
        regpaths+=sorted((ST/dr).rglob('FIGURE_REGISTRY.json'))
    regpaths+=list((ST/'06_Structural_and_root_depth_diagnostics').rglob('FIGURE_INTERPRETATIONS.json'))
    for p in regpaths:
        x=json.loads(p.read_text());rows=x if isinstance(x,list) else x['figures']
        for r in rows:add(p.parent,r)
    for dr in ['09_Rainfall_and_data_provenance_audit','10_Single_objective_multi_algorithm_validation']:
        for r in pd.read_csv(ST/dr/'tables/Figure_captions.csv').fillna('').to_dict('records'):add(ST/dr,r)
    (OUT/'All_final_figure_interpretations.json').write_text(json.dumps(ALL,ensure_ascii=False,indent=2))
    pd.DataFrame(ALL).to_csv(OUT/'All_final_figure_index.csv',index=False)
    doc=Document();style(doc,'CN');heading(doc,'URP全套英文图逐图解析与源表索引','CN',1)
    para(doc,'本索引按研究阶段收录可取得的正式英文图及诊断图。每图包含英文图注、中文分析、适用边界和源表。旧文件F/R/S编号用于追溯，最终论文重新编号为Figure 1—14。R02已按用户确认的原CI图解释；四年回归和新前沿另有本轮修订。','CN')
    md=['# URP全套英文图逐图解析','']
    atlas=fitz.open();cover=atlas.new_page(width=595,height=842)
    cover.insert_text((40,65),'URP: English Figure Atlas',fontsize=22);cover.insert_text((40,100),'2019-2022 DI maize | 21 October 2026',fontsize=12)
    cover.insert_textbox(fitz.Rect(40,135,550,750),'Original IDs are preserved for traceability. Main-manuscript figure numbers differ.\n\nThe accompanying CSV/Word guide provides captions, source tables and interpretation boundaries.\n\nHistorical four-year results (Zmax 2.30 m, fMulch 0) are separate from 2021 root-depth/mulch pilots. Numerical verification is not field validation.\n\nFull-resolution PNG, PDF and SVG files remain in their scientific-stage packages.',fontsize=12)
    for i,a in enumerate(ALL,1):
        heading(doc,f'{i}. {a["Figure_ID"]}','CN',2)
        for lab,k in [('阶段','Stage'),('English caption','English_caption'),('解析','Analysis_CN'),('解释边界','Boundary_CN')]:para(doc,lab+'：'+a[k],'CN',10)
        src=', '.join(a['Source_tables']) if isinstance(a['Source_tables'],list) else str(a['Source_tables'])
        para(doc,'源表：'+src,'CN',9);para(doc,'图像：stages/'+a['PNG'],'CN',9)
        md += [f'## {i}. {a["Figure_ID"]}','',a['English_caption'],'','解析：'+a['Analysis_CN'],'','边界：'+a['Boundary_CN'],'','源表：'+src,'','图像：'+a['PNG'],'']
        if a['PDF']:
            with fitz.open(ST/a['PDF']) as f:atlas.insert_pdf(f)
    doc.save(OUT/'URP_All_Figure_Interpretations.docx');(OUT/'URP_All_Figure_Interpretations.md').write_text('\n'.join(md),encoding='utf-8')
    atlas.save(OUT/'URP_All_English_Figures_Final.pdf',garbage=4,deflate=True)
    print('Indexed',len(ALL),'English figure groups; vector atlas',len(atlas),'pages')
