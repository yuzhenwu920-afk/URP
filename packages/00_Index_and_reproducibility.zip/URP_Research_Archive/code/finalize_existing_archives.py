"""Refresh the index and checksum sidecars after archive generation."""
from pathlib import Path
import json,csv,shutil,zipfile,hashlib
from package_delivery import ROOT,ST,DEL,files,sha,writezip
if __name__=='__main__':
    final=ST/'11_English_figures_tables_and_interpretations/Final_revision'
    shutil.copy2(final/'figures/R03_Pareto_four_years_annotated_EN.png',DEL/'Preview_Four_year_Pareto_EN.png')
    rootitems=[p for p in ROOT.iterdir() if p.is_file() and p.name!='GLOBAL_FILE_MANIFEST.csv']
    indexitems=rootitems+files(ROOT/'code')+files(ROOT/'verification')
    with (ROOT/'GLOBAL_FILE_MANIFEST.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['path','bytes','sha256']);w.writeheader()
        for p in sorted(files(ST)+indexitems):w.writerow(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)))
    indexitems.append(ROOT/'GLOBAL_FILE_MANIFEST.csv')
    p=writezip(DEL/'00_Index_and_reproducibility.zip',indexitems)
    rows=list(csv.DictReader((DEL/'PACKAGE_INDEX.csv').open(encoding='utf-8-sig')))
    for row in rows:
        if row['filename']==p.name:row.update(bytes=p.stat().st_size,files=len(indexitems),sha256=sha(p))
    with (DEL/'PACKAGE_INDEX.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    readme=(DEL/'README.md').read_text();lines=readme.splitlines()
    rr=next(r for r in rows if r['filename']==p.name)
    for i,line in enumerate(lines):
        if line.startswith('|00_Index_and_reproducibility|'):
            fields=line.split('|');fields[-3]=f'{p.stat().st_size/1e6:.1f}';fields[-2]=str(len(indexitems));lines[i]='|'.join(fields)
    (DEL/'README.md').write_text('\n'.join(lines)+'\n')
    validation=json.loads((DEL/'ARCHIVE_VALIDATION.json').read_text())
    for row in validation['archives']:
        if row['file']==p.name:row.update(bytes=p.stat().st_size,sha256=sha(p))
    with zipfile.ZipFile(p) as z:assert z.testzip() is None
    (DEL/'ARCHIVE_VALIDATION.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
    actual={p.name for p in DEL.glob('*.zip')};assert actual=={r['filename'] for r in rows},actual
    assert all(sha(DEL/r['filename'])==r['sha256'] for r in rows)
    expected={r['path']:r for r in csv.DictReader((ROOT/'GLOBAL_FILE_MANIFEST.csv').open(encoding='utf-8-sig'))}
    found=set();members=0
    for row in rows:
        if row['filename']=='URP_Final_Documents_and_Figure_Atlas.zip':continue
        with zipfile.ZipFile(DEL/row['filename']) as z:
            for info in z.infolist():
                rel=info.filename.removeprefix('URP_Research_Archive/')
                if rel=='GLOBAL_FILE_MANIFEST.csv':continue
                assert rel in expected,rel
                with z.open(info) as inp:
                    h=hashlib.sha256()
                    while data:=inp.read(1024*1024):h.update(data)
                assert h.hexdigest()==expected[rel]['sha256'],rel
                found.add(rel);members+=1
    assert found==set(expected),set(expected)-found
    (DEL/'CONTENT_MANIFEST_VALIDATION.json').write_text(json.dumps(dict(status='PASS',manifest_files=len(expected),unique_archive_files=len(found),checked_members=members,all_stage_and_index_members_matched_SHA256=True),indent=2))
    (DEL/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in files(DEL) if p.name!='SHA256SUMS.txt')+'\n')
    print('FINAL DELIVERY',len(rows),'ZIPs',round(sum((DEL/r['filename']).stat().st_size for r in rows)/1e6,1),'MB;',len(files(DEL)),'download files; checksums verified')
