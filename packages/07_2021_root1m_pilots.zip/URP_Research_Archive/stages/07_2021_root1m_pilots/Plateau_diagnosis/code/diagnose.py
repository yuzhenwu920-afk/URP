"""Fixed-parameter physiological traces; no fitting or optimization."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
BASE=Path('/workspace/urp_2021_fmulch_comparison_20261021');OUT=Path(__file__).resolve().parents[1];T=OUT/'tables'
sys.path.insert(0,str(BASE/'code'))
import trace_scenarios
from trace_scenarios import TraceEngine
from scenario_engine import SCENARIOS
trace_scenarios.T=T

def summarize(sc,label,d,s):
    active=d.Tr_potential_actual_canopy_mm>1e-8;tadj=d.DAP-d.Delayed_days
    reproductive=active&(tadj>=d.HIstart_dap)&(tadj<d.Senescence_dap)
    row=dict(Scenario=sc,fMulch=SCENARIOS[sc],Control=label,Irrigation_mm=s['Irrigation_mm'],Y13=s['Y_13pct'],ET_mm=s['ET_mm'],Tr_mm=s['Tr_mm'],Es_mm=s['Es_mm'],Root_initial_mm=s['Root1m_initial_mm'],Root_final_mm=s['Root1m_final_mm'],Root_depletion_mm=s['Root1m_initial_mm']-s['Root1m_final_mm'],Mean_effective_HI=float(d.HI_adjusted.iloc[-1]),Calendar_days=len(d),Model_HIstart_dap=float(d.HIstart_dap.iloc[0]),Model_senescence_dap=float(d.Senescence_dap.iloc[0]))
    for key,mask in [('Season',active),('HIstart_to_senescence',reproductive)]:
        a=d[mask];k=a.Ks_sto_linear_computed.dropna()
        row.update({key+'_eligible_days':len(a),key+'_stomatal_Ks_min':k.min(),key+'_stomatal_days_lt095':int((k<.95).sum()),key+'_stomatal_equivalent_days':float((1-k).sum()),key+'_Tr_mm':float(a.Tr.sum()),key+'_actual_to_canopy_potential_Tr':float(a.Tr.sum()/a.Tr_potential_actual_canopy_mm.sum()),key+'_mean_CC':float(a.CC.mean())})
        rz=a.Tr_root_Dr_before_mm/a.Tr_root_TAW_before_mm;tz=a.Tr_top_Dr_before_mm/a.Tr_top_TAW_before_mm
        row[key+'_maximum_root_relative_depletion']=float(rz.max());row[key+'_topsoil_selected_days']=int((tz<rz).sum())
    return row

def main():
    existing=pd.read_csv(BASE/'tables/All_stress_storage_summaries.csv');opt=pd.read_csv(BASE/'tables/Optimized_candidate_stress_summaries.csv');summaries=[];extra=[]
    for sc in SCENARIOS:
        e=TraceEngine(sc,True,tag='plateau_diagnosis')
        for amount in [300,350,500]:
            label=f'{sc}_I{amount}';row=e.trace(label,float(amount));extra.append(dict(row,Scenario=sc,fMulch=SCENARIOS[sc],Control=f'Proportional_{amount}'))
            d=pd.read_csv(T/(label+'_daily.csv'));summaries.append(summarize(sc,f'Proportional_{amount}',d,row))
        for label,name in [('I400','Proportional_400'),('I100','Proportional_633.47')]:
            s=existing[existing.Scenario.eq(sc+'_'+label)].iloc[0];d=pd.read_csv(BASE/'tables'/(sc+'_'+label+'_daily.csv'));summaries.append(summarize(sc,name,d,s))
        for label,name in [('Opt95','Optimized_95pct'),('OptOwnDI','Optimized_own_DI')]:
            s=opt[opt.Scenario.eq(sc+'_'+label)].iloc[0];d=pd.read_csv(BASE/'tables'/(sc+'_'+label+'_daily.csv'));summaries.append(summarize(sc,name,d,s))
    a=pd.DataFrame(summaries)
    for sc in SCENARIOS:
        b=a[a.Scenario.eq(sc)&a.Control.eq('Proportional_633.47')].iloc[0];m=a.Scenario.eq(sc)
        a.loc[m,'Y13_fraction_of_own_DI']=a.loc[m,'Y13']/b.Y13;a.loc[m,'Tr_fraction_of_own_DI']=a.loc[m,'Tr_mm']/b.Tr_mm;a.loc[m,'Extra_root_depletion_vs_DI_mm']=b.Root_final_mm-a.loc[m,'Root_final_mm']
    a.to_csv(T/'Physiological_plateau_comparison.csv',index=False);pd.DataFrame(extra).to_csv(T/'Additional_exact_dose_replays.csv',index=False)
    status=dict(Status='PASS',New_exact_dose_trajectories=9,Daily_rows_per_trajectory=148,Scenarios=SCENARIOS,Calibration_reruns=0,Optimization_reruns=0,Parameters_changed=False,Scope='2021 root1m selected 500-step pilot parameters; diagnostic only, separate from old four-year figure',Reproductive_window='Model HIstart to senescence; not measured phenology',Observer_and_plain_replay_match='<=1e-8',Daily_mass_balance='<=1e-7mm')
    (OUT/'CHECK.json').write_text(json.dumps(status,ensure_ascii=False,indent=2));print(a[['fMulch','Control','Y13','Y13_fraction_of_own_DI','Tr_fraction_of_own_DI','Extra_root_depletion_vs_DI_mm','HIstart_to_senescence_stomatal_days_lt095','HIstart_to_senescence_actual_to_canopy_potential_Tr']].to_string(index=False));print(json.dumps(status,indent=2))
if __name__=='__main__':main()
