"""Read-only replay of selected calibrated pilot points; no recalibration."""
from pathlib import Path
import sys,json,importlib.util,copy
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from pilot_engine import load,PROJECT
_,m,data,p=load(True,'wuwei_stock_check')
p=json.loads((ROOT/'tables/SELECTED_PILOT_PARAMETERS.json').read_text())
spec=importlib.util.spec_from_file_location('stock_adapter',PROJECT/'real_model/four_year_adapter.py');adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter);adapter.STATES[2021]=(m,data)
space=adapter.management_space(2021);base=np.array(space['baseline_amounts'])
rows=[];a=pd.read_csv(ROOT/'tables/Yield_irrigation_curve_0_to_observed.csv')
original=m.AquaCropModel._perform_timestep
for i in [0,100,126,150,200]:
 target=a.iloc[i];daily=[];prof=data['soil'].profile;weights=np.clip(1-prof.z_top.to_numpy(float),0,prof.dz.to_numpy(float))*1000
 def observe(model):
  result=original(model);clock,cond,param,out=result
  daily.append(dict(Rootzone_stock_mm=float(np.dot(cond.th,weights)),Below_root_stock_mm=float(np.dot(cond.th,prof.dz.to_numpy(float)*1000-weights)),Root_depth_m=float(cond.z_root)))
  return result
 m.AquaCropModel._perform_timestep=observe
 adapter._template.cache_clear()
 try:
  control=dict(kind='stage_amounts',values=dict(zip(space['names'],base*target.Fraction_of_DI)))
  s,w,g=adapter.simulate(params=p,year=2021,management=control,details=True)
 finally:m.AquaCropModel._perform_timestep=original;adapter._template.cache_clear()
 z=pd.DataFrame(daily);initial=float(np.dot(data['theta'],weights));below=float(np.dot(data['theta'],prof.dz.to_numpy(float)*1000-weights))
 rows.append(dict(Point=i,Irrigation_mm=s['Irrigation_mm'],Y13_t_ha=s['Y_13pct'],ET_mm=s['ET_mm'],Rootzone_initial_mm=initial,Rootzone_final_mm=z.Rootzone_stock_mm.iloc[-1],Rootzone_change_mm=z.Rootzone_stock_mm.iloc[-1]-initial,
  Below_root_initial_mm=below,Below_root_final_mm=z.Below_root_stock_mm.iloc[-1],Below_root_change_mm=z.Below_root_stock_mm.iloc[-1]-below,
  Whole_profile_change_mm=s['Profile_final_mm']-s['Profile_initial_mm'],Maximum_root_m=z.Root_depth_m.max()))
r=pd.DataFrame(rows);r.to_csv(ROOT/'diagnosis_wuwei/Rootzone_storage_replays.csv',index=False);print(r.to_string(index=False))
