# 2026-10-16新增材料复核与论文修订
先读URP_20261016_复核与变更说明.pdf，再使用URP_20261016_论文框架_确定性主线.docx。
本轮主线为确定性研究，不要求伪联合后验。29个中心值已核验，2022阶段二3个值仍是报告值。采样表按整组最大tau向上取整修正。7张图含6张新绘、1张沿用的已核验校准图。
本轮没有执行真实模型Sobol/NSGA-III。新增文件没有交付文字所述恢复的模型源码、2022原始阶段二链，参考PDF亦只有PC路径与哈希。请以RUN_READINESS.json和证据标签为准。
submitted/为本次原件，tables/为来源与数值核查，figures/同时有300dpi PNG和矢量PDF。build_revision.py为新增脚本，在本云环境用/workspace/urp_review/.venv/bin/python运行；依赖原/workspace/urp_review/data和artifacts，不独立包含旧原始数据。
旧交付包和17.7MB真实检查点重建样本保留，不覆盖。MANIFEST.json为本版本逐文件校验清单。
