# 全部英文图逐图解析

## 1. F02_CC_trajectories_EN

建议位置：Fig. 3；3.1 Calibration performance

英文图注：Figure 2. Simulated daily canopy cover (solid lines) and calibration data (open circles) for (a) 2019, (b) 2020, (c) 2021 and (d) 2022. Days after planting follow the model DAP field. R²cal = 1 − SSE/SST and RMSE are calculated at paired calibration dates; these are in-sample assessments. Lines are trajectories at frozen parameter centers, not posterior predictive means or uncertainty intervals.

回答的问题：检查冠层季节过程及配对拟合的一致性。

实际结果：共48对；年度校准R²为0.931–0.993，RMSE为0.032–0.060（比例）。2022相对较弱。

正文怎样写：F02用于正文叙述冠层生长和衰老过程；F04以1:1线检查系统偏差，作为替代或补图，避免重复宣称两次验证。

解释边界：田间LAI转换CC属于校准数据；曲线为冻结参数中心的确定性轨迹，不是后验预测均值或区间。

数据：F02_CC_calibration_pairs.csv, Calibration_daily_growth.csv, Calibration_metrics.csv

## 2. F05_Biomass_pairs_EN

建议位置：Fig. 4；3.1 Calibration performance

英文图注：Figure 5. Paired observed and simulated aboveground dry biomass in (a) 2019, (b) 2020, (c) 2021 and (d) 2022. The dashed line denotes 1:1 agreement. R²cal = 1 − SSE/SST; RMSE is in t ha⁻¹. The 37 pairs are calibration data, including digitized records with source-specific assumed errors; the plot is not an independent validation.

回答的问题：检验地上干生物量累积及观测—模拟配对误差。

实际结果：四年共37对；R²cal为0.969–0.997，RMSE为0.556–1.252 t ha⁻¹。

正文怎样写：正文优先F05，报告各年样本数及是否偏离1:1线；F03用于补充季节累积过程。高相关与偏差较小应分别描述。

解释边界：含数字化生物量及假定误差尺度；所有配对为样本内校准，未构成独立验证。

数据：F05_Biomass_calibration_pairs.csv, Calibration_metrics.csv

## 3. F07_parameter_intervals_EN

建议位置：Fig. 5；3.2 Parameter identifiability

英文图注：Figure 7. Marginal distributions of retained stage-specific MCMC samples for eight parameters during 2019–2022. Colored points and bars show medians and the 2.5th–97.5th sample percentiles; gray ranges indicate year-specific prior supports. Stage 2 is conditional on the fixed stage 1 handoff. These intervals neither certify convergence nor demonstrate absence of boundary effects. Boundary-band masses are reported separately.

回答的问题：同时显示保留样本分位区间、年际差异和实际先验边界。

实际结果：2019/2020 CCx在上界1%支持宽度内的样本质量约22.14%/23.06%；2020/2021早期WP下界附近约11.43%/23.65%。

正文怎样写：可写“保留样本均在支持域内，但部分参数仍存在边界邻近集中”；不能写“完全没有撞墙”。用S02对照定量边界质量。

解释边界：2.5%–97.5%为相关保留样本的经验分位区间；阶段二条件于阶段一交接点，不是经认证的八维联合后验。

数据：F07_parameter_intervals_and_boundary_mass.csv

## 4. S02_parameter_boundary_mass_EN

建议位置：补充材料或正文备选图

英文图注：Supplementary Figure S2. Percentage of retained draws within the lower or upper 1% of each year-specific prior-support width. The band width is a descriptive diagnostic choice, not a significance threshold. No out-of-support draws is distinct from no concentration near a boundary; substantial near-boundary mass is retained and reported.

回答的问题：把F07的边界观察转为可核对的比例。

实际结果：上/下界邻近带定义为各年支持宽度的1%；高质量集中见CCx及早期WP。

正文怎样写：报告具体参数、年份与比例，再讨论扩大合理支持或增加独立观测是否必要。

解释边界：1%带宽是描述选择，不是显著性阈值；不把无越界等同无边界影响。

数据：F07_parameter_intervals_and_boundary_mass.csv

## 5. S01_MCMC_stage1_diagnostics_EN

建议位置：补充材料或正文备选图

英文图注：Supplementary Figure S1. Existing rank-normalized R-hat and bulk ESS summaries for stage 1, recomputed in the previous source audit. The original strict diagnostic criteria are not met. Retained draw counts are not effective sample sizes. No long-chain extension is performed as part of this figure revision; stage 2 single-ensemble limitations are listed in the sampling table.

回答的问题：披露阶段一R-hat与ESS的严格诊断限制。

实际结果：既有阶段一未通过原严格R-hat/ESS条件；相关保留样本虽多，有效信息量仍受自相关和ensemble差异影响。

正文怎样写：正文用一段客观描述并引用补图，避免“高拟合说明MCMC充分收敛”的逻辑跳跃。

解释边界：热图只反映已有诊断记录，不是本轮新长链实验。

数据：MCMC_existing_diagnostics.csv, MCMC_existing_sampling_groups.csv

## 6. F09_annual_water_budget_EN

建议位置：补充材料或正文备选图

英文图注：Figure 9. Annual water-budget components for the calibrated DI baseline during 2019–2022. Inflow is irrigation plus precipitation; capillary and groundwater inputs are zero in these runs. Outflow comprises evapotranspiration, runoff, deep percolation and tile drainage. Storage denotes the absolute end-of-season soil-profile plus surface water storage. Water-balance closure is assessed as inflow − outflow = final storage − initial storage, not as inflow − outflow = final storage. Lines connect annual summaries for comparison and do not represent a statistical trend test.

回答的问题：检验入流、出流与储水定义以及水量闭合。

实际结果：2021基准季末土壤水约705.7 mm，比初始增加约170.0 mm；其他年度初末变化不同。四年水量残差在数值精度范围内。

正文怎样写：年度三线版用于跨年比较；原柱状账是补图。明确I+P−ET−径流/排水=ΔS，绝对季末储水不能直接代入ΔS。

解释边界：年际连线不是趋势检验。土壤剖面总储水不等于作物根系可利用水。

数据：F09_annual_water_budget.csv

## 7. S03_annual_water_storage_change_EN

建议位置：补充材料或正文备选图

英文图注：Supplementary Figure S3. Annual inflow, outflow and signed storage change (ΔS = final − initial storage). The three components satisfy inflow − outflow = ΔS within numerical precision. Positive ΔS indicates net storage gain. This is the change-in-storage companion to the absolute-storage version of Figure 9.

回答的问题：检验入流、出流与储水定义以及水量闭合。

实际结果：2021基准季末土壤水约705.7 mm，比初始增加约170.0 mm；其他年度初末变化不同。四年水量残差在数值精度范围内。

正文怎样写：年度三线版用于跨年比较；原柱状账是补图。明确I+P−ET−径流/排水=ΔS，绝对季末储水不能直接代入ΔS。

解释边界：年际连线不是趋势检验。土壤剖面总储水不等于作物根系可利用水。

数据：F09_annual_water_budget.csv

## 8. R01_Sobol_four_outputs_2x2_EN

建议位置：Fig. 6；3.3 Annual sensitivity patterns

英文图注：Figure R1. Total-effect Sobol indices for (a) grain yield at 13% moisture, (b) aboveground dry biomass, (c) seasonal evapotranspiration and (d) maximum canopy cover. Each cell is the mean of three N=512 scrambles within a year, using the same eight independent uniform parameter ranges. One color scale is used throughout. Rank agreement and variation in index magnitude are assessed separately; indices are not normalized to sum to one. Transpiration and soil evaporation are retained in Supplementary Figure S5.

回答的问题：在同一色标和2×2布局下讨论年度稳定性与输出差异。

实际结果：产量以晚期WP和HI0为主；生物量以晚期/早期WP和Kcb为主；ET以Kcb为主；最大CC以CCx为主。四主输出年度均值排序的Kendall W均为1。

正文怎样写：强调“这四个年度均值的排序一致”，同时给指数范围；不能把排序一致改写为贡献完全不变。

解释边界：只有四个年度模拟情景；2022产量早期WP/Kcb在种子层面近似并列，年度均值相同排序不消除该不确定性。

数据：Sobol_all_seed_indices.csv, Sobol_annual_means_and_ranks.csv

## 9. S05_Sobol_Tr_Es_EN

建议位置：补充材料或正文备选图

英文图注：Supplementary Figure S5. Annual mean total-effect indices for transpiration and soil evaporation. All six original model outputs are retained in the source tables; these two outputs supplement the four primary-output panels in Figure R1.

回答的问题：补充蒸腾与土壤蒸发分量的敏感性。

实际结果：Tr平均ST以Kcb约0.578为首；Es以CCx约0.718为首。两者对同一参数的贡献大小不同。

正文怎样写：用来解释总ET并不能代表所有水分分量的响应；区分冠层遮蔽对土壤蒸发的作用与Kcb对蒸腾的作用。

解释边界：水分分量的ST是不同输出方差的归一化比，不能相加成ET的ST。

数据：Sobol_all_seed_indices.csv, Sobol_annual_means_and_ranks.csv

## 10. R02_Sobol_Yield_all_years_mean_EN

建议位置：Fig. 7；3.3 Annual sensitivity patterns

英文图注：Figure R2. Four-year yield sensitivity shown together as (a) first-order and (b) total-effect indices. Colored symbols are annual means across three independent scrambles; black diamonds are equal-weight means across the four annual estimates. Gray segments show the annual minimum–maximum range, not confidence intervals. A four-year mean summarizes these simulation contexts and is not a pooled climate-mixture Sobol index or proof of year-invariant sensitivity. Within-year numerical intervals are retained in Supplementary Figure S4.

回答的问题：合并四年产量S1/ST，并展示年度值、等权均值和年际范围。

实际结果：晚期WP、HI0、早期WP、Kcb的四年ST均值约0.396、0.206、0.164、0.145；晚期WP年度范围约0.353–0.426。

正文怎样写：可以把均值作为四情景的描述摘要，因为高贡献层级总体一致；仍应保留年度点和范围，不用均值遮蔽近似并列。

解释边界：灰线是年际最小—最大范围而非置信区间；先年内平均3个scramble，再四年各1/4加权，不等于混合气候下重新计算Sobol。cat/coc尚无定义。

数据：Sobol_annual_means_and_ranks.csv, Sobol_four_year_descriptive_means.csv

## 11. S04_Sobol_yield_numerical_intervals_EN

建议位置：补充材料或正文备选图

英文图注：Supplementary Figure S4. Total-effect yield indices from three N=512 scrambles per year, with 95% bootstrap half-widths based on 512 resamples. Open diamonds show the within-year scramble mean of S1. The early-WP/Kcb ordering remains numerically uncertain in 2022. This numerical uncertainty is distinct from between-year sensitivity variation. Negative finite-sample S1 values are not set to zero.

回答的问题：报告Sobol数值估计的不确定性及种子重复性。

实际结果：N=512、每年3个scramble、512次bootstrap；24项筛查23项通过。2022产量早期WP与Kcb的ST均约0.139，排名随种子互换。

正文怎样写：将两者归为相近贡献层级，不强制严格先后。区分数值估计区间与年际变化范围。

解释边界：这里的95%区间不是田间产量预测区间，S1有限样本负值不强制改零。

数据：Sobol_all_seed_indices.csv, Sobol_numerical_stability.csv

## 12. R03_full_range_diagnostic_2x2_EN

建议位置：补充材料或正文备选图

英文图注：Supplemental full-range diagnostic. Solid lines are nondominated best-found actual model evaluations from three NSGA-III searches per year (80 individuals × 60 generations), using frozen yearly parameter centers and four fixed-date irrigation windows. The original 95% observed-yield gate is removed for these searches; the dotted line is shown only as a reference. Gray dashed curves scale the original event amounts proportionally and are not optimized fronts. Open circles show zero irrigation; stars show original DI model baselines. This conditional model reference is separate from field validation and from the gated main optimization.

回答的问题：把零灌溉及低水量区间补回，检验原局部图的解释。

实际结果：移除产量门槛的补充搜索共57,600次；四年零灌溉产量约9.071、6.184、6.140、5.850 t ha⁻¹，均明显低于DI。

正文怎样写：解释零灌溉仍可利用雨水和初始储水；区分固定比例剂量响应与择优包络。补充搜索预算与正式实验分开报告。

解释边界：仅补充诊断取消95%门槛；仍保留灌水上限，未新增储水约束。没有零灌溉田间验证，也未证明全局最优。

数据：Full_range_best_found_front.csv, Fixed_proportion_dose_response.csv, Zero_irrigation_reference.csv

## 13. N01_Optimized_yield_irrigation_EN

建议位置：补充材料或正文备选图

英文图注：New figure. Best-found full-range yield–irrigation trade-offs from supplemental actual-model NSGA-III searches. Each curve is an upper nondominated envelope, not the response of a single fixed irrigation pattern or a proven global optimum. Zero-irrigation and original DI baselines are shown explicitly. Initial soil water, rainfall, climate and parameter centers remain year specific; terminal storage and per-event delivery limits are not additional constraints in these searches.

回答的问题：把零灌溉及低水量区间补回，检验原局部图的解释。

实际结果：移除产量门槛的补充搜索共57,600次；四年零灌溉产量约9.071、6.184、6.140、5.850 t ha⁻¹，均明显低于DI。

正文怎样写：解释零灌溉仍可利用雨水和初始储水；区分固定比例剂量响应与择优包络。补充搜索预算与正式实验分开报告。

解释边界：仅补充诊断取消95%门槛；仍保留灌水上限，未新增储水约束。没有零灌溉田间验证，也未证明全局最优。

数据：Full_range_best_found_front.csv, Zero_irrigation_reference.csv

## 14. R04_right_yield_comparison_EN

建议位置：补充材料或正文备选图

英文图注：Observed yields are the values reported in the source study; DI baseline and selected-candidate yields are simulations at frozen annual parameter centers. Candidates minimize irrigation within the NSGA-III union subject to the DI irrigation cap and Y13 ≥ 0.95 Yobs. Dotted segments mark this deterministic yield constraint, not confidence intervals. Symbols are offset horizontally within each year for readability. Candidate colors consistently denote 2019, 2020, 2021 and 2022. Lower irrigation does not imply an equal reduction in ET; terminal soil storage is reported separately.

回答的问题：直接比较观测、模型基准和主候选，并对应减灌水幅度。

实际结果：四年候选灌水约218.36、312.42、267.30、260.78 mm，较DI减少50.96%、44.19%、57.80%、35.58%。产量接近95%观测门槛。

正文怎样写：把候选产量相对观测和相对模型基准的变化分开。最低灌水规则导致候选靠近门槛，不是保产能力特别稳定的证据。

解释边界：95%虚线不是置信区间。减少灌水不能直接写为等幅减少ET或无条件节水不减产。

数据：R04_yield_comparison.csv

## 15. R04_irrigation_yield_comparison_EN

建议位置：Fig. 9；3.4 Irrigation–yield trade-offs

英文图注：Panel (a): percentages are reductions in applied irrigation relative to the original annual DI schedule, not consumptive-water savings or a demonstrated sustainable water-saving rate. Observed yields are the values reported in the source study; DI baseline and selected-candidate yields are simulations at frozen annual parameter centers. Candidates minimize irrigation within the NSGA-III union subject to the DI irrigation cap and Y13 ≥ 0.95 Yobs. Dotted segments mark this deterministic yield constraint, not confidence intervals. Symbols are offset horizontally within each year for readability. Candidate colors consistently denote 2019, 2020, 2021 and 2022. Lower irrigation does not imply an equal reduction in ET; terminal soil storage is reported separately.

回答的问题：直接比较观测、模型基准和主候选，并对应减灌水幅度。

实际结果：四年候选灌水约218.36、312.42、267.30、260.78 mm，较DI减少50.96%、44.19%、57.80%、35.58%。产量接近95%观测门槛。

正文怎样写：把候选产量相对观测和相对模型基准的变化分开。最低灌水规则导致候选靠近门槛，不是保产能力特别稳定的证据。

解释边界：95%虚线不是置信区间。减少灌水不能直接写为等幅减少ET或无条件节水不减产。

数据：R04_yield_comparison.csv, R03_irrigation_ET_storage_tradeoff.csv

## 16. R03_Gated_Pareto_fronts_EN

建议位置：Fig. 8；3.4 Irrigation–yield trade-offs

英文图注：English reconstruction of the supplied R03 from its canonical 3,986 final feasible Pareto records. Colored points show NSGA-III results; solid and dashed curves are nondominated unions across five seeds for NSGA-III and NSGA-II, respectively (100 individuals × 100 generations per seed). Each panel uses its own zoomed axes and includes only yield-gated feasible points, not the full dose response. Zero-irrigation yields fall below the gate in every year and therefore are absent. Stars are model baselines, not observations. Open circles are minimum-irrigation selections from the gated NSGA-III union, not geometric knee points. Use the separate full-range figure to interpret the omitted low-irrigation region.

回答的问题：展示正式产量门槛内的用水—产量权衡及算法对照。

实际结果：3,986条最终可行记录；NSGA-II/III前沿基本重合。2021可行产量约15.067–15.251 t ha⁻¹，独立纵轴截取使曲线显得陡。

正文怎样写：先交代I≤IDI和Y13≥0.95Yobs，再说明圈点为NSGA-III并集内最低灌水量候选。星号是模型基准，虚线是门槛。

解释边界：零灌溉被产量门槛排除；圈点不是几何膝点。曲线是搜索得到的非支配包络，未证明全局最优。

数据：Original_main_NSGA_all_seed_Pareto_points.csv, R04_yield_comparison.csv

## 17. S07_Irrigation_reduction_decomposition_EN

建议位置：Fig. 10；3.5 Water balance and applicability

英文图注：Irrigation reduction equals lower ET plus the difference in final soil storage and lower runoff/drainage, because rainfall, initial soil water, other inflows and changes in surface storage match within each annual baseline–candidate pair. The storage term is the baseline final storage minus candidate final storage. It includes avoided baseline recharge and/or additional depletion and is not wholly attributable to soil-water mining. In 2021, baseline storage increases by about 170.0 mm whereas candidate storage decreases by about 186.7 mm; their 356.7 mm difference accounts for 97.4% of the irrigation reduction. Bars do not demonstrate long-term sustainability; terminal storage was not constrained in the original optimization.

回答的问题：解释少灌的水量由哪些水量账差异构成。

实际结果：2021少灌366.2 mm，其中ET仅少8.6 mm，季末储水差356.7 mm，解释97.4%的减灌水量；四年储水项占比约83%–97%。

正文怎样写：明确“少灌水”和“少耗水”不同；2021基准增储约170.0 mm、候选耗储约186.7 mm，储水差包含两部分。

解释边界：不能把整个储水差都叫土壤水透支；无季末储水限制的单季方案不能保证跨季可持续。

数据：R03_irrigation_ET_storage_tradeoff.csv, Original_main_Water_ledger_baseline_and_candidate.csv

## 18. Figure1_three_column_EN

建议位置：Fig. 1；2.1 Overall framework

英文图注：Three-column workflow linking original inputs, grouped conditional MCMC calibration, independent-range Sobol analysis, two-objective irrigation optimization and candidate checks. MCMC samples remain frozen and their diagnostic limitations are retained.

回答的问题：说明从资料、分阶段校准到敏感性分析、优化和核验的完整衔接。

实际结果：四年原模型已接入；MCMC冻结；正式Sobol为N=512×3种子；双算法优化各100个体×100代×5种子。

正文怎样写：研究按“过程复现—参数贡献—管理权衡—水量与条件扰动核验”组织。三列版适合正文；树状版作为替代布局，不重复入正文。

解释边界：流程完成不表示采样诊断全部通过，也不表示参数不确定性已在寻优中传播。

数据：

## 19. Figure1_tree_EN

建议位置：补充材料或正文备选图

英文图注：Alternative tree layout of the same four-year workflow. This is an alternative to the three-column version and should not be inserted twice into the main manuscript.

回答的问题：说明从资料、分阶段校准到敏感性分析、优化和核验的完整衔接。

实际结果：四年原模型已接入；MCMC冻结；正式Sobol为N=512×3种子；双算法优化各100个体×100代×5种子。

正文怎样写：研究按“过程复现—参数贡献—管理权衡—水量与条件扰动核验”组织。三列版适合正文；树状版作为替代布局，不重复入正文。

解释边界：流程完成不表示采样诊断全部通过，也不表示参数不确定性已在寻优中传播。

数据：

## 20. Figure10_environment_EN

建议位置：Fig. 2；2.2 Data and environmental conditions

英文图注：Daily reference evapotranspiration and precipitation over the actual model calendar in 2019–2022. Lines and bars retain the exact source dates and values, with consistent axis limits across years. Reference evapotranspiration is distinct from simulated actual crop evapotranspiration.

回答的问题：说明四年模型实际采用的天气驱动及比较窗口。

实际结果：模型日历合计599天；四年降雨分别约177.9、113.5、143.3、151.4 mm。逐日ETo与降雨保持源值，不插值或按年缩放。

正文怎样写：先描述需水与供水过程差异，再讨论其可能影响；ETo为参考蒸散，不能与后续模拟实际ET混称。

解释边界：仅四个年度情景；气象差异与参数、初始水差异并存，不能由本图识别单一气候因果效应。

数据：Figure10_daily_environment.csv, Figure10_window_summary.csv

## 21. F03_Biomass_trajectories_EN

建议位置：补充材料或正文备选图

英文图注：Daily aboveground dry biomass at frozen annual parameter centers and the 37 paired calibration observations. These trajectories are deterministic simulations, not posterior predictive means. Errors are in-sample calibration metrics.

回答的问题：检验地上干生物量累积及观测—模拟配对误差。

实际结果：四年共37对；R²cal为0.969–0.997，RMSE为0.556–1.252 t ha⁻¹。

正文怎样写：正文优先F05，报告各年样本数及是否偏离1:1线；F03用于补充季节累积过程。高相关与偏差较小应分别描述。

解释边界：含数字化生物量及假定误差尺度；所有配对为样本内校准，未构成独立验证。

数据：Calibration_daily_growth.csv, F05_Biomass_calibration_pairs.csv, Calibration_metrics.csv

## 22. F04_CC_pairs_EN

建议位置：补充材料或正文备选图

英文图注：Observed and simulated canopy cover at the same 48 calibration dates. Dashed lines indicate 1:1 agreement. R²cal = 1 − SSE/SST is computed against observations without refitting a regression. This is an alternative display to F02, not independent validation.

回答的问题：检查冠层季节过程及配对拟合的一致性。

实际结果：共48对；年度校准R²为0.931–0.993，RMSE为0.032–0.060（比例）。2022相对较弱。

正文怎样写：F02用于正文叙述冠层生长和衰老过程；F04以1:1线检查系统偏差，作为替代或补图，避免重复宣称两次验证。

解释边界：田间LAI转换CC属于校准数据；曲线为冻结参数中心的确定性轨迹，不是后验预测均值或区间。

数据：F02_CC_calibration_pairs.csv, Calibration_metrics.csv

## 23. F06_calibration_summary_EN

建议位置：补充材料或正文备选图

英文图注：Canopy-cover and biomass RMSE are calculated from paired calibration dates. Grain-yield bias compares the annual model baseline with published observations. The ±5% shaded band is a descriptive project tolerance, not a confidence interval or independent validation.

回答的问题：把冠层、生物量及季末产量误差放在同一年度框架下。

实际结果：2022冠层RMSE最高，但生物量RMSE最低；不同输出的拟合优劣不必一致。年度籽粒产量偏差约−4.18%至+0.92%。

正文怎样写：先说明各指标单位，再解释不同观测约束对过程与终值的贡献，不把不同量纲RMSE直接比大小。

解释边界：±5%灰带是项目容许幅度，不是统计置信区间；年产量每年只有一个观测终值。

数据：F06_calibration_summary_EN.csv, Calibration_metrics.csv, observed_yield_gate_headroom.csv

## 24. F08_phase2_compensation_EN

建议位置：补充材料或正文备选图

英文图注：Late WP and HI0 are taken from the same retained stage-2 sample rows. Correlations use every retained row; points are evenly thinned for display. Association indicates conditional parameter compensation and is not a causal relationship or proof of convergence.

回答的问题：观察晚期水分生产率与收获指数之间的条件补偿。

实际结果：HI0与晚期WP的Pearson r依次为-0.871、-0.595、-0.463、-0.645，均呈负相关。

正文怎样写：说明不同参数组合可能给出相似生物量—产量终值，因而拟合良好不等于每个参数都能唯一识别。

解释边界：r使用同一行的全部保留样本计算，散点只为显示抽稀；不推断因果，不用该图认证收敛。

数据：F08_phase2_correlation.csv, F08_displayed_same_row_samples.csv

## 25. F14_phase2_trace_WP_early_EN

建议位置：补充材料或正文备选图

英文图注：Only the retained segment of the original stage-2 ensemble is shown. The line is the median across 32 walkers at each step; shading is the 10th–90th walker-percentile range, not a posterior confidence band or an independent-chain convergence certificate.

回答的问题：观察阶段二保留段中walker分布随原采样步变化。

实际结果：四年均完整保留；线为每步32个walker的中位数，浅带为10%–90%分位。图从原步号展示，仅保留段有值。

正文怎样写：检查明显漂移及分布范围；可说轨迹描述了保留段行为，但需要独立采样诊断才能判断收敛。

解释边界：阴影不是参数均值置信区间，也不是独立链间一致性证据；本轮没有延长原链。

数据：F14_F16_phase2_trace_summaries.csv, sampling_group_summary.csv

## 26. F15_phase2_trace_WP_late_EN

建议位置：补充材料或正文备选图

英文图注：Only the retained segment of the original stage-2 ensemble is shown. The line is the median across 32 walkers at each step; shading is the 10th–90th walker-percentile range, not a posterior confidence band or an independent-chain convergence certificate.

回答的问题：观察阶段二保留段中walker分布随原采样步变化。

实际结果：四年均完整保留；线为每步32个walker的中位数，浅带为10%–90%分位。图从原步号展示，仅保留段有值。

正文怎样写：检查明显漂移及分布范围；可说轨迹描述了保留段行为，但需要独立采样诊断才能判断收敛。

解释边界：阴影不是参数均值置信区间，也不是独立链间一致性证据；本轮没有延长原链。

数据：F14_F16_phase2_trace_summaries.csv, sampling_group_summary.csv

## 27. F16_phase2_trace_HI0_EN

建议位置：补充材料或正文备选图

英文图注：Only the retained segment of the original stage-2 ensemble is shown. The line is the median across 32 walkers at each step; shading is the 10th–90th walker-percentile range, not a posterior confidence band or an independent-chain convergence certificate.

回答的问题：观察阶段二保留段中walker分布随原采样步变化。

实际结果：四年均完整保留；线为每步32个walker的中位数，浅带为10%–90%分位。图从原步号展示，仅保留段有值。

正文怎样写：检查明显漂移及分布范围；可说轨迹描述了保留段行为，但需要独立采样诊断才能判断收敛。

解释边界：阴影不是参数均值置信区间，也不是独立链间一致性证据；本轮没有延长原链。

数据：F14_F16_phase2_trace_summaries.csv, sampling_group_summary.csv

## 28. F17_parameter_centers_EN

建议位置：补充材料或正文备选图

英文图注：Arithmetic means of retained stage-specific parameter samples used as deterministic annual centers. Stage 2 is conditional on the stage-1 handoff; these eight values do not define a certified joint posterior mean. Connecting lines aid annual comparison without establishing temporal trends.

回答的问题：交代四个年度用于确定性下游模拟的八参数中心。

实际结果：晚期WP中心依次为30.58、25.85、21.94、31.50 g m⁻²；各年中心与原冻结文件一致。

正文怎样写：说明中心参数用于可复现的条件模拟；年际差异可能包含气象、数据和可辨识性补偿，不直接解释为生理参数真实漂移。

解释边界：拼接阶段均值不构成完整联合后验的数学均值；年度虚线只是视觉连接。

数据：central_vectors_with_provenance.csv

## 29. F11_CC_evidence_roles_EN

建议位置：补充材料或正文备选图

英文图注：The field LAI-derived DI canopy-cover series enters calibration. Remote-sensing CCquad is converted from percent to fraction and shown only as auxiliary evidence. The 2019–2021 remote-sensing records refer to BI and the 2022 treatment metadata are incomplete; none is relabeled as independent DI validation.

回答的问题：区分田间LAI转换CC与遥感时序的证据角色。

实际结果：田间DI序列用于校准；遥感未入似然，2019–2021为BI标签，2022处理标签不完整。

正文怎样写：两来源时序只作辅助比较，并讨论转换与处理差异；不把灰线接近彩线写成DI独立验证。

解释边界：遥感CCquad由百分数转比例；横轴为模型起点后的日数，不能混用未经核实的物候日期。

数据：F11_evidence_series_EN.csv

## 30. F12_sampling_record_EN

建议位置：补充材料或正文备选图

英文图注：Each original ensemble used 32 walkers and 2,000 raw steps. Stage 1 has four ensembles per year and stage 2 has one. The dashed 50-IAT line is only a length reference, not proof of convergence; correlated retained-row counts must not be reported as effective sample sizes.

回答的问题：给出原采样预算、截断后长度与自相关时间的关系。

实际结果：原ensemble均为32 walkers、2,000步；阶段一每年4个ensemble，阶段二每年1个；阶段一长度不足50τ参考。

正文怎样写：将“采样设置”和“实际诊断”分开报告。参考论文采用相似步数不能证明URP也收敛。

解释边界：walker不等于独立链；保留行数不等于ESS。阶段二不能仅因超过50τ就宣称完成严格收敛诊断。

数据：sampling_group_summary.csv, MCMC_existing_diagnostics.csv

## 31. F09_water_ledger_EN

建议位置：补充材料或正文备选图

英文图注：English version of the original two-column water ledger, retained as a supplementary alternative to the annual three-line F09. Inflow plus depletion equals outflow plus storage gain. Net storage change is final minus initial storage, not the absolute final storage.

回答的问题：检验入流、出流与储水定义以及水量闭合。

实际结果：2021基准季末土壤水约705.7 mm，比初始增加约170.0 mm；其他年度初末变化不同。四年水量残差在数值精度范围内。

正文怎样写：年度三线版用于跨年比较；原柱状账是补图。明确I+P−ET−径流/排水=ΔS，绝对季末储水不能直接代入ΔS。

解释边界：年际连线不是趋势检验。土壤剖面总储水不等于作物根系可利用水。

数据：F09_annual_water_budget.csv

## 32. F13_yield_gate_EN

建议位置：补充材料或正文备选图

英文图注：English reconstruction of the original F13 yield-gate figure. The gate is 95% of published observed grain yield. Headroom is the allowable yield decrease relative to the model baseline, not an irrigation-saving rate. This does not assign meanings to the unresolved labels Y_catmul and Y_tot.

回答的问题：解释优化的产量门槛及模型偏差带来的实际余量。

实际结果：2021模型基准约15.197，95%观测门槛15.067 t ha⁻¹，相对模型基准可下降余量仅约0.86%。

正文怎样写：门槛以发表观测Yobs为分母，模型基准只用来衡量余量；这也解释2021可行前沿产量范围较窄。

解释边界：这是原F13门槛图英文化，尚未把Y_catmul或Y_tot映射为任何未经确认的列；N02另给明确变量名的回归图。

数据：observed_yield_gate_headroom.csv

## 33. R01_Sobol_ST_Y_13pct_EN

建议位置：补充材料或正文备选图

英文图注：Annual mean total-effect sensitivity for grain yield at 13% moisture, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

回答的问题：展示单一输出在四年、八参数下的总效应贡献。

实际结果：四年等权ST描述均值前三位：WP_late 0.396；HI0 0.206；WP_early 0.164。

正文怎样写：比较主导参数排序是否一致，再比较指数大小；与输出形成机理对照，不跨不同输入分布套用排名。

解释边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

数据：Sobol_all_seed_indices.csv

## 34. R01_Sobol_ST_B_t_ha_EN

建议位置：补充材料或正文备选图

英文图注：Annual mean total-effect sensitivity for aboveground dry biomass, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

回答的问题：展示单一输出在四年、八参数下的总效应贡献。

实际结果：四年等权ST描述均值前三位：WP_late 0.503；WP_early 0.207；Kcb 0.180。

正文怎样写：比较主导参数排序是否一致，再比较指数大小；与输出形成机理对照，不跨不同输入分布套用排名。

解释边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

数据：Sobol_all_seed_indices.csv

## 35. R01_Sobol_ST_Tr_mm_EN

建议位置：补充材料或正文备选图

英文图注：Annual mean total-effect sensitivity for seasonal transpiration, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

回答的问题：展示单一输出在四年、八参数下的总效应贡献。

实际结果：四年等权ST描述均值前三位：Kcb 0.578；CCx 0.227；CGC_CD 0.180。

正文怎样写：比较主导参数排序是否一致，再比较指数大小；与输出形成机理对照，不跨不同输入分布套用排名。

解释边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

数据：Sobol_all_seed_indices.csv

## 36. R01_Sobol_ST_Es_mm_EN

建议位置：补充材料或正文备选图

英文图注：Annual mean total-effect sensitivity for seasonal soil evaporation, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

回答的问题：展示单一输出在四年、八参数下的总效应贡献。

实际结果：四年等权ST描述均值前三位：CCx 0.718；CGC_CD 0.267；SenescenceCD 0.022。

正文怎样写：比较主导参数排序是否一致，再比较指数大小；与输出形成机理对照，不跨不同输入分布套用排名。

解释边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

数据：Sobol_all_seed_indices.csv

## 37. R01_Sobol_ST_ET_mm_EN

建议位置：补充材料或正文备选图

英文图注：Annual mean total-effect sensitivity for seasonal evapotranspiration, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

回答的问题：展示单一输出在四年、八参数下的总效应贡献。

实际结果：四年等权ST描述均值前三位：Kcb 0.837；CGC_CD 0.102；CCx 0.059。

正文怎样写：比较主导参数排序是否一致，再比较指数大小；与输出形成机理对照，不跨不同输入分布套用排名。

解释边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

数据：Sobol_all_seed_indices.csv

## 38. R01_Sobol_ST_MaxCC_EN

建议位置：补充材料或正文备选图

英文图注：Annual mean total-effect sensitivity for maximum canopy cover, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

回答的问题：展示单一输出在四年、八参数下的总效应贡献。

实际结果：四年等权ST描述均值前三位：CCx 0.911；CGC_CD 0.097；Kcb 0.001。

正文怎样写：比较主导参数排序是否一致，再比较指数大小；与输出形成机理对照，不跨不同输入分布套用排名。

解释边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

数据：Sobol_all_seed_indices.csv

## 39. R05_Actual_irrigation_schedules_EN

建议位置：补充材料或正文备选图

英文图注：Actual event amounts are compared at original annual irrigation dates. Decisions redistribute totals across four ordered windows while preserving baseline proportions within each window. No irrigation dates are optimized. Planned amounts canceled after crop termination are retained separately in the source table.

回答的问题：把四窗口控制量解释到实际日期与单次水量。

实际结果：原事件数为8、8、7、5；2020主候选单次最大量约179.9 mm。日期固定，调整的是窗口总水量及相应事件水量。

正文怎样写：对照生长阶段解释水量重新分配，并说明设备上限尚未纳入，不能写成已经优化灌水日期。

解释边界：原始逐次记录才是实际用水，提前结束后取消的计划水量另列；需核实设施和入渗能力才能实施。

数据：NSGA_event_schedules.csv

## 40. R06_Seeded_convergence_EN

建议位置：补充材料或正文备选图

英文图注：Each algorithm used 100 individuals × 100 generations × five seeds per year. Curves show seed medians and shading shows minimum–maximum seed ranges, not confidence intervals. Hypervolume uses annual observed yield and DI irrigation for normalization and reference point [0, 1.01]. Compare algorithms within a year; convergence histories do not prove a global optimum.

回答的问题：比较同预算下两算法的多随机种子搜索行为。

实际结果：40次搜索共400,000次评估、4,000代记录；逐年并集HV相对差异绝对值小于0.07%，没有NSGA-III明显优越性的证据。

正文怎样写：报告中位数与种子范围，说明结果重复性；曲线趋于稳定不等于已达到数学全局最优。

解释边界：阴影是5种子最小—最大范围，不是置信区间。不同年份HV归一化背景不同，不横向排名算法性能。

数据：NSGA_convergence_history.csv, NSGA_algorithm_comparison.csv

## 41. R07_Conditional_candidate_checks_EN

建议位置：补充材料或正文备选图

英文图注：Each group uses 128 whole-row draws from one retained stage-specific sample pool while fixing the other group at its center. Left intervals describe Monte Carlo sampling uncertainty conditional on that empirical pool, not field failure probability or original MCMC uncertainty. These are not joint eight-parameter posterior draws; 128 perturbations are not 128 effective posterior samples. Right dotted marks are deterministic yield gates.

回答的问题：核查中心点可行候选对条件参数扰动是否敏感。

实际结果：四个主候选的组内门槛达标比例约0.281–0.555，Q05均低于相应门槛；仅中心点达标不代表扰动后高达标率。

正文怎样写：将这些结果作为风险提示与后续稳健优化动机，不能把本实验改称已完成稳健优化。

解释边界：每次只扰动一个阶段并固定另一个；Wilson区间仅描述给定经验池的重采样误差，不是田间失败概率，未含原链和模型结构误差。

数据：NSGA_conditional_validation.csv, NSGA_main_candidates.csv

## 42. R09_Terminal_storage_screening_EN

建议位置：补充材料或正文备选图

英文图注：Dark bars are minimum-irrigation points among already evaluated feasible solutions satisfying final storage at least equal to the original DI baseline; selected points were replayed. This is post hoc filtering, not a new storage-constrained optimization or proof of infeasibility/optimality. The baseline final storage is a sensitivity scenario, not an established agronomic sustainability target.

回答的问题：展示加入季末储水条件后结论的敏感性。

实际结果：事后筛选要求季末储水不低于DI时，既有点中四年减灌比例约8.75%、0.56%、0.23%、7.01%，明显小于原主候选。

正文怎样写：用来支持增加储水条件的重要性，注明筛选点已经回放，但没有重新优化。

解释边界：原DI季末值不自动等于合理可持续标准；未找到既有点不等于证明不可行。

数据：Terminal_storage_screening.csv, NSGA_main_candidates.csv, Water_ledger_baseline_and_candidate.csv

## 43. N02_Biomass_regression_EN

建议位置：补充材料或正文备选图

英文图注：Additional regression using all 37 biomass calibration pairs from 2019–2022. X is simulated and Y is observed aboveground dry biomass, explicitly named rather than mapped to unresolved Y_catmul/Y_tot labels. OLS R² is calculated after fitting an intercept and differs from the 1:1 calibration R² used in F05. Pearson r describes association. Pooling repeated observations across years can inflate apparent agreement; no independent-observation p-value or validation claim is made.

回答的问题：提供明确变量名的四年生物量拟合直线图。

实际结果：37对数据的OLS R²=0.9892，Pearson r=0.9946；横轴模拟生物量，纵轴观测生物量。

正文怎样写：同时看OLS斜率、截距和相对1:1线的偏离；高r只是相关性，不能替代无偏性与独立验证。

解释边界：含年内重复日期和跨年合并效应，未给独立样本显著性推断；OLS R²与F05的1:1校准R²不同。未擅自解释Y_catmul/Y_tot。

数据：F05_Biomass_calibration_pairs.csv, N02_Biomass_regression_summary.csv

