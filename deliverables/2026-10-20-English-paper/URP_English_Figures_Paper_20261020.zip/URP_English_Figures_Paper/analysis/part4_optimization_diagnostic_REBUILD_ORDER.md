# 第四部分复现顺序

本目录包含正式实验源表副本、补充全范围搜索原始记录及本次原图诊断。R03和R04已收到，诊断已经完成。

使用 `/workspace/urp_run_20261018/.venv/bin/python`。绘图时设置 `MPLCONFIGDIR=/workspace/urp_true_runs_20261019/.mplcache`，数值库线程数设为1。

1. 如需从已有全范围搜索记录重新导出，可执行 `publish_full_range_reference.py`。它重核57,600条评估及全部代记录，不重新求解模型。该步骤是原图诊断之前的导出阶段，会重置图册登记；随后必须执行第2步。
2. 执行 `diagnose_R03_finalize_R04.py`：重新核对正式实验源表和门槛，导出诊断表与四组新增英文图，恢复最终图册登记。
3. 执行 `write_part4_notes.py`：更新中文诊断、方法限制和英文正文段落。
4. 执行上级目录的 `build_stage_workbooks.py 4`：生成Excel与含图Word。表格保留完整精度，展示数字另作四舍五入。
5. 将Word转为 `/tmp/part4_optimization_diagnostic_revision_working.pdf`，目视检查；执行上级目录 `validate_parts_3_4.py` 更新质量记录及清单。

`run_full_range_reference.py` 为已经实际执行的额外模型搜索，结果完整保留，不需再次运行。原正式实验、冻结MCMC和模型源码均未在本轮英文化中修改。本阶段不创建压缩包或上传；按用户要求留待所有部分完成后统一交付。
