# 第二部分：MCMC采样与拟合分析（持续修订，暂不打包）

## 选图与执行状态

- 正文选F02：四年冠层覆盖过程线与校准数据，替代F04重复散点展示。
- 正文选F05：四年地上干生物量观测—模拟配对，F03/F06可移到补充材料或撤去重复内容。
- 保留F07：英文版增加完整先验支持范围；另有S02边界附近样本质量，不能用原图推出“完全没有参数撞墙”。
- F09重绘为以年份为横轴的三条折线；主图采用绝对季末储水，S03另给ΔS用于守恒核对。
- F13仍待Y_catmul、Y_tot的定义与单位确认。当前原F13是4对籽粒产量；另有37对四年生物量数据。未擅自混用、改名或拟合成指定变量。

## 本节论证顺序

先用F02说明冠层过程是否被观测约束，再用F05评价生物量幅值与偏差。F07与S02讨论参数识别和边界依赖，S01/诊断表单独讨论采样充分性；F09提供水量核算一致性。这些证据分别回答不同问题，不把高校准R²、水量闭合和MCMC收敛相互替代。

原年度模型与分阶段MCMC保持冻结。没有启动长链延长；没有把相关保留样本数量当作有效样本量。英文节名建议为“MCMC sampling and calibration assessment”。

## 图文与指标口径

F02横轴按Daily_growth.csv的dap字段，配对日期与过程线逐点对应，避免用0基日期差却写成1基DAP。CC为比例。曲线是冻结中心的确定性过程，未添加不存在的后验预测带。

F05横轴是校准生物量观测、纵轴是模拟生物量，单位t ha⁻¹；保留1:1线。2019–2021观测含数字化记录，Sigma_assumed不是独立实测SD，不将其画成实验重复测量误差条。各年9、10、8、10对，共37对。

两张拟合图采用R²cal=1−Σ(sim−obs)²/Σ(obs−mean(obs))²，与原配对评价一致。Pearson r另外列入数据表。它们用于样本内校准，不能改称独立验证。F13如采用带截距OLS，其Regression R²等于Pearson r的平方；它与1:1预测一致性的R²cal并非同一指标。

F07灰色范围为各年度原先验支持，点为中位数、彩色区间为2.5%–97.5%保留样本分位。阶段1未满足严格诊断、阶段2条件于固定交接点，不能声称得到已收敛的八维联合后验。2022第二阶段范围与前三年不同，保持原件。

F09：入流=灌溉+降水（本组CR与地下水入流为0）；出流=Tr+Es+径流+深层渗漏+暗管排水；季末储水=土壤剖面期末量+地表期末量。CSV同时列初末值与ΔS，并核验I−O=ΔS。不同年度只作相邻年度连线比较，不据4个年度点作趋势显著性检验。

## 需要诚实保留的边界结果

| Year | Parameter | Prior_low | Prior_high | Lower_1pct_mass_pct | Upper_1pct_mass_pct |
|---|---|---|---|---|---|
| 2019 | CCx | 0.6 | 0.99 | 0.0 | 22.1359 |
| 2020 | CCx | 0.6 | 0.99 | 0.0 | 23.0624 |
| 2020 | WP_early | 10.0 | 40.0 | 11.432 | 0.0 |
| 2020 | HI0 | 0.35 | 0.6 | 0.0 | 7.2317 |
| 2021 | WP_early | 10.0 | 40.0 | 23.6513 | 0.0 |
| 2021 | HI0 | 0.35 | 0.6 | 0.0 | 9.7902 |

边界1%带宽是描述性诊断口径，不是显著性门槛。32组参数均无超支持样本，不代表边界附近无积累。若要检验边界依赖，后续需要有依据的先验敏感性试验与独立验证；不为消除图中积累而任意扩大边界。

## 英文正文草稿

### calibration

The frozen year-specific parameter centers reproduced the main temporal pattern of canopy development (Figure 2). Across 48 paired canopy-cover dates, annual calibration R² values ranged from 0.931 to 0.993, with RMSE values of 0.032–0.060. For the 37 biomass calibration pairs, annual R² values were 0.969–0.997 and RMSE values were 0.556–1.252 t ha⁻¹ (Figure 5). These metrics describe agreement at the calibration dates. The biomass records include digitized observations with assumed error scales, and their agreement should not be interpreted as independent predictive validation.

### boundary

Parameter distributions were assessed relative to their year-specific prior supports (Figure 7). Approximately 22.1% and 23.1% of retained CCx draws in 2019 and 2020, respectively, lay within the upper 1% of the prior-support width. For early-period WP, the corresponding lower-band masses were 11.4% in 2020 and 23.7% in 2021. All retained draws remained within their declared supports, but these concentrations indicate sensitivity to parameter boundaries. The absence of out-of-support samples therefore does not establish the absence of boundary effects.

### sampling

The existing sampling audit is reported separately from deterministic calibration performance. Each retained stage-specific sample set originates from a 2000-step-per-walker checkpoint, with year- and stage-specific burn-in. Stage 1 strict R-hat/ESS criteria are not met. Stage 2 samples come from one ensemble and are conditional on a fixed stage 1 handoff. High calibration agreement alone does not establish MCMC convergence or an eight-parameter joint posterior. This revision does not extend or rerun the chains.

### water

The annual water-budget comparison separates irrigation-plus-precipitation inflow, total outflow and absolute end-of-season storage (Figure 9). Initial storage differs among years; the closure identity is inflow minus outflow equals final minus initial storage. Signed storage changes were −19.2, +61.9, +170.0 and −40.6 mm in 2019–2022, respectively. The maximum absolute seasonal closure residual was below 2 × 10⁻¹² mm. Numerical closure supports internal water accounting; external validation of the flux partitioning still requires independent data.

## 英文图注

Figure 2. Simulated daily canopy cover (solid lines) and calibration data (open circles) for (a) 2019, (b) 2020, (c) 2021 and (d) 2022. Days after planting follow the model DAP field. R²cal = 1 − SSE/SST and RMSE are calculated at paired calibration dates; these are in-sample assessments. Lines are trajectories at frozen parameter centers, not posterior predictive means or uncertainty intervals.

Figure 5. Paired observed and simulated aboveground dry biomass in (a) 2019, (b) 2020, (c) 2021 and (d) 2022. The dashed line denotes 1:1 agreement. R²cal = 1 − SSE/SST; RMSE is in t ha⁻¹. The 37 pairs are calibration data, including digitized records with source-specific assumed errors; the plot is not an independent validation.

Figure 7. Marginal distributions of retained stage-specific MCMC samples for eight parameters during 2019–2022. Colored points and bars show medians and the 2.5th–97.5th sample percentiles; gray ranges indicate year-specific prior supports. Stage 2 is conditional on the fixed stage 1 handoff. These intervals neither certify convergence nor demonstrate absence of boundary effects. Boundary-band masses are reported separately.

Supplementary Figure S2. Percentage of retained draws within the lower or upper 1% of each year-specific prior-support width. The band width is a descriptive diagnostic choice, not a significance threshold. No out-of-support draws is distinct from no concentration near a boundary; substantial near-boundary mass is retained and reported.

Supplementary Figure S1. Existing rank-normalized R-hat and bulk ESS summaries for stage 1, recomputed in the previous source audit. The original strict diagnostic criteria are not met. Retained draw counts are not effective sample sizes. No long-chain extension is performed as part of this figure revision; stage 2 single-ensemble limitations are listed in the sampling table.

Figure 9. Annual water-budget components for the calibrated DI baseline during 2019–2022. Inflow is irrigation plus precipitation; capillary and groundwater inputs are zero in these runs. Outflow comprises evapotranspiration, runoff, deep percolation and tile drainage. Storage denotes the absolute end-of-season soil-profile plus surface water storage. Water-balance closure is assessed as inflow − outflow = final storage − initial storage, not as inflow − outflow = final storage. Lines connect annual summaries for comparison and do not represent a statistical trend test.

Supplementary Figure S3. Annual inflow, outflow and signed storage change (ΔS = final − initial storage). The three components satisfy inflow − outflow = ΔS within numerical precision. Positive ΔS indicates net storage gain. This is the change-in-storage companion to the absolute-storage version of Figure 9.