# 第三部分：Sobol合并图与年度稳定性

R01主图采用2×2：产量、生物量、ET和最大冠层四个主输出。原六输出中的Tr与Es不删除，另列补图S05；原始576条逐种子指标全部保留。

R02保留并合并四年：同一张图中分别展示S1和ST，彩色点表示各年的三种子均值，黑菱形表示四年等权均值，灰线是年际最小–最大范围，不是置信区间。原R02逐年、逐种子的数值区间保留为S04。用户提到的cat/coc尚未在原表找到对应列，等待名称定义，不擅自当成CCx、CGC、S1或ST。

## 为什么可以给四年均值

四年使用同一输出定义、同一八参数独立均匀范围、同一N和估计方法，因而可在同一口径下计算等权描述性均值。主要输出的年度平均排序高度一致，为以均值概括主要排序提供支持；但敏感性幅度不完全一致，必须同时展示年际点和范围，不能把“排序稳定”写成“各年贡献完全相同”。

均值计算分两步：先在每年对三个独立scramble取均值，再对四个年度均值按1/4等权。不能把12个估计当作12个独立气候年份，也不能把这一均值叫作含气候变异的总体Sobol指数。

各年Sobol指数的分母是该年输出方差。四个比值的均值通常不等于将年份作为随机输入、将四年响应混合后得到的方差分解指数。本文的均值只描述这四个既定模拟情景，不外推为未来气候或所有地区的普遍贡献。

## 稳定性证据应分开报告

- 数值稳定性：N递增、重复scramble与bootstrap区间；原24个输出×年份中23个通过筛查，2022产量Early WP/Kcb近并列。
- 年际排序：四年年度均值间的Spearman相关、Kendall一致性W及前列集合是否一致。
- 年际幅度：各参数ST和S1的均值、最小–最大、SD与范围；近零均值不报告具有误导性的CV。

以上是描述性核查，不是只有四年的等效性检验。ST也不应强制归一化为加和100%的贡献率；总效应含交互作用。

## 可用于正文的英文段落

For grain yield, biomass, seasonal evapotranspiration and maximum canopy cover, the rank ordering of the eight annual-mean total-effect indices was identical across the four simulation years (pairwise Spearman ρ = 1.00). Sensitivity magnitudes nevertheless varied among years. For example, the total-effect index of Kcb for evapotranspiration ranged from 0.762 to 0.882, while the CCx index for maximum canopy cover ranged from 0.836 to 0.957. Four-year equal-weight means are therefore used as descriptive summaries of the common experimental design, with the individual annual estimates and their range shown explicitly. They are not interpreted as year-invariant contributions or as Sobol indices for a pooled climate distribution.

Yield sensitivity was dominated by late-period WP and HI0. The ST values of late-period WP ranged from 0.353 to 0.426, whereas those of HI0 ranged from 0.203 to 0.208. The annual-mean ordering of early-period WP and Kcb was nearly tied in 2022, and scramble-level uncertainty prevents a strong distinction between their ranks. Numerical repeatability within years and consistency between years are reported separately.

## 图文状态

四组英文PNG/PDF/SVG已制作，CSV与Excel保留原数据和全部汇总。cat/coc映射待确认。本部分暂不打包发送，随所有修订统一交付。
