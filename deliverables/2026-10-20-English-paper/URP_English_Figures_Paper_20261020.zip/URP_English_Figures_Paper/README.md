# URP 四年英文图、数据与论文骨架

本包对应2026-10-20本轮统一修订，2019、2020、2021、2022均完整保留。

## 先打开这些文件

- **URP_Paper_Skeleton_EN_Figures.docx**：可编辑Word。按参考论文的“模型与MCMC—敏感性—优化—讨论”思路，逐节说明写什么、配哪些图表及怎样解释；后附43组英文图、英文图注和逐图中文解析。高幅参数图在Word中分为两页，完整大图另存。
- **URP_Paper_Skeleton_EN_Figures.pdf**：上述Word的排版预览。
- **URP_Paper_Tables.xlsx**：精简论文表格，5张主表＋10张补表，含目录。
- **URP_All_Figure_Data.xlsx**：完整图表源数据工作簿，91个数据表，另有目录和逐图解析。
- **URP_All_English_Figures.pdf**：43组矢量英文图的连续浏览版，不含中文正文。
- **figures/**：每组均有600 dpi PNG、矢量PDF、可编辑SVG。
- **tables/**：完整精度CSV、补充全范围评估表及此前分部分工作簿。
- **analysis/URP_Figure_Interpretations_CN_EN.md**：每张图的英文图注、回答的问题、真实结果、正文写法及解释边界。
- **tables/Original_to_English_figure_map.csv**：原32组历史图到英文图的映射，F01–F17全部覆盖。
- **tables/Manuscript_figure_plan.csv**：正文建议10组主图及章节位置；其余图作为补图或替代布局。

## 参考论文与口径

参考Liu等（2025）：*An integrated data assimilation, crop modeling, and multi-objective optimization framework for improving cotton irrigation water use efficiency*, Agricultural Water Management 319, 109774，DOI: https://doi.org/10.1016/j.agwat.2025.109774。已核对用户提供的原PDF，借鉴论证结构与图表逻辑，不挪用棉田数据、百分数、参数排名或SMT决策定义。

本项目是四个年度DI玉米情景，不自动等于四个独立试验地块。原MCMC冻结且未在本轮延长；阶段二是条件推断，严格收敛及边界限制仍保留。Sobol为八参数共同独立均匀范围的实际模型结果，不称相关后验Sobol。正式NSGA-III/II为固定中心双目标、100个体×100代×5种子；四个固定日期窗口调整水量，不优化日期。补充全范围试验80个体×60代×3种子，共57,600次评估，与正式实验分开记录。

大比例减少施灌水量不等于同幅减少ET或长期可持续节水。候选近95%观测产量门槛是最低灌水筛选规则的结果，不能称“完全不减产”；两阶段条件扰动不是联合稳健优化或田间达标概率。旧的后验Sobol、未经核对的三目标/标准差代理图不作为本轮正式结果；以本包实际计算口径替代。

**仍待用户核定的自定义名称**：Y_catmul、Y_tot、cat、coc。本包未擅自映射。原F13门槛图已英文化；另提供N02的37对四年生物量OLS回归，横纵轴明确命名，并标出R²和Pearson r。试验元数据、重复数及误差出处仍按Word中的标记在投稿前核定。

## 独立复绘与代码

本包已在独立输出目录完成全部43组复绘检查。无需原作物模型，不重跑MCMC或优化；复绘使用保留的实际响应、配对表及冻结样本。示例：

```bash
python -m pip install -r scripts/requirements-figures.txt
python scripts/rebuild_packaged_figures.py --out recreated_English_figures
```

`--out`请指定新的空目录。`make_remaining_english_figures.py`生成本轮新增23组；`build_paper_skeleton.py`生成论文骨架、图册和完整数据工作簿。Word转PDF另需LibreOffice。依赖版本见`verification/DOCUMENT_AND_PLOT_DEPENDENCIES.json`。

`scripts/part1_*`至`part4_*`是先前计算/修订阶段的原始来源代码，其中单独的历史主入口仍含原项目路径。统一复绘入口会用本包数据建立临时输入，不要求复制原云环境路径。`model_records/`提供复绘所需冻结数组及资料；完整作物模型和全部正式优化种群原始记录仍保留于此前项目及六个运行交付包，不与本次图文包的内容混称。

## 校验

`verification/`保存图件英文与边界检查、源表/Excel比对、原图诊断、独立复绘及Word分页检查。`MANIFEST.json`与`SHA256SUMS.txt`用于核对完整性。这里的检查证明文件与数据处理一致，不替代独立田间验证。

本轮统一交付上传至此前授权的`delivery/urp-review-20261015`分支，主分支不变。历史分部分说明保留其阶段日期；以本README和本轮质量记录为最终交付状态。
