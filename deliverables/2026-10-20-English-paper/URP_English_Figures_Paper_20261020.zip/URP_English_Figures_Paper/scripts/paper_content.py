"""Source-based figure interpretations and the manuscript writing plan."""
from pathlib import Path
import json
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
YEARS=[2019,2020,2021,2022]
def read(name):return pd.read_csv(ROOT/'tables'/name,float_precision='round_trip')

MAIN=[
 ('Fig. 1','Figure1_three_column_EN','2.1 Overall framework'),
 ('Fig. 2','Figure10_environment_EN','2.2 Data and environmental conditions'),
 ('Fig. 3','F02_CC_trajectories_EN','3.1 Calibration performance'),
 ('Fig. 4','F05_Biomass_pairs_EN','3.1 Calibration performance'),
 ('Fig. 5','F07_parameter_intervals_EN','3.2 Parameter identifiability'),
 ('Fig. 6','R01_Sobol_four_outputs_2x2_EN','3.3 Annual sensitivity patterns'),
 ('Fig. 7','R02_Sobol_Yield_all_years_mean_EN','3.3 Annual sensitivity patterns'),
 ('Fig. 8','R03_Gated_Pareto_fronts_EN','3.4 Irrigation–yield trade-offs'),
 ('Fig. 9','R04_irrigation_yield_comparison_EN','3.4 Irrigation–yield trade-offs'),
 ('Fig. 10','S07_Irrigation_reduction_decomposition_EN','3.5 Water balance and applicability'),
]

def interpretation(e):
    name=e['name'];metrics=read('Calibration_metrics.csv')
    common='四年颜色统一为2019蓝、2020橙、2021绿、2022紫。'
    purpose='说明该图所对应的模型证据。';finding='结果来自本包源表。'
    writing='先交代图中变量、样本与比较基准，再写结果及其适用范围。'
    limit='模拟结果不能替代独立田间验证。'
    placement=next((n+'；'+s for n,f,s in MAIN if f==name),'补充材料或正文备选图')
    if name.startswith('Figure1_'):
        purpose='说明从资料、分阶段校准到敏感性分析、优化和核验的完整衔接。'
        finding='四年原模型已接入；MCMC冻结；正式Sobol为N=512×3种子；双算法优化各100个体×100代×5种子。'
        writing='研究按“过程复现—参数贡献—管理权衡—水量与条件扰动核验”组织。三列版适合正文；树状版作为替代布局，不重复入正文。'
        limit='流程完成不表示采样诊断全部通过，也不表示参数不确定性已在寻优中传播。'
    elif name=='Figure10_environment_EN':
        d=read('Figure10_window_summary.csv')
        purpose='说明四年模型实际采用的天气驱动及比较窗口。'
        finding='模型日历合计599天；四年降雨分别约177.9、113.5、143.3、151.4 mm。逐日ETo与降雨保持源值，不插值或按年缩放。'
        writing='先描述需水与供水过程差异，再讨论其可能影响；ETo为参考蒸散，不能与后续模拟实际ET混称。'
        limit='仅四个年度情景；气象差异与参数、初始水差异并存，不能由本图识别单一气候因果效应。'
    elif name.startswith('F02_') or name.startswith('F04_'):
        a=metrics[metrics.Variable=='CC']
        purpose='检查冠层季节过程及配对拟合的一致性。'
        finding=f'共48对；年度校准R²为{a.R2_calibration.min():.3f}–{a.R2_calibration.max():.3f}，RMSE为{a.RMSE.min():.3f}–{a.RMSE.max():.3f}（比例）。2022相对较弱。'
        writing='F02用于正文叙述冠层生长和衰老过程；F04以1:1线检查系统偏差，作为替代或补图，避免重复宣称两次验证。'
        limit='田间LAI转换CC属于校准数据；曲线为冻结参数中心的确定性轨迹，不是后验预测均值或区间。'
    elif name.startswith('F03_') or name.startswith('F05_'):
        a=metrics[metrics.Variable=='Biomass']
        purpose='检验地上干生物量累积及观测—模拟配对误差。'
        finding=f'四年共37对；R²cal为{a.R2_calibration.min():.3f}–{a.R2_calibration.max():.3f}，RMSE为{a.RMSE.min():.3f}–{a.RMSE.max():.3f} t ha⁻¹。'
        writing='正文优先F05，报告各年样本数及是否偏离1:1线；F03用于补充季节累积过程。高相关与偏差较小应分别描述。'
        limit='含数字化生物量及假定误差尺度；所有配对为样本内校准，未构成独立验证。'
    elif name.startswith('F06_'):
        purpose='把冠层、生物量及季末产量误差放在同一年度框架下。'
        finding='2022冠层RMSE最高，但生物量RMSE最低；不同输出的拟合优劣不必一致。年度籽粒产量偏差约−4.18%至+0.92%。'
        writing='先说明各指标单位，再解释不同观测约束对过程与终值的贡献，不把不同量纲RMSE直接比大小。'
        limit='±5%灰带是项目容许幅度，不是统计置信区间；年产量每年只有一个观测终值。'
    elif name.startswith('F07_'):
        purpose='同时显示保留样本分位区间、年际差异和实际先验边界。'
        finding='2019/2020 CCx在上界1%支持宽度内的样本质量约22.14%/23.06%；2020/2021早期WP下界附近约11.43%/23.65%。'
        writing='可写“保留样本均在支持域内，但部分参数仍存在边界邻近集中”；不能写“完全没有撞墙”。用S02对照定量边界质量。'
        limit='2.5%–97.5%为相关保留样本的经验分位区间；阶段二条件于阶段一交接点，不是经认证的八维联合后验。'
    elif name.startswith('F08_'):
        a=read('F08_phase2_correlation.csv')
        purpose='观察晚期水分生产率与收获指数之间的条件补偿。'
        finding='HI0与晚期WP的Pearson r依次为'+ '、'.join(f'{v:.3f}' for v in a.Pearson_r)+'，均呈负相关。'
        writing='说明不同参数组合可能给出相似生物量—产量终值，因而拟合良好不等于每个参数都能唯一识别。'
        limit='r使用同一行的全部保留样本计算，散点只为显示抽稀；不推断因果，不用该图认证收敛。'
    elif name.startswith('F09_') or name.startswith('S03_'):
        purpose='检验入流、出流与储水定义以及水量闭合。'
        finding='2021基准季末土壤水约705.7 mm，比初始增加约170.0 mm；其他年度初末变化不同。四年水量残差在数值精度范围内。'
        writing='年度三线版用于跨年比较；原柱状账是补图。明确I+P−ET−径流/排水=ΔS，绝对季末储水不能直接代入ΔS。'
        limit='年际连线不是趋势检验。土壤剖面总储水不等于作物根系可利用水。'
    elif name.startswith('F11_'):
        purpose='区分田间LAI转换CC与遥感时序的证据角色。'
        finding='田间DI序列用于校准；遥感未入似然，2019–2021为BI标签，2022处理标签不完整。'
        writing='两来源时序只作辅助比较，并讨论转换与处理差异；不把灰线接近彩线写成DI独立验证。'
        limit='遥感CCquad由百分数转比例；横轴为模型起点后的日数，不能混用未经核实的物候日期。'
    elif name.startswith('F12_'):
        purpose='给出原采样预算、截断后长度与自相关时间的关系。'
        finding='原ensemble均为32 walkers、2,000步；阶段一每年4个ensemble，阶段二每年1个；阶段一长度不足50τ参考。'
        writing='将“采样设置”和“实际诊断”分开报告。参考论文采用相似步数不能证明URP也收敛。'
        limit='walker不等于独立链；保留行数不等于ESS。阶段二不能仅因超过50τ就宣称完成严格收敛诊断。'
    elif name.startswith('F13_'):
        purpose='解释优化的产量门槛及模型偏差带来的实际余量。'
        finding='2021模型基准约15.197，95%观测门槛15.067 t ha⁻¹，相对模型基准可下降余量仅约0.86%。'
        writing='门槛以发表观测Yobs为分母，模型基准只用来衡量余量；这也解释2021可行前沿产量范围较窄。'
        limit='这是原F13门槛图英文化，尚未把Y_catmul或Y_tot映射为任何未经确认的列；N02另给明确变量名的回归图。'
    elif name.startswith(('F14_','F15_','F16_')):
        purpose='观察阶段二保留段中walker分布随原采样步变化。'
        finding='四年均完整保留；线为每步32个walker的中位数，浅带为10%–90%分位。图从原步号展示，仅保留段有值。'
        writing='检查明显漂移及分布范围；可说轨迹描述了保留段行为，但需要独立采样诊断才能判断收敛。'
        limit='阴影不是参数均值置信区间，也不是独立链间一致性证据；本轮没有延长原链。'
    elif name.startswith('F17_'):
        purpose='交代四个年度用于确定性下游模拟的八参数中心。'
        finding='参数中心为分阶段保留样本算术均值；晚期WP依次约30.58、25.85、21.91、31.50 g m⁻²，年度数值以源表为准。'
        a=read('central_vectors_with_provenance.csv')
        finding='晚期WP中心依次为'+ '、'.join(f'{v:.2f}' for v in a.WP_late)+' g m⁻²；各年中心与原冻结文件一致。'
        writing='说明中心参数用于可复现的条件模拟；年际差异可能包含气象、数据和可辨识性补偿，不直接解释为生理参数真实漂移。'
        limit='拼接阶段均值不构成完整联合后验的数学均值；年度虚线只是视觉连接。'
    elif name.startswith('S01_'):
        purpose='披露阶段一R-hat与ESS的严格诊断限制。'
        finding='既有阶段一未通过原严格R-hat/ESS条件；相关保留样本虽多，有效信息量仍受自相关和ensemble差异影响。'
        writing='正文用一段客观描述并引用补图，避免“高拟合说明MCMC充分收敛”的逻辑跳跃。'
        limit='热图只反映已有诊断记录，不是本轮新长链实验。'
    elif name.startswith('S02_'):
        purpose='把F07的边界观察转为可核对的比例。'
        finding='上/下界邻近带定义为各年支持宽度的1%；高质量集中见CCx及早期WP。'
        writing='报告具体参数、年份与比例，再讨论扩大合理支持或增加独立观测是否必要。'
        limit='1%带宽是描述选择，不是显著性阈值；不把无越界等同无边界影响。'
    elif name.startswith('R01_Sobol_ST_'):
        output=name.removeprefix('R01_Sobol_ST_').removesuffix('_EN')
        a=read('Sobol_four_year_descriptive_means.csv');a=a[a.Output==output].nlargest(3,'ST_four_year_mean')
        purpose='展示单一输出在四年、八参数下的总效应贡献。'
        finding='四年等权ST描述均值前三位：'+ '；'.join(f'{r.Parameter} {r.ST_four_year_mean:.3f}' for r in a.itertuples())+'。'
        writing='比较主导参数排序是否一致，再比较指数大小；与输出形成机理对照，不跨不同输入分布套用排名。'
        limit='这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。'
    elif name.startswith('R01_Sobol_four'):
        purpose='在同一色标和2×2布局下讨论年度稳定性与输出差异。'
        finding='产量以晚期WP和HI0为主；生物量以晚期/早期WP和Kcb为主；ET以Kcb为主；最大CC以CCx为主。四主输出年度均值排序的Kendall W均为1。'
        writing='强调“这四个年度均值的排序一致”，同时给指数范围；不能把排序一致改写为贡献完全不变。'
        limit='只有四个年度模拟情景；2022产量早期WP/Kcb在种子层面近似并列，年度均值相同排序不消除该不确定性。'
    elif name.startswith('S05_'):
        purpose='补充蒸腾与土壤蒸发分量的敏感性。'
        finding='Tr平均ST以Kcb约0.578为首；Es以CCx约0.718为首。两者对同一参数的贡献大小不同。'
        writing='用来解释总ET并不能代表所有水分分量的响应；区分冠层遮蔽对土壤蒸发的作用与Kcb对蒸腾的作用。'
        limit='水分分量的ST是不同输出方差的归一化比，不能相加成ET的ST。'
    elif name.startswith('R02_'):
        purpose='合并四年产量S1/ST，并展示年度值、等权均值和年际范围。'
        finding='晚期WP、HI0、早期WP、Kcb的四年ST均值约0.396、0.206、0.164、0.145；晚期WP年度范围约0.353–0.426。'
        writing='可以把均值作为四情景的描述摘要，因为高贡献层级总体一致；仍应保留年度点和范围，不用均值遮蔽近似并列。'
        limit='灰线是年际最小—最大范围而非置信区间；先年内平均3个scramble，再四年各1/4加权，不等于混合气候下重新计算Sobol。cat/coc尚无定义。'
    elif name.startswith('S04_'):
        purpose='报告Sobol数值估计的不确定性及种子重复性。'
        finding='N=512、每年3个scramble、512次bootstrap；24项筛查23项通过。2022产量早期WP与Kcb的ST均约0.139，排名随种子互换。'
        writing='将两者归为相近贡献层级，不强制严格先后。区分数值估计区间与年际变化范围。'
        limit='这里的95%区间不是田间产量预测区间，S1有限样本负值不强制改零。'
    elif name.startswith('R03_Gated'):
        purpose='展示正式产量门槛内的用水—产量权衡及算法对照。'
        finding='3,986条最终可行记录；NSGA-II/III前沿基本重合。2021可行产量约15.067–15.251 t ha⁻¹，独立纵轴截取使曲线显得陡。'
        writing='先交代I≤IDI和Y13≥0.95Yobs，再说明圈点为NSGA-III并集内最低灌水量候选。星号是模型基准，虚线是门槛。'
        limit='零灌溉被产量门槛排除；圈点不是几何膝点。曲线是搜索得到的非支配包络，未证明全局最优。'
    elif name.startswith('R03_full') or name.startswith('N01_'):
        purpose='把零灌溉及低水量区间补回，检验原局部图的解释。'
        finding='移除产量门槛的补充搜索共57,600次；四年零灌溉产量约9.071、6.184、6.140、5.850 t ha⁻¹，均明显低于DI。'
        writing='解释零灌溉仍可利用雨水和初始储水；区分固定比例剂量响应与择优包络。补充搜索预算与正式实验分开报告。'
        limit='仅补充诊断取消95%门槛；仍保留灌水上限，未新增储水约束。没有零灌溉田间验证，也未证明全局最优。'
    elif name.startswith('R04_'):
        purpose='直接比较观测、模型基准和主候选，并对应减灌水幅度。'
        finding='四年候选灌水约218.36、312.42、267.30、260.78 mm，较DI减少50.96%、44.19%、57.80%、35.58%。产量接近95%观测门槛。'
        writing='把候选产量相对观测和相对模型基准的变化分开。最低灌水规则导致候选靠近门槛，不是保产能力特别稳定的证据。'
        limit='95%虚线不是置信区间。减少灌水不能直接写为等幅减少ET或无条件节水不减产。'
    elif name.startswith('R05_'):
        purpose='把四窗口控制量解释到实际日期与单次水量。'
        finding='原事件数为8、8、7、5；2020主候选单次最大量约179.9 mm。日期固定，调整的是窗口总水量及相应事件水量。'
        writing='对照生长阶段解释水量重新分配，并说明设备上限尚未纳入，不能写成已经优化灌水日期。'
        limit='原始逐次记录才是实际用水，提前结束后取消的计划水量另列；需核实设施和入渗能力才能实施。'
    elif name.startswith('R06_'):
        purpose='比较同预算下两算法的多随机种子搜索行为。'
        finding='40次搜索共400,000次评估、4,000代记录；逐年并集HV相对差异绝对值小于0.07%，没有NSGA-III明显优越性的证据。'
        writing='报告中位数与种子范围，说明结果重复性；曲线趋于稳定不等于已达到数学全局最优。'
        limit='阴影是5种子最小—最大范围，不是置信区间。不同年份HV归一化背景不同，不横向排名算法性能。'
    elif name.startswith('R07_'):
        purpose='核查中心点可行候选对条件参数扰动是否敏感。'
        finding='四个主候选的组内门槛达标比例约0.281–0.555，Q05均低于相应门槛；仅中心点达标不代表扰动后高达标率。'
        writing='将这些结果作为风险提示与后续稳健优化动机，不能把本实验改称已完成稳健优化。'
        limit='每次只扰动一个阶段并固定另一个；Wilson区间仅描述给定经验池的重采样误差，不是田间失败概率，未含原链和模型结构误差。'
    elif name.startswith('S07_'):
        purpose='解释少灌的水量由哪些水量账差异构成。'
        finding='2021少灌366.2 mm，其中ET仅少8.6 mm，季末储水差356.7 mm，解释97.4%的减灌水量；四年储水项占比约83%–97%。'
        writing='明确“少灌水”和“少耗水”不同；2021基准增储约170.0 mm、候选耗储约186.7 mm，储水差包含两部分。'
        limit='不能把整个储水差都叫土壤水透支；无季末储水限制的单季方案不能保证跨季可持续。'
    elif name.startswith('R09_'):
        purpose='展示加入季末储水条件后结论的敏感性。'
        finding='事后筛选要求季末储水不低于DI时，既有点中四年减灌比例约8.75%、0.56%、0.23%、7.01%，明显小于原主候选。'
        writing='用来支持增加储水条件的重要性，注明筛选点已经回放，但没有重新优化。'
        limit='原DI季末值不自动等于合理可持续标准；未找到既有点不等于证明不可行。'
    elif name.startswith('N02_'):
        a=read('N02_Biomass_regression_summary.csv').iloc[0]
        purpose='提供明确变量名的四年生物量拟合直线图。'
        finding=f'37对数据的OLS R²={a.OLS_R2:.4f}，Pearson r={a.Pearson_r:.4f}；横轴模拟生物量，纵轴观测生物量。'
        writing='同时看OLS斜率、截距和相对1:1线的偏离；高r只是相关性，不能替代无偏性与独立验证。'
        limit='含年内重复日期和跨年合并效应，未给独立样本显著性推断；OLS R²与F05的1:1校准R²不同。未擅自解释Y_catmul/Y_tot。'
    else:raise ValueError('Missing interpretation: '+name)
    return dict(name=name,purpose=purpose,finding=finding,writing=writing,limitations=limit,
                suggested_placement=placement,caption_EN=e['caption'],source_tables=e['source_tables'],color_key=common)

SECTIONS=[
 ('题目与主线',[
  '建议中文题目：基于分阶段MCMC校准与Sobol分析的玉米灌溉—产量权衡及土壤储水代价。',
  '英文题目：Maize irrigation–yield trade-offs and soil-water storage costs informed by staged MCMC calibration and Sobol analysis.',
  '核心问题：过程拟合与参数识别是否可靠？主导参数在四年是否稳定？在95%观测产量门槛下能减少多少灌水，以及这种减少是否依赖季末储水？',
  '贡献宜落在四年原模型核验、敏感性层级比较与灌水—ET—储水的分辨。避免仅把MCMC、Sobol和NSGA-III串联本身写成方法创新；创新性仍需完整文献检索。']),
 ('参考论文怎样借鉴',[
  '参考：Liu, Y., Wang, Y., Šimůnek, J., & Liao, R. (2025). An integrated data assimilation, crop modeling, and multi-objective optimization framework for improving cotton irrigation water use efficiency. Agricultural Water Management, 319, 109774. https://doi.org/10.1016/j.agwat.2025.109774。已重新核对用户提供的11页PDF。',
  '沿用其论证顺序：整体框架（PDF第2页图1）→模型和MCMC（第3–4页、图2）→拟合评价（第6–7页图3–4）→Sobol（第7页图5）→帕累托与制度（第8–9页图6–7）→讨论及局限。',
  'URP必须保留的差别：四个年度DI玉米情景而非2020六个棉田；八参数两阶段条件校准而非其11参数设定；四固定日期窗口水量而非土壤水分阈值SMT；产量门槛为95%发表观测而非照搬其基准定义。',
  '参考论文第9页明确说明用参数均值优化、未完整传播后验不确定性。URP同样不能因为使用MCMC就把确定性前沿写为联合稳健最优，也不照搬该论文的增产、节水百分数或主导参数。']),
 ('摘要骨架：按五句话写',[
  '背景：节水灌溉决策需要同时解释作物过程、参数贡献和土壤水量来源，单独报告灌水下降容易高估效益。',
  '方法：以2019–2022年DI玉米资料和原年度模型为基础，冻结两阶段MCMC成果，复核过程拟合；在八参数公共独立范围内计算Sobol；以NSGA-III和同预算NSGA-II寻求产量与灌水量双目标权衡。',
  '校准与敏感性结果：48对CC和37对生物量具有较高样本内拟合度；产量四年ST描述均值中晚期WP约0.396、HI0约0.206，主要贡献层级较稳定。MCMC严格诊断限制在正文披露。',
  '决策与机理结果：满足95%观测产量门槛的中心点主候选减少灌水约35.6%–57.8%，ET仅降低约1.4%–5.2%；主要差异对应较低的季末储水，且条件扰动达标比例并不高。',
  '结论：模型支持单季灌水—产量权衡，但储水和参数条件敏感性限制了可持续推广。避免结尾写“已证明普适稳健节水不减产”。']),
 ('1 引言：四段建立研究问题',[
  '第1段讲灌溉决策的实际矛盾：既要产量又要减少取水；区分田间施灌水量、作物耗水及跨季土壤储水。引用本项目地区与作物的真实文献，地区坐标等未核定信息不能从参考棉田论文移用。',
  '第2段讲作物模型与参数校准的必要性：CC约束冠层过程，生物量与季末产量约束生产过程；不同参数组合可能补偿，拟合好并不保证参数唯一。',
  '第3段综述MCMC—Sobol—多目标决策的已有工作，指出输入分布依赖、年度稳定性、确定性优化与储水核算方面的缺口。参考论文是结构参照，不是所有方法选择的唯一依据。',
  '第4段给出三项可检验目标：复核四年过程与采样证据；比较共同参数范围下六输出敏感性及年度稳定性；评估受产量门槛约束的减灌潜力、储水代价及条件参数敏感性。']),
 ('2.1 整体框架',[
  '配Fig. 1（三列流程），树状图作为版式备选。文字逐一交代输入→两阶段校准→确定性中心→独立范围敏感性→固定窗口寻优→回代与条件扰动。',
  '解释三个不混淆：参数校准解决数据相容性；Sobol解决声明分布下的贡献；多目标优化解决管理权衡。三者并不自动构成联合后验风险优化。']),
 ('2.2 数据、环境与证据角色',[
  '写模型日历、天气、初始土壤水、灌水事件、CC、生物量和季末Y13的来源、单位和处理。配Fig. 2、Table 1；以F11说明田间和遥感资料的不同证据角色。',
  '四年气象窗口共599天，CC配对数12/13/11/12，生物量9/10/8/10；灌水事件数8/8/7/5。保留2021记录合计633.47 mm与发表值633.46 mm的0.01 mm差异，不改观测凑整。',
  '需在投稿前核定：试验地与坐标、品种、田间重复数、土壤分层、水力参数出处、数字化生物量误差及水分目标来源。这些资料不从拟合曲线推断，不把四年自动视为四独立地块。']),
 ('2.3 模型机制与两阶段MCMC',[
  '解释路径CC→蒸腾Tr→生物量B→收获指数与产量；ET=Tr+Es。前后期有效WP按实际年度源码实现；不要用一套未经核对的通用AquaCrop公式替代本项目分段和胁迫实现。Y13=Ydry/0.87，确认与观测的13%含水率定义一致。',
  '阶段一参数为CCx、CGC、CDC、衰老起始、Kcb，依据原模型CC及Tr/Es等目标约束；阶段二为早期WP、晚期WP、HI0，条件于固定阶段一交接点，结合生物量与干产量目标。参数/误差尺度应由原年度合同逐项列出。',
  '通式：p(θ|D)∝p(D|θ)p(θ)，log L=−(1/2)Σ[(f(θ)−D)/σ]²（权重及误差尺度依年度源码）。这是方法解释，不能据通式声称已经进行八维联合推断。',
  '配Table 2参数定义及公共Sobol范围；各年真实MCMC先验与边界质量另列补表。原链32 walkers、2,000步，阶段一4个ensemble、阶段二1个；列R-hat、ESS和τ，承认原严格诊断尚未满足。本轮未延长MCMC。']),
 ('2.4 拟合指标、误差与可辨识性',[
  '写R²cal=1−Σ(模拟−观测)²/Σ(观测−观测均值)²，RMSE与MAE。将1:1拟合R²与另拟合直线后的OLS R²区分；Pearson r仅描述相关。配Table 3及Fig. 3–5。',
  '说明CC和生物量为样本内校准，年产量每年只有一个终值，不单独算年度产量R²。N02的37对 pooled OLS仅作描述，观测嵌套在年份内，不用独立样本显著性推断。',
  '通过F08参数补偿、S01采样诊断、S02边界质量说明“过程拟合好”与“参数可靠识别”之间的区别。']),
 ('2.5 Sobol设计与跨年摘要',[
  '八参数采用共同的独立均匀范围；这些范围不是MCMC后验，也不自动等于原MCMC先验密度。S1=Var(E[Y|Xi])/Var(Y)，ST=E(Var[Y|X−i])/Var(Y)。',
  '正式N=512，3个scramble（101、202、303），四年、六输出；未算二阶，设计响应数为N(D+2)×3×4=61,440。各指标用512次bootstrap估计数值半宽。先前N128属于前期筛查，不混入最终均值。',
  '先每年对3个scramble平均，再四年等权1/4汇总；用年度点、范围、Spearman/Kendall排名一致性和种子区间共同说明稳定程度。配Fig. 6–7、Table 4，Tr/Es和数值区间保留补图。',
  '解释为什么可以取平均：这四个年度的主要贡献层级相近，因此均值可作描述摘要；它不是在混合天气分布下重新计算的Sobol，也不是年际完全不变的统计证明。2022早期WP/Kcb保留近似并列。cat/coc若需额外指标，必须先给出列名和定义。']),
 ('2.6 NSGA-III双目标与公平对照',[
  '设a=(a1,a2,a3,a4)为四有序窗口水量，固定原事件日期及窗口内比例。目标min f(a)=[−Y13(a), Iactual(a)]；约束0≤Iactual≤IDI、Y13≥0.95Yobs，并满足非负窗口量及原修复规则。图中实际水量与计划量分列。',
  'NSGA-III与NSGA-II同预算：每算法每年100个体×100代×5种子（31、73、109、151、199），合计40次搜索、400,000次评估。按同年同一归一化和参考点计算HV。III是算法代别，不是只跑3代或必然3个目标。',
  '主候选取NSGA-III五种子非支配并集内门槛可行的最低灌水量点，邻近替代点另列。它不是几何膝点。配Fig. 8–9及候选Table 5；算法历史与逐次灌水放补图R06/R05。',
  '原目标未包括季末储水与设备单次能力，不把后验标准差冒充已优化的第三目标。全部是冻结年度中心和已知年度天气的回顾性决策，不是实时预报灌溉。']),
 ('2.7 回代、完整水量账与补充试验',[
  '候选回代核对产量、实际灌水、逐日通量和水量闭合。I+P+CR+GW−ET−径流−排水=ΔSsoil+ΔSsurface。早终止后保留真实产量，按原日历完成水量账，取消作物结束后的灌水并保留覆膜假设；该管理边界需核实。',
  '同年基准与候选初始条件一致，分解ΔI=ΔET+(Send,base−Send,cand)+地表储水变化差+损失减少−其他入流差。配Fig. 10及水量补表，明确储水差与额外耗储不是同一个量。',
  '两组条件扰动各128次整行抽样，分别固定另一组中心，报告Q05和门槛比例；不是联合后验优化，128也不等于原链ESS。配R07和补表。',
  '含零水量的全范围NSGA-III是另一个补充试验：80个体×60代×3种子×4年=57,600次，另有84次固定比例剂量和8次零/DI回放；仅取消95%产量门槛，保留水量上限。配N01和全范围四小图，预算不能混写成正式40次实验。']),
 ('3.1 结果：过程拟合先于管理解释',[
  '配Fig. 3–4和Table 3。先写冠层过程，再写生物量配对误差，最后核对年度产量偏差，避免只凭终产量误差小认定所有过程正确。',
  '可写：四年CC校准R²约0.931–0.993、RMSE约0.032–0.060；生物量R²约0.969–0.997、RMSE约0.556–1.252 t ha⁻¹。2022冠层拟合相对较弱，生物量拟合较强，提示不同过程约束提供不同信息。',
  '解释后紧接证据限制：这些是校准表现；不能换词写为独立验证或未来年份的预测精度。']),
 ('3.2 结果：参数区间与补偿',[
  '配Fig. 5，F08/F12/F14–F17和诊断图为补充。逐项写主要年际差异、区间宽度、边界邻近质量，不对每条波动强行赋予生理意义。',
  '可写：HI0与晚期WP保留样本存在负相关，说明终值可由不同参数组合补偿；部分CCx或早期WP集中在支持边界附近。高拟合与充分可辨识不等同，现有严格采样诊断限制仍保留。']),
 ('3.3 结果：敏感性及年度稳定性',[
  '配Fig. 6–7和Table 4。先讲不同输出的主导机制，再讲四年排序与大小变化，最后报告数值不确定性。',
  '可写：产量ST四年描述均值中晚期WP约0.396、HI0约0.206；ET主要受Kcb影响（均值约0.837），最大冠层主要受CCx影响（约0.911）。四主输出年度均值排序一致，但晚期WP产量ST仍在约0.353–0.426变化。',
  '2022产量早期WP与Kcb在种子层面近似并列；不把微小均值差写成稳定的严格名次，也不据此删去当前八参数或改变优化变量。']),
 ('3.4 结果：可行前沿与主候选',[
  '配Fig. 8–9和Table 5。先写约束和可行区，再写候选的实际I、Y及两类产量相对变化；算法差异单独用HV补表，不凭平滑外观比较算法。',
  '可写：四年最低灌水量主候选约218.36、312.42、267.30、260.78 mm，较DI减少约51.0%、44.2%、57.8%、35.6%。对应产量接近95%观测门槛，因此不能概括成完全不减产。',
  '解释原R03理想化外观：只保留高产可行解、纵轴局部放大、不同分配方案择优包络。用N01完整低水量区间说明零灌溉仍显著减产，四年模拟约5.85–9.07 t ha⁻¹。']),
 ('3.5 结果：储水代价与条件敏感性',[
  'Fig. 10为关键机制证据。可写：2021灌水下降57.8%，ET仅下降1.43%；季末储水比基准低356.7 mm，解释97.4%的减灌水量。基准增储和候选耗储必须分列，不能全部称为额外土壤水透支。',
  '配R09及储水筛查补表：追加不低于基准季末储水的事后筛查使既有点减灌比例约降至8.75%、0.56%、0.23%、7.01%。说明结论依赖储水要求，但不是新增约束下已重新求得的最优值。',
  '配R07：主候选两组条件扰动达标比例约28.1%–55.5%，提示中心点门槛可行的方案对参数条件敏感。它不是田间达标概率，亦不支持把现方案称为稳健保产制度。']),
 ('4 讨论：每段用结果解释，不重复报数',[
  '4.1 数据与校准：讨论LAI→CC、数字化生物量、年度目标误差和参数补偿；说明参考论文与本项目证据角色差异，不能混称遥感独立验证。',
  '4.2 参数贡献与模型机制：解释晚期WP/HI0对产量、Kcb对ET、CCx对冠层及蒸发的贡献；强调敏感性依赖声明范围，不能泛化为任何先验或后验分布下都如此。',
  '4.3 少灌水为何不是同幅少耗水：围绕Fig. 10区分减少基准补水、增加耗储和ET变化。讨论跨季补水、根区可利用水和流域尺度问题；没有数据不量化更大尺度节水。',
  '4.4 管理可实施性：固定日期与四窗口重新分配的适用范围；2020单次约179.9 mm需设施核验。未来天气、人工轮灌、最小事件量、土壤水底线不在原目标内。',
  '4.5 局限与完善：优先改善原MCMC诊断和先验可辨识性；补独立/留一年验证；定义农学储水和设备限制后重新优化；再基于合适的联合参数或天气情景设计稳健目标。不能将这些计划写入“已完成方法”。']),
 ('5 结论：三条对应研究目标',[
  '结论1：四年模型能复现主要冠层、生物量和产量校准资料，但参数边界、条件推断及采样诊断限制尚存；不写为全面独立验证。',
  '结论2：共同独立范围下主要敏感性层级在四年较稳定，年度幅度及近似并列仍需保留；四年均值只是描述摘要。',
  '结论3：门槛约束下存在较低灌水的中心点候选，但ET降幅远小于灌水降幅，且储水与参数敏感性限制了持续应用；需更完整约束和独立检验。']),
 ('表图安排与投稿前核对',[
  '建议正文10组图、5张主表。图册收齐全部43组英文图，剩余图作为补充或替代显示，不要求全部塞入正文。图号以本文建议顺序重排，文件仍保留原F/R/S编号以追溯。',
  '逐图至少写清：图中变量和误差条含义→主要年度结果→机制或选择规则→能支持什么及不能支持什么。不要仅写“如图可见”。本文件后半部分已为每组图提供对应解析。',
  '投稿前待核定字段：试验元数据、数字化误差出处、Y_catmul/Y_tot和cat/coc的正式定义。原F13门槛图已英文化；新增N02明确使用模拟/观测生物量，不擅自改名为未知列。']),
]

def build():
    registry=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text())
    analyses=[interpretation(e) for e in registry['figures']]
    assert len(analyses)==43
    (ROOT/'analysis/FIGURE_INTERPRETATIONS.json').write_text(json.dumps(analyses,ensure_ascii=False,indent=2))
    text='# 全部英文图逐图解析\n\n'
    for i,a in enumerate(analyses,1):
        text+=f'## {i}. {a["name"]}\n\n建议位置：{a["suggested_placement"]}\n\n英文图注：{a["caption_EN"]}\n\n'
        for label,key in [('回答的问题','purpose'),('实际结果','finding'),('正文怎样写','writing'),('解释边界','limitations')]:text+=label+'：'+a[key]+'\n\n'
        text+='数据：'+', '.join(a['source_tables'])+'\n\n'
    (ROOT/'analysis/URP_Figure_Interpretations_CN_EN.md').write_text(text,encoding='utf-8')
    mapping=pd.DataFrame([dict(Manuscript_figure=n,File=f,Section=s) for n,f,s in MAIN])
    mapping.to_csv(ROOT/'tables/Manuscript_figure_plan.csv',index=False)
    return analyses

if __name__=='__main__':build()
