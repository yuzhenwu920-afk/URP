"""Write interpretation after the supplied R03/R04 have been diagnosed."""
from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parent


def main():
    proof = json.loads((ROOT / 'FULL_RANGE_VERIFICATION.json').read_text())
    diagnosis = json.loads((ROOT / 'R03_DIAGNOSIS_STATUS.json').read_text())
    assert proof['status'] == diagnosis['status'] == 'PASS'
    z = pd.read_csv(ROOT / 'tables/Zero_irrigation_reference.csv')
    t = pd.read_csv(ROOT / 'tables/R03_irrigation_ET_storage_tradeoff.csv')
    annual = '\n'.join(
        f'{int(r.Year)}年：灌水量减少{r.Irrigation_reduction_pct:.1f}%，'
        f'ET减少{r.ET_reduction_pct:.2f}%；季末土壤储水比基准低'
        f'{r.Lower_final_soil_storage_mm:.1f} mm，该项解释'
        f'{r.Storage_difference_share_of_irrigation_reduction_pct:.1f}%的减灌水量。'
        for r in t.itertuples(index=False))
    zeros = '\n'.join(
        f'{int(r.Year)}年：零灌溉模拟产量{r.Zero_Y13:.3f} t ha⁻¹，'
        f'DI模型基准{r.DI_baseline_Y13:.3f} t ha⁻¹，'
        f'相对下降{-r.Zero_yield_change_pct_vs_DI:.1f}%。'
        for r in z.itertuples(index=False))
    text = '''# 第四部分：原图诊断、优化前沿与灌水—产量权衡

## 原图已核对：数值可保留，结论需要限定

用户已提供R03四年可行帕累托前沿及R04灌水—产量对照原图。图形身份、候选点、模型基准和95%观测产量门槛与原正式实验源表吻合；3,986条最终可行前沿记录全部满足门槛与年度灌水上限。R04右图英文版已在诊断完成后定稿，并另留整幅英文双图。

R03在当前模型和约束下数值自洽，但不能单独证明无条件节水不减产、长期可持续节水或NSGA-III算法优越性。应将大比例“节水率”改写为“相对原DI方案的灌水量减少比例”，并同时报告ET与土壤储水代价。这是论文结论需要实质修改的地方。

当前资料对应2019–2022四个年度DI情景，不能擅自称为四个独立地块。模型基准和优化候选均为模拟；发表观测另列。Y13为13%含水率籽粒产量。

## 为什么原R03看起来过于理想

原图只保留Y13 ≥ 0.95 Yobs且灌水不超过年度DI上限的可行解，并非从零灌溉开始的完整剂量响应。四年零灌溉产量均低于门槛，不出现在原图里是约束筛选的结果。

各小图独立截取高产窄区间。2021年前沿产量约15.067–15.251 t ha⁻¹，纵轴尤其窄；模型基准本就低于观测，95%观测门槛只允许相对模型基准约0.86%的下降。局部斜率陡、很快进入平台不代表低水量段也高产。英文重绘保留局部图，并配套含零灌溉点的全范围图。

非支配筛选形成的是已评估方案中的高产候选包络，不是一套固定灌水模式随水量变化的连续响应。折线只连接实际非支配点，未拟合或强制平滑为S形，也未证明全局最优。

四个主候选按NSGA-III五种子并集内的最低灌水量选择，满足95%观测产量约束，因此产量接近门槛是筛选规则的结果。它们不是几何膝点，也没有要求相对模型基准零减产。2019年候选相对观测减产约4.95%，相对模型基准减产约5.81%；两种分母必须区分。点位距门槛很小，不代表田间保产概率高。

## 水量账：减灌水主要对应季末储水差异

''' + annual + '''

同年基准与候选的初始储水、降雨及其他入流一致。分解满足：减灌水量 = ET减少量 + 季末土壤储水差 + 地表储水变化差 + 径流/排水减少量 − 其他入流差。本资料地表储水变化差和其他入流差均为零，核对残差小于10⁻⁷ mm。

2021年减灌约366.2 mm，而ET仅减少8.6 mm；候选季末储水比基准低356.7 mm。基准相对初始值增加约170.0 mm，候选减少约186.7 mm。因此356.7 mm包含减少基准补水和额外消耗储水两部分，不能全部叫作“透支土壤水”。灌水量降低57.8%与耗水量降低1.43%描述不同现象。

未设季末储水下限，不能把单季候选推广为可年年重复的通用方案。根系可利用水与剖面总储水也不同；下一季能否补回水量未在本轮优化中验证。

## 零灌溉机理及实际模型参照

零灌溉仍有降水与根区初始可利用水，故不必零产量。缺水可限制蒸腾、生物量和收获指数，减产程度受降雨时段、土壤与根系影响。同年度天气、土壤、参数中心和覆膜管理定义一致的回放得到：

''' + zeros + '''

结果与“零灌溉显著减产但不必绝收”的常规机理相容，与原高产可行前沿没有数值冲突。但它们仍是模型内部条件参照，缺少零灌溉田间观测，不能当作外部验证。降水量不等于有效降水，初始剖面总储水不等于根系可利用水。

## 新增全范围产量—灌溉图的计算身份

补充诊断使用原年度模型重跑NSGA-III：每年3种子、80个体、60代，共57,600次新搜索评估，另有84次固定比例剂量回放及8次零灌溉/DI回放。各代X/F/G/CV、全部响应和水量账均保留并核对。参数中心冻结，原MCMC未重跑。

补充计算保留年度DI灌水上限，只在此诊断中移除95%观测产量门槛，以覆盖零与低灌水区间。决策仍为四个固定日期窗口总水量，组内原比例不变，日期未优化。该补充实验独立于正式100个体×100代×5种子、设产量门槛的NSGA-III/II比较。

N01合并四年最佳已知非支配包络；R03_full_range四小图另示固定比例剂量响应、零灌溉、原DI模型基准及仅作参照的95%门槛。最佳已知包络不证明全局最优，也没有新增季末储水或单次供水能力限制。

## 算法比较与后续怎样完善

相同预算下，NSGA-III与NSGA-II前沿几乎重合。逐年并集归一化HV相对差异绝对值均小于0.07%，不能宣称三代算法更优；本项目实际优化是产量与实际灌水量两个目标，“III”是算法名称，不代表已经实现三个目标。跨年HV不直接互比。

建议在有农学依据后增加季末根区/剖面储水下限、单次灌水能力、时段供水量和最小灌水量等限制，再重求前沿。2020年候选单次最大灌水约179.9 mm，需核对设施与入渗能力；现有输入没有该上限，不擅自补人为阈值。

已有终端储水筛选显示：若要求季末储水不低于原DI基准，旧搜索点中四年的最低灌水减少比例约8.75%、0.56%、0.23%、7.01%。这些点已回放，但只是事后筛选，不是新增约束下重新优化的最优解。原DI过量补水时，其季末值也不应自动成为通用可持续标准。

若要求不低于本年初始储水，现有点的减灌空间为2019年约0%、2020年约13.0%、2021年约27.5%；2022年未找到符合条件的既有点，不代表已证明不可行。阈值需结合根区持水、下一季播种水分及降雨补给确定。

后续可增加留一年验证、独立田间验证及天气不确定性。现有分组条件MCMC扰动不等于八维联合后验稳健优化，当前确定性前沿也未包含模型结构或未来天气风险。这些扩展未在本轮悄然加入。

## 可用于正文的英文解释

The apparently steep yield–irrigation trade-offs partly reflect constraint filtering and axis truncation. The main fronts contain only solutions satisfying Y13 ≥ 0.95 Yobs and the annual DI irrigation cap. Zero-irrigation simulations fall below this yield gate in all four years and are therefore excluded. Minimum-irrigation candidates lie close to the threshold by construction; they are not geometric knee points. The year-specific axes show a zoomed feasible region, whereas a separate full-range diagnostic retains zero- and low-irrigation responses.

Reductions in applied irrigation should be distinguished from reductions in consumptive water use. In 2021, applied irrigation declined by 57.8%, but seasonal ET declined by only 1.43%. The candidate ended with 356.7 mm less soil water than the DI baseline, explaining 97.4% of the irrigation reduction. This difference combines avoided baseline recharge and additional depletion. Because terminal soil storage was unconstrained, the result cannot establish the sustainability of repeated application across seasons.

NSGA-III and the equal-budget NSGA-II comparator produced nearly overlapping two-objective fronts. These results support a within-model description of feasible irrigation–yield trade-offs rather than a claim of NSGA-III superiority or field-validated optimality. The supplemental full-range search used frozen annual parameter centers and retained the irrigation cap, while removing the yield gate solely for diagnosis.

## 图件与交付安排

R04_right为所要求的右图独立英文版；R04_irrigation_yield为整幅英文双图，左图标注灌水量减少比例；R03_Gated为原图英文重绘；S07为新增水量分解图。全部四年完整，统一年度配色、英文单位与字体，输出600 dpi PNG、矢量PDF和可编辑SVG。虚线门槛不是95%置信区间，不添加无来源误差条。

原图专项诊断与R04英文化已完成；F13及R02的变量定义问题保留在总待确认表中。本阶段继续暂存，待所有部分修改完成后统一打包，不逐部分发送下载链接。
'''
    (ROOT / 'PART4_ANALYSIS_NOTES.md').write_text(text, encoding='utf-8')
    (ROOT / 'AGRONOMIC_EXPECTATION_AND_ZERO_REFERENCE.md').write_text(
        '# 零灌溉的机理与模型参照\n\n' + text.split('## 零灌溉机理及实际模型参照')[1].split('## 新增')[0],
        encoding='utf-8')
    (ROOT / 'R03_DIAGNOSIS.md').write_text(text.split('## 新增全范围')[0]
        + '\n## 后续完善\n\n' + text.split('## 算法比较与后续怎样完善')[1].split('## 可用于正文')[0],
        encoding='utf-8')
    print('Original R03 diagnosed; R04 English finalized; numeric interpretation updated')


if __name__ == '__main__':
    main()
