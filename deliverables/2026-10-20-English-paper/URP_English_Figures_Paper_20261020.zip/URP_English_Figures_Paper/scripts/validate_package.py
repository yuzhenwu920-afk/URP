"""Check all plot/text assets, source references and final Word pagination."""
from pathlib import Path
import json,re
import fitz
from PIL import Image
from docx import Document
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]

def main():
    figures=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text())['figures']
    analyses=json.loads((ROOT/'analysis/FIGURE_INTERPRETATIONS.json').read_text())
    assert len(figures)==len(analyses)==43
    bounds=[]
    for e in figures:
        assert e['years']==[2019,2020,2021,2022]
        for name in e['source_tables']:assert (ROOT/'tables'/name).is_file()
        with fitz.open(ROOT/'figures'/(e['name']+'.pdf')) as d:
            assert len(d)==1
            assert not re.search('[\u3400-\u9fff]',d[0].get_text())
            for block in d[0].get_text('dict')['blocks']:
                for line in block.get('lines',[]):
                    for span in line['spans']:
                        x0,y0,x1,y1=span['bbox']
                        assert x0>=-.5 and y0>=-.5 and x1<=d[0].rect.width+.5 and y1<=d[0].rect.height+.5,(e['name'],span['text'])
        with Image.open(ROOT/'figures'/(e['name']+'.png')) as im:assert min(im.info['dpi'])>599
        assert (ROOT/'figures'/(e['name']+'.svg')).stat().st_size>500
        bounds.append(dict(figure=e['name'],English_text='PASS',PDF_text_bounds='PASS',PNG_dpi=600))
    assert len(Document(ROOT/'URP_Paper_Skeleton_EN_Figures.docx').inline_shapes)==45
    with fitz.open(ROOT/'URP_Paper_Skeleton_EN_Figures.pdf') as doc:
        pages=[]
        for i,p in enumerate(doc):
            text=p.get_text();images=len(p.get_image_info())
            assert len(text.strip())>100,(i+1,'nearly empty page')
            pages.append(dict(page=i+1,characters=len(text),images=images))
        assert sum(x['images'] for x in pages)==45
        first=next(x['page'] for x in pages if x['images'])
        assert not [x for x in pages if x['page']>=first and x['images']==0], 'Orphaned figure text page'
    original=pd.read_csv(ROOT/'tables/Original_to_English_figure_map.csv')
    assert len(original)==32 and sum(original.Original_figure.str.startswith('F'))==17
    assert set(original.English_figure)<={f['name'] for f in figures}
    assert all(json.loads((ROOT/'verification'/name).read_text())['status']=='PASS'
               for name in ['PORTABLE_REBUILD_CHECK.json'])
    q=dict(status='PASS_FOR_DELIVERED_FIGURES_AND_SKELETON',figure_groups=43,
        original_figure_groups_covered=32,original_F01_F17_complete=True,
        all_four_years=True,all_figure_labels_English=True,figure_interpretations=43,
        Word_pages=len(pages),Word_embedded_panels=45,no_blank_or_orphan_figure_pages=True,
        source_table_references='PASS',Excel_checks='WORKBOOK_CHECK.json',
        portable_43_group_rebuild='PASS',new_MCMC_runs=0,
        unresolved_custom_labels=['Y_catmul','Y_tot','cat','coc'],checks=bounds)
    (ROOT/'verification/FINAL_QUALITY_CHECK.json').write_text(json.dumps(q,ensure_ascii=False,indent=2))
    (ROOT/'verification/WORD_PAGE_INVENTORY.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in q.items() if k!='checks'},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
