"""Build the editable paper skeleton, complete annotated atlas and workbooks."""
from pathlib import Path
import json,re,hashlib
import numpy as np
import pandas as pd
from openpyxl.styles import Font,PatternFill,Alignment
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from PIL import Image
from paper_content import ROOT,YEARS,MAIN,SECTIONS,build,read


def publication_tables():
    climate=read('Figure10_window_summary.csv').set_index('Year')
    cal=read('Calibration_metrics.csv');gates=read('observed_yield_gate_headroom.csv').set_index('Year')
    rows=[];fit=[]
    for y in YEARS:
        c=cal[(cal.Year==y)&(cal.Variable=='CC')].iloc[0]
        b=cal[(cal.Year==y)&(cal.Variable=='Biomass')].iloc[0]
        rows.append(dict(Year=y,Weather_days=int(climate.loc[y].Days),CC_pairs=int(c.n),Biomass_pairs=int(b.n),
            Rain_mm=climate.loc[y].Precipitation_sum_mm,Observed_Y13_t_ha=gates.loc[y].Observed_Y13_t_ha,
            DI_irrigation_mm=gates.loc[y].Baseline_Irrigation_mm))
        fit.append(dict(Year=y,CC_R2_cal=c.R2_calibration,CC_RMSE=c.RMSE,
            Biomass_R2_cal=b.R2_calibration,Biomass_RMSE_t_ha=b.RMSE,
            Baseline_Y13_t_ha=gates.loc[y].Original_model_baseline_Y13_t_ha,
            Yield_bias_pct=gates.loc[y].Baseline_bias_pct_vs_observed))
    params=[];bounds=json.loads((ROOT/'model_records/project_config.json').read_text())['global_physical_bounds']
    meaning=['Maximum canopy cover','Canopy growth coefficient','Canopy decline coefficient','Senescence onset',
             'Basal crop coefficient','Early effective water productivity','Late effective water productivity','Reference harvest index']
    units=['fraction','d-1','d-1','d','dimensionless','g m-2','g m-2','fraction']
    for j,(key,limits) in enumerate(bounds.items()):
        params.append(dict(Parameter=key,Stage=1 if j<5 else 2,Meaning=meaning[j],Unit=units[j],
            Sobol_lower=limits[0],Sobol_upper=limits[1],Distribution='independent uniform; not MCMC posterior'))
    sobol=read('Sobol_four_year_descriptive_means.csv').query('Output == "Y_13pct"').sort_values('ST_four_year_mean',ascending=False)
    sobol=sobol[['Parameter','S1_four_year_mean','ST_2019','ST_2020','ST_2021','ST_2022','ST_four_year_mean','ST_year_min','ST_year_max']]
    c=read('R04_yield_comparison.csv');trade=read('R03_irrigation_ET_storage_tradeoff.csv')
    candidate=c.merge(trade,on=['Year','Irrigation_reduction_pct'],validate='one_to_one')
    d=read('NSGA_conditional_validation.csv');d=d[d.Candidate_ID.str.endswith('_C1')]
    d=d[['Year','Group','N','Mean_Y13','Q05_Y13','Probability_above_absolute_gate','Wilson_low','Wilson_high']]
    t={'Table1_study_data':pd.DataFrame(rows),'Table2_parameter_definitions':pd.DataFrame(params),
       'Table3_calibration_performance':pd.DataFrame(fit),'Table4_yield_sensitivity':sobol,
       'Table5_selected_candidates':candidate,'TableS1_MCMC_prior_and_boundary':read('F07_parameter_intervals_and_boundary_mass.csv'),
       'TableS2_MCMC_sampling':read('MCMC_existing_sampling_groups.csv'),
       'TableS3_MCMC_diagnostics':read('MCMC_existing_diagnostics.csv'),
       'TableS4_water_balance':read('F09_annual_water_budget.csv'),
       'TableS5_water_reduction_decomposition':trade,'TableS6_conditional_checks':d,
       'TableS7_algorithm_comparison':read('R03_algorithm_union_comparison.csv'),
       'TableS8_storage_post_filter':read('Terminal_storage_screening.csv'),
       'TableS9_zero_irrigation':read('Zero_irrigation_reference.csv'),
       'TableS10_Sobol_ranks':read('Sobol_output_rank_summary.csv')}
    for name,frame in t.items():frame.to_csv(ROOT/'tables'/(name+'.csv'),index=False)
    return t


def coverage():
    names={x['name'] for x in json.loads((ROOT/'FIGURE_REGISTRY.json').read_text())['figures']}
    mapping={
      'F01_workflow':'Figure1_three_column_EN','F02_CC_trajectories':'F02_CC_trajectories_EN',
      'F03_Biomass_trajectories':'F03_Biomass_trajectories_EN','F04_CC_pairs':'F04_CC_pairs_EN',
      'F05_Biomass_pairs':'F05_Biomass_pairs_EN','F06_calibration_summary':'F06_calibration_summary_EN',
      'F07_parameter_intervals':'F07_parameter_intervals_EN','F08_phase2_compensation':'F08_phase2_compensation_EN',
      'F09_water_ledger':'F09_water_ledger_EN','F10_climate':'Figure10_environment_EN',
      'F11_CC_evidence_roles':'F11_CC_evidence_roles_EN','F12_sampling_record':'F12_sampling_record_EN',
      'F13_yield_gate':'F13_yield_gate_EN','F14_phase2_trace_WP_early':'F14_phase2_trace_WP_early_EN',
      'F15_phase2_trace_WP_late':'F15_phase2_trace_WP_late_EN','F16_phase2_trace_HI0':'F16_phase2_trace_HI0_EN',
      'F17_parameter_centers':'F17_parameter_centers_EN',
      'R02_Sobol_Yield_CI':'S04_Sobol_yield_numerical_intervals_EN',
      'R03_Actual_Pareto_fronts':'R03_Gated_Pareto_fronts_EN',
      'R04_Water_and_yield':'R04_irrigation_yield_comparison_EN',
      'R05_Actual_irrigation_schedules':'R05_Actual_irrigation_schedules_EN',
      'R06_Seeded_convergence':'R06_Seeded_convergence_EN',
      'R07_Conditional_candidate_checks':'R07_Conditional_candidate_checks_EN',
      'R08_Water_saving_decomposition':'S07_Irrigation_reduction_decomposition_EN',
      'R09_Terminal_storage_screening':'R09_Terminal_storage_screening_EN',
      'S01_phase1_diagnostics':'S01_MCMC_stage1_diagnostics_EN'}
    for output in ['Y_13pct','B_t_ha','Tr_mm','Es_mm','ET_mm','MaxCC']:
        mapping['R01_Sobol_ST_'+output]='R01_Sobol_ST_'+output+'_EN'
    assert len(mapping)==32 and set(mapping.values())<=names
    frame=pd.DataFrame([dict(Original_figure=k,English_figure=v,Status='COMPLETE',Years='2019;2020;2021;2022',
        Formats='PNG 600 dpi; PDF; SVG') for k,v in mapping.items()])
    frame.to_csv(ROOT/'tables/Original_to_English_figure_map.csv',index=False)
    return frame


def workbook(analyses):
    files=sorted((ROOT/'tables').glob('*.csv'));index=[];seen=set()
    with pd.ExcelWriter(ROOT/'URP_All_Figure_Data.xlsx',engine='openpyxl') as writer:
        for i,path in enumerate(files,1):
            d=pd.read_csv(path,float_precision='round_trip')
            if len(d)>30000:continue
            sheet=f'{i:02d}_'+path.stem[:27]
            if sheet in seen:raise ValueError(sheet)
            seen.add(sheet);d.to_excel(writer,index=False,sheet_name=sheet)
            index.append(dict(Sheet=sheet,Rows=len(d),CSV='tables/'+path.name))
        pd.DataFrame(index).to_excel(writer,index=False,sheet_name='INDEX')
        writer.book._sheets.insert(0,writer.book._sheets.pop())
        pd.DataFrame(analyses).assign(source_tables=lambda x:x.source_tables.map('; '.join)).to_excel(
            writer,index=False,sheet_name='FIGURE_INTERPRETATIONS')
        for ws in writer.book.worksheets:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.showGridLines=False
            ws.row_dimensions[1].height=32
            for c in ws[1]:
                c.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='24556B')
                c.alignment=Alignment(wrap_text=True,vertical='center')
            for column in ws.columns:
                ws.column_dimensions[column[0].column_letter].width=min(48,max(13,max(len(str(c.value or '')) for c in list(column)[:50])+2))
                for c in list(column)[1:]:
                    c.font=Font(name='Calibri',size=10)
                    if isinstance(c.value,float):c.number_format='0.0000'
                    if c.row%2==0:c.fill=PatternFill('solid',fgColor='F0F5F7')
    return index


def add_table(doc,title,frame,columns):
    doc.add_heading(title,2)
    table=doc.add_table(rows=1,cols=len(columns));table.style='Light Shading Accent 1'
    flag=OxmlElement('w:tblHeader');table.rows[0]._tr.get_or_add_trPr().append(flag)
    for cell,(_,label,_) in zip(table.rows[0].cells,columns):cell.text=label
    for _,row in frame.iterrows():
        cells=table.add_row().cells
        for cell,(key,_,digits) in zip(cells,columns):
            v=row[key]
            cell.text='' if pd.isna(v) else (f'{v:.{digits}f}' if digits is not None else str(v))
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after=Pt(3)
                for run in paragraph.runs:run.font.size=Pt(9)
    doc.add_paragraph('显示值经四舍五入；完整精度与原始列名见同名CSV及总数据工作簿。',style='Caption')


def document(tables,analyses):
    doc=Document();s=doc.sections[0]
    s.left_margin=s.right_margin=Cm(1.65);s.top_margin=Cm(1.65);s.bottom_margin=Cm(1.5)
    normal=doc.styles['Normal'];normal.font.name='DejaVu Sans';normal.font.size=Pt(10.5)
    normal._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    normal.paragraph_format.line_spacing=1.13;normal.paragraph_format.space_after=Pt(5)
    for name in ['Title','Subtitle','Heading 1','Heading 2','Caption']:
        st=doc.styles[name];st.font.name='DejaVu Sans'
        st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.styles['Title'].font.size=Pt(21);doc.styles['Heading 1'].font.size=Pt(14)
    doc.styles['Heading 2'].font.size=Pt(11.5);doc.styles['Caption'].font.size=Pt(9)
    doc.styles['Caption'].font.bold=False;doc.styles['Caption'].font.italic=False
    doc.styles['Caption'].font.color.rgb=RGBColor.from_string('53616B')
    doc.styles['Caption'].paragraph_format.line_spacing=1.05
    doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('24556B')
    footer=s.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run('URP · 2019–2022 · ')
    f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');footer._p.append(f)
    doc.add_heading('URP论文骨架与英文图表解析',0)
    doc.add_paragraph('分阶段MCMC → Sobol敏感性 → 灌溉双目标优化 → 水量与条件敏感性核验',style='Subtitle')
    doc.add_paragraph('范围：2019、2020、2021、2022四年DI玉米。参考Liu等（2025）的组织思路，采用本项目实际数据与已核验结果。')
    doc.add_paragraph('本文件是一份可扩写的论文骨架：前半部逐节说明写什么、引用什么图表和怎样解释；后半部收录全部43组英文图、英文图注及中文解析。原32组历史Figures均有英文对应，另保留合并版和新增诊断。')
    doc.add_paragraph('本轮完成英文化、表格汇总与写作重构，未重新采样MCMC，也没有把建议中的新约束或稳健优化写成已完成实验。')
    doc.add_paragraph('版本：2026-10-20。表图数据可编辑；图片同时提供600 dpi PNG、矢量PDF和SVG。')
    table_specs={
      '2.2':('Table 1 · 四年资料概况','Table1_study_data',[
        ('Year','年份',0),('Weather_days','气象日数',0),('CC_pairs','CC对数',0),
        ('Biomass_pairs','B对数',0),('Rain_mm','降雨mm',1),('Observed_Y13_t_ha','观测Y13',2),('DI_irrigation_mm','DI灌水mm',2)]),
      '2.3':('Table 2 · 参数与公共Sobol范围','Table2_parameter_definitions',[
        ('Parameter','参数',None),('Stage','阶段',0),('Unit','单位',None),('Sobol_lower','下限',2),('Sobol_upper','上限',2)]),
      '3.1':('Table 3 · 校准拟合评价','Table3_calibration_performance',[
        ('Year','年份',0),('CC_R2_cal','CC R²cal',3),('CC_RMSE','CC RMSE',3),
        ('Biomass_R2_cal','B R²cal',3),('Biomass_RMSE_t_ha','B RMSE',3),('Yield_bias_pct','Y偏差%',2)]),
      '3.3':('Table 4 · 产量总效应敏感性','Table4_yield_sensitivity',[
        ('Parameter','参数',None),('ST_2019','2019',3),('ST_2020','2020',3),('ST_2021','2021',3),
        ('ST_2022','2022',3),('ST_four_year_mean','四年均值',3)]),
      '3.4':('Table 5 · 主候选权衡','Table5_selected_candidates',[
        ('Year','年份',0),('Candidate_irrigation_mm','候选I mm',2),('Candidate_Y13','候选Y13',3),
        ('Irrigation_reduction_pct','灌水减少%',2),('Yield_change_vs_observed_pct','相对观测Y变化%',2),
        ('ET_reduction_pct','ET减少%',2)])}
    for title,paras in SECTIONS:
        heading=doc.add_heading(title,1)
        if title.startswith(('1 ','2.1','3.1','4 ','5 ')):heading.paragraph_format.page_break_before=True
        for paragraph in paras:doc.add_paragraph(paragraph)
        for prefix,(label,key,columns) in table_specs.items():
            if title.startswith(prefix):add_table(doc,label,tables[key],columns)
    heading=doc.add_heading('正文图号—文件—章节对照',1);heading.paragraph_format.page_break_before=True
    add_table(doc,'建议正文10组图',pd.DataFrame([dict(Number=n,File=f,Section=s) for n,f,s in MAIN]),
              [('Number','图号',None),('File','文件名（不含扩展名）',None),('Section','使用章节',None)])
    doc.add_heading('补图和数据表怎样使用',2)
    doc.add_paragraph('F03/F04/F06用于拟合补充或替代；F08/F11/F12/F14–F17用于参数识别与资料解释；F09及S03用于水量定义；S01/S02用于采样与边界；S04/S05用于敏感性数值区间及水分分量；R05/R06/R07/R09用于实施、重复性、条件敏感性及储水筛查；N01和全范围R03用于低灌水诊断，N02用于明确观测—模拟关系。')
    doc.add_paragraph('补表S1–S10已提供CSV和Excel：真实年度先验及边界质量、采样设置、诊断、水量账、减灌分解、条件核验、算法比较、储水筛查、零灌溉和年度排名。正文无需塞入所有补表。')
    doc.add_heading('仍需核定的定义与资料',2)
    doc.add_paragraph('Y_catmul/Y_tot及cat/coc未有可靠定义，本文件不擅自替换。原F13门槛图已经完整英文化；N02使用37对明确的生物量变量。地点、品种、重复数与误差出处在正式投稿前从原记录补齐。现有图表和压缩包不因这些字段暂缺而扣留。')
    doc.add_heading('参考文献与软件引用起点',2)
    refs=[
      'Liu, Y., Wang, Y., Šimůnek, J., & Liao, R. (2025). An integrated data assimilation, crop modeling, and multi-objective optimization framework for improving cotton irrigation water use efficiency. Agricultural Water Management, 319, 109774. https://doi.org/10.1016/j.agwat.2025.109774',
      'Foreman-Mackey, D., Hogg, D. W., Lang, D., & Goodman, J. (2013). emcee: The MCMC Hammer. PASP, 125, 306–312. https://doi.org/10.1086/670067',
      'Herman, J., & Usher, W. (2017). SALib: An open-source Python library for sensitivity analysis. JOSS, 2(9), 97. https://doi.org/10.21105/joss.00097',
      'Deb, K., & Jain, H. (2014). An evolutionary many-objective optimization algorithm using reference-point-based nondominated sorting approach, Part I: Solving problems with box constraints. IEEE Transactions on Evolutionary Computation, 18(4), 577–601. https://doi.org/10.1109/TEVC.2013.2281535',
      '正式稿另补原试验数据、LAI—CC、生物量数字化、水分目标和年度模型修改来源。软件版本以项目锁定依赖及实际执行记录为准，不能直接复制参考论文版本。']
    for paragraph in refs:doc.add_paragraph(paragraph)
    registry={x['name']:x for x in json.loads((ROOT/'FIGURE_REGISTRY.json').read_text())['figures']}
    preferred=[f for _,f,_ in MAIN]
    ordered=sorted(analyses,key=lambda a:(0,preferred.index(a['name'])) if a['name'] in preferred else (1,a['name']))
    for index,a in enumerate(ordered,1):
        e=registry[a['name']]
        views=[ROOT/'figures'/(a['name']+'.png')]
        if a['name'] in ['F07_parameter_intervals_EN','F17_parameter_centers_EN']:
            views=[ROOT/'word_panels'/f'{a["name"]}_page{page}.png' for page in [1,2]]
        for view_number,path in enumerate(views,1):
            suffix=f' · {view_number}/2' if len(views)>1 else ''
            heading=doc.add_heading(f'图册 {index}{suffix} · '+e['title'],1)
            heading.paragraph_format.page_break_before=True
            p=doc.add_paragraph(a['name']+' | '+a['suggested_placement']);p.paragraph_format.space_after=Pt(4)
            for run in p.runs:run.font.size=Pt(9)
            with Image.open(path) as im:width,height=im.size
            width_cm=min(16.6,14.1*width/height)
            p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            p.add_run().add_picture(str(path),width=Cm(width_cm))
            caption=re.sub(r'^(?:Supplementary )?Figure\s+[^.]+\.\s*','',e['caption'])
            if a['name']=='R03_full_range_diagnostic_2x2_EN':
                caption=('Supplemental full-range diagnostic using three NSGA-III searches per year '
                    '(80 individuals × 60 generations). The yield gate is removed; the irrigation cap and annual '
                    'parameter centers are retained. Solid lines show best-found nondominated envelopes; dashed gray '
                    'lines show fixed-proportion dose responses. Open circles mark zero irrigation and stars the '
                    'original DI model baselines. The dotted 95% observed-yield line is a reference only. '
                    'This is a model diagnostic, not field validation.')
            if view_number==1:
                p=doc.add_paragraph(caption,style='Caption')
            keys=[('回答的问题','purpose'),('实际结果','finding'),('正文怎样写','writing'),('解释边界','limitations')]
            if len(views)>1:keys=keys[:2] if view_number==1 else keys[2:]
            for label,key in keys:
                p=doc.add_paragraph();p.add_run(label+'：').bold=True;p.add_run(a[key])
                p.paragraph_format.space_after=Pt(4)
            if view_number==len(views):
                p=doc.add_paragraph('数据表：'+', '.join(a['source_tables']) if a['source_tables'] else '流程示意；无数值数据表。')
                for run in p.runs:run.font.size=Pt(8.5)
    doc.save(ROOT/'URP_Paper_Skeleton_EN_Figures.docx')
    text='# URP论文骨架\n\n'
    for title,paras in SECTIONS:text+='## '+title+'\n\n'+'\n\n'.join(paras)+'\n\n'
    (ROOT/'URP_Paper_Skeleton.md').write_text(text,encoding='utf-8')
    return len(ordered)


def main():
    analyses=build();tables=publication_tables();mapping=coverage();index=workbook(analyses)
    count=document(tables,analyses)
    status=dict(status='GENERATED_PENDING_LAYOUT_REVIEW',English_figure_groups=count,
        original_figure_groups_covered=len(mapping),original_F01_F17_complete=True,
        figure_interpretations=len(analyses),source_workbook_sheets=len(index),
        manuscript_main_figures=len(MAIN),publication_tables=len(tables),
        reference_DOI='10.1016/j.agwat.2025.109774',new_MCMC_runs=0,
        custom_variable_definitions_pending=['Y_catmul','Y_tot','cat','coc'])
    (ROOT/'verification/PAPER_BUILD_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
    print(json.dumps(status,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
