"""Diagnose the supplied R03/R04 using their canonical actual-run tables.

Run after publish_full_range_reference.py. This step reuses audited model
responses, changes no MCMC/model inputs, and creates no delivery archive.
"""
from pathlib import Path
import hashlib
import json
import shutil

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parent
TABLES = ROOT / 'tables'
PUB = Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/actual_publication_20261019/tables')
YEARS = [2019, 2020, 2021, 2022]
COLORS = {2019: '#0072B2', 2020: '#D55E00', 2021: '#009E73', 2022: '#A85AA0'}
DARK, GRAY, GATE = '#263F4B', '#AAB8C1', '#B37870'
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.titlesize': 11,
    'axes.labelsize': 10, 'xtick.labelsize': 9, 'ytick.labelsize': 9,
    'legend.fontsize': 9, 'axes.spines.top': False, 'axes.spines.right': False,
    'pdf.fonttype': 42, 'svg.fonttype': 'none', 'savefig.facecolor': 'white',
})
NEW_FIGURES = []


def read(name, base=PUB):
    return pd.read_csv(base / name, float_precision='round_trip')


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def save(fig, name, title, caption, tables):
    for ext in ['png', 'pdf', 'svg']:
        fig.savefig(ROOT / 'figures' / f'{name}.{ext}', dpi=600)
    plt.close(fig)
    NEW_FIGURES.append(dict(name=name, title=title, caption=caption, years=YEARS,
                            source_tables=tables, PNG_dpi=600))


def nondominated(d):
    a = d.sort_values(['Irrigation_mm', 'Y13'], ascending=[True, False])
    a = a.drop_duplicates(['Irrigation_mm', 'Y13'])
    return a[a.Y13 > a.Y13.cummax().shift(fill_value=-np.inf)]


def yield_panel(ax, comparison, title):
    for j, row in enumerate(comparison.itertuples(index=False)):
        ax.scatter(j - .17, row.Observed_Y13, c=DARK, marker='_', s=195, lw=2.2, zorder=4)
        ax.scatter(j, row.Model_baseline_Y13, c=GRAY, marker='D', s=46, zorder=4)
        ax.scatter(j + .17, row.Candidate_Y13, c=COLORS[row.Year], s=48,
                   edgecolors='white', linewidths=.45, zorder=5)
        ax.plot([j - .30, j + .30], [row.Yield_gate_Y13] * 2,
                c=GATE, ls=':', lw=1.25, zorder=2)
    ax.set(xticks=np.arange(4), xticklabels=YEARS, xlim=(-.52, 3.52),
           ylim=(13.0, 17.7), xlabel='Year',
           ylabel='Grain yield at 13% moisture (t ha⁻¹)', title=title)
    ax.set_axisbelow(True)
    ax.grid(axis='y', alpha=.17)


def yield_handles():
    return [Line2D([], [], c=DARK, marker='_', ls='', ms=12, mew=2,
                   label='Published observed yield'),
            Line2D([], [], c=GRAY, marker='D', ls='', ms=6, label='DI model baseline'),
            Line2D([], [], c='#3F7897', marker='o', ls='', ms=6,
                   label='Selected optimized candidate'),
            Line2D([], [], c=GATE, ls=':', lw=1.3, label='95% observed-yield constraint')]


def main():
    assert json.loads((ROOT / 'FULL_RANGE_VERIFICATION.json').read_text())['status'] == 'PASS'
    sources = ['NSGA_main_candidates.csv', 'NSGA_all_seed_Pareto_points.csv',
               'Water_ledger_baseline_and_candidate.csv', 'Irrigation_saving_decomposition.csv',
               'Terminal_storage_screening.csv', 'NSGA_algorithm_comparison.csv',
               'NSGA_event_schedules.csv']
    identities = []
    for name in sources:
        dest = TABLES / ('Original_main_' + name)
        shutil.copyfile(PUB / name, dest)
        identities.append(dict(source=str(PUB / name), local=str(dest.relative_to(ROOT)),
                               sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
    c = read('NSGA_main_candidates.csv').set_index('Year')
    fronts = read('NSGA_all_seed_Pareto_points.csv')
    ledger = read('Water_ledger_baseline_and_candidate.csv')
    decomposition = read('Irrigation_saving_decomposition.csv').set_index('Year')
    schedules = read('NSGA_event_schedules.csv')
    alg = read('NSGA_algorithm_comparison.csv')
    zero = read('Zero_irrigation_reference.csv', TABLES).set_index('Year')
    b = ledger[ledger.Scenario == 'baseline'].set_index('Year')
    q = ledger[ledger.Scenario == 'candidate'].set_index('Year')
    assert c.index.tolist() == YEARS and len(fronts) == 3986
    diagnostics, comparisons, tradeoffs, algorithm_rows = [], [], [], []
    for year in YEARS:
        cc, bb, qq, dd = c.loc[year], b.loc[year], q.loc[year], decomposition.loc[year]
        a = fronts[fronts.Year == year]
        gate = .95 * cc.Observed_Y13
        assert (a.Y13 >= gate - 1e-10).all()
        assert (a.Irrigation_mm <= bb.Irrigation_mm + 1e-10).all()
        assert cc.Y13 >= gate and cc.Irrigation_mm <= bb.Irrigation_mm
        assert zero.loc[year].Zero_Y13 < gate
        assert cc.Selection == 'epsilon_min_irrigation'
        # The recommendation comes from the NSGA-III union, not both algorithms.
        np.testing.assert_allclose(cc.Irrigation_mm,
                                   a[a.Algorithm == 'NSGA3'].Irrigation_mm.min(), atol=1e-8, rtol=0)
        np.testing.assert_allclose([cc.Y13, cc.Irrigation_mm, cc.ET_mm],
                                   [qq.Y_13pct, qq.Irrigation_mm, qq.ET_mm], atol=1e-10, rtol=0)
        np.testing.assert_allclose(bb.Y_13pct, cc.Model_baseline_Y13, atol=1e-10, rtol=0)
        np.testing.assert_allclose(bb.Y_13pct, zero.loc[year].DI_baseline_Y13, atol=1e-10, rtol=0)
        np.testing.assert_allclose(bb.Profile_initial_mm, qq.Profile_initial_mm, atol=1e-12, rtol=0)
        np.testing.assert_allclose(bb.Rain_mm, qq.Rain_mm, atol=1e-12, rtol=0)
        for rr in [bb, qq]:
            assert abs(rr.Water_balance_residual_mm) < 1e-7
            assert abs(rr.Max_daily_balance_residual_mm) < 1e-7
        saving = bb.Irrigation_mm - qq.Irrigation_mm
        et = bb.ET_mm - qq.ET_mm
        storage = bb.Profile_final_mm - qq.Profile_final_mm
        surface = ((bb.Surface_final_mm - bb.Surface_initial_mm)
                   - (qq.Surface_final_mm - qq.Surface_initial_mm))
        loss = sum(bb[k] - qq[k] for k in ['Runoff_mm', 'DeepPerc_mm', 'TileDrain_mm'])
        external = -sum(bb[k] - qq[k] for k in ['Rain_mm', 'CR_mm', 'GwIn_mm'])
        closure = saving - (et + storage + surface + loss + external)
        assert abs(closure) < 1e-7
        np.testing.assert_allclose([saving, et, storage, surface, loss, external],
            dd[['Irrigation_saving_mm', 'ET_reduction_mm', 'Reduced_soil_storage_gain_mm',
                'Reduced_surface_storage_gain_mm', 'Loss_reduction_mm',
                'External_inflow_adjustment_mm']].to_numpy(float), atol=1e-8, rtol=0)
        reduction_pct = 100 * saving / bb.Irrigation_mm
        obs_change = 100 * (cc.Y13 / cc.Observed_Y13 - 1)
        model_change = 100 * (cc.Y13 / bb.Y_13pct - 1)
        np.testing.assert_allclose([reduction_pct, obs_change, model_change],
            [cc.Water_saving_pct, cc.Yield_change_vs_observed_pct, cc.Yield_change_vs_model_pct],
            atol=1e-10, rtol=0)
        events = schedules[schedules.Year == year]
        np.testing.assert_allclose(events.Candidate_actual_mm.sum(), cc.Irrigation_mm, atol=1e-8, rtol=0)
        diagnostics.append(dict(Year=year, Feasible_Pareto_rows=len(a),
            Minimum_front_irrigation_mm=a.Irrigation_mm.min(),
            Maximum_front_irrigation_mm=a.Irrigation_mm.max(),
            Minimum_front_Y13=a.Y13.min(), Maximum_front_Y13=a.Y13.max(),
            Feasible_yield_span_t_ha=a.Y13.max() - a.Y13.min(), Yield_gate_Y13=gate,
            Zero_irrigation_Y13=zero.loc[year].Zero_Y13, Zero_satisfies_gate=False,
            Candidate_gate_margin_t_ha=cc.Y13 - gate,
            Model_baseline_Y13=bb.Y_13pct,
            Yield_reduction_allowed_from_model_baseline_pct=100 * (1 - gate / bb.Y_13pct),
            Selection='minimum irrigation in gated NSGA-III union; not geometric knee'))
        comparisons.append(dict(Year=year, Observed_Y13=cc.Observed_Y13,
            Model_baseline_Y13=bb.Y_13pct, Candidate_Y13=cc.Y13,
            Yield_gate_Y13=gate, Candidate_gate_margin_t_ha=cc.Y13 - gate,
            Baseline_irrigation_mm=bb.Irrigation_mm, Candidate_irrigation_mm=cc.Irrigation_mm,
            Irrigation_reduction_pct=reduction_pct, Yield_change_vs_observed_pct=obs_change,
            Yield_change_vs_model_baseline_pct=model_change,
            Observed_role='published observed yield; not a model output',
            Candidate_role='frozen-center simulation; not field-validated yield'))
        tradeoffs.append(dict(Year=year, Irrigation_reduction_mm=saving,
            Irrigation_reduction_pct=reduction_pct, ET_reduction_mm=et,
            ET_reduction_pct=100 * et / bb.ET_mm, Lower_final_soil_storage_mm=storage,
            Storage_difference_share_of_irrigation_reduction_pct=100 * storage / saving,
            Loss_reduction_mm=loss, Surface_storage_difference_mm=surface,
            External_inflow_adjustment_mm=external, Decomposition_residual_mm=closure,
            Initial_soil_storage_mm=bb.Profile_initial_mm,
            Baseline_final_soil_storage_mm=bb.Profile_final_mm,
            Candidate_final_soil_storage_mm=qq.Profile_final_mm,
            Baseline_soil_storage_change_mm=bb.Profile_final_mm - bb.Profile_initial_mm,
            Candidate_soil_storage_change_mm=qq.Profile_final_mm - qq.Profile_initial_mm,
            Baseline_ET_mm=bb.ET_mm, Candidate_ET_mm=qq.ET_mm,
            Maximum_candidate_single_event_mm=events.Candidate_actual_mm.max()))
        aa = alg[alg.Year == year].set_index('Algorithm')
        algorithm_rows.append(dict(Year=year, NSGAII_union_HV=aa.loc['NSGA2'].Normalized_union_HV,
            NSGAIII_union_HV=aa.loc['NSGA3'].Normalized_union_HV,
            HV_relative_difference_III_vs_II_pct=100 * (
                aa.loc['NSGA3'].Normalized_union_HV / aa.loc['NSGA2'].Normalized_union_HV - 1),
            Interpretation='near overlap; no evidence of NSGA-III superiority'))
    diagnostic = pd.DataFrame(diagnostics)
    comparison = pd.DataFrame(comparisons)
    tradeoff = pd.DataFrame(tradeoffs)
    algorithm = pd.DataFrame(algorithm_rows)
    for name, data in [('R03_gated_front_diagnostic.csv', diagnostic),
                       ('R04_yield_comparison.csv', comparison),
                       ('R03_irrigation_ET_storage_tradeoff.csv', tradeoff),
                       ('R03_algorithm_union_comparison.csv', algorithm)]:
        data.to_csv(TABLES / name, index=False)

    yield_caption = (
        'Observed yields are the values reported in the source study; DI baseline and selected-candidate yields '
        'are simulations at frozen annual parameter centers. Candidates minimize irrigation within the NSGA-III '
        'union subject to the DI irrigation cap and Y13 ≥ 0.95 Yobs. Dotted segments mark this deterministic yield '
        'constraint, not confidence intervals. Symbols are offset horizontally within each year for readability. '
        'Candidate colors consistently denote 2019, 2020, 2021 and 2022. Lower irrigation does not imply an equal '
        'reduction in ET; terminal soil storage is reported separately.')
    fig, ax = plt.subplots(figsize=(7.2, 4.65), layout='constrained')
    yield_panel(ax, comparison, 'Observed yield, model baseline and selected candidate')
    fig.legend(handles=yield_handles(), loc='outside upper center', ncol=2, frameon=False)
    save(fig, 'R04_right_yield_comparison_EN', 'Observed yield, model baseline and selected candidate',
         yield_caption, ['R04_yield_comparison.csv'])

    fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.8), layout='constrained')
    for j, row in enumerate(comparison.itertuples(index=False)):
        axes[0].bar(j - .18, row.Baseline_irrigation_mm, .33, color='#D1DADF')
        axes[0].bar(j + .18, row.Candidate_irrigation_mm, .33, color=COLORS[row.Year])
        axes[0].annotate(f'{row.Irrigation_reduction_pct:.1f}%', (j + .18, row.Candidate_irrigation_mm),
                         xytext=(0, 6), textcoords='offset points', ha='center', fontsize=10)
    axes[0].set(xticks=np.arange(4), xticklabels=YEARS, ylim=(0, 710), xlabel='Year',
                ylabel='Applied seasonal irrigation (mm)', title='(a) Reduction in applied irrigation')
    axes[0].set_axisbelow(True)
    axes[0].grid(axis='y', alpha=.17)
    axes[0].legend(handles=[Patch(fc='#D1DADF', label='Original DI schedule'),
                            Patch(fc='#3F7897', label='Selected candidate')], frameon=False)
    yield_panel(axes[1], comparison, '(b) Yield comparison')
    axes[1].legend(handles=yield_handles(), loc='upper right', fontsize=8.5, frameon=False)
    save(fig, 'R04_irrigation_yield_comparison_EN', 'Irrigation reduction and yield comparison',
         'Panel (a): percentages are reductions in applied irrigation relative to the original annual DI schedule, '
         'not consumptive-water savings or a demonstrated sustainable water-saving rate. ' + yield_caption,
         ['R04_yield_comparison.csv', 'R03_irrigation_ET_storage_tradeoff.csv'])

    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.85), layout='constrained')
    for i, (ax, year) in enumerate(zip(axes.flat, YEARS)):
        a = fronts[fronts.Year == year]
        cc, bb = c.loc[year], b.loc[year]
        main = a[a.Algorithm == 'NSGA3']
        ax.scatter(main.Irrigation_mm, main.Y13, s=7, color=COLORS[year], alpha=.20,
                   rasterized=True, linewidths=0)
        for alg_name, color, style in [('NSGA3', COLORS[year], '-'), ('NSGA2', '#69757B', '--')]:
            union = nondominated(a[a.Algorithm == alg_name])
            ax.plot(union.Irrigation_mm, union.Y13, c=color, ls=style, lw=1.5)
        ax.scatter(bb.Irrigation_mm, bb.Y_13pct, marker='*', c=DARK, s=75,
                   edgecolors='white', linewidths=.5, zorder=5)
        ax.scatter(cc.Irrigation_mm, cc.Y13, fc='white', ec=COLORS[year], s=38, lw=1.6, zorder=6)
        ax.axhline(.95 * cc.Observed_Y13, c=GATE, ls=':', lw=1.1)
        ax.set_title(f'({chr(97 + i)}) {year}')
        ax.ticklabel_format(axis='y', style='plain', useOffset=False)
        ax.set_axisbelow(True)
        ax.grid(alpha=.16)
        ax.margins(x=.07, y=.10)
    fig.supxlabel('Actual seasonal irrigation (mm)', fontsize=10)
    fig.supylabel('Grain yield at 13% moisture (t ha⁻¹)', fontsize=10)
    fig.legend(handles=[Line2D([], [], c='#3F7897', lw=1.5, label='NSGA-III'),
        Line2D([], [], c='#69757B', ls='--', label='NSGA-II'),
        Line2D([], [], c=DARK, marker='*', ls='', ms=9, label='DI model baseline'),
        Line2D([], [], c='#3F7897', marker='o', mfc='white', ls='', label='Selected candidate'),
        Line2D([], [], c=GATE, ls=':', label='95% observed-yield constraint')],
        loc='outside upper center', ncol=2, frameon=False)
    save(fig, 'R03_Gated_Pareto_fronts_EN', 'Yield-gated Pareto fronts (zoomed feasible region)',
         'English reconstruction of the supplied R03 from its canonical 3,986 final feasible Pareto records. '
         'Colored points show NSGA-III results; solid and dashed curves are nondominated unions across five seeds '
         'for NSGA-III and NSGA-II, respectively (100 individuals × 100 generations per seed). Each panel uses its '
         'own zoomed axes and includes only yield-gated feasible points, not the full dose response. Zero-irrigation '
         'yields fall below the gate in every year and therefore are absent. Stars are model baselines, not observations. '
         'Open circles are minimum-irrigation selections from the gated NSGA-III union, not geometric knee points. '
         'Use the separate full-range figure to interpret the omitted low-irrigation region.',
         ['Original_main_NSGA_all_seed_Pareto_points.csv', 'R04_yield_comparison.csv'])

    fig, ax = plt.subplots(figsize=(7.2, 4.65), layout='constrained')
    x = np.arange(4)
    bottom = np.zeros(4)
    components = [('ET_reduction_mm', '#519DAD', 'Lower seasonal ET'),
                  ('Lower_final_soil_storage_mm', '#CF9C58', 'Lower end-of-season soil storage'),
                  ('Loss_reduction_mm', '#839C84', 'Lower runoff and drainage')]
    for col, color, label in components:
        values = tradeoff[col].to_numpy()
        ax.bar(x, values, .53, bottom=bottom, color=color, label=label,
               edgecolor='white', linewidth=.5)
        if col == 'Lower_final_soil_storage_mm':
            for j, (v, base) in enumerate(zip(values, bottom)):
                ax.text(j, base + v / 2, f'{v:.1f} mm', ha='center', va='center', fontsize=10, color='#243640')
        bottom += values
    for j, row in enumerate(tradeoff.itertuples(index=False)):
        ax.annotate(f'{row.Irrigation_reduction_mm:.1f} mm', (j, row.Irrigation_reduction_mm),
                     xytext=(0, 6), textcoords='offset points', ha='center', fontsize=10)
    ax.set(xticks=x, xticklabels=YEARS, xlabel='Year', ylim=(0, 420),
           ylabel='Contribution to irrigation reduction (mm)',
           title='Irrigation reduction: ET, storage and water losses')
    ax.set_axisbelow(True)
    ax.grid(axis='y', alpha=.17)
    fig.legend(loc='outside upper center', ncol=1, frameon=False)
    save(fig, 'S07_Irrigation_reduction_decomposition_EN', 'Water-balance decomposition of irrigation reduction',
         'Irrigation reduction equals lower ET plus the difference in final soil storage and lower runoff/drainage, '
         'because rainfall, initial soil water, other inflows and changes in surface storage match within each annual '
         'baseline–candidate pair. The storage term is the baseline final storage minus candidate final storage. '
         'It includes avoided baseline recharge and/or additional depletion and is not wholly attributable to soil-water '
         'mining. In 2021, baseline storage increases by about 170.0 mm whereas candidate storage decreases by about '
         '186.7 mm; their 356.7 mm difference accounts for 97.4% of the irrigation reduction. Bars do not demonstrate '
         'long-term sustainability; terminal storage was not constrained in the original optimization.',
         ['R03_irrigation_ET_storage_tradeoff.csv', 'Original_main_Water_ledger_baseline_and_candidate.csv'])

    registry = json.loads((ROOT / 'FIGURE_REGISTRY.json').read_text())
    names = {f['name'] for f in NEW_FIGURES}
    registry['figures'] = [f for f in registry['figures'] if f['name'] not in names] + NEW_FIGURES
    registry.update(R03_original_diagnosis='COMPLETE_WITH_STORAGE_AND_SCOPE_LIMITATIONS',
                    R04_status='ENGLISH_FINALIZED_AFTER_DIAGNOSIS')
    write_json(ROOT / 'FIGURE_REGISTRY.json', registry)
    (ROOT / 'CAPTIONS_EN.txt').write_text('\n\n'.join(
        f['name'] + '\n' + f['caption'] for f in registry['figures']), encoding='utf-8')
    audit = dict(status='PASS', original_images_received=True, years=YEARS,
        original_Pareto_rows_verified=len(fronts), source_identities=identities,
        candidate_points_and_yield_gates_verified=True,
        annual_zero_yields_below_gate=True, water_balance_decomposition_verified=True,
        maximum_decomposition_residual_mm=float(tradeoff.Decomposition_residual_mm.abs().max()),
        all_new_figure_points_from_canonical_tables=True,
        original_R03_verdict='NUMERICALLY_CONSISTENT_CONDITIONAL_MODEL_RESULT; '
                             'IRRIGATION_REDUCTION_NOT_EQUIVALENT_TO_ET_SAVING',
        NSGAIII_superiority_demonstrated=False, sustainable_water_saving_demonstrated=False,
        independent_field_validation=False, R04_English='COMPLETE',
        new_MCMC_runs=0, new_model_evaluations_in_this_finalization=0,
        supplemental_full_range_evaluations_previously_completed=57600,
        final_delivery='accumulate for one final package; no interim archive or upload')
    write_json(ROOT / 'R03_DIAGNOSIS_STATUS.json', audit)
    status = json.loads((ROOT / 'FULL_RANGE_STATUS.json').read_text())
    status.update(R03_user_supplied_figure_diagnosis='COMPLETE_WITH_STORAGE_AND_SCOPE_LIMITATIONS',
                  R04_English_finalization='COMPLETE', diagnosis_record='R03_DIAGNOSIS_STATUS.json')
    write_json(ROOT / 'FULL_RANGE_STATUS.json', status)
    verification = json.loads((ROOT / 'FULL_RANGE_VERIFICATION.json').read_text())
    verification.update(R03_original_image_verdict=audit['original_R03_verdict'],
                         R04_English_finalization='COMPLETE', diagnosis_record='R03_DIAGNOSIS_STATUS.json')
    write_json(ROOT / 'FULL_RANGE_VERIFICATION.json', verification)
    write_json(ROOT / 'R04_TRANSLATION_QUEUE.json', dict(status='COMPLETE_AFTER_ORIGINAL_R03_DIAGNOSIS',
        source='Original_main_NSGA_main_candidates.csv',
        figures=['R04_right_yield_comparison_EN', 'R04_irrigation_yield_comparison_EN'],
        completed_checks=['original source-table identity', 'zero and low-dose response',
                          'yield-gate truncation', 'terminal-storage decomposition'],
        scope='conditional model outcome; not a field-validated or storage-constrained optimum'))
    print(json.dumps({k: audit[k] for k in ['status', 'original_Pareto_rows_verified',
        'maximum_decomposition_residual_mm', 'R04_English']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
