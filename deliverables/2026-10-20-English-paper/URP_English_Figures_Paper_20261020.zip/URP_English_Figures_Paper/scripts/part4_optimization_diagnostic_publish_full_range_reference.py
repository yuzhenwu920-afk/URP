"""Export a supplemental full-range Pareto reference and all source tables.

No verdict on the user's yet-to-be-supplied R03 image is made here. R04 is
held for that diagnostic step. All new curve points are actual model runs.
"""
from pathlib import Path
import json,sys,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parent
PROJECT=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
YEARS=[2019,2020,2021,2022]
COLORS={2019:'#0072B2',2020:'#D55E00',2021:'#009E73',2022:'#A85AA0'}
VARS=[f'Window{i}_mm' for i in range(1,5)]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,'axes.labelsize':10,
    'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,'axes.spines.top':False,'axes.spines.right':False,
    'pdf.fonttype':42,'svg.fonttype':'none'})
REG=[]


def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False))


def save(fig,name,title,caption,tables):
    for suffix in ['png','pdf','svg']:fig.savefig(ROOT/'figures'/f'{name}.{suffix}',dpi=600,facecolor='white')
    REG.append(dict(name=name,title=title,caption=caption,years=YEARS,source_tables=tables,PNG_dpi=600))
    plt.close(fig)


def nondominated_observed(d):
    # Two-objective maximization of yield and minimization of actual water.
    a=d.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False]).drop_duplicates(['Irrigation_mm','Y_13pct'])
    best_before=a.Y_13pct.cummax().shift(fill_value=-np.inf)
    return a[a.Y_13pct>best_before].reset_index(drop=True)


def verify_seed(folder,cap):
    state=json.loads((folder/'run.json').read_text());assert state['status']=='COMPLETE'
    d=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip')
    assert len(d)==state['evaluations'] and len(d)==80*60
    nums=d.select_dtypes(include='number').to_numpy();assert np.isfinite(nums).all()
    assert d.Water_balance_residual_mm.abs().max()<1e-7 and d.Max_daily_balance_residual_mm.abs().max()<1e-7
    tol=64*np.finfo(float).eps*max(1,cap)
    assert (d[VARS]>=0).all().all() and (d[VARS].sum(axis=1)<=cap+tol).all()
    assert (d.Irrigation_mm<=cap+tol).all() and (d.Irrigation_mm>=0).all()
    x=np.ascontiguousarray(d[VARS].to_numpy(),dtype=np.float64)
    f=np.c_[-d.Y_13pct,d.Irrigation_mm]
    lookup={tuple(row.view(np.uint64)):i for i,row in enumerate(x)}
    checked=0
    files=sorted(folder.glob('generation_*.npz'));assert len(files)==60
    for path in files:
        with np.load(path,allow_pickle=False) as z:
            xx,ff,gg,cv=z['X'],z['F'],z['G'],z['CV']
            assert xx.shape==(80,4) and ff.shape==(80,2) and gg.shape==(80,1)
            assert all(np.isfinite(a).all() for a in [xx,ff,gg,cv])
            for row,values,g in zip(xx,ff,gg):
                i=lookup[tuple(np.ascontiguousarray(row).view(np.uint64))]
                np.testing.assert_allclose(values,f[i],atol=1e-10,rtol=0)
                np.testing.assert_allclose(g[0],(d.Irrigation_mm.iloc[i]-cap)/cap,atol=1e-12,rtol=0)
                checked+=1
    return d,{'folder':folder.relative_to(ROOT).as_posix(),'evaluations':len(d),'population_individuals_verified':checked,
        'max_season_water_residual_mm':float(d.Water_balance_residual_mm.abs().max()),'status':'PASS'}


def main():
    status=json.loads((ROOT/'FULL_RANGE_STATUS.json').read_text());assert status['status']=='COMPLETE'
    (ROOT/'figures').mkdir(exist_ok=True);(ROOT/'tables').mkdir(exist_ok=True)
    cfg=json.loads((PROJECT/'project_config.json').read_text())
    zero=pd.read_csv(ROOT/'Zero_DI_replays.csv',float_precision='round_trip')
    all_front=[];all_dose=[];budget_rows=[];seed_rows=[];audit=[]
    for year in YEARS:
        cap=float(cfg['baseline_irrigation_mm'][str(year)]);all_eval=[]
        for seed in status['seeds']:
            folder=ROOT/'actual_runs'/str(year)/f'NSGA3_full_range_seed{seed}'
            d,check=verify_seed(folder,cap);audit.append(check)
            d=d.assign(Year=year,Seed=seed,Evaluation_row=np.arange(len(d)))
            all_eval.append(d)
            info=json.loads((folder/'run.json').read_text())
            seed_rows.append(dict(Year=year,Seed=seed,Population=80,Generations=60,Evaluations=len(d),Seconds=info['seconds'],Yield_gate_applied=False))
            for frac in np.linspace(0,1,21):
                budget=cap*frac
                eligible=d[d.Irrigation_mm<=budget+64*np.finfo(float).eps*max(1,budget)]
                assert len(eligible)
                b=eligible.sort_values(['Y_13pct','Irrigation_mm'],ascending=[False,True]).iloc[0]
                budget_rows.append(dict(Year=year,Seed=seed,Budget_fraction=frac,Water_budget_mm=budget,Best_Y13=b.Y_13pct,
                    Actual_water_used_mm=b.Irrigation_mm,Source_evaluation_row=int(b.Evaluation_row),
                    Final_soil_storage_mm=b.Profile_final_mm,ET_mm=b.ET_mm,
                    Label='best found among actual model evaluations under budget; no global optimality proof'))
        combined=pd.concat(all_eval,ignore_index=True)
        # Retain every new evaluation in a readable, compressed canonical table.
        combined.to_csv(ROOT/'tables'/f'Full_range_all_evaluations_{year}.csv.gz',index=False,compression='gzip')
        front=nondominated_observed(combined)
        assert front.Irrigation_mm.iloc[0]==0
        expected=zero[(zero.Year==year)&(zero.Scenario=='Zero')].Y13.iloc[0]
        assert np.isclose(front.Y_13pct.iloc[0],expected,atol=1e-10,rtol=0)
        assert (front.Y_13pct.diff().dropna()>0).all()
        all_front.append(front)
        dose=pd.read_csv(ROOT/'actual_runs'/str(year)/'fixed_proportion_dose_response.csv',float_precision='round_trip')
        assert len(dose)==21 and np.isfinite(dose.select_dtypes(include='number')).all().all()
        assert np.isclose(dose.Y_13pct.iloc[0],expected,atol=1e-10)
        baseline=zero[(zero.Year==year)&(zero.Scenario=='DI')].Y13.iloc[0]
        assert np.isclose(dose.Y_13pct.iloc[-1],baseline,atol=1e-10)
        all_dose.append(dose)
    front=pd.concat(all_front,ignore_index=True);dose=pd.concat(all_dose,ignore_index=True)
    front.to_csv(ROOT/'tables/Full_range_best_found_front.csv',index=False)
    dose.to_csv(ROOT/'tables/Fixed_proportion_dose_response.csv',index=False)
    budgets=pd.DataFrame(budget_rows);budgets.to_csv(ROOT/'tables/Yield_budget_best_found_by_seed.csv',index=False)
    pd.DataFrame(seed_rows).to_csv(ROOT/'tables/Full_range_seed_summary.csv',index=False)
    zrows=[]
    for year in YEARS:
        z=zero[(zero.Year==year)&(zero.Scenario=='Zero')].iloc[0]
        b=zero[(zero.Year==year)&(zero.Scenario=='DI')].iloc[0]
        zrows.append(dict(Year=year,Zero_Y13=z.Y13,DI_baseline_Y13=b.Y13,
            Zero_yield_change_pct_vs_DI=100*(z.Y13/b.Y13-1),Rain_mm=z.Rain_mm,
            Initial_total_storage_mm=z.Initial_storage_mm,Zero_final_total_storage_mm=z.Final_storage_mm,
            Zero_storage_depletion_mm=z.Initial_storage_mm-z.Final_storage_mm,Zero_ET_mm=z.ET_mm,
            Role='same-model conditional replay, not a rainfed field observation'))
    pd.DataFrame(zrows).to_csv(ROOT/'tables/Zero_irrigation_reference.csv',index=False)
    fig,axes=plt.subplots(2,2,figsize=(7.2,5.85),layout='constrained',sharex=True,sharey=True)
    for i,(ax,year) in enumerate(zip(axes.flat,YEARS)):
        a=front[front.Year==year];d=dose[dose.Year==year];b=zero[(zero.Year==year)&(zero.Scenario=='DI')].iloc[0]
        ax.plot(a.Irrigation_mm,a.Y_13pct,c=COLORS[year],lw=1.7,zorder=4)
        ax.plot(d.Irrigation_mm,d.Y_13pct,c='#929FA8',ls='--',lw=1.1,zorder=2)
        ax.scatter(0,a.Y_13pct.iloc[0],fc='white',ec=COLORS[year],s=36,lw=1.4,zorder=5)
        ax.scatter(b.Actual_irrigation_mm,b.Y13,c='#263F4B',marker='*',s=75,zorder=5)
        ax.axhline(.95*cfg['observed_Y13'][str(year)],c='#B37870',ls=':',lw=1)
        ax.set(title=f'({chr(97+i)}) {year}',xlim=(-15,660),ylim=(0,19),xticks=[0,200,400,600],yticks=[0,5,10,15])
        ax.grid(alpha=.16);ax.set_axisbelow(True)
    fig.supxlabel('Actual seasonal irrigation (mm)',fontsize=10)
    fig.supylabel('Grain yield at 13% moisture (t ha⁻¹)',fontsize=10)
    fig.legend(handles=[Line2D([],[],c='#536979',lw=1.7,label='Full-range best-found front'),
        Line2D([],[],c='#929FA8',ls='--',label='Fixed-proportion dose response'),
        Line2D([],[],marker='o',mfc='white',mec='#536979',ls='',label='Zero irrigation'),
        Line2D([],[],marker='*',c='#263F4B',ls='',label='DI model baseline'),
        Line2D([],[],c='#B37870',ls=':',label='95% observed-yield gate (reference only)')],
        loc='outside upper center',ncol=2,frameon=False)
    save(fig,'R03_full_range_diagnostic_2x2_EN','Full-range yield–irrigation reference including zero irrigation',
        'Supplemental full-range diagnostic. Solid lines are nondominated best-found actual model evaluations from three NSGA-III searches per year '
        '(80 individuals × 60 generations), using frozen yearly parameter centers and four fixed-date irrigation windows. '
        'The original 95% observed-yield gate is removed for these searches; the dotted line is shown only as a reference. '
        'Gray dashed curves scale the original event amounts proportionally and are not optimized fronts. '
        'Open circles show zero irrigation; stars show original DI model baselines. This conditional model reference is separate from field validation and from the gated main optimization.',
        ['Full_range_best_found_front.csv','Fixed_proportion_dose_response.csv','Zero_irrigation_reference.csv'])
    fig,ax=plt.subplots(figsize=(7.2,4.6),layout='constrained')
    for year in YEARS:
        a=front[front.Year==year];b=zero[(zero.Year==year)&(zero.Scenario=='DI')].iloc[0]
        ax.plot(a.Irrigation_mm,a.Y_13pct,c=COLORS[year],lw=1.7,label=str(year))
        ax.scatter(0,a.Y_13pct.iloc[0],fc='white',ec=COLORS[year],s=36,lw=1.3,zorder=4)
        ax.scatter(b.Actual_irrigation_mm,b.Y13,c=COLORS[year],marker='*',s=85,zorder=4)
    ax.set(xlabel='Actual seasonal irrigation (mm)',ylabel='Grain yield at 13% moisture (t ha⁻¹)',
        xlim=(-15,660),ylim=(0,19),xticks=[0,100,200,300,400,500,600],yticks=[0,5,10,15])
    ax.grid(alpha=.17);ax.set_axisbelow(True)
    handles=ax.get_legend_handles_labels()[0]+[
        Line2D([],[],marker='o',ls='',mfc='white',mec='#536979',label='Zero irrigation'),
        Line2D([],[],marker='*',ls='',c='#536979',label='DI model baseline')]
    fig.legend(handles=handles,loc='outside upper center',ncol=3,frameon=False)
    save(fig,'N01_Optimized_yield_irrigation_EN','Best-found yield–irrigation trade-offs across four years',
        'New figure. Best-found full-range yield–irrigation trade-offs from supplemental actual-model NSGA-III searches. '
        'Each curve is an upper nondominated envelope, not the response of a single fixed irrigation pattern or a proven global optimum. '
        'Zero-irrigation and original DI baselines are shown explicitly. Initial soil water, rainfall, climate and parameter centers remain year specific; '
        'terminal storage and per-event delivery limits are not additional constraints in these searches.',
        ['Full_range_best_found_front.csv','Zero_irrigation_reference.csv'])
    checks={'status':'PASS','new_search_evaluations':sum(x['evaluations'] for x in audit),
        'all_stored_population_individuals_verified':sum(x['population_individuals_verified'] for x in audit),
        'extra_fixed_proportion_evaluations':84,'separate_zero_DI_replays':8,'seeds_and_generations':audit,
        'all_four_zero_anchors_preserved':True,'all_generation_and_response_values_finite':True,
        'legacy_repair_warning':'At a zero allocation the legacy repair computes an overflowing intermediate ratio, then clips its scale to 1; '
            'all repaired controls, generations and model responses were verified finite. Zero responses match independent replays.',
        'R03_original_image_verdict':'DEFERRED_UNTIL_USER_PROVIDES_ORIGINAL','R04_English_finalization':'HELD_PENDING_DIAGNOSIS'}
    write(ROOT/'FULL_RANGE_VERIFICATION.json',checks)
    write(ROOT/'FIGURE_REGISTRY.json',{'years':YEARS,'figures':REG,'R03_original_diagnosis':'PENDING_ORIGINAL','R04_status':'HELD'})
    write(ROOT/'R04_TRANSLATION_QUEUE.json',{'status':'HELD_PENDING_ORIGINAL_R03_DIAGNOSIS',
        'translations':{'Y13（t/ha）':'Grain yield at 13% moisture (t ha⁻¹)','观测':'Published observed yield',
            '模型基准':'DI model baseline','主候选':'Optimized candidate','观测、模型基准与主候选':'Observed yield, model baseline and optimized candidate'},
        'unresolved_validity_conditions':['original figure/data identity','zero and low-dose response','yield-gate truncation','terminal-storage and event constraints']})
    (ROOT/'CAPTIONS_EN.txt').write_text('\n\n'.join(r['caption'] for r in REG))
    print('Full-range figures and complete numerical audit saved',flush=True)


if __name__=='__main__':main()
