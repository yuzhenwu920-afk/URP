"""Prepare bilingual analysis notes and an editable result workbook, no ZIP."""
from pathlib import Path
import json,hashlib,shutil
import numpy as np
import pandas as pd
from openpyxl.styles import Font,PatternFill,Alignment
from docx import Document
from docx.shared import Cm,Pt
from docx.oxml.ns import qn

OUT=Path(__file__).resolve().parent
T=OUT/'tables'


def md_table(frame):
    return '| '+' | '.join(map(str,frame.columns))+' |\n|'+ '|'.join('---' for _ in frame.columns)+'|\n'+''.join(
        '| '+' | '.join('' if pd.isna(v) else str(v) for v in row)+' |\n' for row in frame.itertuples(index=False,name=None))


def main():
    registry=json.loads((OUT/'FIGURE_REGISTRY.json').read_text())
    metrics=pd.read_csv(T/'Calibration_metrics.csv')
    params=pd.read_csv(T/'F07_parameter_intervals_and_boundary_mass.csv')
    water=pd.read_csv(T/'F09_annual_water_budget.csv')
    diag=pd.read_csv(T/'MCMC_existing_diagnostics.csv')
    groups=pd.read_csv(T/'MCMC_existing_sampling_groups.csv')
    rows=[]
    for year in [2019,2020,2021,2022]:
        a=diag[(diag.Year==year)&(diag.Phase==1)]
        rows.append(dict(Year=year,Stage1_max_Rhat=a.Rhat_max.max(),Stage1_min_bulk_ESS=a.ESS_bulk_min.min(),
            Stage1_min_tail_ESS=a.ESS_tail_min.min(),Raw_steps_per_walker=int(a.Raw_steps.iloc[0]),
            Strict_stage1_diagnostics_met=False))
    convergence=pd.DataFrame(rows);convergence.to_csv(T/'MCMC_diagnostic_summary.csv',index=False)
    defs=pd.DataFrame([
        ['CCx','Maximum canopy cover','fraction',1],['CGC_CD','Canopy growth coefficient','d⁻¹',1],
        ['CDC_CD','Canopy decline coefficient','d⁻¹',1],['SenescenceCD','Senescence onset in calendar days after planting','d',1],
        ['Kcb','Basal crop/transpiration coefficient','dimensionless',1],
        ['WP_early','Early-period normalized water productivity','g m⁻²',2],
        ['WP_late','Late-period normalized water productivity','g m⁻²',2],
        ['HI0','Reference harvest index','fraction',2]],columns=['Parameter','Definition','Unit','Stage'])
    defs.to_csv(T/'Parameter_definitions.csv',index=False)
    highlights=params.sort_values(['Lower_1pct_mass_pct','Upper_1pct_mass_pct'],ascending=False)
    notable=params[(params.Lower_1pct_mass_pct>=5)|(params.Upper_1pct_mass_pct>=5)][
        ['Year','Parameter','Prior_low','Prior_high','Lower_1pct_mass_pct','Upper_1pct_mass_pct']].copy()
    notable.to_csv(T/'F07_notable_boundary_concentrations.csv',index=False)
    cc=metrics[metrics.Variable=='CC'];bio=metrics[metrics.Variable=='Biomass']
    prose={
        'calibration':f'The frozen year-specific parameter centers reproduced the main temporal pattern of canopy development (Figure 2). '
            f'Across 48 paired canopy-cover dates, annual calibration R² values ranged from {cc.R2_calibration.min():.3f} to {cc.R2_calibration.max():.3f}, '
            f'with RMSE values of {cc.RMSE.min():.3f}–{cc.RMSE.max():.3f}. '
            f'For the 37 biomass calibration pairs, annual R² values were {bio.R2_calibration.min():.3f}–{bio.R2_calibration.max():.3f} '
            f'and RMSE values were {bio.RMSE.min():.3f}–{bio.RMSE.max():.3f} t ha⁻¹ (Figure 5). '
            'These metrics describe agreement at the calibration dates. The biomass records include digitized observations with assumed error scales, '
            'and their agreement should not be interpreted as independent predictive validation.',
        'boundary':'Parameter distributions were assessed relative to their year-specific prior supports (Figure 7). '
            'Approximately 22.1% and 23.1% of retained CCx draws in 2019 and 2020, respectively, lay within the upper 1% of the prior-support width. '
            'For early-period WP, the corresponding lower-band masses were 11.4% in 2020 and 23.7% in 2021. '
            'All retained draws remained within their declared supports, but these concentrations indicate sensitivity to parameter boundaries. '
            'The absence of out-of-support samples therefore does not establish the absence of boundary effects.',
        'sampling':'The existing sampling audit is reported separately from deterministic calibration performance. '
            'Each retained stage-specific sample set originates from a 2000-step-per-walker checkpoint, with year- and stage-specific burn-in. '
            'Stage 1 strict R-hat/ESS criteria are not met. Stage 2 samples come from one ensemble and are conditional on a fixed stage 1 handoff. '
            'High calibration agreement alone does not establish MCMC convergence or an eight-parameter joint posterior. '
            'This revision does not extend or rerun the chains.',
        'water':'The annual water-budget comparison separates irrigation-plus-precipitation inflow, total outflow and absolute end-of-season storage (Figure 9). '
            'Initial storage differs among years; the closure identity is inflow minus outflow equals final minus initial storage. '
            'Signed storage changes were −19.2, +61.9, +170.0 and −40.6 mm in 2019–2022, respectively. '
            'The maximum absolute seasonal closure residual was below 2 × 10⁻¹² mm. '
            'Numerical closure supports internal water accounting; external validation of the flux partitioning still requires independent data.'}
    text='''# 第二部分：MCMC采样与拟合分析（持续修订，暂不打包）

## 选图与执行状态

- 正文选F02：四年冠层覆盖过程线与校准数据，替代F04重复散点展示。
- 正文选F05：四年地上干生物量观测—模拟配对，F03/F06可移到补充材料或撤去重复内容。
- 保留F07：英文版增加完整先验支持范围；另有S02边界附近样本质量，不能用原图推出“完全没有参数撞墙”。
- F09重绘为以年份为横轴的三条折线；主图采用绝对季末储水，S03另给ΔS用于守恒核对。
- F13仍待Y_catmul、Y_tot的定义与单位确认。当前原F13是4对籽粒产量；另有37对四年生物量数据。未擅自混用、改名或拟合成指定变量。

## 本节论证顺序

先用F02说明冠层过程是否被观测约束，再用F05评价生物量幅值与偏差。F07与S02讨论参数识别和边界依赖，S01/诊断表单独讨论采样充分性；F09提供水量核算一致性。这些证据分别回答不同问题，不把高校准R²、水量闭合和MCMC收敛相互替代。

原年度模型与分阶段MCMC保持冻结。没有启动长链延长；没有把相关保留样本数量当作有效样本量。英文节名建议为“MCMC sampling and calibration assessment”。

## 图文与指标口径

F02横轴按Daily_growth.csv的dap字段，配对日期与过程线逐点对应，避免用0基日期差却写成1基DAP。CC为比例。曲线是冻结中心的确定性过程，未添加不存在的后验预测带。

F05横轴是校准生物量观测、纵轴是模拟生物量，单位t ha⁻¹；保留1:1线。2019–2021观测含数字化记录，Sigma_assumed不是独立实测SD，不将其画成实验重复测量误差条。各年9、10、8、10对，共37对。

两张拟合图采用R²cal=1−Σ(sim−obs)²/Σ(obs−mean(obs))²，与原配对评价一致。Pearson r另外列入数据表。它们用于样本内校准，不能改称独立验证。F13如采用带截距OLS，其Regression R²等于Pearson r的平方；它与1:1预测一致性的R²cal并非同一指标。

F07灰色范围为各年度原先验支持，点为中位数、彩色区间为2.5%–97.5%保留样本分位。阶段1未满足严格诊断、阶段2条件于固定交接点，不能声称得到已收敛的八维联合后验。2022第二阶段范围与前三年不同，保持原件。

F09：入流=灌溉+降水（本组CR与地下水入流为0）；出流=Tr+Es+径流+深层渗漏+暗管排水；季末储水=土壤剖面期末量+地表期末量。CSV同时列初末值与ΔS，并核验I−O=ΔS。不同年度只作相邻年度连线比较，不据4个年度点作趋势显著性检验。

## 需要诚实保留的边界结果

'''+md_table(notable.round(4))+'''
边界1%带宽是描述性诊断口径，不是显著性门槛。32组参数均无超支持样本，不代表边界附近无积累。若要检验边界依赖，后续需要有依据的先验敏感性试验与独立验证；不为消除图中积累而任意扩大边界。

## 英文正文草稿

'''
    for k,p in prose.items():text+=f'### {k}\n\n{p}\n\n'
    text+='## 英文图注\n\n'+ '\n\n'.join(r['caption'] for r in registry['figures'])
    (OUT/'PART2_ANALYSIS_NOTES.md').write_text(text,encoding='utf-8')
    (OUT/'CAPTIONS_EN.txt').write_text('\n\n'.join(r['caption'] for r in registry['figures']),encoding='utf-8')
    (OUT/'MANUSCRIPT_PARAGRAPHS_EN.txt').write_text('\n\n'.join(prose.values()),encoding='utf-8')
    workbook=OUT/'Part2_figures_source_tables.xlsx'
    sheets=[('Calibration_metrics','Calibration_metrics.csv'),('CC_pairs','F02_CC_calibration_pairs.csv'),
        ('Biomass_pairs','F05_Biomass_calibration_pairs.csv'),('Daily_growth','Calibration_daily_growth.csv'),
        ('Parameters_and_bounds','F07_parameter_intervals_and_boundary_mass.csv'),
        ('Notable_boundary_mass','F07_notable_boundary_concentrations.csv'),
        ('Water_budget','F09_annual_water_budget.csv'),('MCMC_sampling_groups','MCMC_existing_sampling_groups.csv'),
        ('MCMC_diagnostics','MCMC_existing_diagnostics.csv'),('Diagnostic_summary','MCMC_diagnostic_summary.csv'),
        ('Parameter_definitions','Parameter_definitions.csv'),('Available_yield_pairs','F13_available_annual_yield_pairs.csv')]
    if (T/'F13_confirmed_regression_pairs.csv').exists():
        sheets.extend([('F13_regression_pairs','F13_confirmed_regression_pairs.csv'),('F13_statistics','F13_regression_statistics.csv')])
    with pd.ExcelWriter(workbook,engine='openpyxl') as writer:
        pd.DataFrame([{'Sheet':name,'Canonical_CSV':file} for name,file in sheets]).to_excel(writer,index=False,sheet_name='Index')
        for name,file in sheets:pd.read_csv(T/file,float_precision='round_trip').to_excel(writer,index=False,sheet_name=name)
        pd.DataFrame(registry['figures']).drop(columns=['years','source_tables','vector_formats']).to_excel(writer,index=False,sheet_name='Figure_captions')
        for ws in writer.book.worksheets:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.showGridLines=False
            ws.row_dimensions[1].height=32
            for c in ws[1]:
                c.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='24556B')
                c.alignment=Alignment(wrap_text=True,vertical='center')
            for col in ws.columns:
                values=[str(c.value or '') for c in list(col)[:60]]
                ws.column_dimensions[col[0].column_letter].width=min(45,max(13,max(map(len,values))+2))
                for c in list(col)[1:]:
                    c.font=Font(name='Calibri',size=10)
                    if isinstance(c.value,float):c.number_format='0.0000'
                    if c.row%2==0:c.fill=PatternFill('solid',fgColor='F0F5F7')
    doc=Document();sec=doc.sections[0]
    sec.left_margin=sec.right_margin=Cm(1.7);sec.top_margin=sec.bottom_margin=Cm(1.6)
    normal=doc.styles['Normal'];normal.font.name='DejaVu Sans';normal.font.size=Pt(10.5)
    normal._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.add_heading('URP第二部分：MCMC采样与拟合分析',0)
    doc.add_paragraph('持续修订工作稿；最终与其他部分统一打包。重点配套图件、原始配对表、边界诊断和Excel。')
    doc.add_heading('本节逻辑与选图',1)
    for p in [
        '正文选F02和F05，保留F07，F09改为年度三条折线。另留边界质量、采样诊断和ΔS守恒图作为补充材料。',
        '过程拟合、参数边界、采样诊断和水量闭合各回答不同问题。F07不能证明完全没有边界积累；原样本存在明显的CCx上界及早期WP下界积累。',
        '原MCMC未延长。现有严格阶段1诊断未满足，阶段2是条件于固定交接点的单ensemble样本；不把高校准R²解释成已收敛联合后验。',
        'F13变量名与单位待确认：当前原图是4对年度产量，另有37对四年生物量配对。确认后按指定X、Y标注回归R²与Pearson r，不擅自替换指标。']:
        doc.add_paragraph(p)
    doc.add_heading('可用于正文的英文段落',1)
    for p in prose.values():doc.add_paragraph(p)
    doc.add_heading('校准指标与水量表',1)
    for name,data in [('Calibration metrics',metrics[['Year','Variable','n','R2_calibration','RMSE']].round(4)),
        ('Annual water budget (mm)',water[['Year','Inflow_mm','Outflow_mm','Total_storage_initial_mm','Total_storage_final_mm','Storage_change_mm']].round(2))]:
        doc.add_paragraph(name);tb=doc.add_table(rows=1,cols=len(data.columns));tb.style='Table Grid'
        for c,v in zip(tb.rows[0].cells,data.columns):c.text=str(v)
        for row in data.itertuples(index=False,name=None):
            for c,v in zip(tb.add_row().cells,row):c.text=str(v)
    for f in registry['figures']:
        doc.add_page_break();doc.add_heading(f['name'],1)
        width=Cm(16.2 if f['name']=='F07_parameter_intervals_EN' else 17.2)
        doc.add_picture(str(OUT/'figures'/(f['name']+'.png')),width=width)
        doc.add_paragraph(f['caption'])
    doc.save(OUT/'Part2_MCMC_fit_revision_working.docx')
    entries=[{'file':p.relative_to(OUT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['MANIFEST.json','REBUILD.log']]
    write=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
    write(OUT/'MANIFEST.json',entries)
    print('Part 2 notes, Word and source workbook staged; no archive created.')


if __name__=='__main__':main()
