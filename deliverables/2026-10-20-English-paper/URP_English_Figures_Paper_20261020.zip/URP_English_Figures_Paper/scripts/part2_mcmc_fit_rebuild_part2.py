"""Part 2 figure revision, using only frozen calibration data.

F13 is deliberately gated on an explicit variable definition. No MCMC runs
are launched. Figures are staged for the user's eventual combined package.
"""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import pearsonr,linregress
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

YEARS=[2019,2020,2021,2022]
NAMES=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
COLORS={2019:'#0072B2',2020:'#D55E00',2021:'#009E73',2022:'#A85AA0'}
LABELS=['CCx (–)','CGC (d⁻¹)','CDC (d⁻¹)','Senescence onset (d)',
        'Kcb (–)','Early WP (g m⁻²)','Late WP (g m⁻²)','HI0 (–)']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,
    'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
    'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,
    'axes.edgecolor':'#8596A1','grid.linewidth':.5,'grid.alpha':.2,
    'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
REG=[]


def write(path,data):Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False))


def save(fig,out,name,title,caption,source):
    for ext in ['png','pdf','svg']:fig.savefig(out/'figures'/f'{name}.{ext}',dpi=600,facecolor='white')
    REG.append(dict(name=name,title=title,caption=caption,years=YEARS,source_tables=source,
                    PNG_dpi=600,vector_formats=['PDF','SVG']))
    plt.close(fig)


def read_pairs(root,year,kind):
    path=root/'frozen_inputs/year_outputs'/str(year)
    f=path/('CC_pairs.csv' if kind=='CC' else 'Biomass_pairs.csv')
    d=pd.read_csv(f,parse_dates=['Date'],float_precision='round_trip')
    if 'Included' in d:d=d[d.Included.astype(str).str.lower().eq('true')].copy()
    mapping={'Observed_CC':'CC_observed','canopy_cover':'CC_simulated',
             'Observed_B_t_ha':'B_observed_t_ha','Biomass_t_ha':'B_simulated_t_ha'}
    d=d.rename(columns={k:v for k,v in mapping.items() if k in d and v not in d})
    d['Year']=year
    g=pd.read_csv(path/'Daily_growth.csv',parse_dates=['Date'],float_precision='round_trip').set_index('Date')
    obs,sim,gcol=('CC_observed','CC_simulated','canopy_cover') if kind=='CC' else ('B_observed_t_ha','B_simulated_t_ha','Biomass_t_ha')
    np.testing.assert_allclose(d[sim].to_numpy(),g.loc[d.Date,gcol].to_numpy(),atol=1e-10,rtol=0)
    d['DAP']=g.loc[d.Date,'dap'].to_numpy()
    x=d[obs].to_numpy();y=d[sim].to_numpy()
    assert np.isfinite(np.c_[x,y]).all()
    m=dict(Year=year,Variable=kind,n=len(x),R2_calibration=float(1-np.sum((y-x)**2)/np.sum((x-x.mean())**2)),
        RMSE=float(np.sqrt(np.mean((y-x)**2))),MAE=float(np.mean(abs(y-x))),
        Mean_bias_sim_minus_observed=float(np.mean(y-x)),Pearson_r=float(pearsonr(x,y).statistic),
        Evaluation_role='in-sample calibration; not independent validation')
    return d,g.reset_index(),m


def calibration(project,out):
    all_cc=[];all_bio=[];all_growth=[];metrics=[]
    cases={}
    for year in YEARS:
        cc,g,mc=read_pairs(project,year,'CC');b,_,mb=read_pairs(project,year,'Biomass')
        cases[year]=(cc,b,g,mc,mb);all_cc.append(cc);all_bio.append(b);all_growth.append(g.assign(Year=year));metrics.extend([mc,mb])
    tables=out/'tables'
    pd.concat(all_cc,ignore_index=True).to_csv(tables/'F02_CC_calibration_pairs.csv',index=False)
    pd.concat(all_bio,ignore_index=True).to_csv(tables/'F05_Biomass_calibration_pairs.csv',index=False)
    pd.concat(all_growth,ignore_index=True).to_csv(tables/'Calibration_daily_growth.csv',index=False)
    pd.DataFrame(metrics).to_csv(tables/'Calibration_metrics.csv',index=False)
    fig,axes=plt.subplots(2,2,figsize=(7.2,5.65),layout='constrained',sharex=True,sharey=True)
    for i,(ax,year) in enumerate(zip(axes.flat,YEARS)):
        cc,b,g,m,mb=cases[year]
        ax.plot(g.dap,g.canopy_cover,c=COLORS[year],lw=1.5)
        ax.scatter(cc.DAP,cc.CC_observed,s=22,facecolor='white',edgecolor=COLORS[year],lw=1,zorder=4)
        ax.set(title=f'({chr(97+i)}) {year}',xlim=(0,155),ylim=(0,1.06),xticks=[0,30,60,90,120,150])
        ax.grid(axis='y');ax.set_axisbelow(True)
        ax.text(.96,.08,f'$R^2_{{cal}}$ = {m["R2_calibration"]:.3f}\nRMSE = {m["RMSE"]:.3f}',
            transform=ax.transAxes,ha='right',va='bottom',fontsize=9,bbox=dict(fc='white',ec='none',alpha=.88))
    fig.supxlabel('Days after planting (d)',fontsize=10)
    fig.supylabel('Canopy cover (fraction)',fontsize=10)
    fig.legend(handles=[Line2D([],[],c='#536979',lw=1.5,label='Daily simulation'),
        Line2D([],[],marker='o',ls='',mfc='white',mec='#536979',label='Calibration data')],
        loc='outside upper center',ncol=2,frameon=False)
    save(fig,out,'F02_CC_trajectories_EN','Simulated canopy development and calibration data, 2019–2022',
        'Figure 2. Simulated daily canopy cover (solid lines) and calibration data (open circles) for (a) 2019, (b) 2020, (c) 2021 and (d) 2022. '
        'Days after planting follow the model DAP field. R²cal = 1 − SSE/SST and RMSE are calculated at paired calibration dates; these are in-sample assessments. '
        'Lines are trajectories at frozen parameter centers, not posterior predictive means or uncertainty intervals.',
        ['F02_CC_calibration_pairs.csv','Calibration_daily_growth.csv','Calibration_metrics.csv'])
    fig,axes=plt.subplots(2,2,figsize=(7.2,6.4),layout='constrained',sharex=True,sharey=True)
    for i,(ax,year) in enumerate(zip(axes.flat,YEARS)):
        _,b,g,_,m=cases[year]
        ax.plot([0,40],[0,40],c='#9AA8B2',ls='--',lw=1)
        ax.scatter(b.B_observed_t_ha,b.B_simulated_t_ha,s=28,c=COLORS[year],ec='white',lw=.6,zorder=4)
        ax.set(title=f'({chr(97+i)}) {year}',xlim=(0,40),ylim=(0,40),xticks=[0,10,20,30,40],yticks=[0,10,20,30,40])
        ax.set_aspect('equal',adjustable='box');ax.grid();ax.set_axisbelow(True)
        ax.text(.045,.95,f'n = {m["n"]}\n$R^2_{{cal}}$ = {m["R2_calibration"]:.3f}\nRMSE = {m["RMSE"]:.3f}',
            transform=ax.transAxes,ha='left',va='top',fontsize=9,bbox=dict(fc='white',ec='none',alpha=.9))
    fig.supxlabel('Observed aboveground dry biomass (t ha⁻¹)',fontsize=10)
    fig.supylabel('Simulated aboveground dry biomass (t ha⁻¹)',fontsize=10)
    fig.legend(handles=[Line2D([],[],c='#9AA8B2',ls='--',label='1:1 line')],loc='outside upper center',frameon=False)
    save(fig,out,'F05_Biomass_pairs_EN','Observed and simulated aboveground dry biomass, 2019–2022',
        'Figure 5. Paired observed and simulated aboveground dry biomass in (a) 2019, (b) 2020, (c) 2021 and (d) 2022. '
        'The dashed line denotes 1:1 agreement. R²cal = 1 − SSE/SST; RMSE is in t ha⁻¹. '
        'The 37 pairs are calibration data, including digitized records with source-specific assumed errors; the plot is not an independent validation.',
        ['F05_Biomass_calibration_pairs.csv','Calibration_metrics.csv'])


def parameters(project,out):
    old=pd.read_csv(project/'figure_source_tables/parameter_intervals_verified.csv',float_precision='round_trip')
    rows=[]
    with np.load(project/'frozen_inputs/verified_phase_specific_draws.npz',allow_pickle=False) as z:
        for year in YEARS:
            for j,k in enumerate(NAMES):
                phase=1 if j<5 else 2;arr=z[f'p{phase}_{year}'][:,j if j<5 else j-5]
                r=old[(old.Year==year)&(old.Parameter==k)].iloc[0]
                lo,hi=float(r.Prior_low),float(r.Prior_high);edge=.01*(hi-lo)
                assert np.all((arr>=lo-1e-12)&(arr<=hi+1e-12))
                q=np.quantile(arr,[.025,.5,.975])
                lower=float(np.mean(arr<=lo+edge));upper=float(np.mean(arr>=hi-edge))
                np.testing.assert_allclose(q,[r.P025,r.Median,r.P975],atol=1e-10,rtol=0)
                np.testing.assert_allclose([lower,upper],[r.Lower_1pct_mass,r.Upper_1pct_mass],atol=1e-12,rtol=0)
                rows.append(dict(Year=year,Phase=phase,Parameter=k,Retained_correlated_draws=len(arr),Prior_low=lo,Prior_high=hi,
                    Mean=float(np.mean(arr)),SD=float(np.std(arr,ddof=1)),P025=float(q[0]),Median=float(q[1]),P975=float(q[2]),
                    Minimum=float(arr.min()),Maximum=float(arr.max()),Lower_1pct_mass_pct=100*lower,Upper_1pct_mass_pct=100*upper,
                    Lower_exact_bound_count=int(np.sum(arr==lo)),Upper_exact_bound_count=int(np.sum(arr==hi)),
                    Outside_support_count=int(np.sum((arr<lo-1e-12)|(arr>hi+1e-12))),
                    Interval_role='empirical retained stage-specific sample quantiles; not a certified joint posterior'))
    d=pd.DataFrame(rows);d.to_csv(out/'tables/F07_parameter_intervals_and_boundary_mass.csv',index=False)
    fig,axes=plt.subplots(4,2,figsize=(7.2,8.55),layout='constrained')
    for ax,k,title in zip(axes.flat,NAMES,LABELS):
        values=d[d.Parameter==k]
        for j,year in enumerate(YEARS):
            r=values[values.Year==year].iloc[0]
            ax.plot([j,j],[r.Prior_low,r.Prior_high],c='#CED6DC',lw=3,zorder=1)
            ax.plot([j-.10,j+.10],[r.Prior_low]*2,c='#AEBCC6',lw=.8)
            ax.plot([j-.10,j+.10],[r.Prior_high]*2,c='#AEBCC6',lw=.8)
            ax.errorbar(j,r.Median,yerr=[[r.Median-r.P025],[r.P975-r.Median]],fmt='o',ms=4,
                color=COLORS[year],capsize=2,lw=1.6,zorder=3)
        low=values.Prior_low.min();high=values.Prior_high.max();margin=.06*(high-low)
        ax.set(title=title,xticks=range(4),xticklabels=YEARS,xlim=(-.4,3.4),ylim=(low-margin,high+margin))
        ax.tick_params(labelsize=8.5);ax.grid(axis='y');ax.set_axisbelow(True)
    fig.legend(handles=[Line2D([],[],c='#BCC9D2',lw=3,label='Prior support'),
        Line2D([],[],c='#536979',marker='o',lw=1.5,label='Median and central 95% retained-sample interval')],
        loc='outside upper center',ncol=1,frameon=False)
    save(fig,out,'F07_parameter_intervals_EN','Stage-specific parameter distributions and prior supports',
        'Figure 7. Marginal distributions of retained stage-specific MCMC samples for eight parameters during 2019–2022. '
        'Colored points and bars show medians and the 2.5th–97.5th sample percentiles; gray ranges indicate year-specific prior supports. '
        'Stage 2 is conditional on the fixed stage 1 handoff. These intervals neither certify convergence nor demonstrate absence of boundary effects. '
        'Boundary-band masses are reported separately.', ['F07_parameter_intervals_and_boundary_mass.csv'])
    fig,axes=plt.subplots(1,2,figsize=(7.2,4.85),layout='constrained',sharey=True)
    vmax=max(5.,max(d.Lower_1pct_mass_pct.max(),d.Upper_1pct_mass_pct.max()))
    for ax,key,title in zip(axes,['Lower_1pct_mass_pct','Upper_1pct_mass_pct'],['Lower-bound band','Upper-bound band']):
        a=d.pivot(index='Parameter',columns='Year',values=key).reindex(index=NAMES,columns=YEARS)
        im=ax.imshow(a,aspect='auto',cmap='YlOrRd',vmin=0,vmax=vmax)
        for i in range(8):
            for j in range(4):ax.text(j,i,f'{a.iloc[i,j]:.1f}',ha='center',va='center',fontsize=9,color='white' if a.iloc[i,j]>.58*vmax else '#243746')
        ax.set(title=title,xticks=range(4),xticklabels=YEARS,yticks=range(8),yticklabels=['CCx','CGC','CDC','Senescence','Kcb','Early WP','Late WP','HI0'])
    fig.colorbar(im,ax=list(axes),shrink=.8,label='Retained sample mass (%)')
    save(fig,out,'S02_parameter_boundary_mass_EN','Sample mass close to prior boundaries',
        'Supplementary Figure S2. Percentage of retained draws within the lower or upper 1% of each year-specific prior-support width. '
        'The band width is a descriptive diagnostic choice, not a significance threshold. '
        'No out-of-support draws is distinct from no concentration near a boundary; substantial near-boundary mass is retained and reported.',
        ['F07_parameter_intervals_and_boundary_mass.csv'])
    diag=pd.read_csv(project/'figure_source_tables/mcmc_diagnostics_recomputed.csv',float_precision='round_trip')
    groups=pd.read_csv(project/'figure_source_tables/sampling_group_summary.csv',float_precision='round_trip')
    diag.to_csv(out/'tables/MCMC_existing_diagnostics.csv',index=False)
    groups.to_csv(out/'tables/MCMC_existing_sampling_groups.csv',index=False)
    fig,axes=plt.subplots(1,2,figsize=(7.2,3.7),layout='constrained')
    p1=diag[diag.Phase==1]
    for ax,key,title in zip(axes,['Rhat_max','ESS_bulk_min'],['Rank-normalized R-hat','Bulk effective sample size']):
        a=p1.pivot(index='Parameter',columns='Year',values=key).reindex(index=NAMES[:5],columns=YEARS)
        im=ax.imshow(a,aspect='auto',cmap='Blues',vmin=1 if key=='Rhat_max' else 0,vmax=1.3 if key=='Rhat_max' else max(400.,a.max().max()))
        for i in range(5):
            for j in range(4):ax.text(j,i,f'{a.iloc[i,j]:.3f}' if key=='Rhat_max' else f'{a.iloc[i,j]:.0f}',ha='center',va='center',fontsize=9)
        ax.set(title=title,xticks=range(4),xticklabels=YEARS,yticks=range(5),yticklabels=['CCx','CGC','CDC','Senescence','Kcb'])
    save(fig,out,'S01_MCMC_stage1_diagnostics_EN','Existing stage 1 sampling diagnostics',
        'Supplementary Figure S1. Existing rank-normalized R-hat and bulk ESS summaries for stage 1, recomputed in the previous source audit. '
        'The original strict diagnostic criteria are not met. Retained draw counts are not effective sample sizes. '
        'No long-chain extension is performed as part of this figure revision; stage 2 single-ensemble limitations are listed in the sampling table.',
        ['MCMC_existing_diagnostics.csv','MCMC_existing_sampling_groups.csv'])
    return d


def water(project,out):
    source=pd.read_csv(project/'figure_source_tables/water_balance_recomputed.csv',float_precision='round_trip')
    d=source[source.Scenario=='DI'].set_index('Year').loc[YEARS].reset_index()
    rows=[]
    for _,r in d.iterrows():
        assert abs(r.CR_mm)+abs(r.GwIn_mm)<1e-10
        inflow=r.Irrigation_mm+r.Rain_mm+r.CR_mm+r.GwIn_mm
        outflow=r.Tr_mm+r.Es_mm+r.DeepPerc_mm+r.Runoff_mm+r.TileDrain_mm
        initial=r.Profile_initial_mm+r.Surface_initial_mm
        final=r.Profile_final_mm+r.Surface_final_mm
        delta=final-initial;residual=inflow-outflow-delta
        assert abs(residual)<1e-7
        rows.append(dict(Year=int(r.Year),Irrigation_mm=r.Irrigation_mm,Precipitation_mm=r.Rain_mm,
            Capillary_rise_mm=r.CR_mm,Groundwater_inflow_mm=r.GwIn_mm,Inflow_mm=inflow,
            Transpiration_mm=r.Tr_mm,Soil_evaporation_mm=r.Es_mm,Evapotranspiration_mm=r.ET_mm,
            Runoff_mm=r.Runoff_mm,Deep_percolation_mm=r.DeepPerc_mm,Tile_drainage_mm=r.TileDrain_mm,Outflow_mm=outflow,
            Soil_profile_initial_mm=r.Profile_initial_mm,Soil_profile_final_mm=r.Profile_final_mm,
            Surface_initial_mm=r.Surface_initial_mm,Surface_final_mm=r.Surface_final_mm,
            Total_storage_initial_mm=initial,Total_storage_final_mm=final,Storage_change_mm=delta,Closure_residual_mm=residual))
    z=pd.DataFrame(rows);z.to_csv(out/'tables/F09_annual_water_budget.csv',index=False)
    for storage,key,name in [('End-of-season storage','Total_storage_final_mm','F09_annual_water_budget_EN'),
        ('Storage change (ΔS)','Storage_change_mm','S03_annual_water_storage_change_EN')]:
        fig,ax=plt.subplots(figsize=(7.2,4.2),layout='constrained')
        for column,label,color,marker,style in [('Inflow_mm','Inflow','#0072B2','o','-'),
            ('Outflow_mm','Outflow','#D55E00','s','--'),(key,storage,'#8A63A4','^','-.')]:
            ax.plot(z.Year,z[column],label=label,color=color,marker=marker,ls=style,lw=1.7,ms=5)
        ax.set(xticks=YEARS,xlim=(2018.8,2022.2),xlabel='Year',ylabel='Water depth (mm)',ylim=(0,900) if key=='Total_storage_final_mm' else (-100,900))
        if key=='Storage_change_mm':ax.axhline(0,c='#9DAAB3',lw=.8)
        ax.grid(axis='y');ax.set_axisbelow(True)
        fig.legend(handles=ax.get_legend_handles_labels()[0],labels=ax.get_legend_handles_labels()[1],
            loc='outside upper center',ncol=3,frameon=False)
        caption=('Figure 9. Annual water-budget components for the calibrated DI baseline during 2019–2022. '
            'Inflow is irrigation plus precipitation; capillary and groundwater inputs are zero in these runs. '
            'Outflow comprises evapotranspiration, runoff, deep percolation and tile drainage. '
            'Storage denotes the absolute end-of-season soil-profile plus surface water storage. '
            'Water-balance closure is assessed as inflow − outflow = final storage − initial storage, not as inflow − outflow = final storage. '
            'Lines connect annual summaries for comparison and do not represent a statistical trend test.')
        if key=='Storage_change_mm':caption=('Supplementary Figure S3. Annual inflow, outflow and signed storage change (ΔS = final − initial storage). '
            'The three components satisfy inflow − outflow = ΔS within numerical precision. Positive ΔS indicates net storage gain. '
            'This is the change-in-storage companion to the absolute-storage version of Figure 9.')
        save(fig,out,name,'Annual water-budget components, 2019–2022',caption,['F09_annual_water_budget.csv'])


def f13(project,out,mode):
    # A direct mapping must be chosen by the user before fitting or relabeling.
    yields=pd.read_csv(project/'figure_source_tables/observed_yield_gate_headroom.csv',float_precision='round_trip')
    available=yields[['Year','Original_model_baseline_Y13_t_ha','Observed_Y13_t_ha']].rename(columns={
        'Original_model_baseline_Y13_t_ha':'Simulated_Y13_t_ha','Observed_Y13_t_ha':'Observed_Y13_t_ha'})
    available.to_csv(out/'tables/F13_available_annual_yield_pairs.csv',index=False)
    if mode is None:
        write(out/'F13_PENDING_DEFINITION.json',{'status':'AWAITING_USER_VARIABLE_DEFINITIONS','requested_x':'Y_catmul',
            'requested_y':'Y_tot','original_F13':'annual yield gate, four observed/simulated Y13 pairs',
            'available_alternative':'37 biomass calibration pairs across four years','no_variable_mapping_assumed':True})
        return
    if mode=='yield':
        d=available.rename(columns={'Simulated_Y13_t_ha':'X','Observed_Y13_t_ha':'Y'})
        xl='Simulated grain yield at 13% moisture (t ha⁻¹)';yl='Observed grain yield at 13% moisture (t ha⁻¹)'
    else:
        d=pd.read_csv(out/'tables/F05_Biomass_calibration_pairs.csv').rename(columns={'B_simulated_t_ha':'X','B_observed_t_ha':'Y'})
        xl='Simulated aboveground dry biomass (t ha⁻¹)';yl='Observed aboveground dry biomass (t ha⁻¹)'
    fit=linregress(d.X,d.Y);r=float(pearsonr(d.X,d.Y).statistic)
    yhat=fit.intercept+fit.slope*d.X
    r2=float(1-np.sum((d.Y-yhat)**2)/np.sum((d.Y-d.Y.mean())**2))
    assert np.isclose(r2,r*r)
    d['OLS_fitted_Y']=yhat;d.to_csv(out/'tables/F13_confirmed_regression_pairs.csv',index=False)
    stats=dict(mode=mode,n=len(d),Slope=float(fit.slope),Intercept=float(fit.intercept),Regression_R2=r2,Pearson_r=r,
        R2_1to1_agreement=float(1-np.sum((d.Y-d.X)**2)/np.sum((d.Y-d.Y.mean())**2)),
        fitting_method='pooled ordinary least squares with intercept; descriptive calibration association, not independent validation')
    write(out/'tables/F13_regression_statistics.json',stats)
    pd.DataFrame([stats]).to_csv(out/'tables/F13_regression_statistics.csv',index=False)
    fig,ax=plt.subplots(figsize=(6.3,5.5),layout='constrained')
    low=float(min(d.X.min(),d.Y.min()));high=float(max(d.X.max(),d.Y.max()));pad=.08*(high-low)
    lim=[max(0,low-pad),high+pad]
    ax.plot(lim,lim,c='#A7B4BD',ls='--',lw=1,label='1:1 line')
    xs=np.linspace(lim[0],lim[1],200);ax.plot(xs,fit.intercept+fit.slope*xs,c='#334F61',lw=1.5,label='Pooled OLS fit')
    for year in YEARS:
        s=d[d.Year==year];ax.scatter(s.X,s.Y,c=COLORS[year],s=32,ec='white',lw=.6,label=str(year),zorder=3)
    ax.set(xlim=lim,ylim=lim,xlabel=xl,ylabel=yl);ax.set_aspect('equal',adjustable='box');ax.grid();ax.set_axisbelow(True)
    ax.text(.045,.96,f'n = {len(d)}\nRegression $R^2$ = {r2:.3f}\nPearson r = {r:.3f}\ny = {fit.slope:.3f}x {fit.intercept:+.3f}',
        transform=ax.transAxes,va='top',fontsize=10,bbox=dict(fc='white',ec='none',alpha=.9))
    fig.legend(handles=ax.get_legend_handles_labels()[0],labels=ax.get_legend_handles_labels()[1],
        loc='outside upper center',ncol=3,frameon=False)
    save(fig,out,'F13_confirmed_regression_EN','Four-year observed–simulated calibration association',
        'Figure 13. Four-year observed–simulated calibration association using the confirmed variable mapping. '
        'The solid line is a pooled ordinary least-squares regression with an intercept; the dashed line denotes 1:1 agreement. '
        'Regression R² and Pearson r summarize association, whereas deviation from 1:1 agreement reflects bias. '
        'Pooled biomass dates are nested within years; no independent-replicate inference or external validation is claimed.',
        ['F13_confirmed_regression_pairs.csv','F13_regression_statistics.csv'])
    (out/'F13_PENDING_DEFINITION.json').unlink(missing_ok=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,default=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED'))
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--f13-mode',choices=['yield','biomass']);a=p.parse_args();out=a.out;out.mkdir(parents=True,exist_ok=True)
    (out/'figures').mkdir(exist_ok=True);(out/'tables').mkdir(exist_ok=True)
    status=json.loads((a.project/'output_real_20261019/EXPERIMENT_STATUS.json').read_text())
    for path,sha in status['frozen_input_hashes'].items():assert hashlib.sha256((a.project/path).read_bytes()).hexdigest()==sha
    calibration(a.project,out);parameters(a.project,out);water(a.project,out);f13(a.project,out,a.f13_mode)
    write(out/'FIGURE_REGISTRY.json',{'years':YEARS,'F02_selected_over_F04':True,'F05_selected_over_F03_F06':True,
        'F07_retained':True,'no_claim_of_absence_of_boundary_effects':True,'MCMC_rerun':False,'figures':REG})
    print('Built',len(REG),'four-year figure groups; F13 mode:',a.f13_mode,flush=True)


if __name__=='__main__':main()
