"""Supplemental NSGA-III reference including zero and low irrigation.

Same original annual engines and frozen centers. The 95% yield gate is
removed solely for this full-range diagnostic. It is not the published
gated main optimization, nor a new field validation.
"""
from pathlib import Path
import argparse,json,sys,hashlib,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd

PROJECT=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
sys.path.insert(0,str(PROJECT))
from model_adapter import RealModel,load_study,management,check_management_response,OUTPUTS,LEDGER,write,csv
from phaseC_nsga3 import WaterBudgetRepair,nondominated
from pymoo.core.problem import Problem
from pymoo.core.sampling import Sampling
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.optimize import minimize
from pymoo.util.ref_dirs import get_reference_directions

SEEDS=[31,73,109]
POP=80
GENERATIONS=60
EXTRA=['Y_dry','Growing_days','Harvest_date','Early_termination','Planned_irrigation_mm','Cancelled_irrigation_mm']


class SamplingAcrossFullRange(Sampling):
    def _do(self,problem,n_samples,random_state=None,**kwargs):
        rng=random_state if random_state is not None else np.random.default_rng(0)
        X=rng.dirichlet(np.ones(4),n_samples)*rng.uniform(0,1,n_samples)[:,None]*problem.cap
        anchors=[np.zeros(4),np.asarray(problem.spec['baseline_amounts'])]
        anchors.extend(np.asarray(problem.spec['baseline_amounts'])*a for a in np.linspace(.05,.95,10))
        anchors.extend(np.eye(4)*problem.cap*.5)
        parent=problem.parent
        ids=np.unique(np.linspace(0,len(parent)-1,min(20,len(parent)),dtype=int))
        anchors.extend(parent[ids])
        for j,x in enumerate(anchors[:n_samples]):X[j]=x
        return X


class FullRangeProblem(Problem):
    def __init__(self,model,study,year,folder):
        self.model=model;self.study=study;self.year=year;self.spec=model.management_space(year)
        self.params=study['_centers'][year]
        self.cap=float(study['baseline_irrigation_mm'][str(year)]);self.base_i=self.cap
        f=PROJECT/'actual_publication_20261019/tables/NSGA_all_seed_Pareto_points.csv'
        parent=pd.read_csv(f);parent=parent[(parent.Year==year)&(parent.Algorithm=='NSGA3')].sort_values('Irrigation_mm')
        self.parent=parent[self.spec['names']].to_numpy()
        self.file=folder/'evaluations.csv.gz'
        super().__init__(n_var=4,n_obj=2,n_ieq_constr=1,xl=np.zeros(4),xu=np.full(4,self.cap))

    def evaluate_response(self,x):
        r=self.model.simulate(self.params,self.year,management(self.spec,x))
        return check_management_response(r,self.spec,x)

    def _evaluate(self,X,out,*args,**kwargs):
        F=[];G=[];rows=[]
        for x in X:
            r=self.evaluate_response(x)
            F.append([-r['Y_13pct'],r['Irrigation_mm']]);G.append([(r['Irrigation_mm']-self.cap)/self.cap])
            rows.append(dict(**dict(zip(self.spec['names'],map(float,x))),**{k:r[k] for k in OUTPUTS+LEDGER+EXTRA}))
        out['F']=np.asarray(F);out['G']=np.asarray(G)
        pd.DataFrame(rows).to_csv(self.file,mode='a',header=not self.file.exists(),index=False,compression='gzip')


def run_year(year,out):
    out=Path(out);folder=out/'actual_runs'/str(year);folder.mkdir(parents=True,exist_ok=True)
    study=load_study();model=RealModel(study);fronts=[]
    for seed in SEEDS:
        run=folder/f'NSGA3_full_range_seed{seed}';run.mkdir(exist_ok=True)
        state=run/'run.json'
        if state.exists():
            data=json.loads(state.read_text())
            if data['status']!='COMPLETE':raise RuntimeError('Incomplete run must be preserved; choose a new output folder')
            fronts.append(pd.read_csv(run/'pareto_front.csv'));continue
        problem=FullRangeProblem(model,study,year,run)
        identity={'engine':model.identity,'Year':year,'Algorithm':'NSGA3_full_range','Seed':seed,
            'population':POP,'generations':GENERATIONS,'objectives':['-Y13','actual_irrigation_mm'],
            'constraints':['actual irrigation <= annual baseline cap'],'minimum_yield_gate':None,
            'fixed_params':problem.params,'management_space':problem.spec,
            'initialization':'zero, baseline, proportional doses, window corners, existing high-yield NSGA-III points and random allocations',
            'scope':'supplemental full-range diagnostic, separate from gated 100x100x5 main experiment'}
        write(state,{'status':'RUNNING','identity':identity})
        refs=get_reference_directions('das-dennis',2,n_partitions=POP-1)
        algo=NSGA3(pop_size=POP,ref_dirs=refs,sampling=SamplingAcrossFullRange(),repair=WaterBudgetRepair(),eliminate_duplicates=True)
        history=[];start=time.perf_counter()
        def callback(a):
            x,f,g=a.pop.get('X'),a.pop.get('F'),a.pop.get('G');cv=a.pop.get('CV').ravel()
            np.savez_compressed(run/f'generation_{a.n_gen:04d}.npz',X=x,F=f,G=g,CV=cv)
            history.append(dict(Year=year,Seed=seed,Generation=a.n_gen,Evaluations=a.evaluator.n_eval,
                Min_actual_irrigation_mm=float(np.min(f[:,1])),Max_Y13=float(np.max(-f[:,0])),Seconds=time.perf_counter()-start))
            csv(run/'history.csv',history)
            if a.n_gen%20==0:print(f'{year} seed={seed} generation={a.n_gen}/{GENERATIONS}',flush=True)
        try:
            result=minimize(problem,algo,('n_gen',GENERATIONS),seed=seed,callback=callback,verbose=False)
            values=[]
            for x,f in zip(np.atleast_2d(result.X),np.atleast_2d(result.F)):
                if f[1]<=problem.cap+1e-8:
                    values.append(dict(Year=year,Algorithm='NSGA3_full_range',Seed=seed,Y13=-float(f[0]),Irrigation_mm=float(f[1]),
                        **dict(zip(problem.spec['names'],map(float,x)))))
            front=nondominated(pd.DataFrame(values));csv(run/'pareto_front.csv',front)
            write(state,{'status':'COMPLETE','identity':identity,'evaluations':result.algorithm.evaluator.n_eval,
                'seconds':time.perf_counter()-start,'front_size':len(front)})
            fronts.append(front)
        except Exception as e:
            write(state,{'status':'FAILED','identity':identity,'error':repr(e)});raise
    combined=pd.concat(fronts,ignore_index=True);csv(folder/'all_seed_fronts.csv',combined)
    csv(folder/'nondominated_union.csv',nondominated(combined))
    # Independent fixed-proportion response path; these are not Pareto optima.
    problem=FullRangeProblem(model,study,year,folder)
    dose=[]
    for fraction in np.linspace(0,1,21):
        x=np.asarray(problem.spec['baseline_amounts'])*fraction;r=problem.evaluate_response(x)
        dose.append(dict(Year=year,Baseline_fraction=float(fraction),**dict(zip(problem.spec['names'],map(float,x))),
            **{k:r[k] for k in OUTPUTS+LEDGER+EXTRA}))
    csv(folder/'fixed_proportion_dose_response.csv',dose)
    return dict(year=year,status='COMPLETE')


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True);path=a.out/'FULL_RANGE_STATUS.json'
    study=load_study()
    status={'status':'RUNNING','years':[2019,2020,2021,2022],'population':POP,'generations':GENERATIONS,'seeds':SEEDS,
        'planned_new_search_evaluations':POP*GENERATIONS*len(SEEDS)*4,'minimum_yield_gate_applied':False,
        'frozen_hashes':study['_frozen_hashes'],'new_zero_and_baseline_replays':'Zero_DI_replays.csv',
        'R03_user_supplied_figure_diagnosis':'PENDING_ORIGINAL','R04_English_finalization':'HELD_PENDING_DIAGNOSIS',
        'jobs':[],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    write(path,status)
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(run_year,y,a.out):y for y in status['years']}
        for future in as_completed(futures):
            try:status['jobs'].append(future.result())
            except Exception as e:
                status['jobs'].append(dict(year=futures[future],status='FAILED',error=repr(e)));write(path,status);raise
            write(path,status)
    for rel,digest in status['frozen_hashes'].items():assert hashlib.sha256((PROJECT/rel).read_bytes()).hexdigest()==digest
    status['status']='COMPLETE';write(path,status)
    print('Full-range diagnostic searches completed for all four years',flush=True)


if __name__=='__main__':main()
