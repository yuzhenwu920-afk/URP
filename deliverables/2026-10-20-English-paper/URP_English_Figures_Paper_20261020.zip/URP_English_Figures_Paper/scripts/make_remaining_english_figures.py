"""Rebuild remaining historical Figures from packaged data; no model reruns."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import linregress, pearsonr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parents[1]
T, F = ROOT / 'tables', ROOT / 'figures'
YEARS = [2019, 2020, 2021, 2022]
COLORS = {2019: '#0072B2', 2020: '#D55E00', 2021: '#009E73', 2022: '#A85AA0'}
NAMES = ['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
LABELS = ['CCx (fraction)','CGC (d⁻¹)','CDC (d⁻¹)','Senescence onset (d)',
          'Kcb (dimensionless)','Early WP (g m⁻²)','Late WP (g m⁻²)','HI0 (fraction)']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,
 'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,
 'axes.edgecolor':'#8797A1','pdf.fonttype':42,'svg.fonttype':'none',
 'savefig.facecolor':'white','grid.alpha':.17})
NEW=[]

def read(name):return pd.read_csv(T / name, float_precision='round_trip')
def save(fig,name,title,caption,sources):
    for ext in ['png','pdf','svg']:fig.savefig(F / (name+'.'+ext),dpi=600)
    plt.close(fig)
    NEW.append(dict(name=name,title=title,caption=caption,years=YEARS,
                    source_tables=sources,PNG_dpi=600,origin='complete_English_refresh'))
def grid(height=5.45,**kwargs):
    fig,axes=plt.subplots(2,2,figsize=(7.2,height),layout='constrained',**kwargs)
    for i,(ax,year) in enumerate(zip(axes.flat,YEARS)):
        ax.set_title(f'({chr(97+i)}) {year}');ax.grid(alpha=.17);ax.set_axisbelow(True)
    return fig,axes

def remaining_calibration():
    growth=read('Calibration_daily_growth.csv');bio=read('F05_Biomass_calibration_pairs.csv')
    cc=read('F02_CC_calibration_pairs.csv');metrics=read('Calibration_metrics.csv')
    fig,axes=grid(5.5,sharex=True,sharey=True)
    for ax,y in zip(axes.flat,YEARS):
        g=growth[growth.Year==y];d=bio[bio.Year==y]
        ax.plot(g.dap,g.Biomass_t_ha,c=COLORS[y],lw=1.5)
        ax.scatter(d.DAP,d.B_observed_t_ha,fc='white',ec=COLORS[y],s=23,zorder=4)
        ax.set(xlim=(0,155),ylim=(0,40),xticks=[0,30,60,90,120,150])
        m=metrics[(metrics.Year==y)&(metrics.Variable=='Biomass')].iloc[0]
        ax.text(.05,.94,f'$R^2_{{cal}}$ = {m.R2_calibration:.3f}\nRMSE = {m.RMSE:.3f}',
                transform=ax.transAxes,va='top',fontsize=9)
    fig.supxlabel('Days after planting (d)',fontsize=10)
    fig.supylabel('Aboveground dry biomass (t ha⁻¹)',fontsize=10)
    fig.legend(handles=[Line2D([],[],c='#536979',label='Daily simulation'),
        Line2D([],[],marker='o',mfc='white',mec='#536979',ls='',label='Calibration data')],
        loc='outside upper center',ncol=2,frameon=False)
    save(fig,'F03_Biomass_trajectories_EN','Biomass development and calibration data',
         'Daily aboveground dry biomass at frozen annual parameter centers and the 37 paired calibration observations. '
         'These trajectories are deterministic simulations, not posterior predictive means. Errors are in-sample calibration metrics.',
         ['Calibration_daily_growth.csv','F05_Biomass_calibration_pairs.csv','Calibration_metrics.csv'])
    fig,axes=grid(6.1,sharex=True,sharey=True)
    for ax,y in zip(axes.flat,YEARS):
        d=cc[cc.Year==y];m=metrics[(metrics.Year==y)&(metrics.Variable=='CC')].iloc[0]
        ax.plot([0,1.04],[0,1.04],c='#A1AFB8',ls='--',lw=1)
        ax.scatter(d.CC_observed,d.CC_simulated,c=COLORS[y],ec='white',s=28,zorder=4)
        ax.set(xlim=(0,1.04),ylim=(0,1.04));ax.set_aspect('equal',adjustable='box')
        ax.text(.045,.95,f'n = {m.n}\n$R^2_{{cal}}$ = {m.R2_calibration:.3f}\nRMSE = {m.RMSE:.3f}',
                transform=ax.transAxes,va='top',fontsize=9,bbox=dict(fc='white',ec='none',alpha=.9))
    fig.supxlabel('Observed canopy cover (fraction)',fontsize=10)
    fig.supylabel('Simulated canopy cover (fraction)',fontsize=10)
    save(fig,'F04_CC_pairs_EN','Paired observed and simulated canopy cover',
         'Observed and simulated canopy cover at the same 48 calibration dates. Dashed lines indicate 1:1 agreement. '
         'R²cal = 1 − SSE/SST is computed against observations without refitting a regression. This is an alternative display to F02, not independent validation.',
         ['F02_CC_calibration_pairs.csv','Calibration_metrics.csv'])
    gates=read('observed_yield_gate_headroom.csv').set_index('Year')
    rows=[]
    for y in YEARS:
        a=metrics[(metrics.Year==y)&(metrics.Variable=='CC')].iloc[0]
        b=metrics[(metrics.Year==y)&(metrics.Variable=='Biomass')].iloc[0]
        rows.append(dict(Year=y,CC_RMSE=a.RMSE,Biomass_RMSE_t_ha=b.RMSE,
                         Yield_bias_pct=gates.loc[y].Baseline_bias_pct_vs_observed))
    d=pd.DataFrame(rows);d.to_csv(T/'F06_calibration_summary_EN.csv',index=False)
    fig,axes=plt.subplots(1,3,figsize=(9.5,3.35),layout='constrained')
    for ax,key,title,label in zip(axes,['CC_RMSE','Biomass_RMSE_t_ha','Yield_bias_pct'],
        ['(a) Canopy cover','(b) Dry biomass','(c) Grain yield'],
        ['RMSE (fraction)','RMSE (t ha⁻¹)','Bias relative to observation (%)']):
        ax.scatter(range(4),d[key],c=[COLORS[y] for y in YEARS],s=40,zorder=4)
        ax.set(xticks=range(4),xticklabels=YEARS,xlabel='Year',ylabel=label,title=title)
        ax.grid(axis='y');ax.set_axisbelow(True)
        if key=='Yield_bias_pct':ax.axhspan(-5,5,color='#EDF2F5',zorder=0);ax.axhline(0,c='#8797A1',lw=.8);ax.set_ylim(-6,6)
    save(fig,'F06_calibration_summary_EN','Calibration errors across four years',
         'Canopy-cover and biomass RMSE are calculated from paired calibration dates. Grain-yield bias compares the annual model baseline with published observations. '
         'The ±5% shaded band is a descriptive project tolerance, not a confidence interval or independent validation.',
         ['F06_calibration_summary_EN.csv','Calibration_metrics.csv','observed_yield_gate_headroom.csv'])

def phase2_and_centers():
    with np.load(ROOT/'model_records/verified_phase_specific_draws.npz',allow_pickle=False) as z:
        draws={y:z[f'p2_{y}'] for y in YEARS}
    fig,axes=grid();corr=[];shown=[];trace=[]
    groups=read('sampling_group_summary.csv').query('Phase == 2').set_index('Year')
    for ax,y in zip(axes.flat,YEARS):
        a=draws[y];ids=np.linspace(0,len(a)-1,min(1800,len(a)),dtype=int)
        r=float(np.corrcoef(a[:,2],a[:,1])[0,1]);corr.append(dict(Year=y,N=len(a),Pearson_r=r))
        shown.append(pd.DataFrame(dict(Year=y,Retained_row=ids,HI0=a[ids,2],WP_late=a[ids,1])))
        ax.scatter(a[ids,2],a[ids,1],s=5,c=COLORS[y],alpha=.16,rasterized=True,linewidths=0)
        ax.set(xlabel='HI0 (fraction)',ylabel='Late WP (g m⁻²)')
        ax.text(.96,.94,f'Pearson r = {r:.3f}',transform=ax.transAxes,ha='right',va='top',fontsize=9)
        h=a.reshape(-1,32,3);assert len(h)==int(groups.loc[y].Retained_steps_per_walker)
        steps=np.arange(len(h))+int(groups.loc[y].Integer_group_burn)
        d={'Year':y,'Raw_step_index':steps}
        for j,key in enumerate(NAMES[5:]):
            q=np.quantile(h[:,:,j],[.1,.5,.9],axis=1)
            for name,v in zip(['Q10','Median','Q90'],q):d[key+'_'+name]=v
        trace.append(pd.DataFrame(d))
    pd.DataFrame(corr).to_csv(T/'F08_phase2_correlation.csv',index=False)
    pd.concat(shown,ignore_index=True).to_csv(T/'F08_displayed_same_row_samples.csv',index=False)
    traces=pd.concat(trace,ignore_index=True);traces.to_csv(T/'F14_F16_phase2_trace_summaries.csv',index=False)
    save(fig,'F08_phase2_compensation_EN','Conditional parameter compensation in stage 2',
         'Late WP and HI0 are taken from the same retained stage-2 sample rows. Correlations use every retained row; '
         'points are evenly thinned for display. Association indicates conditional parameter compensation and is not a causal relationship or proof of convergence.',
         ['F08_phase2_correlation.csv','F08_displayed_same_row_samples.csv'])
    for j,key in enumerate(NAMES[5:]):
        fig,axes=grid(5.25,sharex=True)
        for ax,y in zip(axes.flat,YEARS):
            d=traces[traces.Year==y]
            ax.fill_between(d.Raw_step_index,d[key+'_Q10'],d[key+'_Q90'],color=COLORS[y],alpha=.17,lw=0)
            ax.plot(d.Raw_step_index,d[key+'_Median'],c=COLORS[y],lw=.65)
            ax.set(xlim=(0,2000),xlabel='Original sampling step',ylabel=LABELS[j+5])
        save(fig,f'F{14+j:02d}_phase2_trace_{key}_EN',f'Retained stage-2 sampling trajectory: {key}',
             'Only the retained segment of the original stage-2 ensemble is shown. The line is the median across 32 walkers at each step; '
             'shading is the 10th–90th walker-percentile range, not a posterior confidence band or an independent-chain convergence certificate.',
             ['F14_F16_phase2_trace_summaries.csv','sampling_group_summary.csv'])
    centers=read('central_vectors_with_provenance.csv').set_index('Year').loc[YEARS]
    fig,axes=plt.subplots(4,2,figsize=(7.2,8.0),layout='constrained')
    for ax,key,label in zip(axes.flat,NAMES,LABELS):
        ax.plot(range(4),centers[key],c='#A9B5BD',lw=1,ls='--')
        ax.scatter(range(4),centers[key],c=[COLORS[y] for y in YEARS],s=25,zorder=4)
        ax.set(xticks=range(4),xticklabels=YEARS,title=label);ax.grid(axis='y');ax.set_axisbelow(True)
    save(fig,'F17_parameter_centers_EN','Frozen annual parameter centers',
         'Arithmetic means of retained stage-specific parameter samples used as deterministic annual centers. Stage 2 is conditional on the stage-1 handoff; '
         'these eight values do not define a certified joint posterior mean. Connecting lines aid annual comparison without establishing temporal trends.',
         ['central_vectors_with_provenance.csv'])
    # Readable two-panel-page views for the Word atlas; full figure files above remain intact.
    intervals=read('F07_parameter_intervals_and_boundary_mass.csv')
    for parent,mode in [('F07_parameter_intervals_EN','intervals'),('F17_parameter_centers_EN','centers')]:
        for page,offset in enumerate([0,4],1):
            fig,axes=plt.subplots(2,2,figsize=(7.2,4.8),layout='constrained')
            for ax,key,label in zip(axes.flat,NAMES[offset:offset+4],LABELS[offset:offset+4]):
                if mode=='centers':
                    ax.plot(range(4),centers[key],c='#A9B5BD',lw=1,ls='--')
                    ax.scatter(range(4),centers[key],c=[COLORS[y] for y in YEARS],s=25,zorder=4)
                else:
                    for j,y in enumerate(YEARS):
                        r=intervals[(intervals.Year==y)&(intervals.Parameter==key)].iloc[0]
                        ax.plot([j,j],[r.Prior_low,r.Prior_high],c='#CED6DC',lw=3,zorder=1)
                        ax.errorbar(j,r.Median,yerr=[[r.Median-r.P025],[r.P975-r.Median]],
                                    fmt='o',ms=4,color=COLORS[y],capsize=2,lw=1.5,zorder=3)
                ax.set(xticks=range(4),xticklabels=YEARS,title=label);ax.grid(axis='y');ax.set_axisbelow(True)
            for ext in ['png','pdf','svg']:fig.savefig(ROOT/'word_panels'/f'{parent}_page{page}.{ext}',dpi=600)
            plt.close(fig)

def evidence_and_sampling():
    growth=read('Calibration_daily_growth.csv');field=pd.read_csv(ROOT/'model_records/DI_2019_2022_FIELD_LAI_CC_LOCKED.csv',parse_dates=['Date'])
    fig,axes=grid(5.45,sharex=True,sharey=True);rows=[]
    for ax,y in zip(axes.flat,YEARS):
        g=growth[growth.Year==y];start=pd.to_datetime(g.Date.min());end=pd.to_datetime(g.Date.max())
        a=field[field.Year==y];rs=pd.read_csv(ROOT/'model_records'/f'Maize-{y}-RS_NDVI.csv',parse_dates=['date'])
        rs=rs[rs.date.between(start,end)]
        x=(a.Date-start).dt.days;xx=(rs.date-start).dt.days
        ax.plot(x,a.Field_CC,'o-',c=COLORS[y],ms=3.4,lw=1.25)
        ax.plot(xx,rs.CCquad/100,'s--',c='#9EAAB3',ms=3,lw=1.1)
        ax.set(xlim=(0,155),ylim=(0,1.06),xticks=[0,30,60,90,120,150])
        for dap,val in zip(x,a.Field_CC):rows.append(dict(Year=y,Days_from_model_start=dap,CC_fraction=val,Role='DI field LAI-derived calibration data'))
        for dap,val in zip(xx,rs.CCquad/100):rows.append(dict(Year=y,Days_from_model_start=dap,CC_fraction=val,Role='auxiliary remote sensing; not independent DI validation'))
    pd.DataFrame(rows).to_csv(T/'F11_evidence_series_EN.csv',index=False)
    fig.supxlabel('Days from model start (d)',fontsize=10);fig.supylabel('Canopy cover (fraction)',fontsize=10)
    fig.legend(handles=[Line2D([],[],c='#536979',marker='o',label='DI field LAI-derived CC'),
        Line2D([],[],c='#9EAAB3',ls='--',marker='s',label='Auxiliary remote-sensing series')],loc='outside upper center',ncol=1,frameon=False)
    save(fig,'F11_CC_evidence_roles_EN','Canopy-cover data sources and evidence roles',
         'The field LAI-derived DI canopy-cover series enters calibration. Remote-sensing CCquad is converted from percent to fraction and shown only as auxiliary evidence. '
         'The 2019–2021 remote-sensing records refer to BI and the 2022 treatment metadata are incomplete; none is relabeled as independent DI validation.',
         ['F11_evidence_series_EN.csv'])
    d=read('sampling_group_summary.csv');fig,axes=plt.subplots(1,2,figsize=(7.2,3.7),layout='constrained')
    for phase,color,marker in [(1,'#527C96','o'),(2,'#9B879D','s')]:
        a=d[d.Phase==phase].sort_values('Year')
        for ax,key in zip(axes,['Retained_steps_per_walker','Steps_over_group_tau']):
            ax.plot(range(4),a[key],color=color,marker=marker,lw=1.5,ms=4,label=f'Stage {phase}')
    axes[0].set(ylabel='Retained steps per walker',title='(a) Retained sampling length')
    axes[1].axhline(50,c='#8998A3',ls='--',lw=1)
    axes[1].set(ylabel='Raw steps / maximum IAT',title='(b) Length relative to IAT')
    for ax in axes:ax.set(xticks=range(4),xticklabels=YEARS,xlabel='Year');ax.grid(axis='y');ax.set_axisbelow(True)
    fig.legend(handles=axes[0].get_legend_handles_labels()[0],loc='outside upper center',ncol=2,frameon=False)
    save(fig,'F12_sampling_record_EN','Existing stage-specific sampling records',
         'Each original ensemble used 32 walkers and 2,000 raw steps. Stage 1 has four ensembles per year and stage 2 has one. '
         'The dashed 50-IAT line is only a length reference, not proof of convergence; correlated retained-row counts must not be reported as effective sample sizes.',
         ['sampling_group_summary.csv','MCMC_existing_diagnostics.csv'])

def water_and_gate():
    w=read('F09_annual_water_budget.csv').set_index('Year');fig,axes=grid()
    labels=['Irrigation','Precipitation','Storage depletion','ET','Runoff and drainage','Storage gain']
    colors=['#5A8CA8','#A2C6D5','#D7BA8A','#6F9D86','#A9B2B9','#ABA4C6']
    for ax,y in zip(axes.flat,YEARS):
        r=w.loc[y];ds=r.Storage_change_mm
        parts=[[r.Irrigation_mm,r.Precipitation_mm,max(-ds,0)],
               [r.Evapotranspiration_mm,r.Runoff_mm+r.Deep_percolation_mm+r.Tile_drainage_mm,max(ds,0)]]
        np.testing.assert_allclose(sum(parts[0]),sum(parts[1]),atol=1e-7,rtol=0)
        for xpos,values,offset in [(0,parts[0],0),(1,parts[1],3)]:
            bottom=0
            for k,value in enumerate(values):ax.bar(xpos,value,.5,bottom=bottom,color=colors[k+offset]);bottom+=value
        ax.set(xticks=[0,1],xticklabels=['Inputs + depletion','Outputs + gain'],ylim=(0,920),ylabel='Seasonal water depth (mm)')
        ax.text(.5,.91,f'ΔS = {ds:+.1f} mm',transform=ax.transAxes,ha='center',fontsize=9)
    fig.legend(handles=[Patch(fc=c,label=l) for c,l in zip(colors,labels)],loc='outside upper center',ncol=3,frameon=False,fontsize=8.5)
    save(fig,'F09_water_ledger_EN','Balanced seasonal water ledgers',
         'English version of the original two-column water ledger, retained as a supplementary alternative to the annual three-line F09. '
         'Inflow plus depletion equals outflow plus storage gain. Net storage change is final minus initial storage, not the absolute final storage.',
         ['F09_annual_water_budget.csv'])
    d=read('observed_yield_gate_headroom.csv').sort_values('Year');fig,axes=plt.subplots(1,2,figsize=(7.2,4.0),layout='constrained',width_ratios=[1.25,1])
    for i,r in enumerate(d.itertuples(index=False)):
        color=COLORS[r.Year];gate=r.Absolute_95pct_gate_t_ha;base=r.Original_model_baseline_Y13_t_ha
        axes[0].plot([gate,base],[i,i],c=color,lw=6,alpha=.23,solid_capstyle='round')
        axes[0].scatter(gate,i,marker='|',s=140,c=color,lw=1.8)
        axes[0].scatter(base,i,c=color,s=32)
        axes[0].scatter(r.Observed_Y13_t_ha,i,marker='D',fc='white',ec=color,s=29)
        v=r.Remaining_loss_allowed_pct_of_model_baseline
        axes[1].bar(i,v,.55,color=color);axes[1].text(i,v+.13,f'{v:.2f}%',ha='center',fontsize=9)
    axes[0].set(yticks=range(4),yticklabels=YEARS,xlabel='Grain yield at 13% moisture (t ha⁻¹)',title='(a) Baseline and observed-yield gate')
    axes[0].invert_yaxis();axes[0].grid(axis='x')
    axes[1].set(xticks=range(4),xticklabels=YEARS,xlabel='Year',ylim=(0,7),ylabel='Allowed yield decrease from model baseline (%)',title='(b) Yield headroom');axes[1].grid(axis='y');axes[1].set_axisbelow(True)
    fig.legend(handles=[Line2D([],[],marker='o',ls='',c='#536979',label='DI model baseline'),
        Line2D([],[],marker='D',mfc='white',ls='',c='#536979',label='Published observation'),
        Line2D([],[],marker='|',ls='',c='#B37870',label='95% observed-yield gate')],loc='outside upper center',ncol=2,frameon=False)
    save(fig,'F13_yield_gate_EN','Yield-gate definition and model-baseline headroom',
         'English reconstruction of the original F13 yield-gate figure. The gate is 95% of published observed grain yield. '
         'Headroom is the allowable yield decrease relative to the model baseline, not an irrigation-saving rate. '
         'This does not assign meanings to the unresolved labels Y_catmul and Y_tot.',
         ['observed_yield_gate_headroom.csv'])

def sobol_individuals():
    raw=read('Sobol_all_seed_indices.csv')
    titles={'Y_13pct':'Grain yield at 13% moisture','B_t_ha':'Aboveground dry biomass',
        'Tr_mm':'Seasonal transpiration','Es_mm':'Seasonal soil evaporation',
        'ET_mm':'Seasonal evapotranspiration','MaxCC':'Maximum canopy cover'}
    for output,title in titles.items():
        a=raw[raw.Output==output].groupby(['Parameter','Year']).ST.mean().unstack('Year').reindex(index=NAMES,columns=YEARS)
        fig,ax=plt.subplots(figsize=(5.5,4.7),layout='constrained')
        im=ax.imshow(a,cmap='YlGnBu',vmin=0,vmax=1,aspect='auto')
        for i in range(8):
            for j in range(4):ax.text(j,i,f'{a.iloc[i,j]:.3f}',ha='center',va='center',fontsize=9,color='white' if a.iloc[i,j]>.55 else '#213B4B')
        ax.set(xticks=range(4),xticklabels=YEARS,yticks=range(8),yticklabels=['CCx','CGC','CDC','Senescence','Kcb','Early WP','Late WP','HI0'],xlabel='Year',title=title)
        fig.colorbar(im,ax=ax,shrink=.85,label='Total-effect Sobol index (ST)')
        save(fig,'R01_Sobol_ST_'+output+'_EN',title+': annual total-effect indices',
             f'Annual mean total-effect sensitivity for {title.lower()}, averaged over three independent N=512 scrambles. '
             'All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. '
             'Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.',
             ['Sobol_all_seed_indices.csv'])

def optimization_remaining():
    schedule=read('NSGA_event_schedules.csv');fig,axes=grid(5.5)
    for ax,y in zip(axes.flat,YEARS):
        d=schedule[schedule.Year==y];x=np.arange(len(d))
        ax.bar(x-.18,d.Baseline_mm,.34,color='#CFD8DE')
        ax.bar(x+.18,d.Candidate_actual_mm,.34,color=COLORS[y])
        ax.set(xticks=x,xticklabels=d.Date.str[5:],ylabel='Irrigation per event (mm)',ylim=(0,200))
        ax.tick_params(axis='x',rotation=45)
    fig.legend(handles=[Patch(fc='#CFD8DE',label='Original DI schedule'),Patch(fc='#3F7897',label='Selected candidate')],loc='outside upper center',ncol=2,frameon=False)
    save(fig,'R05_Actual_irrigation_schedules_EN','Actual irrigation amounts at fixed event dates',
         'Actual event amounts are compared at original annual irrigation dates. Decisions redistribute totals across four ordered windows while preserving baseline proportions within each window. '
         'No irrigation dates are optimized. Planned amounts canceled after crop termination are retained separately in the source table.',
         ['NSGA_event_schedules.csv'])
    h=read('NSGA_convergence_history.csv');fig,axes=grid(5.4,sharex=True)
    for ax,y in zip(axes.flat,YEARS):
        for alg,col,style in [('NSGA3',COLORS[y],'-'),('NSGA2','#69757B','--')]:
            a=h[(h.Year==y)&(h.Algorithm==alg)].pivot(index='Generation',columns='Seed',values='Hypervolume')
            assert a.shape==(100,5)
            ax.fill_between(a.index,a.min(axis=1),a.max(axis=1),color=col,alpha=.12,lw=0)
            ax.plot(a.index,a.median(axis=1),c=col,ls=style,lw=1.5)
        ax.set(xlabel='Generation',ylabel='Normalized hypervolume',xlim=(1,100))
    fig.legend(handles=[Line2D([],[],c='#3F7897',label='NSGA-III median and seed range'),
        Line2D([],[],c='#69757B',ls='--',label='NSGA-II median and seed range')],loc='outside upper center',ncol=1,frameon=False)
    save(fig,'R06_Seeded_convergence_EN','Equal-budget seeded optimization histories',
         'Each algorithm used 100 individuals × 100 generations × five seeds per year. Curves show seed medians and shading shows minimum–maximum seed ranges, not confidence intervals. '
         'Hypervolume uses annual observed yield and DI irrigation for normalization and reference point [0, 1.01]. Compare algorithms within a year; convergence histories do not prove a global optimum.',
         ['NSGA_convergence_history.csv','NSGA_algorithm_comparison.csv'])
    c=read('NSGA_conditional_validation.csv');c=c[c.Candidate_ID.str.endswith('_C1')]
    chosen=read('NSGA_main_candidates.csv').set_index('Year');fig,axes=plt.subplots(1,2,figsize=(7.2,4.65),layout='constrained')
    for j,y in enumerate(YEARS):
        for group,offset,marker in [('phase1_conditional',-.12,'o'),('phase2_conditional',.12,'s')]:
            r=c[(c.Year==y)&(c.Group==group)].iloc[0];pos=j+offset;p=r.Probability_above_absolute_gate
            axes[0].errorbar(p,pos,xerr=[[max(0,p-r.Wilson_low)],[max(0,r.Wilson_high-p)]],fmt=marker,c=COLORS[y],capsize=2,ms=4.5)
            axes[1].scatter(r.Q05_Y13,pos,marker=marker,c=COLORS[y],s=30)
        gate=.95*chosen.loc[y].Observed_Y13;axes[1].plot([gate,gate],[j-.3,j+.3],c='#B37870',ls=':',lw=1.3)
    for ax in axes:ax.set(yticks=range(4),yticklabels=YEARS,ylim=(3.5,-.5));ax.grid(axis='x');ax.set_axisbelow(True)
    axes[0].set(xlabel='Conditional fraction above yield gate',xlim=(-.03,1.03),title='(a) Conditional gate exceedance')
    axes[1].set(xlabel='5th-percentile grain yield (t ha⁻¹)',title='(b) Conditional lower-tail yield')
    fig.legend(handles=[Line2D([],[],marker='o',ls='',c='#536979',label='Vary stage 1; fix stage 2'),
        Line2D([],[],marker='s',ls='',c='#536979',label='Vary stage 2; fix stage 1'),
        Line2D([],[],c='#B37870',ls=':',label='95% observed-yield gate')],loc='outside upper center',ncol=1,frameon=False)
    save(fig,'R07_Conditional_candidate_checks_EN','Conditional parameter checks of selected candidates',
         'Each group uses 128 whole-row draws from one retained stage-specific sample pool while fixing the other group at its center. '
         'Left intervals describe Monte Carlo sampling uncertainty conditional on that empirical pool, not field failure probability or original MCMC uncertainty. '
         'These are not joint eight-parameter posterior draws; 128 perturbations are not 128 effective posterior samples. Right dotted marks are deterministic yield gates.',
         ['NSGA_conditional_validation.csv','NSGA_main_candidates.csv'])
    d=read('Terminal_storage_screening.csv');fig,ax=plt.subplots(figsize=(7.2,4.5),layout='constrained')
    for j,y in enumerate(YEARS):
        main=chosen.loc[y];s=d[(d.Year==y)&(d.Screen=='same_baseline_end_storage')].iloc[0]
        baseline=read('Water_ledger_baseline_and_candidate.csv').query('Year == @y and Scenario == "baseline"').iloc[0]
        ax.bar(j-.25,baseline.Irrigation_mm,.23,color='#CDD7DD')
        ax.bar(j,main.Irrigation_mm,.23,color=COLORS[y],alpha=.40)
        if pd.notna(s.Irrigation_mm):ax.bar(j+.25,s.Irrigation_mm,.23,color=COLORS[y])
    ax.set(xticks=range(4),xticklabels=YEARS,xlabel='Year',ylabel='Actual seasonal irrigation (mm)',ylim=(0,730))
    ax.grid(axis='y');ax.set_axisbelow(True)
    fig.legend(handles=[Patch(fc='#CDD7DD',label='DI baseline'),Patch(fc='#3F7897',alpha=.4,label='Original selected candidate'),
        Patch(fc='#3F7897',label='Existing point meeting baseline final-storage floor')],loc='outside upper center',ncol=1,frameon=False)
    save(fig,'R09_Terminal_storage_screening_EN','Post hoc screening under a terminal-storage floor',
         'Dark bars are minimum-irrigation points among already evaluated feasible solutions satisfying final storage at least equal to the original DI baseline; selected points were replayed. '
         'This is post hoc filtering, not a new storage-constrained optimization or proof of infeasibility/optimality. The baseline final storage is a sensitivity scenario, not an established agronomic sustainability target.',
         ['Terminal_storage_screening.csv','NSGA_main_candidates.csv','Water_ledger_baseline_and_candidate.csv'])

def regression():
    d=read('F05_Biomass_calibration_pairs.csv');x=d.B_simulated_t_ha.to_numpy();y=d.B_observed_t_ha.to_numpy()
    fit=linregress(x,y);r=float(pearsonr(x,y).statistic);pred=fit.intercept+fit.slope*x
    r2=1-np.sum((y-pred)**2)/np.sum((y-y.mean())**2)
    summary=pd.DataFrame([dict(N=len(x),OLS_slope=fit.slope,OLS_intercept=fit.intercept,OLS_R2=r2,Pearson_r=r,
        X='simulated aboveground dry biomass',Y='observed aboveground dry biomass',Units='t ha-1',
        Note='37 pooled calibration pairs; repeated dates nested within four years; not independent validation')])
    summary.to_csv(T/'N02_Biomass_regression_summary.csv',index=False)
    fig,ax=plt.subplots(figsize=(6.1,4.8),layout='constrained')
    for year in YEARS:
        a=d[d.Year==year];ax.scatter(a.B_simulated_t_ha,a.B_observed_t_ha,c=COLORS[year],s=31,ec='white',lw=.6,label=str(year),zorder=4)
    xx=np.linspace(0,40,200);ax.plot(xx,xx,ls='--',c='#A1AFB8',lw=1,label='1:1 line')
    ax.plot(xx,fit.intercept+fit.slope*xx,c='#263F4B',lw=1.5,label='Pooled OLS fit')
    ax.set(xlabel='Simulated aboveground dry biomass (t ha⁻¹)',ylabel='Observed aboveground dry biomass (t ha⁻¹)',xlim=(0,40),ylim=(0,40))
    ax.set_aspect('equal',adjustable='box');ax.grid();ax.set_axisbelow(True)
    ax.text(.045,.95,f'n = {len(x)}\nOLS $R^2$ = {r2:.3f}\nPearson r = {r:.3f}\ny = {fit.slope:.3f}x {fit.intercept:+.3f}',
            transform=ax.transAxes,va='top',fontsize=9,bbox=dict(fc='white',ec='none',alpha=.9))
    fig.legend(handles=ax.get_legend_handles_labels()[0],loc='outside upper center',ncol=3,frameon=False)
    save(fig,'N02_Biomass_regression_EN','Pooled four-year biomass regression',
         'Additional regression using all 37 biomass calibration pairs from 2019–2022. X is simulated and Y is observed aboveground dry biomass, explicitly named rather than mapped to unresolved Y_catmul/Y_tot labels. '
         'OLS R² is calculated after fitting an intercept and differs from the 1:1 calibration R² used in F05. Pearson r describes association. '
         'Pooling repeated observations across years can inflate apparent agreement; no independent-observation p-value or validation claim is made.',
         ['F05_Biomass_calibration_pairs.csv','N02_Biomass_regression_summary.csv'])

def main():
    remaining_calibration();phase2_and_centers();evidence_and_sampling();water_and_gate()
    sobol_individuals();optimization_remaining();regression()
    path=ROOT/'FIGURE_REGISTRY.json';registry=json.loads(path.read_text());names={d['name'] for d in NEW}
    registry['figures']=[d for d in registry['figures'] if d['name'] not in names]+NEW
    registry['all_figures_English']=True
    path.write_text(json.dumps(registry,ensure_ascii=False,indent=2))
    print('Additional English figure groups:',len(NEW),'; total:',len(registry['figures']),flush=True)

if __name__=='__main__':main()
