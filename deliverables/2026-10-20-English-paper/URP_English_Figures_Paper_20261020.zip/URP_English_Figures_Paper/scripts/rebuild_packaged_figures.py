"""Recreate all 43 figure groups from this package without crop-model calls.

Usage: python scripts/rebuild_packaged_figures.py --out /path/to/new/output
The source package is read-only; recreated figures and tables go to --out.
"""
from pathlib import Path
import argparse,importlib.util,json,shutil,tempfile
import pandas as pd

PACKAGE=Path(__file__).resolve().parents[1]

def module(name):
    path=PACKAGE/'scripts'/name
    spec=importlib.util.spec_from_file_location(path.stem,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def full_range(out):
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    years=[2019,2020,2021,2022]
    colors={2019:'#0072B2',2020:'#D55E00',2021:'#009E73',2022:'#A85AA0'}
    front=pd.read_csv(PACKAGE/'tables/Full_range_best_found_front.csv',float_precision='round_trip')
    dose=pd.read_csv(PACKAGE/'tables/Fixed_proportion_dose_response.csv',float_precision='round_trip')
    base=pd.read_csv(PACKAGE/'tables/R04_yield_comparison.csv',float_precision='round_trip').set_index('Year')
    fig,axes=plt.subplots(2,2,figsize=(7.2,5.85),layout='constrained',sharex=True,sharey=True)
    for i,(ax,y) in enumerate(zip(axes.flat,years)):
        a=front[front.Year==y];d=dose[dose.Year==y];b=base.loc[y]
        ax.plot(a.Irrigation_mm,a.Y_13pct,c=colors[y],lw=1.7,zorder=4)
        ax.plot(d.Irrigation_mm,d.Y_13pct,c='#929FA8',ls='--',lw=1.1,zorder=2)
        ax.scatter(0,a.Y_13pct.iloc[0],fc='white',ec=colors[y],s=36,lw=1.4,zorder=5)
        ax.scatter(b.Baseline_irrigation_mm,b.Model_baseline_Y13,c='#263F4B',marker='*',s=75,zorder=5)
        ax.axhline(b.Yield_gate_Y13,c='#B37870',ls=':',lw=1)
        ax.set(title=f'({chr(97+i)}) {y}',xlim=(-15,660),ylim=(0,19),xticks=[0,200,400,600],yticks=[0,5,10,15])
        ax.grid(alpha=.16);ax.set_axisbelow(True)
    fig.supxlabel('Actual seasonal irrigation (mm)',fontsize=10)
    fig.supylabel('Grain yield at 13% moisture (t ha⁻¹)',fontsize=10)
    fig.legend(handles=[Line2D([],[],c='#536979',lw=1.7,label='Full-range best-found front'),
        Line2D([],[],c='#929FA8',ls='--',label='Fixed-proportion dose response'),
        Line2D([],[],marker='o',mfc='white',mec='#536979',ls='',label='Zero irrigation'),
        Line2D([],[],marker='*',c='#263F4B',ls='',label='DI model baseline'),
        Line2D([],[],c='#B37870',ls=':',label='95% observed-yield gate (reference only)')],
        loc='outside upper center',ncol=2,frameon=False)
    def save(fig,name):
        for ext in ['png','pdf','svg']:fig.savefig(out/'figures'/(name+'.'+ext),dpi=600)
        plt.close(fig)
    save(fig,'R03_full_range_diagnostic_2x2_EN')
    fig,ax=plt.subplots(figsize=(7.2,4.6),layout='constrained')
    for y in years:
        a=front[front.Year==y];b=base.loc[y]
        ax.plot(a.Irrigation_mm,a.Y_13pct,c=colors[y],lw=1.7,label=str(y))
        ax.scatter(0,a.Y_13pct.iloc[0],fc='white',ec=colors[y],s=36,lw=1.3,zorder=4)
        ax.scatter(b.Baseline_irrigation_mm,b.Model_baseline_Y13,c=colors[y],marker='*',s=85,zorder=4)
    ax.set(xlabel='Actual seasonal irrigation (mm)',ylabel='Grain yield at 13% moisture (t ha⁻¹)',
        xlim=(-15,660),ylim=(0,19),xticks=[0,100,200,300,400,500,600],yticks=[0,5,10,15])
    ax.grid(alpha=.17);ax.set_axisbelow(True)
    fig.legend(handles=ax.get_legend_handles_labels()[0]+[
        Line2D([],[],marker='o',ls='',mfc='white',mec='#536979',label='Zero irrigation'),
        Line2D([],[],marker='*',ls='',c='#536979',label='DI model baseline')],loc='outside upper center',ncol=3,frameon=False)
    save(fig,'N01_Optimized_yield_irrigation_EN')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);a=parser.parse_args()
    out=a.out.resolve()
    if out==PACKAGE:raise ValueError('Choose a new output directory; keep source package unchanged')
    if out.exists() and any(out.iterdir()):raise FileExistsError('Output directory must be empty')
    out.mkdir(parents=True,exist_ok=True)
    for name in ['figures','tables','word_panels']:(out/name).mkdir()
    shutil.copytree(PACKAGE/'tables',out/'tables',dirs_exist_ok=True)
    shutil.copytree(PACKAGE/'model_records',out/'model_records')
    shutil.copyfile(PACKAGE/'FIGURE_REGISTRY.json',out/'FIGURE_REGISTRY.json')
    p1=module('part1_rebuild_figures_part1.py');p1.OUT=out/'figures'
    shutil.copyfile(PACKAGE/'tables/Figure10_daily_environment.csv',p1.OUT/'Figure10_daily_environment.csv')
    p1.three_column();p1.tree();p1.weather()
    p2=module('part2_mcmc_fit_rebuild_part2.py')
    with tempfile.TemporaryDirectory(prefix='urp_plot_inputs_') as tmp:
        project=Path(tmp);(project/'frozen_inputs').mkdir();(project/'figure_source_tables').mkdir()
        shutil.copyfile(PACKAGE/'model_records/verified_phase_specific_draws.npz',project/'frozen_inputs/verified_phase_specific_draws.npz')
        for name in ['parameter_intervals_verified.csv','mcmc_diagnostics_recomputed.csv','sampling_group_summary.csv','water_balance_recomputed.csv']:
            shutil.copyfile(PACKAGE/'tables'/name,project/'figure_source_tables'/name)
        for filename,target in [('Calibration_daily_growth.csv','Daily_growth.csv'),
            ('F02_CC_calibration_pairs.csv','CC_pairs.csv'),('F05_Biomass_calibration_pairs.csv','Biomass_pairs.csv')]:
            d=pd.read_csv(PACKAGE/'tables'/filename,float_precision='round_trip')
            for year,frame in d.groupby('Year'):
                dest=project/'frozen_inputs/year_outputs'/str(year);dest.mkdir(parents=True,exist_ok=True)
                # Packaged pair tables already contain selected rows. A union
                # column present only in one year's original table must not
                # cause older, already selected rows to be filtered a second time.
                frame=frame.drop(columns=['Included'],errors='ignore')
                frame.to_csv(dest/target,index=False)
        p2.calibration(project,out);p2.parameters(project,out);p2.water(project,out)
    p3=module('part3_sobol_rebuild_part3.py')
    load=lambda name:pd.read_csv(PACKAGE/'tables'/name,float_precision='round_trip')
    p3.figures(load('Sobol_all_seed_indices.csv'),load('Sobol_annual_means_and_ranks.csv'),
        load('Sobol_four_year_descriptive_means.csv'),load('Sobol_numerical_stability.csv'),out)
    p4=module('part4_optimization_diagnostic_diagnose_R03_finalize_R04.py')
    p4.ROOT=out;p4.TABLES=out/'tables';p4.PUB=PACKAGE/'tables'
    shutil.copyfile(PACKAGE/'verification/part4_optimization_diagnostic_FULL_RANGE_VERIFICATION.json',out/'FULL_RANGE_VERIFICATION.json')
    shutil.copyfile(PACKAGE/'verification/part4_FULL_RANGE_STATUS.json',out/'FULL_RANGE_STATUS.json')
    p4.main();full_range(out)
    rest=module('make_remaining_english_figures.py');rest.ROOT=out;rest.T=out/'tables';rest.F=out/'figures';rest.main()
    registry=json.loads((PACKAGE/'FIGURE_REGISTRY.json').read_text())
    for e in registry['figures']:
        for ext in ['png','pdf','svg']:assert (out/'figures'/(e['name']+'.'+ext)).is_file()
    print('All 43 English figure groups recreated from packaged data; zero crop-model or MCMC calls.',flush=True)

if __name__=='__main__':main()
