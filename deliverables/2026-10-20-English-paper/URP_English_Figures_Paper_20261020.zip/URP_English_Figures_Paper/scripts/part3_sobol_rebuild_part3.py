"""Combine the four-year Sobol figures; assess rank and magnitude separately."""
from pathlib import Path
import argparse,json,itertools
import numpy as np
import pandas as pd
from scipy.stats import spearmanr,rankdata
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

YEARS=[2019,2020,2021,2022]
NAMES=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
LABELS=['CCx','CGC','CDC','Senescence','Kcb','Early WP','Late WP','HI0']
COLORS={2019:'#0072B2',2020:'#D55E00',2021:'#009E73',2022:'#A85AA0'}
OUTPUTS=['Y_13pct','B_t_ha','ET_mm','MaxCC','Tr_mm','Es_mm']
TITLES={'Y_13pct':'Grain yield','B_t_ha':'Aboveground biomass','ET_mm':'Evapotranspiration',
        'MaxCC':'Maximum canopy cover','Tr_mm':'Transpiration','Es_mm':'Soil evaporation'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,
    'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
    'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
REG=[]


def write(path,x):Path(path).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False))


def save(fig,out,name,title,caption,sources):
    for suffix in ['png','pdf','svg']:fig.savefig(out/'figures'/f'{name}.{suffix}',dpi=600,facecolor='white')
    REG.append(dict(name=name,title=title,caption=caption,years=YEARS,source_tables=sources,PNG_dpi=600))
    plt.close(fig)


def summaries(raw,out):
    assert raw.Year.unique().tolist()==YEARS or sorted(raw.Year.unique())==YEARS
    assert set(raw.N)=={512} and set(raw.Seed)=={101,202,303}
    assert len(raw)==4*6*8*3 and not raw.duplicated(['Year','Output','Parameter','Seed']).any()
    annual=raw.groupby(['Year','Output','Parameter']).agg(S1_mean=('S1','mean'),ST_mean=('ST','mean'),
        ST_seed_min=('ST','min'),ST_seed_max=('ST','max'),ST_max_bootstrap_halfwidth=('ST_conf','max'),
        Output_variance_seed_mean=('Variance','mean')).reset_index()
    annual['ST_rank']=annual.groupby(['Year','Output']).ST_mean.rank(method='average',ascending=False)
    annual.to_csv(out/'tables/Sobol_annual_means_and_ranks.csv',index=False)
    means=[]
    for (output,param),a in annual.groupby(['Output','Parameter']):
        row=dict(Output=output,Parameter=param,Years=4,Year_weight=.25)
        for metric in ['S1','ST']:
            values=a[metric+'_mean'].to_numpy()
            row.update({metric+'_four_year_mean':values.mean(),metric+'_year_min':values.min(),metric+'_year_max':values.max(),
                metric+'_year_range':np.ptp(values),metric+'_year_SD':values.std(ddof=1)})
            row[metric+'_year_CV_if_mean_ge_0p01']=values.std(ddof=1)/abs(values.mean()) if abs(values.mean())>=.01 else np.nan
        for y in YEARS:row[f'ST_{y}']=float(a[a.Year==y].ST_mean.iloc[0])
        means.append(row)
    means=pd.DataFrame(means);means.to_csv(out/'tables/Sobol_four_year_descriptive_means.csv',index=False)
    pair_rows=[];overall=[]
    for output in OUTPUTS:
        a=annual[annual.Output==output].pivot(index='Parameter',columns='Year',values='ST_mean').reindex(index=NAMES,columns=YEARS)
        rho=[]
        for x,y in itertools.combinations(YEARS,2):
            corr=float(spearmanr(a[x],a[y]).statistic);rho.append(corr)
            pair_rows.append(dict(Output=output,Year_1=x,Year_2=y,Spearman_rho=corr,Number_of_parameters=8,
                Role='descriptive rank agreement, not an equivalence test'))
        ranks=np.array([rankdata(-a[y].to_numpy(),method='average') for y in YEARS])
        m,n=ranks.shape;total=ranks.sum(axis=0);ss=np.sum((total-total.mean())**2)
        ties=0
        for y in YEARS:
            _,counts=np.unique(a[y],return_counts=True);ties+=sum(c**3-c for c in counts if c>1)
        denom=m*m*(n**3-n)-m*ties
        W=12*ss/denom if denom else np.nan
        overall.append(dict(Output=output,Kendall_W_tie_corrected=W,Min_pairwise_Spearman=min(rho),
            Max_pairwise_Spearman=max(rho),Same_top_1=len({tuple(a[y].nlargest(1).index) for y in YEARS})==1,
            Same_top_2_set=len({tuple(sorted(a[y].nlargest(2).index)) for y in YEARS})==1,
            Same_top_3_set=len({tuple(sorted(a[y].nlargest(3).index)) for y in YEARS})==1,
            Caution='yearly mean ranks can agree while magnitudes or near-tied seed-level ranks differ'))
    pd.DataFrame(pair_rows).to_csv(out/'tables/Sobol_year_pair_rank_agreement.csv',index=False)
    pd.DataFrame(overall).to_csv(out/'tables/Sobol_output_rank_summary.csv',index=False)
    return annual,means,pd.DataFrame(overall)


def heatmap(ax,annual,output,panel):
    d=annual[annual.Output==output].pivot(index='Parameter',columns='Year',values='ST_mean').reindex(index=NAMES,columns=YEARS)
    im=ax.imshow(d,cmap='YlGnBu',vmin=0,vmax=1,aspect='auto')
    for i in range(8):
        for j in range(4):ax.text(j,i,f'{d.iloc[i,j]:.3f}',ha='center',va='center',fontsize=8.3,color='white' if d.iloc[i,j]>.55 else '#243746')
    ax.set(xticks=range(4),xticklabels=YEARS,yticks=range(8),yticklabels=LABELS,
        title=f'({panel}) {TITLES[output]}')
    return im


def figures(raw,annual,means,checks,out):
    main=['Y_13pct','B_t_ha','ET_mm','MaxCC']
    fig,axes=plt.subplots(2,2,figsize=(7.2,7.0),layout='constrained')
    for i,(ax,output) in enumerate(zip(axes.flat,main)):im=heatmap(ax,annual,output,chr(97+i))
    fig.colorbar(im,ax=list(axes.flat),label='Total-effect Sobol index, ST',shrink=.8,pad=.025)
    save(fig,out,'R01_Sobol_four_outputs_2x2_EN','Four-year total-effect sensitivity of four primary outputs',
        'Figure R1. Total-effect Sobol indices for (a) grain yield at 13% moisture, (b) aboveground dry biomass, '
        '(c) seasonal evapotranspiration and (d) maximum canopy cover. Each cell is the mean of three N=512 scrambles '
        'within a year, using the same eight independent uniform parameter ranges. One color scale is used throughout. '
        'Rank agreement and variation in index magnitude are assessed separately; indices are not normalized to sum to one. '
        'Transpiration and soil evaporation are retained in Supplementary Figure S5.',
        ['Sobol_all_seed_indices.csv','Sobol_annual_means_and_ranks.csv'])
    fig,axes=plt.subplots(1,2,figsize=(7.2,4.3),layout='constrained')
    for i,(ax,output) in enumerate(zip(axes,['Tr_mm','Es_mm'])):im=heatmap(ax,annual,output,chr(97+i))
    fig.colorbar(im,ax=list(axes),label='Total-effect Sobol index, ST',shrink=.8,pad=.025)
    save(fig,out,'S05_Sobol_Tr_Es_EN','Four-year sensitivity of the water-flux partition',
        'Supplementary Figure S5. Annual mean total-effect indices for transpiration and soil evaporation. '
        'All six original model outputs are retained in the source tables; these two outputs supplement the four primary-output panels in Figure R1.',
        ['Sobol_all_seed_indices.csv','Sobol_annual_means_and_ranks.csv'])
    # Combine years by superposition while retaining individual annual values.
    fig,axes=plt.subplots(1,2,figsize=(7.2,5.1),layout='constrained',sharey=True)
    y=np.arange(8)
    for ax,metric,title in zip(axes,['S1','ST'],['(a) First-order effect, S1','(b) Total effect, ST']):
        d=annual[annual.Output=='Y_13pct'];m=means[means.Output=='Y_13pct'].set_index('Parameter').reindex(NAMES)
        for j,year in enumerate(YEARS):
            z=d[d.Year==year].set_index('Parameter').reindex(NAMES)
            ax.scatter(z[metric+'_mean'],y+(j-1.5)*.125,c=COLORS[year],marker=['o','s','^','v'][j],s=25,zorder=4)
        ax.hlines(y,m[metric+'_year_min'],m[metric+'_year_max'],color='#A7B5BF',lw=1.5,zorder=2)
        ax.scatter(m[metric+'_four_year_mean'],y,c='#243746',marker='D',s=31,ec='white',lw=.5,zorder=5)
        ax.axvline(0,c='#A7B5BF',lw=.7)
        ax.set(title=title,yticks=y,yticklabels=LABELS,ylim=(7.6,-.6),xlim=(-.04,.55),xlabel='Sobol sensitivity index')
        ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
    handles=[Line2D([],[],marker=['o','s','^','v'][j],c=COLORS[year],ls='',label=str(year)) for j,year in enumerate(YEARS)]
    handles.extend([Line2D([],[],marker='D',c='#243746',ls='',label='Four-year mean'),Line2D([],[],c='#A7B5BF',label='Across-year min–max')])
    fig.legend(handles=handles,loc='outside upper center',ncol=3,frameon=False)
    save(fig,out,'R02_Sobol_Yield_all_years_mean_EN','Yield sensitivity across four years and its equal-weight descriptive mean',
        'Figure R2. Four-year yield sensitivity shown together as (a) first-order and (b) total-effect indices. '
        'Colored symbols are annual means across three independent scrambles; black diamonds are equal-weight means across the four annual estimates. '
        'Gray segments show the annual minimum–maximum range, not confidence intervals. '
        'A four-year mean summarizes these simulation contexts and is not a pooled climate-mixture Sobol index or proof of year-invariant sensitivity. '
        'Within-year numerical intervals are retained in Supplementary Figure S4.',
        ['Sobol_annual_means_and_ranks.csv','Sobol_four_year_descriptive_means.csv'])
    fig,axes=plt.subplots(2,2,figsize=(7.2,6.5),layout='constrained',sharex=True,sharey=True)
    for ax,year in zip(axes.flat,YEARS):
        d=raw[(raw.Year==year)&(raw.Output=='Y_13pct')]
        for j,seed in enumerate([101,202,303]):
            z=d[d.Seed==seed].set_index('Parameter').reindex(NAMES)
            ax.errorbar(z.ST,y+(j-1)*.18,xerr=z.ST_conf,fmt=['o','s','^'][j],ms=3.2,lw=.75,capsize=1.7,color=COLORS[year],alpha=.85)
        s1=d.groupby('Parameter').S1.mean().reindex(NAMES)
        ax.scatter(s1,y,s=20,marker='D',fc='white',ec='#253F4D',lw=.7,zorder=4)
        ax.set(title=f'{year}; N = 512',yticks=y,yticklabels=LABELS,ylim=(7.6,-.65),xlim=(-.04,.62),xlabel='Sobol index')
        ax.grid(axis='x',alpha=.18)
        if year==2022:
            ax.text(.98,.025,'Early WP ≈ Kcb',transform=ax.transAxes,ha='right',fontsize=8.5,color='#657682')
    fig.legend(handles=[Line2D([],[],marker=m,ls='',color='#536979',label=f'ST: seed {seed}') for m,seed in zip(['o','s','^'],[101,202,303])]+
        [Line2D([],[],marker='D',mfc='white',mec='#253F4D',ls='',label='S1: seed mean')],loc='outside upper center',ncol=2,frameon=False)
    save(fig,out,'S04_Sobol_yield_numerical_intervals_EN','Yield sensitivity and within-year numerical uncertainty',
        'Supplementary Figure S4. Total-effect yield indices from three N=512 scrambles per year, with 95% bootstrap half-widths based on 512 resamples. '
        'Open diamonds show the within-year scramble mean of S1. The early-WP/Kcb ordering remains numerically uncertain in 2022. '
        'This numerical uncertainty is distinct from between-year sensitivity variation. Negative finite-sample S1 values are not set to zero.',
        ['Sobol_all_seed_indices.csv','Sobol_numerical_stability.csv'])


def notes(annual,means,ranks,out):
    y=means[means.Output=='Y_13pct'].set_index('Parameter')
    text='''# 第三部分：Sobol合并图与年度稳定性

R01主图采用2×2：产量、生物量、ET和最大冠层四个主输出。原六输出中的Tr与Es不删除，另列补图S05；原始576条逐种子指标全部保留。

R02保留并合并四年：同一张图中分别展示S1和ST，彩色点表示各年的三种子均值，黑菱形表示四年等权均值，灰线是年际最小–最大范围，不是置信区间。原R02逐年、逐种子的数值区间保留为S04。用户提到的cat/coc尚未在原表找到对应列，等待名称定义，不擅自当成CCx、CGC、S1或ST。

## 为什么可以给四年均值

四年使用同一输出定义、同一八参数独立均匀范围、同一N和估计方法，因而可在同一口径下计算等权描述性均值。主要输出的年度平均排序高度一致，为以均值概括主要排序提供支持；但敏感性幅度不完全一致，必须同时展示年际点和范围，不能把“排序稳定”写成“各年贡献完全相同”。

均值计算分两步：先在每年对三个独立scramble取均值，再对四个年度均值按1/4等权。不能把12个估计当作12个独立气候年份，也不能把这一均值叫作含气候变异的总体Sobol指数。

各年Sobol指数的分母是该年输出方差。四个比值的均值通常不等于将年份作为随机输入、将四年响应混合后得到的方差分解指数。本文的均值只描述这四个既定模拟情景，不外推为未来气候或所有地区的普遍贡献。

## 稳定性证据应分开报告

- 数值稳定性：N递增、重复scramble与bootstrap区间；原24个输出×年份中23个通过筛查，2022产量Early WP/Kcb近并列。
- 年际排序：四年年度均值间的Spearman相关、Kendall一致性W及前列集合是否一致。
- 年际幅度：各参数ST和S1的均值、最小–最大、SD与范围；近零均值不报告具有误导性的CV。

以上是描述性核查，不是只有四年的等效性检验。ST也不应强制归一化为加和100%的贡献率；总效应含交互作用。

## 可用于正文的英文段落

For grain yield, biomass, seasonal evapotranspiration and maximum canopy cover, the rank ordering of the eight annual-mean total-effect indices was identical across the four simulation years (pairwise Spearman ρ = 1.00). Sensitivity magnitudes nevertheless varied among years. For example, the total-effect index of Kcb for evapotranspiration ranged from 0.762 to 0.882, while the CCx index for maximum canopy cover ranged from 0.836 to 0.957. Four-year equal-weight means are therefore used as descriptive summaries of the common experimental design, with the individual annual estimates and their range shown explicitly. They are not interpreted as year-invariant contributions or as Sobol indices for a pooled climate distribution.

Yield sensitivity was dominated by late-period WP and HI0. The ST values of late-period WP ranged from 0.353 to 0.426, whereas those of HI0 ranged from 0.203 to 0.208. The annual-mean ordering of early-period WP and Kcb was nearly tied in 2022, and scramble-level uncertainty prevents a strong distinction between their ranks. Numerical repeatability within years and consistency between years are reported separately.

## 图文状态

四组英文PNG/PDF/SVG已制作，CSV与Excel保留原数据和全部汇总。cat/coc映射待确认。本部分暂不打包发送，随所有修订统一交付。
'''
    (out/'PART3_ANALYSIS_NOTES.md').write_text(text,encoding='utf-8')
    write(out/'R02_PENDING_CAT_COC.json',{'status':'AWAITING_USER_DEFINITIONS','unknown_fields':['cat','coc'],
        'existing_metrics':['S1','ST'],'no_mapping_assumed':True,
        'provisional_plot':'R02_Sobol_Yield_all_years_mean_EN'})


def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,default=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED'))
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();out=a.out
    (out/'figures').mkdir(parents=True,exist_ok=True);(out/'tables').mkdir(exist_ok=True)
    source=a.project/'actual_publication_20261019/tables'
    raw=pd.read_csv(source/'Sobol_all_seed_indices.csv',float_precision='round_trip')
    raw.to_csv(out/'tables/Sobol_all_seed_indices.csv',index=False)
    checks=pd.read_csv(source/'Sobol_numerical_stability.csv');checks.to_csv(out/'tables/Sobol_numerical_stability.csv',index=False)
    annual,means,ranks=summaries(raw,out);figures(raw,annual,means,checks,out);notes(annual,means,ranks,out)
    write(out/'FIGURE_REGISTRY.json',{'years':YEARS,'figures':REG,'R02_cat_coc_status':'PENDING_DEFINITION',
        'averaging':'first three scrambles within each year, then four equal-weight year means',
        'descriptive_mean_is_not_pooled_climate_Sobol':True,'new_crop_simulations_for_Sobol':False})
    (out/'CAPTIONS_EN.txt').write_text('\n\n'.join(r['caption'] for r in REG))
    print('Built',len(REG),'combined Sobol figure groups and stability source tables',flush=True)


if __name__=='__main__':main()
