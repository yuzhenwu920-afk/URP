from pathlib import Path
import json,re,subprocess,hashlib
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH,WD_LINE_SPACING
from docx.enum.section import WD_SECTION_START,WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
OUT=ROOT;T=OUT/'tables'
YEARS=[2019,2020,2021,2022]
def df(n):return pd.read_csv(T/(n+'.csv'))
def table(headers,rows):
    return '\n'.join(['|'+'|'.join(headers)+'|','|'+'|'.join(['---']*len(headers))+'|']+
                    ['|'+'|'.join(map(str,r))+'|' for r in rows])

def expand():
    source=(ROOT/'writing_template.md').read_text()
    cal=df('calibration_metrics_recomputed')
    gate=df('observed_yield_gate_headroom').set_index('Year')
    water=df('water_balance_recomputed');water=water[water.Scenario=='DI'].set_index('Year')
    climate=df('climate_audit').set_index('Year')
    ref=[
        ['研究对象','2020年六个棉田；PDF第4页表2','2019—2022年DI玉米，不能移用棉田坐标和参数'],
        ['校准证据','NDVI转换CC与年产量；第3—4页','Field LAI转换CC、水分目标、生物量和产量；遥感仅辅助'],
        ['参数推断','11参数MCMC；32 walkers、2000步；第4页','五参数阶段一、三参数阶段二；条件推断与诊断限制单列'],
        ['敏感性','11参数均匀范围，N=500；第5页','8参数公共独立范围，初始N=128、3种子；正式响应待算'],
        ['管理变量','四生长阶段SMT；第5、8页','当前2022接口为五个固定日期的灌水量'],
        ['目标与约束','增产、减水；以其基准定义约束；第5页','双目标；灌水不超基准，Y13≥发表观测95%'],
        ['不确定性','均值输入优化；第9页承认未完整传播','固定中心优化＋候选分阶段条件核验；不是联合稳健最优'],
    ]
    blocks={'TABLE_REFERENCE': '表1  参考论文与URP的结构映射\n\n'+table(['环节','参考论文写法与位置','URP采用的写法'],ref)}
    rows=[]
    for y in YEARS:
        a=cal[(cal.Year==y)&(cal.Variable=='CC')].iloc[0]
        b=cal[(cal.Year==y)&(cal.Variable=='Biomass')].iloc[0]
        rows.append([y,int(climate.loc[y,'Days']),int(a.N),int(b.N),
            f'{gate.loc[y,"Observed_Y13_t_ha"]:.2f}',f'{gate.loc[y,"Baseline_Irrigation_mm"]:.2f}'])
    blocks['TABLE_DATA']='表2  四年资料规模与DI基准\n\n'+table(['年份','气象日数','CC配对数','B配对数','观测Y13（t/ha）','灌水（mm）'],rows)
    params=[
        ['CCx','阶段一：冠层上限','比例','[0.60, 0.99]'],
        ['CGC_CD','阶段一：冠层增长','日⁻¹','[0.08, 0.16]'],
        ['CDC_CD','阶段一：冠层衰退','日⁻¹','[0.03, 0.12]'],
        ['SenescenceCD','阶段一：衰老起始','播后日历日','[115, 145]'],
        ['Kcb','阶段一：基础作物系数','无量纲','[1.05, 1.60]'],
        ['WP_early','阶段二：前段有效WP','g/m²','[10, 40]'],
        ['WP_late','阶段二：后段有效WP','g/m²','[10, 40]'],
        ['HI0','阶段二：参考收获指数','比例','[0.35, 0.60]']]
    blocks['TABLE_PARAMETERS']='表3  参数含义与正式Sobol公共独立范围（非原MCMC先验）\n\n'+table(['参数','主要作用','单位','Sobol范围'],params)
    groups=df('sampling_group_summary');rows=[]
    for r in groups.sort_values(['Year','Phase']).itertuples():
        rows.append([int(r.Year),int(r.Phase),int(r.Ensembles),int(r.Integer_group_burn),
                     int(r.Retained_steps_per_walker),int(r.Retained_correlated_draws)])
    blocks['TABLE_SAMPLING']='表4  既有采样记录（各ensemble均32 walkers、2000步）\n\n'+table(['年份','阶段','ensemble数','截断步','保留步/walker','相关保留行数'],rows)
    rows=[]
    for y in YEARS:
        a=cal[(cal.Year==y)&(cal.Variable=='CC')].iloc[0];b=cal[(cal.Year==y)&(cal.Variable=='Biomass')].iloc[0]
        rows.append([y,f'{a.R2:.4f}',f'{a.RMSE:.4f}',f'{b.R2:.4f}',f'{b.RMSE:.4f}',
            f'{gate.loc[y,"Original_model_baseline_Y13_t_ha"]:.4f}',f'{gate.loc[y,"Baseline_bias_pct_vs_observed"]:+.2f}'])
    blocks['TABLE_CALIBRATION']='表5  校准评价（CC为比例，B为地上干生物量）\n\n'+table(['年份','CC R²','CC RMSE','B R²','B RMSE t/ha','模拟Y13 t/ha','产量偏差%'],rows)
    centers=df('central_vectors_with_provenance').set_index('Year')
    keys=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
    blocks['TABLE_CENTERS']='表6  分阶段保留样本算术均值拼接的确定性中心\n\n'+table(['参数']+list(map(str,YEARS)),
        [[k]+[f'{centers.loc[y,k]:.4f}' for y in YEARS] for k in keys])
    rows=[]
    for y in YEARS:
        r=water.loc[y];rows.append([y,f'{r.Irrigation_mm:.2f}',f'{r.Tr_mm:.2f}',f'{r.Es_mm:.2f}',f'{r.ET_mm:.2f}',
                                    f'{r.Storage_gain_mm:+.2f}',f'{r.IWP_kg_m3:.3f}'])
    blocks['TABLE_WATER']='表7  四年DI季节水量与灌溉水生产率\n\n'+table(['年份','I mm','Tr mm','Es mm','ET mm','储水增加 mm','IWP kg/m³'],rows)
    rows=[]
    for y in YEARS:
        r=gate.loc[y];rows.append([y,f'{r.Observed_Y13_t_ha:.2f}',f'{r.Original_model_baseline_Y13_t_ha:.4f}',
            f'{r.Absolute_95pct_gate_t_ha:.4f}',f'{r.Remaining_loss_allowed_pct_of_model_baseline:.2f}%'])
    blocks['TABLE_GATES']='表8  以发表观测产量定义的门槛及减产余量\n\n'+table(['年份','观测Y13','模型基准Y13','95%观测门槛','相对模型允许减产'],rows)+'\n\n产量单位为t/ha；最后一列不是节水率。'
    blocks['TABLE_SCHEDULE']='表9  2022原固定日期与基准灌水量\n\n'+table(['日期','基准水量（mm）','优化变量'],[
        ['2022-06-09','84.36','该日期水量a1'],['2022-06-22','77.12','该日期水量a2'],
        ['2022-07-03','80.73','该日期水量a3'],['2022-07-24','76.78','该日期水量a4'],
        ['2022-08-09','85.85','该日期水量a5'],['合计','404.84','合计受上限约束']])
    blocks['TABLE_PENDING_RESULTS']='表10  正式候选结果的填写格式（尚未生成）\n\n'+table(
        ['年份','候选I mm','候选Y13 t/ha','节水率%','产量Q05','条件门槛达标比例'],
        [[y,'待真实计算','待真实计算','待真实计算','分阶段另列','分阶段另列'] for y in YEARS])
    blocks['TABLE_COMPLETION']='表11  从框架到投稿稿的必要补充\n\n'+table(['内容','当前可写的证据','后续补充'],[
        ['试验来源','已有四年处理、驱动与配对表','地点、品种、重复数、图件页码及误差出处'],
        ['模型与先验','2022原模型、正式阶段二合同与四年中心可追溯','其余年度源码接入、交接点及年度先验表'],
        ['校准评价','表5及18组当前四年图','独立资料评价或明确保留无独立验证限制'],
        ['敏感性','设计与范围已声明','真实响应、S1/ST及区间、样本量与种子稳定性'],
        ['优化','目标、约束、日期与预算已声明','真实前沿、NSGA-II对照、候选回代与条件扰动'],
        ['结论与推广','现有过程复现及参数补偿','据真实结果填节水率，明确年度与管理适用范围']])
    for key,value in blocks.items():source=source.replace('{{'+key+'}}',value)
    assert '{{TABLE_' not in source
    (OUT/'URP_paper_writing_framework.md').write_text(source,encoding='utf-8')

# Twenty image pages comprise all eighteen original figure groups.
ATLAS=[
 ('图1','研究路线与数据状态','F01_workflow','wide',
  '四年冻结校准输入、过程复现与后续正式计算的衔接。原图中的完成状态对应2026-10-18核验。',
  '该图用来连接“为什么先校准”与“怎样进入决策”。先说明四年资料和条件参数来源，再说明2022原模型已接入；敏感性与优化在现阶段仍是待执行环节。',
  '适合放在材料方法开头；投稿稿若实验已完成，必须随实际结果更新状态，不能只保留流程图就宣称完成优化。'),
 ('图2','四年气象驱动','F10_climate','portrait',
  '线为参考蒸散ETo，灰柱为日降水。2022为冻结B组ETo；其他年份沿用原气象输入。',
  '不同年份的需水驱动及降水过程并不相同，是跨年比较的外部条件。此处先描述季节内变率，不用气象曲线本身解释全部产量差异。',
  '说明模型实际使用哪一类ETo及其处理来源；原始ETo与B组修正量不能混名。'),
 ('图3','冠层资料的证据角色','F11_CC_evidence_roles','portrait',
  '彩色为DI田间LAI转换CC，灰色为遥感辅助时序；遥感未进入当前似然。',
  '两类时序的差别提示来源、处理及转换的不确定性。2019—2021遥感处理为BI，2022标签不全；因此不以曲线接近作为DI独立验证。',
  '用于资料与局限说明；不能把此图改称“遥感同化效果”，也不能把来源差异都归因于模型误差。'),
 ('图4','分阶段采样记录','F12_sampling_record','wide',
  '左图为每walker保留步数，右图为总步数与组内最大τ之比；50τ为参考线。',
  '保留步数是截断与链长的记录，不能直接等同有效独立样本量。阶段一每年4个ensemble、阶段二1个，这种组织决定了可作出的诊断范围。',
  '与表4和补充图S7配合；超过一条长度参考线仍不能证明全面收敛。'),
 ('图5','四年冠层校准过程','F02_CC_trajectories','portrait',
  '实线为模型逐日输出，空心点为校准观测。R²与RMSE按全部年度配对复算，四年坐标范围一致。',
  '模型总体跟随冠层扩展与平台阶段；2022部分早期观测高于模拟，且R²低于其余年份，应解释这种过程偏差，而不是只报告总体拟合较好。',
  '2019—2021为已核验原输出，2022为本轮冻结均值点回放；均属样本内校准评价。'),
 ('图6','四年生物量校准过程','F03_Biomass_trajectories','portrait',
  '生物量为地上干物质，单位t/ha。实线与空心点含义同图5。',
  '2021生物量RMSE约1.252 t/ha，2022约0.556 t/ha，说明不同年度误差并不一致。应联系WP结构和数字化资料误差讨论，不能只以高R²判断每个阶段均准确。',
  '生物量属于阶段二校准证据，不写成独立验证；同时与终点产量和参数补偿图对照。'),
 ('图7','校准误差概览','F06_calibration_summary','wide',
  '分别展示CC RMSE、生物量RMSE和年产量相对观测偏差。±5%灰带为项目容许范围。',
  '冠层、生物量和产量共同描绘拟合表现；2022产量偏差接近零但冠层误差相对较大，体现终点与过程指标不能相互替代。',
  '不同面板单位不同，不直接比较RMSE数值大小；灰带不是置信区间，单年产量不计算R²。'),
 ('图8a','保留样本参数分位区间：前四参数','F07_parameter_intervals_a','portrait',
  '点为中位数，竖线为2.5%—97.5%保留样本分位；由原图F07同一源表拆分重排。',
  'CCx、CGC、CDC和衰老起始的区间长度不同，反映当前资料、先验和模型结构下的识别差异。贴近边界时应同时讨论边界及先验影响。',
  '严格采样诊断限制仍在，称保留样本分位区间；区间窄不自动等于公共范围敏感性低。'),
 ('图8b','保留样本参数分位区间：后四参数','F07_parameter_intervals_b','portrait',
  '显示Kcb及阶段二WP_early、WP_late、HI0；与图8a合为原F07一组。',
  '阶段二不同年度的WP与HI0组合存在变化，需结合生物量和产量解释。它们是在相应阶段条件下得到的分布，不是相互独立的八参数区间。',
  '不要把拼接区间称为八维联合后验；区间也不提供已验证的生理变化因果关系。'),
 ('图9','阶段二参数补偿','F08_phase2_compensation','portrait',
  '散点仅作等距抽稀展示，相关系数由全部同阶段整行保留样本计算。',
  '2022 WP_late与HI0相关约−0.645，显示生物量形成效率与收获分配之间可以补偿。类似终点产量可能由不同参数组合产生。',
  '用于讨论可辨识性，并支持整行条件扰动；相关不是因果关系，也不能据此宣布某参数更敏感。'),
 ('图10','四年DI季节水量账','F09_water_ledger','portrait',
  '入流及储水耗用与出流及储水增加同时展示，ΔS为期末减期初；模型水量账闭合。',
  '2019、2022存在储水消耗，2020、2021存在储水增加。季节灌水与ET并非一一对应，因而节水评价应同时说明土壤储水变化。',
  '守恒是内部数值检查，不等于通量得到田间验证；不能单凭2021储水增加就宣称其灌水一定可减少某个百分数。'),
 ('图11','观测产量保产门槛','F13_yield_gate','wide',
  '圆点为模拟基准，空心菱形为发表观测，短竖线为95%观测门槛；右图为相对模型基准的减产余量。',
  '2021只剩约0.86%的进一步减产余量，2022约4.99%。相同95%观测门槛在不同年份具有不同松紧程度。',
  '右图不是节水率；选择候选要用绝对产量门槛，不能从有偏模拟基准再减5%。'),
 ('补充图S1','冠层观测—模拟配对','F04_CC_pairs','portrait',
  '虚线为1:1；R²按1−SSE/SST计算，n为该年CC配对数。',
  '散点补充过程图：若某阶段点持续落在1:1线同一侧，提示系统偏差。2022部分观测高于模拟与图5的前期偏差相呼应。',
  '不连接散点制造时间关系；样本量和观测量值范围均影响R²解释。'),
 ('补充图S2','生物量观测—模拟配对','F05_Biomass_pairs','portrait',
  '横纵轴均为t/ha，四年使用相同量值范围及1:1参考。',
  '配对散点展示较高生物量阶段的偏差是否具有方向性，可与RMSE和Bias一起报告。2022拟合较接近1:1仍属于同一校准资料的比较。',
  '不要把生物量的拟合R²当作产量R²；数字化资料误差仍需说明。'),
 ('补充图S3','阶段二WP_early保留段轨迹','F14_phase2_trace_WP_early','portrait',
  '线为每步32个walker的中位数，浅带为10%—90%分位；仅显示截断后的保留段。',
  '该图用于检查步间漂移和样本覆盖的外观，说明保留段如何分布；它不是32条独立链的轨迹图。',
  '浅带不是作物产量的后验预测区间，也不单独证明收敛。'),
 ('补充图S4','阶段二WP_late保留段轨迹','F15_phase2_trace_WP_late','portrait',
  '轨迹定义与S3相同，各年保留起点不同，横轴保留原采样步数。',
  'WP_late的轨迹与图9的相关结构结合，可帮助解释该参数在条件空间中的探索；波动幅度不直接等于管理风险。',
  '样本有效性须结合自相关及适用诊断，不能因曲线平稳就删去诊断限制。'),
 ('补充图S5','阶段二HI0保留段轨迹','F16_phase2_trace_HI0','portrait',
  'HI0为参考收获指数输入；线、浅带与截断定义同S3。',
  'HI0不同年度的分布位置与WP参数补偿相关；需要与最终调整收获指数HIadj区分。',
  '不将输入HI0恒等于所有情景的最终HI，也不将分位带当作独立链不确定性。'),
 ('补充图S6a','年度中心值：前四参数','F17_parameter_centers_a','portrait',
  '点为各阶段保留样本算术均值，虚线仅辅助跨年阅读；原F17拆分的第一部分。',
  '该图说明确定性模型用了哪些年度输入，突出“来源于校准中心”的定义。',
  '只有四个年度条件点，不依据连接线声称长期趋势或统计显著变化。'),
 ('补充图S6b','年度中心值：后四参数','F17_parameter_centers_b','portrait',
  'Kcb、WP_early、WP_late、HI0中心，与S6a合为原F17一组。',
  '参数中心可用于确定性管理试验，但拼接中心输出不等于对全部样本预测求平均。',
  '完整区间和相关信息见图8、图9；不能用中心点图代替不确定性描述。'),
 ('补充图S7','阶段一严格诊断','S01_phase1_diagnostics','wide',
  '沿用原检查点复核，显示阶段一秩标准化Rhat和bulk ESS；四年仍未达到原严格诊断阈值。',
  '该图保留对推断精度的实质限制。参数中心、过程拟合及下游确定性分析应连同此限制解释，不能改写为已全面认证收敛。',
  '不因拟合好而隐去此图，也不据此自动新增联合后验或强制重跑门槛。原始计算组织及诊断定义须保留。'),
]

SANS='Noto Sans CJK SC';SERIF='Noto Serif CJK SC'
def rf(r,size=None,bold=None,color=None):
    r.font.name=SERIF
    f=r._element.get_or_add_rPr().get_or_add_rFonts()
    for k in ['ascii','hAnsi','eastAsia','cs']:f.set(qn('w:'+k),SERIF)
    if size is not None:r.font.size=Pt(size)
    if bold is not None:r.bold=bold
    if color:r.font.color.rgb=RGBColor.from_string(color)
def pf(p,size=11,after=5):
    f=p.paragraph_format;f.space_after=Pt(after);f.line_spacing=Pt(size*1.5);f.line_spacing_rule=WD_LINE_SPACING.EXACTLY
    f.widow_control=True
    snap=OxmlElement('w:snapToGrid');snap.set(qn('w:val'),'false');p._p.get_or_add_pPr().append(snap)
    for r in p.runs:rf(r,size)
def addp(d,text='',size=11,bold=False,after=5):
    p=d.add_paragraph();p.add_run(text);pf(p,size,after)
    for r in p.runs:rf(r,size,bold)
    return p
def footer(sec):
    sec.header_distance=Cm(.7);sec.footer_distance=Cm(.8)
    # Shared normal header/footer keeps page fields continuous across sections.
    if not sec.header.paragraphs[0].text:
        p=sec.header.paragraphs[0];p.text='URP  |  2019—2022 DI玉米  |  论文写作框架与图表解读'
        pf(p,8,0)
        for r in p.runs:rf(r,8,color='6B7B87')
    if not sec.footer.paragraphs[0].text:
        p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.add_run('URP  |  ');pf(p,8.5,0)
        e=OxmlElement('w:fldSimple');e.set(qn('w:instr'),'PAGE');p._p.append(e)
def dimensions(sec,wide):
    sec.page_width=Cm(29.7 if wide else 21);sec.page_height=Cm(21 if wide else 29.7)
    sec.orientation=WD_ORIENT.LANDSCAPE if wide else WD_ORIENT.PORTRAIT
    sec.left_margin=Cm(1.6 if wide else 2);sec.right_margin=Cm(1.6 if wide else 2)
    sec.top_margin=Cm(1.25 if wide else 1.8);sec.bottom_margin=Cm(1.2 if wide else 1.8)
    grid=sec._sectPr.find(qn('w:docGrid'))
    if grid is not None:sec._sectPr.remove(grid)
    footer(sec)

def word():
    target=OUT/'URP_paper_writing_framework.docx'
    subprocess.run(['pandoc',str(OUT/'URP_paper_writing_framework.md'),'-f','markdown+tex_math_single_backslash','-o',str(target)],
                   check=True,capture_output=True)
    d=Document(target);dimensions(d.sections[0],False)
    d.core_properties.title='URP论文写作框架与正文示例（含四年图表）'
    d.core_properties.author='URP项目写作工作稿'
    d.core_properties.subject='参考Liu等2025年AWM论文；分阶段MCMC、Sobol与灌溉优化'
    normal=d.styles['Normal'];normal.font.name=SERIF;normal.font.size=Pt(11)
    normal._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),SERIF)
    for name in ['Heading 1','Heading 2','Heading 3']:
        s=next(s for s in d.styles if s.style_id==name.replace(' ',''));s.font.name=SANS;s.font.color.rgb=RGBColor.from_string('24556B')
        s._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),SANS)
        s.font.size=Pt(16 if name=='Heading 1' else 13 if name=='Heading 2' else 11.5)
        s.paragraph_format.keep_with_next=True
    for i,p in enumerate(d.paragraphs):
        heading=p.style.name.startswith('Heading')
        size=16 if p.style.name=='Heading 1' else 13 if p.style.name=='Heading 2' else 11.5 if heading else 11
        pf(p,size,after=7 if heading else 5)
        if heading:
            for r in p.runs:
                r.font.name=SANS;r.font.color.rgb=RGBColor.from_string('24556B');r.bold=True
                r._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),SANS)
            p.paragraph_format.space_before=Pt(12 if p.style.name=='Heading 1' else 8)
            p.paragraph_format.keep_with_next=True
            if p.style.name=='Heading 1' and i>0:p.paragraph_format.page_break_before=True
            if i==0:
                pf(p,22,after=14)
                for r in p.runs:
                    rf(r,22,True,color='24556B')
        if p.text.endswith('：'):p.paragraph_format.keep_with_next=True
        if p.text.startswith('【写作说明') or p.text.startswith('【待补'):
            for r in p.runs:rf(r,10.5,color='815722')
        if p.text.startswith('【') and p.text.endswith('】') and len(p.text)<80:
            p.paragraph_format.keep_with_next=True
        if p.text.startswith('表') and re.match(r'^表\d+',p.text):
            p.paragraph_format.keep_with_next=True
            for r in p.runs:rf(r,10.5,True)
        if p._p.xpath('.//m:oMath'):
            p.paragraph_format.line_spacing=1.1
            p.paragraph_format.keep_together=True
            p.paragraph_format.space_before=Pt(7);p.paragraph_format.space_after=Pt(8)
    for t in d.tables:
        t.autofit=False;t.alignment=WD_TABLE_ALIGNMENT.CENTER
        widths=[17/len(t.columns)]*len(t.columns)
        if len(t.columns)==3:widths=[2.6,6.8,7.6]
        if len(t.columns)==4:widths=[3.1,6.1,3.2,4.6]
        for c,w in zip(t.columns,widths):c.width=Cm(w)
        for ri,row in enumerate(t.rows):
            no=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(no)
            if ri==0:
                hdr=OxmlElement('w:tblHeader');row._tr.get_or_add_trPr().append(hdr)
            for c,w in zip(row.cells,widths):
                c.width=Cm(w);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                for p in c.paragraphs:
                    pf(p,9.5,3);p.paragraph_format.line_spacing=Pt(14.5)
                    p.paragraph_format.keep_with_next=ri<len(t.rows)-1
                    for r in p.runs:rf(r,9.5,ri==0)
                if ri==0:
                    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E7EFF3');c._tc.get_or_add_tcPr().append(sh)
        bs=OxmlElement('w:tblBorders')
        for edge in ['top','left','bottom','right','insideH','insideV']:
            e=OxmlElement('w:'+edge)
            for k,v in [('val','single'),('sz','4'),('color','ABBAC3')]:e.set(qn('w:'+k),v)
            bs.append(e)
        t._tbl.tblPr.append(bs)
    # Cover navigation and the glossary make the draft useful as a writing guide.
    cover_end=next(p for p in d.paragraphs if p.style.name=='Heading 1' and p.text.startswith('一、'))
    for text in [
        '本稿包含：参考论文结构映射；摘要至结论的中文正文示例；可编辑数学公式与11张方法/数据表；18组四年图的图注、正文解读和写作提示。',
        '使用建议：在Word导航窗格按章节浏览；优先使用与现有证据对应的正文，补齐真实敏感性及优化结果后，再整理为目标期刊的篇幅。',
        '关键区别：MCMC估计模型参数，Sobol解释指定范围的方差贡献，NSGA-III搜索管理变量；三者回答不同问题。NSGA-III中的III不表示只运行三代，也不要求三个目标。',
    ]:
        p=cover_end.insert_paragraph_before(text);pf(p,11,after=12)
    # A compact figure locator fills the atlas introduction page.
    p=addp(d,'图表导航（现有18组，两个八参数图各分上下页）',11,True,8)
    locator=d.add_table(rows=1,cols=3)
    for c,text in zip(locator.rows[0].cells,['图号','内容','建议论文位置']):c.text=text
    positions=['方法路线','资料','资料角色','采样方法','校准结果','校准结果','拟合评价','参数分析','参数分析',
               '参数补偿','水量过程','管理约束','补充材料','补充材料','补充材料','补充材料','补充材料','补充材料','补充材料','诊断限制']
    for item,position in zip(ATLAS,positions):
        for c,text in zip(locator.add_row().cells,[item[0],item[1],position]):c.text=text
    for row in locator.rows:
        for c in row.cells:
            for p in c.paragraphs:pf(p,9.5,after=2)
    locator.alignment=WD_TABLE_ALIGNMENT.CENTER
    # The main draft ends with atlas instructions; every following image group
    # occupies its own section/page so orientation and readable sizes are explicit.
    receipt=[]
    atlas_markdown=[]
    for label,title,stem,layout,caption,interpret,tip in ATLAS:
        wide=layout=='wide'
        sec=d.add_section(WD_SECTION_START.NEW_PAGE);dimensions(sec,wide)
        p=addp(d,label+'  '+title,14,True,8);p.paragraph_format.keep_with_next=True
        f=(OUT/('figures_original' if wide else 'figures_word')/(stem+'.png'))
        im=Image.open(f);wcm=26 if wide else 17
        p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after=Pt(5);p.paragraph_format.line_spacing=1.0
        p.add_run().add_picture(str(f),width=Cm(wcm));p.paragraph_format.keep_with_next=True
        p=addp(d,'图注：'+caption,10.5,False,7);p.paragraph_format.keep_together=True
        addp(d,'正文示例：'+interpret,11,False,6)
        addp(d,'写作说明：'+tip,10.5,False,3)
        # Compute print font size from the actual tight-cropped raster dimensions.
        minfont=10 if stem in ['F02_CC_trajectories','F03_Biomass_trajectories'] else 10.5
        effective=minfont*wcm/(im.width/300*2.54)
        assert effective>=10.0,(stem,effective)
        receipt.append({'label':label,'file':f.relative_to(OUT).as_posix(),'years':YEARS,
            'layout':layout,'image_width_cm':wcm,'image_height_cm':wcm*im.height/im.width,
            'minimum_effective_image_font_pt':effective,'caption':caption,'interpretation':interpret,'writing_note':tip,
            'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
        atlas_markdown += ['## '+label+' '+title,'','!['+title+']('+f.relative_to(OUT).as_posix()+')','',
                          '图注：'+caption,'','正文示例：'+interpret,'','写作说明：'+tip,'']
    d.save(target)
    (OUT/'FIGURE_WRITING_INDEX.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
    md=OUT/'URP_paper_writing_framework.md'
    md.write_text(md.read_text()+'\n'+'\n'.join(atlas_markdown),encoding='utf-8')
    print('Word created:',target.name,'tables',len(d.tables),'inline figures',len(d.inline_shapes),
          'editable math objects',len(d._element.xpath('.//m:oMath')),
          'minimum effective figure font',round(min(x['minimum_effective_image_font_pt'] for x in receipt),2))

if __name__=='__main__':
    expand();word()
