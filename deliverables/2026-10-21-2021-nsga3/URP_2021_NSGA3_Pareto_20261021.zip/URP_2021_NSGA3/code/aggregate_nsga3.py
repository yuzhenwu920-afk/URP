"""Union of all actually evaluated controls; explicit model vs observed targets."""
import json,hashlib,shutil
import numpy as np
import pandas as pd
from pilot_engine import ROOT,PROJECT,SOURCE,dump
from pareto_engine import Engine
from run_nsga3 import front,SEEDS,POP,GEN
T=ROOT/'tables'


def main():
    status=json.loads((ROOT/'verification/OPTIMIZATION_STATUS.json').read_text());assert status['State']=='COMPLETE'
    e=Engine(True,'aggregate');e.install();reference=[]
    for label,x in [('DI_model_baseline',e.base),('Zero_irrigation',np.zeros(4))]:
        s,w,g=e.run(x,True);s.update(Scenario=label,**dict(zip(e.spec['names'],map(float,x))))
        reference.append({k:v for k,v in s.items() if k!='irrigation_events'});w.to_csv(T/f'{label}_daily_water.csv',index=False);g.to_csv(T/f'{label}_daily_growth.csv',index=False)
    refs=pd.DataFrame(reference);refs.to_csv(T/'Baseline_and_zero.csv',index=False);baseline=refs[refs.Scenario.eq('DI_model_baseline')].iloc[0]
    old=pd.read_csv(ROOT/'sources/Parent_water_audit_summary.csv');old=old[old.Scenario.eq('I100')].iloc[0]
    for key in ['Y_13pct','ET_mm','Root1m_final_mm']:assert abs(baseline[key]-old[key])<1e-8
    frames=[];stability=[];all_history=[]
    for seed in SEEDS:
        folder=ROOT/'runs'/f'seed{seed}';a=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip');assert len(a)==POP*GEN
        assert a.G_seasonal_cap.max()<=0 and a.Max_daily_balance_residual_mm.max()<1e-7
        a['Candidate_ID']=[f's{seed}_e{int(i):05d}' for i in a.Evaluation];frames.append(a)
        f=front(a);match=f[f.Y_13pct>=baseline.Y_13pct-1e-9]
        stability.append(dict(Seed=seed,Evaluations=len(a),Front_points=len(f),Maximum_found_Y13=f.Y_13pct.max(),
            Minimum_I_for_DI_model_yield_mm=match.Irrigation_mm.min() if len(match) else None,
            Maximum_end_root_storage_on_front_mm=f.Root1m_final_mm.max()))
        h=pd.read_csv(folder/'history.csv');all_history.append(h)
    allpoints=pd.concat(frames,ignore_index=True);allpoints.to_csv(T/'All_NSGA3_evaluations.csv.gz',index=False,compression='gzip')
    f=front(allpoints);f.to_csv(T/'NSGA3_best_found_front.csv',index=False)
    # 0.01 mm is a reporting/comparison tolerance, not a measured error bound.
    # It avoids excluding effectively equal stores due to tiny transient tails.
    floor=float(baseline.Root1m_final_mm);eligible=allpoints[allpoints.Root1m_final_mm>=floor-.01].copy();sf=front(eligible)
    sf.to_csv(T/'Storage_qualified_evaluated_subset_front.csv',index=False)
    pd.DataFrame(stability).to_csv(T/'Seed_stability.csv',index=False);pd.concat(all_history,ignore_index=True).to_csv(T/'Generation_history_all_seeds.csv',index=False)
    selection=[]
    def add(name,row,target=None,status='FOUND_IN_EVALUATED_SET',scope='primary two-objective front'):
        if row is None:
            selection.append(dict(Selection=name,Status='NOT_FOUND_IN_SEARCH',Target_Y13=target,Scope=scope));return
        out=row.to_dict();out.update(Selection=name,Status=status,Target_Y13=target,Scope=scope,
            Irrigation_reduction_vs_DI_pct=100*(1-float(row.Irrigation_mm)/e.cap),
            Yield_difference_vs_DI_model_pct=100*(float(row.Y_13pct)/baseline.Y_13pct-1),
            Yield_difference_vs_observed_pct=100*(float(row.Y_13pct)/15.86-1),
            Extra_root_storage_depletion_vs_DI_mm=float(baseline.Root1m_final_mm-row.Root1m_final_mm))
        selection.append(out)
    add('Maximum_found_yield',f.loc[f.Y_13pct.idxmax()])
    iv=(f.Irrigation_mm-f.Irrigation_mm.min())/(f.Irrigation_mm.max()-f.Irrigation_mm.min())
    yv=(f.Y_13pct-f.Y_13pct.min())/(f.Y_13pct.max()-f.Y_13pct.min())
    add('Geometric_compromise',f.loc[(yv-iv).idxmax()])
    for name,target in [('Match_DI_model_yield',float(baseline.Y_13pct)),('At_least_95pct_observed_yield',.95*15.86),('Match_observed_yield',15.86)]:
        q=f[f.Y_13pct>=target-1e-9];add(name,q.iloc[0] if len(q) else None,target)
    q=sf[sf.Y_13pct>=baseline.Y_13pct-1e-9]
    add('Storage_qualified_match_DI_model',q.iloc[0] if len(q) else None,float(baseline.Y_13pct),scope='post-filtered evaluated candidates, NOT a dedicated constrained optimization')
    chosen=pd.DataFrame(selection);chosen.to_csv(T/'Selected_front_solutions.csv',index=False)
    replays=[];events=[]
    for _,row in chosen[chosen.Status.eq('FOUND_IN_EVALUATED_SET')].iterrows():
        x=row[e.spec['names']].to_numpy(float);s,w,g=e.run(x,True)
        for key in ['Y_13pct','Irrigation_mm','Root1m_final_mm']:assert abs(s[key]-row[key])<1e-8
        label=row.Selection;w.to_csv(T/f'{label}_daily_water.csv',index=False);g.to_csv(T/f'{label}_daily_growth.csv',index=False)
        replays.append(dict(Selection=label,**{k:v for k,v in s.items() if k!='irrigation_events'},**dict(zip(e.spec['names'],x))))
        for event,original in zip(s['irrigation_events'],e.data['schedule'].Depth):events.append(dict(Selection=label,Date=event['date'],Window=event['stage']+1,Original_DI_mm=float(original),Actual_mm=event['mm']))
    pd.DataFrame(replays).to_csv(T/'Selected_solution_replays.csv',index=False);pd.DataFrame(events).to_csv(T/'Selected_actual_event_schedules.csv',index=False)
    # All final fronts are based on evaluated candidates, never a fitted envelope.
    assert np.all(np.diff(f.Irrigation_mm)>=0) and np.all(np.diff(f.Y_13pct)>0)
    e.restore()
    summary=dict(Year=2021,Algorithm='NSGA-III',Seeds=SEEDS,Population=POP,Generations=GEN,Actual_optimization_evaluations=len(allpoints),
        Front_points=len(f),Storage_qualified_subset_points=len(sf),Storage_qualified_evaluations=len(eligible),
        Observed_Y13=15.86,Baseline_DI_Y13=float(baseline.Y_13pct),Baseline_DI_irrigation_mm=e.cap,
        Baseline_DI_final_root_storage_mm=floor,Zero_irrigation_Y13=float(refs[refs.Scenario.eq('Zero_irrigation')].Y_13pct.iloc[0]),
        Maximum_found_Y13=float(f.Y_13pct.max()),Original_parameters_SHA256=hashlib.sha256((ROOT/'sources/SELECTED_PILOT_PARAMETERS.json').read_bytes()).hexdigest(),
        MCMC_converged=False,MCMC_reruns=0,Objectives=2,Storage_floor_enforced_in_search=False,Yield_gate_enforced=False,
        Storage_subset_definition='End-of-season 0-1m storage >= original DI model storage minus0.01mm comparison tolerance; front from qualifying evaluated points only; not a dedicated constrained search',
        Selection_definition='Geometric compromise maximizes normalized yield minus normalized irrigation; display choice, not a field optimum',
        Constraint_tolerance='target yield1e-9t/ha; storage comparison0.01mm; not a measured uncertainty bound')
    dump(ROOT/'RESULT_SUMMARY.json',summary)
    snap=ROOT/'model_snapshots/DI_PHASE3_NEXTGEN_UPDATED/real_model';snap.mkdir(parents=True,exist_ok=True)
    shutil.copytree(SOURCE.parent,snap/'model_2021',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','MCMC_Article_Results_2021'))
    for name in ['four_year_adapter.py','numerical_acceleration.py','root_zone_kernel.py','physical_kernels.py','KERNEL_ARGUMENTS.json']:shutil.copy2(PROJECT/'real_model'/name,snap/name)
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
