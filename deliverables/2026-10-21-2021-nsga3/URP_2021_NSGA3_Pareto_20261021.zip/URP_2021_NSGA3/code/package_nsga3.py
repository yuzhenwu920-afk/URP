"""Independent scientific-output verification and delivery packaging."""
import contextlib,hashlib,json,shutil,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
import fitz
from pareto_engine import Engine
from pilot_engine import ROOT
from run_nsga3 import SEEDS,POP,GEN

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    meta=json.loads((ROOT/'RESULT_SUMMARY.json').read_text());allpoints=pd.read_csv(ROOT/'tables/All_NSGA3_evaluations.csv.gz',float_precision='round_trip');f=pd.read_csv(ROOT/'tables/NSGA3_best_found_front.csv',float_precision='round_trip');chosen=pd.read_csv(ROOT/'tables/Selected_front_solutions.csv',float_precision='round_trip')
    assert len(allpoints)==30000 and allpoints.Candidate_ID.nunique()==30000
    assert allpoints.Max_daily_balance_residual_mm.max()<1e-7
    assert allpoints.Irrigation_mm.min()>=0 and allpoints.Planned_irrigation_mm.max()<=633.47+1e-8
    # Independently test whether any actual evaluated point dominates each front point.
    I=allpoints.Irrigation_mm.to_numpy();Y=allpoints.Y_13pct.to_numpy()
    for _,r in f.iterrows():
        assert not np.any((I<=r.Irrigation_mm)&(Y>=r.Y_13pct)&((I<r.Irrigation_mm)|(Y>r.Y_13pct)))
    matched=0;generation_files=0
    names=[f'Window{i}_mm' for i in range(1,5)]
    for seed in SEEDS:
        a=pd.read_csv(ROOT/'runs'/f'seed{seed}'/'evaluations.csv.gz',float_precision='round_trip');assert len(a)==10000
        lookup={tuple(x):row for x,(_,row) in zip(a[names].to_numpy(),a.iterrows())}
        for gen in range(1,101):
            with np.load(ROOT/'runs'/f'seed{seed}'/f'generation_{gen:04d}.npz',allow_pickle=False) as g:
                assert g['X'].shape==(100,4) and g['F'].shape==(100,2) and np.all(g['CV']<=0)
                for x,response in zip(g['X'],g['F']):
                    r=lookup[tuple(x)];np.testing.assert_allclose(response,[-r.Y_13pct,r.Irrigation_mm],atol=1e-10,rtol=0);matched+=1
            generation_files+=1
    # Fresh process: exact original unaccelerated equations, including final root stock.
    replays=[]
    with (ROOT/'verification/UNACCELERATED_REPLAY.log').open('w') as log,contextlib.redirect_stdout(log):
        e=Engine(False,'unaccelerated_check');e.install()
        try:
            for _,row in chosen[chosen.Status.eq('FOUND_IN_EVALUATED_SET')].iterrows():
                s,w,g=e.run(row[names].to_numpy(float),True)
                dif={k:abs(s[k]-row[k]) for k in ['Y_13pct','Irrigation_mm','ET_mm','Root1m_final_mm','Below1m_final_mm']}
                assert max(dif.values())<1e-8
                replays.append(dict(Selection=row.Selection,Maximum_absolute_difference=max(dif.values()),Status='PASS'))
        finally:e.restore()
    sf=pd.read_csv(ROOT/'tables/Storage_qualified_evaluated_subset_front.csv');floor=meta['Baseline_DI_final_root_storage_mm']
    assert len(sf)>0 and (sf.Root1m_final_mm>=floor-.01-1e-10).all()
    reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text());assert len(reg)==3
    images=[]
    for r in reg:
        p=ROOT/'figures'/(r['ID']+'.png');im=Image.open(p);assert im.width>3500 and im.height>2000;images.append(dict(File=p.name,Width=im.width,Height=im.height))
    doc=Document(ROOT/'URP_2021_NSGA3_Report.docx');pdf=fitz.open(ROOT/'URP_2021_NSGA3_Report.pdf');assert len(doc.inline_shapes)==3 and all(len(p.get_text())>80 for p in pdf)
    check=dict(Status='PASS',Optimization_evaluations=30000,Front_points=len(f),Front_nondominance_against_all_evaluated_points='PASS',
        Generation_files=generation_files,Population_records_matched_to_actual_evaluations=matched,
        Unaccelerated_selected_replays=replays,Storage_subset_floor_comparison='DI final store minus0.01mm reporting tolerance',
        Storage_subset_front_points=len(sf),Figures=images,Report_pages=len(pdf),Report_tables=len(doc.tables),
        MCMC_reruns=0,Parent_MCMC_converged=False,Field_validation=False)
    (ROOT/'verification/FINAL_DATA_CHECK.json').write_text(json.dumps(check,indent=2))
    selected=[]
    for folder in ['code','tables','figures','sources','verification','runs','model_snapshots']:
        selected.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.lock','.tmp'])
    selected.extend(ROOT/name for name in ['README.md','RESULT_SUMMARY.json','FIGURE_REGISTRY.json','URP_2021_NSGA3_Report.docx','URP_2021_NSGA3_Report.pdf','URP_2021_NSGA3_Report.md','URP_2021_NSGA3_Data.xlsx','ENVIRONMENT.json','requirements.txt'])
    selected=sorted(selected);manifest=dict(Date='2026-10-21',Scope='2021 NSGA-III with fixed selected root1m pilot parameters; 30000 actual model optimization evaluations',
        Files=[dict(Path=str(p.relative_to(ROOT)),Bytes=p.stat().st_size,SHA256=sha(p)) for p in selected])
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));selected.append(ROOT/'MANIFEST.json')
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+str(p.relative_to(ROOT)) for p in selected)+'\n');selected.append(ROOT/'SHA256SUMS.txt')
    archive=ROOT.parent/'URP_2021_NSGA3_Pareto_20261021.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in selected:z.write(p,'URP_2021_NSGA3/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for p in manifest['Files']:assert hashlib.sha256(z.read('URP_2021_NSGA3/'+p['Path'])).hexdigest()==p['SHA256']
    target=Path('/workspace/URP/deliverables/2026-10-21-2021-nsga3');target.mkdir(parents=True,exist_ok=True)
    for p in [archive,ROOT/'README.md',ROOT/'RESULT_SUMMARY.json',ROOT/'URP_2021_NSGA3_Report.docx',ROOT/'URP_2021_NSGA3_Report.pdf',ROOT/'URP_2021_NSGA3_Data.xlsx',
        ROOT/'figures/N21_01_Pareto_front.png',ROOT/'figures/N21_02_Storage_qualification.png',ROOT/'tables/Selected_front_solutions.csv',ROOT/'tables/NSGA3_best_found_front.csv',ROOT/'verification/FINAL_DATA_CHECK.json']:
        shutil.copy2(p,target/p.name)
    result=dict(Status='PASS',Archive_bytes=archive.stat().st_size,Archive_SHA256=sha(archive),Files=len(selected),ZIP_CRC='PASS',Manifest_hashes='PASS')
    (target/'PACKAGE_CHECK.json').write_text(json.dumps(result,indent=2));(target/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in sorted(target.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt')+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
