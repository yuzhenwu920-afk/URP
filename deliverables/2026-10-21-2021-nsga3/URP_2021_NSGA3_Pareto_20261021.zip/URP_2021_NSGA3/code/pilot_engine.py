"""2021 original likelihood, Zmax=1m; exact kernels and memoized WP inverse."""
from pathlib import Path
import copy,importlib.util,sys,functools,json,time,os
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
PROJECT=Path(os.environ.get('URP_PROJECT','/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED'))
SOURCE=PROJECT/'real_model/model_2021/DI_2021_MCMC_ONE_CLICK.py'

def load(accelerated=True,tag='default'):
    spec=importlib.util.spec_from_file_location('original2021_driver',SOURCE)
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    for name in ['sampler','diagnostics','audit_hooks','ensemble_pipeline']:
        driver._embedded_module(name)
    m=driver._embedded_module('model',SOURCE.parent/'data/model.py')
    m.OUTPUT_DIR=ROOT/'runs'/'input_audit'/tag;m.OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
    data=m.load_inputs();m.prepare_soil(data)
    point=json.loads((SOURCE.parent/'data/start.json').read_text())
    m.PRIOR_BOUNDS.update(WP_early=(10.,40.),WP_late=(10.,40.),HI0=(.35,.60))
    m.NORMAL_PRIORS={'CDC_CD','SenescenceCD'}
    data['center'].update(WP_early=25.,WP_late=25.)
    original=m.crop_for
    def crop(v):
        c=original(v);c.Zmin=.30;c.Zmax=1.;return c
    m.crop_for=crop
    m.effective_wp=functools.lru_cache(maxsize=128)(m.effective_wp)
    if accelerated:
        sys.path.insert(0,str(PROJECT/'real_model'))
        import numerical_acceleration
        numerical_acceleration.install()
    return driver,m,data,point

def dump(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False))

if __name__=='__main__':
    d,m,data,p=load(False,'validation');t=time.time()
    ref=m.simulate(data,p);print('unaccelerated',time.time()-t,ref[0],flush=True)
    sys.path.insert(0,str(PROJECT/'real_model'));import numerical_acceleration;numerical_acceleration.install()
    times=[]
    for i in range(4):
        t=time.time();r=m.simulate(data,p);times.append(time.time()-t)
    diff={k:abs(ref[0][k]-r[0][k]) for k in ref[0]}
    print('accelerated_seconds',times,'max_diff',max(diff.values()),flush=True)
    np.testing.assert_allclose(ref[1].select_dtypes(include=[np.number]),r[1].select_dtypes(include=[np.number]),atol=1e-10,rtol=0)
    dump(ROOT/'verification/INITIAL_ACCELERATION_CHECK.json',dict(Status='PASS',Metrics_absolute_difference=diff,Accelerated_seconds=times,Initial_metrics=r[0]))
