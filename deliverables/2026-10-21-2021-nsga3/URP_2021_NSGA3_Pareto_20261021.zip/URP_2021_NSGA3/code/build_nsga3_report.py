"""Numeric workbook, concise Chinese interpretation and English figure report."""
import json,platform,importlib.metadata
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openpyxl.styles import Font,PatternFill,Alignment
from pilot_engine import ROOT
T=ROOT/'tables'
LABEL={'Maximum_found_yield':'最高找到产量','Geometric_compromise':'几何示意点（非推荐）','Match_DI_model_yield':'匹配原DI模型产量','At_least_95pct_observed_yield':'达到95%实测产量','Match_observed_yield':'达到实测产量','Storage_qualified_match_DI_model':'储水合格子集匹配DI模型'}
def read(name):return pd.read_csv(T/(name+'.csv'))

def main():
    meta=json.loads((ROOT/'RESULT_SUMMARY.json').read_text());chosen=read('Selected_front_solutions');chosen['方案']=chosen.Selection.map(LABEL);chosen['状态']=chosen.Status.map({'FOUND_IN_EVALUATED_SET':'已找到','NOT_FOUND_IN_SEARCH':'本次未找到'})
    reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text());seed=read('Seed_stability');ref=read('Baseline_and_zero');baseline=ref[ref.Scenario.eq('DI_model_baseline')].iloc[0]
    with pd.ExcelWriter(ROOT/'URP_2021_NSGA3_Data.xlsx',engine='openpyxl') as writer:
        index=[]
        for i,p in enumerate(sorted(T.glob('*.csv')),1):
            name=f'{i:02d}_'+p.stem[:27];a=pd.read_csv(p);a.to_excel(writer,sheet_name=name,index=False);index.append(dict(Sheet=name,CSV=p.name,Rows=len(a)))
        allpoints=pd.read_csv(T/'All_NSGA3_evaluations.csv.gz');allpoints.to_excel(writer,sheet_name='ALL_30000_EVALUATIONS',index=False);index.append(dict(Sheet='ALL_30000_EVALUATIONS',CSV='All_NSGA3_evaluations.csv.gz',Rows=len(allpoints)))
        pd.DataFrame(index).to_excel(writer,sheet_name='INDEX',index=False)
        for ws in writer.book:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            for c in ws[1]:c.font=Font(name='Calibri',bold=True,color='FFFFFF',size=10);c.fill=PatternFill('solid',fgColor='275767');c.alignment=Alignment(wrap_text=True)
            for column in ws.columns:
                ws.column_dimensions[column[0].column_letter].width=min(34,max(13,max(len(str(c.value or '')) for c in list(column)[:25])+2))
                # Keep the full 30k-row workbook compact; style summary rows only.
                for c in list(column)[1:300]:
                    c.font=Font(name='Calibri',size=10)
                    if isinstance(c.value,float):c.number_format='0.0000'
                    if c.row%2==0:c.fill=PatternFill('solid',fgColor='F0F5F6')
    doc=Document();sec=doc.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=sec.right_margin=Cm(1.65);sec.top_margin=sec.bottom_margin=Cm(1.55)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
        st=doc.styles[name];st.font.name='DejaVu Sans';st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.styles['Normal'].font.size=Pt(10.5);doc.styles['Normal'].paragraph_format.line_spacing=1.10;doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    doc.styles['Title'].font.size=Pt(21);doc.styles['Heading 1'].font.size=Pt(14.5);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('275767');doc.styles['Caption'].font.size=Pt(9)
    ft=sec.footer.paragraphs[0];ft.alignment=WD_ALIGN_PARAGRAPH.CENTER;ft.add_run('URP · 2021年NSGA-III · ');pg=OxmlElement('w:fldSimple');pg.set(qn('w:instr'),'PAGE');ft._p.append(pg)
    md=[]
    def p(text,style=None):doc.add_paragraph(text,style);md.append(text+'\n')
    def h(text):doc.add_heading(text,1);md.append('\n## '+text+'\n')
    def table(title,a,cols):
        doc.add_heading(title,2);tab=doc.add_table(rows=1,cols=len(cols));tab.style='Light Shading Accent 1';flag=OxmlElement('w:tblHeader');tab.rows[0]._tr.get_or_add_trPr().append(flag)
        for cell,(_,label,_) in zip(tab.rows[0].cells,cols):cell.text=label
        for _,row in a.iterrows():
            for cell,(key,_,digits) in zip(tab.add_row().cells,cols):
                v=row[key];cell.text='—' if pd.isna(v) else str(v) if digits is None else f'{v:.{digits}f}'
        for i,row in enumerate(tab.rows):
            flag=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(flag)
            for cell in row.cells:
                for para in cell.paragraphs:
                    para.paragraph_format.space_after=Pt(3);para.paragraph_format.keep_with_next=i<len(tab.rows)-1
                    for run in para.runs:run.font.size=Pt(8.5)
        md.append(a[[k for k,_,_ in cols]].to_csv(index=False))
    def fig(i,height=12.6):
        r=reg[i-1];path=ROOT/'figures'/(r['ID']+'.png');im=Image.open(path);w,hh=im.size;im.thumbnail((2400,2600));embed=ROOT/'verification/word_figures'/(r['ID']+'.png');embed.parent.mkdir(parents=True,exist_ok=True);im.save(embed,optimize=True)
        para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER;para.paragraph_format.keep_with_next=True;para.add_run().add_picture(str(embed),width=Cm(min(17.5,height*w/hh)))
        p(f"图N21-{i:02d} · {r['Title']}",'Caption');p('解析：'+r['Interpretation_CN']);p('解释边界：'+r['Boundary_CN'],'Caption');p('数据：'+', '.join(r['Source_tables']),'Caption');md.append(f"![{r['Title']}](figures/{r['ID']}.png)\n")
    doc.add_heading('2021年DI玉米\nNSGA-III帕累托前沿',0)
    p('最大根深1m · 产量—实际灌水量双目标 · 2026-10-21','Subtitle')
    p('基于上一轮2021年1m最大根深MCMC短链试跑选定参数及含水量审计，实际重新运行NSGA-III。三代遗传指NSGA-III算法；本次每个随机种子运行100代，并非只迭代3代。')
    p(f"已完成3种子×100个体×100代=30,000次模型优化评价。全部评价非支配并集共{meta['Front_points']:,}点；最高找到产量{meta['Maximum_found_Y13']:.4f}t/ha，原DI模型产量{meta['Baseline_DI_Y13']:.4f}t/ha，文献实测15.86t/ha。最高找到不等于数学全局最优。")
    table('选定候选概览',chosen,[('方案','方案',None),('状态','状态',None),('Irrigation_mm','实际灌水mm',2),('Y_13pct','Y13 t/ha',3),('Root1m_final_mm','根层季末储水mm',2)])
    h('1 决策空间、目标与固定条件')
    p('目标为最大化13%含水率籽粒产量Y13、最小化实际季节灌水量I。NSGA-III可以用于双目标；没有为了算法名称强行添加缺乏依据的第三目标。季末储水在本轮作为审计量和后筛选指标，不冒充独立不确定性目标。')
    p('原7个DI灌水日期保留：6月13/30日、7月9/20/30日、8月11/23日。按事件顺序分四窗口（2、2、2、1次），优化窗口总量，同窗口内各次原比例不变；窗口不是重新识别的四个田间生育期，也没有优化日期。')
    p('计划季总量不超过633.47mm，实际执行量用于目标；提前结束生长后取消后续计划灌水，土壤水分平衡延续至共同日历边界。原MaxIrr和MaxIrrSeason按候选最大单次/季总量加0.10mm设置，属于执行保护，不是已知设备能力。未新增现场单次上限。')
    p('固定：Zmin=0.30m、Zmax=1.00m动态根深，MulchPct=75%、fMulch=0、WetSurf=100%、AppEff=100%，原天气/ETo、土壤水力转换及冻结初始水不变。fMulch=0仅关闭代码中额外减蒸效应。参数来自500步、10walkers的条件两阶段试跑，尚未正式收敛；本轮没有重跑MCMC或扩大先验。')
    p('搜索设置：种子31/73/109，100条二维Das–Dennis参考方向；SBX概率0.9、η=15，PM个体概率1、逐变量概率0.25、η=20。修复只将超季总量候选按比例缩回可行单纯形。保留零灌水、原DI和部分同比例减灌作为初始锚点，并全部实际重算。')
    h('2 2021年帕累托前沿')
    fig(1,12.7)
    p('读图先比较彩色前沿与同比例灰虚线：前沿额外收益来自四个窗口的水量重新配置，不能与固定比例路径混为同一曲线。星号是原DI模型，方框是实测产量，不能用模型基准冒充实测基准。')
    p('前沿只连接实际评价的非支配点，不用平滑拟合生成模拟产量。高水量点若产量没有更高，会被低水量候选支配，因此前沿通常不会延伸至原DI总量；原DI参考点仍完整保留。')
    for _,r in chosen[chosen.Selection.isin(['Match_DI_model_yield','At_least_95pct_observed_yield','Match_observed_yield'])].iterrows():
        if r.Status=='FOUND_IN_EVALUATED_SET':p(f"{LABEL[r.Selection]}：在已评价前沿中，达到目标{r.Target_Y13:.4f}t/ha的最少已找到实际灌水为{r.Irrigation_mm:.2f}mm，产量{r.Y_13pct:.4f}t/ha，比原DI少灌{r.Irrigation_reduction_vs_DI_pct:.2f}%。这是条件模型内的比较，尚非田间推荐。")
        else:p(f"{LABEL[r.Selection]}：本次未找到达到{r.Target_Y13:.4f}t/ha的候选。有限搜索未找到不等于数学上证明无解；未把目标降低后改称已经达到实测。")
    p('几何折中点采用前沿端点归一化后最大化“归一化产量−归一化灌水量”；取值受归一化范围和偏好影响，只作为展示候选，不自动称最优灌水定额。主搜索未施加95%实测产量门槛，因此零水和低水区没有被截掉。')
    h('3 将土壤耗储从少灌中分开')
    fig(2,10.5)
    table('选点的水量与储水审计',chosen[chosen.Status.eq('FOUND_IN_EVALUATED_SET')],[('方案','方案',None),('ET_mm','ET mm',2),('Extra_root_storage_depletion_vs_DI_mm','比DI多耗根层水mm',2),('Max_actual_event_mm','最大单次mm',2)])
    p(f"原DI季末0—1m储水为{meta['Baseline_DI_final_root_storage_mm']:.4f}mm。本轮橙色子集要求候选季末储水不低于此基准，再对合格已评价点求非支配集；共有{meta['Storage_qualified_evaluations']:,}个已评价候选合格，子集前沿{meta['Storage_qualified_subset_points']:,}点。")
    p('这不是另一轮带储水约束的NSGA-III，也不是已充分搜索的约束最优前沿。该阈值是同模型原DI基准，不是新增加的实测季末含水要求；原DI本身也会耗储，不能直接改为季末必须不低于播前而不检查基准是否可行。')
    p('储水比较允许0.01mm报告精度容差，以免因极小的数值尾差把几乎相同的季末储水判作不同；这不是实测含水量误差界限。子集实际条件为S末≥S末,DI−0.01mm。')
    r=chosen[chosen.Selection.eq('Match_DI_model_yield')&chosen.Status.eq('FOUND_IN_EVALUATED_SET')]
    if len(r):
        r=r.iloc[0];p(f"匹配原DI模型产量的主前沿候选：少灌{633.47-r.Irrigation_mm:.2f}mm，ET较原DI减少{baseline.ET_mm-r.ET_mm:.2f}mm，季末根层储水比原DI少{r.Extra_root_storage_depletion_vs_DI_mm:.2f}mm。少灌比例不等于耗水节约比例，也不能忽略下一季储水回补。")
    exceeded=chosen[chosen.Status.eq('FOUND_IN_EVALUATED_SET')&chosen.Exceeds_observed_max_event_114p8_mm.eq(True)]
    if len(exceeded):p('部分选点的最大单次水量超过原实测最大114.80mm，具体见表。原实测最大值不是已证实的设备上限，因此本轮只标记、不擅自加硬约束；这些日程的流量、时长、入渗和现场可实施性需另核对。')
    p('含水审计的已知限制继续适用：0—1m初始水含近似图件重建，0.9—1.2m原单元混合图件与ERA5来源，原土壤水力参数来自质地转换。不能因为搜索数值稳定就将这些输入假设视为已验证。')
    h('4 逐次灌水日程')
    events=read('Selected_actual_event_schedules')
    use=['Match_DI_model_yield','Storage_qualified_match_DI_model','Maximum_found_yield'];ev=events[events.Selection.isin(use)].copy()
    pivot=ev.pivot(index=['Date','Original_DI_mm'],columns='Selection',values='Actual_mm').reset_index()
    columns=[('Date','日期',None),('Original_DI_mm','原DI mm',2)]
    for key,label in [('Match_DI_model_yield','匹配DI模型'),('Storage_qualified_match_DI_model','储水子集合格'),('Maximum_found_yield','最高产量')]:
        if key in pivot:columns.append((key,label,2))
    table('代表方案实际执行量（mm）',pivot,columns)
    p('表内为引擎实际执行灌水量。全部前沿点保留四窗口控制、计划与取消水量、实际事件最大量、收获日期和根层储水；选定方案另保留逐日生长及水量通量。优化仅改变水量，原日期和同窗比例始终保留。')
    h('5 三种子稳定性与搜索证据')
    fig(3,9)
    table('种子间结果比较',seed,[('Seed','种子',0),('Maximum_found_Y13','最高找到Y13',4),('Minimum_I_for_DI_model_yield_mm','匹配DI最少I mm',2),('Front_points','前沿点数',0)])
    p('每代X、F、G、CV和完整评价记录已保存。当前种群超体积可以轻微波动；种子前沿接近或超体积稳定不等于证明全局最优。主前沿采用所有种子、所有代的评价并集，而非最后一代。')
    h('6 论文可用表述与复现')
    p('建议表述：固定2021年1m根深条件模型的校准试跑参数，以原DI日期上的四窗口灌水量为决策变量，采用NSGA-III求解籽粒产量最大和实际灌水量最小的双目标问题。三随机种子共30,000次模型评价形成最佳已找到非支配并集；同步报告季末根域储水及与原DI等储水基准的已评价候选子集，区分水量配置收益与土壤耗储。结果尚受短链参数诊断及初始含水重建证据限制，需独立亏缺灌水资料验证。')
    p('复现：URP_PROJECT指向model_snapshots/DI_PHASE3_NEXTGEN_UPDATED，依次运行run_nsga3.py、aggregate_nsga3.py、plot_nsga3.py、build_nsga3_report.py。已完成运行会读取run.json避免重复追加；不完整运行会保留并要求新目录，不能把不同搜索混入同一记录。')
    p('包内含3组英文图PNG/PDF/SVG、完整30,000行评价及Excel、前沿与选点表、300代种群快照、源码和输入快照、独立未加速回放与数据完整性检查。原MCMC完整链和含水审计仍保留在之前交付目录，未覆盖。')
    p('实测参照来自王尚今（2023）论文表4-1：2021 DI产量15.86t/ha、ET626.81mm；逐次表合计灌水633.47mm，表4-1总量633.46mm的0.01mm差异继续保留。当前搜索的气象和初始水是原模型冻结输入，未按目标产量重新调节。')
    doc.save(ROOT/'URP_2021_NSGA3_Report.docx');(ROOT/'URP_2021_NSGA3_Report.md').write_text('\n'.join(md))
    packages=['numpy','pandas','scipy','aquacrop','emcee','numba','llvmlite','pymoo','matplotlib','python-docx','openpyxl','Pillow','PyMuPDF']
    versions={k:importlib.metadata.version(k) for k in packages};(ROOT/'requirements.txt').write_text('\n'.join(k+'=='+v for k,v in versions.items())+'\n');(ROOT/'ENVIRONMENT.json').write_text(json.dumps(dict(Python=platform.python_version(),Packages=versions),indent=2))
    print('Report:',len(doc.inline_shapes),'figures,',len(doc.tables),'tables')

if __name__=='__main__':main()
