"""Selected 2021 1m pilot, with a read-only final root-domain storage observer."""
import importlib.util,json,hashlib,copy,time,sys
import numpy as np
from pilot_engine import ROOT,PROJECT,SOURCE,load,dump

class Engine:
    def __init__(self,accelerated=True,tag='pareto'):
        self.accelerated=accelerated;self.driver,self.m,self.data,_=load(accelerated,tag)
        self.params=json.loads((ROOT/'sources/SELECTED_PILOT_PARAMETERS.json').read_text())
        spec=importlib.util.spec_from_file_location('pareto_adapter',PROJECT/'real_model/four_year_adapter.py')
        self.adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.adapter);self.adapter.STATES[2021]=(self.m,self.data)
        self.spec=self.adapter.management_space(2021);self.base=np.array(self.spec['baseline_amounts']);self.cap=float(self.base.sum())
        prof=self.data['soil'].profile;self.weights=np.clip(1-prof.z_top.to_numpy(float),0,prof.dz.to_numpy(float))*1000
        self.initial_root=float(np.dot(self.data['theta'],self.weights));self.initial_profile=float(np.sum(self.data['theta'])*100)
        self.observer=False;self.final={}
    def install(self):
        assert not self.observer
        self.old_step=self.m.AquaCropModel._perform_timestep;engine=self
        def observe(model):
            result=engine.old_step(model);clock,cond,param,out=result
            if clock.model_is_finished:
                assert float(cond.z_root)<=1+1e-9
                assert float(param.Seasonal_Crop_List[0].Zmax)==1.
                assert float(param.FieldMngt.mulch_pct)==75. and float(param.FieldMngt.f_mulch)==0.
                engine.final=dict(Root1m_final_mm=float(np.dot(cond.th,engine.weights)),Maximum_root_depth_setting_m=float(param.Seasonal_Crop_List[0].Zmax))
            return result
        self.m.AquaCropModel._perform_timestep=observe;self.observer=True
    def restore(self):
        if self.observer:self.m.AquaCropModel._perform_timestep=self.old_step;self.observer=False
    def run(self,x,details=False):
        assert self.observer
        self.final={}
        control=dict(kind='stage_amounts',values=dict(zip(self.spec['names'],map(float,x))))
        s,w,g=self.adapter.simulate(params=self.params,year=2021,management=control,details=True,accelerate=self.accelerated)
        assert 'Root1m_final_mm' in self.final
        s.update(self.final);s['Root1m_initial_mm']=self.initial_root;s['Root1m_change_mm']=s['Root1m_final_mm']-self.initial_root
        s['Below1m_initial_mm']=s['Profile_initial_mm']-self.initial_root;s['Below1m_final_mm']=s['Profile_final_mm']-s['Root1m_final_mm']
        s['Below1m_change_mm']=s['Below1m_final_mm']-s['Below1m_initial_mm']
        s['Net_downward_1m_balance_derived_mm']=s['Rain_mm']+s['Irrigation_mm']-s['ET_mm']-s['Runoff_mm']-s['Root1m_change_mm']-(s['Surface_final_mm']-s['Surface_initial_mm'])
        assert abs(s['Net_downward_1m_balance_derived_mm']-s['Below1m_change_mm']-s['DeepPerc_mm'])<1e-7
        s['Max_actual_event_mm']=max(e['mm'] for e in s['irrigation_events'])
        s['Exceeds_observed_max_event_114p8_mm']=bool(s['Max_actual_event_mm']>114.80+1e-8)
        return (s,w,g) if details else s
    def plain(self,x):
        control=dict(kind='stage_amounts',values=dict(zip(self.spec['names'],map(float,x))))
        return self.adapter.simulate(params=self.params,year=2021,management=control,details=True,accelerate=self.accelerated)

if __name__=='__main__':
    e=Engine(True,'benchmark');e.install();times=[]
    for x in [e.base,np.zeros(4),e.base*.5,e.base*.7]:
        t=time.monotonic();s=e.run(x);times.append(time.monotonic()-t)
    e.restore();print('seconds',times,'last',s,flush=True)
