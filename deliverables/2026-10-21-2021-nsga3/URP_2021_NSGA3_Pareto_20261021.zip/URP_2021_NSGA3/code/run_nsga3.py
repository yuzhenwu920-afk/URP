"""2021 NSGA-III: actual yield vs actual irrigation, fixed root1m pilot params.
Four irrigation-window amounts; original event dates and within-window weights.
No fabricated uncertainty objective, minimum-yield gate or unrequested soil floor.
"""
from pathlib import Path
import json,time,contextlib,hashlib,multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd
from pymoo.core.problem import Problem
from pymoo.core.sampling import Sampling
from pymoo.core.repair import Repair
from pymoo.core.callback import Callback
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.optimize import minimize
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.indicators.hv import HV
from pareto_engine import Engine
from pilot_engine import ROOT,SOURCE,dump
POP,GEN,SEEDS=100,100,[31,73,109]

def front(frame):
    a=frame.sort_values(['Irrigation_mm','Y_13pct','Planned_irrigation_mm'],ascending=[True,False,True],kind='mergesort').drop_duplicates(['Irrigation_mm','Y_13pct'])
    best=-np.inf;keep=[]
    for idx,r in a.iterrows():
        if r.Y_13pct>best:keep.append(idx);best=r.Y_13pct
    return a.loc[keep].reset_index(drop=True)

class CapRepair(Repair):
    def _do(self,problem,X,**kwargs):
        a=np.clip(X,0,problem.cap);s=a.sum(axis=1);factor=np.ones(len(s));over=s>problem.cap;factor[over]=problem.cap/s[over]
        return a*factor[:,None]

class AnchoredSampling(Sampling):
    def _do(self,problem,n_samples,random_state=None,**kwargs):
        rng=random_state if random_state is not None else np.random.default_rng(0)
        X=rng.dirichlet(np.ones(4),size=n_samples)*rng.uniform(0,1,n_samples)[:,None]*problem.cap
        anchors=[np.zeros(4),problem.engine.base]
        anchors.extend(problem.engine.base*f for f in np.linspace(.05,.95,19))
        anchors.append(problem.engine.base*(400/problem.cap))
        anchors.extend(np.eye(4)*problem.cap*f for f in [.25,.5])
        flat=[]
        for anchor in anchors:
            a=np.asarray(anchor)
            if a.ndim==2:flat.extend(a)
            else:flat.append(a)
        unique=[];seen=set()
        for a in flat:
            key=tuple(np.round(a,10))
            if key not in seen:seen.add(key);unique.append(a)
        for i,a in enumerate(unique[:n_samples]):X[i]=a
        return X

class IrrigationProblem(Problem):
    def __init__(self,engine,seed,folder):
        self.engine,self.seed,self.folder=engine,seed,folder;self.cap=engine.cap;self.count=0
        super().__init__(n_var=4,n_obj=2,n_ieq_constr=1,xl=np.zeros(4),xu=np.full(4,self.cap))
    def _evaluate(self,X,out,*args,**kwargs):
        fs=[];gs=[];rows=[]
        for x in X:
            s=self.engine.run(x);self.count+=1
            assert s['Planned_irrigation_mm']<=self.cap+1e-8 and s['Irrigation_mm']<=self.cap+1e-8
            delta=float(np.sum(x))-self.cap;g=0. if abs(delta)<=64*np.finfo(float).eps*self.cap else delta/self.cap
            fs.append([-s['Y_13pct'],s['Irrigation_mm']]);gs.append([g])
            rows.append(dict(Evaluation=self.count,Seed=self.seed,**dict(zip(self.engine.spec['names'],map(float,x))),
                **{k:v for k,v in s.items() if k!='irrigation_events'},G_seasonal_cap=g))
        out['F']=np.array(fs);out['G']=np.array(gs)
        p=self.folder/'evaluations.csv.gz';pd.DataFrame(rows).to_csv(p,index=False,mode='a',header=not p.exists(),compression='gzip')

class GenerationHistory(Callback):
    def __init__(self,problem):super().__init__();self.problem=problem;self.rows=[]
    def notify(self,algorithm):
        p=self.problem;gen=int(algorithm.n_gen);pop=algorithm.pop
        X,F,G,CV=pop.get('X'),pop.get('F'),pop.get('G'),pop.get('CV');assert len(X)==POP
        np.savez_compressed(p.folder/f'generation_{gen:04d}.npz',X=X,F=F,G=G,CV=CV)
        row=dict(Seed=p.seed,Generation=gen,Evaluations=p.count,Population=len(X),Maximum_yield=float(-F[:,0].min()),
            Population_normalized_HV=float(HV(ref_point=np.array([0.,1.05]))(np.c_[F[:,0]/15.86,F[:,1]/p.cap])),Feasible_individuals=int((CV.ravel()<=0).sum()))
        self.rows.append(row)
        if gen==1 or gen%5==0:
            pd.DataFrame(self.rows).to_csv(p.folder/'history.csv',index=False);dump(p.folder/'progress.json',dict(State='RUNNING',**row))
        if gen%10==0:print('seed',p.seed,'generation',gen,'/',GEN,'evaluations',p.count,flush=True)

def run_seed(seed):
    folder=ROOT/'runs'/f'seed{seed}';folder.mkdir(parents=True,exist_ok=True);state=folder/'run.json'
    if state.exists():
        prev=json.loads(state.read_text())
        if prev['State']=='COMPLETE':return prev
        raise RuntimeError('Incomplete run preserved; do not mix new evaluations with existing run: '+str(folder))
    with (folder/'log.txt').open('w',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        t=time.monotonic();e=Engine(True,f'seed{seed}');e.install()
        identity=dict(Seed=seed,Population=POP,Generations=GEN,Algorithm='NSGA-III',
            Objectives=['maximize model Y13','minimize actual seasonal irrigation'],Decision_space=e.spec,
            Seasonal_planned_cap_mm=e.cap,Zmax_m=1.,Zmin_m=.3,MulchPct=75.,fMulch=0.,WetSurf=100.,AppEff=100.,
            Yield_gate=False,Terminal_soil_floor=False,Additional_event_hardware_cap=False,Parameters=e.params,
            Parent_MCMC_scope='2021 500-step10-walker pilot; NOT converged posterior; fixed selected parameters',
            SBX=dict(probability=.9,eta=15),PM=dict(probability=1.,per_variable_probability=.25,eta=20),Reference_directions=100,
            Original_source_SHA256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            Parameter_file_SHA256=hashlib.sha256((ROOT/'sources/SELECTED_PILOT_PARAMETERS.json').read_bytes()).hexdigest())
        dump(state,dict(State='RUNNING',Identity=identity))
        try:
            problem=IrrigationProblem(e,seed,folder);cb=GenerationHistory(problem)
            algorithm=NSGA3(ref_dirs=get_reference_directions('das-dennis',2,n_partitions=99),pop_size=POP,
                sampling=AnchoredSampling(),repair=CapRepair(),crossover=SBX(prob=.9,eta=15),mutation=PM(prob=1.,prob_var=.25,eta=20),eliminate_duplicates=True)
            result=minimize(problem,algorithm,('n_gen',GEN),seed=seed,callback=cb,verbose=False)
            data=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip')
            assert len(data)==POP*GEN==result.algorithm.evaluator.n_eval and len(cb.rows)==GEN
            f=front(data[data.G_seasonal_cap<=0]);f.to_csv(folder/'all_evaluated_front.csv',index=False)
            pd.DataFrame(cb.rows).to_csv(folder/'history.csv',index=False)
            record=dict(State='COMPLETE',Identity=identity,Actual_evaluations=len(data),Front_points=len(f),Maximum_found_Y13=float(f.Y_13pct.max()),Seconds=time.monotonic()-t)
            dump(state,record);dump(folder/'progress.json',dict(State='COMPLETE',Evaluations=len(data)));return record
        except Exception as ex:dump(state,dict(State='FAILED',Identity=identity,Error=repr(ex)));raise
        finally:e.restore()

def main():
    status=dict(State='RUNNING',Seeds=SEEDS,Population=POP,Generations=GEN,Planned_evaluations=POP*GEN*len(SEEDS),Runs=[])
    dump(ROOT/'verification/OPTIMIZATION_STATUS.json',status)
    with ProcessPoolExecutor(max_workers=3,mp_context=mp.get_context('spawn')) as pool:
        futures=[pool.submit(run_seed,s) for s in SEEDS]
        for future in as_completed(futures):
            status['Runs'].append(future.result());dump(ROOT/'verification/OPTIMIZATION_STATUS.json',status);print('SEED COMPLETE',status['Runs'][-1]['Identity']['Seed'],flush=True)
    assert sum(r['Actual_evaluations'] for r in status['Runs'])==30000
    status['State']='COMPLETE';status['Actual_evaluations']=30000;dump(ROOT/'verification/OPTIMIZATION_STATUS.json',status)
    print('COMPLETE 30000 model optimization evaluations',flush=True)

if __name__=='__main__':main()
