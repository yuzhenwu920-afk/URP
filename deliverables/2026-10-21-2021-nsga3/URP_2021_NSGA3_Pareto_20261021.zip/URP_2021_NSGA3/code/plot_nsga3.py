"""English Pareto and soil-audit plots; finite evaluated fronts, no smoothing."""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from pilot_engine import ROOT
T=ROOT/'tables';F=ROOT/'figures';REG=[]
BLUE='#0072B2';ORANGE='#D55E00';GREEN='#009E73';DARK='#273E49';GREY='#9AABB4';SEEDCOL={31:BLUE,73:ORANGE,109:GREEN}
def read(name):return pd.read_csv(T/(name+'.csv'))
def style(ax):ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.14,zorder=0)
def save(fig,name,title,interpretation,boundary,sources):
    for ext in ['png','pdf','svg']:fig.savefig(F/(name+'.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig);REG.append(dict(ID=name,Title=title,Interpretation_CN=interpretation,Boundary_CN=boundary,Source_tables=sources))

def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.labelsize':12,'axes.titlesize':13,'xtick.labelsize':10.5,'ytick.labelsize':10.5,'legend.fontsize':9.5,'pdf.fonttype':42,'svg.fonttype':'none'})
    meta=json.loads((ROOT/'RESULT_SUMMARY.json').read_text());f=read('NSGA3_best_found_front');sf=read('Storage_qualified_evaluated_subset_front');chosen=read('Selected_front_solutions')
    refs=read('Baseline_and_zero');baseline=refs[refs.Scenario.eq('DI_model_baseline')].iloc[0]
    dose=pd.read_csv(ROOT/'sources/Proportional_DI_response.csv');cloud=pd.read_csv(T/'All_NSGA3_evaluations.csv.gz')
    sample=cloud.iloc[np.unique(np.linspace(0,len(cloud)-1,min(3500,len(cloud)),dtype=int))]
    fig,ax=plt.subplots(figsize=(10.2,6.6));fig.subplots_adjust(left=.09,right=.86,bottom=.14,top=.79)
    ax.scatter(sample.Irrigation_mm,sample.Y_13pct,s=5,color='#C0CBD0',alpha=.24,rasterized=True,zorder=1)
    ax.plot(dose.Irrigation_mm,dose.Y_13pct,color='#697F8B',ls='--',lw=1.25,zorder=2)
    coords=np.c_[f.Irrigation_mm,f.Y_13pct];segments=np.stack([coords[:-1],coords[1:]],axis=1)
    norm=Normalize(vmin=float(f.Root1m_final_mm.min()),vmax=float(f.Root1m_final_mm.max()))
    lc=LineCollection(segments,cmap='viridis',norm=norm,linewidth=2.2,zorder=4);lc.set_array((f.Root1m_final_mm.to_numpy()[:-1]+f.Root1m_final_mm.to_numpy()[1:])/2);ax.add_collection(lc)
    ids=np.unique(np.linspace(0,len(f)-1,min(65,len(f)),dtype=int));v=f.iloc[ids]
    ax.scatter(v.Irrigation_mm,v.Y_13pct,c=v.Root1m_final_mm,cmap='viridis',norm=norm,s=14,zorder=5)
    cbax=fig.add_axes([.89,.17,.02,.58]);cb=fig.colorbar(lc,cax=cbax);cb.set_label('Final water storage in 0–1 m (mm)',fontsize=10.5);cb.ax.tick_params(labelsize=10)
    ax.scatter([633.47],[baseline.Y_13pct],marker='*',s=150,color=BLUE,edgecolor=DARK,lw=.6,zorder=7,clip_on=False)
    ax.scatter([633.47],[15.86],marker='s',s=50,facecolor='white',edgecolor=DARK,lw=1.2,zorder=7,clip_on=False)
    z=refs[refs.Scenario.eq('Zero_irrigation')].iloc[0];ax.scatter([0],[z.Y_13pct],s=50,facecolor='white',edgecolor=DARK,lw=1.1,zorder=7,clip_on=False)
    match=chosen[chosen.Selection.eq('Match_DI_model_yield')&chosen.Status.eq('FOUND_IN_EVALUATED_SET')]
    if len(match):
        r=match.iloc[0];ax.scatter([r.Irrigation_mm],[r.Y_13pct],s=75,facecolor='none',edgecolor=ORANGE,lw=1.6,zorder=8)
        ax.annotate(f'Match DI model yield\n{r.Irrigation_mm:.1f} mm',xy=(r.Irrigation_mm,r.Y_13pct),xytext=(18,-42),textcoords='offset points',fontsize=9,color=DARK,arrowprops=dict(arrowstyle='-',lw=.7,color=DARK))
    ax.annotate('Observed DI yield',xy=(633.47,15.86),xytext=(-8,15),textcoords='offset points',ha='right',fontsize=9)
    ax.annotate('DI model baseline',xy=(633.47,baseline.Y_13pct),xytext=(-8,-20),textcoords='offset points',ha='right',fontsize=9,color=BLUE)
    ax.set(xlim=(0,633.47),ylim=(0,max(17.5,float(f.Y_13pct.max())+1.5)),xticks=[0,100,200,300,400,500,633.47],xticklabels=['0','100','200','300','400','500','633.47'],
        xlabel='Actual seasonal irrigation (mm)',ylabel=r'Grain yield at 13% moisture (t ha$^{-1}$)');style(ax)
    handles=[Line2D([],[],color='#527C77',lw=2,label='NSGA-III best-found front'),Line2D([],[],color='#697F8B',ls='--',label='Proportional DI dose response'),
        Line2D([],[],ls='none',marker='*',ms=10,color=BLUE,label='DI model baseline'),Line2D([],[],ls='none',marker='s',mfc='white',mec=DARK,label='Observed DI yield')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.48,.94),ncol=2,frameon=False)
    fig.suptitle(r'2021 NSGA-III Pareto front | $Z_{max}$ = 1.00 m',fontsize=15,y=.995)
    fig.supxlabel('3 seeds × 100 individuals × 100 generations; fixed pilot-calibrated parameters. Finite best-found front, not field validation.',fontsize=9,y=.025)
    save(fig,'N21_01_Pareto_front','2021 NSGA-III yield–irrigation Pareto front with soil-storage audit',
        '以全部30,000次实际优化评价的非支配并集构成前沿；灰点为显示抽样，虚线为原DI同比例减灌响应。前沿颜色代表季末0—1m储水，星号与方框分开表示原DI模型和文献实测。',
        '二维目标为产量最大与实际灌水最少，颜色只是审计量，不是第三目标。前沿不强行延长到633.47mm，被支配的原DI仍保留参照。固定参数来自未正式收敛的短链；未设置产量门槛或新增储水约束。',
        ['NSGA3_best_found_front.csv','All_NSGA3_evaluations.csv.gz','Baseline_and_zero.csv','sources/Proportional_DI_response.csv'])
    fig,axs=plt.subplots(1,2,figsize=(11.3,5.6));fig.subplots_adjust(left=.075,right=.985,bottom=.14,top=.79,wspace=.23)
    axs[0].plot(f.Irrigation_mm,f.Y_13pct,color=BLUE,lw=1.9,label='Primary best-found front')
    axs[0].plot(sf.Irrigation_mm,sf.Y_13pct,color=ORANGE,lw=1.9,ls='--',label='Storage-qualified evaluated subset')
    axs[0].scatter([633.47],[baseline.Y_13pct],marker='*',s=120,color=DARK,zorder=5,clip_on=False)
    axs[0].set(xlim=(0,633.47),ylim=(0,max(17,float(f.Y_13pct.max())+1)),xlabel='Actual seasonal irrigation (mm)',ylabel=r'Grain yield (t ha$^{-1}$)',title='(a) Yield–irrigation trade-off')
    axs[1].scatter(f.Irrigation_mm,f.Root1m_final_mm,s=7,color=BLUE,alpha=.6,rasterized=True)
    axs[1].scatter(sf.Irrigation_mm,sf.Root1m_final_mm,s=8,color=ORANGE,alpha=.6,rasterized=True)
    axs[1].axhline(baseline.Root1m_final_mm,color=DARK,lw=1.2,ls='--')
    axs[1].axhline(baseline.Root1m_initial_mm,color=GREY,lw=1,ls=':')
    axs[1].text(12,baseline.Root1m_final_mm+4,f'DI final storage: {baseline.Root1m_final_mm:.2f} mm',fontsize=9,color=DARK)
    axs[1].text(12,baseline.Root1m_initial_mm+4,f'Initial storage: {baseline.Root1m_initial_mm:.2f} mm',fontsize=9,color='#6F818B')
    axs[1].set(xlim=(0,633.47),xlabel='Actual seasonal irrigation (mm)',ylabel='Final water storage in 0–1 m (mm)',title='(b) End-of-season root-domain storage')
    for ax in axs:style(ax)
    handles=[Line2D([],[],color=BLUE,lw=1.8,label='Primary front: no storage floor'),Line2D([],[],color=ORANGE,lw=1.8,ls='--',label='Evaluated subset: final storage ≥ DI baseline')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.52,.93),ncol=1,frameon=False)
    fig.suptitle('Soil-storage qualification of the evaluated candidates',fontsize=14,y=.995)
    fig.supxlabel('Orange front is post-filtered from this search; no dedicated storage-constrained optimization was run.',fontsize=9,y=.025)
    save(fig,'N21_02_Storage_qualification','Soil-storage qualification and its effect on the evaluated trade-off',
        '蓝线是未附加储水约束的主前沿；橙线从所有已评价候选中筛出季末0—1m储水不低于原DI者，再取非支配点。右图单独展示储水，避免把根层耗储当作无代价节水。',
        '原DI季末储水是同模型比较基准，允许0.01mm报告精度容差，不是新增实测阈值。橙线不是另一次带约束NSGA-III的优化结果，也不证明已充分搜索该子域；候选集合与主前沿可能不同。',
        ['NSGA3_best_found_front.csv','Storage_qualified_evaluated_subset_front.csv','Selected_front_solutions.csv'])
    h=read('Generation_history_all_seeds');fig,axs=plt.subplots(1,2,figsize=(10.6,4.9),layout='constrained')
    for seed in [31,73,109]:
        a=pd.read_csv(ROOT/'runs'/f'seed{seed}'/'all_evaluated_front.csv');b=h[h.Seed.eq(seed)]
        axs[0].plot(a.Irrigation_mm,a.Y_13pct,color=SEEDCOL[seed],lw=1.1,alpha=.8,label=f'Seed {seed}')
        axs[1].plot(b.Generation,b.Population_normalized_HV,color=SEEDCOL[seed],lw=1.4,label=f'Seed {seed}')
    axs[0].set(xlim=(0,633.47),ylim=(0,17),xlabel='Actual seasonal irrigation (mm)',ylabel=r'Grain yield (t ha$^{-1}$)',title='(a) Best-found front of each seed')
    axs[1].set(xlim=(1,100),xlabel='Generation',ylabel='Normalized population hypervolume',title='(b) Search progress')
    for ax in axs:style(ax);ax.legend(fontsize=9)
    save(fig,'N21_03_Seed_stability','Three-seed front agreement and NSGA-III search progress',
        '三个独立随机种子各运行100个体、100代；左图比较各自全部评价的非支配前沿，右图为每代当前种群的归一化超体积。',
        '种子差异不是统计置信区间；种群超体积稳定也不证明全局最优。前沿并集使用所有代记录，不只取最后一代。',
        ['Seed_stability.csv','Generation_history_all_seeds.csv','runs/seed*/all_evaluated_front.csv'])
    (ROOT/'FIGURE_REGISTRY.json').write_text(json.dumps(REG,ensure_ascii=False,indent=2));print('Created',len(REG),'English figure groups')

if __name__=='__main__':main()
