"""Verify historical runtime setting, new field settings and exact numerical kernels."""
import json,sys,hashlib
import numpy as np
import pandas as pd
from scenario_engine import ROOT,PROJECT,SOURCE,SCENARIOS,load,Engine,dump

def main():
    rows=[];historical=json.loads((ROOT/'sources/Historical_f0_parameters.json').read_text())
    for name,f in [('historical_f0',0.),*SCENARIOS.items()]:
        driver,m,data,start=load(f,False,'preflight_'+name)
        profile=data['soil'].profile.copy();profile['Initial_theta']=data['theta']
        if name=='historical_f0':profile.to_csv(ROOT/'sources/Frozen_soil_initial_water.csv',index=False);data['field'].to_csv(ROOT/'sources/Field_CC_2021.csv',index=False);data['bio'].to_csv(ROOT/'sources/Biomass_2021.csv',index=False)
        ref=m.simulate(data,historical)
        fm=m.field_management();assert fm.mulch_pct==75 and fm.f_mulch==f
        rows.append(dict(Scenario=name,fMulch=f,MulchPct=fm.mulch_pct,Potential_Es_multiplier=1-f*.75,
            Y13=ref[0]['Y_13pct'],Es_mm=ref[0]['Es_mm'],ET_mm=ref[0]['ET_mm'],Scope='historical fitted parameters fixed; NOT new calibration'))
    # Unaccelerated comparisons were computed before installing our exact kernels.
    sys.path.insert(0,str(PROJECT/'real_model'));import numerical_acceleration;numerical_acceleration.install()
    differences=[]
    for name,f in SCENARIOS.items():
        _,m,data,start=load(f,True,'accelerated_'+name);s=m.simulate(data,historical)[0]
        rr=next(x for x in rows if x['Scenario']==name);d=max(abs(rr['Y13']-s['Y_13pct']),abs(rr['Es_mm']-s['Es_mm']),abs(rr['ET_mm']-s['ET_mm']));assert d<1e-8
        differences.append(dict(Scenario=name,Maximum_difference=d))
    pd.DataFrame(rows).to_csv(ROOT/'tables/Fixed_parameter_fMulch_profile.csv',index=False)
    dump(ROOT/'verification/PREFLIGHT.json',dict(Status='PASS',Historical_cloud_fMulch=0.,Requested_scenarios=SCENARIOS,Original_source_SHA256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        Kernels_checked=differences,Zmax_m=1.,Root_and_texture_changes=False,Management='MulchPct75; WetSurf100; AppEff100; original dates and initial water',
        Formula='EsPotMul=EsPot*(1-fMulch*MulchPct/100) when mulch applies; ponding bypass and min with irrigation-wetted potential retained',
        Parent_MCMC_was_not_fMulch0p85=True,External_2022_table_not_treated_as_2021_results=True))
    print(pd.DataFrame(rows).to_string(index=False),flush=True)

if __name__=='__main__':main()
