"""Compare evaluated fronts at shared absolute yield targets, with soil stocks."""
import json
import numpy as np
import pandas as pd
from scenario_engine import ROOT,SCENARIOS,Engine,dump
from run_optimizations import front,SEEDS,POP,GEN
T=ROOT/'tables'

def main():
    status=json.loads((ROOT/'verification/OPTIMIZATION_STATUS.json').read_text());assert status['State']=='COMPLETE'
    fit=pd.read_csv(T/'Calibrated_DI_fit_summary.csv');reference085=float(fit.loc[fit.Scenario.eq('fm085'),'Y_13pct'].iloc[0])
    historical=15.1521563445;allfronts=[];stockfronts=[];chosen=[];stability=[];history=[];summary=[];events=[];cross=[];selection_controls=[];baselines=[]
    for sc,fmulch in SCENARIOS.items():
        e=Engine(sc,True,tag='aggregate');e.install()
        try:
            base=e.run(e.base);baselines.append({k:v for k,v in base.items() if k!='irrigation_events'});zero=e.run(e.base*0);frames=[]
            for seed in SEEDS:
                folder=ROOT/'optimization'/sc/f'seed{seed}';a=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip');assert len(a)==POP*GEN
                assert a.G_seasonal_cap.max()<=0 and a.Max_daily_balance_residual_mm.max()<1e-7
                a['Candidate_ID']=[f'{sc}_s{seed}_e{int(i):05d}' for i in a.Evaluation];frames.append(a)
                sf=front(a);q=sf[sf.Y_13pct>=base['Y_13pct']-1e-9]
                stability.append(dict(Scenario=sc,fMulch=fmulch,Seed=seed,Maximum_found_Y13=sf.Y_13pct.max(),Minimum_I_for_own_DI_mm=q.Irrigation_mm.min() if len(q) else None))
                h=pd.read_csv(folder/'history.csv');h['Scenario']=sc;history.append(h)
            a=pd.concat(frames,ignore_index=True);a.to_csv(T/f'{sc}_All_optimization_evaluations.csv.gz',index=False,compression='gzip')
            ff=front(a);allfronts.append(ff);ff.to_csv(T/f'{sc}_NSGA3_front.csv',index=False)
            floor=base['Root1m_final_mm'];qualified=a[a.Root1m_final_mm>=floor-.01];sq=front(qualified);stockfronts.append(sq)
            def add(label,row,target=None,scope='two-objective best-found front'):
                out=dict(Scenario=sc,fMulch=fmulch,Selection=label,Target_Y13=target,Scope=scope,Status='NOT_FOUND_IN_SEARCH')
                if row is not None:
                    out.update(row.to_dict());out.update(Selection=label,Target_Y13=target,Scope=scope,Status='FOUND_IN_EVALUATED_SET',Irrigation_reduction_pct=100*(1-row.Irrigation_mm/e.cap),Yield_bias_vs_observed_pct=100*(row.Y_13pct/15.86-1),Extra_root_depletion_vs_own_DI_mm=floor-row.Root1m_final_mm)
                    selection_controls.append(dict(Source_scenario=sc,Selection=label,Candidate_ID=row.Candidate_ID,**{k:float(row[k]) for k in e.space['names']}))
                chosen.append(out)
            add('Maximum_found_yield',ff.loc[ff.Y_13pct.idxmax()])
            targets=[('Match_own_DI_model',base['Y_13pct']),('At_least_95pct_observed',.95*15.86),('Match_observed',15.86),('Match_historical_f0_DI',historical),('Match_recalibrated_f085_DI',reference085)]
            for label,target in targets:
                q=ff[ff.Y_13pct>=target-1e-9];add(label,q.iloc[0] if len(q) else None,target)
            q=sq[sq.Y_13pct>=base['Y_13pct']-1e-9];add('Storage_qualified_match_own_DI',q.iloc[0] if len(q) else None,base['Y_13pct'],scope='post-filtered evaluated subset; NOT dedicated constrained optimization')
            summary.append(dict(Scenario=sc,fMulch=fmulch,DI_Y13=base['Y_13pct'],Zero_Y13=zero['Y_13pct'],DI_Es_mm=base['Es_mm'],DI_ET_mm=base['ET_mm'],DI_Tr_mm=base['Tr_mm'],DI_root_final_mm=floor,Evaluations=len(a),Front_points=len(ff),Maximum_found_Y13=ff.Y_13pct.max(),Storage_qualified_evaluations=len(qualified),Storage_qualified_front_points=len(sq)))
        finally:e.restore()
    pd.concat(allfronts,ignore_index=True).to_csv(T/'All_scenario_NSGA3_fronts.csv',index=False);pd.concat(stockfronts,ignore_index=True).to_csv(T/'All_storage_qualified_subset_fronts.csv',index=False)
    pd.DataFrame(chosen).to_csv(T/'Selected_front_comparisons.csv',index=False);pd.DataFrame(stability).to_csv(T/'Seed_stability.csv',index=False);pd.concat(history,ignore_index=True).to_csv(T/'All_generation_history.csv',index=False)
    pd.DataFrame(summary).to_csv(T/'Optimization_scenario_summary.csv',index=False)
    pd.DataFrame(baselines).to_csv(T/'All_DI_storage_baselines.csv',index=False)
    partition=[];exact=pd.read_csv(T/'Exact_300_350_400_response_checks.csv')
    for sc in SCENARIOS:
        di=exact[exact.Scenario.eq(sc)&exact.Requested_mm.eq(633.47)].iloc[0];low=exact[exact.Scenario.eq(sc)&exact.Requested_mm.eq(400)].iloc[0]
        row=dict(Scenario=sc,fMulch=SCENARIOS[sc],Applied_irrigation_reduction_mm=di.Irrigation_mm-low.Irrigation_mm)
        for out,key in [('ET_reduction_mm','ET_mm'),('Root_final_storage_difference_mm','Root1m_final_mm'),('Below_root_final_storage_difference_mm','Below1m_final_mm'),('Deep_drainage_reduction_mm','DeepPerc_mm'),('Runoff_reduction_mm','Runoff_mm'),('Surface_storage_difference_mm','Surface_final_mm')]:row[out]=di[key]-low[key]
        row['Closure_residual_mm']=row['Applied_irrigation_reduction_mm']-sum(row[k] for k in ['ET_reduction_mm','Root_final_storage_difference_mm','Below_root_final_storage_difference_mm','Deep_drainage_reduction_mm','Runoff_reduction_mm','Surface_storage_difference_mm']);assert abs(row['Closure_residual_mm'])<1e-7;partition.append(row)
    pd.DataFrame(partition).to_csv(T/'Irrigation_reduction_partition_400mm.csv',index=False)
    # Cross-evaluate controls at all three conditionally recalibrated structures.
    for amount in [0,300,350,400,475.1025,633.47]:
        selection_controls.append(dict(Source_scenario='common_proportional',Selection=f'I{amount:g}',Candidate_ID=f'proportional_{amount:g}',**dict(zip(e.space['names'],e.base*(amount/e.cap)))))
    controls=pd.DataFrame(selection_controls);controls.to_csv(T/'Cross_scenario_control_definitions.csv',index=False)
    for sc in SCENARIOS:
        e=Engine(sc,True,tag='crosscheck');e.install()
        try:
            for _,c in controls.iterrows():
                x=c[e.space['names']].to_numpy(float);s=e.run(x)
                cross.append(dict(Source_scenario=c.Source_scenario,Selection=c.Selection,Source_candidate_ID=c.Candidate_ID,Evaluation_scenario=sc,**{k:v for k,v in s.items() if k!='irrigation_events'}))
                if c.Source_scenario==sc:
                    for ev in s['irrigation_events']:events.append(dict(Scenario=sc,Selection=c.Selection,Date=ev['date'],Window=ev['stage']+1,Amount_mm=ev['mm']))
        finally:e.restore()
    cross=pd.DataFrame(cross);cross.to_csv(T/'Cross_scenario_candidate_replays.csv',index=False);pd.DataFrame(events).to_csv(T/'Selected_event_schedules.csv',index=False)
    robust=cross.groupby(['Source_scenario','Selection','Source_candidate_ID'],sort=False).agg(Worst_case_Y13=('Y_13pct','min'),Best_case_Y13=('Y_13pct','max'),Minimum_actual_irrigation_mm=('Irrigation_mm','min'),Maximum_actual_irrigation_mm=('Irrigation_mm','max'),Minimum_final_root_storage_mm=('Root1m_final_mm','min'),Maximum_final_root_storage_mm=('Root1m_final_mm','max')).reset_index()
    robust['All_scenarios_meet_95pct_observed']=robust.Worst_case_Y13>=.95*15.86-1e-9;robust['Scope']='cross-check of finite selected controls; NOT a dedicated robust optimization'
    robust.to_csv(T/'Cross_scenario_worst_case_summary.csv',index=False)
    dump(ROOT/'RESULT_SUMMARY.json',dict(Year=2021,Structures=SCENARIOS,Recorded_MCMC_states=120000,MCMC_formally_converged=False,Actual_optimization_evaluations=90000,Observed_Y13=15.86,Observed_irrigation_mm=633.47,Common_targets=['observed15.86','95pct_observed15.067','historicalf0DI15.1521563445','newf085DI'],Fixed_parameters_per_optimization=True,Posterior_uncertainty_propagated=False,Soil_storage_floor_enforced_in_search=False,Target_irrigation_fitted=False,Results=summary))
    from optimized_audit import main as audit_optimized
    audit_optimized()
    print('AGGREGATION COMPLETE',flush=True)
if __name__=='__main__':main()
