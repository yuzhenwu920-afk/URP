"""Separate pure fMulch effects from conditional parameter compensation."""
import json
import pandas as pd
from scenario_engine import ROOT,SCENARIOS,Engine
T=ROOT/'tables'
def main():
    rows=[]
    for parameter_source in SCENARIOS:
        p=json.loads((ROOT/'calibration'/parameter_source/'SELECTED_PARAMETERS.json').read_text())
        for structure in SCENARIOS:
            e=Engine(structure,True,params=p,tag='factorial_'+parameter_source);e.install()
            try:
                for amount in [0,350,400,633.47]:
                    s=e.run(e.base*amount/633.47);rows.append(dict(Parameter_source=parameter_source,Structure=structure,Requested_mm=amount,**{k:v for k,v in s.items() if k!='irrigation_events'}))
            finally:e.restore()
    pd.DataFrame(rows).to_csv(T/'Factorial_parameter_structure_check.csv',index=False)
    print('FACTORIAL CHECKS COMPLETE',flush=True)
if __name__=='__main__':main()
