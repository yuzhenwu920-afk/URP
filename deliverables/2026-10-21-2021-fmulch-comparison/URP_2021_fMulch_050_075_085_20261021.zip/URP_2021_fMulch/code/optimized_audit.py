"""Daily stress and calendar-window ledgers for selected optimized controls."""
import pandas as pd
import numpy as np
from scenario_engine import ROOT,SCENARIOS
from trace_scenarios import TraceEngine
T=ROOT/'tables'
def main():
    selected=pd.read_csv(T/'Selected_front_comparisons.csv',float_precision='round_trip');rows=[];labels=[]
    for sc in SCENARIOS:
        e=TraceEngine(sc,True,tag='optimized_trace')
        for kind,label in [('At_least_95pct_observed','Opt95'),('Match_own_DI_model','OptOwnDI')]:
            q=selected[selected.Scenario.eq(sc)&selected.Selection.eq(kind)&selected.Status.eq('FOUND_IN_EVALUATED_SET')]
            if not len(q):continue
            r=q.iloc[0];x=r[e.space['names']].to_numpy(float);name=sc+'_'+label;s=e.trace(name,float(x.sum()),controls=x)
            assert abs(s['Y_13pct']-r.Y_13pct)<1e-8 and abs(s['Irrigation_mm']-r.Irrigation_mm)<1e-8
            s.update(Mulch_scenario=sc,fMulch=SCENARIOS[sc],Selection=kind,Control_type='optimized');rows.append(s);labels.append((sc,name,'optimized_'+label))
            if label=='Opt95':
                name=sc+'_PropSameOpt95';s=e.trace(name,float(r.Irrigation_mm));assert abs(s['Irrigation_mm']-r.Irrigation_mm)<1e-8
                s.update(Mulch_scenario=sc,fMulch=SCENARIOS[sc],Selection='Same_amount_as_Opt95',Control_type='proportional');rows.append(s);labels.append((sc,name,'proportional_same_Opt95_amount'))
    pd.DataFrame(rows).to_csv(T/'Optimized_candidate_stress_summaries.csv',index=False)
    labels +=[(sc,sc+'_'+dose,dose) for sc in SCENARIOS for dose in ['I000','I050','I400','I075','I100']]
    ledger=[];bounds=pd.to_datetime(['2021-04-27','2021-07-01','2021-07-21','2021-08-12','2021-09-22'])
    for sc,name,control in labels:
        d=pd.read_csv(T/(name+'_daily.csv'));date=pd.to_datetime(d.Date)
        for j,(start,end) in enumerate(zip(bounds[:-1],bounds[1:]),1):
            a=d[(date>=start)&(date<end)];active=a[a.Tr_potential_actual_canopy_mm>1e-8]
            row=dict(Scenario=sc,fMulch=SCENARIOS[sc],Control=control,Accounting_window=j,Start=start.strftime('%Y-%m-%d'),End_exclusive=end.strftime('%Y-%m-%d'),Days=len(a),Mean_CC=a.CC.mean(),Mean_stomatal_Ks=active.Ks_sto_linear_computed.mean(),Stomatal_equivalent_stress_days=(1-active.Ks_sto_linear_computed).sum(),Root_initial_mm=a.Root1m_start_mm.iloc[0],Root_final_mm=a.Root1m_end_mm.iloc[-1],Below_root_initial_mm=a.Below1m_start_mm.iloc[0],Below_root_final_mm=a.Below1m_end_mm.iloc[-1],Definition='calendar accounting windows linked to fixed event groups; NOT inferred phenological stages')
            for out,col in [('Irrigation_mm','IrrDay'),('Rain_mm','Rain_mm'),('Tr_mm','Tr'),('Es_mm','Es'),('ET_mm','ET_mm'),('Runoff_mm','Runoff'),('DeepPerc_mm','DeepPerc'),('Root_storage_change_mm','DeltaS_root1m_mm'),('Below_root_storage_change_mm','DeltaS_below1m_mm'),('Net_downward_flux_at_1m_mm','Net_downward_flux_1m_balance_derived_mm')]:row[out]=a[col].sum()
            ledger.append(row)
    pd.DataFrame(ledger).to_csv(T/'Calendar_window_water_stress_ledger.csv',index=False)
    print('OPTIMIZED DAILY AND WINDOW AUDIT COMPLETE',flush=True)
if __name__=='__main__':main()
