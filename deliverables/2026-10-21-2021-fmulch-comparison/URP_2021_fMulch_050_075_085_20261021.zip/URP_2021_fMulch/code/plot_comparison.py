"""Publication-quality English figures with actual numerical sources."""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.lines import Line2D
from scenario_engine import ROOT,SCENARIOS
T=ROOT/'tables';F=ROOT/'figures';REG=[]
COL={'fm050':'#0072B2','fm075':'#D55E00','fm085':'#009E73'}
LS={'fm050':'-','fm075':'--','fm085':'-.'}
LABEL={k:rf'$f_{{Mulch}}={v:.2f}$' for k,v in SCENARIOS.items()}
DOSES=['I000','I050','I400','I075','I100']
DC={'I000':'#77858C','I050':'#0072B2','I400':'#D55E00','I075':'#009E73','I100':'#7A5195'}
DL={'I000':':','I050':'-','I400':'-','I075':'--','I100':'-.'}
DN={'I000':'0 mm','I050':'316.74 mm (50% DI)','I400':'400.00 mm','I075':'475.10 mm (75% DI)','I100':'633.47 mm (DI)'}
def read(n):return pd.read_csv(T/(n+'.csv'))
def style(ax,date=False):
    ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.15,zorder=0)
    if date:
        ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));ax.set_xlim(pd.Timestamp('2021-04-27'),pd.Timestamp('2021-09-23'))
def save(fig,name,title,analysis,boundary,sources):
    for ext in ['png','pdf','svg']:fig.savefig(F/(name+'.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig);REG.append(dict(ID=name,Title=title,Analysis_CN=analysis,Boundary_CN=boundary,Source_tables=sources))
def handles():return [Line2D([],[],color=COL[k],ls=LS[k],lw=2,label=LABEL[k]) for k in SCENARIOS]
def header(fig,title,hs,ncol=3):
    fig.suptitle(title,fontsize=14,y=.995);fig.legend(handles=hs,loc='upper center',bbox_to_anchor=(.53,.947),ncol=ncol,frameon=False)
def stress_values(d):
    tadj=d.DAP-d.Delayed_days;masks=[(tadj>=d.Emergence_dap)&(tadj<d.CanopyDevEnd_dap)&(~d.Protected_seed_before)&(d.CC>1e-8),d.Tr_potential_actual_canopy_mm>1e-8,(d.CC>1e-8)&(~d.Protected_seed_before)]
    return [d[c].where(m) for c,m in zip(['Ks_exp_computed','Ks_sto_linear_computed','Ks_sen_computed'],masks)]+[d.CC]

def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':10,'pdf.fonttype':42,'svg.fonttype':'none'})
    fit=read('Calibrated_DI_fit_summary');curve=read('All_proportional_responses');fronts=read('All_scenario_NSGA3_fronts');sel=read('Selected_front_comparisons');summary=read('All_stress_storage_summaries')
    profile=pd.read_csv(ROOT/'sources/Frozen_soil_initial_water.csv');weights=np.clip(1-profile.z_top,0,profile.dz)*1000
    fc=float(np.dot(profile.th_fc,weights));wp=float(np.dot(profile.th_wp,weights))
    # Observations only at DI; no observational deficit-yield points are invented.
    fig,axs=plt.subplots(1,2,figsize=(11.2,4.9));fig.subplots_adjust(left=.08,right=.985,bottom=.14,top=.77,wspace=.24)
    for sc in SCENARIOS:
        cc=read(sc+'_CC_pairs');bio=read(sc+'_Biomass_pairs');g=read(sc+'_DI_growth');date=pd.to_datetime(g.Date) if 'Date' in g else pd.date_range('2021-04-27',periods=len(g))
        axs[0].plot(date,g.canopy_cover,color=COL[sc],ls=LS[sc],lw=1.8)
        axs[1].plot(date,g.biomass/100,color=COL[sc],ls=LS[sc],lw=1.8)
    axs[0].scatter(pd.to_datetime(cc.Date),cc.Observed_CC,s=26,facecolors='white',edgecolors='#263D48',zorder=6)
    axs[1].scatter(pd.to_datetime(bio.Date),bio.Observed_B_t_ha,s=26,facecolors='white',edgecolors='#263D48',zorder=6)
    for ax in axs:style(ax,True);ax.set_xlabel('Date in 2021')
    axs[0].set(ylabel='Canopy cover (fraction)',ylim=(0,1.05),title='(a) Canopy cover under the original DI schedule')
    axs[1].set(ylabel=r'Aboveground biomass (t ha$^{-1}$)',title='(b) Aboveground biomass under the original DI schedule')
    for j,sc in enumerate(SCENARIOS):
        r=fit[fit.Scenario.eq(sc)].iloc[0]
        axs[0].text(.03,.94-j*.075,f'fMulch={SCENARIOS[sc]:.2f}: RMSE={r.CC_RMSE:.4f}; R²={r.CC_fit_R2:.3f}',transform=axs[0].transAxes,color=COL[sc],fontsize=9)
        axs[1].text(.03,.94-j*.075,f'fMulch={SCENARIOS[sc]:.2f}: RMSE={r.Bio_RMSE:.2f} t/ha',transform=axs[1].transAxes,color=COL[sc],fontsize=9)
    header(fig,'2021 conditional recalibration | maximum root depth 1.00 m',handles()+[Line2D([],[],marker='o',mfc='white',mec='#263D48',ls='none',label='DI calibration data')],4)
    save(fig,'F01_DI_canopy_biomass_fits','Canopy and biomass fits after conditional recalibration','三种fMulch分别重校准两阶段参数。比较冠层与生物量的残差，同时查看产量偏差；不能仅因产量接近而判定物理结构正确。','圆点是原DI校准数据，生物量与部分CC来自原项目数字化或换算；这是条件拟合，不是独立验证。',['fm*_CC_pairs.csv','fm*_Biomass_pairs.csv','fm*_DI_growth.csv','Calibration_fit_metrics.csv'])
    fig,axs=plt.subplots(2,2,figsize=(9.8,7.2));fig.subplots_adjust(left=.10,right=.985,bottom=.09,top=.84,hspace=.38,wspace=.25)
    for ax,(var,target,ylabel,title) in zip(axs.ravel(),[('Y_13pct',15.86,r'Grain yield at 13% moisture (t ha$^{-1}$)','(a) Grain yield'),('Es_mm',78.,'Seasonal soil evaporation (mm)','(b) Soil evaporation'),('Tr_mm',548.81,'Seasonal transpiration (mm)','(c) Transpiration'),('ET_mm',626.81,'Seasonal evapotranspiration (mm)','(d) Evapotranspiration')]):
        vals=[float(fit.loc[fit.Scenario.eq(sc),var].iloc[0]) for sc in SCENARIOS];ax.bar(range(3),vals,color=list(COL.values()),width=.57)
        ax.axhline(target,color='#745A50',ls=':',lw=1.4,label='Original calibration target')
        ax.set_xticks(range(3),[f'{v:.2f}' for v in SCENARIOS.values()]);ax.set(xlabel=r'$f_{Mulch}$',ylabel=ylabel,title=title);style(ax)
        ax.set_ylim(0,max(max(vals),target)*1.18)
        for j,v in enumerate(vals):ax.text(j,v+max(max(vals),target)*.025,f'{v:.2f}',ha='center',fontsize=10)
    fig.suptitle('2021 DI fit comparison after two-stage 500-step recalibration',fontsize=14,y=.985)
    fig.text(.53,.915,'Dotted lines: original targets; Es and Tr partition includes reconstructed information.',ha='center',fontsize=9)
    save(fig,'F02_DI_yield_Es_Tr_ET','DI yield and seasonal water-flux fits','充分灌溉下产量可能接近，但Es、Tr、ET未必同时接近原目标；用共同目标和相同误差权重比较，而非挑选节水幅度符合预期的情景。','Es=78mm是原项目近似重建的校准目标，Tr由ET减Es得到，并非新增加的独立实测。不同目标并不相互独立。',['Calibrated_DI_fit_summary.csv','Descriptive_fit_residual_scores.csv'])
    # Theme 1: full proportional dose-response, no optimization envelope substituted.
    fig,ax=plt.subplots(figsize=(9.6,5.7));fig.subplots_adjust(left=.105,right=.98,bottom=.14,top=.78)
    hs=handles()
    for sc in SCENARIOS:
        d=curve[curve.Scenario.eq(sc)];ax.plot(d.Irrigation_mm,d.Y_13pct,color=COL[sc],ls=LS[sc],lw=2);ax.scatter(d.Irrigation_mm.iloc[0],d.Y_13pct.iloc[0],s=40,facecolor='white',edgecolor=COL[sc],zorder=6);ax.scatter(633.47,d.Y_13pct.iloc[-1],marker='*',s=105,color=COL[sc],zorder=6)
    old=pd.read_csv(ROOT/'sources/Historical_f0_proportional_response.csv');ax.plot(old.Irrigation_mm,old.Y_13pct,color='#9AA5AA',ls=':',lw=1.4);hs.append(Line2D([],[],color='#9AA5AA',ls=':',label='Historical fMulch=0 pilot'))
    ax.axhline(15.86,color='#6B4D40',ls='--',lw=1.1);hs.append(Line2D([],[],color='#6B4D40',ls='--',label='Observed DI yield'))
    ax.set(xlim=(0,650),ylim=(0,17.1),xlabel='Actual seasonal irrigation (mm)',ylabel=r'Grain yield at 13% moisture (t ha$^{-1}$)');style(ax)
    ax.set_xticks([0,100,200,300,400,500,633.47],['0','100','200','300','400','500','633.47'])
    header(fig,'2021 yield–irrigation response | three recalibrated mulch structures',hs,3)
    fig.text(.52,.025,'Root depth 1.00 m; original dates and proportions retained; open circles: zero irrigation; stars: DI model baselines.',ha='center',fontsize=8.7)
    save(fig,'T01_Yield_irrigation_comparison','Proportional irrigation responses across three mulch structures','每条线用该地膜情景各自重校准的参数，按原DI日程比例缩放灌水；比较0、300、350、400及633.47mm的产量与储水，不强制曲线在400mm转折。','这些是单个短链选定参数的剂量响应，既非优化前沿，也没有传播参数后验不确定性；零灌溉允许降雨和初始储水。历史f0只作旧结果对照。',['All_proportional_responses.csv','Exact_300_350_400_response_checks.csv','Historical_f0_proportional_response.csv'])
    # Pilot parameter walls and convergence are visible, not concealed by fit quality.
    d=read('All_MCMC_parameter_diagnostics');names=d.Parameter.drop_duplicates().tolist();fig,axs=plt.subplots(2,1,figsize=(10.3,8.3));fig.subplots_adjust(left=.09,right=.985,bottom=.15,top=.82,hspace=.60)
    for j,sc in enumerate(SCENARIOS):
        q=d[d.Scenario.eq(sc)].set_index('Parameter').loc[names];den=q.Prior_high-q.Prior_low;x=np.arange(len(q))+(j-1)*.19
        y=(q.Selected-q.Prior_low)/den;lo=(q.Q025-q.Prior_low)/den;hi=(q.Q975-q.Prior_low)/den
        axs[0].vlines(x,lo,hi,color=COL[sc],lw=2,alpha=.65);axs[0].scatter(x,y,color=COL[sc],s=28,zorder=4)
        axs[1].plot(x,q.Rhat_max,'o',color=COL[sc],ms=4)
    axs[0].axhspan(0,.01,color='#D55E00',alpha=.13);axs[0].axhspan(.99,1,color='#D55E00',alpha=.13);axs[0].set(ylabel='Fraction of original prior range',ylim=(-.03,1.04),title='(a) Selected point and retained short-pilot 2.5–97.5% interval')
    axs[1].axhline(1.01,color='#745A50',ls=':',lw=1.2);axs[1].set(ylabel=r'Maximum split rank $\hat{R}$',title='(b) Mixing across independent ensembles (same walker index)')
    for ax in axs:ax.set_xticks(range(len(names)),names,rotation=25,ha='right');style(ax)
    header(fig,'2021 MCMC diagnostics | 500 steps × 10 walkers × 4 ensembles per phase',handles())
    fig.text(.53,.025,'Short-pilot intervals are not a converged posterior. Dots in panel (a): highest sampled log posterior after step 250.',ha='center',fontsize=8.8)
    save(fig,'F03_MCMC_walls_and_mixing','Parameter bounds and short-chain mixing diagnostics','检查选定点距先验上下界、边界附近样本占比、Rhat和ESS。拟合良好并不代表参数可辨识；WP或HI0贴边时应优先复核先验与模型结构。','500步仅为用户指定的调试试验。保留段分位数不是收敛后验区间，正式原流程最少2000步等门槛未通过，不可把12万保存状态称为独立有效样本。',['All_MCMC_parameter_diagnostics.csv','calibration/*/*/Pilot_arrays.npz'])
    # Theme 2 and storage, five actual amounts in each calibrated structure.
    for sc,fm in SCENARIOS.items():
        daily={dose:read(sc+'_'+dose+'_daily') for dose in DOSES}
        fig,axs=plt.subplots(2,2,figsize=(11.6,8.0),sharex=True);fig.subplots_adjust(left=.085,right=.985,bottom=.115,top=.80,hspace=.23,wspace=.23)
        for dose,d in daily.items():
            for ax,y in zip(axs.ravel(),stress_values(d)):ax.plot(pd.to_datetime(d.Date),y,color=DC[dose],ls=DL[dose],lw=1.65)
        cc=read(sc+'_CC_pairs');axs[1,1].scatter(pd.to_datetime(cc.Date),cc.Observed_CC,s=24,facecolor='white',edgecolor='#263D48',zorder=6)
        for i,(ax,title) in enumerate(zip(axs.ravel(),['(a) Canopy-expansion coefficient','(b) Stomatal coefficient (linear, used for Tr)','(c) Drought-senescence coefficient','(d) Simulated canopy cover'])):
            ax.set(title=title,ylabel=r'Water-stress coefficient $K_s$' if i<3 else 'Canopy cover (fraction)',ylim=(-.035,1.065),yticks=[0,.25,.5,.75,1]);style(ax,True)
        for ax in axs[1]:ax.set_xlabel('Date in 2021')
        hs=[Line2D([],[],color=DC[s],ls=DL[s],lw=2,label=DN[s]) for s in DOSES]+[Line2D([],[],ls='none',marker='o',mfc='white',mec='#263D48',label='Observed DI CC (panel d)')]
        header(fig,rf'2021 water stress | $f_{{Mulch}}={fm:.2f}$, maximum root depth 1.00 m',hs,3)
        fig.text(.53,.025,r'$K_s=1$: no drought limitation; lower $K_s$: stronger limitation. Missing process windows remain blank.',ha='center',fontsize=9)
        save(fig,'T02_'+sc+'_Water_stress_canopy',f'Water-stress and canopy responses, fMulch={fm:.2f}','前三面板分别追溯扩展、气孔、衰老的缺水限制，第四面板显示CC。重点查看316.74与400mm是否在关键时期维持蒸腾以及冠层。','显示实际函数调用；气孔使用本版本实际作用于Tr的sto_lin。按过程适用时间掩膜，断线不填成1。DI观测圆点仅对应633.47mm，不能直接验证缺水情景。',[sc+'_I*_daily.csv',sc+'_I*_stress_function_calls.csv','All_stress_storage_summaries.csv'])
        fig,axs=plt.subplots(2,1,figsize=(10.2,7.4),sharex=True);fig.subplots_adjust(left=.105,right=.985,bottom=.12,top=.80,hspace=.25)
        for dose,d in daily.items():
            dates=pd.DatetimeIndex([pd.Timestamp(d.Storage_time_start.iloc[0])]+pd.to_datetime(d.Storage_time_end).tolist());top=np.r_[d.Root1m_start_mm.iloc[0],d.Root1m_end_mm];deep=np.r_[d.Below1m_start_mm.iloc[0],d.Below1m_end_mm]-d.Below1m_start_mm.iloc[0]
            axs[0].plot(dates,top,color=DC[dose],ls=DL[dose],lw=1.75);axs[1].plot(dates,deep,color=DC[dose],ls=DL[dose],lw=1.75)
        for val,label,line in [(fc,f'Model FC: {fc:.1f} mm','--'),(wp,f'Model WP: {wp:.1f} mm',':')]:axs[0].axhline(val,color='#697B85',ls=line,lw=1);axs[0].text(pd.Timestamp('2021-09-20'),val+4,label,ha='right',fontsize=9)
        axs[0].set(ylabel='Water storage in 0–1 m (mm)',title='(a) Fixed root-domain storage');axs[1].set(ylabel='Storage change in 1–2.4 m (mm)',xlabel='Date in 2021',title='(b) Storage below the maximum root depth, relative to planting')
        for ax in axs:style(ax,True)
        header(fig,rf'2021 soil-water storage | $f_{{Mulch}}={fm:.2f}$',hs[:5],3)
        fig.text(.53,.025,'Fixed 0–1 m storage is not fully accessible to growing roots from planting. FC/WP and the initial state are model inputs.',ha='center',fontsize=8.7)
        save(fig,'S01_'+sc+'_Soil_water_storage',f'Root and deep soil storage, fMulch={fm:.2f}','把根区储水与根区以下储水分开，检查少灌是否靠多消耗土壤水维持产量。季末储水差异是一次性节水与持续管理方案区别的重要依据。','水力剖面仍为原2.4m；根系最大1m，1m以下没有直接根系吸水。初始含水率来自原近似重建，未经新增独立校正。',[sc+'_I*_daily.csv','All_stress_storage_summaries.csv'])
    # Theme 3: finite actual-evaluation fronts; no smoothed or interpolated optimum.
    for key in ['all']+list(SCENARIOS):
        fig,ax=plt.subplots(figsize=(10,6));fig.subplots_adjust(left=.105,right=.98,bottom=.14,top=.78);hs=[]
        cases=list(SCENARIOS) if key=='all' else [key]
        for sc in cases:
            q=fronts[fronts.Scenario.eq(sc)];a=curve[curve.Scenario.eq(sc)];ax.plot(q.Irrigation_mm,q.Y_13pct,color=COL[sc],lw=2,label=LABEL[sc]);ax.plot(a.Irrigation_mm,a.Y_13pct,color=COL[sc],ls=':',lw=1,alpha=.75);hs.append(Line2D([],[],color=COL[sc],lw=2,label=LABEL[sc]+' NSGA-III'));ax.scatter(633.47,a.Y_13pct.iloc[-1],color=COL[sc],marker='*',s=110,zorder=6)
            match=sel[(sel.Scenario.eq(sc))&(sel.Selection.eq('At_least_95pct_observed'))&(sel.Status.eq('FOUND_IN_EVALUATED_SET'))]
            if len(match):r=match.iloc[0];ax.scatter(r.Irrigation_mm,r.Y_13pct,s=55,facecolor='white',edgecolor=COL[sc],lw=1.7,zorder=7)
        ax.axhline(15.86,color='#514C48',ls='--',lw=1);ax.axhline(.95*15.86,color='#AB7665',ls=':',lw=1)
        hs.extend([Line2D([],[],color='#514C48',ls='--',label='Observed DI yield'),Line2D([],[],color='#AB7665',ls=':',label='95% observed yield (reference)'),Line2D([],[],color='#7B8990',ls=':',label='Proportional dose response')])
        ax.set(xlim=(0,650),ylim=(0,17.1),xlabel='Actual seasonal irrigation (mm)',ylabel=r'Grain yield at 13% moisture (t ha$^{-1}$)');style(ax)
        ax.set_xticks([0,100,200,300,400,500,633.47],['0','100','200','300','400','500','633.47'])
        header(fig,'2021 NSGA-III | root depth 1.00 m | '+('mulch-structure comparison' if key=='all' else f'fMulch={SCENARIOS[key]:.2f}'),hs,3)
        fig.text(.53,.025,'Each structure: 3 seeds × 100 individuals × 100 generations; fixed pilot parameters. Stars: own DI model baselines.',ha='center',fontsize=8.7)
        save(fig,'T03_'+key+'_NSGA3_front','NSGA-III best-found yield–irrigation front, '+key,'实线来自实际评估候选的非支配集合，点虚线是原比例日程。用共同的实测产量和95%实测产量参照比较，另报告各情景自己的DI基线，避免因基线变差而显得更省水。','两个目标：产量最大化、实际季灌水最小化；四个固定时间窗分配量。无强制400mm下界、无产量门槛、未加入季末储水约束。有限搜索不是已证明的全局最优，也不是田间验证。',['All_scenario_NSGA3_fronts.csv','Selected_front_comparisons.csv','All_proportional_responses.csv'])
    # Fix irrigation at400 to isolate structure+conditional calibration response.
    fig,axs=plt.subplots(2,2,figsize=(11,7.5),sharex=True);fig.subplots_adjust(left=.09,right=.985,bottom=.12,top=.82,hspace=.26,wspace=.24)
    for sc in SCENARIOS:
        d=read(sc+'_I400_daily');values=stress_values(d);date=pd.to_datetime(d.Date)
        for ax,y in zip(axs.ravel(),[values[0],values[1],values[3],d.Root1m_end_mm]):ax.plot(date,y,color=COL[sc],ls=LS[sc],lw=1.7)
    for i,(ax,title,ylabel) in enumerate(zip(axs.ravel(),['(a) Canopy expansion','(b) Stomatal water limitation','(c) Canopy cover','(d) End-of-day root-domain storage'],[r'Water-stress coefficient $K_s$',r'Water-stress coefficient $K_s$','Canopy cover (fraction)','Storage in 0–1 m (mm)'])):
        ax.set(title=title,ylabel=ylabel);style(ax,True)
        if i<3:ax.set_ylim(-.03,1.05)
    for ax in axs[1]:ax.set_xlabel('Date in 2021')
    header(fig,'2021 common 400 mm schedule | structure and conditional-recalibration effects',handles())
    fig.text(.53,.025,'No deficit-treatment observations are available here; these are model diagnostic comparisons.',ha='center',fontsize=9)
    save(fig,'D01_400mm_cross_structure','Stress, canopy and storage at a shared 400 mm schedule','固定灌溉总量与日程为400mm，横向比较地膜结构及其条件重校准的联合作用；观察胁迫、CC和储水的变化能否解释平台移动。','每个情景参数不同，因而不是固定参数的纯fMulch导数。原DI的CC观测不叠加到400mm面板，避免误当缺水验证。',['fm*_I400_daily.csv','Selected_parameters_all_scenarios.csv'])
    sq=read('All_storage_qualified_subset_fronts')
    fig,axs=plt.subplots(1,3,figsize=(12.4,4.8),sharex=True,sharey=True);fig.subplots_adjust(left=.07,right=.985,bottom=.17,top=.74,wspace=.12)
    for ax,sc in zip(axs,SCENARIOS):
        d=fronts[fronts.Scenario.eq(sc)];q=sq[sq.Scenario.eq(sc)];baseline=fit[fit.Scenario.eq(sc)].iloc[0]
        ax.plot(d.Irrigation_mm,d.Y_13pct,color=COL[sc],lw=1.8)
        ax.plot(q.Irrigation_mm,q.Y_13pct,color='#6A5192',ls='--',marker='.',ms=3,lw=1.5)
        ax.axhline(baseline.Y_13pct,color='#65747D',ls=':',lw=1);ax.scatter(633.47,baseline.Y_13pct,color=COL[sc],marker='*',s=90,zorder=5)
        ax.set(title=f'fMulch={SCENARIOS[sc]:.2f}',xlim=(0,650),ylim=(0,16.8),xlabel='Actual irrigation (mm)');style(ax)
    for ax in axs:ax.set_xticks([0,200,400,633.47],['0','200','400','633.47'])
    axs[0].set_ylabel(r'Grain yield at 13% moisture (t ha$^{-1}$)')
    header(fig,'2021 soil-stock audit | qualifying candidates from the same evaluated set',[Line2D([],[],color='#597B85',lw=2,label='Primary best-found front'),Line2D([],[],color='#6A5192',ls='--',lw=2,label='Storage-qualified evaluated subset'),Line2D([],[],color='#65747D',ls=':',label='Own DI model yield')],3)
    fig.text(.53,.035,'Subset: final 0–1 m storage >= own DI minus 0.01 mm; not a dedicated constrained optimization.',ha='center',fontsize=9)
    save(fig,'D02_Storage_qualified_subset','Effect of post-filtering for comparable terminal root-zone storage','按各自DI季末0—1m储水后筛选，查看主前沿少灌的收益有多少依赖额外耗储；原DI产量线只用于同一面板比较，三情景仍应另用共同实测门槛。','紫虚线只来自主搜索已经评估过的合格候选，并非另一次充分的储水约束搜索；0.01mm是报告精度容差，不是实测阈值。',['All_storage_qualified_subset_fronts.csv','Selected_front_comparisons.csv','Optimization_scenario_summary.csv'])
    part=read('Irrigation_reduction_partition_400mm');fig,ax=plt.subplots(figsize=(9.5,5.8));fig.subplots_adjust(left=.10,right=.98,bottom=.16,top=.76)
    bottom=np.zeros(3);components=[('ET_reduction_mm','Lower ET','#0072B2'),('Root_final_storage_difference_mm','Lower final storage, 0–1 m','#E69F00'),('Below_root_final_storage_difference_mm','Lower final storage, 1–2.4 m','#009E73'),('Deep_drainage_reduction_mm','Lower drainage at 2.4 m','#9E9AC8')]
    for col,label,color in components:
        vals=part[col].to_numpy();ax.bar(range(3),vals,bottom=bottom,width=.55,color=color,label=label)
        for j,v in enumerate(vals):
            if v>12:ax.text(j,bottom[j]+v/2,f'{v:.1f}',ha='center',va='center',color='white' if col!='Root_final_storage_difference_mm' else '#333333',fontsize=11)
        bottom+=vals
    ax.set_xticks(range(3),[f'fMulch={v:.2f}' for v in SCENARIOS.values()]);ax.set(ylabel='Partition of 233.47 mm less applied water (mm)',ylim=(0,260));style(ax)
    header(fig,'2021 water-balance diagnosis | original DI versus proportional 400 mm',[Line2D([],[],color=color,lw=7,label=label) for _,label,color in components],2)
    fig.text(.53,.025,'Differences are DI minus 400 mm. This is a model mass-balance comparison, not measured field losses.',ha='center',fontsize=9)
    save(fig,'D03_Applied_water_reduction_partition','Water-balance partition of reducing irrigation from633.47 to400 mm','在相同参数、天气和初值下，从633.47减到400mm少灌233.47mm，ET几乎不变；主要差额表现为季末土壤存水减少，尤其1m根层以下。这个质量守恒分解比只讨论地膜系数更能解释模型平台。','季末根层以下存水不是可直接被根系利用的水；分量来自冻结模型而非实测去向。改变土壤域、水力参数或初值可能改变分配，不能直接把深层存水差叫田间浪费。',['Irrigation_reduction_partition_400mm.csv','Exact_300_350_400_response_checks.csv'])
    optsum=read('Optimized_candidate_stress_summaries');fig,axs=plt.subplots(3,3,figsize=(12.8,9.4),sharex=True);fig.subplots_adjust(left=.075,right=.985,bottom=.10,top=.84,hspace=.25,wspace=.27)
    for row,sc in enumerate(SCENARIOS):
        for suffix,color,line,label in [('Opt95','#0072B2','-','Optimized 95% yield candidate'),('PropSameOpt95','#D55E00','--','Proportional, same actual amount'),('I100','#83929A',':','Original DI schedule')]:
            path=T/(sc+'_'+suffix+'_daily.csv')
            if not path.exists():continue
            d=pd.read_csv(path);date=pd.to_datetime(d.Date);vals=stress_values(d)
            for ax,y in zip(axs[row],[vals[1],d.CC,d.Root1m_end_mm]):ax.plot(date,y,color=color,ls=line,lw=1.6)
        q=optsum[(optsum.Mulch_scenario.eq(sc))&(optsum.Selection.eq('At_least_95pct_observed'))]
        amount=float(q.Irrigation_mm.iloc[0]) if len(q) else float('nan')
        axs[row,0].text(.025,.06,f'fMulch={SCENARIOS[sc]:.2f} | I={amount:.1f} mm',transform=axs[row,0].transAxes,fontsize=9,bbox=dict(facecolor='white',alpha=.8,edgecolor='none'))
        for j,ax in enumerate(axs[row]):
            style(ax,True);ax.set_ylabel([r'Stomatal coefficient $K_s$','Canopy cover (fraction)','Storage in 0–1 m (mm)'][j])
            if j<2:ax.set_ylim(-.03,1.06)
            if row==2:ax.set_xlabel('Date in 2021')
    for ax,title in zip(axs[0],['(a) Water stress','(b) Canopy growth','(c) Root-domain storage']):ax.set_title(title)
    header(fig,'2021 timing-allocation diagnostic | optimized versus proportional schedules',[Line2D([],[],color=c,ls=line,lw=2,label=label) for c,line,label in [('#0072B2','-','Optimized 95% yield candidate'),('#D55E00','--','Proportional, same actual amount'),('#83929A',':','Original DI schedule')]],3)
    fig.text(.53,.025,'Dates remain fixed. Only the amounts in the four original irrigation windows change. No deficit-treatment validation is implied.',ha='center',fontsize=8.6)
    save(fig,'D04_Optimized_vs_same_amount_schedule','Why allocation improves the best-found front','在相同地膜结构和同一实际灌水总量下，对照优化分配与原比例分配，追溯气孔胁迫、冠层以及季末储水。灰线为原DI；同时检查四个日历窗口账本和七次事件水量。','优化保持原日期，改变四个窗口总量，并非优化灌溉日期。95%目标候选与原DI不是同产量的实测田间对照；日历会计窗口也不是重新识别的生育阶段。',['Optimized_candidate_stress_summaries.csv','fm*_Opt95_daily.csv','fm*_PropSameOpt95_daily.csv','Calendar_window_water_stress_ledger.csv','Selected_event_schedules.csv'])
    (ROOT/'FIGURE_REGISTRY.json').write_text(json.dumps(REG,ensure_ascii=False,indent=2));print('FIGURES',len(REG),flush=True)
if __name__=='__main__':main()
