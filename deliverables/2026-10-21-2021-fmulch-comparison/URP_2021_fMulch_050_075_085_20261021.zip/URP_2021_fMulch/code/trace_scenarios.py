"""Exact daily water-stress observers, adapted from the completed 2021 audit."""
import importlib,functools
import numpy as np
import pandas as pd
from scenario_engine import ROOT,Engine
T=ROOT/'tables'

class TraceEngine(Engine):
    def __init__(self,scenario,accelerated=True,tag='trace'):
        super().__init__(scenario,accelerated,tag=tag)
        self.a=self.adapter;self.control_override=None
    def run(self,amount):
        x=self.base*(amount/self.cap) if self.control_override is None else np.asarray(self.control_override,float)
        control=dict(kind='stage_amounts',values=dict(zip(self.space['names'],x)))
        return self.adapter.simulate(params=self.params,year=2021,management=control,details=True,accelerate=self.accelerated)

    def trace(self,label,amount,controls=None):
        self.control_override=controls
        m,data=self.m,self.data;self.a._template.cache_clear()
        prof=data['soil'].profile;dz=prof.dz.to_numpy(float);weights=np.clip(1-prof.z_top.to_numpy(float),0,dz)*1000
        step=importlib.import_module('aquacrop.timestep.run_single_timestep')
        trmod=importlib.import_module('aquacrop.solution.transpiration')
        old_perform=m.AquaCropModel._perform_timestep;oldtr=step.transpiration;oldaer=trmod.aeration_stress
        records=[];layers=[];calls=[];ctx={};replacements=[]
        for stage,name in [('CC','canopy_cover'),('Tr','transpiration'),('HI','harvest_index')]:
            module=importlib.import_module('aquacrop.solution.'+name);original=module.water_stress
            def factory(fn,prefix):
                @functools.wraps(fn)
                def observed(*args,**kwargs):
                    result=fn(*args,**kwargs)
                    if ctx:
                        r=ctx['row'];num=int(r.get(prefix+'_calls',0))+1;r[prefix+'_calls']=num
                        for key,value in zip(['exp','sto','sen','pol','sto_lin'],result):
                            r[prefix+'_Ks_'+key]=float(value)
                            if num==1:r[prefix+'_Ks_'+key+'_first']=float(value)
                        calls.append(dict(Scenario=label,Date=r['Date'],Function=prefix,Call=num,
                            Dr_mm=float(args[6]),TAW_mm=float(args[7]),ETo_mm=float(args[8]),Beta=bool(args[9]),
                            Ks_exp=float(result[0]),Ks_sto=float(result[1]),Ks_sen=float(result[2]),Ks_pol=float(result[3]),Ks_sto_lin=float(result[4])))
                    return result
                return observed
            replacements.append((module,original));module.water_stress=factory(original,stage)
        @functools.wraps(oldaer)
        def aer(*args,**kwargs):
            result=oldaer(*args,**kwargs)
            if ctx:ctx['row']['Tr_Ks_aeration']=float(result[0])
            return result
        trmod.aeration_stress=aer
        @functools.wraps(oldtr)
        def transpiration(*args,**kwargs):
            cond=args[6];before=np.array(cond.th,copy=True);surface=float(cond.surface_storage)
            rz=step.root_zone_water(args[0],float(cond.z_root),cond.th,args[2],float(args[3].Zmin),args[3].Aer)
            ctx['row'].update(Tr_root_Dr_before_mm=float(rz[2]),Tr_root_TAW_before_mm=float(rz[4]),
                Tr_top_Dr_before_mm=float(rz[1]),Tr_top_TAW_before_mm=float(rz[3]),
                Tr_selected_wetter_topsoil=bool(rz[1]/rz[3]<rz[2]/rz[4]))
            result=oldtr(*args,**kwargs);after=result[3]
            uptake=(before-np.asarray(after.th))*dz*1000;ctx['uptake']=uptake
            ctx['row'].update(Tr_actual_mm=float(result[0]),Tr_potential_no_stress_canopy_mm=float(result[1]),
                Tr_potential_actual_canopy_mm=float(result[2]),Surface_uptake_mm=surface-float(after.surface_storage))
            np.testing.assert_allclose(uptake.sum()+surface-float(after.surface_storage),result[0],atol=1e-8,rtol=0)
            return result
        step.transpiration=transpiration
        def perform(model):
            date=pd.Timestamp(model._clock_struct.step_start_time);before=np.array(model._init_cond.th,copy=True)
            ctx.clear();ctx.update(row=dict(Scenario=label,Date=date.strftime('%Y-%m-%d'),
                Storage_time_start=date.isoformat(),Storage_time_end=(date+pd.Timedelta(days=1)).isoformat(),
                Profile_start_mm=float(np.dot(before,dz*1000)),Root1m_start_mm=float(np.dot(before,weights)),
                Surface_start_mm=float(model._init_cond.surface_storage),Protected_seed_before=bool(model._init_cond.protected_seed)),uptake=np.zeros(len(dz)))
            result=old_perform(model);clock,cond,param,out=result;after=np.array(cond.th,copy=True);sc=param.Seasonal_Crop_List[0]
            rz=step.root_zone_water(param.Soil.Profile,float(cond.z_root),after,param.Soil.z_top,float(sc.Zmin),sc.Aer)
            row=ctx['row'];row.update(DAP=int(cond.dap),Growing_season_end=bool(cond.growing_season),Crop_dead=bool(cond.crop_dead),
                Root_depth_m=float(cond.z_root),Zmax_m=float(sc.Zmax),CC=float(cond.canopy_cover),CC_no_stress=float(cond.canopy_cover_ns),
                Biomass_t_ha=float(cond.biomass/100),HI_adjusted=float(cond.harvest_index_adj),
                Profile_end_mm=float(np.dot(after,dz*1000)),Root1m_end_mm=float(np.dot(after,weights)),
                Surface_end_mm=float(cond.surface_storage),Dynamic_root_water_end_mm=float(rz[0]),
                Dynamic_root_Dr_end_mm=float(rz[2]),Dynamic_root_TAW_end_mm=float(rz[4]),
                MulchPct=float(param.FieldMngt.mulch_pct),fMulch=float(param.FieldMngt.f_mulch),
                WetSurf=float(param.IrrMngt.WetSurf),AppEff=float(param.IrrMngt.AppEff),
                Emergence_dap=float(sc.Emergence),CanopyDevEnd_dap=float(sc.CanopyDevEnd),Senescence_dap=float(sc.Senescence),HIstart_dap=float(sc.HIstart),
                Delayed_days=float(cond.delayed_cds),Premature_senescence=bool(cond.premat_senes))
            row['Below1m_start_mm']=row['Profile_start_mm']-row['Root1m_start_mm'];row['Below1m_end_mm']=row['Profile_end_mm']-row['Root1m_end_mm']
            records.append(row)
            for j in range(len(dz)):
                layers.append(dict(Scenario=label,Date=row['Date'],Compartment=j+1,Depth_top_m=float(prof.z_top.iloc[j]),Depth_bottom_m=float(prof.dzsum.iloc[j]),
                    dz_m=float(dz[j]),Theta_start=float(before[j]),Theta_end=float(after[j]),Theta_FC=float(prof.th_fc.iloc[j]),Theta_WP=float(prof.th_wp.iloc[j]),
                    Storage_change_mm=float((after[j]-before[j])*dz[j]*1000),Transpiration_uptake_mm=float(ctx['uptake'][j])))
            return result
        m.AquaCropModel._perform_timestep=perform
        try:s,w,g=self.run(amount)
        finally:
            m.AquaCropModel._perform_timestep=old_perform;step.transpiration=oldtr;trmod.aeration_stress=oldaer
            for module,original in replacements:module.water_stress=original
            self.a._template.cache_clear()
        daily=pd.DataFrame(records);layer=pd.DataFrame(layers);kc=pd.DataFrame(calls)
        assert len(daily)==148 and not daily.Date.duplicated().any()
        for k in ['Tr','Es','IrrDay','Runoff','DeepPerc','CR','GwIn','TileDrain']:daily[k]=w[k].to_numpy()
        daily['Rain_mm']=data['weather'].set_index('Date').loc[m.DATES,'Precipitation'].to_numpy()
        daily['ET_mm']=daily.Tr+daily.Es
        daily['DeltaS_profile_mm']=daily.Profile_end_mm-daily.Profile_start_mm
        daily['DeltaS_root1m_mm']=daily.Root1m_end_mm-daily.Root1m_start_mm
        daily['DeltaS_below1m_mm']=daily.Below1m_end_mm-daily.Below1m_start_mm
        daily['DeltaS_surface_mm']=daily.Surface_end_mm-daily.Surface_start_mm
        daily['Whole_profile_WB_residual_mm']=daily.Rain_mm+daily.IrrDay+daily.CR+daily.GwIn-daily.ET_mm-daily.Runoff-daily.DeepPerc-daily.TileDrain-daily.DeltaS_profile_mm-daily.DeltaS_surface_mm
        assert daily.Whole_profile_WB_residual_mm.abs().max()<1e-7
        assert daily.Zmax_m.eq(1).all() and daily.Root_depth_m.max()<=1+1e-9
        assert daily.MulchPct.eq(75).all() and daily.fMulch.eq(self.fmulch).all() and daily.WetSurf.eq(100).all() and daily.AppEff.eq(100).all()
        assert abs(layer.loc[layer.Depth_top_m>=1-1e-8,'Transpiration_uptake_mm'].sum())<1e-8
        assert daily[['CR','GwIn','TileDrain']].abs().to_numpy().max()<1e-10
        daily['Net_downward_flux_1m_balance_derived_mm']=daily.Rain_mm+daily.IrrDay-daily.ET_mm-daily.Runoff-daily.DeltaS_root1m_mm-daily.DeltaS_surface_mm
        np.testing.assert_allclose(daily.Net_downward_flux_1m_balance_derived_mm,daily.DeltaS_below1m_mm+daily.DeepPerc,atol=1e-8,rtol=0)
        daily['Ks_exp_computed']=daily.get('CC_Ks_exp_first',np.nan)
        daily['Ks_sto_linear_computed']=daily.get('Tr_Ks_sto_lin',np.nan)
        daily['Ks_sen_computed']=daily.get('CC_Ks_sen',np.nan)
        daily['Ks_transpiration_combined']=np.minimum(daily.Ks_sto_linear_computed,daily.Tr_Ks_aeration)
        daily['Tr_fraction_of_actual_canopy_potential']=np.where(daily.Tr_potential_actual_canopy_mm>1e-8,daily.Tr/daily.Tr_potential_actual_canopy_mm,np.nan)
        for k in ['Ks_exp_computed','Ks_sto_linear_computed','Ks_sen_computed','Tr_Ks_aeration']:
            assert daily[k].dropna().between(-1e-10,1+1e-10).all()
        for suffix,tab in [('daily',daily),('layers',layer),('stress_function_calls',kc),('water',w),('growth',g)]:tab.to_csv(T/f'{label}_{suffix}.csv',index=False)
        # Independently replay without observers and compare all numeric summaries.
        plain,pw,pg=self.run(amount)
        diff={k:abs(float(v)-float(plain[k])) for k,v in s.items() if isinstance(v,(float,int,np.number)) and not isinstance(v,bool)}
        assert max(diff.values())<1e-8
        np.testing.assert_allclose(w[['Tr','Es','IrrDay']],pw[['Tr','Es','IrrDay']],atol=1e-10,rtol=0)
        np.testing.assert_allclose(g[['canopy_cover','biomass']],pg[['canopy_cover','biomass']],atol=1e-10,rtol=0)
        row=dict(Scenario=label,Requested_mm=amount,**{k:v for k,v in s.items() if k!='irrigation_events'},
            Root1m_initial_mm=float(daily.Root1m_start_mm.iloc[0]),Root1m_final_mm=float(daily.Root1m_end_mm.iloc[-1]),
            Root1m_change_mm=float(daily.DeltaS_root1m_mm.sum()),Below1m_initial_mm=float(daily.Below1m_start_mm.iloc[0]),Below1m_final_mm=float(daily.Below1m_end_mm.iloc[-1]),
            Below1m_change_mm=float(daily.DeltaS_below1m_mm.sum()),Net_downward_flux_1m_balance_derived_mm=float(daily.Net_downward_flux_1m_balance_derived_mm.sum()),
            Daily_balance_max_mm=float(daily.Whole_profile_WB_residual_mm.abs().max()),Below1m_root_uptake_mm=float(layer.loc[layer.Depth_top_m>=1-1e-8,'Transpiration_uptake_mm'].sum()),Observer_max_difference=max(diff.values()))
        # A coefficient is not necessarily growth-limiting throughout the season.
        # Store counts only on explicit process-active diagnostic masks.
        tadj=daily.DAP-daily.Delayed_days
        masks=dict(Expansion=(tadj>=daily.Emergence_dap)&(tadj<daily.CanopyDevEnd_dap)&(~daily.Protected_seed_before)&(daily.CC>1e-8),
            Stomatal=(daily.Tr_potential_actual_canopy_mm>1e-8),Senescence=(daily.CC>1e-8)&(~daily.Protected_seed_before))
        for process,col in [('Expansion','Ks_exp_computed'),('Stomatal','Ks_sto_linear_computed'),('Senescence','Ks_sen_computed')]:
            vals=daily.loc[masks[process],col].dropna();row[process+'_eligible_days']=len(vals)
            row[process+'_stress_days_Ks_lt_0p95']=int((vals<.95).sum());row[process+'_severe_days_Ks_lt_0p5']=int((vals<.5).sum())
            row[process+'_equivalent_stress_days']=float((1-vals).sum())
        row['Topsoil_selected_days']=int(daily.Tr_selected_wetter_topsoil.fillna(False).astype(bool).sum())
        self.control_override=None
        return row
