"""Three fMulch structures, each with two real 500x10x4 MCMC phases.
Original likelihood and priors; short-pilot handoff explicitly bypasses formal
>=2000-step convergence gate, without relabeling results as converged.
"""
import contextlib,hashlib,json,multiprocessing as mp,sys,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
from scenario_engine import ROOT,SOURCE,SCENARIOS,load,dump
STEPS,WALKERS,ENSEMBLES,BURN,SEED=500,10,4,250,42


def worker(task):
    scenario,phase,names,fixed,e=task;f=SCENARIOS[scenario];folder=ROOT/'calibration'/scenario/phase;folder.mkdir(parents=True,exist_ok=True)
    with (folder/f'ensemble_{e+1}.log').open('a',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        t=time.monotonic();_,m,data,start=load(f,True,f'{scenario}_{phase}_{e}')
        lower=np.array([m.PRIOR_BOUNDS[k][0] for k in names]);upper=np.array([m.PRIOR_BOUNDS[k][1] for k in names]);m.simulate(data,fixed)
        contract=dict(Experiment='2021_fMulch_structural_pilots',Scenario=scenario,fMulch=f,Names=names,Fixed=fixed,Bounds=m.PRIOR_BOUNDS,
            Steps=STEPS,Walkers=WALKERS,Ensembles=ENSEMBLES,Seed=SEED,Ensemble=e,Zmax_m=1.,MulchPct=75.,
            Original_source_SHA256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),Harness_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),Engine_SHA256=hashlib.sha256(Path(__file__).with_name('scenario_engine.py').read_bytes()).hexdigest())
        sampler=sys.modules['_di_2021_sampler'];sampler.run_ensemble(lambda x:m.logprob(x,names,fixed,phase,data),
            np.array([fixed[k] for k in names]),lower,upper,STEPS,WALKERS,SEED+m.YEAR*100+e+(100000 if phase=='biomass_yield' else 0),
            folder/f'ensemble_{e+1}.npz',contract,25)
        result=dict(Scenario=scenario,Phase=phase,Ensemble=e+1,Seconds=time.monotonic()-t);print('COMPLETE',result,flush=True);return result


def analyze(scenario,phase,names,fixed):
    _,m,data,start=load(SCENARIOS[scenario],True,'analyze_'+scenario+'_'+phase);folder=ROOT/'calibration'/scenario/phase
    xs=[];ps=[];aa=[]
    for e in range(ENSEMBLES):
        with np.load(folder/f'ensemble_{e+1}.npz',allow_pickle=False) as f:xs.append(f['history']);ps.append(f['logs']);aa.append(f['accepted'])
    raw,logs,accept=np.array(xs),np.array(ps),np.array(aa);lower=np.array([m.PRIOR_BOUNDS[k][0] for k in names]);upper=np.array([m.PRIOR_BOUNDS[k][1] for k in names])
    sys.modules['_di_2021_ensemble_pipeline'].analyze(phase,names,raw,logs,accept,lower,upper,folder,False)
    retained=raw[:,BURN:];lp=logs[:,BURN:];idx=np.unravel_index(np.argmax(lp),lp.shape);chosen=dict(fixed,**dict(zip(names,map(float,retained[idx]))))
    groups=[sys.modules['_di_2021_diagnostics'].diagnose(retained[:,:,w,:],names) for w in range(WALKERS)];rows=[]
    for j,k in enumerate(names):
        x=retained[:,:,:,j].ravel();lo,hi=m.PRIOR_BOUNDS[k];width=hi-lo;rhat=[g[j]['Rhat'] for g in groups]
        rows.append(dict(Scenario=scenario,fMulch=SCENARIOS[scenario],Phase=phase,Parameter=k,Selected=chosen[k],Mean=float(x.mean()),SD=float(x.std(ddof=1)),
            Q025=float(np.quantile(x,.025)),Median=float(np.median(x)),Q975=float(np.quantile(x,.975)),Prior_low=lo,Prior_high=hi,
            Selected_within_1pct_bound=bool(min(chosen[k]-lo,hi-chosen[k])<=.01*width),
            Mass_lower_1pct=float((x<=lo+.01*width).mean()),Mass_upper_1pct=float((x>=hi-.01*width).mean()),Mass_lower_5pct=float((x<=lo+.05*width).mean()),Mass_upper_5pct=float((x>=hi-.05*width).mean()),
            Rhat_max=max(rhat) if all(v is not None for v in rhat) else None,ESS_bulk_min=min(g[j]['ESS_bulk'] for g in groups),ESS_tail_min=min(g[j]['ESS_tail'] for g in groups),
            Formal_convergence=False,Summary_scope='last250 steps short pilot; NOT converged posterior'))
    pd.DataFrame(rows).to_csv(folder/'Pilot_parameter_diagnostics.csv',index=False)
    full=pd.read_csv(folder/f'mcmc_full_chain_{phase}.csv');full[full.Step>=BURN].to_csv(folder/'Pilot_retained_draws.csv',index=False)
    np.savez_compressed(folder/'Pilot_arrays.npz',raw=raw,log_posterior=logs,accepted=accept)
    dump(folder/'SELECTED_POINT.json',dict(Scenario=scenario,fMulch=SCENARIOS[scenario],Values=chosen,Selected_log_posterior=float(lp[idx]),Formal_convergence=False,
        Selection='highest log posterior in last250 steps, not a global MAP',Phase2_handoff='explicit user short-trial continuation despite original formal gate'))
    return chosen


def main():
    assert json.loads((ROOT/'verification/PREFLIGHT.json').read_text())['Status']=='PASS'
    status=dict(State='RUNNING',Scenario_values=SCENARIOS,Steps=STEPS,Walkers=WALKERS,Independent_ensembles=4,Phases=2,Planned_recorded_states=120000,Completed=[])
    dump(ROOT/'verification/CALIBRATION_STATUS.json',status);fixed={}
    _,m,data,start=load(.5,True,'coordinator');names_by_phase=[('canopy_transpiration',m.PHASE1_NAMES),('biomass_yield',m.PHASE2_NAMES)]
    fixed={name:dict(start) for name in SCENARIOS}
    dump(ROOT/'verification/CALIBRATION_DESIGN.json',dict(Priors=m.PRIOR_BOUNDS,Normal_priors=sorted(m.NORMAL_PRIORS),Prior_centers=data['center'],Prior_SD=m.PRIOR_SD,
        Sigmas=dict(CC=m.SIGMA_CC,Tr=m.SIGMA_TR,Es=m.SIGMA_ES,Ydry=m.SIGMA_Y),Targets=dict(Tr=m.TR_TARGET,Es=m.ES_TARGET,ET=m.ET_OBS,Y13_internal=m.Y13_TARGET,Y13_published=m.Y13_PUBLISHED),
        Common_initial_point=start,Common_random_seed_rule='42+2021*100+ensemble_index (+100000 for phase2), common across scenarios',
        Steps=500,Walkers=10,Ensembles=4,Pilot_summary_burn=250,Formal_convergence_gate_unchanged_but_not_required_for_pilot_handoff=True,
        No_target_irrigation_fitting=True,Root_max_m=1.,Soil_texture_unchanged=True,Historical_f0_preserved=True))
    for phase,names in names_by_phase:
        tasks=[(scenario,phase,names,fixed[scenario],e) for scenario in SCENARIOS for e in range(ENSEMBLES)]
        with ProcessPoolExecutor(max_workers=4,mp_context=mp.get_context('spawn')) as pool:
            futures=[pool.submit(worker,task) for task in tasks]
            for future in as_completed(futures):
                result=future.result();status['Completed'].append(result);dump(ROOT/'verification/CALIBRATION_STATUS.json',status);print('ENSEMBLE COMPLETE',result,flush=True)
        for scenario in SCENARIOS:
            fixed[scenario]=analyze(scenario,phase,names,fixed[scenario]);dump(ROOT/'calibration'/scenario/('PHASE1_PARAMETERS.json' if phase=='canopy_transpiration' else 'SELECTED_PARAMETERS.json'),fixed[scenario])
            print('SCENARIO PHASE COMPLETE',scenario,phase,fixed[scenario],flush=True)
    status['State']='COMPLETE';status['Recorded_states']=120000;dump(ROOT/'verification/CALIBRATION_STATUS.json',status);print('ALL CALIBRATIONS COMPLETE',flush=True)

if __name__=='__main__':main()
