"""Independent output checks, including original unaccelerated model replay."""
import contextlib,hashlib,json
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
import fitz
from scenario_engine import ROOT,SOURCE,SCENARIOS,Engine,dump
T=ROOT/'tables'
def main():
    checks=[];states=0;population_records=0;generations=0;evaluations=0
    fit=pd.read_csv(T/'Calibrated_DI_fit_summary.csv');chosen=pd.read_csv(T/'Selected_front_comparisons.csv',float_precision='round_trip');curves=pd.read_csv(T/'All_proportional_responses.csv')
    names=['Window1_mm','Window2_mm','Window3_mm','Window4_mm']
    for sc,value in SCENARIOS.items():
        for phase,dim in [('canopy_transpiration',5),('biomass_yield',3)]:
            for i in range(1,5):
                with np.load(ROOT/'calibration'/sc/phase/f'ensemble_{i}.npz',allow_pickle=False) as a:
                    assert a['history'].shape==(500,10,dim) and a['logs'].shape==(500,10);assert np.isfinite(a['history']).all() and np.isfinite(a['logs']).all()
                    contract=json.loads(str(a['contract']));assert contract['fMulch']==value and contract['Zmax_m']==1. and contract['Steps']==500 and contract['Walkers']==10
                    assert contract['Original_source_SHA256']==hashlib.sha256(SOURCE.read_bytes()).hexdigest()
                    assert contract['Harness_SHA256']==hashlib.sha256((ROOT/'code/run_calibrations.py').read_bytes()).hexdigest()
                    assert contract['Engine_SHA256']==hashlib.sha256((ROOT/'code/scenario_engine.py').read_bytes()).hexdigest();states+=5000
        allpoints=pd.read_csv(T/f'{sc}_All_optimization_evaluations.csv.gz',float_precision='round_trip');front=pd.read_csv(T/f'{sc}_NSGA3_front.csv',float_precision='round_trip')
        assert len(allpoints)==30000==allpoints.Candidate_ID.nunique();evaluations+=len(allpoints)
        assert allpoints.fMulch.eq(value).all() and allpoints.Runtime_fMulch.eq(value).all()
        assert allpoints.Irrigation_mm.min()>=0 and allpoints.Planned_irrigation_mm.max()<=633.47+1e-8
        assert allpoints.Max_daily_balance_residual_mm.max()<1e-7
        I,Y=allpoints.Irrigation_mm.to_numpy(),allpoints.Y_13pct.to_numpy()
        for _,r in front.iterrows():assert not np.any((I<=r.Irrigation_mm)&(Y>=r.Y_13pct)&((I<r.Irrigation_mm)|(Y>r.Y_13pct)))
        for seed in [31,73,109]:
            folder=ROOT/'optimization'/sc/f'seed{seed}';a=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip');assert len(a)==10000
            lookup={tuple(x):(-float(row.Y_13pct),float(row.Irrigation_mm)) for x,(_,row) in zip(a[names].to_numpy(),a.iterrows())}
            for n in range(1,101):
                with np.load(folder/f'generation_{n:04d}.npz',allow_pickle=False) as a:
                    assert a['X'].shape==(100,4) and a['F'].shape==(100,2) and np.all(a['CV']<=0)
                    for x,f in zip(a['X'],a['F']):np.testing.assert_allclose(f,lookup[tuple(x)],atol=1e-10,rtol=0);population_records+=1
                generations+=1
        c=curves[curves.Scenario.eq(sc)];assert len(c)==201 and abs(c.Irrigation_mm.iloc[0])<1e-10 and abs(c.Irrigation_mm.iloc[-1]-633.47)<1e-8
        assert abs(c.Y_13pct.iloc[-1]-float(fit.loc[fit.Scenario.eq(sc),'Y_13pct'].iloc[0]))<1e-8
        for dose in ['I000','I050','I400','I075','I100','Opt95','OptOwnDI','PropSameOpt95']:
            a=pd.read_csv(T/f'{sc}_{dose}_daily.csv');layers=pd.read_csv(T/f'{sc}_{dose}_layers.csv');assert len(a)==148 and a.fMulch.eq(value).all()
            assert a.Root_depth_m.max()<=1+1e-9 and a.MulchPct.eq(75).all();assert a.Whole_profile_WB_residual_mm.abs().max()<1e-7
            assert abs(layers.loc[layers.Depth_top_m>=1-1e-8,'Transpiration_uptake_mm'].sum())<1e-8
    # This verifier is a separate process and never installs acceleration kernels.
    with (ROOT/'verification/UNACCELERATED_REPLAY.log').open('w') as log,contextlib.redirect_stdout(log):
        for sc in SCENARIOS:
            e=Engine(sc,False,tag='unaccelerated_final');e.install()
            try:
                s=e.run(e.base);target=fit[fit.Scenario.eq(sc)].iloc[0]
                diff=max(abs(s[k]-target[k]) for k in ['Y_13pct','Es_mm','Tr_mm','ET_mm']);assert diff<1e-8
                checks.append(dict(Scenario=sc,Selection='DI_full_recalibrated',Maximum_absolute_difference=diff,Status='PASS'))
                for _,r in chosen[chosen.Scenario.eq(sc)&chosen.Status.eq('FOUND_IN_EVALUATED_SET')].iterrows():
                    s=e.run(r[names].to_numpy(float));diff=max(abs(s[k]-r[k]) for k in ['Y_13pct','Irrigation_mm','ET_mm','Root1m_final_mm','Below1m_final_mm']);assert diff<1e-8
                    checks.append(dict(Scenario=sc,Selection=r.Selection,Maximum_absolute_difference=diff,Status='PASS'))
            finally:e.restore()
    reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text());figures=[]
    for r in reg:
        im=Image.open(ROOT/'figures'/(r['ID']+'.png'));assert im.width>3500 and im.height>2000
        for ext in ['pdf','svg']:assert (ROOT/'figures'/(r['ID']+'.'+ext)).stat().st_size>1000
        figures.append(dict(ID=r['ID'],Width=im.width,Height=im.height))
    doc=Document(ROOT/'URP_2021_fMulch_Report.docx');pdf=fitz.open(ROOT/'URP_2021_fMulch_Report.pdf');assert len(doc.inline_shapes)==len(reg)
    assert all(len(page.get_text())>60 for page in pdf)
    assert states==120000 and evaluations==90000 and generations==900 and population_records==90000
    dump(ROOT/'verification/FINAL_DATA_CHECK.json',dict(Status='PASS',MCMC_recorded_states=states,MCMC_checkpoints=24,Optimization_model_evaluations=evaluations,Generation_files=generations,Population_records_checked=population_records,Per_scenario_front_nondominance='PASS',Daily_trace_scenarios_checked=24,Water_balance_and_runtime_fMulch='PASS',Below_root_direct_uptake='ZERO',Unaccelerated_model_replays=checks,Figures=figures,Report_pages=len(pdf),Formal_MCMC_convergence=False,Field_validation=False))
    print('ALL SCIENTIFIC CHECKS PASS',flush=True)
if __name__=='__main__':main()
