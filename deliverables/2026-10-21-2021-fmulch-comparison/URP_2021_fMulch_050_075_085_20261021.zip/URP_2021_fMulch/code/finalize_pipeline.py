"""Finalize after complete figure generation; publication is separate."""
from pathlib import Path
import json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[1]
while not (ROOT/'FIGURE_REGISTRY.json').exists():time.sleep(10)
for script in ['build_report.py']:
    subprocess.run([os.sys.executable,str(ROOT/'code'/script)],cwd=ROOT,check=True)
subprocess.run(['soffice','-env:UserInstallation=file:///tmp/urp_fmulch_report_20261021','--headless','--convert-to','pdf','--outdir',str(ROOT),str(ROOT/'URP_2021_fMulch_Report.docx')],cwd=ROOT,check=True)
for script in ['verify_results.py','package_results.py']:
    subprocess.run([os.sys.executable,str(ROOT/'code'/script)],cwd=ROOT,check=True)
print('FINALIZE COMPLETE',flush=True)
