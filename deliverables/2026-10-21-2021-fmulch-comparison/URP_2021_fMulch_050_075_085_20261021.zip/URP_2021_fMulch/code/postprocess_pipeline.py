"""Run export then optimization immediately after MCMC finishes; fail closed."""
import json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
while True:
    state=json.loads((ROOT/'verification/CALIBRATION_STATUS.json').read_text())
    if state['State']=='COMPLETE':break
    time.sleep(10)
for name in ['export_scenarios.py','factorial_checks.py','run_optimizations.py','aggregate_comparison.py','plot_comparison.py']:
    print('START',name,flush=True)
    subprocess.run([os.sys.executable,str(ROOT/'code'/name)],cwd=ROOT,check=True)
    print('FINISHED',name,flush=True)
