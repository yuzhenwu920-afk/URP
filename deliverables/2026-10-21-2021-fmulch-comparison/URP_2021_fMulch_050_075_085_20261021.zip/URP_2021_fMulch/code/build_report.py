"""Chinese scientific interpretation, English figures, auditable numeric workbook."""
import importlib.metadata,json,platform
from pathlib import Path
import pandas as pd
import numpy as np
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl.styles import Font,PatternFill,Alignment
from scenario_engine import ROOT,SCENARIOS
T=ROOT/'tables'
def read(n):return pd.read_csv(T/(n+'.csv'))
def main():
    fit=read('Calibrated_DI_fit_summary');scores=read('Descriptive_fit_residual_scores');selection=read('Selected_front_comparisons');diag=read('All_MCMC_parameter_diagnostics');summary=read('Optimization_scenario_summary');reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text());exact=read('Exact_300_350_400_response_checks')
    # Workbook keeps full core outputs; bulky raw traces/chains/90k evaluations remain in their CSV/NPZ archives.
    sheets=['Calibrated_DI_fit_summary','Calibration_fit_metrics','Descriptive_fit_residual_scores','Selected_parameters_all_scenarios','All_MCMC_parameter_diagnostics','Fixed_parameter_fMulch_profile','All_proportional_responses','Exact_300_350_400_response_checks','All_stress_storage_summaries','Optimization_scenario_summary','Selected_front_comparisons','All_scenario_NSGA3_fronts','All_storage_qualified_subset_fronts','Seed_stability','All_generation_history','Selected_event_schedules','Cross_scenario_control_definitions','Cross_scenario_candidate_replays','Cross_scenario_worst_case_summary','Factorial_parameter_structure_check','Irrigation_reduction_partition_400mm','All_DI_storage_baselines','Optimized_candidate_stress_summaries','Calendar_window_water_stress_ledger']
    with pd.ExcelWriter(ROOT/'URP_2021_fMulch_Data.xlsx',engine='openpyxl') as writer:
        idx=[]
        for i,n in enumerate(sheets,1):
            a=read(n);name=f'{i:02d}_'+n[:27];a.to_excel(writer,sheet_name=name,index=False);idx.append(dict(Sheet=name,CSV=n+'.csv',Rows=len(a),Scope='full core data'))
        for sc in SCENARIOS:
            for typ in ['CC_pairs','Biomass_pairs']:
                n=sc+'_'+typ;a=read(n);a.to_excel(writer,sheet_name=n,index=False);idx.append(dict(Sheet=n,CSV=n+'.csv',Rows=len(a),Scope='full fitted pairs'))
        daily=pd.concat([read(sc+'_'+dose+'_daily') for sc in SCENARIOS for dose in ['I000','I050','I400','I075','I100']],ignore_index=True)
        daily.to_csv(T/'All_scenario_daily_traces.csv',index=False);daily.to_excel(writer,sheet_name='DAILY_15_SCENARIOS',index=False);idx.append(dict(Sheet='DAILY_15_SCENARIOS',CSV='All_scenario_daily_traces.csv',Rows=len(daily),Scope='full daily traces'))
        pd.DataFrame(idx).to_excel(writer,sheet_name='INDEX',index=False)
        for ws in writer.book:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            for cell in ws[1]:cell.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='275767');cell.alignment=Alignment(wrap_text=True)
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width=min(34,max(13,max(len(str(c.value or '')) for c in list(col)[:25])+2))
                for c in list(col)[1:150]:
                    if isinstance(c.value,float):c.number_format='0.0000'
    doc=Document();sec=doc.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=sec.right_margin=Cm(1.65);sec.top_margin=sec.bottom_margin=Cm(1.5)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
        st=doc.styles[name];st.font.name='DejaVu Sans';st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.styles['Normal'].font.size=Pt(10.5);doc.styles['Normal'].paragraph_format.line_spacing=1.12;doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    doc.styles['Title'].font.size=Pt(21);doc.styles['Heading 1'].font.size=Pt(14.5);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('275767');doc.styles['Caption'].font.size=Pt(8.5)
    footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER;footer.add_run('URP · 2021 fMulch结构试验 · ');field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    md=[]
    def p(text,style=None):doc.add_paragraph(text,style);md.append(text+'\n')
    def h(text):doc.add_heading(text,1);md.append('\n## '+text+'\n')
    def table(title,a,cols):
        doc.add_heading(title,2);tab=doc.add_table(rows=1,cols=len(cols));tab.style='Light Shading Accent 1';flag=OxmlElement('w:tblHeader');tab.rows[0]._tr.get_or_add_trPr().append(flag)
        for cell,(_,label,_) in zip(tab.rows[0].cells,cols):cell.text=label
        for _,row in a.iterrows():
            for cell,(key,_,digits) in zip(tab.add_row().cells,cols):
                v=row[key];cell.text='未找到' if pd.isna(v) else str(v) if digits is None else f'{v:.{digits}f}'
        for row in tab.rows:
            no=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(no)
            for cell in row.cells:
                for par in cell.paragraphs:
                    par.paragraph_format.space_after=Pt(3)
                    for run in par.runs:run.font.size=Pt(8.5)
        md.append(a[[k for k,_,_ in cols]].to_csv(index=False))
    doc.add_heading('2021年DI玉米\nfMulch条件重校准与灌溉优化',0)
    p('0.50 / 0.75 / 0.85 三情景对比 · 最大根深1.00m · 500步MCMC调试','Subtitle')
    p('2026-10-21｜实际重跑两阶段MCMC、剂量响应、逐日水分审计及NSGA-III；保留历史fMulch=0结果，不覆盖。')
    h('1 本次试验回答了什么')
    p('问题是：当实际DI季灌水约633.47mm，而模型前沿只需约300—350mm时，是否由于地膜蒸发调整因子设置偏差？本轮固定其他输入，以三种地膜结构分别重新条件校准，比较拟合与搜索结果。没有把400mm作为拟合目标、灌水下界或人为拐点。')
    table('原DI日程下的重校准拟合',fit,[('fMulch','fMulch',2),('CC_RMSE','CC RMSE',4),('Y_13pct','Y13 t/ha',3),('Yield_bias_pct','产量偏差%',2),('Es_mm','Es mm',2),('ET_mm','ET mm',2)])
    p('统一参照：文献2021年DI产量15.86t/ha（13%含水率），ET=626.81mm；原模型的Es目标为78mm、Tr目标为548.81mm。Es含原项目近似重建成分，Tr为ET−Es，不能视为新增独立实测。内部产量目标15.862t/ha与文献四舍五入数15.86并列保留。')
    best=scores.loc[scores.Descriptive_total.idxmin()]
    p(f"按所选短链点的共同标准化残差总分，fMulch={best.fMulch:.2f}为三者中较低值（{best.Descriptive_total:.3f}）。这只是在这些试跑选定点上的描述比较；阶段条件拟合、参数先验补偿和未收敛使其不能被解释成模型证据、最优物理常数或可靠模型概率。")
    h('2 fMulch与历史设置的核查')
    p('AquaCrop原生乘数为1−fMulch×MulchPct/100。覆盖率75%时，fMulch=0.50/0.75/0.85分别对应0.625/0.4375/0.3625；值越大，满足适用条件时的潜在土壤蒸发抑制越强。不是地膜完好率，也不能把整季实际Es直接乘这个数。蒸发还受湿润面积、积水与土壤供水状态等约束。')
    p('当前云端上一轮2021年代码实际为fMulch=0，而用户另一个工作位置提到的0.85未在此历史源代码中找到。本轮已把0.85作为新的对照结构，与0.50及0.75同样重校准。用户提供的2022年固定中心剖面是背景信息，不冒充本轮2021年数据。')
    fixed=read('Fixed_parameter_fMulch_profile');table('固定旧f0参数的单因素复算（非重校准结论）',fixed,[('fMulch','fMulch',2),('Y13','Y13 t/ha',3),('Es_mm','Es mm',2),('ET_mm','ET mm',2)])
    p('固定参数时，较强减蒸通常释放更多水给蒸腾或季末储水，反而可能让较小灌水量维持产量。因此不能预设把0.85改成较低值一定能把前沿推到400mm。随后所有正式对比曲线均使用各自条件重校准参数。额外的3×3参数来源—地膜结构交叉表，可把纯结构效应与参数补偿分开观察。')
    factor=read('Factorial_parameter_structure_check')
    for dose in [350,633.47]:
        matrix=factor[factor.Requested_mm.eq(dose)].pivot(index='Parameter_source',columns='Structure',values='Y_13pct').reset_index()
        matrix['参数来源']=matrix.Parameter_source.map(lambda sc:f'fMulch={SCENARIOS[sc]:.2f}')
        table(f'{dose:.2f}mm：参数来源×施用地膜结构的产量矩阵',matrix,[('参数来源','参数来源',None),('fm050','结构0.50',3),('fm075','结构0.75',3),('fm085','结构0.85',3)])
    p('同一行保持作物参数不变，跨列差异主要反映地膜结构作用；同一列保持地膜结构不变，跨行差异反映参数补偿。对角线是本轮各情景自己的条件重校准结果。这个交叉不能被解释为已传播后验不确定性。')
    h('3 校准设计、固定条件与撞墙检查')
    p('每情景每阶段4组独立ensemble，每组10 walkers×500步；两阶段合计每情景40,000个保存状态，三情景共120,000。每阶段前250步不进入试跑摘要；walker相互耦合，保存状态数不是独立有效样本量。三情景使用一致先验、误差项、起点和配对随机种子规则。')
    p('第一阶段：CCx、CGC_CD、CDC_CD、SenescenceCD、Kcb，约束CC与季节Tr/Es；第二阶段：WP_early、WP_late、HI0，条件于各自第一阶段选定点，约束生物量与籽粒产量。最高保留段采样log posterior点仅作为调试参数，非已证明的全局MAP，也不是联合八参数收敛后验。')
    p('根系Zmin=0.30m、Zmax=1.00m，原2.4m水力土壤域、质地水力转换、播前含水、天气与ETo、地膜覆盖75%、WetSurf=100%、AppEff=100%不变。本轮只改变fMulch结构，并重新拟合原来的作物参数，没有通过修改初始水、降雨或蒸散强行改变平台。')
    p('播前0—1m冻结储水为324.97mm，模型田持水量对应储水300.30mm、萎蔫点96.90mm。略高于田持并不自动代表错误或不可能，仍需对应播前灌水和排水时间核对；尤其0.9—1.2m源单元混有图件和ERA5信息，守恒重采样不等于恢复了缺失的实测分层信息。')
    p('原正式流程至少2000步等收敛门槛仍保留；本轮按用户指定500步继续两阶段试验，明确跳过正式放行，不标成收敛。Rhat按同一walker索引跨4个独立ensemble计算，报告10个索引中最大值与最小ESS，以免把ensemble内walker当完全独立链。')
    wall=diag[diag.Selected_within_1pct_bound.astype(bool)].copy()
    if len(wall):table('选定参数距离先验边界不足1%范围',wall,[('fMulch','fMulch',2),('Parameter','参数',None),('Selected','选定值',5),('Prior_low','先验下界',3),('Prior_high','先验上界',3),('Rhat_max','最大Rhat',3)])
    p('表中边界问题意味着当前数据与结构下参数补偿或可辨识性不足，不能宣称不存在撞墙。不要为了把灌水推到400mm而随意扩大HI0/WP边界；应先核对产量含水率、Biomass数字化和误差、收获指数及分期WP的外部依据，再确定是否需要改先验并跑长链。')
    h('4 三个主题的主要数值')
    a=exact[exact.Requested_mm.isin([0,350,400,633.47])];table('原日程同比例减灌（不是优化）',a,[('fMulch','fMulch',2),('Requested_mm','请求mm',2),('Irrigation_mm','实际mm',2),('Y_13pct','Y13',3),('ET_mm','ET mm',2),('Root1m_final_mm','季末根层水mm',2)])
    table('统一达到95%文献实测产量15.067t/ha的已找到前沿候选',selection[selection.Selection.eq('At_least_95pct_observed')],[('fMulch','fMulch',2),('Irrigation_mm','实际灌水mm',2),('Y_13pct','Y13',3),('Root1m_final_mm','季末根层水mm',2),('Extra_root_depletion_vs_own_DI_mm','比自身DI多耗根层水mm',2)])
    table('匹配各自DI模型产量（目标不完全相同）',selection[selection.Selection.eq('Match_own_DI_model')],[('fMulch','fMulch',2),('Target_Y13','目标Y13',3),('Irrigation_mm','实际灌水mm',2),('Y_13pct','达到Y13',3),('Extra_root_depletion_vs_own_DI_mm','多耗根层水mm',2)])
    table('季末根层储水近似不低于各自DI：合格已评价子集匹配自身DI产量',selection[selection.Selection.eq('Storage_qualified_match_own_DI')],[('fMulch','fMulch',2),('Irrigation_mm','实际灌水mm',2),('Y_13pct','Y13',3),('Root1m_final_mm','季末根层水mm',2),('Max_actual_event_mm','最大单次mm',2)])
    p('仅改变fMulch并重新校准，没有使主前沿自然移至400mm：匹配自身DI模型产量的最少已找到I约326.20、298.55、306.52mm（依次0.50、0.75、0.85），且比自身DI多耗根层水约124—127mm。按季末根层储水后筛选后，相应已找到值为455.35、428.14、437.49mm，体现比较条件的影响。这些数不是已证明的约束最优，更不是田间需水定额。')
    p('达到95%实测目标的三个主选候选最大单次分别85.91、60.41、74.07mm，均在原114.8mm实测范围内。储水合格子集的0.85情景匹配点单次最大135.47mm，超出原实测范围；若现场能力确有限制，须用有实测依据的单次约束重新搜索，不能直接推荐这个后筛选点。')
    table('三情景搜索最高找到产量',summary,[('fMulch','fMulch',2),('DI_Y13','自身DI Y13',3),('Maximum_found_Y13','最高找到Y13',3),('Evaluations','模型评价次数',0)])
    for _,r in selection[selection.Selection.eq('Match_observed')].iterrows():
        if r.Status=='NOT_FOUND_IN_SEARCH':p(f'fMulch={r.fMulch:.2f}：本次搜索未找到达到完整实测15.86t/ha的候选；不能把95%门槛或自身模型基线替代完整实测后仍写成“达到实测产量”。')
        else:p(f'fMulch={r.fMulch:.2f}：达到完整实测15.86t/ha的最少已找到灌水为{r.Irrigation_mm:.2f}mm。')
    h('5 如何理解偏乐观结果，以及下一步解决方案')
    part=read('Irrigation_reduction_partition_400mm')
    table('从633.47降到400mm：233.47mm少灌量的去向',part,[('fMulch','fMulch',2),('ET_reduction_mm','ET减少mm',2),('Root_final_storage_difference_mm','季末0—1m存水减少mm',2),('Below_root_final_storage_difference_mm','季末1—2.4m存水减少mm',2),('Deep_drainage_reduction_mm','底部排水减少mm',2)])
    p('这组差额闭合于同一模型的完整水量平衡。400mm与633.47mm的ET差异很小，说明当前模型中高水量段的大部分附加灌水没有增加耗水，而主要增加了季末储水，尤其根层以下。因此，调整地膜参数不是解释整个约200—300mm灌水差距的充分证据。此处描述的是冻结模型的分配，不能把它直接称为已实测的田间浪费。')
    p('注意区分少补给和透支：400mm情景的1—2.4m储水比播前仍增加约23.6—23.7mm；633.47mm则增加约203.7—223.3mm。因此主要深层差额是减少了根层以下补给，不是根系吸走了约200mm深层水。与此同时，400mm的0—1m根层确实比自身DI多耗约27.7—52.2mm储水，这两种机制应分别解释。')
    p('第一，区分实际毛灌水、入渗到根区的净灌水与耗水。模型AppEff=100%、WetSurf=100%仍是冻结的管理假设；本轮没有现场净毛换算观测，不能用一个未经测量的效率把300mm随意换成600mm。但下一轮应核对田间计量口径、滴灌湿润比例与地膜蒸发结构是否一致。')
    p('第二，检查全季和分期水量平衡。少灌并不必然少耗ET，可能改变季末根区及根区以下储水。本轮提供逐日θ、储水、Tr、Es、水分胁迫、根深和候选七次事件水量，额外对95%目标及自身DI匹配优化候选回放，并与同总量原比例日程比较；根层水以下没有直接根系取水，2.4m底边界DeepPerc接近零也不代表没有水离开1m根层。')
    p('第三，优化可重新分配四个时间窗水量，但保留原7个日期；以计划/实际季总量633.47mm为唯一管理上限。原单次MaxIrr=最大实测+0.10是代码执行保护而非已验证硬件能力，候选可超出原单次实测范围，表中标记Max_actual_event_mm与Exceeds_original_max_event。对超范围候选先做水力与灌溉能力复核，不能直接给出田间推荐。')
    p('第四，分离适配误差与真实管理收益。当前条件校准可能在原DI日程下就低估产量，匹配自身模型基准会比匹配完整实测容易。所有情景另用共同的15.067、15.86及历史f0DI产量比较。500步未收敛、参数贴边时，几毫米级情景差异不支持选择唯一fMulch。')
    p('第五，储水筛选与跨情景复核。将已有候选按季末0—1m储水不低于该情景自身DI减0.01mm筛选，再报告非支配子集；这不是带储水约束的独立再优化，也不把0.01mm当实测误差。选定控制方案同时在三种条件重校准模型中复算，提供最差产量；仍不是专门的稳健优化或后验不确定性传播。')
    p('正式方案建议：补充原DI和至少一组300—400mm亏缺处理的分层含水、CC/LAI、Tr/Es或ET及产量；先以多处理共同约束fMulch、湿润比例和作物参数，再用长链检查混合与后验预测。若多个结构拟合难以区分，用结构集合与后验抽样做机会约束或最差情景优化，并加入有实测依据的季末储水和单次供水约束。单凭本轮试验不能排除初始水、根系或土壤水力转换的影响。')
    h('6 复现与数据口径')
    p('原始驱动、源数据、数值内核和SHA256随包保存。加速只缓存或编译相同方程，先通过未加速对照；最终所选方案再独立用原方程复算。每代100个体的X/F/G/CV、每次实际模型评价、24条MCMC checkpoint和随机状态全部保留。')
    p('NSGA-III为第三代非支配排序遗传算法，本轮每个情景3种子×100个体×100代=30,000次，合计90,000次模型优化评价；双目标最大化Y13、最小化实际季节I。没有伪造产量不确定性第三目标、95%产量门槛或400mm偏好约束。提前成熟/死亡后的取消灌水、共同日历期储水变化都按原适配器执行。')
    p('Excel含完整核心数据、三情景的拟合配对、603个剂量响应点和15组比例日程逐日审计；原始表另含9组优化及同总量日程逐日轨迹和四窗口会计账本；90,000次评价和全部MCMC状态另以CSV/NPZ原始档归档，避免重复庞大工作表。每图的英文PNG/PDF/SVG与数据源一一对应，以下每图附中文解析及使用边界。')
    h('7 图件与逐图解析')
    for i,r in enumerate(reg,1):
        doc.add_page_break();doc.add_heading(f"图{i:02d} · {r['Title']}",2)
        path=ROOT/'figures'/(r['ID']+'.png');im=Image.open(path);w,hh=im.size;im.thumbnail((2400,2500));embed=ROOT/'verification/word_figures'/(r['ID']+'.png');embed.parent.mkdir(parents=True,exist_ok=True);im.save(embed,optimize=True)
        para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER;para.add_run().add_picture(str(embed),width=Cm(min(17.5,14*w/hh)))
        p(r['ID'],'Caption');p('解析：'+r['Analysis_CN']);p('使用边界：'+r['Boundary_CN'],'Caption');p('数据源：'+', '.join(r['Source_tables']),'Caption');md.append(f"![{r['Title']}](figures/{r['ID']}.png)\n")
    doc.save(ROOT/'URP_2021_fMulch_Report.docx');(ROOT/'URP_2021_fMulch_Report.md').write_text('\n'.join(md))
    packages={n:importlib.metadata.version(n) for n in ['aquacrop','numpy','pandas','scipy','numba','emcee','pymoo','python-docx','matplotlib','openpyxl','Pillow','PyMuPDF']}
    (ROOT/'ENVIRONMENT.json').write_text(json.dumps(dict(Python=platform.python_version(),Packages=packages,OMP_NUM_THREADS=1,OPENBLAS_NUM_THREADS=1),indent=2));(ROOT/'requirements.txt').write_text('\n'.join(k+'=='+v for k,v in packages.items())+'\n')
    print('WORD AND EXCEL COMPLETE',len(reg),'figures',flush=True)
if __name__=='__main__':main()
