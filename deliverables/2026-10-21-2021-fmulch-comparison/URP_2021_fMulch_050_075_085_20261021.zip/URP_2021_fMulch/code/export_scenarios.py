"""Calibrated fit metrics, 201-point responses, daily stress, and fixed targets."""
import json,hashlib,shutil
import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from scenario_engine import ROOT,PROJECT,SOURCE,SCENARIOS,load,Engine,dump
from trace_scenarios import TraceEngine
T=ROOT/'tables'

def metrics(obs,pred):
    obs=np.asarray(obs,float);pred=np.asarray(pred,float)
    return dict(N=len(obs),RMSE=float(np.sqrt(np.mean((pred-obs)**2))),MAE=float(np.mean(abs(pred-obs))),Bias=float(np.mean(pred-obs)),Fit_R2=float(1-np.sum((pred-obs)**2)/np.sum((obs-obs.mean())**2)),Pearson_r=float(pearsonr(obs,pred).statistic))

def main():
    assert json.loads((ROOT/'verification/CALIBRATION_STATUS.json').read_text())['State']=='COMPLETE'
    fit=[];md=[];parameters=[];curves=[];diags=[];stress=[];likelihood=[]
    for scenario,f in SCENARIOS.items():
        params=json.loads((ROOT/'calibration'/scenario/'SELECTED_PARAMETERS.json').read_text());_,m,data,start=load(f,True,'export_'+scenario)
        s,g,cc,bio=m.simulate(data,params)
        cc.to_csv(T/f'{scenario}_CC_pairs.csv',index=False);bio.to_csv(T/f'{scenario}_Biomass_pairs.csv',index=False);g.to_csv(T/f'{scenario}_DI_growth.csv',index=False)
        cm=metrics(cc.Observed_CC,cc.canopy_cover);bm=metrics(bio.Observed_B_t_ha,bio.Biomass_t_ha)
        fit.append(dict(s,Scenario=scenario,fMulch=f,CC_RMSE=cm['RMSE'],CC_fit_R2=cm['Fit_R2'],CC_Pearson=cm['Pearson_r'],Bio_RMSE=bm['RMSE'],Bio_fit_R2=bm['Fit_R2'],
            Observed_ET_mm=626.81,Es_original_target_mm=m.ES_TARGET,Tr_original_target_mm=m.TR_TARGET,Observed_Y13=15.86,Yield_bias_pct=100*(s['Y_13pct']/15.86-1),ET_bias_mm=s['ET_mm']-626.81,Es_bias_mm=s['Es_mm']-m.ES_TARGET,
            Scope='each fMulch has its own 500x10x4 two-stage conditional recalibration; not independent validation'))
        md.extend([dict(Scenario=scenario,fMulch=f,Variable='CC',**cm),dict(Scenario=scenario,fMulch=f,Variable='Biomass',**bm)])
        for key in m.ALL_NAMES:parameters.append(dict(Scenario=scenario,fMulch=f,Parameter=key,Value=params[key]))
        # Comparable residual scores are descriptive, never Bayes factors.
        cc_score=float(np.sum(cc.Weight*((cc.canopy_cover-cc.Observed_CC)/m.SIGMA_CC)**2));tr=((s['Tr_mm']-m.TR_TARGET)/m.SIGMA_TR)**2;es=((s['Es_mm']-m.ES_TARGET)/m.SIGMA_ES)**2
        b=float(np.sum(((bio.Biomass_t_ha-bio.Observed_B_t_ha)/bio.Sigma_assumed)**2));y=((s['Y_dry']-m.YDRY_TARGET)/m.SIGMA_Y)**2
        likelihood.append(dict(Scenario=scenario,fMulch=f,CC_standardized_SSE=cc_score,Tr_standardized_SSE=tr,Es_standardized_SSE=es,Bio_standardized_SSE=b,Yield_standardized_SSE=y,
            Stage1_sum=cc_score+tr+es,Stage2_sum=b+y,Descriptive_total=cc_score+tr+es+b+y,Scope='fit residual score at selected short-chain point, NOT Bayesian evidence or model probability'))
        for phase in ['canopy_transpiration','biomass_yield']:diags.append(pd.read_csv(ROOT/'calibration'/scenario/phase/'Pilot_parameter_diagnostics.csv'))
        engine=Engine(scenario,True,tag='response');engine.install()
        try:
            for point,frac in enumerate(np.linspace(0,1,201)):
                ss,w,gg=engine.run(engine.base*frac,True)
                curves.append(dict(Point=point,Fraction_of_DI=frac,**{k:v for k,v in ss.items() if k!='irrigation_events'}))
            end=curves[-1]
            assert abs(end['Irrigation_mm']-633.47)<1e-8 and abs(end['Y_13pct']-s['Y_13pct'])<1e-8
        finally:engine.restore()
        tracer=TraceEngine(scenario,True)
        for label,amount in [('I000',0.),('I050',316.735),('I400',400.),('I075',475.1025),('I100',633.47)]:
            row=tracer.trace(scenario+'_'+label,amount);row.update(Mulch_scenario=scenario,fMulch=f,Irrigation_scenario=label);stress.append(row)
        print('EXPORTED',scenario,'Y13',s['Y_13pct'],'Es',s['Es_mm'],'CC RMSE',cm['RMSE'],flush=True)
    pd.DataFrame(fit).to_csv(T/'Calibrated_DI_fit_summary.csv',index=False);pd.DataFrame(md).to_csv(T/'Calibration_fit_metrics.csv',index=False)
    pd.DataFrame(parameters).to_csv(T/'Selected_parameters_all_scenarios.csv',index=False);pd.concat(diags,ignore_index=True).to_csv(T/'All_MCMC_parameter_diagnostics.csv',index=False)
    pd.DataFrame(likelihood).to_csv(T/'Descriptive_fit_residual_scores.csv',index=False);pd.DataFrame(curves).to_csv(T/'All_proportional_responses.csv',index=False)
    pd.DataFrame(stress).to_csv(T/'All_stress_storage_summaries.csv',index=False)
    # Exact diagnostic amounts, avoiding 201-point-grid rounding near 300/350/400.
    exact=[]
    for scenario in SCENARIOS:
        engine=Engine(scenario,True,tag='exact_doses');engine.install()
        try:
            for amount in [0,300,316.735,350,400,475.1025,633.47]:
                ss=engine.run(engine.base*(amount/633.47));exact.append(dict(Requested_mm=amount,**{k:v for k,v in ss.items() if k!='irrigation_events'}))
        finally:engine.restore()
    pd.DataFrame(exact).to_csv(T/'Exact_300_350_400_response_checks.csv',index=False)
    snap=ROOT/'model_snapshots/DI_PHASE3_NEXTGEN_UPDATED/real_model';snap.mkdir(parents=True,exist_ok=True)
    shutil.copytree(SOURCE.parent,snap/'model_2021',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','MCMC_Article_Results_2021'))
    for name in ['four_year_adapter.py','numerical_acceleration.py','root_zone_kernel.py','physical_kernels.py','KERNEL_ARGUMENTS.json']:shutil.copy2(PROJECT/'real_model'/name,snap/name)
    dump(ROOT/'verification/EXPORT_STATUS.json',dict(Status='COMPLETE',Scenarios=3,Proportional_response_evaluations=603,Daily_stress_replays=15,Exact_amount_replays=21,
        No_MCMC_uncertainty_propagation=True,Source_moisture_unchanged=True,Root_max_m=1.,Mulch_pct=75.))

if __name__=='__main__':main()
