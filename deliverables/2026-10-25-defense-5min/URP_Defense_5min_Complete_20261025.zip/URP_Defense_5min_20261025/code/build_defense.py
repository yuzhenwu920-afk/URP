"""Build an editable 16:9 deck: eight timed main slides and four backup slides."""
from pathlib import Path
import json,math,re
import pandas as pd
from PIL import Image
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN,MSO_ANCHOR,MSO_AUTO_SIZE
from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
from docx import Document
from docx.shared import Cm
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'documents';DATA=ROOT/'data';FIG=ROOT/'figures'
W,H=13.333333,7.5
FONT='Noto Sans CJK SC';LATIN='DejaVu Sans'
BG='F6F8F5';WHITE='FFFFFF';INK='163D3B';TEAL='0C7B74';MUTED='647C77';LINE='D9E4DC';GOLD='D39A43';PALE='E7F1EC';DARK='112F2F';RED='CF6551'
YC={2019:'287BA3',2020:'CE892E',2021:'2A9178',2022:'9565A6'}
prs=Presentation();prs.slide_width=Inches(W);prs.slide_height=Inches(H)
prs.core_properties.title='膜下滴灌玉米灌溉制度优化｜URP五分钟答辩'
prs.core_properties.author='吴雨臻；李承昊；段璞';prs.core_properties.subject='8 main slides, 300 seconds; 4 backup slides; verified five-stage results'
SCRIPTS=[
('膜下滴灌玉米灌溉制度优化',15,'各位老师好，我们汇报的主题是膜下滴灌玉米灌溉制度优化。研究围绕四年资料，连接参数校准、敏感性分析与五期灌水优化，并用水量核算解释结果。'),
('把灌水、生长与储水放在一起评价',35,'研究采用甘肃武威2019至2022年膜下滴灌玉米既有观测资料。四年灌水量约为405至633毫米，产量约为14.08至17.29吨每公顷。我们整理了48个冠层覆盖度配对和37个生物量配对，并接入气象、土壤及灌水日程。研究主要回答三个问题：需要灌多少水，在哪些生育期灌，以及较低灌水量下支撑产量的水来自哪里。'),
('两阶段校准，连接敏感性与五期决策',40,'技术路线分三步。首先，两阶段MCMC先利用冠层和耗水指标确定五个参数，再利用生物量和产量确定三个生产参数。其次，Sobol在共同独立参数范围内比较四年敏感性。最后，使用两种遗传算法求解产量与实际灌水量的权衡。五个生育期各设最多三次可选灌水，零水量取消，同时优化十五个水量和十五个日期。主分析保持原模型物理设定，结构补充试验单列。'),
('多指标拟合再现四年主要生长过程',45,'左图展示冠层覆盖度，右图展示地上生物量，颜色区分四个年份。大部分配对点接近一比一线。四年冠层拟合决定系数为0.931至0.993，生物量为0.969至0.997；年度产量相对偏差为负4.18%至正0.92%。这些结果描述了参数中心对生长和产量的拟合效果。我们同时单独检查了原链，发现有效样本量仍需提高，因此将过程拟合与分布采样精度分别报告。'),
('产量主导参数的年度排序保持一致',35,'敏感性分析表明，四年年平均结果中，晚期水分生产率、收获指数、早期水分生产率和基础作物系数的排序保持一致，但贡献幅度存在年际变化。晚期水分生产率的总效应指数四年均值为0.396，位居首位。这里的平均是共同独立输入范围下的四年等权描述，保留逐年结果共同解释。'),
('五期优化形成四年灌水—产量候选前沿',50,'这页给出四年的产量与灌水权衡。蓝色虚线连接全范围搜索得到的非支配解，星号是原DI模型基准，橙圈是正式搜索按95%观测产量门槛选出的候选。四年候选灌水量分别约为210、306、264和257毫米。每个候选都对应完整的逐次日期和水量。两种遗传算法获得相近的最低灌水区间。面对看起来很大的减灌幅度，我们进一步追踪水量来源，而不是只用这张图直接给出田间定额。'),
('储水核算解释低灌水高产平台',55,'水量核算是解释结果的关键。左图把减灌量拆分为蒸散变化、季末储水差和其他损失差。四年蒸散仅下降1.89%至5.98%，季末储水差则解释了81.09%至96.72%的减灌量。以2021年为例，少灌368.97毫米，其中356.85毫米对应季末储水差，11.46毫米对应蒸散减少，其他差额约0.66毫米。因此，较低灌水候选主要利用了基准日程增储与初始土壤水的缓冲。后续田间方案应配套季末储水及设备供水条件。'),
('过程可复现，决策可细化，机制可解释',25,'我们完成了四年多指标校准、敏感性分析和五期逐次灌水优化，并通过储水核算明确减灌量的组成。下一步重点提升采样精度，结合季末储水、单次供水能力和灌水间隔细化实施方案。感谢各位老师，请批评指正。'),
]
def rgb(c):return RGBColor.from_string(c)
def shape(s,x,y,w,h,fill=WHITE,line=None,rounding=False):
 o=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if rounding else MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h));o.fill.solid();o.fill.fore_color.rgb=rgb(fill)
 if line:o.line.color.rgb=rgb(line);o.line.width=Pt(.8)
 else:o.line.fill.background()
 if rounding:
  try:o.adjustments[0]=.12
  except Exception:pass
 return o
def txt(s,text,x,y,w,h,size=20,color=INK,bold=False,align=PP_ALIGN.LEFT,font=FONT,valign=MSO_ANCHOR.TOP):
 o=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=o.text_frame;tf.clear();tf.word_wrap=True;tf.auto_size=MSO_AUTO_SIZE.NONE;tf.margin_left=Pt(0);tf.margin_right=Pt(0);tf.margin_top=Pt(0);tf.margin_bottom=Pt(0);tf.vertical_anchor=valign
 for i,t in enumerate(str(text).split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.alignment=align;p.space_before=Pt(0);p.space_after=Pt(0);p.line_spacing=1.12;r=p.add_run();r.text=t;r.font.name=font;r.font.size=Pt(size);r.font.bold=bold;r.font.color.rgb=rgb(color)
 return o
def line(s,x1,y1,x2,y2,color=LINE,width=1):
 a=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2));a.line.color.rgb=rgb(color);a.line.width=Pt(width);return a
def ellipse(s,x,y,w,h,fill=None,edge=None,width=1):
 o=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x),Inches(y),Inches(w),Inches(h))
 if fill:o.fill.solid();o.fill.fore_color.rgb=rgb(fill)
 else:o.fill.background()
 if edge:o.line.color.rgb=rgb(edge);o.line.width=Pt(width)
 else:o.line.fill.background()
 return o
def new(title,tag,index,source='',backup=False):
 s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=rgb(BG)
 txt(s,tag,.56,.25,11,.27,10,MUTED,True,font=LATIN);txt(s,title,.56,.70,12.25,.62,30,INK,True);shape(s,.56,1.37,.65,.035,TEAL)
 footer(s,index,source,backup);return s
def footer(s,index,source='',backup=False,dark=False):
 c='AEC8BF' if dark else MUTED
 txt(s,source if source else 'URP 2026  ·  2019–2022 DI MAIZE',.56,7.17,11.3,.2,9.3,c,font=FONT)
 txt(s,f'B{index} / B4' if backup else f'{index:02d} / 08',12.0,7.13,.76,.27,11,c,align=PP_ALIGN.RIGHT,font=LATIN)
def pic(s,name,x,y,w,h):
 p=FIG/(name+'.png');im=Image.open(p);ratio=im.width/im.height;ww=min(w,h*ratio);hh=ww/ratio;return s.shapes.add_picture(str(p),Inches(x+(w-ww)/2),Inches(y+(h-hh)/2),width=Inches(ww),height=Inches(hh))
def ribbon(s,text,y=6.39,fill=PALE,color=TEAL):shape(s,.56,y,12.2,.56,fill,rounding=True);txt(s,text,.79,y+.11,11.75,.34,17,color,True)
def notes(s,index,extra=''):
 title,seconds,speech=SCRIPTS[index-1];start=sum(a[1] for a in SCRIPTS[:index-1]);end=start+seconds
 stamp=lambda t:f'{t//60:02d}:{t%60:02d}'
 s.notes_slide.notes_text_frame.text=f'主讲第{index}页｜{title}\n时间：{stamp(start)}—{stamp(end)}（{seconds}秒）\n\n【口播稿】\n{speech}\n\n【数据与切页提示】\n{extra}\n主讲第8页结束即为5分钟。后续为备答页，按提问选择。'

def cover():
 s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=rgb(DARK)
 shape(s,8.06,0,W-8.06,H,'193E3B');txt(s,'URP 2026  /  RESEARCH DEFENSE',.66,.48,7,.32,12,'B9D4C8',True,font=LATIN)
 shape(s,.68,1.38,.66,.065,GOLD);txt(s,'膜下滴灌玉米\n灌溉制度优化',.65,1.72,7.0,1.95,42,WHITE,True)
 txt(s,'四年两阶段MCMC · Sobol · 五生育期逐次灌水',.69,4.00,7.0,.85,21,'D6E7DE')
 txt(s,'吴雨臻  李承昊  段璞',.70,5.63,6.9,.38,19,WHITE);txt(s,'指导教师：廖人宽  ·  中国农业大学',.70,6.12,6.9,.34,14,'B9D4C8')
 txt(s,'项目：基于马尔科夫链的不同灌溉方式灌溉制度优化',.70,6.71,7.0,.34,11.5,'9FBCB1')
 for j in range(5):line(s,8.38,5.05+j*.27,12.92,5.05+j*.27,'315953',.7)
 for j in range(3):
  ellipse(s,8.95+j*.34,1.09+j*.33,3.1-j*.62,3.1-j*.62,None,'315C55',1)
 stages=['苗期','拔节期','抽穗期','灌浆期','成熟期']
 pts=[(8.58,4.64),(9.34,4.11),(10.07,3.65),(10.83,3.15),(11.64,2.77)]
 for i,(x,y) in enumerate(pts):
  if i:line(s,*pts[i-1],x,y,'80BAA4',2)
  ellipse(s,x-.085,y-.085,.17,.17,GOLD if i==4 else 'B9D9C4');line(s,x,y+.2,x,5.08,'4D8775',.8);txt(s,stages[i],x-.26,y+.3,.9,.3,13,'D0E3D6')
 txt(s,'5 STAGES',8.55,5.92,3.7,.50,29,WHITE,True,font=LATIN);txt(s,'从参数校准到可解释的灌溉决策',8.55,6.49,4.1,.35,15,'B9D4C8')
 footer(s,1,'2026.10.25  ·  项目编号 X2026100190937',dark=True);notes(s,1,'本次汇报聚焦DI玉米，正式项目名称保留原立项名称。')

def data_slide():
 s=new('把灌水、生长与储水放在一起评价','RESEARCH QUESTION  /  STUDY DATA',2,'田间资料[1]；CC由LAI换算，生物量由已发表图件数字化；气象与辅助遥感资料分别归档。')
 txt(s,'甘肃武威 · 膜下滴灌玉米',.66,1.70,6.1,.45,22,TEAL,True)
 txt(s,'灌多少水？\n何时灌水？\n水从哪里来？',.66,2.40,6.2,2.55,30,INK,True)
 for x,n,label in [(0.68,'4','年度资料'),(2.65,'48','CC配对'),(4.72,'37','生物量配对')]:
  txt(s,n,x,5.20,1.7,.6,31,TEAL,True,font=LATIN);txt(s,label,x,5.93,1.75,.35,15,MUTED)
 shape(s,7.25,1.66,5.43,4.98,WHITE,LINE,True);txt(s,'四年田间观测',7.52,1.95,4.85,.45,21,INK,True)
 txt(s,'年份',7.56,2.65,.9,.32,15,MUTED);txt(s,'灌水量 / mm',8.68,2.65,1.6,.32,15,MUTED);txt(s,'产量 / t·ha⁻¹',10.55,2.65,1.8,.32,15,MUTED)
 d=pd.read_csv(DATA/'FiveStage_Four_year_result_comparison.csv')
 for i,r in enumerate(d.itertuples()):
  yy=3.20+i*.68;line(s,7.53,yy-.16,12.36,yy-.16,LINE,.6);txt(s,str(r.Year),7.57,yy,.95,.4,20,YC[r.Year],True,font=LATIN);txt(s,f'{r.Original_I_mm:.2f}',8.85,yy,1.4,.4,20,INK,font=LATIN);txt(s,f'{r.Observed_Y13:.2f}',10.78,yy,1.4,.4,20,INK,font=LATIN)
 txt(s,'既有观测资料[1]  ·  产量按13%含水率表示',7.55,6.14,4.85,.28,12.2,MUTED)
 notes(s,2,'2019/20/21/22原季节灌水量445.27/559.76/633.47/404.84 mm。请直接概括范围，无需逐行朗读。完整数据来源仅在参考文献中按编号说明。')

def methods_slide():
 s=new('两阶段校准，连接敏感性与五期决策','METHODS  /  FROM OBSERVATION TO DECISION',3,'方法：[3–6,8,9]；主模型固定原参数结构、年度天气与初始含水量，补充结构试验单列。')
 blocks=[('01','两阶段MCMC','先定冠层与耗水\n再定生物量与产量','阶段一 5参数｜阶段二 3参数\n每组32 walkers × 2000步'),('02','Sobol敏感性','识别主导参数\n比较年度稳定性','8参数 × 6输出\nN=512 × 3个随机化序列'),('03','五期遗传优化','NSGA-III / NSGA-II\n联合调整日期与水量','每期0–3次｜零量取消\n15个水量＋15个日期')]
 for j,(num,title,body,small) in enumerate(blocks):
  x=.56+j*4.15;shape(s,x,1.73,3.91,2.95,WHITE,LINE,True);txt(s,num,x+.23,1.95,1,.43,22,TEAL,True,font=LATIN);txt(s,title,x+.23,2.55,3.48,.44,24,INK,True);txt(s,body,x+.23,3.19,3.48,.79,19,INK);txt(s,small,x+.23,4.04,3.48,.53,12.6,MUTED)
  if j<2:txt(s,'→',x+3.92,2.88,.23,.38,21,TEAL,True)
 txt(s,'五生育期',.60,5.09,1.6,.4,18,INK,True)
 for j,label in enumerate(['苗期','拔节期','抽穗期','灌浆期','成熟期']):
  x=2.17+j*2.12;shape(s,x,5.00,1.96,.59,PALE,rounding=True);txt(s,label,x+.04,5.10,1.88,.35,18,TEAL,True,PP_ALIGN.CENTER)
 ribbon(s,'固定主设定：覆膜75%  ·  fMulch=0结构基线  ·  最大根深2.30 m',6.18)
 notes(s,3,'主模型是四年原始结构，fMulch=0为关闭额外蒸发抑制的复现基线。2021年1 m根深与fMulch条件拟合不是此页主模型。正式和全范围优化共457,596次目标查询。')

def calibration_slide():
 s=new('多指标拟合再现四年主要生长过程','RESULT 01  /  MCMC CALIBRATION',4,'校准配对：48个CC、37个生物量；R²cal=1−SSE/SST；原链采样诊断另列备答1。')
 pic(s,'P04_Calibration_EN',.52,1.62,9.05,4.66)
 for y,num,label,size in [(1.95,'0.931–0.993','CC年度 R²cal',23),(3.25,'0.969–0.997','生物量年度 R²cal',23),(4.55,'−4.18%–0.92%','年度产量相对偏差',18)]:
  shape(s,9.83,y-.13,2.85,1.1,WHITE,LINE,True);txt(s,num,10.04,y,2.47,.4,size,TEAL,True,font=LATIN);txt(s,label,10.04,y+.51,2.47,.32,14.5,MUTED)
 ribbon(s,'过程拟合与分布采样精度分别评价；参数中心用于本轮确定性模拟')
 notes(s,4,'图中虚线为1:1线。R²cal区间由年度源表计算，非图中汇总散点的OLS R²。主讲说明“有效样本量仍需提高”，详细Rhat与ESS在备答1。')

def sobol_slide():
 s=new('产量主导参数的年度排序保持一致','RESULT 02  /  SOBOL SENSITIVITY',5,'共同独立均匀输入范围；N=512 × 3随机化序列；四年61,440次模型评估。')
 pic(s,'P05_Sobol_EN',.64,1.65,12.04,4.6)
 ribbon(s,'晚期WP → HI0 → 早期WP → Kcb：年平均排序一致，贡献幅度存在年际变化')
 notes(s,5,'ST并非百分比份额，不要求求和为1。图左为逐年三个随机化序列的平均，图右再对四年等权平均；这是公共独立范围敏感性，不是相关后验敏感性。')

def pareto_slide():
 s=new('五期优化形成四年灌水—产量候选前沿','RESULT 03  /  FIVE-STAGE NSGA-III',6,'全范围展示前沿：3种子×80个体×60代/年；正式95%门槛候选：5种子最终种群可行非支配解并集。')
 pic(s,'P06_Pareto_EN',.48,1.56,9.20,4.78)
 txt(s,'95%观测产量门槛下',9.93,1.70,2.74,.38,16,MUTED,True)
 d=pd.read_csv(DATA/'FiveStage_Four_year_result_comparison.csv')
 for i,r in enumerate(d.itertuples()):
  yy=2.24+i*.91;shape(s,9.88,yy,2.82,.80,WHITE,LINE,True);txt(s,str(r.Year),10.05,yy+.10,.8,.30,15,YC[r.Year],True,font=LATIN);txt(s,f'{r.Optimized_I_mm:.2f}',10.94,yy+.08,1.55,.40,25,INK,True,font=LATIN);txt(s,'mm',12.02,yy+.52,.45,.22,11,MUTED,font=LATIN)
 ribbon(s,'每期0–3次，日期与水量联合调整；候选对应完整的逐次灌水日程')
 notes(s,6,'95%是确定产量水平门槛，不是95%保证概率。蓝线展示补充全范围搜索，橙圈来自正式搜索，二者来源分别说明。棕色点线为95%观测产量参考。所有图显示未经任意平滑的原计算解连线。')

def water_slide():
 s=new('储水核算解释低灌水高产平台','MECHANISM  /  WATER ACCOUNTING',7,'对照保持同一年天气、参数中心和初始水分；储水核算范围为相同0–2.4 m模拟剖面。')
 pic(s,'P07_Water_components_EN',.55,1.65,7.52,4.62)
 shape(s,8.40,1.79,4.27,4.31,WHITE,LINE,True);txt(s,'2021 水量账',8.67,2.01,3.72,.4,23,INK,True)
 txt(s,'少灌 368.97 mm',8.67,2.63,3.72,.55,29,TEAL,True);line(s,8.67,3.34,12.38,3.34,LINE,.8)
 for yy,num,label,col in [(3.62,'356.85','季末储水差 / mm',TEAL),(4.43,'11.46','ET下降 / mm',GOLD),(5.23,'0.66','其他损失差 / mm',MUTED)]:
  txt(s,num,8.67,yy,1.72,.45,26,col,True,font=LATIN);txt(s,label,10.46,yy+.10,1.95,.31,14.5,MUTED)
 ribbon(s,'ET下降1.89%–5.98%；季末储水差解释81.09%–96.72%的减灌量')
 notes(s,7,'2021年：原633.47、候选264.499975 mm，差368.970025 mm。储水差356.853567、ET差11.459783、其他差0.656675 mm。正文约数0.66+11.46+356.85=368.97。原初始535.70 mm，原日程终值705.67，候选348.82 mm。')

def conclusion_slide():
 s=new('过程可复现，决策可细化，机制可解释','CONCLUSIONS  /  NEXT STEP',8,'项目组：吴雨臻、李承昊、段璞  ·  指导教师：廖人宽  ·  中国农业大学')
 for i,(num,title,body) in enumerate([('01','过程可复现','四年多指标校准\n主要生长与产量轨迹'),('02','决策可细化','五期、逐次日期与水量\n形成完整候选日程'),('03','机制可解释','分解减灌量的组成\n明确储水缓冲的作用')]):
  x=.56+i*4.15;shape(s,x,1.88,3.91,2.65,WHITE,LINE,True);txt(s,num,x+.23,2.12,.9,.45,24,TEAL,True,font=LATIN);txt(s,title,x+.23,2.88,3.45,.43,23,INK,True);txt(s,body,x+.23,3.55,3.45,.74,18,MUTED)
 txt(s,'下一步',.64,5.00,1.5,.39,19,TEAL,True);txt(s,'提升采样精度，结合季末储水、单次供水能力与灌水间隔细化实施方案。',2.08,4.98,10.36,.86,20,INK)
 shape(s,.56,6.18,12.2,.66,TEAL,rounding=True);txt(s,'感谢各位老师，恳请批评指正',.75,6.31,11.8,.40,22,WHITE,True,PP_ALIGN.CENTER)
 notes(s,8,'按计划5分钟结束。后面4页为备答，不主动展开；根据老师提问跳转。')

def backup_diagnostic():
 s=new('备答1｜模型设定与原链诊断','BACKUP  /  SETTINGS AND SAMPLING',1,'诊断：[15]；按时间轴比较独立ensemble的同编号walker组，组间依赖不作简单累加。',True)
 txt(s,'主模型固定设置',.66,1.77,4.5,.42,22,TEAL,True)
 for i,v in enumerate(['覆膜覆盖率 75%','fMulch = 0：结构复现基线','Zmin = 0.30 m；Zmax = 2.30 m','模拟土壤剖面深度 2.4 m','第一阶段4组；第二阶段1组/年']):txt(s,v,.68,2.47+i*.53,5.65,.40,18,INK)
 shape(s,6.64,1.73,6.05,4.37,WHITE,LINE,True);txt(s,'四年第一阶段时间序列诊断',6.91,1.99,5.52,.42,21,INK,True)
 for x,t,w in [(6.96,'年份',1),(8.22,'最差 R̂',1.6),(10.13,'最小组 bulk ESS',2.3)]:txt(s,t,x,2.67,w,.34,14.5,MUTED,True)
 d=pd.read_csv(DATA/'Actual_sampling_diagnostics_and_center_stability.csv');d=d[d.Phase==1]
 for i,r in enumerate(d.itertuples()):
  y=3.23+i*.56;line(s,6.94,y-.10,12.36,y-.10,LINE,.6);txt(s,str(r.Year),6.96,y,1,.34,18,YC[r.Year],True,font=LATIN);txt(s,f'{r.Maximum_Rhat:.3f}',8.34,y,1.45,.34,18,INK,font=LATIN);txt(s,f'{r.Minimum_group_bulk_ESS:.2f}',10.60,y,1.57,.34,18,INK,font=LATIN)
 txt(s,'参考：R̂ < 1.01；bulk/tail ESS ≥ 400',6.94,5.64,5.4,.30,13.2,MUTED)
 ribbon(s,'参数中心的过程拟合与分布采样精度分开报告；后续重点提升有效样本量')
 s.notes_slide.notes_text_frame.text='【备答，不计入5分钟】\n四年阶段一均未达到原严格采样参考标准；不能以多条walker展平后充当独立长链。阶段二每年仅一个独立ensemble，链间一致性无法按同一方式评价。主结果使用原保留均值作确定性模拟。2021年根深1 m与不同fMulch条件重校准是独立补充试验，不替代本页四年主设定。'

def backup_calendar():
 s=new('备答2｜每次灌水日期与水量均已输出','BACKUP  /  INDIVIDUAL-EVENT CALENDAR',2,'42条正水量记录完整保留；≥0.1 mm事件数另计。完整日期、水量及五期合计见随附数据工作簿。',True)
 pic(s,'B02_Irrigation_calendar_EN',.57,1.64,12.15,4.69)
 ribbon(s,'2021年 ≥0.1 mm：6/15 92.959 mm；6/28 85.822 mm；7/29 85.634 mm')
 s.notes_slide.notes_text_frame.text='【备答，不计入5分钟】\n图件显示全部正水量事件，包括微量正数。四年全部正事件数12、13、9、8；≥0.1 mm为8、8、3、6。每期最多3个可选槽位，零量取消、同日合并。2021年另有6个<0.1 mm微量事件；主方案计算未擅自删除，实施时应先加入最低可执行水量等设备条件后再评价。'

def backup_qa():
 s=new('备答3｜三个关键问题的回答口径','BACKUP  /  DISCUSSION',3,'回答依据：四年主结果、原链诊断、逐日水量账与条件结构试验；不混用不同模型设定。',True)
 rows=[('01','300 mm左右维持高产，是否过于理想？','固定初值与年度天气下，储水能够缓冲供水；2021年减灌中96.72%对应季末储水差。进一步结合季末储水、设备能力与间隔条件筛选田间方案。'),('02','MCMC的拟合好，是否就意味着链已收敛？','分别报告过程拟合、参数中心稳定性和时间序列诊断。原链bulk ESS偏低，后续结合可辨识性、独立初始化与误差结构提高采样精度。'),('03','为什么按五期优化，却有些期没有明显灌水？','五期对应田间生育进程；每期0–3次，零量允许取消。30维日期—水量控制空间由优化分配事件，不要求每期固定灌一次或灌满三次。')]
 for i,(n,q,a) in enumerate(rows):
  y=1.70+i*1.57;shape(s,.57,y,12.13,1.35,WHITE,LINE,True);txt(s,n,.79,y+.21,.75,.41,22,TEAL,True,font=LATIN);txt(s,q,1.67,y+.18,10.65,.39,20,INK,True);txt(s,a,1.67,y+.72,10.65,.53,15.3,MUTED)
 s.notes_slide.notes_text_frame.text='【备答，不计入5分钟】\n先给出问题的直接结论，再引用对应数据。不要将减灌量直接解释成ET节约，不将95%产量门槛说成概率保证，不把公共独立范围Sobol说成相关后验敏感性，不把1 m覆膜试验混成四年原模型。'

def backup_refs():
 s=new('主要参考文献与成果入口','REFERENCES  /  REPRODUCIBILITY',4,'编号沿用当前中英文论文；完整文献证据与数据来源随稿归档。',True)
 refs=json.loads((DATA/'REFERENCE_EVIDENCE.json').read_text());selected=[1,3,4,5,6,8,9,15];lookup={r['number']:r for r in refs}
 for i,n in enumerate(selected):
  j=i//4;k=i%4;x=.66+j*6.23;y=1.70+k*1.13;r=lookup[n]
  text=r.get('CN','')
  if r.get('DOI'):text+=' DOI: '+r['DOI']
  txt(s,f'[{n}]',x,y,.49,.3,12.5,TEAL,True,font=LATIN);txt(s,text,x+.55,y,5.34,1.03,11.5,INK)
 shape(s,.57,6.35,12.12,.58,PALE,rounding=True);link=txt(s,'完整论文、原始资料与代码：GitHub · yuzhenwu920-afk/URP',.80,6.47,11.65,.33,16,TEAL,True)
 link.text_frame.paragraphs[0].runs[0].hyperlink.address='https://github.com/yuzhenwu920-afk/URP/tree/delivery/urp-review-20261015/deliverables/2026-10-23-unified-update'
 s.notes_slide.notes_text_frame.text='【备答，不计入5分钟】\n主要数据来源引用[1]，本项目完成资料整理、数值模型校准和分析。原资料作者的完整信息保留在本参考文献页；正文及主讲页以编号引用。可点击成果入口查找已核验的论文、逐查询数据和代码。'

def manuscripts():
 d=Document();sec=d.sections[0];sec.top_margin=sec.bottom_margin=Cm(1.8);sec.left_margin=sec.right_margin=Cm(2.0)
 normal=d.styles['Normal'];normal.font.name=FONT;normal.font.size=Pt(11);normal._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),FONT);normal.paragraph_format.line_spacing=1.3
 d.add_heading('URP五分钟答辩讲稿',0);d.add_paragraph('主讲8页，计划共300秒；PPT备注区已逐页嵌入同版讲稿。后4页为隐藏备答页，默认放映跳过；可在“查看所有幻灯片”中选择跳转。')
 table=d.add_table(rows=1,cols=4);table.style='Light Shading Accent 1'
 for c,t in zip(table.rows[0].cells,['主讲页','主题','用时','累计']):c.text=t
 total=0;rows=[]
 for i,(title,seconds,speech) in enumerate(SCRIPTS,1):
  total+=seconds;row=table.add_row().cells
  for c,t in zip(row,[str(i),title,f'{seconds}秒',f'{total//60}:{total%60:02d}']):c.text=t
  rows.append({'Slide':i,'Title':title,'Duration_seconds':seconds,'Cumulative_seconds':total,'Script':speech,'Chinese_characters':len(re.findall('[\u4e00-\u9fff]',speech))})
 for r in rows:
  d.add_heading(f'第{r["Slide"]}页｜{r["Title"]}（{r["Duration_seconds"]}秒）',1);d.add_paragraph(r['Script'])
 d.add_heading('备答口径',1)
 for s in list(prs.slides)[8:]:
  text=s.notes_slide.notes_text_frame.text;d.add_heading(s.shapes[1].text if len(s.shapes)>1 and s.shapes[1].has_text_frame else '备答',2);d.add_paragraph(text)
 d.add_heading('排练提示',1);d.add_paragraph('按每分钟约250–280字排练，先概括图中结论，再点出一组关键数字。第6页不逐行读四年数值；第7页重点解释2021水量账。主讲第8页结束即停，备答页只按提问打开。')
 d.save(OUT/'URP_5min_Speaker_Script_20261025.docx')
 pd.DataFrame(rows).to_csv(DATA/'Slide_timing_and_scripts.csv',index=False,encoding='utf-8-sig')
 (OUT/'URP_5min_Speaker_Script_20261025.md').write_text('# URP五分钟答辩讲稿\n\n'+ '\n\n'.join(f'## {r["Slide"]}. {r["Title"]}｜{r["Duration_seconds"]}秒\n\n{r["Script"]}' for r in rows))
 return rows

def main():
 OUT.mkdir(exist_ok=True)
 for f in [cover,data_slide,methods_slide,calibration_slide,sobol_slide,pareto_slide,water_slide,conclusion_slide,backup_diagnostic,backup_calendar,backup_qa,backup_refs]:f()
 assert len(prs.slides)==12 and sum(s[1] for s in SCRIPTS)==300
 for s in list(prs.slides)[8:]:s._element.set('show','0')
 rows=manuscripts();path=OUT/'URP_Defense_5min_20261025.pptx';prs.save(path)
 (ROOT/'analysis/BUILD_SUMMARY.json').write_text(json.dumps({'Slides':12,'Main_slides':8,'Backup_slides':4,'Planned_main_seconds':300,'Chinese_script_characters':sum(r['Chinese_characters'] for r in rows),'Scientific_source':'Current citation-revised manuscript, five-stage multi-event results','New_model_runs':False},ensure_ascii=False,indent=2))
 print(path,flush=True)
 print('Main script Chinese characters:',sum(r['Chinese_characters'] for r in rows),flush=True)

if __name__=='__main__':main()
