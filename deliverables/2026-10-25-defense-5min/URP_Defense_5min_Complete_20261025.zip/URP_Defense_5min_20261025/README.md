# URP 五分钟答辩 · 2026-10-25

本套答辩以最新四年五生育期逐次灌水结果为依据，采用中文讲解、英文科学图表、深绿与米白的16:9版式。主体文字、卡片与布局均可编辑，图表同时提供高清PNG、矢量PDF/SVG和源数据。

## 文件

- `documents/URP_Defense_5min_20261025.pptx`：8页主讲＋4页隐藏备答。默认放映跳过备答，可在“查看所有幻灯片”中选择。
- `documents/URP_Defense_5min_20261025.pdf`：主讲8页PDF预览。
- `documents/URP_Defense_5min_With_Backup_20261025.pdf`：含备答的12页PDF。
- `documents/URP_5min_Speaker_Script_20261025.docx/pdf`：逐页中文讲稿、时间表与备答口径。讲稿也已嵌入PPT备注。
- `data/URP_Defense_Source_Data_20261025.xlsx`：12张来源表汇总；另保留原精度CSV。
- `figures/`：5组重新排版的英文科学图，均由真实数据绘制。
- `code/`：图表、PPT与讲稿生成脚本及核对脚本。

## 5分钟主讲安排

|页码|内容|建议用时|累计|
|---|---|---:|---:|
|1|标题与研究主题|15秒|0:15|
|2|科学问题与四年资料|35秒|0:50|
|3|两阶段MCMC—Sobol—五期优化|40秒|1:30|
|4|冠层、生物量和产量拟合|45秒|2:15|
|5|年度敏感性规律|35秒|2:50|
|6|四年产量—灌水前沿|50秒|3:40|
|7|水量来源与储水机制|55秒|4:35|
|8|结论与下一步|25秒|5:00|

讲稿约1100字，配合指图及切页排练。前沿页不逐行朗读四年数值，第7页重点解释2021水量账；第8页结束即停。

备答为：原链诊断与固定设置、每次灌水日程、三个关键问题、主要参考文献与成果入口。

## 科学口径

四年主模型沿用已归档设定：覆膜75%、fMulch=0结构基线、Zmax=2.30 m、2.4 m土壤剖面。2021年根深1 m与fMulch条件试验保持独立。五期各最多3个可选事件，同时优化15个水量与15个整数日期；95%为观测产量的确定水平门槛。正式候选取NSGA-III五种子最终种群并集，全范围展示前沿来自独立补充搜索。

四年候选灌水量209.83、306.50、264.50、257.47 mm。ET下降1.89%–5.98%，储水差解释81.09%–96.72%的减灌量。主讲明确将过程拟合与采样精度分开，备答保留真实原链诊断。

正文使用编号引文，原资料作者的完整信息在参考文献页保留。所有数字与最新中英文论文一致，本次仅制作答辩和重绘图表，无新增模型运行。

## 再生成

Python 3.12：python-pptx、python-docx、pandas、numpy、matplotlib、Pillow、openpyxl、PyMuPDF。PDF导出使用LibreOffice；字体为Noto Sans CJK SC，Windows上可整体替换为微软雅黑，附PDF可直接检查版式。

```bash
python code/make_figures.py
python code/build_defense.py
soffice --headless --convert-to pdf --outdir documents documents/URP_Defense_5min_20261025.pptx documents/URP_5min_Speaker_Script_20261025.docx
mkdir -p analysis/full_preview
soffice --headless --convert-to 'pdf:impress_pdf_Export:{"ExportHiddenSlides":{"type":"boolean","value":"true"}}' --outdir analysis/full_preview documents/URP_Defense_5min_20261025.pptx
cp analysis/full_preview/URP_Defense_5min_20261025.pdf documents/URP_Defense_5min_With_Backup_20261025.pdf
python code/validate_defense.py
```

计算结果版本：`20f1616556f5aeb79329b7ead22faa28f9fcda6a`；论文资料版本：`c6649028a4cbb37c5f587921fb4887880c34ddd6`。来源、放映时间、备注、版面与水量核对结果见数据和验收JSON。
