"""English figures: no smoothing, invented uncertainties, or convergence claims."""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.lines import Line2D
from pilot_engine import ROOT
T=ROOT/'tables';F=ROOT/'figures';REG=[]
BLUE='#0072B2';GREEN='#009E73';ORANGE='#D55E00';DARK='#273E49';GREY='#9BAAB3'
PHASES=['canopy_transpiration','biomass_yield'];COLORS=[BLUE,ORANGE,GREEN,'#A45A9D']
LABELS={'CCx':r'$CC_x$','CGC_CD':r'$CGC_{CD}$','CDC_CD':r'$CDC_{CD}$','SenescenceCD':'Senescence (day)','Kcb':r'$K_{cb}$','WP_early':r'$WP_{early}$','WP_late':r'$WP_{late}$','HI0':r'$HI_0$'}

def read(name):return pd.read_csv(T/(name+'.csv'))
def style(ax):ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.15,zorder=0)
def save(fig,name,title,interpretation,boundary,tables):
    for ext in ['png','pdf','svg']:fig.savefig(F/(name+'.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig);REG.append(dict(ID=name,Title=title,Interpretation_CN=interpretation,Boundary_CN=boundary,Source_tables=tables))

def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11.5,'axes.titlesize':12.5,'axes.labelsize':12,
        'xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':9.5,'pdf.fonttype':42,'svg.fonttype':'none'})
    initial=read('Initial_root1m_daily_growth');g=read('Phase2_pilot_daily_growth');cc=read('Phase2_pilot_CC_fitted_pairs')
    metrics=read('Fit_metrics');cm=metrics[(metrics.Scenario=='Phase2_pilot')&(metrics.Variable=='CC')].iloc[0]
    fig,axs=plt.subplots(1,2,figsize=(10.5,4.35),width_ratios=[1.4,1],layout='constrained')
    a=axs[0];a.plot(pd.to_datetime(initial.Date),initial.canopy_cover,color=GREY,lw=1.5,ls='--',label='Initial point, root depth 1 m')
    a.plot(pd.to_datetime(g.Date),g.canopy_cover,color=BLUE,lw=2,label='Calibrated pilot point')
    a.scatter(pd.to_datetime(cc.Date),cc.Observed_CC,s=38,facecolor='white',edgecolor=DARK,lw=1.2,zorder=4,label='Field LAI-derived CC')
    a.set(ylim=(0,1.04),xlabel='Date in 2021',ylabel='Canopy cover (fraction)',title='(a) Canopy-cover calibration')
    a.xaxis.set_major_locator(mdates.MonthLocator());a.xaxis.set_major_formatter(mdates.DateFormatter('%b'));a.legend(loc='upper left',fontsize=8.5)
    a=axs[1];a.plot([0,1],[0,1],ls='--',color=GREY,lw=1.2,label='1:1 line');a.scatter(cc.Observed_CC,cc.canopy_cover,color=BLUE,s=40,alpha=.85)
    a.set(xlim=(0,1.03),ylim=(0,1.03),xlabel='Observed CC',ylabel='Simulated CC',title='(b) Fitted observation pairs');a.set_aspect('equal')
    a.text(.05,.95,f'n = {int(cm.N)}\nRMSE = {cm.RMSE:.4f}\nFit $R^2$ = {cm.NSE_R2:.3f}\nPearson r = {cm.Pearson_r:.3f}',transform=a.transAxes,va='top',fontsize=10,bbox=dict(fc='white',ec='none',alpha=.8))
    for a in axs:style(a)
    save(fig,'P01_CC_fit_2021_root1m','2021 canopy-cover fit with maximum root depth fixed at 1 m',
        '左图将原起点和新校准试跑的逐日CC与田间LAI换算CC配对；右图展示实测与模拟的一致性，并列出RMSE、拟合R²和Pearson r。',
        'CC是校准资料而非独立验证；未把短链分布当作正式可信区间。拟合R²=1−SSE/SST，与Pearson r²不同。',
        ['Phase2_pilot_CC_fitted_pairs.csv','Phase2_pilot_daily_growth.csv','Fit_metrics.csv'])
    y=read('Yield_and_water_comparison');bio=read('Phase2_pilot_Biomass_fitted_pairs')
    fig,axs=plt.subplots(1,2,figsize=(10.5,4.5),layout='constrained');a=axs[0]
    values=[y.iloc[0].Y_13pct,y.iloc[-1].Y_13pct];a.bar([0,1],values,color=[GREY,BLUE],width=.55,zorder=3)
    a.axhline(15.86,color=ORANGE,ls='--',lw=1.4,label='Observed DI yield: 15.86')
    for i,v in enumerate(values):a.text(i,v-.38,f'{v:.3f}\n{100*(v/15.86-1):+.2f}%',ha='center',va='top',fontsize=10,color='white',fontweight='bold')
    a.set(xticks=[0,1],xticklabels=['Initial point\n(root depth 1 m)','Calibrated\nshort-chain pilot'],ylim=(0,max(18,max(values)+2)),ylabel=r'Grain yield at 13% moisture (t ha$^{-1}$)',title='(a) Yield agreement under observed DI');a.legend(loc='upper left',fontsize=8.5)
    a=axs[1];a.plot(pd.to_datetime(g.Date),g.Biomass_t_ha,lw=2,color=BLUE,label='Calibrated pilot point')
    a.errorbar(pd.to_datetime(bio.Date),bio.Observed_B_t_ha,yerr=bio.Sigma_assumed,fmt='o',mfc='white',mec=DARK,ecolor=GREY,capsize=3,ms=5,label='Digitized biomass ± assumed sigma')
    a.set(xlabel='Date in 2021',ylabel=r'Aboveground dry biomass (t ha$^{-1}$)',title='(b) Conditional biomass calibration')
    a.xaxis.set_major_locator(mdates.MonthLocator());a.xaxis.set_major_formatter(mdates.DateFormatter('%b'));a.legend(loc='upper left',fontsize=8.4)
    for a in axs:style(a)
    save(fig,'P02_Yield_and_biomass','Yield agreement and conditional biomass fit for the 2021 pilot',
        '左图比较1m根深下原起点与两阶段试跑最终参数的产量，并以文献15.86t/ha标出差异；右图给出条件阶段二的生物量拟合。',
        '产量进入阶段二似然，属于样本内拟合；生物量误差条是原代码假设sigma，不是实测标准差。原内部产量靶值15.862t/ha与论文显示精度15.86同时保留。',
        ['Yield_and_water_comparison.csv','Phase2_pilot_Biomass_fitted_pairs.csv'])
    diag=read('All_parameter_boundary_and_mixing_checks')
    arrays={phase:np.load(ROOT/'runs'/phase/'pilot_arrays.npz') for phase in PHASES}
    fig,axs=plt.subplots(2,4,figsize=(12.6,6.3),layout='constrained')
    for a,(_,r) in zip(axs.ravel(),diag.iterrows()):
        names=diag[diag.Phase==r.Phase].Parameter.tolist();j=names.index(r.Parameter);v=arrays[r.Phase]['raw'][:,250:,:,j].ravel()
        a.hist(v,bins=28,color=BLUE,alpha=.65,density=True,edgecolor='white',lw=.3)
        lo,hi=r.Prior_low,r.Prior_high;span=hi-lo
        a.axvspan(lo,lo+.01*span,color=ORANGE,alpha=.18);a.axvspan(hi-.01*span,hi,color=ORANGE,alpha=.18)
        a.axvline(r.Pilot_best_sample,color=ORANGE,lw=1.5,label='Selected pilot point');a.set_xlim(lo,hi)
        a.set_title(LABELS[r.Parameter],loc='left');a.set_xlabel('Parameter value');a.set_ylabel('Pilot draw density')
        a.text(.04,.95,f'Edge mass (1%):\nL {100*r.Mass_lower_1pct:.1f}% | U {100*r.Mass_upper_1pct:.1f}%',transform=a.transAxes,va='top',fontsize=8.1)
        a.tick_params(axis='x',labelsize=8.5);style(a)
    fig.suptitle('Boundary screening | last 250 of 500 steps; 10 walkers × 4 ensembles',fontsize=13)
    save(fig,'P03_Parameter_boundary_screen','Parameter-boundary screening of eight calibrated pilot parameters',
        '八个面板横轴完整显示先验范围；两侧淡橙色为各1%边界带，橙线为选中的短链样本点；角标给出边界带内样本质量。',
        '分布来自未确认收敛的短链，不能凭图宣称无撞墙。需同时查看选点距离、1%/5%边界质量、跨组Rhat与ESS；SenescenceCD在引擎内按原代码取整。',
        ['All_parameter_boundary_and_mixing_checks.csv','runs/*/pilot_retained_draws_last250.csv'])
    fig,axs=plt.subplots(4,2,figsize=(10.8,10),sharex=True,layout='constrained')
    for a,(_,r) in zip(axs.ravel(),diag.iterrows()):
        names=diag[diag.Phase==r.Phase].Parameter.tolist();j=names.index(r.Parameter);raw=arrays[r.Phase]['raw'][:,:,:,j]
        a.axvspan(0,250,color='#CAD3D8',alpha=.25)
        for e,color in enumerate(COLORS):
            a.plot(np.arange(1,501),raw[e],color=color,lw=.35,alpha=.11)
            a.plot(np.arange(1,501),raw[e].mean(axis=1),color=color,lw=1.1)
        a.set(ylabel=LABELS[r.Parameter],xlim=(0,500));a.set_title(f'Max group $\\hat R$ = {r.Rhat_max_matched_walker_groups:.2f}; min bulk ESS = {r.ESS_bulk_min:.1f}',fontsize=9.5,loc='left');style(a)
    for a in axs[-1]:a.set_xlabel('MCMC step')
    fig.legend(handles=[Line2D([],[],color=c,label=f'Independent ensemble {e+1}') for e,c in enumerate(COLORS)],loc='outside upper center',ncol=2,fontsize=9)
    save(fig,'P04_MCMC_trace_and_mixing','Short-chain traces and matched-walker mixing diagnostics',
        '淡线为各walker，粗线为同组walker均值；四种颜色为独立ensemble，灰区为试跑摘要排除的前250步。标题给出跨独立组匹配walker诊断的保守Rhat与ESS。',
        '同组walker相互耦合，未当成独立链。500步不满足原2000步正式要求；即便拟合好也不能自动认定收敛。',
        ['runs/canopy_transpiration/pilot_arrays.npz','runs/biomass_yield/pilot_arrays.npz','All_parameter_boundary_and_mixing_checks.csv'])
    c=read('Yield_irrigation_curve_0_to_observed');a0=c.iloc[0];a1=c.iloc[-1]
    fig,a=plt.subplots(figsize=(9.2,5.6),layout='constrained');z=c.sort_values('Irrigation_mm')
    a.plot(z.Irrigation_mm,z.Y_13pct,color=BLUE,lw=2.2,label='Proportional DI dose response, calibrated pilot')
    a.axhline(15.86,color=ORANGE,lw=1.2,ls='--',label='Observed DI yield (calibration target)')
    a.scatter([a0.Irrigation_mm],[a0.Y_13pct],s=70,facecolor='white',edgecolor=BLUE,lw=1.6,zorder=5,clip_on=False,label='Zero irrigation')
    a.scatter([a1.Irrigation_mm],[a1.Y_13pct],marker='*',s=155,color=BLUE,edgecolor=DARK,lw=.6,zorder=5,clip_on=False,label='Observed DI amount: 633.47 mm')
    a.annotate(f'0 mm: {a0.Y_13pct:.3f} t ha$^{{-1}}$',xy=(0,a0.Y_13pct),xytext=(14,14),textcoords='offset points',fontsize=10)
    a.annotate(f'633.47 mm: {a1.Y_13pct:.3f} t ha$^{{-1}}$',xy=(633.47,a1.Y_13pct),xytext=(-10,-30),textcoords='offset points',ha='right',fontsize=10)
    a.set(xlim=(0,633.47),ylim=(0,max(18.2,c.Y_13pct.max()*1.17)),xticks=[0,100,200,300,400,500,633.47],
        xticklabels=['0','100','200','300','400','500','633.47'],xlabel='Actual seasonal irrigation (mm)',
        ylabel=r'Grain yield at 13% moisture (t ha$^{-1}$)',title=r'2021 yield–irrigation response | calibrated pilot, $Z_{max}$ = 1.00 m')
    a.legend(loc='upper left',fontsize=9);style(a)
    save(fig,'P05_Yield_irrigation_0_to_actual','2021 yield–irrigation curve from zero to the actual DI amount',
        '采用本轮新校准参数逐点计算201个水量水平；灌水日期和原逐次比例不变，横轴用引擎实际执行量，严格从0到633.47mm，终点与新拟合DI回放一致。',
        '此图是固定比例剂量响应，不是NSGA-III帕累托前沿；零灌水仍有初始土壤水与143.32mm季节降雨，所以不强制零产量。低水量尚无独立田间验证。',
        ['Yield_irrigation_curve_0_to_observed.csv','Yield_irrigation_curve_actual_event_amounts.csv'])
    (ROOT/'FIGURE_REGISTRY.json').write_text(json.dumps(REG,ensure_ascii=False,indent=2))
    print('Created',len(REG),'English figure groups')

if __name__=='__main__':main()
