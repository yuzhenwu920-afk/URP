"""Replay fitted pilot point, verify exact engine, and compute 0..observed DI dose path."""
from pathlib import Path
import json,sys,copy,importlib.util,hashlib,shutil
import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from pilot_engine import ROOT,PROJECT,SOURCE,load,dump
T=ROOT/'tables'

def metric(observed,predicted):
    o=np.asarray(observed,float);p=np.asarray(predicted,float);r=float(pearsonr(o,p).statistic)
    return dict(N=len(o),RMSE=float(np.sqrt(np.mean((p-o)**2))),MAE=float(np.mean(abs(p-o))),
        Mean_bias=float(np.mean(p-o)),NSE_R2=float(1-np.sum((p-o)**2)/np.sum((o-o.mean())**2)),Pearson_r=r,Pearson_r_squared=r*r)

def main():
    driver,m,data,initial=load(True,'export')
    selected=json.loads((T/'SELECTED_PILOT_PARAMETERS.json').read_text())
    stage1=json.loads((ROOT/'runs/canopy_transpiration/PILOT_SELECTED_PARAMETERS.json').read_text())['Values']
    rows=[]
    for label,v in [('Initial_root1m',initial),('Phase1_pilot',stage1),('Phase2_pilot',selected)]:
        s,g,cc,bio=m.simulate(data,v)
        for name,tab in [('daily_growth',g),('CC_fitted_pairs',cc),('Biomass_fitted_pairs',bio)]:tab.to_csv(T/f'{label}_{name}.csv',index=False)
        rows.append(dict(Scenario=label,Observed_Y13_t_ha=m.Y13_PUBLISHED,Y13_likelihood_target=m.Y13_TARGET,
            Yield_bias_t_ha=s['Y_13pct']-m.Y13_PUBLISHED,Yield_bias_pct=100*(s['Y_13pct']/m.Y13_PUBLISHED-1),
            Observed_ET_mm=m.ET_OBS,ET_bias_mm=s['ET_mm']-m.ET_OBS,**s))
    pd.DataFrame(rows).to_csv(T/'Yield_and_water_comparison.csv',index=False)
    met=[]
    for label in ['Initial_root1m','Phase1_pilot','Phase2_pilot']:
        a=pd.read_csv(T/f'{label}_CC_fitted_pairs.csv');b=pd.read_csv(T/f'{label}_Biomass_fitted_pairs.csv')
        met.extend([dict(Scenario=label,Variable='CC',**metric(a.Observed_CC,a.canopy_cover)),
            dict(Scenario=label,Variable='Biomass_t_ha',**metric(b.Observed_B_t_ha,b.Biomass_t_ha))])
    pd.DataFrame(met).to_csv(T/'Fit_metrics.csv',index=False)
    diag=pd.concat([pd.read_csv(T/f'{p}_pilot_parameter_diagnostics.csv') for p in ['canopy_transpiration','biomass_yield']],ignore_index=True)
    diag['Boundary_signal']=np.where(diag.Best_within_1pct_bound,'Best_sample_within_1pct',
        np.where(np.maximum(diag.Mass_lower_5pct,diag.Mass_upper_5pct)>=.20,'At_least_20pct_draws_in_5pct_edge','No_strong_edge_signal_in_this_pilot'))
    diag.to_csv(T/'All_parameter_boundary_and_mixing_checks.csv',index=False)
    pd.DataFrame([dict(Parameter=k,Value=selected[k],Unit='day' if k=='SenescenceCD' else 'g_m2_normalized' if k.startswith('WP_') else 'fraction_or_coefficient',
        Phase=1 if k in m.PHASE1_NAMES else 2,Scope='provisional highest retained sampled point') for k in m.ALL_NAMES]).to_csv(T/'Selected_parameters.csv',index=False)
    data['schedule'].to_csv(T/'Observed_DI_irrigation_events_2021.csv',index=False)
    data['field'].to_csv(T/'Calibration_CC_observations.csv',index=False);data['bio'].to_csv(T/'Calibration_biomass_observations.csv',index=False)
    data['weather'].to_csv(T/'Frozen_weather_ETo_2021.csv',index=False)
    p=data['soil'].profile.copy();p['Initial_theta_m3m3']=data['theta'];p.to_csv(T/'Frozen_soil_and_initial_water.csv',index=False)
    # Original DI calibration rejects premature harvest. Low-dose counterfactuals
    # use common-calendar soil accounting and preserve yield at actual harvest.
    path=PROJECT/'real_model/four_year_adapter.py'
    spec=importlib.util.spec_from_file_location('pilot_response_adapter',path);adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
    adapter.STATES[2021]=(m,data)
    a0,f0,g0=adapter.simulate(params=selected,year=2021,details=True)
    direct=m.simulate(data,selected)
    dif={k:abs(float(a0[k])-float(direct[0][k])) for k in a0.keys()&direct[0].keys() if isinstance(a0[k],(float,int))}
    assert max(dif.values())<1e-8,dif
    np.testing.assert_allclose(g0.canopy_cover,direct[1].canopy_cover,atol=1e-10,rtol=0)
    np.testing.assert_allclose(g0.biomass,direct[1].biomass,atol=1e-10,rtol=0)
    # Daily root monitoring returns all original model results unmodified.
    klass=m.AquaCropModel;old=klass._perform_timestep;records=[]
    def observe(model):
        result=old(model);clock,cond,param,out=result
        records.append(dict(Date=str((m.PLANT+pd.Timedelta(days=len(records))).date()),Root_depth_m=float(cond.z_root),
            Zmax_m=float(param.Seasonal_Crop_List[0].Zmax),MulchPct=float(param.FieldMngt.mulch_pct),fMulch=float(param.FieldMngt.f_mulch)))
        return result
    klass._perform_timestep=observe
    try:original=m.simulate(data,selected)
    finally:klass._perform_timestep=old
    rd=pd.DataFrame(records);assert len(rd)==148 and rd.Root_depth_m.max()<=1.+1e-10
    assert rd.Zmax_m.eq(1).all() and rd.MulchPct.eq(75).all() and rd.fMulch.eq(0).all()
    rd.to_csv(T/'Selected_DI_daily_root_and_film_checks.csv',index=False)
    specspace=adapter.management_space(2021);baseline=np.array(specspace['baseline_amounts']);curves=[];events=[]
    for i,fraction in enumerate(np.linspace(0,1,201)):
        control=dict(kind='stage_amounts',values=dict(zip(specspace['names'],baseline*fraction)))
        s,w,g=adapter.simulate(params=selected,year=2021,management=control,details=True)
        assert abs(s['Water_balance_residual_mm'])<1e-5
        curves.append(dict(Point=i,Fraction_of_DI=fraction,**{k:v for k,v in s.items() if k!='irrigation_events'}))
        for event in s['irrigation_events']:events.append(dict(Point=i,Fraction_of_DI=fraction,**event))
        if i in [0,50,100,150,200]:
            w.to_csv(T/f'Response_{i:03d}_daily_water.csv',index=False);g.to_csv(T/f'Response_{i:03d}_daily_growth.csv',index=False)
    c=pd.DataFrame(curves);c.to_csv(T/'Yield_irrigation_curve_0_to_observed.csv',index=False)
    pd.DataFrame(events).to_csv(T/'Yield_irrigation_curve_actual_event_amounts.csv',index=False)
    assert c.iloc[0].Irrigation_mm==0 and abs(c.iloc[-1].Irrigation_mm-633.47)<1e-8
    assert abs(c.iloc[-1].Y_13pct-original[0]['Y_13pct'])<1e-8
    correlation=[]
    for phase,names in [('canopy_transpiration',m.PHASE1_NAMES),('biomass_yield',m.PHASE2_NAMES)]:
        draws=pd.read_csv(ROOT/'runs'/phase/'pilot_retained_draws_last250.csv');corr=draws[names].corr()
        corr.to_csv(T/f'{phase}_pilot_correlation_matrix.csv',index_label='Parameter')
        for j,k in enumerate(names):
            for kk in names[j+1:]:correlation.append(dict(Phase=phase,Parameter_1=k,Parameter_2=kk,Pilot_correlation=corr.loc[k,kk]))
    pd.DataFrame(correlation).to_csv(T/'Within_phase_parameter_correlations.csv',index=False)
    trade=[]
    for label,v in [('Phase1_handoff',stage1),('Selected_phase2',selected),('Selected_phase2_HI0_upper',dict(selected,HI0=.60))]:
        ss,gg,ccc,bb=m.simulate(data,v)
        lb=.5*np.sum(((bb.Biomass_t_ha-bb.Observed_B_t_ha)/bb.Sigma_assumed)**2)
        ly=.5*((ss['Y_dry']-m.YDRY_TARGET)/m.SIGMA_Y)**2
        trade.append(dict(Scenario=label,WP_early=v['WP_early'],WP_late=v['WP_late'],HI0=v['HI0'],
            Y13_t_ha=ss['Y_13pct'],B_last_t_ha=ss['B_last'],Adjusted_HI=ss['HI_last'],
            Biomass_negative_log_likelihood=float(lb),Yield_negative_log_likelihood=float(ly),
            Total_phase2_negative_log_likelihood=float(lb+ly),
            Effective_HI_needed_for_published_yield=m.Y13_PUBLISHED*.87/ss['B_last']))
    pd.DataFrame(trade).to_csv(T/'Biomass_yield_tradeoff_and_HI_upper_check.csv',index=False)
    dump(ROOT/'verification/FINAL_ENGINE_AND_CURVE_CHECK.json',dict(Status='PASS',DI_adapter_absolute_differences=dif,
        Daily_CC_and_biomass_agree=True,Maximum_root_depth_m=float(rd.Root_depth_m.max()),MulchPct=75,fMulch=0,
        Curve_points=len(c),Curve_first_actual_irrigation_mm=float(c.iloc[0].Irrigation_mm),Curve_last_actual_irrigation_mm=float(c.iloc[-1].Irrigation_mm),
        Endpoint_yield_matches_fitted_DI=True,Maximum_water_balance_residual_mm=float(c.Water_balance_residual_mm.abs().max()),
        Early_terminated_curve_points=int(c.Early_termination.sum()),
        Curve_definition='Original DI dates and event proportions scaled uniformly from 0 to 100%; NOT an optimized Pareto front',
        Formal_convergence=False))
    snap=ROOT/'model_snapshots/DI_PHASE3_NEXTGEN_UPDATED/real_model';snap.mkdir(parents=True,exist_ok=True)
    shutil.copytree(SOURCE.parent,snap/'model_2021',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','MCMC_Article_Results_2021'))
    for name in ['four_year_adapter.py','numerical_acceleration.py','root_zone_kernel.py','physical_kernels.py','KERNEL_ARGUMENTS.json']:
        shutil.copy2(PROJECT/'real_model'/name,snap/name)
    oldroot=Path('/workspace/urp_root1m_experiment_20261020/sources')
    for name in ['SOURCE_DOCUMENT.json','PDF_page_019.png','PDF_page_019.txt','PDF_page_021.png','PDF_page_021.txt','PDF_page_063.png','PDF_page_063.txt','PDF_page_068.png','PDF_page_068.txt']:
        shutil.copy2(oldroot/name,ROOT/'sources'/name)
    print('EXPORTED',len(c),'dose points, new fitted DI yield',c.iloc[-1].Y_13pct,'zero yield',c.iloc[0].Y_13pct,flush=True)

if __name__=='__main__':main()
