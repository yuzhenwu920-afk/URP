"""Readable Chinese interpretation, English figures and complete numeric workbook."""
from pathlib import Path
import json,platform,importlib.metadata
import pandas as pd
import numpy as np
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openpyxl.styles import Font,PatternFill,Alignment
from pilot_engine import ROOT
T=ROOT/'tables'
def read(name):return pd.read_csv(T/(name+'.csv'))

def main():
    y=read('Yield_and_water_comparison');d=read('All_parameter_boundary_and_mixing_checks');metrics=read('Fit_metrics');curve=read('Yield_irrigation_curve_0_to_observed')
    chosen=y[y.Scenario=='Phase2_pilot'].iloc[0];cc=metrics[(metrics.Scenario=='Phase2_pilot')&(metrics.Variable=='CC')].iloc[0]
    cfg=json.loads((ROOT/'verification/EXPERIMENT_CONFIG.json').read_text());reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text())
    checks=json.loads((ROOT/'verification/FINAL_ENGINE_AND_CURVE_CHECK.json').read_text())
    with pd.ExcelWriter(ROOT/'URP_2021_Root1m_Pilot_Data.xlsx',engine='openpyxl') as writer:
        index=[]
        for i,p in enumerate(sorted(T.glob('*.csv')),1):
            name=f'{i:02d}_'+p.stem[:27];a=pd.read_csv(p);a.to_excel(writer,sheet_name=name,index=False);index.append(dict(Sheet=name,Source_CSV=p.name,Rows=len(a)))
        pd.DataFrame(index).to_excel(writer,sheet_name='INDEX',index=False)
        for ws in writer.book:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            for cell in ws[1]:cell.font=Font(name='Calibri',bold=True,color='FFFFFF',size=10);cell.fill=PatternFill('solid',fgColor='275767');cell.alignment=Alignment(wrap_text=True)
            for column in ws.columns:
                ws.column_dimensions[column[0].column_letter].width=min(35,max(13,max(len(str(c.value or '')) for c in list(column)[:30])+2))
                for cell in list(column)[1:]:
                    cell.font=Font(name='Calibri',size=10)
                    if isinstance(cell.value,float):cell.number_format='0.0000'
                    if cell.row%2==0:cell.fill=PatternFill('solid',fgColor='F1F5F6')
    doc=Document();sec=doc.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7)
    sec.left_margin=sec.right_margin=Cm(1.65);sec.top_margin=sec.bottom_margin=Cm(1.5)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
        st=doc.styles[name];st.font.name='DejaVu Sans';st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.styles['Normal'].font.size=Pt(10.5);doc.styles['Normal'].paragraph_format.line_spacing=1.12;doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    doc.styles['Title'].font.size=Pt(22);doc.styles['Heading 1'].font.size=Pt(15);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('275767');doc.styles['Caption'].font.size=Pt(9)
    foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER;foot.add_run('URP · 2021年1m根深MCMC短链试跑 · ')
    page=OxmlElement('w:fldSimple');page.set(qn('w:instr'),'PAGE');foot._p.append(page)
    md=[]
    def p(text,style=None):doc.add_paragraph(text,style);md.append(text+'\n')
    def h(text):
        para=doc.add_heading(text,1);para.paragraph_format.page_break_before=False;md.append('\n## '+text+'\n')
    def table(title,a,columns):
        doc.add_heading(title,2);tab=doc.add_table(rows=1,cols=len(columns));tab.style='Light Shading Accent 1'
        hd=OxmlElement('w:tblHeader');tab.rows[0]._tr.get_or_add_trPr().append(hd)
        for cell,(_,label,_) in zip(tab.rows[0].cells,columns):cell.text=label
        for _,row in a.iterrows():
            for cell,(key,_,digits) in zip(tab.add_row().cells,columns):
                value=row[key];cell.text='—' if pd.isna(value) else str(value) if digits is None else f'{value:.{digits}f}'
        for row in tab.rows:
            node=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(node)
            for cell in row.cells:
                for para in cell.paragraphs:
                    para.paragraph_format.space_after=Pt(3)
                    for run in para.runs:run.font.size=Pt(8.5)
        md.append(a[[k for k,_,_ in columns]].to_csv(index=False))
    def fig(i,maxheight=12):
        r=reg[i-1];path=ROOT/'figures'/(r['ID']+'.png');w,hh=Image.open(path).size
        # Keep full 600-dpi publication figures separately; 2400 px is ample
        # for the Word page and avoids embedding a 15-MB dense trace bitmap.
        im=Image.open(path);im.thumbnail((2400,2600))
        embed=ROOT/'verification/word_figures'/(r['ID']+'.png');embed.parent.mkdir(parents=True,exist_ok=True);im.save(embed,optimize=True)
        para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER;para.paragraph_format.keep_with_next=True;para.add_run().add_picture(str(embed),width=Cm(min(17.5,maxheight*w/hh)))
        p(f"图P-{i:02d} · {r['Title']}",'Caption');p('解析：'+r['Interpretation_CN']);p('解释边界：'+r['Boundary_CN'],'Caption');p('源数据：'+', '.join(r['Source_tables']),'Caption')
        md.append(f"![{r['Title']}](figures/{r['ID']}.png)\n")
    doc.add_heading('2021年DI玉米\n最大根深1m的MCMC校准试跑',0)
    p('500步 × 10 walkers × 4组独立ensemble；条件两阶段；2026-10-21','Subtitle')
    p('本轮按用户要求缩短链长，实际重新运行两阶段采样；不是仅把旧参数放进1m模型回放。最大根深固定为1.00m，保留0.30m最小根深及动态根系生长。')
    p(f'新选定参数在原DI日程下的产量为{chosen.Y_13pct:.4f}t/ha；与文献实测15.86t/ha相比差{chosen.Yield_bias_t_ha:+.4f}t/ha（{chosen.Yield_bias_pct:+.2f}%）。CC拟合RMSE={cc.RMSE:.4f}，拟合R²={cc.NSE_R2:.3f}，Pearson r={cc.Pearson_r:.3f}。')
    p('重要结论：这是一轮短链效果检验。原程序正式判据要求至少2000步，且Rhat、ESS及自相关时间均达标；本轮500步未获得正式收敛通过。本文所有参数、边界质量和水量响应均按“初步样本结果”解释，不能因为拟合接近实测就称后验可靠。')
    table('核心交付摘要',pd.DataFrame([dict(Item='CC拟合RMSE',Value=f'{cc.RMSE:.4f}'),dict(Item='新模拟Y13',Value=f'{chosen.Y_13pct:.4f} t/ha'),dict(Item='实测Y13',Value='15.86 t/ha'),dict(Item='相对偏差',Value=f'{chosen.Yield_bias_pct:+.2f}%'),dict(Item='曲线横轴',Value='0—633.47 mm实际执行灌水量'),dict(Item='正式收敛',Value='未通过：500步短链试跑')]),[('Item','项目',None),('Value','结果',None)])
    h('1 模型、资料与校准方法')
    p('依据2021年DI_2021_MCMC_ONE_CLICK.py内嵌模型及正式runner设置。沿用原先验范围、CDC_CD与SenescenceCD的截断正态先验、似然和误差尺度；WP_early/WP_late按原runner采用Uniform(10,40)，HI0采用Uniform(0.35,0.60)，未为避开边界擅自扩大参数范围。')
    p('第一阶段：校准CCx、CGC_CD、CDC_CD、SenescenceCD、Kcb。似然由田间LAI换算CC及季节Tr/Es约束构成；RS遥感CC不进入似然。阶段一并非仅用CC校准，Tr与Es分解靶值仍是原代码构造的约束，不应改称分别独立实测。')
    p(f"原误差尺度：σCC={cfg['Sigmas']['CC']:.2f}，σTr={cfg['Sigmas']['Tr']:.3f}mm，σEs={cfg['Sigmas']['Es']:.1f}mm；Tr靶值={cfg['Tr_target']:.2f}mm，Es靶值={cfg['Es_target']:.1f}mm。文献季节ET={cfg['ET_observed']:.2f}mm。")
    p('第二阶段：在第一阶段选出的短链最高保留样本点上，条件校准WP_early、WP_late、HI0；用数字化生物量及籽粒干重产量组成似然。最终Y13由干重产量除以0.87换算，内设靶值15.862t/ha保留原精度，报告与公开表格15.86t/ha比较。生物量Sigma_assumed是原有假设，不是实测SD。')
    p('每阶段4组独立ensemble，每组500步、10walkers，共20,000个保存状态；两阶段共40,000个状态。拒绝步会重复上一状态，因此状态数不能当成40,000次独立样本，也不能当成模型实际调用次数。随机种子沿用原规则，以42为基础。')
    p('第一阶段维数5，10walkers正好满足emcee至少2×维数的底线；维数3的第二阶段同样用10walkers。为“先看效果”，用各组第251—500步作明确标记的试跑摘要（零基索引250—499），并取这些状态中log posterior最高者；这不是由收敛诊断确认的正式烧入或全局MAP。')
    p('原正式流程在第一阶段未收敛时会停止。为完成本轮用户明确要求的两阶段短链效果检查，新试验在保留原“未收敛”标记的前提下继续阶段二；不把这一试跑继续机制写成正式采样通过。阶段二也没有传播第一阶段的全部不确定性。')
    p('固定条件：地膜覆盖75%，fMulch=0表示关闭额外减蒸效应；原气象与ETo、初始含水、土壤水力转换、DI灌水日期、WetSurf=100%、AppEff=100%均保持。主模型保留原2.4m水文网格以隔离根深改变，但根系上限严格1m；1m以下物性和初始水仍是既有外推结构，不能称为新增实测。')
    p('资料来源：王尚今（2023）学位论文，DI表2-1土壤六层到1m，表2-3逐次灌水，表4-1产量与ET。2021年7次DI灌水合计633.47mm，表4-1总量633.46mm，相差0.01mm；本轮以逐次表合计为曲线终点。1m根深是本轮假设，不代表有证据证明田间根系绝不超过1m。')
    table('原DI灌水事件',read('Observed_DI_irrigation_events_2021'),[('Date','日期',None),('Depth','灌水mm',2)])
    h('2 CC拟合结果')
    fig(1,10)
    table('CC拟合指标',metrics[metrics.Variable=='CC'],[('Scenario','方案',None),('N','配对数',0),('RMSE','RMSE',4),('NSE_R2','拟合R²',3),('Pearson_r','Pearson r',3)])
    p('拟合R²采用1−Σ(模拟−观测)²/Σ(观测−观测均值)²，属于样本内一致性评分；Pearson r衡量线性同变。两者不能互换，也不能把用于拟合的观测点称独立检验。阶段二参数不反馈CC，因此最终CC与阶段一相同。')
    h('3 Yield与实测的差异及生物量解释')
    fig(2,10)
    table('产量与ET对照',y,[('Scenario','方案',None),('Y_13pct','Y13 t/ha',4),('Yield_bias_pct','偏差%',2),('ET_mm','ET mm',2),('ET_bias_mm','ET偏差mm',2)])
    p('重点区分“结构变化后的起点”和“校准后结果”：改变根深会改变胁迫与冠层过程，随后参数重拟合可以补偿部分差异。拟合产量接近实测是目标资料参与似然后的模型一致性结果，不意味着参数已唯一识别，更不意味着少水情景已被田间确认。')
    trade=read('Biomass_yield_tradeoff_and_HI_upper_check')
    table('生物量—产量权衡及HI上限复核',trade,[('Scenario','方案',None),('Y13_t_ha','Y13 t/ha',4),('Biomass_negative_log_likelihood','生物量负logL',3),('Yield_negative_log_likelihood','产量负logL',3),('Total_phase2_negative_log_likelihood','合计负logL',3)])
    p('阶段一交接点产量15.8356t/ha已很接近观测，但阶段二同时追踪生物量：降低WP_late后，生物量负log似然从4.202降至3.371，代价是产量负log似然由0.001升至0.561，总负log似然仍降低。这解释了为什么阶段二并未简单把产量单独推到实测值。')
    p('在本轮最终WP组合固定时，把HI0推至原上限0.60，产量也仅升至15.2033t/ha。按此点生物量22.0196t/ha匹配15.86t/ha需有效收获指数约0.6266，超过当前引擎该点的约0.6007上限响应。该条件诊断提示生物量轨迹、WP及HI约束有张力，但不证明换用其他WP组合仍必然无解。上限复核点的似然还优于短链所选点，也直接说明当前样本最高点不等于已经找到真实MAP。')
    corr=read('Within_phase_parameter_correlations').sort_values('Pilot_correlation',key=abs,ascending=False)
    if len(corr):
        r=corr.iloc[0];p(f'本轮组内最强线性相关样本对为{r.Parameter_1}与{r.Parameter_2}，r={r.Pilot_correlation:.3f}。该值仅作短链补偿关系的提示；阶段二的水分生产力与收获指数可能通过生物量—籽粒分配共同补偿产量，应结合完整链和独立观测继续检查。')
    h('4 参数撞墙检查')
    fig(3,11)
    b=d.copy();b['Edge1pct_L']=b.Mass_lower_1pct*100;b['Edge1pct_U']=b.Mass_upper_1pct*100
    b['Boundary_signal']=b.Boundary_signal.map({'Best_sample_within_1pct':'选点距边界≤1%','At_least_20pct_draws_in_5pct_edge':'5%边缘区集中','No_strong_edge_signal_in_this_pilot':'本轮无强信号'})
    table('边界距离和边界质量',b,[('Parameter','参数',None),('Pilot_best_sample','选点',5),('Edge1pct_L','下1%质量%',2),('Edge1pct_U','上1%质量%',2),('Boundary_signal','信号',None)])
    flagged=b[b.Boundary_signal!='本轮无强信号']
    if len(flagged):
        p('本轮出现需复核的边界信号：'+', '.join(flagged.Parameter)+'。具体是选点靠近边界还是短链在5%边缘区集中，请按表逐项读；这不是通过换先验范围可自动解决的问题。')
    else:p('本轮所选参数未出现强边界信号；这只是当前短链的观察，不能据此证明不存在撞墙。需在更充分混合后检查边界质量是否持续。')
    p('判据分两层：选点距离先验任一端≤1%范围则标记；另外报告落在上下1%和5%边界带内的保留样本比例，某一5%带内≥20%作进一步复核信号。均匀先验本来允许靠边样本，单个靠边点不等于数学证明模型错误；明显集中更值得警惕。')
    h('5 采样轨迹与收敛边界')
    fig(4,14)
    table('短链保守混合诊断',d,[('Parameter','参数',None),('Rhat_max_matched_walker_groups','最大Rhat',3),('ESS_bulk_min','最小bulk ESS',1),('ESS_tail_min','最小tail ESS',1)])
    p('诊断按相同walker编号在4组独立ensemble间比较，取最大Rhat和最小ESS，不把同一ensemble内10条相互耦合轨迹当10条独立链。原正式要求包括Rhat<1.01、bulk/tail ESS≥400、链长≥50×最大自相关时间、至少2000步；本轮保留未通过状态。')
    p('后续是否加长链取决于用户是否采用本轮模型假设及试跑效果。若继续正式分析，应先确认初始含水、根深与生物量误差假设，再延长采样并检查混合；不应仅为了让产量看起来合理而调参范围或删掉异常点。')
    h('6 产量—灌水量曲线：0至实测总量')
    fig(5,11)
    select=curve[curve.Point.isin([0,50,100,150,200])].copy()
    table('曲线关键数值',select,[('Fraction_of_DI','原DI比例',2),('Irrigation_mm','实际灌水mm',2),('Y_13pct','Y13 t/ha',4),('ET_mm','ET mm',2),('Early_termination','提前终止',None)])
    p(f'零灌水模型产量={curve.iloc[0].Y_13pct:.4f}t/ha；633.47mm终点产量={curve.iloc[-1].Y_13pct:.4f}t/ha，与本轮新参数原DI回放完全一致。图形横轴从0开始，纵轴也保留0以展示绝对产量，但不把零灌水产量强制改为0。')
    p('201个水量水平均是实际模型逐点运算，未用拟合曲线或插值补造模拟产量。每个候选保持原7次灌水日期、各次比例不变。执行上限按当次候选最大事件和季总量加0.10mm，作用是让日程完整执行，不能解释为田间设备极限。')
    p(f"低水量若提前成熟/死亡，则保留实际收获产量并将此后的土壤水分平衡继续算到共同日历末；之后计划灌水停止，横轴用实际执行量。该适配器在原DI下已与校准引擎逐日CC、生物量及标量输出核对一致。本轮{checks['Early_terminated_curve_points']}个水量点有提前结束标记，实际/计划灌水、收获日期及取消水量均在曲线CSV保留。")
    p('本曲线只回答“新参数下，原灌水安排同比例减少时产量怎样变化”。它不是在每个水量上重新寻找最优分配，也没有执行新的NSGA-III前沿搜索；不能将其平台解读成已经证明的田间高节水推荐。零灌水保留原初始土壤水和季节降雨，其真实性仍需独立旱作资料验证。')
    h('7 文件、复现与可用于论文的表述')
    p('建议论文表述：在最大有效根深固定为1.0m、其余原始管理与环境输入不变的条件下，进行每组500步、10walkers的四ensemble条件两阶段MCMC试跑。报告冠层、生物量与产量的样本内拟合，以及参数边界和跨ensemble混合诊断。短链未满足正式收敛判据，产量—灌水量曲线作为结构假设下的初步模型响应，不作经田间验证的最优灌溉结论。')
    p('figures提供5组全英文图，每组PNG/PDF/SVG；tables提供配对观测、逐日结果、误差指标、全部参数诊断和201点响应；Excel汇总所有CSV；runs保留8条完整ensemble检查点、全部40,000状态、接受记录、严格原诊断、试跑摘要及日志；model_snapshots保存原2021年代码/输入与精确数值内核。')
    p('复现：先在独立Python环境安装依赖，令URP_PROJECT指向model_snapshots/DI_PHASE3_NEXTGEN_UPDATED，再运行code/run_pilot.py → export_results.py → plot_results.py → build_report.py。原检查点会校验合同、原源码与脚本哈希及log posterior；源码位置变化不应改变数值。README给出命令和版本，manifest提供逐文件SHA256。旧2.3m结果与之前四年1m冻结参数实验均未覆盖。')
    p('参考：王尚今，2023，《不同灌溉方式下覆膜玉米田水热氮传输及作物生长的观测与模拟》，中国农业大学硕士学位论文。资料页截图和原文件哈希置于sources。软件：AquaCrop 3.1.0、emcee 3.1.6；精确Numba内核仅加速原方程，不使用代理模型，已与未加速输出核对。')
    doc.save(ROOT/'URP_2021_Root1m_Pilot_Report.docx');(ROOT/'URP_2021_Root1m_Pilot_Report.md').write_text('\n'.join(md))
    requirements=['numpy','pandas','scipy','aquacrop','emcee','numba','llvmlite','matplotlib','python-docx','openpyxl','Pillow','PyMuPDF','SALib','pymoo']
    versions={name:importlib.metadata.version(name) for name in requirements}
    (ROOT/'requirements.txt').write_text('\n'.join(k+'=='+v for k,v in versions.items())+'\n')
    (ROOT/'ENVIRONMENT.json').write_text(json.dumps(dict(Python=platform.python_version(),Packages=versions),indent=2))
    print('Word report:',len(doc.inline_shapes),'figures,',len(doc.tables),'tables')

if __name__=='__main__':main()
