"""Check actual pilot states, numeric endpoint, figures, doc and archive integrity."""
from pathlib import Path
import json,sys,hashlib,shutil,zipfile,contextlib
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
import fitz
from pilot_engine import ROOT,PROJECT,SOURCE,load,dump

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    with (ROOT/'verification/unaccelerated_final_check.log').open('w') as log,contextlib.redirect_stdout(log):
        driver,m,data,initial=load(False,'final_unaccelerated')
        v=json.loads((ROOT/'tables/SELECTED_PILOT_PARAMETERS.json').read_text());s,g,cc,b=m.simulate(data,v)
    recorded=pd.read_csv(ROOT/'tables/Yield_and_water_comparison.csv').iloc[-1]
    diff={k:abs(float(s[k])-float(recorded[k])) for k in s}
    assert max(diff.values())<1e-8,diff
    growth=pd.read_csv(ROOT/'tables/Phase2_pilot_daily_growth.csv')
    np.testing.assert_allclose(g.canopy_cover,growth.canopy_cover,atol=1e-10,rtol=0)
    np.testing.assert_allclose(g.biomass,growth.biomass,atol=1e-8,rtol=0)
    calls=0;states=0;checkpoints=[]
    for phase,dim in [('canopy_transpiration',5),('biomass_yield',3)]:
        for e in range(1,5):
            p=ROOT/'runs'/phase/f'ensemble_{e}.npz'
            with np.load(p,allow_pickle=False) as f:
                x=f['history'];assert x.shape==(500,10,dim);assert np.isfinite(x).all() and np.isfinite(f['logs']).all()
                checkpoints.append(dict(Phase=phase,Ensemble=e,Shape=list(x.shape),SHA256=sha(p)));states+=5000
    assert states==40000
    curve=pd.read_csv(ROOT/'tables/Yield_irrigation_curve_0_to_observed.csv')
    assert len(curve)==201 and curve.iloc[0].Irrigation_mm==0 and abs(curve.iloc[-1].Irrigation_mm-633.47)<1e-8
    assert abs(curve.iloc[-1].Y_13pct-s['Y_13pct'])<1e-9
    registry=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text())
    assert len(registry)==5
    images=[]
    for r in registry:
        p=ROOT/'figures'/(r['ID']+'.png');im=Image.open(p);assert im.width>3000 and im.height>2000
        images.append(dict(File=p.name,Width=im.width,Height=im.height))
    doc=Document(ROOT/'URP_2021_Root1m_Pilot_Report.docx');assert len(doc.inline_shapes)==5
    pdf=fitz.open(ROOT/'URP_2021_Root1m_Pilot_Report.pdf');assert all(len(p.get_text())>80 for p in pdf)
    result=dict(Status='PASS',Original_equation_final_replay_max_abs_difference=max(diff.values()),Unaccelerated_daily_CC_and_biomass='PASS',
        Checkpoints=checkpoints,Total_recorded_states=states,Independent_ensembles=4,Steps=500,Walkers=10,
        Figures=images,Report_pages=len(pdf),Report_figures=len(doc.inline_shapes),Report_tables=len(doc.tables),
        Curve_points=201,Curve_first_actual_irrigation_mm=0.,Curve_last_actual_irrigation_mm=633.47,Formal_convergence=False,
        Calibration_scope='2021 only; two-stage pilot, stage 2 conditional on selected stage-1 point')
    dump(ROOT/'verification/FINAL_DATA_CHECK.json',result)
    selected=[]
    for folder in ['code','tables','figures','sources','verification','runs','model_snapshots']:
        selected.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.lock','.tmp'])
    selected.extend(ROOT/name for name in ['README.md','FIGURE_REGISTRY.json','URP_2021_Root1m_Pilot_Report.docx','URP_2021_Root1m_Pilot_Report.pdf','URP_2021_Root1m_Pilot_Report.md','URP_2021_Root1m_Pilot_Data.xlsx','requirements.txt','ENVIRONMENT.json'])
    selected=sorted(selected)
    manifest=dict(Date='2026-10-21',Scope='2021 Zmax=1m MCMC short pilot, actual recalibration',Steps=500,Walkers=10,
        Independent_ensembles=4,Phases=2,Recorded_states=40000,Formal_convergence=False,
        Files=[dict(Path=str(p.relative_to(ROOT)),Bytes=p.stat().st_size,SHA256=sha(p)) for p in selected])
    dump(ROOT/'MANIFEST.json',manifest);selected.append(ROOT/'MANIFEST.json')
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+str(p.relative_to(ROOT)) for p in selected)+'\n');selected.append(ROOT/'SHA256SUMS.txt')
    archive=ROOT.parent/'URP_2021_Root1m_MCMC_Pilot_500x10_20261021.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in selected:z.write(p,'URP_2021_Root1m_Pilot/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for f in manifest['Files']:assert hashlib.sha256(z.read('URP_2021_Root1m_Pilot/'+f['Path'])).hexdigest()==f['SHA256']
    target=Path('/workspace/URP/deliverables/2026-10-21-2021-root1m-calibration');target.mkdir(parents=True,exist_ok=True)
    for p in [archive,ROOT/'URP_2021_Root1m_Pilot_Report.docx',ROOT/'URP_2021_Root1m_Pilot_Report.pdf',ROOT/'URP_2021_Root1m_Pilot_Data.xlsx',ROOT/'README.md',
        ROOT/'figures/P01_CC_fit_2021_root1m.png',ROOT/'figures/P05_Yield_irrigation_0_to_actual.png',ROOT/'tables/Yield_and_water_comparison.csv',ROOT/'tables/All_parameter_boundary_and_mixing_checks.csv',
        ROOT/'verification/FINAL_DATA_CHECK.json']:
        shutil.copy2(p,target/p.name)
    dump(target/'PACKAGE_CHECK.json',dict(Status='PASS',Archive_bytes=archive.stat().st_size,Archive_SHA256=sha(archive),Files=len(selected),ZIP_CRC='PASS',Manifest_hashes='PASS',Formal_convergence=False))
    (target/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in sorted(target.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt')+'\n')
    print(json.dumps(dict(Archive=str(archive),Bytes=archive.stat().st_size,SHA256=sha(archive),Files=len(selected),Report_pages=len(pdf)),indent=2))

if __name__=='__main__':main()
