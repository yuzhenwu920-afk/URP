"""Reproducible numerical checks and explicitly exploratory surrogate experiments.

No generated 2022 phase-2 samples enter new uncertainty or optimization calculations.
The vectorized model reproduces the supplied proxy; it is NOT a replacement for
the missing Modified DI AquaCrop implementation.
"""
from review_core import *
from SALib.sample import sobol as sobol_sample
from SALib.analyze import sobol as sobol_analyze
from pymoo.core.problem import Problem
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.optimize import minimize
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.indicators.hv import HV
import argparse

OBS={2019:16.55,2020:17.29,2021:15.86,2022:14.08}

def source_checks():
    orig=PROJECT/'output'
    knees=pd.read_csv(orig/'pareto_knee_solutions.csv')
    knees['Published_yield']=knees.Year.map(OBS)
    knees['Loss_vs_published_pct']=100*(knees.Y13_opt/knees.Published_yield-1)
    knees['Pass_published_95pct']=knees.Y13_opt>=.95*knees.Published_yield
    knees['IWP_base_correct_kg_m3']=100*knees.Published_yield/knees.Irr_base_mm
    knees['IWP_opt_correct_kg_m3']=100*knees.Y13_opt/knees.Irr_opt_mm
    knees['Evidence']=np.where(knees.Year==2022,'surrogate + artificial phase2','surrogate + conditional-structure approximation')
    csv('original_knees_audited',knees)
    pareto=pd.read_csv(orig/'pareto_front.csv');rows=[];baselines=[]
    for y in YEARS:
        f=np.load(DATA/f'conclusions/output/raw_npz_cache/DI_{y}.npz',allow_pickle=False)
        p1,p2=f['phase1'],f['phase2'];rng=np.random.default_rng(7+y)
        p=np.column_stack([p1[rng.integers(0,len(p1),8)],p2[rng.integers(0,len(p2),8)]])
        b=vector_sim(p,y)
        baselines.append(dict(Year=y,Same_8_draw_base_yield=b['Y_13pct'].mean(),
            Same_8_draw_base_SD=b['Y_13pct'].std(),Base_published_yield=OBS[y],
            Proxy_target=A.YEAR_DATA[y]['y13_obs'],Evidence='synthetic' if y==2022 else 'proxy; cross-phase approximation'))
        d=pareto[pareto.Year==y];days=A.YEAR_DATA[y]['n_days']
        offsets=np.array([(pd.Timestamp(dt)-pd.Timestamp(A.YEAR_DATA[y]['plant'])).days
                          for dt,mm in A.YEAR_DATA[y]['irrigation']])
        ds=[]
        for _,r in d.iterrows():
            irr=np.zeros((8,days));irr[:,offsets]=[r[f'Irr{i}_mm'] for i in range(1,9)]
            z=vector_sim(p,y,irr)
            ds.append((abs(z['Y_13pct'].mean()-r.Y13_mean),abs(z['Y_13pct'].std()-r.Y13_std)))
        obj=np.column_stack([-d.Y13_mean,d.Irr_total_mm,d.Y13_std]);dom=0
        for j,rr in enumerate(obj):
            dom+=bool(np.any(np.all(obj<=rr,axis=1)&np.any(obj<rr,axis=1)))
        rows.append(dict(Year=y,N=len(d),Max_Y_objective_difference=np.max(np.array(ds)[:,0]),
            Max_SD_objective_difference=np.max(np.array(ds)[:,1]),Dominated_points_within_saved_front=dom,
            Phase2_correlation_full=np.corrcoef(p2[:,1],p2[:,2])[0,1],
            Phase2_correlation_in_8=np.corrcoef(p[:,6],p[:,7])[0,1]))
    csv('original_objectives_recomputed',rows);csv('original_baseline_risk_recomputed',baselines)
    # The original validation reuses the very CC observations used by solve_k_cgc.
    ccrows=[]
    for y in YEARS:
        t,o=A.load_cc_obs(y);r=A.simulate(A.REFERENCE_MEAN[y],y);valid=(t>=0)&(t<len(r['cc_series']))
        ccrows.append(dict(Year=y,**metric(o[valid],r['cc_series'][t[valid]]),
            Role='in-sample calibration, not independent validation'))
    csv('surrogate_CC_calibration_recomputed',ccrows)
    print('Original Pareto objectives, baseline risks, units, thresholds and calibration reuse checked.',flush=True)

def sobol_experiments():
    bounds=pd.read_csv(PROJECT/'output/posterior_input_distributions.csv');rows=[];varrows=[]
    for y in [2019,2020,2021]:
        for track in ['Prior_uniform','Narrowed_uniform']:
            bd=A.PRIOR_BOUNDS if track=='Prior_uniform' else {
                r.Parameter:(r.Lo,r.Hi) for r in bounds[bounds.Year==y].itertuples()}
            problem=dict(num_vars=8,names=NAMES,bounds=[bd[k] for k in NAMES])
            for n in [512,2048]:
                for seed in [101,202,303]:
                    x=sobol_sample.sample(problem,n,calc_second_order=False,seed=seed)
                    out=vector_sim(x,y)
                    for name in ['Y_13pct','ET_mm']:
                        v=out[name];si=sobol_analyze.analyze(problem,v,calc_second_order=False,
                            num_resamples=256,seed=seed+1000,print_to_console=False)
                        var=np.var(np.r_[v[0::10],v[9::10]],ddof=1)
                        varrows.append(dict(Year=y,Track=track,N=n,Seed=seed,Output=name,Output_variance=var))
                        for j,k in enumerate(NAMES):
                            rows.append(dict(Year=y,Track=track,N=n,Seed=seed,Output=name,Parameter=k,
                                S1=si['S1'][j],ST=si['ST'][j],S1_conf=si['S1_conf'][j],ST_conf=si['ST_conf'][j],
                                Output_variance=var,Unnormalized_total_effect=var*si['ST'][j]))
            print('Seeded Sobol size/scramble check:',y,track,flush=True)
    df=csv('sobol_seeded_convergence',rows);csv('sobol_output_variance',varrows)
    return df

def conditional_draws(y,k,seed):
    z=np.load(OUT/'verified_phase_specific_draws.npz',allow_pickle=False)
    p1=z[f'p1_{y}'].mean(axis=0); p2=z[f'p2_{y}']
    rng=np.random.default_rng(seed)
    ix=rng.choice(len(p2),size=k,replace=k>len(p2))
    return np.column_stack([np.tile(p1,(k,1)),p2[ix]])

def distribution_check():
    rows=[];details={};sched=pd.read_csv(PROJECT/'output/optimal_irrigation_schedule.csv')
    for y in [2019,2020,2021]:
        p=conditional_draws(y,4096,8800+y);b=vector_sim(p,y)['Y_13pct']
        s=sched[sched.Year==y].sort_values('Event');irr=np.zeros(A.YEAR_DATA[y]['n_days'])
        for r in s.itertuples():
            ix=(pd.Timestamp(r.Date)-pd.Timestamp(A.YEAR_DATA[y]['plant'])).days;irr[ix]+=r.Optimal_mm
        q=vector_sim(p,y,irr)['Y_13pct']
        for label,v in [('Base',b),('Original_selected',q)]:
            rows.append(dict(Year=y,Scenario=label,N=len(v),Mean=v.mean(),SD=v.std(ddof=1),
                Q025=np.quantile(v,.025),Q05=np.quantile(v,.05),Median=np.median(v),Q975=np.quantile(v,.975),
                Probability_above_95pct_published=np.mean(v>=.95*OBS[y]),
                Probability_opt_base_ratio_ge_95pct=np.mean(q/b>=.95),
                Mean_loss_relative_to_paired_base_pct=np.mean(100*(q/b-1))))
        details[f'base_{y}']=b;details[f'original_{y}']=q
    csv('conditional_uncertainty_4096',rows);np.savez_compressed(OUT/'conditional_yield_distributions.npz',**details)

class ConditionalProblem(Problem):
    def __init__(self,y,p):
        super().__init__(n_var=8,n_obj=3,n_ieq_constr=1,xl=np.zeros(8),xu=np.full(8,120.))
        self.y=y;self.p=p
        self.days=A.YEAR_DATA[y]['n_days']
        self.offsets=np.array([(pd.Timestamp(d)-pd.Timestamp(A.YEAR_DATA[y]['plant'])).days
                               for d,mm in A.YEAR_DATA[y]['irrigation']])
    def _evaluate(self,X,out,*args,**kwargs):
        n=len(X);k=len(self.p)
        irr=np.zeros((n*k,self.days));irr[:,self.offsets]=np.repeat(X,k,axis=0)
        vals=vector_sim(np.tile(self.p,(n,1)),self.y,irr)['Y_13pct'].reshape(n,k)
        mu=vals.mean(axis=1);sd=vals.std(axis=1)
        out['F']=np.column_stack([-mu,X.sum(axis=1),sd])
        out['G']=(.95*OBS[self.y]-mu)[:,None]

def rerun_optimization():
    hvrows=[];frontrows=[];selections=[]
    for y in [2019,2020,2021]:
        p=conditional_draws(y,64,12340+y)
        prob=ConditionalProblem(y,p)
        # Fixed across all seeds for this year; all objectives are minimization.
        reference=np.array([0.,1000.,5.])
        indicator=HV(ref_point=reference)
        for seed in [31,73,109]:
            history=[]
            def callback(algo):
                f=algo.pop.get('F');cv=algo.pop.get('CV').ravel();feasible=f[cv<=0]
                history.append(dict(Year=y,Seed=seed,Generation=algo.n_gen,
                    N_evaluations=algo.evaluator.n_eval,Feasible_population=len(feasible),
                    Hypervolume=indicator(feasible) if len(feasible) else 0.))
            t=time.time()
            result=minimize(prob,NSGA3(pop_size=45,
                ref_dirs=get_reference_directions('das-dennis',3,n_partitions=8),eliminate_duplicates=True),
                ('n_gen',100),seed=seed,callback=callback,verbose=False)
            hvrows.extend(history)
            if result.F is None:
                print('No feasible proxy solution:',y,seed,flush=True);continue
            x=np.atleast_2d(result.X);f=np.atleast_2d(result.F)
            for xx,ff in zip(x,f):
                frontrows.append(dict(Year=y,Seed=seed,Yield_mean=-ff[0],Irr_mm=ff[1],Yield_SD=ff[2],
                    **{f'Irr{i+1}_mm':xx[i] for i in range(8)}))
            ix=np.argmin(f[:,1]);selected=x[ix]
            # Hold-out Monte Carlo sample, distinct from the 64 training draws.
            pv=conditional_draws(y,4096,55500+y)
            irr=np.zeros(prob.days);irr[prob.offsets]=selected
            val=vector_sim(pv,y,irr);base=vector_sim(pv,y)
            selections.append(dict(Year=y,Seed=seed,Train_mean=-f[ix,0],Train_SD=f[ix,2],
                Irr_mm=selected.sum(),Water_saving_pct=100*(1-selected.sum()/A.YEAR_DATA[y]['irr_obs']),
                Validation_mean=val['Y_13pct'].mean(),Validation_SD=val['Y_13pct'].std(ddof=1),
                Validation_Q05=np.quantile(val['Y_13pct'],.05),
                Validation_prob_95pct_observed=np.mean(val['Y_13pct']>=.95*OBS[y]),
                Validation_mean_pass=bool(val['Y_13pct'].mean()>=.95*OBS[y]),
                Paired_prob_95pct_base=np.mean(val['Y_13pct']/base['Y_13pct']>=.95),
                **{f'Irr{i+1}_mm':selected[i] for i in range(8)}))
            csv('proxy_optimization_HV_history',hvrows);csv('proxy_optimization_all_fronts',frontrows)
            csv('proxy_optimization_selected_holdout',selections)
            print('Conditional proxy NSGA-III:',y,'seed',seed,'seconds',round(time.time()-t,1),
                  'train yield',round(-f[ix,0],3),'I',round(selected.sum(),1),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--optimization-only',action='store_true');args=parser.parse_args()
    A.calibrate_all();t=time.time()
    if not args.optimization_only:
        source_checks();distribution_check();sobol_experiments()
    rerun_optimization()
    print('Exploratory experiments completed:',round(time.time()-t,1),'s',flush=True)
