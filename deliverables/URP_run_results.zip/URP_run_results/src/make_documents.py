"""Write Chinese audit report and illustrated paper framework from computed tables."""
from review_core import *
from xml.sax.saxutils import escape
import re, subprocess, base64, html, importlib.metadata as md
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image as RLImage,Table,TableStyle,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from PIL import Image
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment

def tb(n):return pd.read_csv(TABLES/(n+'.csv'))
def mdtable(df):
    def fmt(x):
        if pd.isna(x):return '—'
        if isinstance(x,(float,np.floating)):return f'{x:.4f}'
        return str(x).replace('|','/').replace('\n',' ')
    return '| '+' | '.join(map(str,df.columns))+' |\n| '+' | '.join(['---']*len(df.columns))+' |\n'+'\n'.join('| '+' | '.join(fmt(v) for v in row)+' |' for row in df.itertuples(index=False,name=None))+'\n'

def figure(n):
    captions=read(OUT/'figure_captions.json');r=next(r for r in captions if r['file'].startswith(n+'_'))
    return f"\n![{r['title']}](figures/{r['file']})\n\n图注：{r['caption']}\n"

def findings():
    rows=[
      ('A01','必须修正','2022 第二阶段为构造样本','phaseA_merge_posterior.py 的 fallback；三列 1500 个数与固定种子正态+裁剪逐值一致','从 MCMC 统计、Sobol 结论、稳健优化和迁移结论中排除；优先找回真实检查点，必要时按原模型重跑'),
      ('A02','必须修正','后续分析使用自写代理而非原改进模型','aquacrop_surrogate.py；原 Modified DI 实现不在可读附件中；real_simulate 直接抛 NotImplementedError','补含两阶段 WP 与蒸发结构修改的原模型；统一接口核验基准点和随机管理点，再复算候选方案'),
      ('A03','必须修正','独立冠层验证存在数据复用','solve_k_cgc 调 load_cc_obs 拟合同一 LAI-CC；validate_model_chain 再用同一文件算 R²','改称样本内校准；独立年份、处理或地块留出，任何校准都不能看测试资料'),
      ('A04','必须修正','第一阶段尚未满足收敛标准','四年所有参数 Rhat_max=1.073—1.181；与原诊断复算吻合','继续独立 ensembles，监测 Rhat、bulk/tail ESS、tau 稳定性；固定步数或合并样本不等于达标'),
      ('A05','必须修正','两阶段条件分布不能拼成联合后验','第二阶段固定第一阶段均值；原优化独立抽 phase1/phase2','当前可做固定 phase1 的条件传播；完整传播需嵌套条件重拟合或联合/分层模型'),
      ('A06','必须修正','95% 保产基准用错','2020/2021 y13_obs=17.024/15.377，实际来自初始模拟而非文献观测 17.29/15.86','统一观测与同模型同样本基准；重算门槛：原选方案相对观测减产 5.73%/7.75%'),
      ('A07','重要修正','水生产率单位高 10 倍','代码 Y/(I/1000)，标为 kg/m³；应为 100Y/I','统一所有 WP_ET、WP_Irr、基准表与真实模型适配器；节水百分比不受此单位错误影响'),
      ('A08','必须修正','均值约束不足以提供保产概率','新条件代理试算 9 次，4096 样本的绝对门槛概率约 48%—59%','报告均值、低分位、达标概率；采用机会约束或 CVaR，同时核对基准本身是否可行'),
      ('A09','重要修正','8 个固定参数样本不足以稳定估计风险','同一三参数真实链在 8 样本中的相关估计大幅波动；基准图风险被设为 0','搜索使用更多共同随机数；独立大样本复核所有候选，基准按同样本评估'),
      ('A10','必须修正','后验 Sobol 的命名与概率空间不符','后验 0.5%—99.5% 区间被当独立均匀分布；不是实际联合后验；先验轨亦非原全部先验','改名收窄区间敏感性；依赖输入用条件采样/Shapley 等，不能直接向经典 Saltelli 塞相关样本'),
      ('A11','重要修正','CAI 不是识别性或信息吸收的证明','ST 是按各自 Var(Y) 归一化的相对贡献','同时报告输出方差、绝对总效应量和不确定性；识别性用先后验对比、剖面、覆盖率等另行检验'),
      ('A12','必须修正','代理的水量和土壤过程未验证','Dr 从 0 开始；180mm 桶忽略分层初始水；clip 隐去 2019—2021 约 50.7/101.9/199.5mm 溢出','显式记录储水、深渗、径流及缺水限制，先过逐日水量账，再评价制度'),
      ('A13','重要修正','基准灌溉安排含构造记录','原待补清单承认 2021/2022 分次时间和水量构造；2019/2020 的源代码未提供供独立核对','补真实分次记录；保持假设标签，不能将构造表称为实测'),
      ('A14','重要修正','原优化只跑一次且无轨迹','45 参考方向、40 代、固定 8 样本；save_history=False','多算法种子和 HV/IGD+，增大预算做敏感性；NSGA-II 是三目标下合理的对照'),
      ('A15','重要修正','通用方案选择与评分复用年份','迁移矩阵应用年同时用该年的气候和参数；同 4 年择优并宣称推广','嵌套留一年法，选择与评估分开；用同水量/保产约束比较，区别气候迁移和参数迁移'),
      ('A16','重要修正','曲线可视化强制单调','原图分箱取最大产量，再 maximum.accumulate','展示真实散点或确实可行的二维非支配包络；不得把累计最大值当作新可行解'),
      ('A17','数据解释','观测多为数字化重建','LAI 源为论文图提取，CC 为非线性变换；生物量 sigma 为假设，初始深层水部分再分析','追溯原始论文和原表、补测量/数字化误差；不得将假设 sigma 写成实测 SD'),
      ('A18','重要修正','自检不等于科学有效性','check_final 预设首位必须 Kcb/节水必须 15%—30%，部分失败无非零退出；对缺结果的条件分支还可能跳过','改为数据形状、单位、守恒和估计器基准测试；结果排序应是待检验发现'),
      ('A19','写作修正','膝点与三代算法表述不准确','pick_knee 是 95% 门槛内最低灌水量；NSGA-III 原运行 40 代','称 epsilon 约束选择方案；III 为算法名称，不是只进化三代；三目标不自动证明必须 NSGA-III'),
      ('A20','重要修正','按样本数混合年份不等于共同后验','merged_posterior 合并四年非等量样本，2022 第二阶段仅 1500 个人造值','优先分年报告；跨年共享参数使用明确层次结构，不以链长度决定年度权重'),
      ('A21','重要修正','代理对齐目标被误称实测，且并非全部精确对齐','tr_obs/es_obs 等多来自 pre_run_summary 初始模拟；2019 当前 Tr 相对其代理目标仍差 −4.39%','分别保存实测、数字化目标、原模型输出与代理输出；校正验证报告中全部精确复现的说法'),
      ('A22','重要修正','阶段A元数据残留错误配置','YEAR_CONFIG 中 2021 harvest 写为 2020 年，2020—2022 灌溉量亦非现有审计值','从原审计统一生成唯一配置，停止手填多套目标；重新生成元数据并显式版本化')]
    return csv('findings_and_actions',pd.DataFrame(rows,columns=['ID','Level','Finding','Evidence','Action']))

def write_reports():
    ff=findings();fits=tb('calibration_metrics_recomputed');pa=tb('parameter_intervals_verified');di=tb('mcmc_diagnostics_recomputed')
    rows=[]
    for y in [2019,2020,2021]:
        s=read(next((DATA/f'②原始资料包_{y}').rglob('summary.json')))
        rows.append(dict(年份=y,CC样本数=s['CC']['N'],CC_R2=s['CC']['R_Square'],CC_RMSE=s['CC']['RMSE'],
            生物量样本数=s['Biomass']['N'],生物量_R2=s['Biomass']['R_Square'],生物量_RMSE=s['Biomass']['RMSE'],
            观测产量=s['Yield']['yield_observed'],模拟产量=s['Yield']['yield_simulated'],产量误差_pct=s['Yield']['Error_vs_published_pct']))
    mainfit=pd.DataFrame(rows);csv('paper_calibration_table',mainfit)
    knee=tb('original_knees_audited');kn=knee[['Year','Published_yield','Y13_base','Y13_opt','Loss_vs_published_pct','Water_saving_pct','IWP_opt_correct_kg_m3']].copy()
    kn.columns=['年份','文献观测产量','原优化所用基准','原选方案产量','相对观测变化_pct','原表节水_pct','更正IWP_kg_m3']
    dr=[]
    for y,g in di[di.Phase==1].groupby('Year'):
        dr.append(dict(年份=y,Rhat最大值=g.Rhat_max.max(),bulk_ESS最小值=g.ESS_bulk_min.min(),通过原判据=False))
    diagnostic=pd.DataFrame(dr)
    summary_sobol=tb('sobol_seeded_convergence');ss=summary_sobol[(summary_sobol.N==2048)&(summary_sobol.Output=='Y_13pct')&(summary_sobol.Track=='Narrowed_uniform')]
    sob=ss.groupby(['Year','Parameter']).ST.mean().unstack().reindex(columns=NAMES).round(4).reset_index()
    hold=tb('proxy_optimization_selected_holdout');hl=[]
    for y,g in hold.groupby('Year'):
        hl.append(dict(年份=y,训练样本数=64,评估样本数=4096,算法运行次数=3,
            试算节水最小_pct=g.Water_saving_pct.min(),试算节水最大_pct=g.Water_saving_pct.max(),
            绝对保产门槛概率最小_pct=100*g.Validation_prob_95pct_observed.min(),
            绝对保产门槛概率最大_pct=100*g.Validation_prob_95pct_observed.max(),
            评估均值达标次数=int(g.Validation_mean_pass.sum())))
    holdtable=pd.DataFrame(hl);csv('paper_proxy_experiment_summary',holdtable)
    srcmap=[]
    for p in PROJECT.glob('*.py'):srcmap.append(dict(File=p.name,SHA256=digest(p)))
    for p in PROJECT.joinpath('output').glob('*.csv'):srcmap.append(dict(File='output/'+p.name,SHA256=digest(p)))
    csv('reviewed_source_hashes',srcmap)
    report=f'''# URP 合理性审查与改进报告

日期：2026-10-15。审查对象：用户上传的 2019—2022 年 DI 玉米资料、两阶段 MCMC 结果和 DI_PHASE3_NEXTGEN 工程。

## 1. 核心判断

研究方向值得继续：用改进 AquaCrop 描述作物水分过程，再用参数不确定性支持灌溉决策，问题链条明确。当前原始 MCMC 结果中，有可追溯的 2019—2021 校准拟合和季节水量守恒证据；**现有 Sobol、NSGA-III 与跨年推广数值不足以直接作为论文定稿结论**。主要原因不是图片不够好看，而是原模型被未经独立验证的代理替代，2022 第二阶段被构造样本替代，以及校准/验证和优化基准混用。

“已复现”表示本次重新计算得到了相同结果；它不表示相应模型假设为真。“蒙特卡洛评估样本”只是从同一个经验条件分布另外抽样，绝不是外部田间验证。

## 2. 本次实际执行与资料边界

- 检查所有可传输压缩包的 CRC、哈希和内部路径。两个 2021 分年原始包完全重复；三个 DI_PHASE3_NEXTGEN.zip 也逐字节相同。
- 最新单独上传的 Sobol、膝点 CSV、README 和一键脚本与工程包对应文件哈希一致，未把多个版本混用。
- 19 份真实 NPZ：四年各 4 份第一阶段，2019—2021 各 1 份第二阶段。检查形状、有限值、终点状态、接受率，并从原始数组重算诊断。
- 独立重算 36 对 CC 与 27 对生物量的指标；逐日期核对已有逐日输出，重算 3 年 DI/零灌溉季节水量账。
- 原合并明细 4,671,380 行；2019—2021 第二阶段采用固定 400 步 burn-in，可与原检查点逐值对上，但不同于原诊断的动态 burn-in。2022 三列各 1,500 个数与人工 fallback 完全对上。
- 对原 64 个 Pareto 点按原 8 样本复算：目标差值约 10⁻¹⁵，保存点集内部没有相互支配点；不等于证明全局 Pareto 最优。
- 新运行 36 组 Sobol 试验：3 年×2 输入空间×2 样本量×3 scramble，N=512/2048，分析产量与 ET，导出 576 行指数及 bootstrap 半宽。
- 新运行 9 次条件代理 NSGA-III：3 年×3 算法种子、45 参考方向、100 代，每次 4,500 次候选评估；固定第一阶段均值、按第二阶段整行联合样本取 64 组，另用 4,096 组评估。
- 大于 32 MiB 的 3 个整包受文件传输上限影响未读取；可读取分包和重复轻量工程已覆盖本次审查所用材料。没有据此推断那些整包必定不含其他内容。
- 本次没有重跑原版 Modified DI AquaCrop，没有重新进行 MCMC；原模型源码、2022 真实第二阶段检查点、2021/2022 真实分次灌溉与完整逐日纠偏资料仍待补。

## 3. 可以保留的结果

### 3.1 校准拟合

{mdtable(mainfit)}

CC 无量纲；生物量和产量单位 t/ha，产量为 13% 含水率。R² 用 1−SSE/SST，未用相关系数平方替代。单年产量仅一对值，不计算单年产量 R²。上述拟合值来自已有输出；本次验证了配对和计算，没有验证原模拟器当前可重新运行。

### 3.2 数值过程一致性

原改进模型季节水量平衡残差约 10⁻¹² mm，量账内部一致。2021 DI 的 2.4 m 剖面季末储水增加约 169.97 mm，应进入水分效率和跨年管理解释。守恒是必要条件，不能替代真实土壤水和通量验证。零灌溉仍是未验证反事实。

### 3.3 参数补偿和边界值得作为论文讨论重点

真实第二阶段 WP_late—HI0 的相关系数为 2019 −0.871、2020 −0.595、2021 −0.463。2020、2021 WP_early 在先验下界 1% 宽度内的样本质量约 11.43%、23.65%；CCx 在 2019、2020 上界 1% 宽度内约 22.14%、23.06%。这些是诊断线索，不应通过任意拓宽边界直接追求更好拟合。

## 4. 必须修正的关键问题

{mdtable(ff[['ID','Level','Finding','Action']])}

### 4.1 为什么“独立验证”说法不成立

`aquacrop_surrogate.solve_k_cgc → load_cc_obs` 使用 LAI-CC 观测最小化 RMSE；`validate_model_chain` 又读取同一文件计算 CC R²。因此这些数值是校准拟合。关闭 k_B 也不能自动得到独立产量检验：a_cc、f_mulch、k_cgc 仍使用该年的目标或观测，而且 y13_obs 的 2020/2021 值还是初始模型输出。文档中的“独立”必须撤回。

### 4.2 对原自省文档也要纠正的地方

原 `load_posterior_samples` 的确跨阶段独立取行，但第二阶段的 WP_early、WP_late、HI0 来自**同一行**，所以它没有完全打散 WP_late—HI0 的内部相关性。正确批评是“跨阶段条件结构未传播，8 样本下风险和相关估计不稳”。不能照搬文档中“相关被全部抹掉”的说法。

也不能把“联合后验做秩变换后直接 Saltelli 分析”当作通用修正。经典 Sobol 的方差分解假设独立输入；保留输入依赖需要适合依赖输入的指数/条件抽样或 Shapley 分解，且要说明解释对象。

### 4.3 对齐目标与记录不能混称实测

代理的 tr_obs/es_obs 等目标多来自原 pre_run_summary 的**初始模拟输出**，不是直接观测。2019 年当前代理蒸腾约 558.77 mm，相对其目标 584.456 mm 仍低约 4.39%；原文档中“Tr/Es/ET 全部精确复现”的结论不适用于当前代码。季节总量比例缩放 ETo 也只保证相应总量，不能证明逐日风速纠偏正确。所有文献中未经证实的 ±1%—2% 误差范围都应视为假设，不能写成已估计不确定度。

### 4.4 优化基准与水生产率

{mdtable(kn)}

2022 行只展示原结果错误来源，不应进入正式后验结论。2020、2021 原所谓 95% 产量约束相对文献观测实际不成立。正确的水生产率换算为 **IWP[kg/m³] = 100 × Y[t/ha] / I[mm]**；原代码的 1000Y/I 高了 10 倍，但原节水率本身不因该单位换算而改变。

原选择规则是“95% 门槛内最低灌溉量”，属于 epsilon 约束筛选，不是经过曲率或几何定义验证的膝点。

## 5. 本次新增试算告诉了什么

### 5.1 敏感性排序有年度差异

{mdtable(sob)}

这些是代理、独立收窄均匀区间、N=2048、3 scramble 均值的 ST，不是真实联合后验指数。2019 首位 WP_late，2020/2021 首位 Kcb。只报跨年平均“Kcb 第一”会掩盖年度差异。图 7—8 同时给出估计误差、样本量和输出方差。CAI 只能暂作相对贡献变化的描述指标，不能称为已证实的方法创新或识别性指标。

### 5.2 增加算法预算后，风险问题仍存在

{mdtable(holdtable)}

这些较高节水率只是**改变样本组织、优化预算和门槛之后的代理敏感性试验**，不构成新的推荐节水结论，也不能与原表构成单因素因果对比。2021 的 3 个训练集选择方案在独立经验分布抽样后，均值都略低于门槛；9 个方案超过绝对保产门槛的概率仅约 48%—59%。这说明只约束均值、再最小化标准差仍不能自动保证高可靠性。

HV 末 20 代变化约 −0.005% 至 +0.287%，显示部分运行进入平台，**不能据此保证全局收敛**。该 HV 是当前可行种群的指标，不是历史累积最优档案，所以允许小幅下降。3 个算法种子的差异、经验分布的蒙特卡洛误差与真实模型误差是三种不同不确定性。

## 6. 改进优先次序与可检验标准

1. **先恢复科学输入合同。** 找回 2022 第二阶段原检查点；将人工样本隔离为 synthetic，缺少真实数据时默认报错。补原 Modified DI 模型与依赖版本、土壤网格/水分/覆膜设置、真实灌溉与纠偏逐日资料。真实模型适配器目前只是未实现骨架，不能靠开启开关完成。
2. **先过过程审计，再谈管理优化。** 对原模型基准、零灌溉与随机管理点核对产量含水率、逐日水量、HI、生物量及时间窗口；代理需在未参与训练的参数/管理点与原模型比对，并补低水量胁迫区域。设计标准模型、仅改蒸发、仅改两阶段WP、两处同时改的消融对照，按相同数据划分比较样本外表现，判断增加自由度是否真的改善预测。
3. **修复采样与推断。** 继续独立 ensembles，目标 Rhat<1.01、bulk/tail ESS 满足用途、tau 稳定且链足够长。第二阶段至少增加独立 ensembles；若只能固定第一阶段，论文就明确只作条件分析。完整传播需联合/分层校准或按第一阶段样本重建第二阶段条件分布。
4. **明确验证边界。** 留一年或留处理验证；所有气象/冠层/产量校正系数只在训练部分估计。若留一年不能识别作物参数，需跨年共享/层次结构，不能继续使用被留出年的参数。
5. **重做敏感性解释。** 保留独立均匀区间作为响应实验；依赖后验另用合适的方法。N 递增与重复 scramble，报告区间和输出方差，特别检验先验边界及数字化误差。
6. **重做稳健决策。** 决策变量保持可管理的量/日期，参数不作为可调管理变量。明确农艺约束、供水上限、最小灌水间隔及单次水量上限。以真实观测或同模型配对基准定义保产目标，选择机会约束或低分位/CVaR，而非事后仅筛均值。
7. **最后生成论文结果。** 原模型复算整个候选集或有代表性的前沿点；NSGA-II/III 与简单分段灌溉作对照。通用方案采用留一年嵌套选择，报告产量、水量、风险与土壤储水变化，不只比较产量。

## 7. 不能在当前论文中直接写的句子

- “四年已获得收敛的八参数联合后验。”
- “独立验证证明代理与 AquaCrop 一致。”
- “最终平均节水 20.7%，减产不超过 5%。”
- “Kcb 在所有年份都是第一敏感参数。”
- “2022 年第二阶段 MCMC 取得 1500 个有效后验样本。”
- “一套通用灌溉制度已证明可以推广。”

可替换为：“阶段性结果显示校准拟合与过程数值一致性较好，但采样诊断、代理保真度、独立验证与风险约束仍需加强；敏感性与管理结果目前为方法探索。”

## 8. 图表与可复现文件

14 张图均同时导出 300 dpi PNG 与矢量 PDF，见 figures/；完整表见 URP_审查与结果表.xlsx。`src/review_core.py`、`experiments.py`、`make_figures.py` 和 `make_documents.py` 为本次新增脚本；上传源文件未改动。依赖版本、输入哈希及运行日志随包提供。

本次新增试验随机种子、样本量、变量和证据边界已经写入脚本和结果表。复现源文件仍依赖用户提供的完整附件及正确解压布局；原 Modified DI 模型尚未具备可复算条件。
'''
    (OUT/'URP_合理性审查报告.md').write_text(report)
    paper=f'''# 滴灌玉米改进 AquaCrop 模型的分阶段校准、不确定性诊断与稳健灌溉决策

## 论文框架与图表插入稿

版本：2026-10-15；性质：带已核验数据与图的写作框架，不是已完成真实模型复算的投稿定稿。

**建议主线：** 从“模型拟合精度”推进到“哪些不确定性妨碍灌溉决策可靠性”。MCMC、Sobol 和 NSGA-III 是服务这个问题的工具，不宜用算法堆叠本身充当创新点。优先强调分阶段条件结构、参数补偿、代理误差与保产风险之间的联系。

证据标记：**已复核**＝从真实检查点或配对输出重新计算；**代理探索**＝本次/原工程的简化模型试算；**待补证据**＝无法由现有原始文件确认。2022 年第二阶段人工样本不进入主文的后验结论。

## 摘要草稿

为明确滴灌玉米模型参数不确定性向灌溉决策的传递方式，本研究以 2019—2022 年气象、冠层与土壤初始水分资料为基础，复核改进 AquaCrop 的分阶段校准与后续优化链条。2019—2021 年冠层覆盖度校准 R² 为 0.979—0.993，生物量校准 R² 为 0.969—0.993，年产量相对误差为 −4.18% 至 +0.92%；季节水量收支内部闭合。但四年第一阶段均未达到原定收敛阈值，第二阶段为固定第一阶段均值条件下的单 ensemble 分布。敏感性重算表明，代理模型的重要参数排序存在年度差异；增加条件抽样与多次优化运行后，平均保产约束仍不能保证高保产概率。结果提示，建立可信的灌溉制度需要同时控制采样诊断、数据复用、模型替代误差及风险约束。现有优化数值仅作方法探索，定量管理结论需补全原模型复算和独立验证。

关键词：滴灌玉米；改进 AquaCrop；条件贝叶斯校准；参数补偿；敏感性分析；灌溉风险。

## 1 引言：围绕问题展开的四段结构

**第 1 段：科学与应用背景。** 灌溉用水约束下，需要同时关注产量、季节耗水、土壤储水与管理风险。研究区、用水问题和玉米生产背景应引用真实来源，当前资料不足以填写地名、经纬度或推广面积。

**第 2 段：模型与数据问题。** AquaCrop 的产量形成依赖冠层、蒸腾、生物量与收获指数过程；滴灌和覆膜条件下的结构改动必须与标准模型区分。高校准 R² 可能与参数补偿、边界积累并存，不能自动支持管理外推。

**第 3 段：现有流程缺口。** 分阶段校准容易忽略跨阶段不确定性，独立区间敏感性容易被误写成后验归因，平均产量优化容易被误解为高概率保产。这里分别设置可检验问题，避免仅以“采用三种高级算法”作为贡献。

**第 4 段：研究目标。** (i) 复核数据与过程一致性；(ii) 诊断条件参数的不确定性和补偿；(iii) 比较输入空间对敏感性排序的影响；(iv) 检验管理方案的均值与风险表现，并设计独立年份验证。方法学上的价值应在完成原模型复算后再判断。

{figure('F01')}

## 2 材料与数据

### 2.1 试验与研究区信息（待原文补全）

应补：研究区与坐标、气候背景、土壤质地/田间持水量/萎蔫点/饱和导水率、玉米品种、密度、播收日期、滴灌覆膜与施肥、处理和重复设置、原始研究文献与测量方法。不能依据文件名 DI 推断所有实验设计，也不能将数字化资料写成自做田间实验。

### 2.2 资料来源、变量与误差

| 资料 | 当前证据 | 建议写法与补充 |
| --- | --- | --- |
| 气象 | 四年完整日序列，原 ETo 与审计的 Old_ETo 对上 | 称提供的气象资料；补来源与逐日纠偏文件 |
| 冠层 | LAI 由论文图数字化，CC=1.005(1−exp(−0.6LAI))^1.2 | 报告转换公式与误差；非独立冠层实测 |
| 生物量 | 原配对表含数字化值与假设 sigma | 区分读图误差、测量误差与似然假设 |
| 初始土壤水 | 0—1m 近似读图，深层部分来自再分析，覆盖至 2.4m | 报告来源和敏感性；不称完整原始分层实测 |
| 年产量 | 单年一对，13% 含水率 | 报告绝对/相对误差，不做单年相关指标 |
| 遥感 | 2019—2021 CSV 的 IrriMetho 标记 BI | 必须核对与 DI 地块对应关系，不能直接混合 |
| 灌溉记录 | 部分年度总量有记录，2021/2022 分次为构造 | 补真实记录；当前图表显式标记假设 |

{figure('F14')}

### 2.3 分析样本及证据分层

四年第一阶段共有 16 个独立 ensemble 检查点，每个为 2000×32×5。2019—2021 第二阶段各有 1 个 2000×32×3 检查点；2022 第二阶段缺原始链，其 1500 个近似数值已确认是正态构造并裁剪，不用于主分析。已有总结文档声称四年第二阶段均完成，必须通过找回原始链解决这一证据不一致。

## 3 方法

### 3.1 模型结构与水量收支

正式名称建议写 Modified DI AquaCrop，说明相对标准 AquaCrop 的两处改动：蒸发模块的冠层输入变化和 WP_early/WP_late 两阶段有效水分生产力。完整数学式、代码版本和差异必须从原实现核验。不能仅凭 B×HI 的代数一致性推断响应面与 AquaCrop 完全一致。

水量账：ΔS=P+I+CR+GwIn−Tr−Es−Runoff−DeepPerc−TileDrain，并单独处理地表储水。ET=Tr+Es 为派生量；若似然已经含 Tr、Es，不应无条件再把 ET 当独立信息计入。产量含水率换算 Y13=Ydry/0.87；IWP=100Y13/I，单位 kg/m³，I 以 mm 计。

### 3.2 两阶段条件校准与先验

第一阶段 θ1=(CCx,CGC_CD,CDC_CD,SenescenceCD,Kcb)，使用冠层和季节 Tr/Es 信息；第二阶段 θ2=(WP_early,WP_late,HI0)，固定 θ1=第一阶段保留均值，使用生物量与产量。

当前分布应写 **p(θ2 | D2, θ1=μ1)**，而不是八参数联合后验。若要完整传播，需要对 θ1 抽样后获得相应条件分布，再积分；或联合/分层建模。不能把现有 p(θ2|μ1) 与 p(θ1) 随意拼接。

给出完整先验边界和密度；原合同 CDC、SenescenceCD 有正态先验成分，原后续全均匀“先验轨”不等于原贝叶斯模型的全部先验。说明生物量 sigma 为假设，进行误差与先验边界敏感性试验。文档未提供的真实似然细节应保留待补，不自行猜测。

### 3.3 采样诊断

第一阶段对跨独立 ensembles 的匹配 walker 组计算秩标准化 split Rhat 与 bulk/tail ESS，汇报各组极值；此为保守组诊断，不能解释为把全部 walker 当独立链合并后的 ESS。检查 tau 稳定性与足够链长。第二阶段只有一个 ensemble，无法报告独立多链 Rhat；N/tau 通过也不构成多链收敛证明。

### 3.4 校准拟合、预测与验证分开

R²=1−SSE/SST；RMSE=sqrt(mean((S−O)²))；Bias=mean(S−O)。按日期匹配，一年一对产量只报偏差。校准观测再评分属于拟合，不叫独立验证。最终采用留一年/留处理评价，所有校正和参数选择均嵌套在训练集内。只有四年时，不做年际趋势或因果归因。

结构改进的论证建议设置四个对照：A0 标准 AquaCrop；A1 仅改蒸发冠层输入；A2 仅改两阶段 WP；A3 两处均改。固定相同气象与土壤资料、校准预算和留出划分，比较留出年份的冠层、生物量、产量、水量和预测区间，而不只比较样本内 R²。这项消融比较尚未执行，是比继续叠加算法更有价值的论文补强任务。

### 3.5 两类敏感性问题

**当前可复现的响应实验：** 先验边界独立均匀输入，与从样本 0.5%—99.5% 分位区间构成的收窄独立均匀输入比较，均用经典 Sobol。两者是不同设计空间，不应把后者称为真实 Bayesian posterior Sobol。

**待完成的后验归因：** 保留真实后验内部依赖与条件结构，采用合适的依赖输入指标/条件抽样或 Shapley 效应。普通秩变换/copula 不会自动使经典独立 Sobol 在相关输入下有效。

报告 S1、ST、bootstrap 区间、重复 scramble、样本量及输出方差。CAI 暂称“相对总效应变化比”，不得直接证明参数识别性；创新性需系统文献对照。

### 3.6 灌溉多目标与风险约束

管理变量取可实际控制的灌溉量或日期，作物参数属于不确定输入。原算法固定 8 个灌溉日期，只优化每次 [0,120]mm；允许近零灌水量。120mm 是否符合滴灌条件需农艺核验。

可用三目标 min(−E[Y],I,SD[Y])，但须明确只约束 E[Y]≥0.95Yref 不等于高概率保产。建议引入 Pθ(Y≥0.95Yref)≥α，或低分位/CVaR；先检查基准是否有可行解。Yref 可为文献观测，也可为同模型同参数样本下的配对基准，两者回答不同问题，均应报告。

NSGA-III 的 III 是算法名称，原运行 40 代，并非只进化三代；三目标下可比较 NSGA-II 与 NSGA-III，不能直接声称后者必然优越。报告参考方向、种群、终止条件、算法种子、HV 参考点与独立候选评估。原“95% 内最低水量”的选择规则按 epsilon 约束描述，而不直接叫几何膝点。

### 3.7 跨年可迁移性

跨年比较要控制总水量和保产约束。若应用年同时使用本年度参数与气候，只能称校准后的管理情景迁移。要检验未知年份推广，需留一年：在训练年份中选通用制度，在完全留出的气候/观测上评价，不能再用其产量反标定或选方案。

## 4 结果：可直接填写的段落与对应图表

### 4.1 数据和模型输出的一致性【已复核】

现有 2019—2021 校准配对表与逐日输出按日期一致，CC 和生物量指标复算与汇总一致。36 对 CC 的分年度 R² 为 0.979—0.993；27 对生物量的分年度 R² 为 0.969—0.993。此处仅能说明校准拟合较好，不能称为模型已获独立验证。

表 1　可追溯的分年度校准指标。产量为 t/ha，13% 含水率。

{mdtable(mainfit)}

{figure('F02')}

### 4.2 收敛证据与参数边界【已复核】

表 2　第一阶段诊断：从 16 份检查点独立重算的保守组极值。

{mdtable(diagnostic)}

四年第一阶段都未达到原预设标准，因此后验区间只作为当前保留链的描述。第二阶段 2019 N/max(tau)≈58，2020≈38、2021≈42；只有一个 ensemble，不能据其样本数声称独立多链收敛。

{figure('F03')}
{figure('F04')}

### 4.3 参数补偿与可识别性【已复核】

WP_late 与 HI0 呈负相关，2019 最强，提示生物量与产量数据之间存在补偿通道。2020/2021 WP_early 贴近下界，HI0 接近上界，应检验参数边界、两阶段 WP 结构和观测误差设定，而不是把年际参数变化直接解释为作物生理适应。

{figure('F05')}

### 4.4 水量守恒与模型替代差异【已复核＋代理诊断】

原季节水量内部闭合；2021 灌溉情景期末储水增加约 170mm，说明灌水总量不能只与当年 ET 或产量比较。代理以 Dr=0 和固定 TAW 桶替代初始分层水，且在裁剪亏缺量时未报告溢出通量。2019—2021 未报告溢出分别约 50.7、101.9、199.5mm，可能对应深渗/径流等缺失项，不能把它们理解为已核验的实际深渗。

{figure('F06')}

### 4.5 敏感性排序与输入空间【代理探索】

表 3　收窄独立均匀区间的产量总效应 ST，N=2048、3 个 scramble 均值。

{mdtable(sob)}

2019 首位为 WP_late；2020/2021 首位为 Kcb。这个结果依赖代理、年度校准系数、固定灌溉安排和人为构造的输入分布。平均排序不能替代逐年结果，且不能据此认定相应物理参数已被证实为真实系统的首要因子。

{figure('F07')}
{figure('F08')}

### 4.6 原管理方案的门槛核查【原代理结果的审计】

表 4　原选择方案按正确观测基准和单位重新解释。

{mdtable(kn)}

表中 2022 是人工第二阶段输入的示范行，不进入正式统计。2020/2021 的原“保产95%”方案相对文献观测实际损失 5.73%/7.75%；这不是重新模拟得到的作物预测，只是纠正分母后重新计算原结果。

{figure('F09')}

### 4.7 加强采样和算法预算之后的风险【代理探索】

每年运行 3 个算法种子、100 代；用 64 个真实第二阶段整行样本训练目标、另取 4096 个样本评估。第一阶段均值保持固定，故这是一项条件试验，尚未传播第一阶段及模型结构不确定性。

表 5　条件代理试算汇总。仅用于方法诊断，不能成为定稿节水建议。

{mdtable(holdtable)}

尽管训练阶段均值满足门槛，2021 在大样本评估时三个方案均略未过门槛。各年度选择方案的绝对保产门槛概率大约 48%—59%，表明“均值满足”和“低风险”不等价。这个概率是当前经验条件分布下的代理结果，不是田间发生概率。

{figure('F11')}
{figure('F12')}

### 4.8 跨年迁移的解释范围【代理探索】

当前迁移矩阵只能作为样本内情景对比。不能以四年平均产量接近，便断言一套制度可跨年推广；年份总水量不同、参数逐年重标定，以及选择/评分复用年份均需控制。正式结果待嵌套留一年验证与真实模型复算。

{figure('F13')}

## 5 讨论：建议围绕四条机制论证

### 5.1 “高拟合、有限识别”为什么可以同时出现

冠层 R² 高，是已有点的重现证据；链的混合效率、参数贴边和 WP—HI 补偿回答不同问题。讨论观测频次、数字化误差、似然 sigma 与生物量/产量约束对识别性的作用。不要用高 R² 反驳未收敛诊断。

### 5.2 模型误差、参数误差与管理风险分别是什么

当前条件参数传播不含第一阶段、气象纠偏、初始水和模型结构误差；把它的 SD 当作全部风险，会低估风险来源。代理和真实模型差异可能改变排序、前沿和选解，不只是统一平移产量。

### 5.3 不能靠“优美前沿”代替物理与农业约束

高灌水总量可能进入土壤储水或深渗。要核对流量/灌期约束、灌水次数与末次灌水必要性；可采用真实物候阶段而非机械复用绝对日期。原图最大累计化生成的平滑包络不应当作实际可行解。

### 5.4 研究局限与可推广条件

仅四年、资料多来自二次提取、缺完整独立验证和 2022 真链；目前适合阶段性模型与方法诊断。正式推广需真实模型交叉检查、保留年份检验、更多气候情景/地块及可执行的灌溉限制。不要将 n=4 的相关散点图写成气候因果归因。

## 6 结论：当前可以写的三点

1. 2019—2021 校准配对与原模型季节水量账可复现，说明已有流程在数值输出层面具有一致性，但不构成独立外部验证。
2. 四年第一阶段的严格采样标准尚未满足，第二阶段存在条件结构、补偿和边界效应，当前不能声称获得收敛的完整联合后验。
3. 代理试算揭示输入分布、基准和风险约束会影响优化解释；正式节水幅度、优先敏感参数和通用灌溉制度仍需补原始证据并在真实模型中核验。

## 7 补充材料与定稿清单

补图 S1（下图）为原分次安排的审计展示，不作田间推荐。补表建议包含逐文件来源哈希、分年先验/后验区间、所有诊断、Sobol 各种子结果、优化 HV 轨迹和 4096 样本评估。

{figure('F10')}

**定稿前必需：** 找回 2022 原始第二阶段链；补原 Modified DI 模型而不是仅标准 aquacrop 包；补真实分次灌水和逐日纠偏资料；改正验证泄漏、基准与单位；完成诊断达标的推断与独立验证。若暂时无法取得，应将论文定位为阶段性方法审计，删去最终农业建议。

## 8 推荐核对的基础方法文献

以下用于方法论定位；原试验文献、区域资料与原始数据引用仍待补全，当前不构成系统文献综述。

1. Steduto P., Hsiao T.C., Fereres E., Raes D. (2012). Crop yield response to water. FAO Irrigation and Drainage Paper 66.
2. Goodman J., Weare J. (2010). Ensemble samplers with affine invariance. Communications in Applied Mathematics and Computational Science 5(1), 65–80. DOI: 10.2140/camcos.2010.5.65.
3. Vehtari A. et al. (2021). Rank-normalization, folding, and localization: an improved R-hat for assessing convergence of MCMC. Bayesian Analysis 16(2), 667–718. DOI: 10.1214/20-BA1221.
4. Saltelli A. et al. (2010). Variance based sensitivity analysis of model output. Design and estimator for the total sensitivity index. Computer Physics Communications 181, 259–270. DOI: 10.1016/j.cpc.2009.09.018.
5. Deb K., Jain H. (2014). An evolutionary many-objective optimization algorithm using reference-point-based nondominated sorting approach, Part I. IEEE Transactions on Evolutionary Computation 18(4), 577–601. DOI: 10.1109/TEVC.2013.2281535.
6. emcee 文档：autocorrelation analysis；Stan 参考手册：posterior analysis；SALib 与 pymoo 文档。应在投稿时按实际使用版本补齐软件引用。
'''
    (OUT/'URP_论文框架_含数据与图.md').write_text(paper)
    return report,paper

def pdf_report(text,path):
    pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='ZHBody',fontName='STSong-Light',fontSize=10,leading=16,spaceAfter=6,wordWrap='CJK'))
    styles.add(ParagraphStyle(name='ZHTitle',fontName='STSong-Light',fontSize=19,leading=27,spaceAfter=15,textColor=colors.HexColor('#25384A'),wordWrap='CJK'))
    styles.add(ParagraphStyle(name='ZH1',fontName='STSong-Light',fontSize=15,leading=23,spaceBefore=15,spaceAfter=9,textColor=colors.HexColor('#176B87'),wordWrap='CJK',keepWithNext=True))
    styles.add(ParagraphStyle(name='ZH2',fontName='STSong-Light',fontSize=12,leading=19,spaceBefore=10,spaceAfter=7,textColor=colors.HexColor('#25384A'),wordWrap='CJK',keepWithNext=True))
    styles.add(ParagraphStyle(name='ZHSmall',fontName='STSong-Light',fontSize=7.5,leading=11,wordWrap='CJK'))
    def clean(s):
        s=re.sub(r'\*\*|`','',s).replace('R²','R^2').replace('10⁻¹²','10^-12').replace('m³','m^3').replace('−','-')
        s=s.translate(str.maketrans({'²':'2','³':'3','¹':'1','⁻':'-'}))
        return escape(s)
    doc=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=36,leftMargin=36,topMargin=40,bottomMargin=38,
        title=path.stem,author='URP 数据复核与论文框架')
    body=[];lines=text.splitlines();i=0;width=A4[0]-72
    while i<len(lines):
        line=lines[i].strip();i+=1
        if not line:continue
        im=re.match(r'!\[(.*?)\]\((.*?)\)',line)
        if im:
            pp=OUT/im.group(2);w,h=Image.open(pp).size;h2=width*h/w
            body.append(RLImage(str(pp),width=width,height=h2));body.append(Spacer(1,5));continue
        if line.startswith('|'):
            tablelines=[line]
            while i<len(lines) and lines[i].strip().startswith('|'):tablelines.append(lines[i].strip());i+=1
            data=[]
            for rr in tablelines:
                cells=[x.strip() for x in rr.strip('|').split('|')]
                if all(re.fullmatch('[: -]+',c) for c in cells):continue
                data.append([Paragraph(clean(c),styles['ZHSmall']) for c in cells])
            if data:
                cols=len(data[0]);t=Table(data,colWidths=[width/cols]*cols,repeatRows=1,hAlign='LEFT')
                t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DDE8EE')),('VALIGN',(0,0),(-1,-1),'TOP'),
                    ('LINEBELOW',(0,0),(-1,0),.8,colors.HexColor('#176B87')),('LINEBELOW',(0,-1),(-1,-1),.5,colors.HexColor('#AABBC8')),
                    ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F4F7F9')]),('LEFTPADDING',(0,0),(-1,-1),4),
                    ('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
                body.extend([t,Spacer(1,10)])
            continue
        level=len(line)-len(line.lstrip('#'))
        if level:style=styles['ZHTitle' if level==1 else ('ZH1' if level==2 else 'ZH2')];line=line.lstrip('# ').strip()
        else:style=styles['ZHBody']
        if line.startswith('- '):line='• '+line[2:]
        body.append(Paragraph(clean(line),style))
    def footer(canvas,doc):
        canvas.setFont('STSong-Light',8);canvas.setFillColor(colors.HexColor('#627383'))
        canvas.drawString(36,22,'URP  |  证据复核与论文框架  |  2026-10-15')
        canvas.drawRightString(A4[0]-36,22,str(doc.page))
    doc.build(body,onFirstPage=footer,onLaterPages=footer)

def word_report(mdname):
    from docx import Document
    from docx.shared import Pt,Cm,RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    # Pandoc supplies semantic headings, editable tables, and embedded figures.
    target=OUT/(Path(mdname).stem+'.docx')
    subprocess.run(['pandoc',str(OUT/mdname),'-o',str(target),'--resource-path',str(OUT)],check=True,capture_output=True)
    d=Document(target)
    for sec in d.sections:
        sec.page_width=Cm(21);sec.page_height=Cm(29.7)
        sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.8);sec.left_margin=Cm(1.8);sec.right_margin=Cm(1.8)
        p=sec.footer.paragraphs[0];p.alignment=2
        rr=p.add_run('URP  |  ');rr.font.size=Pt(8)
        field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');p._p.append(field)
    for style in d.styles:
        if style.type==1:
            style.font.name='Calibri';style._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体')
    for name in ['Normal','Body Text','First Paragraph']:
        if name in d.styles:
            d.styles[name].font.size=Pt(10.5);d.styles[name].paragraph_format.line_spacing=1.25
    for name in ['Heading 1','Heading 2','Heading 3']:
        if name in d.styles:d.styles[name].font.color.rgb=RGBColor.from_string('176B87')
    for t in d.tables:
        if 'Table Grid' in d.styles:
            t.style='Table Grid'
        else:
            borders=OxmlElement('w:tblBorders')
            for edge in ['top','left','bottom','right','insideH','insideV']:
                border=OxmlElement('w:'+edge)
                for key,value in [('val','single'),('sz','4'),('color','C6D1D9')]:
                    border.set(qn('w:'+key),value)
                borders.append(border)
            t._tbl.tblPr.append(borders)
        for cell in t.rows[0].cells:
            sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'DDE8EE');cell._tc.get_or_add_tcPr().append(sh)
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for r in p.runs:r.font.size=Pt(8)
    # Keep images within the A4 text width even if the PNG contains wide panels.
    maxwidth=Cm(17.0)
    for sh in d.inline_shapes:
        if sh.width>maxwidth:
            ratio=maxwidth/sh.width;sh.height=int(sh.height*ratio);sh.width=maxwidth
    d.save(target)

def workbook():
    wb=Workbook();index=wb.active;index.title='目录';index.append(['工作表','数据文件','用途说明'])
    for no,p in enumerate(sorted(TABLES.glob('*.csv')),1):
        title=f'{no:02d}_'+p.stem[:26];ws=wb.create_sheet(title);df=pd.read_csv(p)
        ws.append(df.columns.tolist())
        for row in df.itertuples(index=False,name=None):
            ws.append([None if pd.isna(v) else v for v in row])
        ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
        for cell in ws[1]:cell.fill=PatternFill('solid',fgColor='176B87');cell.font=Font(color='FFFFFF',bold=True)
        for col in ws.columns:
            name=col[0].column_letter;ws.column_dimensions[name].width=min(42,max(13,max(len(str(c.value or '')) for c in list(col)[:80])+2))
        for row in ws.iter_rows(min_row=2):
            for c in row:
                if isinstance(c.value,float):c.number_format='0.0000'
        index.append([title,p.name,'详见审查报告与各列标签；proxy 表均为代理探索'])
    index.column_dimensions['A'].width=35;index.column_dimensions['B'].width=55;index.column_dimensions['C'].width=65
    wb.save(OUT/'URP_审查与结果表.xlsx')

def html_gallery():
    captions=read(OUT/'figure_captions.json');cards=[]
    for r in captions:
        b64=base64.b64encode((OUT/'figures'/r['file']).read_bytes()).decode()
        cards.append('<article><h2>'+html.escape(r['title'])+'</h2><img loading="lazy" src="data:image/png;base64,'+b64+'"><p>'+html.escape(r['caption'])+'</p></article>')
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>URP 图表与证据</title><style>body{margin:0;background:#edf2f5;color:#25384a;font-family:system-ui,"Noto Sans CJK SC",sans-serif}header,main{max-width:1200px;margin:auto;padding:28px}header{background:#153f55;color:white;border-radius:0 0 20px 20px}article{background:white;padding:26px;margin:24px 0;border-radius:15px;box-shadow:0 4px 18px #263c5010}h1{font-size:30px}h2{font-size:19px;color:#176b87}p{line-height:1.8;color:#596b78}header p{color:#dbe7ed}img{width:100%;height:auto}strong{color:#b24c47}</style><header><h1>URP：从拟合到可信决策</h1><p>14 张可溯源图表 · 19 份真实检查点 · 36 组 Sobol 试验 · 9 次条件代理优化<br>四年第一阶段均未达原定采样标准；2022 人造第二阶段输入已从新分析中剔除。</p></header><main><article><strong>阅读提示</strong><p>校准拟合、数值复现、代理探索与独立验证是不同证据。当前图表不能证明最终节水幅度或灌溉制度可在田间推广。</p></article>'''+''.join(cards)+'</main></html>'
    (OUT/'URP_图表画册.html').write_text(page)

def manifest():
    arr=[]
    for p in Path('/workspace/attachments').rglob('*'):
        if p.is_file():arr.append(dict(File=p.name,SHA256=digest(p),Bytes=p.stat().st_size))
    csv('all_accessible_upload_hashes',arr)
    packages=['numpy','pandas','scipy','matplotlib','arviz','emcee','SALib','pymoo','python-docx','reportlab','openpyxl','Pillow','pypdf']
    versions={p:md.version(p) for p in packages}
    (ROOT/'requirements-verified.txt').write_text('\n'.join(f'{p}=={v}' for p,v in versions.items())+'\n')
    (OUT/'software_versions.json').write_text(json.dumps(versions,indent=2))

if __name__=='__main__':
    manifest();report,paper=write_reports();workbook()
    for name,text in [('URP_合理性审查报告',report),('URP_论文框架_含数据与图',paper)]:
        pdf_report(text,OUT/(name+'.pdf'));word_report(name+'.md');print('Wrote documents:',name,flush=True)
    html_gallery();print('Documents, workbook and gallery completed.',flush=True)
