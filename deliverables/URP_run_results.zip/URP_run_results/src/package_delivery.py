"""Build the downloadable report bundle without duplicating the uploaded raw archives."""
from pathlib import Path
import zipfile,hashlib,json
root=Path(__file__).resolve().parents[1];out=root/'artifacts'
files=[]
excluded={'verified_phase_specific_draws.npz','original_summary_extracted.txt','delivery_file_manifest.json'}
for base in [root/'src',out]:
    for p in base.rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and 'qa' not in p.parts and p.name not in excluded:
            files.append(p)
files.extend([root/'README_交付说明.md',root/'requirements-verified.txt'])
for p in (root/'data/nextgen/DI_PHASE3_NEXTGEN').rglob('*'):
    if p.is_file() and p.suffix in ['.py','.md','.csv','.json'] and '__pycache__' not in p.parts:files.append(p)
manifest=[{'file':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
          for p in sorted(set(files))]
mp=out/'delivery_file_manifest.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2));files.append(mp)
zp=root/'URP_审查_论文框架_图表与代码.zip'
with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(set(files)):z.write(p,arcname=str(Path('URP_review')/p.relative_to(root)))
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    for r in manifest:
        assert hashlib.sha256(z.read('URP_review/'+r['file'])).hexdigest()==r['sha256']
figzip=root/'URP_14张图_PNG与矢量PDF.zip'
with zipfile.ZipFile(figzip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted((out/'figures').glob('*')):z.write(p,arcname=p.name)
with zipfile.ZipFile(figzip) as z:assert z.testzip() is None
print(json.dumps({'bundle':str(zp),'bytes':zp.stat().st_size,'files':len(files),
                  'figure_bundle':str(figzip),'checksums':'PASS'},ensure_ascii=False))
