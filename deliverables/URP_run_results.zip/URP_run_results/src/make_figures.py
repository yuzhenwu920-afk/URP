"""Publication-style figures. Every numeric panel is linked to exported audit tables."""
from review_core import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.colors import Normalize
from PIL import Image,ImageOps,ImageDraw

FIG=OUT/'figures';FIG.mkdir(exist_ok=True)
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
fm.fontManager.addfont(font)
plt.rcParams.update({'font.family':[fm.FontProperties(fname=font).get_name(),'DejaVu Sans'],
    'font.size':10,'axes.titlesize':12,'axes.labelsize':10,'axes.spines.top':False,
    'axes.spines.right':False,'axes.edgecolor':'#6C7886','axes.linewidth':.7,
    'axes.titlepad':12,'xtick.labelsize':9,'ytick.labelsize':9,'axes.unicode_minus':False,
    'figure.facecolor':'white','axes.facecolor':'white','grid.color':'#E5E9EE',
    'grid.linewidth':.6,'legend.frameon':False,'savefig.facecolor':'white',
    'pdf.fonttype':42,'ps.fonttype':42})
C={2019:'#176B87',2020:'#C3842C',2021:'#805CA2',2022:'#8E99A5'}
RED='#B24C47';DARK='#25384A';GRAY='#97A3B0';TEAL='#3B8E84'
captions=[]
def table(n): return pd.read_csv(TABLES/(n+'.csv'))
def panel(ax,label):ax.text(-.08,1.06,label,transform=ax.transAxes,fontweight='bold',fontsize=13,color=DARK)
def save(fig,n,title,note):
    fig.suptitle(title,fontsize=15,fontweight='bold',color=DARK,y=1.02)
    fig.text(.01,-.015,note,fontsize=8.5,color='#526170',va='top')
    fig.savefig(FIG/(n+'.png'),dpi=300,bbox_inches='tight',pad_inches=.18)
    fig.savefig(FIG/(n+'.pdf'),bbox_inches='tight',pad_inches=.18)
    plt.close(fig);captions.append(dict(file=n+'.png',title=title,caption=note))

def evidence_flow():
    fig,ax=plt.subplots(figsize=(12,5.5));ax.axis('off');ax.set_xlim(0,12);ax.set_ylim(0,5.5)
    boxes=[(.2,3.25,3.3,1.45,'资料与来源核对','2019—2022 气象、LAI、初始水\n16 份第一阶段 + 3 份第二阶段检查点',TEAL),
           (4.1,3.25,3.4,1.45,'分阶段校准诊断','第一阶段：四年均未达原定收敛阈值\n第二阶段：2019—2021 条件参数链',C[2019]),
           (8.1,3.25,3.6,1.45,'敏感性与优化复核','Sobol：独立区间试验\nNSGA-III：代理模型、固定灌溉日期',C[2021]),
           (.2,.45,5.45,1.8,'当前有证据支持','原始链可追溯、配对指标可复算\n2019—2021 校准拟合较好，原模型水量守恒\n修正单位、基准与图形后可做方法探索',TEAL),
           (6.2,.45,5.5,1.8,'定稿前必须补强','补 2022 第二阶段原始链与 Modified DI 源码\n延长独立采样、补独立验证、核查真实灌溉记录\n真实模型复算候选方案，报告可靠性与算法稳定性',RED)]
    for x,y,w,h,t,body,col in boxes:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.1,rounding_size=.12',
                                   facecolor=col+'12',edgecolor=col,linewidth=1.2))
        ax.text(x+.18,y+h-.3,t,fontsize=13,fontweight='bold',color=col,va='top')
        ax.text(x+.18,y+h-.8,body,fontsize=10,color=DARK,va='top',linespacing=1.65)
    for x in [3.55,7.65]:ax.annotate('',xy=(x+.4,3.95),xytext=(x,3.95),arrowprops=dict(arrowstyle='->',color=DARK,lw=1.6))
    save(fig,'F01_evidence_chain','研究路线与证据边界','本图为研究流程图；无虚构数值。新代理试算仅评估方法稳定性，不能替代原版改进 AquaCrop。')

def calibration():
    fig,axes=plt.subplots(2,3,figsize=(13,7.3),layout='constrained');metrics=table('calibration_metrics_recomputed')
    for col,y in enumerate([2019,2020,2021]):
        rr=next((DATA/f'②原始资料包_{y}').rglob('summary.json')).parent
        d=pd.read_csv(rr/'Daily_growth.csv');day=pd.to_datetime(d.Date);start=day.min()
        for row,var,pair,oc,sc,dc in [(0,'CC','CC_pairs.csv','CC_observed','CC_simulated','canopy_cover'),
               (1,'Biomass','Biomass_pairs.csv','B_observed_t_ha','B_simulated_t_ha','Biomass_t_ha')]:
            ax=axes[row,col];p=pd.read_csv(rr/pair);p.Date=pd.to_datetime(p.Date)
            if 'Included' in p:p=p[p.Included.astype(str).str.lower().eq('true')]
            ax.plot((day-start).dt.days,d[dc],color=C[y],lw=2.2,label='模型输出（条件均值参数点）')
            ax.scatter((p.Date-start).dt.days,p[oc],s=30,facecolor='white',edgecolor=C[y],lw=1.3,zorder=4,label='用于校准的数字化观测')
            m=metrics[(metrics.Year==y)&(metrics.Variable==var)].iloc[0]
            ax.text(.04,.94,f'n = {int(m.N)}\nR² = {m.R2:.3f}\nRMSE = {m.RMSE:.3f}',
                transform=ax.transAxes,va='top',fontsize=9,bbox=dict(fc='white',ec='none',alpha=.9))
            ax.set(xlabel='距模拟起始日 / d',title=str(y) if row==0 else '',
                   ylabel='冠层覆盖度 CC' if row==0 else '地上生物量 / (t·ha⁻¹)')
            ax.grid(axis='y');panel(ax,chr(97+row*3+col));ax.set_ylim(bottom=0)
    axes[1,2].legend(loc='lower right',fontsize=7)
    save(fig,'F02_calibration_trajectories','冠层与生物量：校准拟合可复现',
         '2019—2021 年配对观测与逐日输出直接核对；实线为已有模型输出，未重跑原模型。无独立验证、无后验预测带；2022 缺对应第二阶段输出。')

def diagnostic():
    d=table('mcmc_diagnostics_recomputed');d=d[d.Phase==1]
    fig,axes=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
    for ax,field,title,cmap,vmin,vmax in [(axes[0],'Rhat_max','匹配 walker 组中最大的秩标准化 R̂','YlOrRd',1,1.2),
            (axes[1],'ESS_bulk_min','匹配 walker 组中最小的 bulk ESS','YlGnBu',0,400)]:
        z=d.pivot(index='Parameter',columns='Year',values=field).reindex(NAMES[:5]);im=ax.imshow(z,cmap=cmap,vmin=vmin,vmax=vmax,aspect='auto')
        for i in range(5):
            for j in range(4):ax.text(j,i,f'{z.iloc[i,j]:.3f}' if field=='Rhat_max' else f'{z.iloc[i,j]:.1f}',ha='center',va='center',fontsize=10,color=DARK)
        ax.set(xticks=range(4),xticklabels=YEARS,yticks=range(5),yticklabels=NAMES[:5],title=title)
        fig.colorbar(im,ax=ax,shrink=.8);panel(ax,'a' if field=='Rhat_max' else 'b')
    save(fig,'F03_mcmc_diagnostics','第一阶段：拟合好不代表采样已收敛',
         '从 4×2000×32×5 原始检查点复算；每个 walker 组跨 4 个独立 ensemble 计算，未将 128 个耦合 walker 视为独立链。原阈值 R̂<1.01、ESS≥400，四年均未达标。')

def intervals():
    d=table('parameter_intervals_verified');fig,axes=plt.subplots(2,4,figsize=(14,7),layout='constrained')
    for i,k in enumerate(NAMES):
        ax=axes.flat[i];sub=d[d.Parameter==k]
        for r in sub.itertuples():
            x=YEARS.index(r.Year);ax.errorbar(x,r.Median,yerr=[[r.Median-r.P025],[r.P975-r.Median]],
                color=C[r.Year],fmt='o',lw=2,capsize=4,ms=6)
        if i>=5:
            ax.text(3,.5,'缺原始链',rotation=90,color=GRAY,ha='center',va='center',transform=ax.get_xaxis_transform(),fontsize=9)
            ax.axvspan(2.7,3.3,color='#F1F3F5')
        lo=sub.Prior_low.iloc[0];hi=sub.Prior_high.iloc[0]
        ax.axhline(lo,color=GRAY,lw=.7,ls=':');ax.axhline(hi,color=GRAY,lw=.7,ls=':')
        ax.set(xticks=range(4),xticklabels=YEARS,xlim=(-.5,3.5),title=k);ax.grid(axis='y');panel(ax,chr(97+i))
    save(fig,'F04_parameter_intervals','分年度参数分布与边界：保留证据，排除人造后验',
         '点为中位数，线为 2.5%—97.5% 保留样本分位区间，虚线为参数边界。第一阶段未收敛，第二阶段为单 ensemble 条件分布；2022 人造第二阶段样本未绘入。')

def phase2_correlation():
    z=np.load(OUT/'verified_phase_specific_draws.npz',allow_pickle=False)
    fig,axes=plt.subplots(1,3,figsize=(12,4.1),layout='constrained')
    for ax,y in zip(axes,[2019,2020,2021]):
        p=z[f'p2_{y}'];ax.hexbin(p[:,2],p[:,1],gridsize=40,mincnt=1,cmap='Blues',rasterized=True)
        ax.set(xlabel='HI0',ylabel='WP_late / (g·m⁻²)',title=str(y))
        ax.text(.04,.94,f'r = {np.corrcoef(p[:,2],p[:,1])[0,1]:.3f}',transform=ax.transAxes,va='top',
            bbox=dict(fc='white',ec='none',alpha=.85));panel(ax,chr(97+y-2019))
    save(fig,'F05_phase2_compensation','后期水分生产力与收获指数的参数补偿',
         '从同一第二阶段检查点的逐行联合样本计算相关性。该阶段内部相关结构在原 NSGA-III 抽样中保留；主要问题是跨阶段独立组合及仅 8 个评估样本。')

def water_figure():
    w=table('water_balance_recomputed');w=w[w.Scenario=='DI']
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained');ax=axes[0]
    for i,r in enumerate(w.itertuples()):
        for shift,parts in [(-.18,[(r.Irrigation_mm,'#176B87','灌溉'),(r.Rain_mm,'#8DBFC8','降水'),
                (max(-r.Storage_gain_mm,0),'#DDC79B','土壤储水消耗')]),
            (.18,[(r.ET_mm,'#805CA2','蒸散 ET'),(r.Runoff_mm,'#B7BFC8','径流'),
                (max(r.Storage_gain_mm,0),'#5F9D77','土壤储水增加')])]:
            bottom=0
            for h,col,label in parts:
                ax.bar(i+shift,h,.31,bottom=bottom,color=col,label=label if i==0 else None);bottom+=h
        ax.text(i,850,f'ΔS={r.Storage_gain_mm:+.1f}',ha='center',fontsize=8.5)
    ax.set(xticks=range(3),xticklabels=[2019,2020,2021],ylabel='季节水量 / mm',ylim=(0,920),title='原改进模型：输入、输出与储水');ax.grid(axis='y')
    ax.legend(ncol=2,fontsize=7.5,loc='upper left');panel(ax,'a')
    ax=axes[1];s=table('surrogate_audit');s=s[s.Year<2022]
    ax.bar(np.arange(3),s.Overflow_mm,color=[C[y] for y in s.Year],width=.55)
    for i,r in enumerate(s.itertuples()):ax.text(i,r.Overflow_mm+4,f'{r.Overflow_mm:.1f}',ha='center')
    ax.set(xticks=range(3),xticklabels=s.Year,ylabel='未报告的溢出 / mm',title='代理：根区亏缺裁剪掩盖了溢出通量',ylim=(0,240));ax.grid(axis='y');panel(ax,'b')
    save(fig,'F06_water_ledger','水量守恒与代理缺失过程需要分别核查',
         '左图据原第二阶段季节汇总重算，残差约 10⁻¹² mm；2021 储水增加约 170 mm。右图按代理原公式逐日复算：clip(Dr,0,TAW) 的溢出没有作为深渗/径流输出，不能据此宣称过程已验证。')

def sobol_figures():
    d=table('sobol_seeded_convergence');orig=pd.read_csv(PROJECT/'output/sobol_indices.csv')
    fig,axes=plt.subplots(1,3,figsize=(14,4.8),layout='constrained')
    for ax,y in zip(axes,[2019,2020,2021]):
        q=d[(d.Year==y)&(d.N==2048)&(d.Output=='Y_13pct')&(d.Track=='Narrowed_uniform')]
        av=q.groupby('Parameter').ST.mean().reindex(NAMES);cf=q.groupby('Parameter').ST_conf.mean().reindex(NAMES)
        oo=orig[(orig.Year==y)&(orig.Output=='Y_13pct')&(orig.Track=='Bayes_posterior')].set_index('Parameter').reindex(NAMES)
        pos=np.arange(8);ax.barh(pos,av,color=C[y],alpha=.85)
        ax.errorbar(av,pos,xerr=cf,fmt='none',ecolor=DARK,lw=.8,capsize=2,label='平均 bootstrap 95% 半宽')
        ax.scatter(oo.ST,pos,facecolors='white',edgecolors=DARK,s=24,zorder=5,label='原 N=512 结果')
        ax.set(yticks=pos,yticklabels=NAMES,xlabel='总效应指数 ST',title=str(y),xlim=(-.02,.73));ax.invert_yaxis();ax.grid(axis='x')
        panel(ax,chr(97+y-2019))
    axes[2].legend(fontsize=7.5,loc='lower right')
    save(fig,'F07_sobol_audited','Sobol 重算：应称为“收窄区间独立均匀输入”',
         '新运行 N=2048、3 个固定 scramble 种子，每次 256 组 bootstrap；横线为平均单次 bootstrap 半宽，并非跨种子合并置信区间。2019 首位为 WP_late，2020—2021 为 Kcb。未保留真实后验相关结构。')
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    ax=axes[0]
    for track,col,dx in [('Prior_uniform',GRAY,-.17),('Narrowed_uniform',TEAL,.17)]:
        z=d[(d.N==2048)&(d.Output=='Y_13pct')&(d.Track==track)].groupby('Year').Output_variance.mean().reindex([2019,2020,2021])
        ax.bar(np.arange(3)+dx,z,.3,color=col,label='先验边界均匀输入' if track=='Prior_uniform' else '收窄区间均匀输入')
    ax.set(xticks=range(3),xticklabels=[2019,2020,2021],ylabel='产量输出方差 / (t·ha⁻¹)²',title='输出总方差随输入分布改变');ax.legend(fontsize=8);ax.grid(axis='y');panel(ax,'a')
    ax=axes[1]
    for n,col in [(512,GRAY),(2048,TEAL)]:
        z=d[(d.N==n)&(d.Output=='Y_13pct')&(d.Track=='Narrowed_uniform')]
        z=z.groupby(['Year','Parameter']).ST.agg(['mean','std']).reset_index()
        for i,y in enumerate([2019,2020,2021]):
            zz=z[(z.Year==y)&(z.Parameter.isin(['Kcb','WP_late']))]
            for k,off in [('Kcb',-.16),('WP_late',.16)]:
                r=zz[zz.Parameter==k].iloc[0]
                ax.errorbar(i+off+(-.035 if n==512 else .035),r['mean'],yerr=r['std'],fmt='o' if k=='Kcb' else 's',
                    color=col,capsize=3,label=f'N={n}, {k}' if i==0 else None)
    ax.set(xticks=range(3),xticklabels=[2019,2020,2021],ylabel='ST：3 个 scramble 的均值 ± SD',title='样本量与随机种子稳定性');ax.legend(fontsize=7.5,ncol=2);ax.grid(axis='y');panel(ax,'b')
    save(fig,'F08_sobol_variance_convergence','归一化敏感性变化不等于“参数已识别”',
         '同一代理、同一年度系数，分别改变输入分布。CAI=(ST_prior−ST_narrow)/ST_prior 比较相对贡献，不能直接解释为信息吸收率；应同时报告输出方差、样本量及随机化稳定性。')

def original_pareto():
    p=pd.read_csv(PROJECT/'output/pareto_front.csv');b=table('original_baseline_risk_recomputed');k=table('original_knees_audited')
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained');norm=Normalize(p.Y13_std.min(),p.Y13_std.max())
    for ax,y in zip(axes.flat,YEARS):
        d=p[p.Year==y];q=k[k.Year==y].iloc[0];bb=b[b.Year==y].iloc[0]
        sc=ax.scatter(d.Irr_total_mm,d.Y13_mean,c=d.Y13_std,cmap='viridis',norm=norm,s=45,edgecolor='white',lw=.5)
        ax.scatter(q.Irr_opt_mm,q.Y13_opt,marker='*',s=170,color=RED,edgecolor='white',lw=.5,zorder=5,label='原表选择方案')
        ax.scatter(A.YEAR_DATA[y]['irr_obs'],bb.Same_8_draw_base_yield,marker='D',s=55,color=DARK,label='同 8 样本评估基准')
        ax.axhline(.95*q.Published_yield,color=RED,ls='--',lw=1,label='95% 文献观测产量')
        ax.set(xlabel='灌溉量 / mm',ylabel='代理期望产量 / (t·ha⁻¹)',title=str(y)+('：人造第二阶段输入' if y==2022 else ''));ax.grid();panel(ax,chr(97+y-2019))
        if y==2019:ax.legend(fontsize=7,loc='lower right')
        if y==2022:ax.set_facecolor('#F1F3F5')
    fig.colorbar(sc,ax=axes.ravel().tolist(),label='同 8 参数样本下的产量 SD / (t·ha⁻¹)',shrink=.85)
    save(fig,'F09_original_pareto_audited','原 Pareto 数据重绘：显示原始点，不人为修成单调曲线',
         '原目标值已逐点复现；基准风险按相同 8 组参数重算，未设为零。2020、2021 原选方案未达到 95% 文献观测产量。2022 为人造参数输入，只作缺陷展示，不能作为定稿结果。')

def schedule_fig():
    d=pd.read_csv(PROJECT/'output/optimal_irrigation_schedule.csv');fig,axes=plt.subplots(2,2,figsize=(13,7.3),layout='constrained')
    for ax,y in zip(axes.flat,YEARS):
        z=d[d.Year==y];x=np.arange(8)
        ax.bar(x-.18,z.Base_mm,.34,color='#CBD7E0',label='提供的基准安排（来源需核）')
        ax.bar(x+.18,z.Optimal_mm,.34,color=C[y],label='原代理选择方案')
        ax.set(xticks=x,xticklabels=pd.to_datetime(z.Date).dt.strftime('%m-%d'),ylabel='单次灌溉量 / mm',title=str(y),ylim=(0,125))
        ax.grid(axis='y');panel(ax,chr(97+y-2019))
        if y>=2021:ax.text(.02,.94,'基准日期与分次水量由原代理工程构造',transform=ax.transAxes,va='top',fontsize=8,color=RED)
    axes[0,0].legend(fontsize=8)
    save(fig,'F10_original_schedules','灌溉安排的展示必须交代基准来源',
         '按所给原表重绘，未新增田间灌溉观测。代码只优化 8 个固定日期的灌水量，允许近零水量；不是灌溉日期与水量联合优化。本图不构成田间执行建议。')

def optimization_figs():
    h=table('proxy_optimization_HV_history');s=table('proxy_optimization_selected_holdout')
    fig,axes=plt.subplots(1,3,figsize=(13,4.3),layout='constrained')
    for ax,y in zip(axes,[2019,2020,2021]):
        z=h[h.Year==y]
        for j,(seed,ss) in enumerate(z.groupby('Seed')):
            ax.plot(ss.Generation,ss.Hypervolume,color=[C[y],GRAY,DARK][j],lw=1.5,label=f'seed={seed}')
        ax.set(xlabel='遗传代数',ylabel='Hypervolume',title=str(y));ax.grid();ax.legend(fontsize=8);panel(ax,chr(97+y-2019))
    save(fig,'F11_optimization_convergence','条件代理试算：独立优化运行的收敛轨迹',
         '每年固定 64 个同一第二阶段联合样本，第一阶段固定为真实链均值；45 个参考方向、100 代、3 个算法种子。增加 E[Y]≥0.95×文献观测的搜索约束。参考点固定为(0,1000,5)，HV 仅用于同年同设定比较。')
    fig,axes=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
    ax=axes[0]
    for i,y in enumerate([2019,2020,2021]):
        z=s[s.Year==y]
        for j,r in enumerate(z.itertuples()):
            xx=i+(j-1)*.14;threshold=.95*{2019:16.55,2020:17.29,2021:15.86}[y]
            ax.errorbar(xx,100*(r.Validation_mean/threshold-1),yerr=[[100*(r.Validation_mean-r.Validation_Q05)/threshold],[0]],
                fmt='o',color=C[y],capsize=3,alpha=.85)
    ax.axhline(0,color=RED,ls='--',lw=1);ax.set(xticks=range(3),xticklabels=[2019,2020,2021],
        ylabel='相对 95% 观测产量门槛的差值 / %',title='独立 4096 样本：均值与第 5 百分位');ax.grid(axis='y');panel(ax,'a')
    ax=axes[1]
    for i,y in enumerate([2019,2020,2021]):
        z=s[s.Year==y]
        ax.scatter(np.full(3,i)+np.array([-.12,0,.12]),100*z.Validation_prob_95pct_observed,s=55,color=C[y])
    ax.axhline(90,color=RED,ls='--',lw=1,label='90% 概率目标（对照）')
    ax.set(xticks=range(3),xticklabels=[2019,2020,2021],ylabel='P(Y ≥ 95% 文献观测产量) / %',
        title='满足均值门槛不能保证高可靠性',ylim=(0,100));ax.grid(axis='y');ax.legend(fontsize=8);panel(ax,'b')
    save(fig,'F12_optimization_risk','把“平均减产小”与“保产可靠性高”分开报告',
         '每点代表一个独立算法种子的选择方案；4096 个评估样本来自相同经验条件分布，与搜索样本分开，不是外部田间验证。2021 三次运行的评估均值均未过门槛；原代理结构与校准误差尚未修复。')

def transfer_figure():
    m=pd.read_csv(PROJECT/'output/D3_transfer_matrix.csv',index_col=0).to_numpy()[:3,:3]
    delta=100*(m/np.diag(m)[None,:]-1)
    fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
    for ax,z,cmap,title,fmt in [(axes[0],m,'YlGnBu','原代理迁移产量 / (t·ha⁻¹)','.2f'),
                              (axes[1],delta,'RdBu','相对同应用年定制方案 / %','+.1f')]:
        im=ax.imshow(z,cmap=cmap,aspect='auto',vmin=-10 if fmt=='+.1f' else None,vmax=10 if fmt=='+.1f' else None)
        for i in range(3):
            for j in range(3):
                rgba=im.cmap(im.norm(z[i,j]));lum=.2126*rgba[0]+.7152*rgba[1]+.0722*rgba[2]
                ax.text(j,i,format(z[i,j],fmt),ha='center',va='center',fontweight='bold' if i==j else 'normal',color='white' if lum<.5 else DARK)
        ax.set(xticks=range(3),xticklabels=[2019,2020,2021],yticks=range(3),yticklabels=[2019,2020,2021],
            xlabel='应用年份',ylabel='方案来源年份',title=title);fig.colorbar(im,ax=ax,shrink=.85)
        panel(ax,'a' if fmt=='.2f' else 'b')
    save(fig,'F13_transfer_audited','跨年套用结果是样本内情景比较',
         '仅重绘 2019—2021 具有真实第二阶段链的子矩阵；应用年同时替换了气候和该年校准参数。由同一批年份挑选通用方案再在这些年份评分，不构成外推验证；水量约束也应一并比较。')

def climate_figure():
    fig,axes=plt.subplots(2,2,figsize=(12,7),layout='constrained')
    for ax,y in zip(axes.flat,YEARS):
        r=DATA/f'②原始资料包_{y}';p=read(next(r.rglob('preflight.json')))
        d=pd.read_csv(next(r.rglob(f'DI_Climate_{y}_FINAL.csv')));d.date=pd.to_datetime(d.date);d=d[d.date.between(*pd.to_datetime(p['Dates']))]
        t=np.arange(len(d));ax.bar(t,d.Precip_mm,color='#97C0CC',width=1,label='原气象资料日降水')
        ax2=ax.twinx();ax2.plot(t,d.ETo_mm,color=C[y],lw=1.2,label='原文件日 ETo')
        ax2.set(ylabel='原 ETo / (mm·d⁻¹)',ylim=(0,10));ax.set(xlabel='距模拟起始日 / d',ylabel='降水 / (mm·d⁻¹)',title=str(y),ylim=(0,30));ax.grid(axis='y');panel(ax,chr(97+y-2019))
    save(fig,'F14_climate_inputs','四年逐日驱动资料与模拟季节窗口',
         '绘制提供文件中的原始 ETo 列；2019—2021 它对应审计表中的 Old_ETo，不是原模型使用的逐日纠偏序列。代理按季节总量比例缩放；2022 比例取三年平均，仍是近似。资料本身不据此认定为气象站实测。')

if __name__=='__main__':
    for fn in [evidence_flow,calibration,diagnostic,intervals,phase2_correlation,water_figure,sobol_figures,
               original_pareto,schedule_fig,optimization_figs,transfer_figure,climate_figure]:
        fn();print('Rendered',fn.__name__,flush=True)
    (OUT/'figure_captions.json').write_text(json.dumps(captions,ensure_ascii=False,indent=2))
    thumbs=[]
    for r in captions:
        im=Image.open(FIG/r['file']).convert('RGB');im.thumbnail((650,420))
        tile=Image.new('RGB',(680,460),'#F1F4F7');tile.paste(im,((680-im.width)//2,20))
        ImageDraw.Draw(tile).text((15,440),r['file'],fill='#25384A');thumbs.append(tile)
    sheet=Image.new('RGB',(680*3,460*((len(thumbs)+2)//3)),'white')
    for i,im in enumerate(thumbs):sheet.paste(im,((i%3)*680,(i//3)*460))
    sheet.save(OUT/'figure_contact_sheet.jpg',quality=92)
    print('Figures completed:',len(captions),flush=True)
