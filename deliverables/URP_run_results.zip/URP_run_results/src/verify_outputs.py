"""Checks of scientific provenance and final artifact consistency."""
from pathlib import Path
import json,zipfile,hashlib
import pandas as pd
import numpy as np
from PIL import Image
from pypdf import PdfReader
from docx import Document
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'artifacts';T=OUT/'tables'
checks=[]
def check(name,ok,detail=''):
    checks.append(dict(Check=name,Passed=bool(ok),Detail=str(detail)))
    if not ok:raise AssertionError((name,detail))
def read(n):return pd.read_csv(T/(n+'.csv'))

integrity=read('checkpoint_integrity');check('19 genuine checkpoints',len(integrity)==19)
check('checkpoint state consistency',integrity.Finite.all() and integrity.Endpoint_match.all())
p=read('merged_sample_provenance');check('all source comparison identities',p.Match.all())
check('2022 artificial fallback explicitly identified',len(p[(p.Year==2022)&(p.Phase==2)&p.Compare.str.contains('artificial')])==3)
d=read('mcmc_diagnostics_recomputed');check('Rhat recomputed from independent ensembles',np.nanmax(abs(d.Rhat_max-d.Source_Rhat))<1e-12)
check('no false convergence certification',not d[d.Phase==1].Diagnostic_pass.astype(str).str.lower().eq('true').any())
f=read('calibration_metrics_recomputed');check('36 CC and 27 biomass pairs',f[f.Variable=='CC'].N.sum()==36 and f[f.Variable=='Biomass'].N.sum()==27)
check('pairing and fit recomputation',f.Pair_daily_max_difference.max()<1e-10 and f.RMSE_difference_vs_summary.abs().max()<1e-12)
w=read('water_balance_recomputed');check('original seasonal water ledgers close',w.Recomputed_balance_mm.abs().max()<1e-8)
a=read('original_objectives_recomputed');check('64 original Pareto objectives reproduced',a.N.sum()==64 and a.Max_Y_objective_difference.max()<1e-10 and a.Max_SD_objective_difference.max()<1e-10)
k=read('original_knees_audited');check('95% gate failure exposed',not k[k.Year.isin([2020,2021])].Pass_published_95pct.any())
u=read('surrogate_audit');check('water-productivity correction is factor ten',np.allclose(u.Reported_IWP/u.Correct_IWP,10))
s=read('sobol_seeded_convergence');check('36 seeded Sobol experiments / 576 rows',len(s)==576 and len(s[['Year','Track','N','Seed']].drop_duplicates())==36)
check('no synthetic year in new Sobol',not (s.Year==2022).any())
h=read('proxy_optimization_HV_history');check('9 independently seeded optimization runs',len(h[['Year','Seed']].drop_duplicates())==9 and h.Generation.max()==100)
v=read('proxy_optimization_selected_holdout');check('holdout mean failures remain visible',(v.Year.eq(2021)&~v.Validation_mean_pass).sum()==3)
caps=json.loads((OUT/'figure_captions.json').read_text());check('14 PNG and 14 PDF figures',len(caps)==14 and len(list((OUT/'figures').glob('*.pdf')))==14)
for r in caps:
    p=OUT/'figures'/r['file']
    with Image.open(p) as im:
        im.verify()
    check('figure '+r['file'],p.stat().st_size>10000)
pdf=PdfReader(OUT/'URP_论文框架_含数据与图.pdf');doc=Document(OUT/'URP_论文框架_含数据与图.docx')
check('paper PDF embeds 14 illustrations',sum(len(p.images) for p in pdf.pages)==14)
check('paper Word embeds 14 illustrations',len(doc.inline_shapes)==14)
check('editable manuscript has real tables',len(doc.tables)>=6)
text='\n'.join(p.extract_text() or '' for p in pdf.pages)
check('manuscript states missing-data and proxy limitations','2022' in text and '代理' in text and '1500' in text)
count=0
for p in Path('/workspace/attachments').rglob('*.zip'):
    with zipfile.ZipFile(p) as z:check('uploaded ZIP CRC: '+p.name,z.testzip() is None)
    count+=1
summary={'status':'PASS','check_count':len(checks),'uploaded_archives_crc_checked':count,
         'paper_pdf_pages':len(pdf.pages),'checks':checks}
(OUT/'delivery_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='checks'},ensure_ascii=False))
