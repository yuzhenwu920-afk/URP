"""Independent audit of uploaded DI-maize results. Original files are read-only inputs."""
from pathlib import Path
import os, json, hashlib, sys, time
ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault('XDG_CACHE_HOME', str(ROOT/'.cache'))
os.environ.setdefault('MPLCONFIGDIR', str(ROOT/'.cache/matplotlib'))
os.environ.setdefault('NUMBA_CACHE_DIR', str(ROOT/'.cache/numba'))
import numpy as np
import pandas as pd
from emcee.autocorr import integrated_time
import arviz as az

DATA = ROOT/'data'
PROJECT = DATA/'nextgen/DI_PHASE3_NEXTGEN'
OUT = ROOT/'artifacts'
TABLES = OUT/'tables'
TABLES.mkdir(exist_ok=True, parents=True)
NAMES = ['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
YEARS = [2019,2020,2021,2022]
sys.path.insert(0,str(PROJECT))
import aquacrop_surrogate as A

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def csv(name,rows):
    df = rows if isinstance(rows,pd.DataFrame) else pd.DataFrame(rows)
    df.to_csv(TABLES/(name+'.csv'),index=False,encoding='utf-8-sig')
    return df
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def metric(o,s):
    o,s=np.asarray(o,float),np.asarray(s,float)
    return dict(N=len(o),R2=1-np.sum((s-o)**2)/np.sum((o-o.mean())**2),
                RMSE=np.sqrt(np.mean((s-o)**2)),MAE=np.mean(np.abs(s-o)),Bias=np.mean(s-o))

def vector_sim(params,year,irrigation=None,calibrated=True,ledger=False):
    """Vectorized, numerically checked reproduction of the supplied surrogate, not AquaCrop.

    Reports mm and t/ha. Water productivity uses 100*Y(t/ha)/water(mm).
    Unaccounted overflow and deficit are exposed without altering original dynamics.
    """
    p=np.atleast_2d(np.asarray(params,float)); n=len(p)
    if not A.CALIB: A.calibrate_all()
    c=A.CALIB[year]; d=A.YEAR_DATA[year]
    et=A._daily_et0(year); rain=A._daily_rain(year)
    if irrigation is None: irr=np.broadcast_to(A._daily_irrigation(year),(n,len(et)))
    else:
        irr=np.asarray(irrigation,float)
        if irr.ndim==1: irr=np.broadcast_to(irr,(n,len(et)))
        if irr.shape != (n,len(et)): raise ValueError('Irrigation must be N x days')
    ccx,cgc,cdc,sen,kcb,wpe,wpl,hi=p.T
    dr=np.zeros(n); biomass=np.zeros(n); trtot=np.zeros(n); estot=np.zeros(n)
    spill=np.zeros(n); creation=np.zeros(n); maxres=np.zeros(n)
    for t in range(len(et)):
        ce=A.CC0*np.exp(cgc*c['k_cgc']*t)
        cc=np.where(ce<=.5*ccx,ce,ccx-.25*ccx**2/A.CC0*np.exp(-cgc*c['k_cgc']*t))
        decline=ccx*(1-.05*(np.exp(cdc/ccx*(t-sen))-1))
        cc=np.where(t<sen,cc,np.clip(decline,0,ccx))
        ks=np.where(dr<=99.,1.,np.maximum(0,(180.-dr)/81.))
        eff=cc*(1-c['a_cc']*cc/ccx)
        tr=ks*eff*kcb*et[t]
        kr=np.where(dr<90.,1.,np.maximum(.2,1-(dr-90.)/90.))
        es=(1-cc)*et[t]*c['f_mulch']*kr
        trtot+=tr; estot+=es
        if et[t]>1e-6: biomass+=np.where(t<d['histart_cd'],wpe,wpl)*tr/et[t]
        raw=dr+tr+es-rain[t]-irr[:,t]
        spill+=np.maximum(-raw,0); creation+=np.maximum(raw-180.,0)
        maxres=np.maximum(maxres,np.maximum(-raw,np.maximum(raw-180.,0)))
        dr=np.clip(raw,0,180.)
    biomass*=.01*(c['k_B'] if calibrated else 1.)
    y=hi*biomass/.87; it=irr.sum(axis=1); ett=trtot+estot
    return dict(Y_13pct=y,B_t_ha=biomass,Tr_mm=trtot,Es_mm=estot,ET_mm=ett,Irr_mm=it,
                WP_Irr=np.divide(100*y,it,out=np.full(n,np.nan),where=it>1e-9),
                final_depletion=dr,unreported_overflow=spill,unfunded_demand=creation,
                max_daily_unreported=maxres,water_ledger_residual=it+rain.sum()-ett+dr)

def collect():
    """Recompute rather than trust the uploaded diagnostics or prose summaries."""
    diag_rows=[]; params=[]; integrity=[]; provenance=[]; fits=[]; water=[]; climate=[]
    phase1={}; phase2={}; full1={}; summaries={}; source_map=[]
    merged=pd.read_csv(DATA/'conclusions/output/merged_chain.csv',
                       dtype={'Year':'int16','Phase':'int8','Parameter':'category'})
    groups={k:g.Value.to_numpy() for k,g in merged.groupby(['Year','Phase','Parameter'],observed=True)}
    for y in YEARS:
        r=DATA/f'②原始资料包_{y}'
        dp=next(r.rglob('canopy_transpiration_diagnostics.json')); d=read(dp)
        paths=sorted(r.rglob('checkpoints/canopy_transpiration/ensemble_*.npz'))
        raw=[]; taus=[]; contracts=[]
        for p in paths:
            with np.load(p,allow_pickle=False) as z:
                h=z['history']; contract=json.loads(z['contract'].item()); contracts.append(contract)
                integrity.append(dict(Year=y,Phase=1,File=str(p.relative_to(DATA)),SHA256=digest(p),
                    Shape=str(h.shape),Finite=bool(np.isfinite(h).all() and np.isfinite(z['logs']).all()),
                    Endpoint_match=bool(np.array_equal(h[-1],z['position'])),
                    Acceptance=float(z['accepted'].mean())))
                assert h.shape==(2000,32,5) and integrity[-1]['Finite'] and integrity[-1]['Endpoint_match']
                raw.append(h.copy()); taus.append(integrated_time(h,tol=0,quiet=True))
        full1[y]=np.array(raw); b=d['Burn_in']; ret=full1[y][:,b:]
        phase1[y]=ret.reshape(-1,5)
        rh=np.zeros((32,5)); eb=rh.copy(); et=rh.copy()
        for w in range(32):
            for j in range(5):
                x=ret[:,:,w,j]
                rh[w,j]=az.rhat(x,method='rank'); eb[w,j]=az.ess(x,method='bulk'); et[w,j]=az.ess(x,method='tail')
        original=pd.DataFrame(d['Parameters']).set_index('Parameter')
        tau_max=np.array(taus).max(axis=0)
        for j,name in enumerate(NAMES[:5]):
            v=phase1[y][:,j]; lo,hi=contracts[0]['priors'][name]
            item=dict(Year=y,Phase=1,Parameter=name,Burn_in=b,Raw_steps=2000,
                Retained_steps=2000-b,Retained_correlated_draws=len(v),Tau_max=tau_max[j],
                Steps_over_tau=2000/tau_max[j],Rhat_max=rh[:,j].max(),ESS_bulk_min=eb[:,j].min(),
                ESS_tail_min=et[:,j].min(),Source_Rhat=float(original.loc[name,'Rhat_max_across_walker_groups']))
            item['Diagnostic_pass']=bool(item['Rhat_max']<1.01 and item['ESS_bulk_min']>=400
                                          and item['ESS_tail_min']>=400 and item['Steps_over_tau']>=50)
            diag_rows.append(item)
            params.append(dict(Year=y,Phase=1,Parameter=name,N=len(v),Mean=v.mean(),SD=v.std(ddof=1),
                Median=np.median(v),P025=np.quantile(v,.025),P975=np.quantile(v,.975),Prior_low=lo,Prior_high=hi,
                Lower_1pct_mass=np.mean(v<lo+.01*(hi-lo)),Upper_1pct_mass=np.mean(v>hi-.01*(hi-lo)),
                Evidence='checkpoint; phase1 not converged'))
            mv=groups[y,1,name]
            provenance.append(dict(Year=y,Phase=1,Parameter=name,Rows=len(mv),
                Compare='official burn-in checkpoint draws',Match=bool(len(mv)==len(v) and np.allclose(mv,v,atol=1e-12,rtol=0))))
        pf=read(next(r.rglob('preflight.json'))); dates=pd.to_datetime(pf['Dates'])
        wc=pd.read_csv(next(r.rglob(f'DI_Climate_{y}_FINAL.csv')));wc.date=pd.to_datetime(wc.date)
        sub=wc[wc.date.between(*dates)]
        wr=pd.read_csv(next(r.rglob('DI_2019_2022_AquaCrop_InitialWater_FIELD_LOCKED.csv')));wr=wr[wr.Year==y]
        row=dict(Year=y,Days=len(sub),Start=str(dates[0].date()),End=str(dates[1].date()),
            All_days_unique=bool(wc.date.is_unique),Missing_cells=int(wc.isna().sum().sum()),
            Bad_temperature_rows=int((wc.Tmin_C>wc.Tmax_C).sum()),Rain_mm=sub.Precip_mm.sum(),
            Raw_ETo_mm=sub.ETo_mm.sum(),Initial_water_mm=np.sum(wr.Thickness_m*wr.Initial_theta_m3m3*1000))
        audits=list(r.rglob('ETo_source_audit.csv'))
        if audits:
            aud=pd.read_csv(audits[0]).iloc[0]; row['Audited_B_ETo_mm']=aud.B_ETo_mm
            row['ETo_scale']=aud.B_ETo_mm/aud.Old_ETo_mm
        climate.append(row)
        sp=list(r.rglob('summary.json'))
        if not sp: continue
        summary=read(sp[0]); assert summary['Year']==y; summaries[y]=summary
        resultdir=sp[0].parent
        daily=pd.read_csv(resultdir/'Daily_growth.csv');daily.Date=pd.to_datetime(daily.Date)
        for variable,filename,oc,sc,dc in [('CC','CC_pairs.csv','CC_observed','CC_simulated','canopy_cover'),
                                        ('Biomass','Biomass_pairs.csv','B_observed_t_ha','B_simulated_t_ha','Biomass_t_ha')]:
            pairs=pd.read_csv(resultdir/filename);pairs.Date=pd.to_datetime(pairs.Date)
            if 'Included' in pairs: pairs=pairs[pairs.Included.astype(str).str.lower().eq('true')]
            met=metric(pairs[oc],pairs[sc]); met.update(Year=y,Variable=variable)
            met['RMSE_difference_vs_summary']=met['RMSE']-summary[variable]['RMSE']
            met['R2_difference_vs_summary']=met['R2']-summary[variable]['R_Square']
            joined=pairs.merge(daily[['Date',dc]],on='Date',validate='one_to_one')
            met['Pair_daily_max_difference']=np.max(np.abs(joined[sc]-joined[dc]))
            fits.append(met)
        for scenario in ['DI','Zero']:
            s=summary[scenario]
            residual=(s['Irrigation_mm']+s['Rain_mm']+s['Profile_initial_mm']-s['Profile_final_mm']
                      +s['Surface_initial_mm']-s['Surface_final_mm']+s['CR_mm']+s['GwIn_mm']
                      -s['Tr_mm']-s['Es_mm']-s['Runoff_mm']-s['DeepPerc_mm']-s['TileDrain_mm'])
            water.append(dict(Year=y,Scenario=scenario,**s,Recomputed_balance_mm=residual,
                Storage_gain_mm=s['Profile_final_mm']-s['Profile_initial_mm'],
                IWP_kg_m3=100*s['Y_13pct']/s['Irrigation_mm'] if s['Irrigation_mm'] else np.nan,
                ETWP_kg_m3=100*s['Y_13pct']/s['ET_mm']))
        pp=next(r.rglob('checkpoints/biomass_yield/ensemble_1.npz'))
        with np.load(pp,allow_pickle=False) as z:
            h=z['history'];c=json.loads(z['contract'].item());dg=read(resultdir/'sampling_diagnostics.json')
            assert h.shape==(2000,32,3) and np.isfinite(h).all()
            integrity.append(dict(Year=y,Phase=2,File=str(pp.relative_to(DATA)),SHA256=digest(pp),Shape=str(h.shape),
                Finite=bool(np.isfinite(z['logs']).all()),Endpoint_match=bool(np.array_equal(h[-1],z['position'])),
                Acceptance=float(z['accepted'].mean())))
            b2=dg['Burn_in'];phase2[y]=h[b2:].reshape(-1,3);tau=integrated_time(h,tol=0,quiet=True)
            for j,name in enumerate(NAMES[5:]):
                v=phase2[y][:,j];lo,hi=c['priors'][name]
                params.append(dict(Year=y,Phase=2,Parameter=name,N=len(v),Mean=v.mean(),SD=v.std(ddof=1),
                    Median=np.median(v),P025=np.quantile(v,.025),P975=np.quantile(v,.975),Prior_low=lo,Prior_high=hi,
                    Lower_1pct_mass=np.mean(v<lo+.01*(hi-lo)),Upper_1pct_mass=np.mean(v>hi-.01*(hi-lo)),
                    Evidence='checkpoint; conditional single ensemble'))
                diag_rows.append(dict(Year=y,Phase=2,Parameter=name,Burn_in=b2,Raw_steps=2000,
                    Retained_steps=2000-b2,Retained_correlated_draws=len(v),Tau_max=tau[j],
                    Steps_over_tau=2000/tau[j],Diagnostic_pass=None))
                mv=groups[y,2,name];target=h[400:,:,j].ravel()
                provenance.append(dict(Year=y,Phase=2,Parameter=name,Rows=len(mv),
                    Compare='20% burn-in checkpoint draws (different from diagnostics)',
                    Match=bool(len(mv)==len(target) and np.allclose(mv,target,atol=1e-12,rtol=0))))
        print('Recomputed checkpoints, diagnostics, paired metrics:',y,flush=True)
    # Confirm the 2022 numbers are exactly the artificial fallback in phase A.
    rng=np.random.default_rng(2022)
    synth=np.column_stack([rng.normal(13.86,1.5,1500),rng.normal(31.5,2.5,1500),rng.normal(.401,.025,1500)])
    for j,name in enumerate(NAMES[5:]):
        lo,hi=A.PRIOR_BOUNDS[name];synth[:,j]=np.clip(synth[:,j],lo+.01*(hi-lo),hi-.01*(hi-lo))
        provenance.append(dict(Year=2022,Phase=2,Parameter=name,Rows=len(groups[2022,2,name]),
            Compare='artificial Normal+clipping fallback, NOT an MCMC chain',
            Match=bool(np.allclose(groups[2022,2,name],synth[:,j],atol=1e-12,rtol=0))))
    csv('mcmc_diagnostics_recomputed',diag_rows);csv('parameter_intervals_verified',params)
    csv('checkpoint_integrity',integrity);csv('merged_sample_provenance',provenance)
    csv('calibration_metrics_recomputed',fits);csv('water_balance_recomputed',water);csv('climate_audit',climate)
    # Save true, phase-specific draws without manufacturing a joint posterior.
    np.savez_compressed(OUT/'verified_phase_specific_draws.npz',
        **{f'p1_{y}':v for y,v in phase1.items()},**{f'p2_{y}':v for y,v in phase2.items()})
    return phase1,phase2,full1,summaries

def proxy_audit():
    A.calibrate_all();rows=[];checks=[]
    for y in YEARS:
        ref=np.array([A.REFERENCE_MEAN[y][k] for k in NAMES]);o=A.simulate(dict(zip(NAMES,ref)),y)
        v=vector_sim(ref,y)
        for k in ['Y_13pct','B_t_ha','Tr_mm','Es_mm','ET_mm','Irr_mm']:
            checks.append(dict(Year=y,Variable=k,Absolute_difference=abs(v[k][0]-o[k])))
            assert np.isclose(v[k][0],o[k],rtol=1e-11,atol=1e-10)
        rng=np.random.default_rng(100+y)
        for i in range(10):
            p=np.array([rng.uniform(*A.PRIOR_BOUNDS[k]) for k in NAMES]);r=A.simulate(dict(zip(NAMES,p)),y)
            z=vector_sim(p,y)
            for k in ['Y_13pct','Tr_mm','Es_mm','ET_mm']:
                assert np.isclose(z[k][0],r[k],rtol=1e-10,atol=1e-9),(y,i,k)
        rows.append(dict(Year=y,**A.CALIB[y],Surrogate_yield=o['Y_13pct'],
            Proxy_yield_target=A.YEAR_DATA[y]['y13_obs'],Declared_Irr_mm=A.YEAR_DATA[y]['irr_obs'],
            Actual_schedule_Irr_mm=o['Irr_mm'],Reported_IWP=o['WP_Irr'],Correct_IWP=100*o['Y_13pct']/o['Irr_mm'],
            Overflow_mm=v['unreported_overflow'][0],Unfunded_demand_mm=v['unfunded_demand'][0],
            Daily_max_unreported_mm=v['max_daily_unreported'][0],
            Unreported_ledger_residual_mm=v['water_ledger_residual'][0]))
    csv('surrogate_audit',rows);csv('vectorized_model_equivalence',checks)
    print('Proxy numerical equivalence passed; units, targets and water ledger audited.',flush=True)
    return pd.DataFrame(rows)

if __name__=='__main__':
    t=time.time();collect();proxy_audit();print('Completed audit in',round(time.time()-t,1),'s')
