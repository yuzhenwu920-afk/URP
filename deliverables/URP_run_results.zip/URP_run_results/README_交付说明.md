# URP 数据复核、图表与论文框架

先阅读 artifacts/URP_合理性审查报告.pdf，再使用 artifacts/URP_论文框架_含数据与图.docx 写作。

本交付已完成原始检查点审计、配对指标复算、原代理结果复现与方法改进试算。它没有重新运行原版 Modified DI AquaCrop 或 MCMC，也没有形成经过独立验证的最终灌溉建议。

## 主要文件

- artifacts/URP_论文框架_含数据与图.docx：可编辑框架，插入真实来源数据表与14幅图。
- artifacts/URP_论文框架_含数据与图.pdf：便于预览的排版版本。
- artifacts/URP_合理性审查报告.pdf：问题证据、应如何修正、可保留与不能下的结论。
- artifacts/URP_审查与结果表.xlsx：全部统计、诊断、目标重算、算法轨迹与来源哈希。
- artifacts/URP_图表画册.html：单文件画册，可离线用浏览器查看。
- artifacts/figures/：14幅300dpi PNG，及同名矢量PDF。
- src/：本次新增分析、绘图、成稿和交付核验脚本；上传原代码未修改。

## 必须保留的解释边界

1. 四年第一阶段均未通过原定收敛判据；第二阶段为条件分布，非八参数联合后验。
2. 2022第二阶段1500行数据已逐值确认为正态构造，不是真实MCMC；新试验均排除此数据。
3. 原版改进模型没有完整源码，所有新优化与Sobol运行都使用已核验数值等价的原代理。
4. “独立4096样本评估”仅表示重新从经验条件分布抽样，不是独立试验或外部验证。
5. 新代理试算的节水幅度只用于检查方法敏感性，不能作为新的推荐数值。
6. 水生产率已经按kg/m³更正；原值高10倍。2020/2021的95%观测产量门槛被原方案违反。

## 在本云环境重跑

本云任务本身是隔离环境。使用已有 /workspace/URP 与 /workspace/urp_review；除非用户明确要求，不新建Git worktree。不要覆写上传文件或已存在的用户源码。

测试环境为Linux、Python3.12；依赖见requirements-verified.txt。本机已有pandoc和Noto CJK字体。绘图脚本中Linux字体路径在其他系统需要替换为可用中文字体；不需要改动统计方法。

```bash
cd /workspace/urp_review
python3 -m venv --system-site-packages .venv
UV_CACHE_DIR=/workspace/urp_review/.cache/uv uv pip install --python .venv/bin/python -r requirements-verified.txt
.venv/bin/python src/review_core.py
.venv/bin/python src/experiments.py
.venv/bin/python src/make_figures.py
.venv/bin/python src/make_documents.py
.venv/bin/python src/verify_outputs.py
```

原始输入的本次解压布局：

```text
data/
  nextgen/DI_PHASE3_NEXTGEN/          原代理工程、inputs和原CSV/JSON输出
  conclusions/output/               merged_chain.csv和raw_npz_cache/DI_YYYY.npz
  ②原始资料包_2019/                 分年包完整内容
  ②原始资料包_2020/
  ②原始资料包_2021/
  ②原始资料包_2022/
```

每个分年包的01_MCMC结果包/中的内嵌zip需安全解压到它旁边的extracted/目录。脚本递归发现真实检查点，不依据错误的原zip年份命名来推断年份。

本交付压缩包不重复装入约百MB的用户原始附件，也不装入可从检查点重建的17MB verified_phase_specific_draws.npz。先重跑review_core.py可重建该文件。当前云环境中原始输入和该中间文件均已保留。完整输入和缺失的原版模型是不同要求：已有资料足以复现本次代理审计，但不足以复算正式AquaCrop管理结论。

依赖安装保持TLS和校验，不使用关闭证书验证的参数。无需额外账号、密钥或后台服务。

## 下一步应补的材料

优先找回2022年的biomass_yield/ensemble_*.npz及对应诊断；如果总结文档所述原链还在，不必先重跑。

补Modified DI原始源码（可含DI_YYYY_MCMC_ONE_CLICK.py内嵌模型）、配置、真实灌溉记录、逐日纠偏ETo及原始研究文献。标准aquacrop包不能替代本项目的结构修改。补齐后才进行真实模型的过程核验、独立验证及候选方案复算。
