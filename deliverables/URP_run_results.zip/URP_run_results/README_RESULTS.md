# URP 实际运行结果完整包

本包汇集本次实际生成的运行产物，并补入此前交付包未包含的 verified_phase_specific_draws.npz（约17.7MB）。

## 内容
- artifacts/tables/：全部CSV结果表，包括MCMC诊断复算、原目标复核、576行Sobol结果、9次NSGA-III的完整HV轨迹、全部保存前沿及独立4096样本评估。
- artifacts/verified_phase_specific_draws.npz：从19份真实检查点重建的分年、分阶段保留样本；包含四年phase1和2019—2021 phase2，没有2022人工phase2。
- artifacts/conditional_yield_distributions.npz：三个完整年份的基准/原选择方案各4096个条件产量模拟值。
- artifacts/figures/：14张300dpi PNG及14份矢量PDF。
- artifacts/*.log：实际执行日志；另附软件版本、验证记录、图注、画册、Word/PDF报告和结果工作簿。
- src/：本次复算、试验、绘图、成稿与核验脚本。
- RUN_RESULTS_MANIFEST.json：本压缩包每个文件的大小和SHA-256清单。
- NPZ_ARRAY_SHAPES.json：NPZ变量及数组维度。

## 边界
本次没有重新运行MCMC；verified_phase_specific_draws是从用户提供的真实检查点重建，不是新采样。新增Sobol与NSGA-III均为代理模型探索，不能等同于原版Modified DI AquaCrop复算或最终田间灌溉建议。4096样本评估来自同一经验条件分布，不是独立田间验证。

2022原始第二阶段缺失；人工构造值没有进入新增试验或verified_phase_specific_draws。原始用户上传的约百MB压缩包不重复装入本包。完整复算的输入布局见README_交付说明.md。
