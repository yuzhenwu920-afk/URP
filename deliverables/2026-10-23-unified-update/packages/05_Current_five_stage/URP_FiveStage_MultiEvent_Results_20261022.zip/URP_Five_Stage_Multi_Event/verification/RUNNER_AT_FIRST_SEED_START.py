from pathlib import Path
import os,json,time,contextlib,multiprocessing,hashlib
from concurrent.futures import ProcessPoolExecutor,as_completed
for var in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[var]='1'
import numpy as np
import pandas as pd
from pymoo.core.problem import Problem
from pymoo.core.sampling import Sampling
from pymoo.core.repair import Repair
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.indicators.hv import HV
from multi_event_engine import ROOT,PROJECT,MultiEventEngine as Engine,OBS,CONTROL_NAMES,N_EVENTS,dump,sha

YEARS=[2019,2020,2021,2022];SEEDS=[31,73,109,151,199];POP=100;GEN=100;FULL_SEEDS=SEEDS[:3];FULL_POP=80;FULL_GEN=60
def nd(d):
 if d.empty:return d.copy()
 d=d.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False],kind='mergesort').drop_duplicates(['Irrigation_mm','Y_13pct']);best=-np.inf;keep=[]
 for i,r in d.iterrows():
  if r.Y_13pct>best:keep.append(i);best=r.Y_13pct
 return d.loc[keep].reset_index(drop=True)
class RepairBudget(Repair):
 def _do(self,p,X,**kw):
  return p.engine.repair(X)
class Init(Sampling):
 def _do(self,p,n_samples,random_state=None,**kw):
  rng=random_state if random_state is not None else np.random.default_rng(0);e=p.engine
  amounts=rng.dirichlet(np.ones(N_EVENTS),n_samples)*rng.uniform(0 if p.full else .15,1,n_samples)[:,None]*p.cap
  dates=np.column_stack([rng.integers(lo,hi+1,n_samples) for lo,hi in zip(e.slot_low,e.slot_high)]);X=np.c_[amounts,dates]
  anchors=[e.old_anchor.copy(),e.base.copy()]
  if p.full:
   anchors=[e.zero.copy(),e.base.copy(),e.old_anchor.copy()]
   anchors.extend(np.r_[e.base[:N_EVENTS]*v,e.base[N_EVENTS:]] for v in np.linspace(.05,.95,10))
   for stage in range(5):
    z=e.zero.copy();z[stage*3]=p.cap*.5;z[N_EVENTS+stage*3]=int(round((e.day_low[stage]+e.day_high[stage])/2));anchors.append(z)
   if len(p.parent):anchors.extend(p.parent[np.unique(np.linspace(0,len(p.parent)-1,min(20,len(p.parent)),dtype=int))])
  else:
   for phase in ['early','middle','late']:
    z=e.base.copy();delta=-5 if phase=='early' else 5 if phase=='late' else 0;z[N_EVENTS:]=np.clip(z[N_EVENTS:]+delta,e.slot_low,e.slot_high);anchors.append(z)
   for frac in [.5,.75]:z=e.base.copy();z[:N_EVENTS]*=frac;anchors.append(z)
  for i,x in enumerate(anchors[:n_samples]):X[i]=x
  return e.repair(X)
class IrrigationProblem(Problem):
 def __init__(self,e,folder,algorithm,seed,cache,full=False,parent=None):
  self.engine=e;self.folder=folder;self.algorithm=algorithm;self.seed=seed;self.cache=cache;self.full=full;self.cap=e.cap;self.observed=OBS[e.year];self.gate=.95*self.observed;self.count=0;self.calls=0;self.start=time.monotonic();self.parent=parent if parent is not None else np.empty((0,2*N_EVENTS))
  super().__init__(n_var=2*N_EVENTS,n_obj=2,n_ieq_constr=1 if full else 2,xl=np.r_[np.zeros(N_EVENTS),e.slot_low],xu=np.r_[np.full(N_EVENTS,e.cap),e.slot_high])
 def _evaluate(self,X,out,*args,**kw):
  rows=[];F=[];G=[]
  for z in X:
   x=self.engine.expand(z);key=x.astype('<f8').tobytes();hit=key in self.cache
   if hit:s=self.cache[key]
   else:s=self.engine.run(x);self.cache[key]=s;self.calls+=1
   self.count+=1;gi=(s['Irrigation_mm']-self.cap)/self.cap;gy=(self.gate-s['Y_13pct'])/self.observed
   if abs(gi)<=64*np.finfo(float).eps:gi=0.
   if abs(gy)<=64*np.finfo(float).eps:gy=0.
   F.append([-s['Y_13pct'],s['Irrigation_mm']]);G.append([gi] if self.full else [gi,gy])
   rows.append(dict(Year=self.engine.year,Algorithm=self.algorithm,Seed=self.seed,Scope='Full_range' if self.full else 'Formal_95pct',Evaluation=self.count,Exact_cache_hit=hit,**self.engine.records(x),**s,G_irrigation=gi,G_yield=gy))
  out['F']=np.asarray(F);out['G']=np.asarray(G);p=self.folder/'evaluations.csv.gz';pd.DataFrame(rows).to_csv(p,index=False,mode='a',header=not p.exists(),compression='gzip')
def run_seed(e,algo,seed,cache,full=False,parent=None):
 scope='full_range' if full else 'formal';folder=ROOT/f'runs/{e.year}/{scope}/{algo}_seed{seed}';folder.mkdir(parents=True,exist_ok=True)
 if (folder/'run.json').exists():raise FileExistsError('Refusing to overwrite a previous seeded search: '+str(folder))
 pop,gen=(FULL_POP,FULL_GEN) if full else (POP,GEN);p=IrrigationProblem(e,folder,algo,seed,cache,full,parent)
 identity=dict(Year=e.year,Algorithm=algo,Seed=seed,Scope=scope,Population=pop,Generations=gen,
  Active_dimension=p.n_var,Space=e.space,Fixed_parameters=e.params,Fixed_settings=e.settings,
  Objectives=['maximize model yield at 13% moisture','minimize actual seasonal irrigation'],Yield_gate=None if full else p.gate,Seasonal_cap_mm=e.cap,
  Terminal_storage_floor=False,Additional_event_hardware_cap=False,Original_dates_unchanged=False,Five_stage_dates_optimized=True,Optional_events_per_stage=3,All_five_stages_eligible=True,Date_repair='integer daily grid within the stage-calendar intersection',
  Initialization='Original DI and old four-window feasible anchors, timing perturbations and random 15-event amounts/dates' if not full else 'Zero, baseline, proportional amounts, stage corners, new five-stage formal front, random simplex',
  Exact_cache_only=True,Surrogate=False)
 dump(folder/'run.json',dict(Status='RUNNING',Identity=identity));history=[];indicator=HV(ref_point=np.array([0,1.01]))
 def callback(a):
  X,F,G,CV=a.pop.get('X'),a.pop.get('F'),a.pop.get('G'),a.pop.get('CV').ravel();np.savez_compressed(folder/f'generation_{a.n_gen:04d}.npz',X_encoded=X,X_event_depths=X[:,:N_EVENTS],X_event_day_indexes=X[:,N_EVENTS:],F=F,G=G,CV=CV)
  good=CV<=0;hv=float(indicator(F[good]/np.array([p.observed,p.cap]))) if good.any() else 0.
  row=dict(Year=e.year,Scope=scope,Algorithm=algo,Seed=seed,Generation=int(a.n_gen),Evaluations=p.count,Actual_model_calls=p.calls,Cache_hits=p.count-p.calls,Feasible=int(good.sum()),Hypervolume=hv,Seconds=time.monotonic()-p.start)
  history.append(row);pd.DataFrame(history).to_csv(folder/'history.csv',index=False)
  if a.n_gen==1 or a.n_gen%5==0:dump(ROOT/f'verification/progress_{e.year}.json',dict(Status='RUNNING',**row,Population=pop,Generations=gen,Completed_searches=int(len(list((ROOT/f'runs/{e.year}').rglob('COMPLETE.json'))))))
  if a.n_gen%20==0:print(e.year,scope,algo,seed,'gen',a.n_gen,'/',gen,'queries',p.count,'calls',p.calls,flush=True)
 cls=NSGA3 if algo=='NSGA3' else NSGA2;opts=dict(pop_size=pop,sampling=Init(),repair=RepairBudget(),eliminate_duplicates=True)
 if algo=='NSGA3':opts['ref_dirs']=get_reference_directions('das-dennis',2,n_partitions=pop-1)
 try:
  result=minimize(p,cls(**opts),('n_gen',gen),seed=seed,callback=callback,verbose=False)
  assert result.algorithm.evaluator.n_eval==pop*gen==p.count and len(history)==gen
  data=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip');feasible=(data.G_irrigation<=0) if full else ((data.G_irrigation<=0)&(data.G_yield<=0));front=nd(data[feasible]);front.to_csv(folder/'all_evaluated_front.csv',index=False)
  final=[]
  if result.X is not None:
   for z,f in zip(np.atleast_2d(result.X),np.atleast_2d(result.F)):final.append(dict(Year=e.year,Algorithm=algo,Seed=seed,Y_13pct=-float(f[0]),Irrigation_mm=float(f[1]),**dict(zip(CONTROL_NAMES,e.expand(z)))))
  final=pd.DataFrame(final);final.to_csv(folder/'final_population_front.csv',index=False)
  record=dict(Status='COMPLETE',Identity=identity,Objective_queries=p.count,Actual_model_calls=p.calls,Exact_cache_hits=p.count-p.calls,All_evaluated_front_points=len(front),Final_population_front_points=len(final),Seconds=time.monotonic()-p.start)
  dump(folder/'run.json',record);dump(folder/'COMPLETE.json',dict(Status='COMPLETE',Objective_queries=p.count,Actual_model_calls=p.calls));return final,record
 except Exception as ex:dump(folder/'run.json',dict(Status='FAILED',Identity=identity,Error=repr(ex)));raise
def run_year(year):
 with (ROOT/f'verification/year_{year}.log').open('w',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  start=time.monotonic();e=Engine(year);dump(ROOT/f'source/decision_space_{year}.json',e.space);dump(ROOT/f'source/fixed_identity_{year}.json',dict(Parameters=e.params,Settings=e.settings,Old_four_window_space=e.old_space))
  e.activate();cache={};records=[];parents=[]
  try:
   base=e.run(e.base);zero=e.run(e.zero);original=e.original_baseline();old=e.run(e.old_anchor);cache[e.base.astype('<f8').tobytes()]=base;cache[e.zero.astype('<f8').tobytes()]=zero;cache[e.old_anchor.astype('<f8').tobytes()]=old
   dump(ROOT/f'verification/baseline_and_zero_{year}.json',dict(Original_DI_baseline=original,Represented_original_schedule=base,Previous_four_window_anchor=old,Zero=zero,Setup_model_calls=4))
   for algo in ['NSGA3','NSGA2']:
    for seed in SEEDS:
     front,record=run_seed(e,algo,seed,cache);records.append(record)
     if algo=='NSGA3' and len(front):parents.append(front)
   parent=pd.concat(parents,ignore_index=True).sort_values('Irrigation_mm')[CONTROL_NAMES].to_numpy()
   for seed in FULL_SEEDS:
    _,record=run_seed(e,'NSGA3',seed,cache,True,parent);records.append(record)
   result=dict(Status='COMPLETE',Year=year,Searches=len(records),Objective_queries=sum(x['Objective_queries'] for x in records),Actual_search_model_calls=sum(x['Actual_model_calls'] for x in records),Setup_model_calls=4,Seconds=time.monotonic()-start,Runs=records)
   dump(ROOT/f'verification/year_{year}_COMPLETE.json',result);dump(ROOT/f'verification/progress_{year}.json',{k:v for k,v in result.items() if k!='Runs'});return result
  finally:e.restore()
def main():
 assert (ROOT/'verification/PREFLIGHT.json').exists(),'Run preflight first'
 if (ROOT/'verification/RUN_STATUS.json').exists():raise FileExistsError('Use a new run directory rather than restarting completed searches')
 cfg=dict(Status='RUNNING',Years=YEARS,Formal_population=POP,Formal_generations=GEN,Formal_seeds=SEEDS,Algorithms=['NSGA3','NSGA2'],Full_range_population=FULL_POP,Full_range_generations=FULL_GEN,Full_range_seeds=FULL_SEEDS,Planned_objective_queries=457600,Planned_formal_queries=400000,Planned_full_range_queries=57600,Workers=4,No_MCMC_reruns=True,Change='Five phenological stages, up to three optional events per stage; jointly optimize 15 continuous depths and 15 integer dates; merge same-day slots; explicit old-schedule warm starts',Runs=[])
 dump(ROOT/'verification/RUN_STATUS.json',cfg)
 with ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn')) as pool:
  fs=[pool.submit(run_year,y) for y in YEARS]
  for f in as_completed(fs):
   result=f.result();cfg['Runs'].append({k:v for k,v in result.items() if k!='Runs'});dump(ROOT/'verification/RUN_STATUS.json',cfg);print('YEAR COMPLETE',result['Year'],result['Objective_queries'],result['Actual_search_model_calls'],flush=True)
 cfg.update(Status='COMPLETE',Total_objective_queries=sum(r['Objective_queries'] for r in cfg['Runs']),Actual_search_model_calls=sum(r['Actual_search_model_calls'] for r in cfg['Runs']),Setup_model_calls=16);assert cfg['Total_objective_queries']==457600;dump(ROOT/'verification/RUN_STATUS.json',cfg)
if __name__=='__main__':main()
