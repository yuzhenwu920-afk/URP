from pathlib import Path
import json,re
import pandas as pd
import numpy as np
from openpyxl.styles import Font,PatternFill,Alignment
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION_START,WD_ORIENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from multi_event_engine import ROOT,STAGES
TB=ROOT/'tables';OUT=ROOT/'documents'
CN={'Seedling':'苗期','Jointing':'拔节期','Heading':'抽穗期','Grain_filling':'灌浆期','Maturity':'成熟期'}
FIGS=[
('R03_Five_stage_multi_event_Pareto_4years_EN','Five-stage multiple-event NSGA-III yield–irrigation fronts across four years.','Blue dashed lines join evaluated nondominated solutions. Red points are labelled by rounded five-stage actual irrigation totals (S1–S5, mm). Irrigation cancelled after crop termination is excluded from these totals. Orange open circles indicate the formal 95%-observed-yield candidates; stars indicate original DI model baselines.'),
('R04_Four_window_vs_multi_event_fronts_EN','Original four-window fronts and five-stage multiple-event amount/date fronts.','The revised search expands timing and event-allocation freedom. Original crop parameters, forcing and initial water are retained.'),
('R05_Five_stage_totals_and_counts_EN','Irrigation totals and event counts in each phenological stage.','Gray bars show original DI totals. Colored bars show selected optimized totals; n counts merged positive-depth events. Trace depths are retained in the source tables.'),
('R06_Optimized_event_calendar_EN','Optimized dates and individual depths for the selected schedules.','At most three optional events are allowed in each stage. Zero-depth slots do not execute, and coincident slots are merged into one daily application.'),
('R07_Annual_irrigation_and_yield_EN','Annual irrigation and yield comparison for original and optimized schedules.','The selected schedules meet 95% of the published observed yield under the frozen annual model. Irrigation-reduction percentages are relative to the original DI schedule.'),
('R08_Daily_profile_storage_EN','Daily soil-profile storage under original DI and selected schedules.','Storage integrates the unchanged 0–2.4 m simulated profile; all schedules share the annual initial water and weather.'),
('R09_Water_balance_decomposition_EN','Components of irrigation reduction under the selected schedules.','Signed ET, terminal-storage and other-loss differences close the baseline-minus-candidate water balance. Labels show the storage difference as a fraction of irrigation reduction.'),
('R10_Algorithm_convergence_EN','NSGA-III and NSGA-II population hypervolume through 100 generations.','Lines show five-seed means; shading shows seed ranges. Population hypervolume is distinct from the final union hypervolume reported in the source tables.'),
]
def read(n):return pd.read_csv(TB/n)
def font(r,size=10.5,bold=False):
 r.font.name='Times New Roman';r.font.size=Pt(size);r.bold=bold;r._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC');return r
def setup(d,title):
 s=d.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7);s.left_margin=s.right_margin=Cm(1.8);s.top_margin=Cm(1.7);s.bottom_margin=Cm(1.6)
 n=d.styles['Normal'];n.font.name='Times New Roman';n.font.size=Pt(10.5);n._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC');n.paragraph_format.line_spacing=1.25;n.paragraph_format.space_after=Pt(5)
 p=s.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER;f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f);d.core_properties.title=title;d.core_properties.author='URP项目组'
def para(d,t,size=10.5,bold=False,keep=False):
 p=d.add_paragraph();p.paragraph_format.first_line_indent=Pt(21);p.paragraph_format.keep_with_next=keep;font(p.add_run(t),size,bold);return p
def head(d,t):
 p=d.add_paragraph();p.paragraph_format.space_before=Pt(10);p.paragraph_format.keep_with_next=True;font(p.add_run(t),12,True)
def table(d,num,title,cols,rows,note=''):
 p=para(d,f'Table {num}. {title}',9.5,True,True);p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0)
 t=d.add_table(rows=1,cols=len(cols));t.autofit=True
 for c,x in zip(t.rows[0].cells,cols):c.text=str(x)
 for vals in rows:
  for c,x in zip(t.add_row().cells,vals):c.text=str(x)
 b=OxmlElement('w:tblBorders')
 for edge in ['top','bottom','left','right','insideH','insideV']:
  x=OxmlElement('w:'+edge);x.set(qn('w:val'),'single' if edge in ['top','bottom'] else 'nil');x.set(qn('w:sz'),'10');b.append(x)
 t._tbl.tblPr.append(b)
 for i,row in enumerate(t.rows):
  row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
  if i==0:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
  for cell in row.cells:
   if i==0:
    bb=OxmlElement('w:tcBorders');x=OxmlElement('w:bottom');x.set(qn('w:val'),'single');x.set(qn('w:sz'),'5');bb.append(x);cell._tc.get_or_add_tcPr().append(bb)
   for p in cell.paragraphs:
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_before=Pt(2);p.paragraph_format.space_after=Pt(2);p.paragraph_format.keep_with_next=(len(rows)<=8 and i<len(t.rows)-1) or i==0
    for r in p.runs:font(r,8.8,i==0)
 if note:para(d,'Note. '+note,8.5)
def figure(d,index,landscape=False):
 name,title,note=FIGS[index];p=ROOT/'figures'/(name+'.png')
 if landscape:
  s=d.add_section(WD_SECTION_START.NEW_PAGE);s.orientation=WD_ORIENT.LANDSCAPE;s.page_width=Cm(29.7);s.page_height=Cm(21);s.left_margin=s.right_margin=Cm(1.3);s.top_margin=s.bottom_margin=Cm(1.0)
 im=Image.open(p);width=min(25.5 if landscape else 17.1,(15.7 if landscape else 11.2)*im.width/im.height)
 pp=d.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER;pp.paragraph_format.keep_with_next=True;pp.paragraph_format.line_spacing=1;pp.add_run().add_picture(str(p),width=Cm(width))
 p=para(d,f'Figure {index+1}. {title}',9.2,True,True);p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0);p=para(d,note,8.8);p.paragraph_format.first_line_indent=Pt(0)
 if landscape:
  s=d.add_section(WD_SECTION_START.NEW_PAGE);s.orientation=WD_ORIENT.PORTRAIT;s.page_width=Cm(21);s.page_height=Cm(29.7);s.left_margin=s.right_margin=Cm(1.8);s.top_margin=Cm(1.7);s.bottom_margin=Cm(1.6)
def joinvalues(d,col,digits=2):return '、'.join(f'{v:.{digits}f}' for v in d[col])
def water_text(v,digits=2):
 if 0<abs(v)<1e-5:return f'{v:.2e}'
 return f'{v:.6f}' if abs(v)<.01 and v!=0 else f'{v:.{digits}f}'
def main():
 OUT.mkdir(exist_ok=True);s=read('Four_year_result_comparison.csv');events=read('Optimized_every_irrigation_event.csv');stages=read('Five_stage_totals_and_event_counts.csv');bounds=read('Five_stage_schedule_bounds.csv');run=json.loads((ROOT/'verification/RESULT_SUMMARY.json').read_text());d=Document();setup(d,'四年五生育期多次灌溉优化与逐次日程')
 p=para(d,'2019—2022年五生育期多次灌溉优化\n及逐次灌水日程',17,True);p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0)
 para(d,'本轮采用用户确认的方案：每个生育期最多3次灌水，允许零水量取消；同时优化每次灌水日期和水量，最终按苗期、拔节期、抽穗期、灌浆期、成熟期汇总。四年均已完成实际模型搜索，原四窗口结果保留作对照。')
 head(d,'1 优化设计与固定条件')
 para(d,'各年设置15个可选灌水槽位，每期3个。决策变量包括15个连续灌水量和15个整数日期，共30维。采用各年度已知天气开展回顾性日程优化，灌水日期限定在王尚今（2023）表2-3的年度生育期与模型实际执行日历的交集内。同日槽位合并成一次灌溉，零水量不执行，最终每期最多3个不同的实际灌水日。原日程及原四窗口代表方案均可在这一控制空间内精确表示，并作为明确标注的初始化日程。')
 para(d,'本轮固定原四年MCMC保留样本均值、土壤结构与初始含水量、气象驱动、MulchPct=75%、fMulch=0、Zmin=0.30 m、Zmax=2.30 m及2.4 m模拟剖面。采用季节总灌水上限与产量门槛约束；灌溉管理器单次上限随计划最大日灌水量设置，以完整执行候选日程。季末储水及最大单次灌水量作为结果单独报告。')
 para(d,'正式NSGA-III和NSGA-II均采用名义100个体、100代、5个种子，以最大化13%含水率产量、最小化实际季节灌水量为目标，主候选满足产量不低于观测值的95%。全范围补充搜索采用NSGA-III、80个体、60代、3个种子，以覆盖零灌水至高产平台。四年实际目标查询合计'+f'{run["Objective_queries"]:,}'+'次。原日程和旧代表方案作为两算法共有初值，搜索过程及每代检查点全部保存。')
 para(d,'主候选取正式NSGA-III五种子最终种群可行非支配解并集中的最低灌水解。每期次数并非预先要求灌满3次，而由15个槽位的优化水量及日期确定。优化目标为水量和产量，灌水次数作为结果统计；0.1 mm以上的事件另作便于操作阅读的描述统计，所有小水量均保留在未取整源表中。')
 head(d,'2 四年前沿及年度候选')
 para(d,'四年全范围帕累托前沿见图1，图中括号依次给出五期总灌水量。前沿中的各点对应真实模型计算及其逐次日程，曲线展示当前搜索预算内的非支配关系。正式主候选的灌水量分别为'+joinvalues(s,'Optimized_I_mm')+' mm，对应产量为'+joinvalues(s,'Optimized_Y13',3)+' t·ha⁻¹。')
 figure(d,0,True)
 table(d,1,'Selected five-stage multiple-event schedules at 95% observed yield.',['Year','Original I\n(mm)','Optimized I\n(mm)','Yield\n(t ha⁻¹)','I reduction\n(%)','Positive\nevents','Max event\n(mm)'],[[int(r.Year),f'{r.Original_I_mm:.2f}',f'{r.Optimized_I_mm:.2f}',f'{r.Optimized_Y13:.3f}',f'{r.I_reduction_pct:.2f}',int(r.Positive_events),f'{r.Max_event_mm:.2f}'] for r in s.itertuples()],'Positive events include all exact positive depths, including numerical trace amounts; practical counts >=0.1 mm are supplied in the source table.')
 original_events=read('Baseline_and_selected_water_ledger.csv');original_events=original_events[original_events.Scenario=='Original_DI'].set_index('Year')
 table(d,'1b','Individual-event magnitudes and timing of the selected schedules.',['Year','Original max\n(mm)','Selected max\n(mm)','Events\n≥0.1 mm','Minimum gap\n(days)'],[[int(r.Year),f'{original_events.loc[r.Year,"Max_actual_event_mm"]:.2f}',f'{r.Max_event_mm:.2f}',int(r.Events_ge_0p1mm),int(r.Minimum_positive_event_gap_days)] for r in s.itertuples()],'The original measured maximum was an execution guard, not an additional equipment constraint in this search. Gaps count all positive-depth events; trace depths can shorten the reported gap.')
 para(d,'新增日期和逐次水量自由度后，单次灌水量可能超过原实测最大值，相邻日期也可能较近。表1b单独对照原日程与新日程的最大单次量、事件数和间隔。本轮未附加管网供水能力、最小单次量或最小间隔约束，因而这些数值与季节总量一并保留，供后续按实际运行条件筛选。')
 para(d,'相对原四窗口代表方案，新方案季节灌水变化分别为'+joinvalues(s,'New_minus_old_I_mm')+' mm。图2同时展示两种控制空间的全范围结果。本次增加了生育期内逐次水量及日期的自由度，原四窗口日程属于新空间可表示的方案，因此该比较反映控制空间扩展的综合影响。')
 figure(d,1)
 head(d,'3 五期总量与优化后的逐次灌水')
 para(d,'五期总量和次数见图3，逐次日期与水量见图4及表2。每年的阶段总量之和、逐次实际灌水量之和与模型季节灌水量一致，误差均小于10⁻⁷ mm。下表列出全部正水量事件；零水量槽位保存在All_selected_schedule_slots.csv中，标注为不灌水。')
 figure(d,2);figure(d,3)
 for year in range(2019,2023):
  v=events[events.Year==year].sort_values('Date');table(d,f'2-{year}',f'Every optimized irrigation date and depth in {year}.',['Event','Stage','Date','Model day\n(1-based)','Actual depth\n(mm)','Interval\n(days)'],[[i+1,r.Stage_name.replace('_',' '),r.Date,int(r.DAP),water_text(r.Actual_mm),'–' if i==0 else (pd.Timestamp(r.Date)-pd.Timestamp(v.iloc[i-1].Date)).days] for i,r in enumerate(v.itertuples())],'Model day 1 is the planting date (source column: DAP). Depths below 0.01 mm use six decimals, or scientific notation below 0.00001 mm. Date intervals are descriptive outputs, with no extra minimum-gap constraint.')
 head(d,'4 产量、灌水量与土壤水分过程')
 para(d,'图5比较观测产量、DI模型基准和主候选。四年候选相对观测产量的偏差分别为'+joinvalues(s,'Yield_RE_vs_observed_pct')+'%，产量门槛为观测值的95%。灌水减少率与产量变化分别报告。')
 figure(d,4)
 para(d,'图6给出相同初始水分与年度气象条件下的全剖面储水时序。原日程季末储水分别为'+joinvalues(s,'Original_final_profile_mm')+' mm，主候选为'+joinvalues(s,'Optimized_final_profile_mm')+' mm。该差额与蒸散及其他损失差共同解释季节灌水变化。')
 figure(d,5)
 para(d,'四年ET变化对应的下降量分别为'+joinvalues(s,'ET_reduction_mm')+' mm，季末储水差分别为'+joinvalues(s,'Lower_final_storage_mm')+' mm，储水差解释的减灌比例分别为'+joinvalues(s,'Storage_difference_share_pct')+'%。图7按同一水量平衡关系展示差额组成；完整日账与原始未取整数值随包提供。')
 figure(d,6)
 table(d,3,'Water-balance decomposition for the selected schedules.',['Year','I reduction\n(mm)','ET reduction\n(mm)','Lower final S\n(mm)','Other losses\n(mm)','Storage share\n(%)'],[[int(r.Year),f'{r.I_reduction_mm:.2f}',f'{r.ET_reduction_mm:.2f}',f'{r.Lower_final_storage_mm:.2f}',f'{r.Other_loss_reduction_mm:.2f}',f'{r.Storage_difference_share_pct:.2f}'] for r in s.itertuples()],'Differences are baseline minus selected schedule; signed components sum to irrigation reduction.')
 head(d,'5 搜索过程及数值复现')
 para(d,'图8给出五次随机启动的种群超体积均值及范围。两种算法采用同一控制空间、目标、约束和共同初值。新旧方案的模型参数保持一致；本轮是优化重算，未重新进行MCMC或Sobol计算。最终选定方案及图中标注点均经完整适配器回放，最大输出差为'+f'{run["Maximum_full_adapter_difference"]:.3g}'+'，最大逐日水量闭合残差为'+f'{run["Maximum_daily_balance_residual_mm"]:.3g}'+' mm。')
 figure(d,7)
 algo=read('Algorithm_comparison.csv').sort_values(['Year','Algorithm'])
 table(d,4,'Five-seed final-population union metrics under the same constraints.',['Year','Algorithm','Minimum I\n(mm)','Maximum yield\n(t ha⁻¹)','Union HV'],[[int(r.Year),'NSGA-III' if r.Algorithm=='NSGA3' else 'NSGA-II',f'{r.Minimum_I_mm:.3f}',f'{r.Maximum_Y13:.3f}',f'{r.Normalized_union_HV:.6f}'] for r in algo.itertuples()],'Each algorithm receives five seeds and shares the disclosed initialization anchors. The minimum irrigation and maximum yield can belong to different schedules. The primary event calendar follows the stated NSGA-III selection rule.')
 head(d,'6 论文中可采用的优化方法表述')
 para(d,'根据各年度玉米苗期、拔节期、抽穗期、灌浆期和成熟期划分灌溉管理阶段，每阶段设置最多3个可选灌水事件。以各事件灌水量和所在阶段内的整数日期为决策变量，构建产量最大、实际季节灌水量最小的双目标优化模型。对同日事件合并计量，以零灌水量表示该槽位不执行。采用NSGA-III求解并以NSGA-II作对照，在产量不低于观测值95%的条件下选取最低灌水候选；同时输出逐次灌水日程、五期汇总及土壤储水变化。')
 head(d,'7 交付内容与统计记录')
 para(d,'Optimized_every_irrigation_event.csv给出每次日期、水量及所属生育期；Five_stage_totals_and_event_counts.csv给出每期总量与次数；All_selected_schedule_slots.csv保留15个槽位，包括零量、取消和数值残量。Pareto_every_irrigation_event.csv.gz进一步给出全范围前沿每个解的逐次日程，通过Control_ID对应前沿总表。Excel汇总主要数据，PNG、PDF及SVG提供英文图件。各年原始查询、每代种群、日期和水量控制量分年打包。')
 para(d,'首个种子的重复初值经规范化去重后为99个，其后99代均为100个，每年该种子实际查询9999次；这些完整100代记录按实际值保留。后续初值补齐100个不同控制量。该统计差异未增加、填充或替换任何模型结果，详细恢复记录位于verification/INITIAL_BUDGET_RECOVERY.json。',9)
 para(d,'生育期依据：王尚今. 不同灌溉方式下覆膜玉米田水热氮传输及作物生长的观测与模拟[D]. 中国农业大学, 2023，表2-3，正文第11页。优化方法：Deb等（2002）NSGA-II；Deb和Jain（2014）NSGA-III。',9)
 d.save(OUT/'URP_Five_Stage_Multi_Event_Optimization_20261022.docx')
 # A separate compact, directly usable schedule document avoids searching figures.
 q=Document();setup(q,'四年优化灌水日程');para(q,'四年优化灌水日程：逐次日期、灌水量与五期汇总',16,True)
 for year in range(2019,2023):
  if year>2019:q.add_page_break()
  head(q,str(year)+'年');r=s[s.Year==year].iloc[0];para(q,f'产量门槛={r.Yield_gate:.3f} t·ha⁻¹；候选产量={r.Optimized_Y13:.3f} t·ha⁻¹；季节实际灌水量={r.Optimized_I_mm:.2f} mm。')
  v=events[events.Year==year].sort_values('Date');table(q,year,'Optimized individual events.',['Stage','Date','Actual depth (mm)'],[[r.Stage_name.replace('_',' '),r.Date,water_text(r.Actual_mm,6)] for r in v.itertuples()])
  a=stages[(stages.Year==year)&(stages.Control_ID=='Selected_95pct')];table(q,str(year)+'S','Five-stage totals.',['Stage','Total depth (mm)','Positive events'],[[r.Stage_name.replace('_',' '),f'{r.Actual_mm:.6f}',int(r.Positive_events)] for r in a.itertuples()])
 q.save(OUT/'URP_Optimized_Every_Event_Schedule_20261022.docx')
 with pd.ExcelWriter(TB/'URP_Five_Stage_Multi_Event_Results_20261022.xlsx',engine='openpyxl') as w:
  names=['Four_year_result_comparison.csv','Optimized_every_irrigation_event.csv','Five_stage_totals_and_event_counts.csv','All_selected_schedule_slots.csv','Five_stage_schedule_bounds.csv','Selected_95pct_candidates.csv','Algorithm_comparison.csv','Formal_all_query_archive_minima.csv','Pareto_display_points.csv','Full_range_Pareto_front.csv','Generation_history.csv','Search_run_summary.csv','Baseline_and_selected_water_ledger.csv','Fixed_proportion_dose_response.csv','Selected_full_adapter_replay_checks.csv']
  for i,name in enumerate(names):read(name).to_excel(w,sheet_name=f'{i+1:02d}_'+Path(name).stem[:27],index=False)
  for sheet in w.book.worksheets:
   sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions
   sheet.row_dimensions[1].height=32
   for cell in sheet[1]:
    cell.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='245568');cell.alignment=Alignment(vertical='center',wrap_text=True);sheet.column_dimensions[cell.column_letter].width=min(40,max(12,len(str(cell.value or ''))+2))
   for row in sheet.iter_rows(min_row=2):
    for cell in row:
     if isinstance(cell.value,float):cell.number_format='0.000E+00' if 0<abs(cell.value)<1e-5 else '0.000000'
 print('Reports and source workbook created')
if __name__=='__main__':main()
