"""User-authorized final design: at most three optional events in each stage.

15 continuous depths + 15 integer dates. Identical-date slots are merged.
The original schedule and the previous four-window candidate are exactly
representable, and are disclosed initialization anchors for both algorithms.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from timing_engine import ROOT,PROJECT,TimingEngine,OBS,STAGES,STAGE_DATES,dump,sha
SLOTS=3;N_EVENTS=15
AMOUNT_NAMES=[f'S{s+1}_E{k+1}_mm' for s in range(5) for k in range(SLOTS)]
DAY_NAMES=[f'S{s+1}_E{k+1}_day_index' for s in range(5) for k in range(SLOTS)]
CONTROL_NAMES=AMOUNT_NAMES+DAY_NAMES

class MultiEventEngine(TimingEngine):
 def __init__(self,year):
  super().__init__(year);self.slot_low=np.repeat(self.day_low,SLOTS);self.slot_high=np.repeat(self.day_high,SLOTS)
  self.base=self.from_schedule(self.data['schedule']);self.zero=np.r_[np.zeros(N_EVENTS),self.slot_low]
  old=pd.read_csv(ROOT/'source/four_window_reference/NSGA_event_schedules.csv');old=old[old.Year==year]
  old_schedule=pd.DataFrame(dict(Date=pd.to_datetime(old.Date),Depth=old.Candidate_actual_mm.to_numpy(float)));self.old_anchor=self.from_schedule(old_schedule)
  self.space.update(Names=CONTROL_NAMES,Amount_names=AMOUNT_NAMES,Day_index_names=DAY_NAMES,Amount_bounds_mm=[[0,self.cap]]*N_EVENTS,Day_index_bounds=[list(x) for x in zip(self.slot_low.tolist(),self.slot_high.tolist())],Maximum_events_per_stage=3,Maximum_events_per_season=15,
   Events_per_stage='0 to 3 optional events; exactly zero depth cancels a slot; same-day slots merged',Five_stages_all_eligible=True,Decision_dimension=30,
   Slot_day_index_bounds=[list(x) for x in zip(self.slot_low.tolist(),self.slot_high.tolist())],
   Original_schedule_representable=True,Previous_four_window_candidate_representable=True,Initialization_anchors='Original schedule and previous four-window candidate, explicitly warm-started, plus independent random allocations',
   Irrigation_count_penalty=False,Minimum_inter_event_gap_days=0,Additional_event_hardware_cap=False,
   Event_count_reporting='Exact positive-depth merged events; practical events >=0.1 mm also summarized without changing any evaluated control')
 def from_schedule(self,schedule):
  water=np.zeros(N_EVENTS);days=np.repeat(self.day_low,SLOTS).astype(float);counts=np.zeros(5,int)
  for r in schedule.itertuples():
   i=int(self.dates.get_loc(pd.Timestamp(r.Date)));matches=[j for j,(a,b) in enumerate(self.stage_bounds) if a<=i<=b];assert len(matches)==1;j=matches[0];k=counts[j];assert k<SLOTS;counts[j]+=1;water[j*SLOTS+k]=float(r.Depth);days[j*SLOTS+k]=i
  return self.repair(np.r_[water,days][None,:])[0]
 def repair(self,X):
  X=np.asarray(X,float).copy();assert X.shape[1]==2*N_EVENTS
  X[:,:N_EVENTS]=np.clip(X[:,:N_EVENTS],0,self.cap);tot=X[:,:N_EVENTS].sum(axis=1);X[:,:N_EVENTS]*=np.minimum(1,self.cap/np.maximum(tot,np.finfo(float).tiny))[:,None]
  X[:,N_EVENTS:]=np.clip(np.rint(X[:,N_EVENTS:]),self.slot_low,self.slot_high)
  for r in X:
   for stage in range(5):
    ids=range(stage*SLOTS,(stage+1)*SLOTS);merged={}
    for k in ids:
     if r[k]>0:
      day=int(r[N_EVENTS+k]);merged[day]=merged.get(day,0.)+r[k]
    r[list(ids)]=0.;r[[N_EVENTS+k for k in ids]]=self.day_low[stage]
    for k,(day,amount) in zip(ids,sorted(merged.items())):r[k]=amount;r[N_EVENTS+k]=day
  return X
 def expand(self,z):
  z=np.asarray(z,float);assert z.shape==(2*N_EVENTS,);return z
 def run(self,x,use_prefix=True,details=False):
  x=np.asarray(x,float);assert x.shape==(2*N_EVENTS,);days=x[N_EVENTS:].astype(int)
  assert np.array_equal(days,x[N_EVENTS:]) and np.all(days>=self.slot_low) and np.all(days<=self.slot_high) and np.all(x[:N_EVENTS]>=0)
  return self._run_schedule(x[:N_EVENTS],days,use_prefix,details)
 def records(self,x):
  water=x[:N_EVENTS];days=x[N_EVENTS:];return dict(**dict(zip(AMOUNT_NAMES,map(float,water))),**dict(zip(DAY_NAMES,map(int,days))),
   **{f'S{s+1}_total_mm':float(water[s*SLOTS:(s+1)*SLOTS].sum()) for s in range(5)},
   **{f'S{s+1}_positive_events':int((water[s*SLOTS:(s+1)*SLOTS]>0).sum()) for s in range(5)})
 def schedule_rows(self,x,response=None,control_id=''):
  rows=[];harvest=pd.Timestamp(response['Harvest_date']) if response is not None else None
  for stage in range(5):
   for slot in range(SLOTS):
    k=stage*SLOTS+slot;day=int(x[N_EVENTS+k]);date=self.dates[day];planned=float(x[k]);actual=0. if harvest is not None and date>=harvest else planned
    rows.append(dict(Year=self.year,Control_ID=control_id,Stage=stage+1,Stage_name=STAGES[stage],Slot=slot+1,Date=str(date.date()),DAP=day+1,Planned_mm=planned,Actual_mm=actual,Status='zero depth; no irrigation' if planned==0 else 'cancelled after harvest' if actual==0 else 'trace depth below 0.1 mm' if actual<.1 else 'irrigation',Eligible_window_start=self.space['Executed_date_windows'][stage][0],Eligible_window_end=self.space['Executed_date_windows'][stage][1]))
  return rows
 def native_reference(self,x=None):
  assert not self.active;a=self.adapter;orig=self.data;oldspace=a.management_space
  if x is not None:
   schedule=pd.DataFrame(dict(Date=[self.dates[int(i)] for i in x[N_EVENTS:]],Depth=x[:N_EVENTS])).groupby('Date',as_index=False).Depth.sum().sort_values('Date')
   stage_indexes=[next(j for j,(lo,hi) in enumerate(self.stage_bounds) if lo<=self.dates.get_loc(d)<=hi) for d in schedule.Date]
   data=dict(orig);data['schedule']=schedule;a.STATES[self.year]=(self.m,data);a.management_space=lambda y:dict(event_stages=stage_indexes)
  a._template.cache_clear()
  try:return a.simulate(params=self.params,year=self.year,management=None,details=True,accelerate=True)
  finally:a.STATES[self.year]=(self.m,orig);a.management_space=oldspace;a._template.cache_clear()
