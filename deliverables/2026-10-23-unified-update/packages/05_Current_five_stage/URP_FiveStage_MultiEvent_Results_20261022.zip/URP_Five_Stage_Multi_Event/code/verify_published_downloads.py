"""Download published immutable artifacts and verify full bytes and ZIP CRC."""
import hashlib, json, sys, tempfile, urllib.request, zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from multi_event_engine import ROOT

REPO='yuzhenwu920-afk/URP'
SUBDIR='deliverables/2026-10-22-five-stage-multi-event'

def one(item):
    sha_commit, path = item
    url=f'https://raw.githubusercontent.com/{REPO}/{sha_commit}/{SUBDIR}/{path.name}'
    h=hashlib.sha256();size=0
    req=urllib.request.Request(url,headers={'User-Agent':'URP-artifact-verification'})
    with tempfile.TemporaryFile() as local:
        with urllib.request.urlopen(req, timeout=180) as response:
            code=response.status
            assert code==200, (path.name,code)
            for b in iter(lambda:response.read(1024*1024),b''):
                h.update(b);size+=len(b);local.write(b)
        expected=hashlib.sha256(path.read_bytes()).hexdigest()
        assert size==path.stat().st_size and h.hexdigest()==expected, path.name
        crc=None
        if path.suffix in ['.zip','.docx','.xlsx']:
            local.seek(0)
            with zipfile.ZipFile(local) as z:
                assert z.testzip() is None,path.name
            crc='PASS'
    return dict(File=path.name,URL=url,HTTP=code,Bytes=size,SHA256=expected,Full_download='PASS',ZIP_CRC=crc)

def main():
    sha_commit=sys.argv[1];assert len(sha_commit)==40 and all(c in '0123456789abcdef' for c in sha_commit)
    paths=sorted(p for p in (ROOT/'delivery').iterdir() if p.suffix in ['.zip','.docx','.pdf','.xlsx','.png','.csv'])
    with ThreadPoolExecutor(max_workers=3) as pool:
        records=list(pool.map(one,[(sha_commit,p) for p in paths]))
    result=dict(Status='PASS',Commit=sha_commit,Repository=REPO,Directory=SUBDIR,Files=records)
    (ROOT/'verification/PUBLISHED_DOWNLOAD_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
