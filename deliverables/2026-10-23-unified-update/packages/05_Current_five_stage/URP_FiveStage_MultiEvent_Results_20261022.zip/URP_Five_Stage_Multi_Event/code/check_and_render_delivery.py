from pathlib import Path
import json,re,hashlib
import pandas as pd
import numpy as np
import fitz
from PIL import Image,ImageDraw
from docx import Document
from multi_event_engine import ROOT,PROJECT,AMOUNT_NAMES,DAY_NAMES,STAGES,OBS
def main():
 result=json.loads((ROOT/'verification/RESULT_SUMMARY.json').read_text());fresh=json.loads((ROOT/'verification/FRESH_UNACCELERATED_CHECK.json').read_text());assert result['Status']=='COMPLETE' and fresh['Status']=='PASS'
 runs=[];queries=calls=0
 for folder in sorted((ROOT/'runs').glob('*/*/*')):
  record=json.loads((folder/'run.json').read_text());assert record['Status']=='COMPLETE';d=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip');assert len(d)==record['Objective_queries'];assert (~d.Exact_cache_hit).sum()==record['Actual_model_calls'];queries+=len(d);calls+=record['Actual_model_calls'];year=int(d.Year.iloc[0])
  spec=json.loads((ROOT/f'source/decision_space_{year}.json').read_text());lo=np.array([x[0] for x in spec['Slot_day_index_bounds']]);hi=np.array([x[1] for x in spec['Slot_day_index_bounds']]);water=d[AMOUNT_NAMES].to_numpy();days=d[DAY_NAMES].to_numpy()
  assert np.isfinite(water).all() and (water>=0).all() and np.array_equal(days,np.rint(days)) and (days>=lo).all() and (days<=hi).all()
  cap=record['Identity']['Seasonal_cap_mm'];assert (water.sum(axis=1)<=cap+1e-8).all();assert np.allclose(water.sum(axis=1),d.Planned_irrigation_mm,atol=1e-8,rtol=0);assert np.allclose(d.ET_mm,d.Tr_mm+d.Es_mm,atol=1e-8,rtol=0);assert d.Water_balance_residual_mm.abs().max()<1e-5
  assert np.isfinite(d[['Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','Profile_initial_mm','Profile_final_mm']].to_numpy(float)).all()
  for j in range(5):
   a=water[:,j*3:(j+1)*3];b=days[:,j*3:(j+1)*3]
   for u,v in [(0,1),(0,2),(1,2)]:assert not ((a[:,u]>0)&(a[:,v]>0)&(b[:,u]==b[:,v])).any()
  assert len(list(folder.glob('generation_*.npz')))==record['Identity']['Generations'];runs.append(dict(Path=str(folder.relative_to(ROOT)),Queries=len(d),Actual_calls=record['Actual_model_calls'],Calendar_valid=True,Max_three_distinct_events_per_stage=True))
 assert len(runs)==52 and queries==result['Objective_queries'] and calls==result['Actual_search_model_calls']
 table=pd.read_csv(ROOT/'tables/Five_stage_totals_and_event_counts.csv');events=pd.read_csv(ROOT/'tables/Optimized_every_irrigation_event.csv');comp=pd.read_csv(ROOT/'tables/Four_year_result_comparison.csv')
 for r in comp.itertuples():
  s=table[(table.Year==r.Year)&(table.Control_ID=='Selected_95pct')];e=events[events.Year==r.Year];assert len(s)==5 and (s.Positive_events<=3).all();assert abs(e.Actual_mm.sum()-r.Optimized_I_mm)<1e-7;assert abs(s.Actual_mm.sum()-r.Optimized_I_mm)<1e-7;assert r.Optimized_Y13>=.95*OBS[int(r.Year)]-1e-9;assert abs(r.I_reduction_mm-r.ET_reduction_mm-r.Lower_final_storage_mm-r.Other_loss_reduction_mm)<1e-7
 front=pd.read_csv(ROOT/'tables/Full_range_Pareto_front.csv');all_events=pd.read_csv(ROOT/'tables/Pareto_every_irrigation_event.csv.gz');totals=all_events.groupby('Control_ID').Actual_mm.sum().reindex(front.Control_ID,fill_value=0).to_numpy()
 assert np.allclose(totals,front.Irrigation_mm,atol=1e-7,rtol=0)
 assert np.allclose(front[[f'S{j}_actual_total_mm' for j in range(1,6)]].sum(axis=1),front.Irrigation_mm,atol=1e-7,rtol=0)
 assert (front[[f'S{j}_actual_events' for j in range(1,6)]]<=3).all().all()
 manifest=pd.read_csv(ROOT/'verification/FROZEN_SOURCE_MANIFEST.csv')
 for r in manifest.itertuples():assert hashlib.sha256((ROOT/r.Path).read_bytes()).hexdigest()==r.SHA256
 cjk=[]
 for p in (ROOT/'figures').glob('*.pdf'):
  text=''.join(pg.get_text() for pg in fitz.open(p))
  if re.search(r'[\u4e00-\u9fff]',text):cjk.append(p.name)
 assert not cjk
 figures=[]
 for p in sorted((ROOT/'figures').glob('*.png')):
  im=Image.open(p).convert('RGB');im.thumbnail((520,350));can=Image.new('RGB',(550,385),'white');can.paste(im,((550-im.width)//2,10));ImageDraw.Draw(can).text((8,367),p.stem,fill='black');figures.append(can)
 contact=Image.new('RGB',(1650,385*((len(figures)+2)//3)),'#CFD8DC')
 for i,im in enumerate(figures):contact.paste(im,((i%3)*550,(i//3)*385))
 contact.save(ROOT/'verification/Figures_contact.jpg',quality=90)
 pages=[];edges=[]
 for p in (ROOT/'documents').glob('*.pdf'):
  doc=fitz.open(p);thumbs=[]
  for i,pg in enumerate(doc):
   pix=pg.get_pixmap(matrix=fitz.Matrix(.42,.42));im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((270,335));can=Image.new('RGB',(290,370),'white');can.paste(im,(10,10));ImageDraw.Draw(can).text((10,350),f'Page {i+1}',fill='black');thumbs.append(can)
   for b in pg.get_text('dict')['blocks']:
    for line in b.get('lines',[]):
     for span in line['spans']:
      if span['bbox'][0]<12 or span['bbox'][2]>pg.rect.width-12:edges.append(dict(File=p.name,Page=i+1,Text=span['text']))
  can=Image.new('RGB',(1450,370*((len(thumbs)+4)//5)),'#CFD8DC')
  for i,im in enumerate(thumbs):can.paste(im,((i%5)*290,(i//5)*370))
  can.save(ROOT/'verification'/(p.stem+'_contact.jpg'),quality=88);pages.append(dict(File=p.name,Pages=len(doc)))
 assert not edges,edges
 report=Document(ROOT/'documents/URP_Five_Stage_Multi_Event_Optimization_20261022.docx');assert len(report.inline_shapes)==8
 out=dict(Status='PASS',Raw_searches=len(runs),Raw_query_rows=queries,Actual_search_model_calls=calls,No_synthetic_rows=True,Date_bounds_checked_for_all_queries=True,Per_stage_event_limit_checked_for_all_queries=True,Full_daily_equation_replays=fresh,Stage_totals_reconcile_with_every_event=True,Frozen_sources_unchanged=True,English_figure_groups=len(figures),CJK_in_figures=cjk,PDF_edge_spans=edges,Documents=pages,Searches=runs)
 (ROOT/'verification/FINAL_DELIVERY_CHECK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('FINAL DELIVERY CHECK PASS',queries,'queries',len(figures),'figure groups',pages)
if __name__=='__main__':main()
