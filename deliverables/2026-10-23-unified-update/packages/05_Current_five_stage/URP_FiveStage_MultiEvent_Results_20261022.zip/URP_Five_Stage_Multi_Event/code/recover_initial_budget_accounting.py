"""Recover fully executed first seeds after a bookkeeping-only assertion.

Canonical duplicate anchors yielded 99 initial individuals rather than 100.
Every first seed completed 100 generations and 9,999 queries; no model result
is replaced or padded. Subsequent seeds fill unique anchors to size 100.
"""
from pathlib import Path
import json,shutil
import numpy as np
import pandas as pd
from multi_event_engine import ROOT,CONTROL_NAMES,dump
from run_optimization import nd
def main():
 audit=[]
 for year in range(2019,2023):
  folder=ROOT/f'runs/{year}/formal/NSGA3_seed31';state=json.loads((folder/'run.json').read_text());assert state['Status']=='FAILED'
  history=pd.read_csv(folder/'history.csv');assert len(history)==100 and int(history.Generation.iloc[-1])==100 and int(history.Evaluations.iloc[-1])==9999
  raw=pd.read_csv(folder/'evaluations.csv.gz',float_precision='round_trip');assert len(raw)==9999
  f=nd(raw[(raw.G_irrigation<=0)&(raw.G_yield<=0)]);f.to_csv(folder/'all_evaluated_front.csv',index=False)
  with np.load(folder/'generation_0100.npz') as z:
   X,F,CV=z['X_encoded'],z['F'],z['CV'];assert len(X)==100;last=pd.DataFrame(X,columns=CONTROL_NAMES);last['Y_13pct']=-F[:,0];last['Irrigation_mm']=F[:,1];last['Year']=year;last['Algorithm']='NSGA3';last['Seed']=31
   final=nd(last[CV<=0]);final.to_csv(folder/'final_population_front.csv',index=False)
  shutil.copy2(folder/'run.json',folder/'bookkeeping_assertion_original.json')
  rec=dict(Status='COMPLETE',Identity=state['Identity'],Objective_queries=9999,Actual_model_calls=int(history.Actual_model_calls.iloc[-1]),Exact_cache_hits=9999-int(history.Actual_model_calls.iloc[-1]),All_evaluated_front_points=len(f),Final_population_front_points=len(final),Seconds=float(history.Seconds.iloc[-1]),Recovery='All 100 generations completed; recovered feasible nondominated set from exact final population after nominal-budget assertion. First population 99 after duplicate elimination; no padded queries.',Final_front_scope='Entire feasible nondominated final population, not only NSGA-III reference-direction representatives')
  dump(folder/'run.json',rec);dump(folder/'COMPLETE.json',{k:rec[k] for k in ['Status','Objective_queries','Actual_model_calls']});audit.append(dict(Year=year,Queries=9999,Generations=100,Initial_population=99,Remaining_generations_population=100,Rows_preserved=True))
 dump(ROOT/'verification/INITIAL_BUDGET_RECOVERY.json',dict(Cause='One duplicate initialization anchor removed before generation 1',Action='Preserve all 9999 actual queries and final checkpoint. Subsequent initial samples are filled to 100 distinct encoded controls.',Recovered=audit,No_model_or_objective_change=True))
 st=json.loads((ROOT/'verification/RUN_STATUS.json').read_text());shutil.copy2(ROOT/'verification/optimization_driver.log',ROOT/'verification/initial_bookkeeping_assertion.log');st['Status']='RECOVERED_FIRST_SEED_BUDGET_ACCOUNTING';dump(ROOT/'verification/RUN_STATUS.json',st);print('Recovered 4 completed first seeds without rerunning or padding; continuation ready')
if __name__=='__main__':main()
