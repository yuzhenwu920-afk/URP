from pathlib import Path
import json,time,subprocess,sys,os
ROOT=Path(__file__).resolve().parents[1]
def run(name):
 print('START',name,flush=True);subprocess.run([sys.executable,str(ROOT/'code'/name)],cwd=ROOT,check=True);print('DONE',name,flush=True)
if __name__=='__main__':
 while True:
  d=json.loads((ROOT/'verification/RUN_STATUS.json').read_text())
  if d['Status']=='COMPLETE':break
  text=(ROOT/'verification/optimization_driver.log').read_text()
  if 'Traceback (most recent call last)' in text:raise RuntimeError('Optimizer requires review; no publication pipeline started')
  time.sleep(5)
 for name in ['aggregate_results.py','verify_fresh_equations.py','make_figures.py','build_report.py']:run(name)
 cmd=['soffice','-env:UserInstallation=file://'+str(ROOT/'verification/lo_profile'),'--headless','--convert-to','pdf','--outdir',str(ROOT/'documents')]+[str(p) for p in (ROOT/'documents').glob('*.docx')]
 subprocess.run(cmd,check=True);print('POSTPROCESS_COMPLETE: ready for document and figure review',flush=True)
