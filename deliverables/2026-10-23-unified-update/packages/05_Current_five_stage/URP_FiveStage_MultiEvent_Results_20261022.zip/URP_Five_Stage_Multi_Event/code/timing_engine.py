"""Shared forward-model kernel and stage calendars.

The final optimization imports MultiEventEngine from multi_event_engine.py,
which overrides the legacy five-event helpers in this base class with fifteen
optional events (three per stage). All evaluated controls use that 30D class.
The original DI schedule is retained as an external baseline. Zero-irrigation
prefix STATES are cached exactly; no response is interpolated.
"""
from pathlib import Path
import os,sys,json,copy,importlib,importlib.util,hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT/'source/model_snapshot'
NAMES=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
STAGES=['Seedling','Jointing','Heading','Grain_filling','Maturity']
AMOUNTS=[f'Stage{i+1}_{s}_mm' for i,s in enumerate(STAGES)]
DAY_INDEXES=[f'Stage{i+1}_day_index' for i in range(5)]
CONTROL_NAMES=AMOUNTS+DAY_INDEXES
STAGE_DATES={2019:[('04-18','05-31'),('06-01','07-09'),('07-10','08-04'),('08-05','08-31'),('09-01','09-16')],2020:[('04-20','06-06'),('06-07','07-13'),('07-14','07-27'),('07-28','08-20'),('08-21','09-18')],2021:[('04-27','06-11'),('06-12','07-12'),('07-13','07-28'),('07-29','08-20'),('08-21','09-22')],2022:[('04-17','06-01'),('06-02','07-04'),('07-05','07-20'),('07-21','08-12'),('08-13','09-12')]}
OBS={2019:16.55,2020:17.29,2021:15.86,2022:14.08}
def dump(path,obj):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False));os.replace(tmp,p)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

class TimingEngine:
 def __init__(self,year):
  self.year=int(year);p=PROJECT/'real_model/four_year_adapter.py';sp=importlib.util.spec_from_file_location(f'original_timing_{year}',p);a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);self.adapter=a
  self.m,self.data=a._load(year);self.old_space=a.management_space(year);self.m.OUTPUT_DIR=ROOT/f'verification/input_audit/{year}';self.m.OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
  cfg=json.loads((PROJECT/'project_config.json').read_text());v=pd.read_csv(PROJECT/cfg['centers'],float_precision='round_trip').set_index('Year').loc[year];self.params=v[NAMES].to_dict();self.cap=float(self.data['schedule'].Depth.sum());self.old_management_space=a.management_space
  self.dates=self.m.DATES;self.n=len(self.dates);self.stage_bounds=[];self.base_amounts=np.zeros(5);self.base_days=[]
  for j,(start,end) in enumerate(STAGE_DATES[year]):
   first=max(pd.Timestamp(f'{year}-{start}'),self.dates[0]);last=min(pd.Timestamp(f'{year}-{end}'),self.dates[-1]);lo=int(self.dates.get_loc(first));hi=int(self.dates.get_loc(last));self.stage_bounds.append((lo,hi))
   schedule=self.data['schedule'];s=schedule[schedule.Date.between(first,last)]
   self.base_amounts[j]=float(s.Depth.sum());self.base_days.append(int(round(np.average([self.dates.get_loc(x) for x in s.Date],weights=s.Depth))) if len(s) else int(round((lo+hi)/2)))
  self.base=np.r_[self.base_amounts,np.asarray(self.base_days,float)];self.day_low=np.array([a for a,b in self.stage_bounds]);self.day_high=np.array([b for a,b in self.stage_bounds]);self.zero=np.r_[np.zeros(5),self.day_low];self.active=np.arange(10)
  self.space=dict(Names=CONTROL_NAMES,Amount_names=AMOUNTS,Day_index_names=DAY_INDEXES,Amount_bounds_mm=[[0,self.cap]]*5,Day_index_bounds=[list(x) for x in self.stage_bounds],Thesis_stage_dates=STAGE_DATES[year],Executed_date_windows=[[str(self.dates[a].date()),str(self.dates[b].date())] for a,b in self.stage_bounds],Five_stages_all_active=True,Events_per_stage='one optional event; amount zero means no irrigation',Amounts='continuous mm',Dates='integer daily grid; zero-based internal day index, reported DAP=day_index+1',Original_dates_fixed=False,Additional_event_hardware_cap=False,Terminal_storage_floor=False,Source='Wang 2023 Table 2-3, printed p.11')
  sys.path.insert(0,str(PROJECT/'real_model'));import numerical_acceleration;numerical_acceleration.install()
  iw=self.m.InitialWaterContent(wc_type='Num',method='Depth',depth_layer=self.data['mid'].tolist(),value=self.data['theta'].tolist());template=self.m.make_model(self.data,self.params,copy.deepcopy(self.data['soil']),iw,'DI');template.off_season=True;template.fallow_field_management=self.m.field_management();template._initialize()
  assert np.allclose(template._init_cond.th,self.data['theta'],atol=1e-10,rtol=0)
  self.template=template;crop=template._param_struct.Seasonal_Crop_List[0];self.full_fco2=float(crop.fCO2);self.wp=[self.m.effective_wp(self.full_fco2,self.params[k]) for k in ['WP_early','WP_late']];self.late=np.array([d>=self.m.SWITCH for d in self.dates])
  p=self.data['soil'].profile;self.root_weights=np.clip(1-p.z_top.to_numpy(float),0,p.dz.to_numpy(float))*1000;self.initial_profile=float(self.data['theta'].sum()*100);self.initial_root=float(self.data['theta']@self.root_weights);self.rain=float(self.data['weather'].set_index('Date').loc[self.dates,'Precipitation'].sum())
  fm=template._param_struct.FieldMngt;self.settings=dict(MulchPct=float(fm.mulch_pct),fMulch=float(fm.f_mulch),Zmin=float(crop.Zmin),Zmax=float(crop.Zmax),WetSurf=float(template._param_struct.IrrMngt.WetSurf),AppEff=float(template._param_struct.IrrMngt.AppEff),Profile_depth_m=float(p.dz.sum()),Calendar_steps=self.n)
  assert self.settings['MulchPct']==75 and self.settings['fMulch']==0 and abs(self.settings['Zmax']-2.3)<1e-12
  self.step=importlib.import_module('aquacrop.timestep.run_single_timestep');self.core=importlib.import_module('aquacrop.core');self.active=False;self.prefix={};self.activate()
  try:
   m=copy.deepcopy(template);m._param_struct.IrrMngt.Schedule=np.zeros(len(m._clock_struct.time_span));self.prefix[0]=copy.deepcopy(m)
   for i in range(self.n):
    c=m._param_struct.Seasonal_Crop_List[0];c.WP,c.fCO2=self.wp[int(self.late[i])];m._clock_struct,m._init_cond,m._param_struct,m._outputs=m._perform_timestep();self.prefix[i+1]=copy.deepcopy(m)
   assert self.prefix[self.n]._clock_struct.model_is_finished
  finally:self.restore()
 def repair(self,X):
  X=np.asarray(X,float).copy();X[:,:5]=np.clip(X[:,:5],0,self.cap);s=X[:,:5].sum(axis=1);X[:,:5]*=np.minimum(1,self.cap/np.maximum(s,np.finfo(float).tiny))[:,None];X[:,5:]=np.clip(np.rint(X[:,5:]),self.day_low,self.day_high)
  X[:,5:]=np.where(X[:,:5]==0,self.day_low,X[:,5:]);return X
 def records(self,x):
  return dict(**{k:float(v) for k,v in zip(AMOUNTS,x[:5])},**{k:int(v) for k,v in zip(DAY_INDEXES,x[5:])},**{f'Stage{i+1}_Date':self.dates[int(x[5+i])].strftime('%Y-%m-%d') for i in range(5)})
 def expand(self,z):
  z=np.asarray(z,float);assert z.shape==(10,);return z
 def activate(self):
  assert not self.active;self.original_evap=self.step.soil_evaporation;self.original_stop=self.core.check_model_is_finished;self.step.soil_evaporation=self.adapter._evap_wrapper(self.original_evap);self.core.check_model_is_finished=lambda current_time,*args:bool(current_time>=self.m.HARVEST);self.active=True
 def restore(self):
  if self.active:self.step.soil_evaporation=self.original_evap;self.core.check_model_is_finished=self.original_stop;self.active=False
 def _run_schedule(self,amounts,indexes,use_prefix=True,details=False):
  assert self.active;amounts=np.asarray(amounts,float);indexes=np.asarray(indexes,int);positive=indexes[amounts>0];offset=int(positive.min()) if len(positive) else self.n
  if not use_prefix:offset=0
  m=copy.deepcopy(self.prefix[offset]);daily=np.zeros(len(m._clock_struct.time_span));np.add.at(daily,indexes,amounts);im=m._param_struct.IrrMngt;im.Schedule=daily;im.MaxIrr=float(daily.max()+.1);im.MaxIrrSeason=float(amounts.sum()+.1)
  storage=[self.initial_profile];surfaces=[float(self.template._init_cond.surface_storage)];root=[self.initial_root]
  if details:
   storage=[float(self.prefix[i]._init_cond.th.sum()*100) for i in range(offset+1)];surfaces=[float(self.prefix[i]._init_cond.surface_storage) for i in range(offset+1)];root=[float(self.prefix[i]._init_cond.th@self.root_weights) for i in range(offset+1)]
  for i in range(offset,self.n):
   c=m._param_struct.Seasonal_Crop_List[0];c.WP,c.fCO2=self.wp[int(self.late[i])];m._clock_struct,m._init_cond,m._param_struct,m._outputs=m._perform_timestep()
   if details:storage.append(float(m._init_cond.th.sum()*100));surfaces.append(float(m._init_cond.surface_storage));root.append(float(m._init_cond.th@self.root_weights))
  assert m._clock_struct.model_is_finished and len(m._outputs.final_stats)==1
  f=m._outputs.water_flux.iloc[:self.n].copy();g=m._outputs.crop_growth.iloc[:self.n].copy();last=m._outputs.final_stats.iloc[0];growing=int(last['Harvest Date (Step)'])+1;harvest=pd.Timestamp(last['Harvest Date (YYYY/MM/DD)']);send=float(m._init_cond.th.sum()*100);surf=float(m._init_cond.surface_storage);tr=float(f.Tr.sum());es=float(f.Es.sum());irr=float(f.IrrDay.sum());r=float(f.Runoff.sum());dp=float(f.DeepPerc.sum());cr=float(f.CR.sum());gw=float(f.GwIn.sum());td=float(f.TileDrain.sum())
  residual=self.rain+irr+cr+gw-tr-es-r-dp-td-send+self.initial_profile-surf+float(self.template._init_cond.surface_storage)
  assert abs(residual)<1e-5
  s=dict(Y_13pct=float(last['Dry yield (tonne/ha)'])/.87,Y_dry=float(last['Dry yield (tonne/ha)']),B_t_ha=float(g.iloc[growing-1].biomass/100),Irrigation_mm=irr,Planned_irrigation_mm=float(amounts.sum()),Cancelled_irrigation_mm=float(amounts.sum()-irr),ET_mm=tr+es,Tr_mm=tr,Es_mm=es,MaxCC=float(g.canopy_cover.max()),Rain_mm=self.rain,Profile_initial_mm=self.initial_profile,Profile_final_mm=send,Root1m_initial_mm=self.initial_root,Root1m_final_mm=float(m._init_cond.th@self.root_weights),Surface_final_mm=surf,Runoff_mm=r,DeepPerc_mm=dp,CR_mm=cr,GwIn_mm=gw,TileDrain_mm=td,Water_balance_residual_mm=residual,Max_actual_event_mm=float(f.IrrDay.max()),Harvest_date=str(harvest.date()),Growing_days=growing,Calendar_days=self.n,Early_termination=growing<self.n)
  if details:
   f['Date']=self.dates;g['Date']=self.dates;f['Profile_initial_of_day_mm']=storage[:-1];f['Profile_final_of_day_mm']=storage[1:];f['Root1m_final_of_day_mm']=root[1:];f['Precipitation']=self.data['weather'].set_index('Date').loc[self.dates,'Precipitation'].to_numpy(float)
   wb=f.Precipitation+f.IrrDay+f.CR+f.GwIn-f.Tr-f.Es-f.Runoff-f.DeepPerc-f.TileDrain-np.diff(storage)-np.diff(surfaces);s['Max_daily_balance_residual_mm']=float(abs(wb).max());assert s['Max_daily_balance_residual_mm']<1e-5
   return s,f,g
  return s
 def run(self,x,use_prefix=True,details=False):
  x=np.asarray(x,float);assert x.shape==(10,);days=x[5:].astype(int);assert np.array_equal(days,x[5:]) and np.all(days>=self.day_low) and np.all(days<=self.day_high) and np.all(x[:5]>=0)
  return self._run_schedule(x[:5],days,use_prefix,details)
 def original_baseline(self,details=False):
  schedule=self.data['schedule'];return self._run_schedule(schedule.Depth.to_numpy(float),self.dates.get_indexer(schedule.Date),True,details)
 def native_reference(self,x=None):
  assert not self.active;a=self.adapter;orig=self.data;oldspace=a.management_space
  if x is not None:
   data=dict(orig);data['schedule']=pd.DataFrame(dict(Date=[self.dates[int(i)] for i in x[5:]],Depth=x[:5]));a.STATES[self.year]=(self.m,data);a.management_space=lambda y:dict(event_stages=list(range(5)))
  a._template.cache_clear()
  try:return a.simulate(params=self.params,year=self.year,management=None,details=True,accelerate=True)
  finally:a.STATES[self.year]=(self.m,orig);a.management_space=oldspace;a._template.cache_clear()
