from pathlib import Path
import string,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from multi_event_engine import ROOT,STAGES
TB=ROOT/'tables';OUT=ROOT/'figures';YEARS=[2019,2020,2021,2022]
YEAR_COLORS=dict(zip(YEARS,['#0072B2','#D55E00','#009E73','#AA4499']))
STAGE_COLORS=['#8DA0CB','#0072B2','#E69F00','#009E73','#AA4499'];SHORT=['Seedling','Jointing','Heading','Grain filling','Maturity']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.8,'grid.alpha':.23,'grid.color':'#AEBCC3','pdf.fonttype':42,'svg.fonttype':'none'})
def read(n):return pd.read_csv(TB/n)
def save(fig,name):
 for ext in ['png','pdf','svg']:fig.savefig(OUT/(name+'.'+ext),dpi=450,bbox_inches='tight',facecolor='white')
 plt.close(fig)
def panel(ax,i,y):ax.set_title(f'({string.ascii_lowercase[i]}) {y}',loc='left',weight='bold',pad=7)
def grid(ax):ax.grid(True);ax.set_axisbelow(True)
def draw_front(ax,y,i,single=False):
 f=read('Full_range_Pareto_front.csv');s=f[f.Year==y].sort_values('Irrigation_mm');labels=read('Pareto_display_points.csv');labels=labels[labels.Year==y];summary=read('Four_year_result_comparison.csv').set_index('Year').loc[y]
 ax.plot(s.Irrigation_mm,s.Y_13pct,'--',c='#527DF4',lw=1.6,zorder=2)
 ax.scatter(labels.Irrigation_mm,labels.Y_13pct,s=22,c='#D33F35',edgecolors='white',lw=.5,zorder=4)
 for k,(_,r) in enumerate(labels.iterrows()):
  totals=[r[f'S{j}_actual_total_mm'] for j in range(1,6)];txt='('+', '.join(str(int(round(v))) for v in totals)+')';dx=7 if k<3 else -7;dy=-20 if k%2==0 else 12
  ax.annotate(txt,(r.Irrigation_mm,r.Y_13pct),xytext=(dx,dy),textcoords='offset points',ha='left' if dx>0 else 'right',va='center',fontsize=8 if single else 7.7,bbox=dict(boxstyle='round,pad=.15',fc='white',ec='#A9B6BD',lw=.45,alpha=.95))
 ax.scatter(summary.Original_I_mm,summary.Original_Y13,marker='*',s=95,c='#245568',zorder=5);ax.scatter(summary.Optimized_I_mm,summary.Optimized_Y13,marker='o',s=64,facecolor='white',edgecolor='#D55E00',lw=1.6,zorder=6)
 ax.axhline(summary.Yield_gate,c='#AE7772',ls=':',lw=1);ax.set_xlim(-summary.Original_I_mm*.025,summary.Original_I_mm*1.07);ax.set_ylim(0,20);panel(ax,i,str(y));grid(ax)
def pareto():
 fig,axs=plt.subplots(2,2,figsize=(9.4,6.2),layout='constrained',sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  draw_front(ax,y,i)
  if i%2==0:ax.set_ylabel('Grain yield at 13% moisture (t ha$^{-1}$)')
  if i>=2:ax.set_xlabel('Actual seasonal irrigation (mm)')
 handles=[Line2D([],[],ls='--',c='#527DF4',label='NSGA-III front'),Line2D([],[],marker='o',c='#D33F35',ls='',label='Evaluated solutions'),Line2D([],[],marker='*',c='#245568',ls='',label='Original DI model baseline'),Line2D([],[],marker='o',mfc='white',mec='#D55E00',ls='',label='Selected 95% yield solution'),Line2D([],[],ls=':',c='#AE7772',label='95% observed yield')]
 fig.legend(handles=handles,loc='outside upper center',ncol=3,frameon=False,fontsize=8.7);save(fig,'R03_Five_stage_multi_event_Pareto_4years_EN')
 for y in YEARS:
  fig,ax=plt.subplots(figsize=(6.6,4.6),layout='constrained');draw_front(ax,y,0,True);ax.set_xlabel('Actual seasonal irrigation (mm)');ax.set_ylabel('Grain yield at 13% moisture (t ha$^{-1}$)');ax.legend(handles=handles,loc='lower right',frameon=False,fontsize=8);save(fig,f'R03_Pareto_{y}_EN')
def old_new():
 old=read('Old_four_window_Full_range_best_found_front.csv');new=read('Full_range_Pareto_front.csv');summary=read('Four_year_result_comparison.csv').set_index('Year');fig,axs=plt.subplots(2,2,figsize=(8.3,5.3),layout='constrained',sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  a=old[old.Year==y].sort_values('Irrigation_mm');b=new[new.Year==y].sort_values('Irrigation_mm');ax.plot(a.Irrigation_mm,a.Y_13pct,c='#8F9FA6',ls='--',lw=1.3);ax.plot(b.Irrigation_mm,b.Y_13pct,c=YEAR_COLORS[y],lw=1.8);ax.scatter(summary.loc[y,'Original_I_mm'],summary.loc[y,'Original_Y13'],marker='*',s=75,c='#245568');ax.set_ylim(0,20);ax.set_xlim(-10,summary.loc[y,'Original_I_mm']*1.05);panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Grain yield (t ha$^{-1}$)')
  if i>=2:ax.set_xlabel('Actual seasonal irrigation (mm)')
 fig.legend(handles=[Line2D([],[],c='#8F9FA6',ls='--',label='Original four fixed-date windows'),Line2D([],[],c='#0072B2',label='Five-stage multiple-event amount/date search')],loc='outside upper center',ncol=1,frameon=False);save(fig,'R04_Four_window_vs_multi_event_fronts_EN')
def stage_totals():
 d=read('Five_stage_totals_and_event_counts.csv');fig,axs=plt.subplots(2,2,figsize=(8.3,5.2),layout='constrained',sharey=True);x=np.arange(5)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  a=d[(d.Year==y)&(d.Control_ID=='Original_DI')].set_index('Stage').loc[range(1,6)];b=d[(d.Year==y)&(d.Control_ID=='Selected_95pct')].set_index('Stage').loc[range(1,6)]
  ax.bar(x-.18,a.Actual_mm,width=.34,color='#CCD5D9',edgecolor='white',lw=.5);ax.bar(x+.18,b.Actual_mm,width=.34,color=YEAR_COLORS[y],edgecolor='white',lw=.5)
  for j,r in enumerate(b.itertuples()):ax.text(j+.18,r.Actual_mm+5,f'n={r.Positive_events}',ha='center',fontsize=8)
  ax.set_xticks(x,SHORT,rotation=22,ha='right');ax.grid(axis='y');ax.set_axisbelow(True);panel(ax,i,str(y))
  if i%2==0:ax.set_ylabel('Stage irrigation total (mm)')
 fig.legend(handles=[Patch(fc='#CCD5D9',label='Original DI schedule'),Patch(fc='#0072B2',label='Optimized schedule; n = positive-depth events')],loc='outside upper center',ncol=2,frameon=False);save(fig,'R05_Five_stage_totals_and_counts_EN')
def event_calendar():
 d=read('Optimized_every_irrigation_event.csv');summary=read('Four_year_result_comparison.csv').set_index('Year');bounds=read('Five_stage_schedule_bounds.csv');fig,axs=plt.subplots(2,2,figsize=(8.9,5.5),layout='constrained')
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y];r=summary.loc[y]
  for j in range(5):
   b=bounds[(bounds.Year==y)&(bounds.Stage==j+1)].iloc[0];ax.axvspan(pd.Timestamp(b.First_allowed_date),pd.Timestamp(b.Last_allowed_date),fc=STAGE_COLORS[j],alpha=.055,zorder=0);v=s[s.Stage==j+1];ax.bar(pd.to_datetime(v.Date),v.Actual_mm,width=1.1,color=STAGE_COLORS[j],edgecolor='white',lw=.3,zorder=3)
  ymax=max(s.Actual_mm.max()*1.25,20);ax.set_ylim(0,ymax);ax.text(.03,.96,f'I = {r.Optimized_I_mm:.2f} mm; Y = {r.Optimized_Y13:.3f} t ha$^{{-1}}$\n{int(r.Positive_events)} positive-depth events',transform=ax.transAxes,va='top',fontsize=8.5);ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));ax.grid(axis='y');ax.set_axisbelow(True);panel(ax,i,str(y))
  if i%2==0:ax.set_ylabel('Individual irrigation depth (mm)')
 fig.legend(handles=[Patch(fc=c,label=t) for c,t in zip(STAGE_COLORS,SHORT)],loc='outside upper center',ncol=5,frameon=False,fontsize=8.5);save(fig,'R06_Optimized_event_calendar_EN')
def annual_comparison():
 d=read('Four_year_result_comparison.csv');fig,(ax,bx)=plt.subplots(1,2,figsize=(8.7,3.5),layout='constrained');x=np.arange(4)
 ax.bar(x-.24,d.Original_I_mm,width=.23,color='#CCD5D9',label='Original DI');ax.bar(x,d.Old_four_window_I_mm,width=.23,color='#9BAFB8',hatch='///',label='Four fixed-date windows');ax.bar(x+.24,d.Optimized_I_mm,width=.23,color=[YEAR_COLORS[y] for y in YEARS],label='Five-stage multiple events')
 for j,r in d.iterrows():ax.text(j+.24,r.Optimized_I_mm+8,f'{r.I_reduction_pct:.1f}%',ha='center',fontsize=8.4)
 ax.set_xticks(x,YEARS);ax.set_ylabel('Actual seasonal irrigation (mm)');ax.set_ylim(0,max(d.Original_I_mm)*1.18);ax.grid(axis='y');ax.set_axisbelow(True);ax.legend(frameon=False,fontsize=8.1,loc='upper left')
 for j,r in d.iterrows():
  bx.plot([j-.24,j-.08],[r.Observed_Y13]*2,c='#263F4A',lw=2);bx.scatter(j,r.Original_Y13,c='#9BAFB8',s=38,marker='D');bx.scatter(j+.18,r.Optimized_Y13,c=YEAR_COLORS[int(r.Year)],s=40);bx.plot([j-.3,j+.3],[r.Yield_gate]*2,c='#AD7772',ls=':',lw=1)
 bx.set_xticks(x,YEARS);bx.set_ylabel('Grain yield (t ha$^{-1}$)');bx.grid(axis='y');bx.legend(handles=[Line2D([],[],c='#263F4A',lw=2,label='Observed DI yield'),Line2D([],[],marker='D',ls='',c='#9BAFB8',label='DI model baseline'),Line2D([],[],marker='o',ls='',c='#0072B2',label='Selected optimized yield'),Line2D([],[],c='#AD7772',ls=':',label='95% observed yield')],frameon=False,fontsize=8.2,loc='lower left');save(fig,'R07_Annual_irrigation_and_yield_EN')
def soil_storage():
 fig,axs=plt.subplots(2,2,figsize=(8.3,5.1),layout='constrained',sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  for tag,color,ls in [('Original_DI','#9BAFB8','--'),('Selected_95pct',YEAR_COLORS[y],'-')]:
   d=read(f'{y}_{tag}_daily_water.csv');ax.plot(pd.to_datetime(d.Date),d.Profile_final_of_day_mm,c=color,ls=ls,lw=1.5)
  ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Soil water storage, 0–2.4 m (mm)')
 fig.legend(handles=[Line2D([],[],c='#9BAFB8',ls='--',label='Original DI schedule'),Line2D([],[],c='#0072B2',label='Selected optimized schedule')],loc='outside upper center',ncol=2,frameon=False);save(fig,'R08_Daily_profile_storage_EN')
def balance():
 d=read('Four_year_result_comparison.csv');fig,ax=plt.subplots(figsize=(7.5,3.4),layout='constrained');x=np.arange(4);pos=np.zeros(4);neg=np.zeros(4)
 for col,label,color,hatch in [('ET_reduction_mm','Lower evapotranspiration','#E69F00',''),('Lower_final_storage_mm','Lower end-of-season storage','#56A0B9','///'),('Other_loss_reduction_mm','Lower other losses','#899A86','')]:
  vals=d[col].to_numpy();bottom=np.where(vals>=0,pos,neg);ax.bar(x,vals,bottom=bottom,width=.55,color=color,hatch=hatch,label=label,edgecolor='white',lw=.6);pos+=np.maximum(vals,0);neg+=np.minimum(vals,0)
 for j,r in d.iterrows():ax.text(j,pos[j]+7,f'{r.Storage_difference_share_pct:.1f}%',ha='center',fontsize=9)
 ax.axhline(0,c='#869BA5',lw=.7);ax.set_xticks(x,YEARS);ax.set_ylabel('Irrigation reduction components (mm)');ax.set_ylim(min(0,neg.min()*1.2),pos.max()*1.23);ax.grid(axis='y');ax.set_axisbelow(True);ax.legend(frameon=False,loc='upper left',fontsize=8.5);save(fig,'R09_Water_balance_decomposition_EN')
def convergence():
 d=read('Generation_history.csv');d=d[d.Scope=='formal'];fig,axs=plt.subplots(2,2,figsize=(8.2,5.1),layout='constrained')
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  for algo,color,label in [('NSGA3','#0072B2','NSGA-III'),('NSGA2','#D55E00','NSGA-II')]:
   s=d[(d.Year==y)&(d.Algorithm==algo)].groupby('Generation').Hypervolume.agg(['mean','min','max']);ax.plot(s.index,s['mean'],c=color,lw=1.4,label=label);ax.fill_between(s.index,s['min'],s['max'],color=color,alpha=.12,lw=0)
  ax.set_xlim(1,100);panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Normalized population hypervolume')
  if i>=2:ax.set_xlabel('Generation')
 handles,labels=axs.flat[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=2,frameon=False);save(fig,'R10_Algorithm_convergence_EN')
def main():
 OUT.mkdir(exist_ok=True)
 for f in [pareto,old_new,stage_totals,event_calendar,annual_comparison,soil_storage,balance,convergence]:f();print(f.__name__,flush=True)
if __name__=='__main__':main()
