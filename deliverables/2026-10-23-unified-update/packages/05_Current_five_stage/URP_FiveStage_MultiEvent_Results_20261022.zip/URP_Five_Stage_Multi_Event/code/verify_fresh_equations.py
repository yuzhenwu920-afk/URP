"""Fresh-process checks against unaccelerated original daily equations."""
import os,json,importlib.util,multiprocessing
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
for v in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[v]='1'
import pandas as pd
import numpy as np
from multi_event_engine import ROOT,PROJECT,STAGE_DATES,dump
def year_check(year):
 adapter=PROJECT/'real_model/four_year_adapter.py';sp=importlib.util.spec_from_file_location(f'fresh_reference_{year}',adapter);a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a);m,data=a._load(year);rows=[]
 for tag in ['Original_DI','Selected_95pct','Maximum_yield']:
  record=json.loads((ROOT/f'verification/{year}_{tag}_complete_replay.json').read_text());events=record['Events'];schedule=pd.DataFrame(dict(Date=pd.to_datetime([r['Date'] for r in events]),Depth=[r['Planned_mm'] for r in events])).groupby('Date',as_index=False).Depth.sum().sort_values('Date')
  patched=dict(data);patched['schedule']=schedule;stages=[]
  for date in schedule.Date:
   md=date.strftime('%m-%d');stages.append(next(j for j,(lo,hi) in enumerate(STAGE_DATES[year]) if lo<=md<=hi))
  a.STATES[year]=(m,patched);a.management_space=lambda yy:dict(event_stages=stages);a._template.cache_clear();response,w,g=a.simulate(params=record['Parameters'],year=year,management=None,details=True,accelerate=False)
  keys=['Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','B_t_ha','MaxCC','Profile_final_mm'];err=max(abs(response[k]-record['Summary'][k]) for k in keys);assert err<1e-8,(year,tag,err);rows.append(dict(Year=year,Control_ID=tag,Maximum_unaccelerated_difference=err,Water_balance_residual_mm=response['Water_balance_residual_mm']))
 return rows
def main():
 with ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn')) as pool:rows=[r for block in pool.map(year_check,range(2019,2023)) for r in block]
 dump(ROOT/'verification/FRESH_UNACCELERATED_CHECK.json',dict(Status='PASS',Fresh_processes=4,Forward_queries=len(rows),Accelerated_wrappers_installed=False,Checks=rows));print('Fresh original-equation checks passed',len(rows),'max difference',max(r['Maximum_unaccelerated_difference'] for r in rows))
if __name__=='__main__':main()
