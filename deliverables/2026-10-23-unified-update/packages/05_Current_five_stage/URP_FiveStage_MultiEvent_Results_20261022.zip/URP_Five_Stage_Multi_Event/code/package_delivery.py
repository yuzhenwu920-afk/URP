"""Package verified outputs; never modifies the model or evaluated controls."""
from pathlib import Path
import hashlib, json, shutil, zipfile
from multi_event_engine import ROOT

def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def usable(p):
    return p.is_file() and '__pycache__' not in p.parts and 'lo_profile' not in p.parts and not p.name.startswith('.~lock.') and not p.name.endswith(('.tmp', '.pyc'))

def archive(target, files):
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
        for p in sorted(set(files)):
            z.write(p, 'URP_Five_Stage_Multi_Event/' + str(p.relative_to(ROOT)))
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
    assert target.stat().st_size < 100_000_000, (target.name, target.stat().st_size)
    return dict(File=target.name, Bytes=target.stat().st_size, SHA256=digest(target), ZIP_CRC='PASS')

def main():
    check = json.loads((ROOT/'verification/FINAL_DELIVERY_CHECK.json').read_text())
    assert check['Status'] == 'PASS'
    out = ROOT/'delivery'; out.mkdir(exist_ok=True)
    dirs = ['code', 'documents', 'figures', 'tables', 'source', 'verification']
    source_files = [p for folder in dirs for p in (ROOT/folder).rglob('*') if usable(p)]
    # Generated input-audit text is retained; Python/Numba caches are excluded.
    source_files = [p for p in source_files if not p.name.endswith(('.nbc', '.nbi'))]
    source_files += [ROOT/'README.md', ROOT/'requirements.txt', ROOT/'FIGURE_GUIDE.md']
    manifest = [dict(Path=str(p.relative_to(ROOT)), Bytes=p.stat().st_size, SHA256=digest(p)) for p in sorted(source_files)]
    (ROOT/'FILE_MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    source_files += [ROOT/'FILE_MANIFEST.json']
    records = [archive(out/'URP_FiveStage_MultiEvent_Results_20261022.zip', source_files)]
    figures = [p for p in (ROOT/'figures').iterdir() if usable(p)]
    figures += [ROOT/'FIGURE_GUIDE.md', ROOT/'tables/Full_range_Pareto_front.csv', ROOT/'tables/Pareto_display_points.csv', ROOT/'tables/Optimized_every_irrigation_event.csv', ROOT/'tables/Five_stage_totals_and_event_counts.csv', ROOT/'tables/Four_year_result_comparison.csv', ROOT/'tables/Pareto_every_irrigation_event.csv.gz']
    records.append(archive(out/'URP_FiveStage_MultiEvent_Figures_20261022.zip', figures))
    for year in range(2019, 2023):
        files = [p for p in (ROOT/f'runs/{year}').rglob('*') if usable(p)]
        files += [ROOT/'README.md', ROOT/'requirements.txt', ROOT/f'source/decision_space_{year}.json', ROOT/f'source/fixed_identity_{year}.json', ROOT/f'verification/year_{year}_COMPLETE.json', ROOT/'verification/INITIAL_BUDGET_RECOVERY.json', ROOT/'verification/RUN_STATUS.json', ROOT/'verification/FINAL_DELIVERY_CHECK.json']
        records.append(archive(out/f'URP_FiveStage_MultiEvent_RawRuns_{year}_20261022.zip', files))
    for p in (ROOT/'documents').iterdir():
        if p.suffix in ['.docx', '.pdf']:
            shutil.copy2(p, out/p.name)
    p = ROOT/'tables/URP_Five_Stage_Multi_Event_Results_20261022.xlsx'
    shutil.copy2(p, out/p.name)
    for name in ['Optimized_every_irrigation_event.csv','Five_stage_totals_and_event_counts.csv','Four_year_result_comparison.csv']:
        shutil.copy2(ROOT/'tables'/name,out/name)
    shutil.copy2(ROOT/'figures/R03_Five_stage_multi_event_Pareto_4years_EN.png', out/'R03_Five_stage_multi_event_Pareto_4years_EN.png')
    shutil.copy2(ROOT/'README.md', out/'README.md')
    shutil.copy2(ROOT/'FIGURE_GUIDE.md', out/'FIGURE_GUIDE.md')
    shutil.copy2(ROOT/'verification/FINAL_DELIVERY_CHECK.json', out/'VERIFICATION.json')
    (out/'ZIP_MANIFEST.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))
    hashes = '\n'.join(f'{digest(p)}  {p.name}' for p in sorted(out.iterdir()) if usable(p) and p.name != 'SHA256SUMS.txt')+'\n'
    (out/'SHA256SUMS.txt').write_text(hashes)
    print(json.dumps(records, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
