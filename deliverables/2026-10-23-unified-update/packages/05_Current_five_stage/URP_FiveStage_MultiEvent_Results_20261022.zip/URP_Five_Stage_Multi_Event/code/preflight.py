from pathlib import Path
import json,time,importlib.metadata
import numpy as np
import pandas as pd
from multi_event_engine import ROOT,PROJECT,MultiEventEngine,STAGES,OBS,N_EVENTS,CONTROL_NAMES,dump,sha
def main():
 checks=[];rows=[];anchor_rows=[];snap=[];queries=0
 old=pd.read_csv(ROOT/'source/four_window_reference/Original_main_NSGA_main_candidates.csv').set_index('Year')
 for year in range(2019,2023):
  e=MultiEventEngine(year);rng=np.random.default_rng(year+163);dump(ROOT/f'source/decision_space_{year}.json',e.space);dump(ROOT/f'source/fixed_identity_{year}.json',dict(Parameters=e.params,Settings=e.settings,Original_schedule=e.data['schedule'].assign(Date=e.data['schedule'].Date.dt.strftime('%Y-%m-%d')).to_dict('records')))
  for j,name in enumerate(STAGES):rows.append(dict(Year=year,Stage=j+1,Stage_name=name,First_allowed_date=e.space['Executed_date_windows'][j][0],Last_allowed_date=e.space['Executed_date_windows'][j][1],Maximum_events=3,All_stages_eligible=True,Amount_bounds=f'0–{e.cap:.2f} mm, subject to seasonal sum',Date_grid='integer day'))
  X=[e.zero,e.base,e.old_anchor]
  for k in range(4):
   z=np.r_[rng.dirichlet(np.ones(N_EVENTS))*rng.uniform(0,e.cap),[rng.integers(a,b+1) for a,b in zip(e.slot_low,e.slot_high)]];X.append(e.repair(z[None,:])[0])
  # Explicit coincident-date case verifies summation rather than overwriting.
  collision=e.base.copy();collision[:3]=[10,20,30];collision[N_EVENTS:N_EVENTS+3]=e.day_low[0];collision=e.repair(collision[None,:])[0];X.append(collision)
  refs=[e.native_reference(x)[0] for x in X];queries+=len(X);original_native=e.native_reference()[0];queries+=1;e.activate()
  try:
   fast=[e.run(x) for x in X];queries+=len(X);fresh=[e.run(x,use_prefix=False) for x in X];queries+=len(X);orig=e.original_baseline();queries+=1
   keys=['Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','B_t_ha','MaxCC','Profile_final_mm','Water_balance_residual_mm'];err=max(abs(a[k]-b[k]) for a,b in zip(refs,fast) for k in keys);prefixerr=max(abs(a[k]-b[k]) for a,b in zip(fresh,fast) for k in keys);origerr=max(abs(orig[k]-original_native[k]) for k in keys)
   assert max(err,prefixerr,origerr)<1e-8,(year,err,prefixerr,origerr)
   assert abs(fast[1]['Y_13pct']-original_native['Y_13pct'])<1e-8 and abs(fast[2]['Y_13pct']-old.loc[year,'Y13'])<1e-8
   assert abs(fast[2]['Irrigation_mm']-old.loc[year,'Irrigation_mm'])<1e-8
   for x in X:
    events=e.schedule_rows(x)
    assert abs(sum(t['Planned_mm'] for t in events)-x[:N_EVENTS].sum())<1e-8
    for j in range(5):
     s=[t for t in events if t['Stage']==j+1 and t['Planned_mm']>0];assert len(s)<=3 and len(set(t['Date'] for t in s))==len(s)
   for i,(x,s) in enumerate(zip(X,fast)):anchor_rows.append(dict(Year=year,Anchor=i,**e.records(x),**s))
   t=time.monotonic()
   for _ in range(20):
    x=e.repair(np.r_[rng.dirichlet(np.ones(N_EVENTS))*rng.uniform(0,e.cap),[rng.integers(a,b+1) for a,b in zip(e.slot_low,e.slot_high)]][None,:])[0];e.run(x)
   queries+=20;checks.append(dict(Year=year,Control_vectors=len(X),Max_native_difference=err,Max_prefix_difference=prefixerr,Original_baseline_difference=origerr,Previous_four_window_anchor_reproduced=True,Seconds_per_20=time.monotonic()-t,Decision_dimension=30))
  finally:e.restore()
  del e
 for p in sorted(PROJECT.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:snap.append(dict(Path=str(p.relative_to(ROOT)),Bytes=p.stat().st_size,SHA256=sha(p)))
 pd.DataFrame(snap).to_csv(ROOT/'verification/FROZEN_SOURCE_MANIFEST.csv',index=False);pd.DataFrame(rows).to_csv(ROOT/'tables/Five_stage_schedule_bounds.csv',index=False,encoding='utf-8-sig');pd.DataFrame(anchor_rows).to_csv(ROOT/'tables/Preflight_anchor_responses.csv',index=False)
 out=dict(Status='PASS',Checks=checks,Preflight_forward_queries=queries,Prefix_initializations=4,Decision_dimension=30,Maximum_events_per_stage=3,Maximum_events_per_season=15,User_frequency_choice='explicitly selected: at most three events per stage with zero-depth cancellation',Original_DI_and_previous_candidate_reproduced=True,Old_results_used_only_as_disclosed_anchors=True,Versions={n:importlib.metadata.version(n) for n in ['aquacrop','numpy','pandas','pymoo','numba']});dump(ROOT/'verification/PREFLIGHT.json',out);print(json.dumps(out,indent=2))
if __name__=='__main__':main()
