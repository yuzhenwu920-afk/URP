from pathlib import Path
import json
import numpy as np
import pandas as pd
from pymoo.indicators.hv import HV
from multi_event_engine import ROOT,PROJECT,MultiEventEngine,OBS,STAGES,N_EVENTS,CONTROL_NAMES,AMOUNT_NAMES,DAY_NAMES,dump,sha
from run_optimization import nd
def save(d,n):d.to_csv(ROOT/'tables'/n,index=False,encoding='utf-8-sig')
def main():
 status=json.loads((ROOT/'verification/RUN_STATUS.json').read_text());assert status['Status']=='COMPLETE'
 finals=[];formal_archives=[];fulls=[];hist=[];summaries=[];mains=[];comparisons=[];algos=[];allquerymin=[];slots=[];stage_rows=[];label_rows=[];doses=[];checks=[];ledger=[];pareto_events=[];replay_calls=0
 old=pd.read_csv(ROOT/'source/four_window_reference/Original_main_NSGA_main_candidates.csv').set_index('Year')
 for year in range(2019,2023):
  e=MultiEventEngine(year);formal=[];archive=[];full=[]
  for folder in sorted((ROOT/f'runs/{year}').glob('*/*')):
   state=json.loads((folder/'run.json').read_text());assert state['Status']=='COMPLETE'
   summary={k:state[k] for k in ['Objective_queries','Actual_model_calls','Exact_cache_hits','Seconds']};summary.update(Year=year,Algorithm=state['Identity']['Algorithm'],Seed=state['Identity']['Seed'],Scope=state['Identity']['Scope'],Population=state['Identity']['Population'],Generations=state['Identity']['Generations']);summaries.append(summary)
   assert summary['Population']*summary['Generations']-summary['Population']<summary['Objective_queries']<=summary['Population']*summary['Generations']
   a=pd.read_csv(folder/'all_evaluated_front.csv',float_precision='round_trip');h=pd.read_csv(folder/'history.csv');hist.append(h)
   # Use the same final-population definition for every search. NSGA-III's
   # reported reference representatives can be a subset of this population.
   with np.load(folder/f'generation_{summary["Generations"]:04d}.npz') as z:
    f=pd.DataFrame(z['X_encoded'],columns=CONTROL_NAMES);f['Y_13pct']=-z['F'][:,0];f['Irrigation_mm']=z['F'][:,1];f['Year']=year;f['Algorithm']=summary['Algorithm'];f['Seed']=summary['Seed'];f=nd(f[z['CV']<=0])
   if summary['Scope']=='formal':formal.append(f);archive.append(a)
   else:full.append(a)
  f=pd.concat(formal,ignore_index=True);a=pd.concat(archive,ignore_index=True);fr=nd(pd.concat(full,ignore_index=True));fr['Control_ID']=[f'{year}_Full_{i+1:05d}' for i in range(len(fr))]
  for i,key in enumerate(DAY_NAMES):
   fr[key.replace('_day_index','_Date')]=[e.dates[int(v)].strftime('%Y-%m-%d') if mm>0 else '' for v,mm in zip(fr[key],fr[AMOUNT_NAMES[i]])]
  for _,r in fr.iterrows():
   x=r[CONTROL_NAMES].to_numpy(float)
   actual_events=e.schedule_rows(x,dict(Harvest_date=r.Harvest_date),r.Control_ID)
   for stage in range(1,6):
    stage_events=[ev for ev in actual_events if ev['Stage']==stage]
    fr.loc[r.name,f'S{stage}_actual_total_mm']=sum(ev['Actual_mm'] for ev in stage_events)
    fr.loc[r.name,f'S{stage}_actual_events']=sum(ev['Actual_mm']>0 for ev in stage_events)
   assert abs(sum(ev['Actual_mm'] for ev in actual_events)-r.Irrigation_mm)<1e-7,(year,r.Control_ID,'stage actual totals')
   for event in actual_events:
    if event['Actual_mm']>0:pareto_events.append(event)
  finals.append(f);formal_archives.append(a);fulls.append(fr)
  for algo,g in f.groupby('Algorithm'):
   q=nd(g);algos.append(dict(Year=year,Algorithm=algo,Scope='formal final-population union',Front_size=len(q),Normalized_union_HV=float(HV(ref_point=np.array([0,1.01]))(np.c_[-q.Y_13pct/OBS[year],q.Irrigation_mm/e.cap])),Minimum_I_mm=float(q.Irrigation_mm.min()),Maximum_Y13=float(q.Y_13pct.max())))
  q=nd(f[f.Algorithm=='NSGA3']);main=q.iloc[0].to_dict();main['Selection']='minimum irrigation in five-seed formal NSGA-III final-population union';mains.append(main)
  for algo,g in a.groupby('Algorithm'):
   v=nd(g).iloc[0].to_dict();v['Selection']='minimum among all formal queries of this algorithm';allquerymin.append(v)
  labelled=fr.iloc[np.unique([np.argmin(abs(fr.Irrigation_mm.to_numpy()-v)) for v in np.linspace(fr.Irrigation_mm.min(),fr.Irrigation_mm.max(),6)])].copy();label_rows.append(labelled)
  main_x=np.array([main[k] for k in CONTROL_NAMES]);max_x=np.array([q.iloc[q.Y_13pct.to_numpy().argmax()][k] for k in CONTROL_NAMES])
  controls=[('Original_DI',e.base),('Selected_95pct',main_x),('Maximum_yield',max_x)]
  for j,r in labelled.iterrows():controls.append((f'Front_label_{j}',r[CONTROL_NAMES].to_numpy(float)))
  for fraction in np.linspace(0,1,21):
   x=e.base.copy();x[:N_EVENTS]*=fraction;controls.append((f'Proportion_{fraction:.2f}',x))
  for tag,x in controls:
   native,w,g=e.native_reference(x);replay_calls+=1;e.activate()
   try:fast,water,growth=e.run(x,details=True);replay_calls+=1
   finally:e.restore()
   keys=['Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','B_t_ha','MaxCC','Profile_final_mm'];error=max(abs(native[k]-fast[k]) for k in keys);assert error<1e-8,(year,tag,error)
   checks.append(dict(Year=year,Control_ID=tag,Maximum_native_difference=error,Seasonal_balance_residual_mm=fast['Water_balance_residual_mm'],Daily_balance_max_mm=fast['Max_daily_balance_residual_mm']))
   if tag.startswith('Proportion_'):doses.append(dict(Year=year,Baseline_fraction=float(tag.split('_')[1]),**e.records(x),**fast))
   if tag in ['Original_DI','Selected_95pct','Maximum_yield']:
    for t in e.schedule_rows(x,fast,tag):slots.append(t)
    if tag in ['Original_DI','Selected_95pct']:
     water.to_csv(ROOT/f'tables/{year}_{tag}_daily_water.csv',index=False);growth.to_csv(ROOT/f'tables/{year}_{tag}_daily_growth.csv',index=False)
     ledger.append(dict(Year=year,Scenario=tag,**fast))
    dump(ROOT/f'verification/{year}_{tag}_complete_replay.json',dict(Year=year,Control_ID=tag,Parameters=e.params,Settings=e.settings,Encoded_controls=x.tolist(),Summary=fast,Events=e.schedule_rows(x,fast,tag)))
  base=[r for r in ledger if r['Year']==year and r['Scenario']=='Original_DI'][0];opt=[r for r in ledger if r['Year']==year and r['Scenario']=='Selected_95pct'][0]
  selected=[r for r in slots if r['Year']==year and r['Control_ID']=='Selected_95pct'];positive=sorted([r for r in selected if r['Actual_mm']>0],key=lambda r:r['Date']);intervals=[(pd.Timestamp(b['Date'])-pd.Timestamp(a['Date'])).days for a,b in zip(positive[:-1],positive[1:])]
  deltaI=e.cap-opt['Irrigation_mm'];deltaET=base['ET_mm']-opt['ET_mm'];deltaS=base['Profile_final_mm']-opt['Profile_final_mm'];deltaL=(base['Runoff_mm']+base['DeepPerc_mm']+base['TileDrain_mm'])-(opt['Runoff_mm']+opt['DeepPerc_mm']+opt['TileDrain_mm']);assert abs(deltaI-deltaET-deltaS-deltaL)<1e-7
  comparisons.append(dict(Year=year,Observed_Y13=OBS[year],Yield_gate=.95*OBS[year],Original_I_mm=e.cap,Original_Y13=base['Y_13pct'],Old_four_window_I_mm=float(old.loc[year,'Irrigation_mm']),Old_four_window_Y13=float(old.loc[year,'Y13']),Optimized_I_mm=opt['Irrigation_mm'],Optimized_Y13=opt['Y_13pct'],New_minus_old_I_mm=opt['Irrigation_mm']-float(old.loc[year,'Irrigation_mm']),I_reduction_mm=deltaI,I_reduction_pct=100*deltaI/e.cap,Yield_RE_vs_observed_pct=100*(opt['Y_13pct']/OBS[year]-1),Yield_RE_vs_model_pct=100*(opt['Y_13pct']/base['Y_13pct']-1),Original_ET_mm=base['ET_mm'],Optimized_ET_mm=opt['ET_mm'],ET_reduction_mm=deltaET,ET_reduction_pct=100*deltaET/base['ET_mm'],Initial_profile_mm=base['Profile_initial_mm'],Original_final_profile_mm=base['Profile_final_mm'],Optimized_final_profile_mm=opt['Profile_final_mm'],Lower_final_storage_mm=deltaS,Other_loss_reduction_mm=deltaL,Storage_difference_share_pct=100*deltaS/deltaI,Positive_events=len(positive),Events_ge_0p1mm=sum(r['Actual_mm']>=.1 for r in selected),Max_event_mm=opt['Max_actual_event_mm'],Minimum_positive_event_gap_days=min(intervals) if intervals else None))
  del e
 event_table=pd.DataFrame(slots);stage_table=event_table.groupby(['Year','Control_ID','Stage','Stage_name'],as_index=False).agg(Planned_mm=('Planned_mm','sum'),Actual_mm=('Actual_mm','sum'),Positive_events=('Actual_mm',lambda v:int((v>0).sum())),Events_ge_0p1mm=('Actual_mm',lambda v:int((v>=.1).sum())))
 pd.DataFrame(pareto_events).to_csv(ROOT/'tables/Pareto_every_irrigation_event.csv.gz',index=False,compression='gzip')
 for row in comparisons:
  y=row['Year'];s=stage_table[(stage_table.Year==y)&(stage_table.Control_ID=='Selected_95pct')];assert len(s)==5 and abs(s.Actual_mm.sum()-row['Optimized_I_mm'])<1e-7
  assert (s.Positive_events<=3).all()
 save(pd.DataFrame(summaries),'Search_run_summary.csv');save(pd.concat(hist,ignore_index=True),'Generation_history.csv');save(pd.concat(finals,ignore_index=True),'Formal_final_population_fronts.csv');save(pd.concat(formal_archives,ignore_index=True),'Formal_all_evaluated_fronts.csv');save(pd.concat(fulls,ignore_index=True),'Full_range_Pareto_front.csv');save(pd.DataFrame(mains),'Selected_95pct_candidates.csv');save(pd.DataFrame(algos),'Algorithm_comparison.csv');save(pd.DataFrame(allquerymin),'Formal_all_query_archive_minima.csv');save(pd.concat(label_rows,ignore_index=True),'Pareto_display_points.csv');save(pd.DataFrame(doses),'Fixed_proportion_dose_response.csv');save(pd.DataFrame(checks),'Selected_full_adapter_replay_checks.csv');save(pd.DataFrame(ledger),'Baseline_and_selected_water_ledger.csv');save(pd.DataFrame(comparisons),'Four_year_result_comparison.csv');save(event_table,'All_selected_schedule_slots.csv');save(event_table[(event_table.Control_ID=='Selected_95pct')&(event_table.Actual_mm>0)].sort_values(['Year','Date']),'Optimized_every_irrigation_event.csv');save(stage_table,'Five_stage_totals_and_event_counts.csv')
 for p in ['Original_main_NSGA_main_candidates.csv','Full_range_best_found_front.csv','NSGA_algorithm_comparison.csv']:
  save(pd.read_csv(ROOT/'source/four_window_reference'/p),'Old_four_window_'+p)
 result=dict(Status='COMPLETE',Objective_queries=status['Total_objective_queries'],Actual_search_model_calls=status['Actual_search_model_calls'],Setup_forward_queries=32,Preflight_forward_queries=184,Postprocessing_replay_forward_queries=replay_calls,Prefix_initializations=dict(preflight=4,optimization_initial=4,optimization_continuation=4,postprocessing=4),Primary_selection='minimum irrigation among feasible nondominated final-population solutions in the five formal NSGA-III searches',Nominal_vs_actual_budget='Four first seeds retained 9999 queries after canonical duplicate elimination; every first seed still completed 100 generations. All subsequent seeds fill to 100 unique initial controls. Actual counts are reported without padding.',Schedule_scope='Five stages, maximum three optional distinct dates each; 15 continuous depths and 15 integer dates',Warm_start='Original schedule and old four-window feasible schedule are explicit seeds; results are not an independent solver test',Maximum_full_adapter_difference=max(r['Maximum_native_difference'] for r in checks),Maximum_daily_balance_residual_mm=max(r['Daily_balance_max_mm'] for r in checks),Candidates=comparisons)
 dump(ROOT/'verification/RESULT_SUMMARY.json',result);print(pd.DataFrame(comparisons).to_string(index=False));print('Aggregation and full replays complete')
if __name__=='__main__':main()
