from pathlib import Path
import json,time,datetime
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def snapshot():
 q=c=0;years=[]
 for p in (ROOT/'runs').glob('*/*/*/history.csv'):
  try:
   d=pd.read_csv(p);q+=int(d.Evaluations.iloc[-1]);c+=int(d.Actual_model_calls.iloc[-1])
  except (pd.errors.EmptyDataError,IndexError):pass
 for p in sorted((ROOT/'verification').glob('progress_*.json')):
  try:
   d=json.loads(p.read_text());years.append({k:d[k] for k in ['Year','Status','Scope','Algorithm','Seed','Generation','Evaluations','Completed_searches'] if k in d})
  except json.JSONDecodeError:pass
 state=json.loads((ROOT/'verification/RUN_STATUS.json').read_text())
 return dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),Status=state['Status'],Objective_queries=q,Actual_search_calls=c,Completed_searches=len(list((ROOT/'runs').rglob('COMPLETE.json'))),Years=years)
if __name__=='__main__':
 while True:
  d=snapshot();print(json.dumps(d),flush=True)
  with (ROOT/'verification/monitor.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
  if d['Status']=='COMPLETE':break
  time.sleep(45)
