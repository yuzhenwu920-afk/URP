# -*- coding: utf-8 -*-
"""阶段 C: NSGA-III "三代" 多目标遗传优化 -- 稳健灌溉制度优化.

设计要点 (相对传统灌溉优化的三点推进)
-------------------------------------
1) 决策变量 = 灌水安排, 不是作物参数.
   作物参数已由 MCMC 校准锁定(阶段 A), 再当决策变量等于"用优化掩盖参数不确定性".
   因此: 变量 = 8 次灌水的灌水量 x_i ∈ [0, 120] mm, 灌水日期沿用各年实际日期.

2) 参数不确定性显式进入目标函数 -- 稳健多目标优化.
   每个候选解用 K 个 MCMC 后验样本评估:
       f1 = -mean(Y13)     最大化期望产量
       f2 =  mean(Irr)     最小化期望灌溉量
       f3 =  std(Y13)      最小化参数不确定性导致的产量波动 (稳健性)
   传统优化只报一个确定解; 这里第三目标直接把"参数没标定准"的风险量化进 Pareto 前沿.

3) NSGA-III (第三代非支配排序遗传算法) + Das-Dennis 参考点.
   三目标已属 many-objective, NSGA-II 的非支配排序会退化, NSGA-III 用参考点维持前沿分布.

产出: pareto_front.csv, pareto_solutions.csv, 最优灌溉时间表, 节水率, 3 张图.
在 PyCharm 中把 aquacrop_surrogate.simulate 换成真实 model.simulate 即为真值.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

from pymoo.core.problem import Problem
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.optimize import minimize
from pymoo.termination import get_termination

try:
    from pymoo.util.ref_dirs import get_reference_directions
except ImportError:                       # pymoo < 0.6
    from pymoo.factory import get_reference_directions

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aquacrop_surrogate as A

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DengXian", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

OUT = Path(__file__).resolve().parent / "output"
CACHE = OUT / "raw_npz_cache"
YEARS = [2019, 2020, 2021, 2022]
PARAM_NAMES = A.PARAM_NAMES

N_IRR = 8                     # 灌水次数
X_MAX = 120.0                 # 单次灌水上限 mm
K_SAMPLES = 8                 # 每个解的稳健性评估样本数
N_PARTITIONS = 8              # Das-Dennis 参考点划分
N_GEN = 40


# ============================================================
# 后验参数样本 (用于稳健性评估)
# ============================================================
def load_posterior_samples(year: int, k: int = K_SAMPLES, seed: int = 7) -> list[dict]:
    """从该年 MCMC 后验抽 k 组 8 参数样本.

    phase1 与 phase2 为条件推断(phase2 条件于 phase1 保留均值), 这里按边际独立组合,
    属于"独立后验边际"近似, 用于不确定性传播的稳健性评估(不用于后验推断).
    """
    f = CACHE / f"DI_{year}.npz"
    rng = np.random.default_rng(seed + year)
    if f.exists():
        d = np.load(f, allow_pickle=False)
        p1, p2 = d["phase1"], d["phase2"]
        i1 = rng.integers(0, len(p1), k)
        i2 = rng.integers(0, len(p2), k)
        out = []
        for a, b in zip(i1, i2):
            v = dict(zip(A.PARAM_NAMES[:5], p1[a]))
            v.update(dict(zip(A.PARAM_NAMES[5:], p2[b])))
            out.append(v)
        return out
    return [dict(A.REFERENCE_MEAN[year]) for _ in range(k)]


def irr_dates(year: int) -> list[str]:
    return [d for d, _ in A.YEAR_DATA[year]["irrigation"]]


# ============================================================
# NSGA-III 问题定义
# ============================================================
class RobustIrrigationProblem(Problem):
    """决策变量 = 8 次灌水量; 目标 = (期望产量, 期望灌水量, 产量波动)."""

    def __init__(self, year: int, samples: list[dict], dates: list[str]):
        super().__init__(
            n_var=len(dates), n_obj=3, n_constr=0,
            xl=np.zeros(len(dates)), xu=np.full(len(dates), X_MAX),
        )
        self.year, self.samples, self.dates = year, samples, dates
        self.n_eval = 0

    def _evaluate(self, X, out, *args, **kwargs):
        F = np.zeros((len(X), 3))
        for i, x in enumerate(X):
            sched = [(self.dates[j], float(x[j])) for j in range(len(x))]
            ys = []
            for p in self.samples:
                r = A.simulate(p, self.year, irrigation=sched)
                ys.append(r["Y_13pct"])
            ys = np.asarray(ys, float)
            F[i, 0] = -float(np.mean(ys))       # 最大化产量 -> 最小化负产量
            F[i, 1] = float(np.sum(x))          # 最小化灌溉量
            F[i, 2] = float(np.std(ys))         # 最小化产量波动 (稳健性)
        self.n_eval += len(X)
        out["F"] = F


# ============================================================
# 主流程
# ============================================================
def run_year(year: int, verbose: bool = True) -> dict:
    samples = load_posterior_samples(year)
    dates = irr_dates(year)
    problem = RobustIrrigationProblem(year, samples, dates)

    ref_dirs = get_reference_directions("das-dennis", 3, n_partitions=N_PARTITIONS)
    pop = ref_dirs.shape[0]
    # NSGA-III 要求 pop_size 与参考点数匹配; 微调到最近的合法值
    algo = NSGA3(pop_size=pop, ref_dirs=ref_dirs, eliminate_duplicates=True)
    term = get_termination("n_gen", N_GEN)

    t0 = time.time()
    res = minimize(problem, algo, term, seed=2024 + year, save_history=False,
                   verbose=False)
    dt = time.time() - t0
    if verbose:
        print(f"  NSGA-III 完成: pop={pop} gen={N_GEN} "
              f"评估={problem.n_eval}次 用时={dt:.1f}s", flush=True)

    F = res.F.copy()
    X = res.X.copy()
    # 还原: 目标是最小化, 这里转回物理意义
    df = pd.DataFrame(X, columns=[f"Irr{j+1}_mm" for j in range(X.shape[1])])
    df["Y13_mean"] = -F[:, 0]
    df["Irr_total_mm"] = F[:, 1]
    df["Y13_std"] = F[:, 2]
    df["Y13_cv_pct"] = 100 * df.Y13_std / df.Y13_mean.replace(0, np.nan)
    df["WP_Irr"] = df.Y13_mean / (df.Irr_total_mm / 1000.0).replace(0, np.nan)
    df["Year"] = year
    return dict(df=df, F=F, X=X, samples=samples, dates=dates,
                n_eval=problem.n_eval, seconds=dt)


def pick_knee(df: pd.DataFrame, year: int) -> pd.Series:
    """从 Pareto 前沿选"膝点": 在产量不低于基准 95% 的约束下, 灌溉量最小的解.

    若无解满足 95%, 退而求其次取产量最高解.
    """
    base = A.YEAR_DATA[year]["y13_obs"]
    feas = df[df.Y13_mean >= 0.95 * base]
    if len(feas):
        return feas.loc[feas.Irr_total_mm.idxmin()]
    return df.loc[df.Y13_mean.idxmax()]


def main():
    print("=" * 68)
    print("阶段 C: NSGA-III 稳健多目标灌溉制度优化")
    print("=" * 68)

    all_pareto, knee_rows, sched_rows = [], [], []

    for year in YEARS:
        print(f"\n--- {year} ---", flush=True)
        r = run_year(year)
        df = r["df"]
        all_pareto.append(df)

        base_y = A.YEAR_DATA[year]["y13_obs"]
        base_i = A.YEAR_DATA[year]["irr_obs"]

        knee = pick_knee(df, year)
        knee_rows.append(dict(
            Year=year,
            Y13_base=base_y,
            Y13_opt=knee.Y13_mean,
            Yield_change_pct=100 * (knee.Y13_mean / base_y - 1),
            Irr_base_mm=base_i,
            Irr_opt_mm=knee.Irr_total_mm,
            Water_saving_pct=100 * (1 - knee.Irr_total_mm / base_i),
            WP_Irr_base=base_y / (base_i / 1000.0),
            WP_Irr_opt=knee.WP_Irr,
            WP_gain_pct=100 * (knee.WP_Irr / (base_y / (base_i / 1000.0)) - 1),
            Y13_std=knee.Y13_std,
            n_pareto=len(df),
        ))
        # 灌溉时间表
        for j, d in enumerate(r["dates"]):
            sched_rows.append(dict(Year=year, Event=j + 1, Date=d,
                                   Base_mm=dict(A.YEAR_DATA[year]["irrigation"])[d],
                                   Optimal_mm=float(knee[f"Irr{j+1}_mm"])))
        print(f"  膝点: 产量 {knee.Y13_mean:.3f} (基准 {base_y:.3f}, "
              f"{100*(knee.Y13_mean/base_y-1):+.2f}%) | "
              f"灌溉 {knee.Irr_total_mm:.1f} (基准 {base_i:.1f}, "
              f"节水 {100*(1-knee.Irr_total_mm/base_i):+.1f}%)", flush=True)

    pareto = pd.concat(all_pareto, ignore_index=True)
    pareto.to_csv(OUT / "pareto_front.csv", index=False, encoding="utf-8-sig")
    print(f"\n✓ pareto_front.csv ({len(pareto)} 个 Pareto 解)")

    knee_df = pd.DataFrame(knee_rows)
    knee_df.to_csv(OUT / "pareto_knee_solutions.csv", index=False, encoding="utf-8-sig")
    print("✓ pareto_knee_solutions.csv")

    sched = pd.DataFrame(sched_rows)
    sched.to_csv(OUT / "optimal_irrigation_schedule.csv", index=False, encoding="utf-8-sig")
    print("✓ optimal_irrigation_schedule.csv")

    # ---------- 图 1: 3D Pareto 前沿 (四年) ----------
    fig = plt.figure(figsize=(14, 10))
    cmap = plt.get_cmap("tab10")
    for idx, year in enumerate(YEARS):
        ax = fig.add_subplot(2, 2, idx + 1, projection="3d")
        d = pareto[pareto.Year == year]
        sc = ax.scatter(d.Irr_total_mm, d.Y13_mean, d.Y13_std,
                        c=d.Y13_mean, cmap="viridis", s=22, alpha=0.85)
        base_y = A.YEAR_DATA[year]["y13_obs"]
        base_i = A.YEAR_DATA[year]["irr_obs"]
        ax.scatter([base_i], [base_y], [0], c="red", marker="*", s=200,
                   edgecolor="k", label="实际灌溉方案")
        ax.set_xlabel("灌溉量 (mm)")
        ax.set_ylabel("产量 Y13 (t/ha)")
        ax.set_zlabel("产量波动 std (t/ha)")
        ax.set_title(f"{year}  Pareto 前沿 (n={len(d)})")
        ax.legend(fontsize=8)
    fig.suptitle("NSGA-III 稳健灌溉制度优化：三目标 Pareto 前沿\n"
                 "（目标：最大化产量 / 最小化灌溉量 / 最小化参数不确定性导致的产量波动）",
                 fontsize=13)
    fig.tight_layout()
    fig.savefig(OUT / "fig_pareto_3d.png", dpi=150)
    plt.close(fig)
    print("✓ fig_pareto_3d.png")

    # ---------- 图 2: 产量-灌溉量权衡曲线 (核心成果图, 对应申报书) ----------
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.8))
    ax = axes[0]
    for i, year in enumerate(YEARS):
        d = pareto[pareto.Year == year].sort_values("Irr_total_mm")
        # Pareto 包络: 按灌溉量分桶取最大产量, 得到单调上升的权衡前沿(去掉散点锯齿)
        nb = 24
        bins = np.linspace(d.Irr_total_mm.min(), d.Irr_total_mm.max() + 1e-9, nb + 1)
        idx = np.clip(np.digitize(d.Irr_total_mm.values, bins) - 1, 0, nb - 1)
        xs, ys = [], []
        for b in range(nb):
            sub = d[idx == b]
            if len(sub):
                xs.append(float(sub.Irr_total_mm.mean()))
                ys.append(float(sub.Y13_mean.max()))
        # 保证单调
        ys = np.maximum.accumulate(np.asarray(ys))
        ax.plot(xs, ys, "-o", ms=3.5, lw=2.1, color=cmap(i), label=f"{year} 优化前沿")
        ax.plot(A.YEAR_DATA[year]["irr_obs"], A.YEAR_DATA[year]["y13_obs"], "*",
                ms=18, color=cmap(i), markeredgecolor="k", markeredgewidth=0.8, zorder=5)
    ax.set_xlabel("灌溉量 (mm)", fontsize=11)
    ax.set_ylabel("产量 $Y_{13}$ (t/ha)", fontsize=11)
    ax.set_title("产量–灌溉量权衡曲线\n（★ = 各年实际灌溉方案；粗线 = NSGA-III Pareto 最优前沿）",
                 fontsize=11)
    ax.legend(ncol=2, fontsize=9)
    ax.grid(alpha=0.35)

    ax = axes[1]
    w = 0.36
    x = np.arange(len(YEARS))
    ax.bar(x - w / 2, knee_df.Irr_base_mm, w, label="实际灌溉量",
           color="#8FAADC", edgecolor="k", lw=0.6)
    ax.bar(x + w / 2, knee_df.Irr_opt_mm, w, label="优化灌溉量（膝点）",
           color="#C00000", edgecolor="k", lw=0.6)
    ymax = float(knee_df.Irr_base_mm.max())
    ax.set_ylim(0, ymax * 1.30)
    for i, row in knee_df.iterrows():
        ax.text(i, row.Irr_base_mm + ymax * 0.035,
                f"节水 {row.Water_saving_pct:.1f}%\n产量 {row.Yield_change_pct:+.1f}%",
                ha="center", fontsize=8.5, linespacing=1.45)
    ax.set_xticks(x)
    ax.set_xticklabels(YEARS)
    ax.set_ylabel("灌溉量 (mm)", fontsize=11)
    ax.set_title("膝点方案 vs 实际方案\n（膝点 = 产量 ≥ 基准 95% 前提下灌溉量最小）", fontsize=11)
    ax.legend(fontsize=9)
    ax.grid(axis="y", alpha=0.35)
    fig.tight_layout()
    fig.savefig(OUT / "fig_yield_irrigation_tradeoff.png", dpi=150)
    plt.close(fig)
    print("✓ fig_yield_irrigation_tradeoff.png")

    # ---------- 图 3: 最优灌溉时间表 ----------
    fig, axes = plt.subplots(2, 2, figsize=(14, 8))
    for idx, year in enumerate(YEARS):
        ax = axes[idx // 2, idx % 2]
        s = sched[sched.Year == year]
        x = np.arange(len(s))
        ax.bar(x - 0.2, s.Base_mm, 0.4, label="实际", color="#8FAADC", edgecolor="k", lw=0.5)
        ax.bar(x + 0.2, s.Optimal_mm, 0.4, label="NSGA-III 优化", color="#C00000", edgecolor="k", lw=0.5)
        ax.set_xticks(x)
        ax.set_xticklabels([d[5:] for d in s.Date], rotation=45, ha="right", fontsize=8)
        ax.set_ylabel("灌水量 (mm)")
        ax.set_title(f"{year} 灌溉时间安排")
        ax.legend(fontsize=8)
        ax.grid(axis="y", alpha=0.3)
    fig.suptitle("NSGA-III 优化的逐年灌溉时间安排表（8 次灌水）", fontsize=13)
    fig.tight_layout()
    fig.savefig(OUT / "fig_irrigation_schedule.png", dpi=150)
    plt.close(fig)
    print("✓ fig_irrigation_schedule.png")

    # ---------- 摘要 ----------
    summary = dict(
        Method="NSGA-III (Das-Dennis 参考点) + 后验样本稳健性评估",
        Decision_variable=f"{N_IRR} 次灌水量, 单次上限 {X_MAX} mm",
        Objectives=["最大化期望产量", "最小化灌溉量", "最小化参数不确定性导致的产量波动"],
        Robustness_samples=K_SAMPLES,
        Generations=N_GEN,
        Knee_solutions=knee_df.to_dict("records"),
        Mean_water_saving_pct=float(knee_df.Water_saving_pct.mean()),
        Mean_yield_change_pct=float(knee_df.Yield_change_pct.mean()),
        Mean_WP_gain_pct=float(knee_df.WP_gain_pct.mean()),
    )
    (OUT / "nsga3_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("✓ nsga3_summary.json")

    print("\n=== 膝点方案汇总 ===")
    print(knee_df[["Year", "Y13_base", "Y13_opt", "Yield_change_pct",
                   "Irr_base_mm", "Irr_opt_mm", "Water_saving_pct",
                   "WP_gain_pct"]].round(3).to_string(index=False))
    print(f"\n平均节水 {knee_df.Water_saving_pct.mean():.1f}% , "
          f"平均产量变化 {knee_df.Yield_change_pct.mean():+.2f}% , "
          f"平均灌溉水生产率提升 {knee_df.WP_gain_pct.mean():+.1f}%")
    print("\n阶段 C 完成 ✅")


if __name__ == "__main__":
    main()
