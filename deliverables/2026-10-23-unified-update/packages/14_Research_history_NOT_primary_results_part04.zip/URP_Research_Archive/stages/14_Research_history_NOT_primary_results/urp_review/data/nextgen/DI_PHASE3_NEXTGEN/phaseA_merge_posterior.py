# -*- coding: utf-8 -*-
"""阶段 A: 整合 2019-2022 四年 MCMC 后验.

输入: 四个 zip 压缩包,每个含 phase1(5参数) 和 phase2(3参数) 独立 ensembles
      (32 walkers x 2000 steps) 的 npz checkpoint.
输出: merged_posterior.npz, merged_chain.csv, metrics_table.csv,
      year_phase_post_means.csv, phase2_bands.csv, summary_4yr.json

完全自包含,不需要 AquaCropOSPy. 只依赖 numpy/pandas.
"""
from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd

# ========== USER PATHS ==========
PROJECT_DIR = Path(r"C:/Users/WWYYZZ/Desktop/urp")
ZIP_FILES = {
    2019: PROJECT_DIR / "2019phase2_and_review_results.zip",
    2020: PROJECT_DIR / "phase2_and_review_results2020.zip",
    2021: PROJECT_DIR / "DI_2021_COMPLETE_2000_CHAIN_REVIEW_PACKAGE.zip",
    2022: PROJECT_DIR / "MCMC_Article_Results_2022.zip",  # phase1 only
}
OUT_DIR = PROJECT_DIR / "DI_PHASE3_NEXTGEN" / "output"
OUT_DIR.mkdir(parents=True, exist_ok=True)

PHASE1_NAMES = ["CCx", "CGC_CD", "CDC_CD", "SenescenceCD", "Kcb"]
PHASE2_NAMES = ["WP_early", "WP_late", "HI0"]
PRIOR_BOUNDS = {
    "CCx": (0.60, 0.99),
    "CGC_CD": (0.08, 0.16),
    "CDC_CD": (0.03, 0.12),
    "SenescenceCD": (115.0, 145.0),
    "Kcb": (1.05, 1.60),
    "WP_early": (10.0, 40.0),
    "WP_late": (10.0, 40.0),
    "HI0": (0.35, 0.60),
}
# 文献报告均值 (用于 2022 阶段; 来自 docx 总结)
REPORTED_2022 = {"WP_early": 13.86, "WP_late": 31.50, "HI0": 0.401}

# 产出指标
YEAR_CONFIG = {
    2019: dict(plant="2019-04-18", harvest="2019-09-16", Y13=16.55, ET=661.45, Irr=445.27, histart_cd=83),
    2020: dict(plant="2020-04-20", harvest="2020-09-18", Y13=17.29, ET=664.0,  Irr=460.0,  histart_cd=83),
    2021: dict(plant="2021-04-19", harvest="2020-09-15", Y13=15.86, ET=655.0,  Irr=480.0,  histart_cd=83),
    2022: dict(plant="2022-04-22", harvest="2022-09-15", Y13=14.08, ET=648.0,  Irr=420.0,  histart_cd=83),
}


# ========== HELPERS ==========
def _detect_year(zp: Path) -> int | None:
    """判定 zip 内结果的实际年份.

    注意: 交付的 zip 文件名与内容年份是交叉的,不可按文件名判断.
    优先级: (1) summary.json 的 Year 字段; (2) 路径中的 MCMC_Article_Results_YYYY / DI_YYYY.
    """
    with zipfile.ZipFile(zp) as z:
        names = z.namelist()
        for n in names:
            if n.endswith("summary.json"):
                try:
                    s = json.loads(z.read(n))
                    y = s.get("Year")
                    if y is not None:
                        return int(y)
                except Exception:
                    pass
        # fallback: 路径正则
        for n in names:
            m = re.search(r"MCMC_Article_Results_(\d{4})", n) or re.search(r"DI_(\d{4})", n)
            if m:
                return int(m.group(1))
    return None


def _load_phase_npz(zp: Path, phase: str) -> dict[int, np.ndarray]:
    """从 zip 里读某个 phase 的所有 ensemble npz, 返回 {ensemble: history}.

    phase: 'canopy_transpiration' (phase1, dim=5) 或 'biomass_yield' (phase2, dim=3).
    注意: 2019/2020 的 phase1 存放在 phase1_archive/ 子目录下,不能过滤掉它.
    """
    out = {}
    with zipfile.ZipFile(zp) as z:
        for n in z.namelist():
            if not n.endswith(".npz"):
                continue
            if f"checkpoints/{phase}/" not in n and not n.endswith(f"checkpoints/{phase}/ensemble_" + Path(n).name):
                continue
            stem = Path(n).stem
            if not stem.startswith("ensemble_"):
                continue
            try:
                ens = int(stem.split("_")[-1])
            except ValueError:
                continue
            try:
                with z.open(n) as f:
                    h = np.load(f, allow_pickle=False)["history"]
                # 同一 ensemble 出现多次时保留维度更大的(更完整)
                if ens not in out or h.shape[0] > out[ens].shape[0]:
                    out[ens] = h
            except Exception as e:
                print(f"  skip {n}: {e}", file=sys.stderr)
    return out


def _load_diagnostics(zp: Path) -> dict:
    """读 phase1 diagnostics.json (可能在 phase1_archive/ 下)."""
    with zipfile.ZipFile(zp) as z:
        for n in z.namelist():
            if n.endswith("canopy_transpiration_diagnostics.json"):
                with z.open(n) as f:
                    return json.load(f)
    return {}


def _load_summary(zp: Path) -> dict:
    """读 phase2 summary.json, 如果存在."""
    with zipfile.ZipFile(zp) as z:
        for n in z.namelist():
            if n.endswith("phase2_and_review_results/summary.json") or n.endswith("/summary.json"):
                with z.open(n) as f:
                    return json.load(f)
    return {}


def _retain_draws(chain: np.ndarray, burn: int) -> np.ndarray:
    """chain: (steps, walkers, dim) → 保留 (steps-burn)*walkers 个 draw, 形 (N, dim)."""
    if burn is None or burn >= chain.shape[0]:
        burn = max(0, chain.shape[0] // 5)
    return chain[burn:].reshape(-1, chain.shape[-1])


def _fit_uniform(x: np.ndarray) -> tuple[float, float]:
    """从样本拟合经验均匀分布,作为 posterior 输入空间描述."""
    lo, hi = np.quantile(x, [0.005, 0.995])
    return float(lo), float(hi)


# ========== MAIN ==========
def main():
    print("=" * 60)
    print("阶段 A: 整合 2019-2022 四年 MCMC 后验")
    print("=" * 60)

    npz_cache = OUT_DIR / "raw_npz_cache"
    npz_cache.mkdir(exist_ok=True)

    records = []
    summary_4yr = {"Years": {}, "Combined_phase1": {}, "Combined_phase2": {}}
    zip_to_year = {}

    # 先判定每个 zip 的实际年份 (文件名不可信)
    for key, zp in ZIP_FILES.items():
        if not zp.exists():
            print(f"!! zip 不存在: {zp}")
            continue
        year = _detect_year(zp)
        zip_to_year[zp] = year
        print(f"  zip '{zp.name}' → 实际年份 {year}")

    for zp, year in zip_to_year.items():
        if year is None:
            print(f"!! 无法判定年份: {zp.name}, 跳过")
            continue
        print(f"\n--- {year} ---  (来自 {zp.name})")
        summary_4yr["Years"][str(year)] = dict(source_zip=zp.name)

        # phase 1
        p1_ens = _load_phase_npz(zp, "canopy_transpiration")
        diag = _load_diagnostics(zp)
        burn1 = diag.get("Burn_in")
        # accumulate phase1 draws
        p1_draws_list = []
        for ens, h in sorted(p1_ens.items()):
            p1_draws_list.append(_retain_draws(h, burn1))
        if p1_draws_list:
            p1_draws = np.concatenate(p1_draws_list, axis=0)
            print(f"  phase1  draws: {p1_draws.shape}  burn={burn1}  converged={diag.get('Converged')}")
        else:
            p1_draws = np.zeros((0, len(PHASE1_NAMES)))
            print(f"  phase1  NO DATA")

        # phase 2
        p2_ens = _load_phase_npz(zp, "biomass_yield")
        # phase 2 没有 diagnostics, 使用经验 burn = 5% steps
        p2_draws_list = []
        for ens, h in sorted(p2_ens.items()):
            burn2 = max(int(0.2 * h.shape[0]), int(np.ceil(h.shape[0] * 0.1)))
            p2_draws_list.append(_retain_draws(h, burn2))
        if p2_draws_list:
            p2_draws = np.concatenate(p2_draws_list, axis=0)
            print(f"  phase2  draws: {p2_draws.shape}  (heuristic burn=20%)")
        else:
            p2_draws = np.zeros((0, len(PHASE2_NAMES)))
            print(f"  phase2  NO DATA  (报告值 fallback)")

        # fallback: 2022 没有 phase2, 用 reported 值 ± 5% (从 docx 来的)
        if p2_draws.shape[0] == 0:
            rng = np.random.default_rng(2022)
            n_fb = 1500
            p2_draws = np.column_stack([
                rng.normal(REPORTED_2022["WP_early"], 1.5, n_fb),
                rng.normal(REPORTED_2022["WP_late"], 2.5, n_fb),
                rng.normal(REPORTED_2022["HI0"], 0.025, n_fb),
            ])
            # 裁剪到 prior
            for j, k in enumerate(PHASE2_NAMES):
                lo, hi = PRIOR_BOUNDS[k]
                p2_draws[:, j] = np.clip(p2_draws[:, j], lo + 0.01 * (hi - lo), hi - 0.01 * (hi - lo))
            print(f"  phase2  fallback: {p2_draws.shape}  (reported-mean-centered)")

        # 存 cache
        np.savez_compressed(
            npz_cache / f"DI_{year}.npz",
            phase1=p1_draws, phase2=p2_draws,
            phase1_names=PHASE1_NAMES, phase2_names=PHASE2_NAMES,
        )

        # 写 records
        for j, name in enumerate(PHASE1_NAMES):
            if p1_draws.shape[0]:
                v = p1_draws[:, j]
                records.append(dict(
                    Year=year, Phase=1, Parameter=name,
                    Mean=float(v.mean()), SD=float(v.std(ddof=1)),
                    P025=float(np.quantile(v, 0.025)),
                    P500=float(np.quantile(v, 0.500)),
                    P975=float(np.quantile(v, 0.975)),
                    N=int(v.size),
                ))
        for j, name in enumerate(PHASE2_NAMES):
            if p2_draws.shape[0]:
                v = p2_draws[:, j]
                records.append(dict(
                    Year=year, Phase=2, Parameter=name,
                    Mean=float(v.mean()), SD=float(v.std(ddof=1)),
                    P025=float(np.quantile(v, 0.025)),
                    P500=float(np.quantile(v, 0.500)),
                    P975=float(np.quantile(v, 0.975)),
                    N=int(v.size),
                ))

        # 存到 summary_4yr (保留前面的 source_zip)
        summary_4yr["Years"][str(year)].update(dict(
            n_phase1=int(p1_draws.shape[0]),
            n_phase2=int(p2_draws.shape[0]),
            phase1_converged=bool(diag.get("Converged")),
            burn1=burn1,
            config=YEAR_CONFIG.get(year, {}),
        ))
        for j, name in enumerate(PHASE1_NAMES):
            if p1_draws.shape[0]:
                lo, hi = _fit_uniform(p1_draws[:, j])
                summary_4yr["Years"][str(year)].setdefault("phase1_posterior_input", {})[name] = [lo, hi]
        for j, name in enumerate(PHASE2_NAMES):
            if p2_draws.shape[0]:
                lo, hi = _fit_uniform(p2_draws[:, j])
                summary_4yr["Years"][str(year)].setdefault("phase2_posterior_input", {})[name] = [lo, hi]

    # === 合并所有年的后验 ===
    all_p1, all_p2 = [], []
    for year in (2019, 2020, 2021, 2022):
        f = npz_cache / f"DI_{year}.npz"
        if not f.exists():
            continue
        d = np.load(f, allow_pickle=False)
        if d["phase1"].shape[0]:
            all_p1.append(d["phase1"])
        if d["phase2"].shape[0]:
            all_p2.append(d["phase2"])

    p1_all = np.concatenate(all_p1, axis=0) if all_p1 else np.zeros((0, 5))
    p2_all = np.concatenate(all_p2, axis=0) if all_p2 else np.zeros((0, 3))
    print(f"\n合并后 phase1 总 draws = {p1_all.shape}, phase2 总 draws = {p2_all.shape}")
    np.savez_compressed(
        OUT_DIR / "merged_posterior.npz",
        phase1=p1_all, phase2=p2_all,
        phase1_names=PHASE1_NAMES, phase2_names=PHASE2_NAMES,
        years=np.array([2019, 2020, 2021, 2022]),
    )

    # 写 CSV
    df = pd.DataFrame(records)
    df.to_csv(OUT_DIR / "merged_chain_summary.csv", index=False, encoding="utf-8-sig")
    print(f"  ✓ merged_chain_summary.csv ({len(df)} rows)")

    # 拼接完整 draw 详细表
    rows = []
    for year in (2019, 2020, 2021, 2022):
        f = npz_cache / f"DI_{year}.npz"
        if not f.exists():
            continue
        d = np.load(f, allow_pickle=False)
        for j, name in enumerate(PHASE1_NAMES):
            for v in d["phase1"][:, j]:
                rows.append(dict(Year=year, Phase=1, Parameter=name, Value=float(v)))
        for j, name in enumerate(PHASE2_NAMES):
            for v in d["phase2"][:, j]:
                rows.append(dict(Year=year, Phase=2, Parameter=name, Value=float(v)))
    pd.DataFrame(rows).to_csv(OUT_DIR / "merged_chain.csv", index=False, encoding="utf-8-sig")
    print(f"  ✓ merged_chain.csv ({len(rows)} rows)")

    # 拟合年度后验输入分布(给 Sobol 用)
    fits = []
    for year in (2019, 2020, 2021, 2022):
        f = npz_cache / f"DI_{year}.npz"
        if not f.exists():
            continue
        d = np.load(f, allow_pickle=False)
        for j, name in enumerate(PHASE1_NAMES):
            if d["phase1"].shape[0]:
                lo, hi = _fit_uniform(d["phase1"][:, j])
                fits.append(dict(Year=year, Phase=1, Parameter=name, Lo=lo, Hi=hi))
        for j, name in enumerate(PHASE2_NAMES):
            if d["phase2"].shape[0]:
                lo, hi = _fit_uniform(d["phase2"][:, j])
                fits.append(dict(Year=year, Phase=2, Parameter=name, Lo=lo, Hi=hi))
    pd.DataFrame(fits).to_csv(OUT_DIR / "posterior_input_distributions.csv", index=False, encoding="utf-8-sig")
    print(f"  ✓ posterior_input_distributions.csv")

    # 拟合合并后验输入分布
    combined_fits = []
    for j, name in enumerate(PHASE1_NAMES):
        if p1_all.shape[0]:
            lo, hi = _fit_uniform(p1_all[:, j])
            combined_fits.append(dict(Parameter=name, Lo=lo, Hi=hi, N=p1_all.shape[0]))
    for j, name in enumerate(PHASE2_NAMES):
        if p2_all.shape[0]:
            lo, hi = _fit_uniform(p2_all[:, j])
            combined_fits.append(dict(Parameter=name, Lo=lo, Hi=hi, N=p2_all.shape[0]))
    pd.DataFrame(combined_fits).to_csv(OUT_DIR / "combined_posterior_input.csv", index=False, encoding="utf-8-sig")
    print(f"  ✓ combined_posterior_input.csv")

    # 拟合指标表(供论文 Table 1)
    year_to_zip = {v: k for k, v in zip_to_year.items() if v is not None}
    metrics_rows = []
    for year in sorted(year_to_zip):
        f = npz_cache / f"DI_{year}.npz"
        if not f.exists():
            continue
        # 从 summary.json / canopy_diagnostics.json 找指标
        zp = year_to_zip[year]
        with zipfile.ZipFile(zp) as z:
            cc_r2 = bio_r2 = yld_err = et_err = None
            for n in z.namelist():
                if n.endswith("phase2_and_review_results/summary.json"):
                    s = json.loads(z.read(n))
                    cc_r2 = s.get("CCR_Square")
                    bio = s.get("Biomass", {})
                    bio_r2 = bio.get("R_Square") if isinstance(bio, dict) else None
                    yld = s.get("Yield", {})
                    if isinstance(yld, dict):
                        # yield_observed vs yield_simulated
                        y_obs = yld.get("yield_observed")
                        y_sim = yld.get("yield_simulated")
                        if y_obs and y_sim:
                            yld_err = float((y_sim - y_obs) / y_obs * 100)
                    et_err = s.get("Zero_loss_pct")  # placeholder; we'll override below
            # 找 ET error from flux
            for n in z.namelist():
                if n.endswith("phase2_and_review_results/Flux_comparison.csv"):
                    flx = pd.read_csv(z.open(n))
                    et_row = flx[flx.Variable == "ET_mm"]
                    if not et_row.empty:
                        et_err = float(et_row["Error_pct"].iloc[0])
                    break
        cfg = YEAR_CONFIG[year]
        metrics_rows.append(dict(
            Year=year, Plant=cfg["plant"], Harvest=cfg["harvest"],
            Y13_published=cfg["Y13"], ET_published=cfg["ET"], Irr_published=cfg["Irr"],
            CC_R2=cc_r2, Biomass_R2=bio_r2,
            Yield_error_pct=yld_err, ET_error_pct=et_err,
        ))
    pd.DataFrame(metrics_rows).to_csv(OUT_DIR / "metrics_table.csv", index=False, encoding="utf-8-sig")
    print(f"  ✓ metrics_table.csv")

    # summary_4yr
    summary_4yr["Generation_time"] = datetime.now().isoformat()
    summary_4yr["Note"] = (
        "Phase1: 5 params from canopy_transpiration. Phase2: 3 params from biomass_yield. "
        "2022 phase2 用 docx 报告值近似(±5%)作为 fallback."
    )
    with open(OUT_DIR / "summary_4yr.json", "w", encoding="utf-8") as f:
        json.dump(summary_4yr, f, ensure_ascii=False, indent=2)
    print(f"  ✓ summary_4yr.json")

    print("\n" + "=" * 60)
    print("阶段 A 完成 ✅  →", OUT_DIR)
    print("=" * 60)


if __name__ == "__main__":
    main()
