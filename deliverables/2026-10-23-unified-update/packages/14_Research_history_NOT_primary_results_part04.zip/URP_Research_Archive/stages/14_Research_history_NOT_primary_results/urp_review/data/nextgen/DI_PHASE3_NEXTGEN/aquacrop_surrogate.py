# -*- coding: utf-8 -*-
"""AquaCrop 简化日尺度代理模型 (surrogate).

严格遵循 FAO Irrigation & Drainage Paper 66 (AquaCrop) 的水分生产函数核心:

    CC(t)   冠层覆盖度, 由 CCx / CGC / CDC / Senescence 参数化
    Tr(t) = Ks(t) * CC*(t) * Kcb * ET0(t)        蒸腾
    Es(t) = Kr(t) * (1 - CC*(t)) * ET0(t) * fMulch  蒸发 (地膜 MulchPct=75% 抑制)
    dB     = WP*(t) * (Tr(t)/ET0(t))              生物量增量 [g/m2]
    B      = sum(dB)                               总生物量 [g/m2] -> /100 = t/ha
    Y_dry  = HI0 * B                               干物质产量 [t/ha]
    Y_13   = Y_dry / 0.87                          13% 含水率产量 [t/ha]

    WP*(t) = WP_early  if t < SWITCH(第 histart_cd 天)  else WP_late

与真实模型的接口约定
--------------------
本模块提供 `simulate(params, year, irrigation=None, ...) -> dict`.
在 PyCharm 中, 只需把下面 `simulate()` 的函数体替换为真实
`model.simulate(data, params, 'DI')[0]` 的返回值, 其余分析代码(B/C/D)完全不用改.

驱动与标定
----------
逐日 ET0 与降水取自**真实观测** (`inputs/DI_Climate_YYYY_FINAL.csv`, 见 `real_forcing.py`):
生长季窗口由 "Old_ETo 年度总量 + 降水年度总量" 双重匹配唯一确定 (四年全部精确复现),
ETo 施加风速纠偏因子 (B_ETo/Old_ETo, 由 ETo_source_audit.csv 给出)。

仍保留两个年度标定系数使代理在后验均值点精确复现观测:
    f_mulch — 地膜对土壤蒸发的有效抑制系数 (二分求解, 使 Es 匹配实测)
    k_B     — 生物量比例因子 (使 Y13 匹配实测)
响应面的物理形态由 AquaCrop 方程保证, 故 Sobol 排序与 Pareto 形状可信。

⚠ 残余限制: 代理不含 24 层土壤分层、毛细上升、根系逐日伸长、HImult 授粉上限等过程;
   绝对值仍应以 PyCharm 中的真实 AquaCropOSPy 复算为准。
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import real_forcing        # 真实逐日气象 (inputs/DI_Climate_*.csv), 缺失时回退
    _HAS_REAL = True
except Exception:
    real_forcing = None
    _HAS_REAL = False

# ============================================================
# 四年真实驱动数据 (来自各年 input_audit/pre_run_summary.csv)
# ============================================================
YEAR_DATA = {
    2019: dict(
        n_days=151, plant="2019-04-18",
        et0_annual=595.62,        # B_ETo_mm 纠偏后
        rain_annual=177.87,
        irrigation=[("2019-06-06", 64.62), ("2019-06-18", 67.71), ("2019-07-06", 63.35),
                    ("2019-07-18", 58.18), ("2019-07-27", 62.17), ("2019-08-10", 63.18),
                    ("2019-08-23", 30.02), ("2019-08-26", 36.04)],
        histart_cd=83,            # WP 切换日 (开花期)
        y13_obs=16.552, b_obs=35.704684, tr_obs=584.456, es_obs=95.408, et_obs=679.864,
        irr_obs=445.27,
    ),
    2020: dict(
        n_days=152, plant="2020-04-20",
        et0_annual=632.26, rain_annual=113.46,
        irrigation=[("2020-06-08", 70.0), ("2020-06-20", 72.0), ("2020-07-04", 68.0),
                    ("2020-07-19", 66.0), ("2020-07-29", 70.0), ("2020-08-12", 72.0),
                    ("2020-08-24", 71.0), ("2020-09-02", 70.8)],
        histart_cd=85,            # 权威 Switch: 2020-07-14 (preflight.json)
        y13_obs=17.024, b_obs=24.646570, tr_obs=545.510, es_obs=82.447, et_obs=627.957,
        irr_obs=559.76,
    ),
    2021: dict(
        n_days=148, plant="2021-04-27",   # 模拟窗口起点 = 气候文件真实窗口起点
        et0_annual=612.93, rain_annual=143.32,
        irrigation=[("2021-06-05", 78.0), ("2021-06-17", 82.0), ("2021-07-02", 80.0),
                    ("2021-07-16", 78.0), ("2021-07-28", 82.0), ("2021-08-09", 80.0),
                    ("2021-08-21", 78.0), ("2021-09-01", 75.5)],
        histart_cd=77,            # 权威 Switch: 2021-07-13 (preflight.json)
        y13_obs=15.377, b_obs=22.278917, tr_obs=548.254, es_obs=71.139, et_obs=619.393,
        irr_obs=633.47,
    ),
    2022: dict(
        n_days=148, plant="2022-04-17",   # 权威窗口 (preflight.json: 2022-04-17 ~ 2022-09-11)
        et0_annual=610.02,        # = Old_ETo 521.941 × 三年均值纠偏因子 1.168755
        rain_annual=151.38,
        irrigation=[("2022-06-07", 52.0), ("2022-06-19", 54.0), ("2022-07-03", 52.0),
                    ("2022-07-17", 50.0), ("2022-07-29", 52.0), ("2022-08-11", 50.0),
                    ("2022-08-23", 50.0), ("2022-09-03", 44.8)],
        histart_cd=79,            # 权威 Switch: 2022-07-05 (preflight.json)
        y13_obs=14.088, b_obs=30.524940, tr_obs=525.447, es_obs=73.163, et_obs=598.609,
        irr_obs=404.84,
    ),
}

# 土壤 / 地膜参数 (与正式模型一致)
SOIL = dict(
    TAW=180.0,     # 根区总有效水 [mm] (1.2 m 根深, 约 150 mm/m)
    p=0.55,        # 玉米易利用水比例 (AquaCrop 默认 p=0.55)
    mulch_pct=75.0,  # 地膜覆盖比例
)
CC0 = 0.0068      # 初始冠层覆盖度 (玉米, 79365 株/ha)


# ============================================================
# 日驱动序列
# ------------------------------------------------------------
# 优先使用**真实逐日观测** (real_forcing: inputs/DI_Climate_*.csv,
# 生长季窗口经年度总量双重校验, ETo 施加风速纠偏因子)。
# 仅当 inputs/ 缺失时才回退到下面的合成序列。
# ============================================================
def _season_shape(n: int, peak_frac: float = 0.45, sharpness: float = 1.0) -> np.ndarray:
    """(回退用) 生长季钟形权重: 中期高, 两头低."""
    t = np.arange(n) / max(n - 1, 1)
    w = np.exp(-((t - peak_frac) ** 2) / (2 * (0.22 / sharpness) ** 2))
    return w / w.sum()


def _daily_et0(year: int) -> np.ndarray:
    """逐日 ET0 [mm]. 真实观测优先; 缺失时用合成序列回退."""
    if _HAS_REAL:
        return real_forcing.et0_daily(year)
    d = YEAR_DATA[year]
    return d["et0_annual"] * _season_shape(d["n_days"], peak_frac=0.45)


def _daily_rain(year: int, seed: int = 2024) -> np.ndarray:
    """逐日降水 [mm]. 真实观测优先; 缺失时用合成序列回退."""
    if _HAS_REAL:
        return real_forcing.rain_daily(year)
    d = YEAR_DATA[year]
    n = d["n_days"]
    rng = np.random.default_rng(seed + year)
    base = _season_shape(n, peak_frac=0.5)
    rain = base * d["rain_annual"] * 0.55          # 55% 作为平缓基底
    remaining = d["rain_annual"] - rain.sum()
    n_events = int(rng.integers(5, 8))
    sizes = rng.dirichlet(np.ones(n_events)) * remaining
    days = rng.choice(np.arange(int(n * 0.15), int(n * 0.85)), size=n_events, replace=False)
    rain[days] += sizes
    return rain


def _daily_irrigation(year: int, irrigation=None) -> np.ndarray:
    """把灌溉时间表展开成日序列.

    支持三种写法 (便于跨年迁移分析):
      ('2019-06-06', 64.6)  绝对日期 -> 按当年播期换算
      (49, 64.6)            播后第 49 天 (相对天数) -> 直接使用, 跨年通用
      (date(2019,6,6), 64.6) date 对象 -> 按当年播期换算
    """
    from datetime import date
    d = YEAR_DATA[year]
    n = d["n_days"]
    out = np.zeros(n)
    sched = irrigation if irrigation is not None else d["irrigation"]
    if sched is None:
        return out
    plant = date.fromisoformat(d["plant"])
    for item in sched:
        dt, mm = item[0], float(item[1])
        if isinstance(dt, (int, np.integer)):
            idx = int(dt)                      # 相对播期天数, 跨年可直接套用
        elif isinstance(dt, str):
            idx = (date.fromisoformat(dt) - plant).days
        else:
            idx = (dt - plant).days
        if 0 <= idx < n:
            out[idx] += mm
    return out


# ============================================================
# 核心: AquaCrop 日尺度模拟
# ============================================================
def _raw_simulate(params: dict, year: int, irrigation=None,
                  et0=None, rain=None, f_mulch: float = 0.25,
                  a_cc: float = 0.0, k_cgc: float = 1.0) -> dict:
    """未标定的 AquaCrop 日尺度核心.

    f_mulch : 地膜对土壤蒸发的有效抑制残余比例 (越小抑制越强)
    a_cc    : 冠层蒸腾折减系数 —— 高密度冠层下的 micro-advection 修正,
              对应 AquaCrop 的 CC* (adjusted canopy cover)。滴灌+地膜+高密度下显著。
    k_cgc   : CGC 的日历日校正系数 —— 后验 CGC_CD 以 calendar-day 为基准,
              与 FAO-66 标准 (GDD 基准) 存在换算差异; 该系数由田间 CC 观测反推,
              使冠层模块的 CC 日序列匹配实测。
    """
    d = YEAR_DATA[year]
    n = d["n_days"]
    et0 = _daily_et0(year) if et0 is None else np.asarray(et0, float)
    rain = _daily_rain(year) if rain is None else np.asarray(rain, float)
    irr = _daily_irrigation(year, irrigation)

    CCx = float(params["CCx"])
    CGC = float(params["CGC_CD"])
    CDC = float(params["CDC_CD"])
    sen = float(params["SenescenceCD"])
    Kcb = float(params["Kcb"])
    WP_early = float(params["WP_early"])
    WP_late = float(params["WP_late"])
    HI0 = float(params["HI0"])

    TAW, p = SOIL["TAW"], SOIL["p"]
    RAW = p * TAW

    Dr = 0.0                 # 根区亏缺 [mm]
    B = 0.0                  # 累积生物量 [g/m2]
    Tr_tot = Es_tot = 0.0
    ks_list = []
    cc_series = np.zeros(n)
    wp_series = np.zeros(n)

    exp = math.exp
    for t in range(n):
        # ---- 冠层 (FAO-66 标准分段公式; CGC 经日历日校正) ----
        cgc_eff = CGC * k_cgc
        if t < sen:
            cc_exp = CC0 * exp(cgc_eff * t)
            if cc_exp <= 0.5 * CCx:
                cc = cc_exp
            else:
                cc = CCx - 0.25 * (CCx * CCx / CC0) * exp(-cgc_eff * t)
                if cc > CCx:
                    cc = CCx
        else:
            cc = CCx * (1.0 - 0.05 * (exp((CDC / CCx) * (t - sen)) - 1.0))
            if cc < 0.0:
                cc = 0.0
            elif cc > CCx:
                cc = CCx
        cc_series[t] = cc

        # ---- WP 切换 (开花期) ----
        wp = WP_early if t < d["histart_cd"] else WP_late
        wp_series[t] = wp

        # ---- 水分胁迫 ----
        if Dr <= RAW:
            Ks = 1.0
        else:
            Ks = max(0.0, (TAW - Dr) / max(TAW - RAW, 1e-6))
        ks_list.append(Ks)

        # ---- 蒸腾 / 蒸发 ----
        # 冠层蒸腾有效系数: 高密度冠层下的 micro-advection 折减
        cc_eff = cc * (1.0 - a_cc * (cc / CCx)) if CCx > 0 else cc
        tr = Ks * cc_eff * Kcb * et0[t]
        es = (1.0 - cc) * et0[t] * f_mulch     # 地膜抑制
        # 蒸发还受表土干燥限制 (Kr): 简化为表土湿润时全蒸, 干燥时衰减
        kr = 1.0 if Dr < 0.5 * TAW else max(0.2, 1.0 - (Dr - 0.5 * TAW) / (0.5 * TAW))
        es *= kr

        Tr_tot += tr
        Es_tot += es

        # ---- 生物量 (AquaCrop 水分生产函数) ----
        if et0[t] > 1e-6:
            B += wp * (tr / et0[t])           # g/m2

        # ---- 水量平衡 ----
        Dr = Dr + tr + es - rain[t] - irr[t]
        Dr = float(np.clip(Dr, 0.0, TAW))

    # ---- 产量 ----
    B_t_ha = B * 0.01                 # g/m2 -> t/ha
    Y_dry = HI0 * B_t_ha
    Y_13 = Y_dry / 0.87

    irr_tot = float(irr.sum())
    et_tot = Tr_tot + Es_tot
    return dict(
        Y_dry=float(Y_dry),
        Y_13pct=float(Y_13),
        B_t_ha=float(B_t_ha),
        Tr_mm=float(Tr_tot),
        Es_mm=float(Es_tot),
        ET_mm=float(et_tot),
        Irr_mm=irr_tot,
        Rain_mm=float(rain.sum()),
        WP_ET=float(Y_13 / (et_tot / 1000.0)) if et_tot > 1e-6 else 0.0,   # t/ha per m3... kg/m3
        WP_Irr=float(Y_13 / (irr_tot / 1000.0)) if irr_tot > 1e-6 else 0.0,
        MaxCC=float(cc_series.max()),
        mean_Ks=float(np.mean(ks_list)),
        cc_series=cc_series,
        wp_series=wp_series,
    )


# ============================================================
# 四年后验均值参考点 (用于标定与基准对比)
# ============================================================
REFERENCE_MEAN = {
    2019: dict(CCx=0.9771, CGC_CD=0.0988, CDC_CD=0.0603, SenescenceCD=137.38, Kcb=1.4866,
               WP_early=18.214, WP_late=30.613, HI0=0.412),
    2020: dict(CCx=0.9773, CGC_CD=0.0956, CDC_CD=0.0607, SenescenceCD=137.84, Kcb=1.4352,
               WP_early=11.258, WP_late=25.842, HI0=0.574),
    2021: dict(CCx=0.9594, CGC_CD=0.1154, CDC_CD=0.0663, SenescenceCD=134.85, Kcb=1.4161,
               WP_early=10.866, WP_late=21.949, HI0=0.580),
    2022: dict(CCx=0.9374, CGC_CD=0.1318, CDC_CD=0.0642, SenescenceCD=134.95, Kcb=1.3775,
               WP_early=13.826, WP_late=31.524, HI0=0.403),
}

PARAM_NAMES = ["CCx", "CGC_CD", "CDC_CD", "SenescenceCD", "Kcb", "WP_early", "WP_late", "HI0"]
PRIOR_BOUNDS = {
    "CCx": (0.60, 0.99), "CGC_CD": (0.08, 0.16), "CDC_CD": (0.03, 0.12),
    "SenescenceCD": (115.0, 145.0), "Kcb": (1.05, 1.60),
    "WP_early": (10.0, 40.0), "WP_late": (10.0, 40.0), "HI0": (0.35, 0.60),
}


# ============================================================
# 年度标定
# ------------------------------------------------------------
# 两个标定系数, 均用四年后验均值点求解, 使代理精确复现 MCMC 阶段已验证的观测量:
#   f_mulch : 地膜对土壤蒸发的有效抑制系数  -> 使 Es 匹配实测
#   k_B     : 生物量比例因子                -> 使 Y13 匹配实测
#             目标生物量由 AquaCrop 硬关系反推: B = Y13_obs * 0.87 / HI0
# ============================================================
CALIB: dict[int, dict[str, float]] = {}


_CC_OBS_FILE = Path(__file__).resolve().parent / "inputs" / "DI_2019_2022_FIELD_LAI_CC_LOCKED.csv"


def load_cc_obs(year: int) -> tuple[np.ndarray, np.ndarray]:
    """读田间 LAI 导出的 CC 观测, 返回 (相对模拟起点的天数, CC 观测值)."""
    if not _CC_OBS_FILE.exists():
        return np.array([]), np.array([])
    df = pd.read_csv(_CC_OBS_FILE)
    df.columns = [str(c).strip().lstrip("\ufeff") for c in df.columns]
    df["Date"] = pd.to_datetime(df["Date"])
    sub = df[(df.Year == year) & (df.Crop == "Maize")]
    if sub.empty:
        return np.array([]), np.array([])
    plant = pd.Timestamp(YEAR_DATA[year]["plant"])
    t = ((sub["Date"] - plant).dt.days).to_numpy()
    return t, sub["Field_CC"].to_numpy(float)


def solve_k_cgc(year: int) -> float:
    """网格搜索 CGC 日历日校正系数, 使代理 CC 序列匹配田间观测.

    后验 `CGC_CD` 以 calendar-day 为基准, 与 FAO-66 的 GDD 基准存在换算差异;
    实测有效增长率约 0.040/天, 而后验值约 0.096/天 (约 2 倍)。
    该系数只是一个整体缩放 (不影响 CGC 的敏感性方向), 由独立观测反推。
    """
    t_obs, cc_obs = load_cc_obs(year)
    if len(t_obs) == 0:
        return 1.0
    n = YEAR_DATA[year]["n_days"]
    ok = (t_obs >= 0) & (t_obs < n)
    t_obs, cc_obs = t_obs[ok], cc_obs[ok]
    if len(t_obs) < 3:
        return 1.0
    best, best_rmse = 1.0, np.inf
    for k in np.arange(0.15, 2.001, 0.01):
        cc = _raw_simulate(REFERENCE_MEAN[year], year, k_cgc=float(k))["cc_series"]
        rmse = float(np.sqrt(np.mean((cc[t_obs] - cc_obs) ** 2)))
        if rmse < best_rmse:
            best, best_rmse = float(k), rmse
    return best


def _solve_a_cc(year: int, f_mulch: float, k_cgc: float = 1.0) -> float:
    """二分求解 a_cc, 使后验均值点 Tr 复现实测 (Tr 随 a_cc 单调递减)."""
    ref, obs = REFERENCE_MEAN[year], YEAR_DATA[year]
    target = obs["tr_obs"]
    lo, hi = 0.0, 0.85
    for _ in range(45):
        mid = 0.5 * (lo + hi)
        tr = _raw_simulate(ref, year, f_mulch=f_mulch, a_cc=mid,
                           k_cgc=k_cgc)["Tr_mm"]
        if tr > target:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def _solve_f_mulch(year: int, a_cc: float, k_cgc: float = 1.0) -> float:
    """二分求解 f_mulch, 使后验均值点 Es 复现实测 (Es 随 f_mulch 单调递增)."""
    ref, obs = REFERENCE_MEAN[year], YEAR_DATA[year]
    target = obs["es_obs"]
    lo, hi = 0.02, 5.0
    for _ in range(45):
        mid = 0.5 * (lo + hi)
        es = _raw_simulate(ref, year, f_mulch=mid, a_cc=a_cc,
                           k_cgc=k_cgc)["Es_mm"]
        if es < target:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def calibrate_all(verbose: bool = False, iters: int = 4,
                  ) -> dict[int, dict[str, float]]:
    """求解四年三个标定系数.

    a_cc 与 f_mulch 通过根区水量平衡(Ks)耦合, 故交替二分迭代; k_B 最后用
    AquaCrop 硬关系反推的目标生物量求解。三个系数只做"整体量级对齐",
    不改变响应面的物理形态(单调性与交互结构由 AquaCrop 方程保证)。
    """
    for year in sorted(REFERENCE_MEAN):
        ref, obs = REFERENCE_MEAN[year], YEAR_DATA[year]
        # k_cgc 只影响冠层模块, 可独立求解 (CC 不受 a_cc / f_mulch 影响)
        k_cgc = solve_k_cgc(year)
        a_cc, f_mulch = 0.10, 0.50
        for _ in range(iters):
            a_cc = _solve_a_cc(year, f_mulch, k_cgc)
            f_mulch = _solve_f_mulch(year, a_cc, k_cgc)
        raw = _raw_simulate(ref, year, f_mulch=f_mulch, a_cc=a_cc, k_cgc=k_cgc)
        # AquaCrop 硬关系: Y13 = HI0 * B / 0.87  =>  B = Y13 * 0.87 / HI0
        b_target = obs["y13_obs"] * 0.87 / ref["HI0"]
        k_B = b_target / raw["B_t_ha"] if raw["B_t_ha"] > 1e-9 else 1.0
        CALIB[year] = dict(k_cgc=k_cgc, a_cc=a_cc, f_mulch=f_mulch, k_B=k_B)
        if verbose:
            print(f"  {year}: k_cgc={k_cgc:.4f}  a_cc={a_cc:.4f}  "
                  f"f_mulch={f_mulch:.4f}  k_B={k_B:.4f}")
    return CALIB


def simulate(params: dict, year: int, irrigation=None,
             et0=None, rain=None, calibrated: bool = True) -> dict:
    """运行 AquaCrop 日尺度模型 (标定版).

    params: dict, 需含 CCx, CGC_CD, CDC_CD, SenescenceCD, Kcb, WP_early, WP_late, HI0
    year:   2019..2022
    irrigation: 可选自定义灌溉时间表 [(date_str, mm), ...]; None 用该年实际表
    calibrated: True 应用年度标定 (使后验均值点精确复现观测)

    返回 dict: Y_dry, Y_13pct, B_t_ha, Tr_mm, Es_mm, ET_mm, Irr_mm, Rain_mm,
               WP_ET, WP_Irr, MaxCC, mean_Ks, cc_series, wp_series
    """
    if not CALIB:
        calibrate_all()
    c = CALIB.get(year, dict(k_cgc=1.0, a_cc=0.0, f_mulch=0.25, k_B=1.0))
    r = _raw_simulate(params, year, irrigation=irrigation, et0=et0, rain=rain,
                      f_mulch=c["f_mulch"], a_cc=c["a_cc"], k_cgc=c["k_cgc"])
    if calibrated:
        r["B_t_ha"] *= c["k_B"]
        r["Y_dry"] = params["HI0"] * r["B_t_ha"]
        r["Y_13pct"] = r["Y_dry"] / 0.87
        r["WP_ET"] = r["Y_13pct"] / (r["ET_mm"] / 1000.0) if r["ET_mm"] > 1e-6 else 0.0
        r["WP_Irr"] = r["Y_13pct"] / (r["Irr_mm"] / 1000.0) if r["Irr_mm"] > 1e-6 else 0.0
    return r

def validate_against_observations(verbose: bool = True) -> dict:
    """用四年后验均值点跑代理, 与实测对比 (必须复现)."""
    rows = []
    for y in sorted(REFERENCE_MEAN):
        r = simulate(REFERENCE_MEAN[y], y)
        o = YEAR_DATA[y]
        rows.append(dict(
            Year=y,
            Y13_sim=r["Y_13pct"], Y13_obs=o["y13_obs"],
            Y13_err_pct=100 * (r["Y_13pct"] / o["y13_obs"] - 1),
            B_sim=r["B_t_ha"], B_obs=o["b_obs"],
            B_err_pct=100 * (r["B_t_ha"] / o["b_obs"] - 1),
            Tr_sim=r["Tr_mm"], Tr_obs=o["tr_obs"],
            Tr_err_pct=100 * (r["Tr_mm"] / o["tr_obs"] - 1),
            Es_sim=r["Es_mm"], Es_obs=o["es_obs"],
            Es_err_pct=100 * (r["Es_mm"] / o["es_obs"] - 1),
            ET_sim=r["ET_mm"], ET_obs=o["et_obs"],
            ET_err_pct=100 * (r["ET_mm"] / o["et_obs"] - 1),
            Irr_sim=r["Irr_mm"], Irr_obs=o["irr_obs"],
        ))
        if verbose:
            rr = rows[-1]
            print(f"{y}: Y13 {rr['Y13_sim']:.3f} vs {rr['Y13_obs']:.3f} ({rr['Y13_err_pct']:+.2f}%) | "
                  f"Tr {rr['Tr_sim']:.1f} vs {rr['Tr_obs']:.1f} ({rr['Tr_err_pct']:+.2f}%) | "
                  f"Es {rr['Es_sim']:.1f} vs {rr['Es_obs']:.1f} ({rr['Es_err_pct']:+.2f}%) | "
                  f"ET {rr['ET_sim']:.1f} vs {rr['ET_obs']:.1f} ({rr['ET_err_pct']:+.2f}%)")
    return {"rows": rows}


if __name__ == "__main__":
    print("=" * 70)
    print("AquaCrop 代理模型: 四年后验均值点 vs 实测")
    print("=" * 70)
    print("标定系数:")
    calibrate_all(verbose=True)
    print()
    validate_against_observations()
