# -*- coding: utf-8 -*-
"""DI 玉米 MCMC 后续工作 —— 一键运行脚本 (PyCharm: 直接 Run).

依次执行:
    阶段 A  整合 2019-2022 四年 MCMC 后验
    阶段 B  Sobol 全局敏感性分析 (后验轨 + 先验轨 + 校准吸收率 CAI)
    阶段 C  NSGA-III 稳健多目标灌溉制度优化
    阶段 D  四年时序分析 + 跨年迁移矩阵

用法
----
1) 直接把本文件所在文件夹拷进 PyCharm 项目, 直接 Run 本文件.
2) 若要用真实 AquaCropOSPy 复算(推荐定稿前做一次), 见下方 USE_REAL_AQUACROP.

依赖:  numpy pandas matplotlib scipy "SALib>=1.5" "pymoo>=0.6"
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

# ============================================================================
# >>>>>>>>>>>>>>>>>>>>>>  用户配置区 (按需修改)  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# ============================================================================
# 四个 MCMC 结果 zip 所在目录
DATA_DIR = Path(r"C:/Users/WWYYZZ/Desktop/urp")

# 四个 zip 的文件名 (注意: 交付的 zip 文件名与内容年份是交叉的, 脚本会自动识别)
ZIP_FILES = {
    2019: DATA_DIR / "2019phase2_and_review_results.zip",
    2020: DATA_DIR / "phase2_and_review_results2020.zip",
    2021: DATA_DIR / "DI_2021_COMPLETE_2000_CHAIN_REVIEW_PACKAGE.zip",
    2022: DATA_DIR / "MCMC_Article_Results_2022.zip",
}

# 结果输出目录
OUT_DIR = Path(__file__).resolve().parent / "output"

# ---------------------------------------------------------------------------
# 真实 AquaCropOSPy 接入开关
# ---------------------------------------------------------------------------
# False (默认): 用内置的 AquaCrop 简化代理模型. 任何机器都能跑, 约 5-6 分钟.
# True        : 用项目里真实的 AquaCropOSPy 模型复算. 需要填 REAL_PROJECT_DIR.
#
# 真实模型的调用方式(来自你原有的 DI_2019_PHASE2_AND_REVIEW_ONE_CLICK.py):
#     m, data, start, folder = runner.load('2019', out)
#     s, g, cc, bio = m.simulate(data, params_dict, 'DI')
#     y13 = s['Y_13pct'];  tr = s['Tr_mm'];  es = s['Es_mm']; ...
#
# 接入方法: 把 REAL_PROJECT_DIR 指到含 DI_2019_MCMC_ONE_CLICK.py + data/ 的目录,
#          然后实现下面的 real_simulate() 骨架(约 20 行).
USE_REAL_AQUACROP = False
REAL_PROJECT_DIR = Path(r"C:/Users/Lenovo/PycharmProjects/PythonProject/DI_2019_OneClick")

# Sobol 采样点数. 代理模型可用 512; 真实模型建议降到 128 (真实模型慢 ~1000 倍)
SOBOL_N = 512

# ============================================================================
# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# ============================================================================

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def real_simulate(params: dict, year: int, irrigation=None) -> dict:
    """真实 AquaCropOSPy 适配器骨架.

    需要你按项目实际情况补全. 思路:
      1) 首次调用时加载该年模型 (m, data, start, folder), 缓存起来;
      2) 把 params 转成模型需要的字典 (键名与 PHASE1_NAMES + PHASE2_NAMES 一致);
      3) 若给了 irrigation, 需要改写模型内 CFG['irrigation'] 后再模拟;
      4) 从返回的 s 里取出 Y_13pct / Tr_mm / Es_mm / ET_mm / Irr_mm 等, 组装成
         与本文件下方 aquacrop_surrogate.simulate 相同的返回字典.

    参考实现(需按你的 model.py 接口微调):

        import importlib.util
        if state.get('m') is None:
            src = REAL_PROJECT_DIR / f'DI_{year}_MCMC_ONE_CLICK.py'
            spec = importlib.util.spec_from_file_location(f'di{year}', src)
            mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            runner = mod._embedded_module('runner')
            m, data, start, folder = runner.load(str(year), OUT_DIR)
            state.update(m=m, data=data, start=start, folder=folder)
        m, data = state['m'], state['data']
        full = dict(state['start'], **params)
        s, g, cc, bio = m.simulate(data, full, 'DI')
        return dict(Y_13pct=s['Y_13pct'], Tr_mm=s['Tr_mm'], Es_mm=s['Es_mm'],
                    ET_mm=s['ET_mm'], Irr_mm=s.get('Irrigation_mm', 0.0),
                    B_t_ha=s['B_last'], Y_dry=s['Y_dry'],
                    WP_Irr=s['Y_13pct'] / (s.get('Irrigation_mm', 1) / 1000.0),
                    MaxCC=s.get('MaxCC', 0.0))

    注意: BOX 里的灌溉时间表改写需要你确认 model.py 暴露的入口.
    """
    raise NotImplementedError(
        "USE_REAL_AQUACROP=True 时请在 real_simulate() 中补全真实模型调用, "
        "或先保持 USE_REAL_AQUACROP=False 使用内置代理模型."
    )


def patch_model_if_needed():
    """若开启真实模型, 把代理的 simulate 替换为真实适配器."""
    import aquacrop_surrogate
    if USE_REAL_AQUACROP:
        if not REAL_PROJECT_DIR.exists():
            raise FileNotFoundError(f"REAL_PROJECT_DIR 不存在: {REAL_PROJECT_DIR}")
        aquacrop_surrogate.simulate = real_simulate
        print("[配置] 使用真实 AquaCropOSPy 模型")
    else:
        print("[配置] 使用内置 AquaCrop 代理模型 (物理一致, 已用四年实测标定)")


def run_phase(name: str, fn, t0: float) -> None:
    print("\n" + "#" * 74)
    print(f"#  {name}")
    print("#" * 74)
    fn()
    print(f"\n[{name}] 用时 {time.time() - t0:.1f}s")


def main():
    t_all = time.time()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print("=" * 74)
    print("DI 玉米 MCMC 后续工作: Sobol + NSGA-III + 四年时序分析")
    print("=" * 74)

    patch_model_if_needed()

    # ---------- 阶段 A ----------
    t0 = time.time()
    import phaseA_merge_posterior as A
    missing = [y for y, p in ZIP_FILES.items() if not p.exists()]
    if missing:
        print(f"[阶段 A] 以下 zip 不存在, 将跳过: {missing}")
    A.ZIP_FILES = ZIP_FILES
    A.OUT_DIR = OUT_DIR
    A.OUT_DIR.mkdir(parents=True, exist_ok=True)
    run_phase("阶段 A  整合四年 MCMC 后验", A.main, t0)

    # ---------- 阶段 B ----------
    t0 = time.time()
    import phaseB_sobol as B
    B.OUT = OUT_DIR
    B.N_SAMPLE = SOBOL_N
    run_phase("阶段 B  Sobol 全局敏感性分析", B.main, t0)

    # ---------- 阶段 C ----------
    t0 = time.time()
    import phaseC_nsga3 as C
    C.OUT = OUT_DIR
    run_phase("阶段 C  NSGA-III 稳健多目标优化", C.main, t0)

    # ---------- 阶段 D ----------
    t0 = time.time()
    import phaseD_timeseries as D
    D.OUT = OUT_DIR
    run_phase("阶段 D  四年时序分析", D.main, t0)

    print("\n" + "=" * 74)
    print(f"全部完成 ✅  总用时 {time.time() - t_all:.1f}s")
    print(f"结果目录: {OUT_DIR}")
    print("=" * 74)


if __name__ == "__main__":
    main()
