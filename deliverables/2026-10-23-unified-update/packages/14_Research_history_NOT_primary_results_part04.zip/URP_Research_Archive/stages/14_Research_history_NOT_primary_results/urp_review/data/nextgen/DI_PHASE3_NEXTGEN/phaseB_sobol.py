# -*- coding: utf-8 -*-
"""阶段 B: Sobol 全局敏感性分析 (双轨).

轨道 B1 (Bayesian Sobol, 创新点):
    输入分布 = MCMC 校准后的后验边际区间 (按年).
    回答: "在已被数据约束的参数空间里, 哪些参数仍主导产量/水分的不确定性?"
轨道 B2 (Prior Sobol, 对照):
    输入分布 = 原始均匀先验边界.
    回答: "在无信息先验下, 模型对哪些参数最敏感?" (与传统文献可比)

关键导出指标 -- 校准吸收率 CAI (Calibration Absorption Index):
    CAI_i = (ST_prior_i - ST_bayes_i) / ST_prior_i
    CAI > 0 : 校准把该参数的不确定性"吸收"了 (数据约束强, 已充分识别)
    CAI < 0 : 校准后反而更敏感 (后验区间内变化仍强烈影响输出, 需重点报告)
    CAI 是本项目相对传统 Sobol 的方法学增量.

输出: sobol_indices.csv, sobol_CAI.csv, 3 张图 + JSON.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from SALib.sample import sobol as sobol_sample
from SALib.analyze import sobol as sobol_analyze_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aquacrop_surrogate as A

# ---- 中文字体 ----
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DengXian", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

OUT = Path(__file__).resolve().parent / "output"
OUT.mkdir(exist_ok=True)

PARAM_NAMES = A.PARAM_NAMES
PRIOR_BOUNDS = A.PRIOR_BOUNDS
YEARS = [2019, 2020, 2021, 2022]
OUTPUTS = {
    "Y_13pct": "产量 (t/ha, 13%含水率)",
    "ET_mm": "季总耗水量 ET (mm)",
    "WP_Irr": "灌溉水生产率 (kg/m³)",
    "Tr_mm": "季总蒸腾 Tr (mm)",
}
N_SAMPLE = 512          # Sobol 基样本数 -> N*(2D+2) 次模拟


def posterior_bounds(year: int) -> dict[str, tuple[float, float]]:
    """从阶段 A 的输出读该年的后验边际区间 (0.5%~99.5% 分位)."""
    f = OUT / "posterior_input_distributions.csv"
    if not f.exists():
        raise FileNotFoundError("请先运行 phaseA_merge_posterior.py")
    df = pd.read_csv(f)
    d = df[df.Year == year].set_index("Parameter")
    return {k: (float(d.loc[k, "Lo"]), float(d.loc[k, "Hi"])) for k in PARAM_NAMES if k in d.index}


def make_problem(bounds: dict[str, tuple[float, float]], names=None) -> dict:
    names = names or PARAM_NAMES
    return dict(
        num_vars=len(names),
        names=list(names),
        bounds=[list(bounds[k]) for k in names],
    )


def evaluate(X: np.ndarray, year: int) -> dict[str, np.ndarray]:
    """批量运行模型, 返回 {输出名: 数组}."""
    res = {k: np.empty(len(X)) for k in OUTPUTS}
    for i, row in enumerate(X):
        p = dict(zip(PARAM_NAMES, row))
        r = A.simulate(p, year)
        for k in OUTPUTS:
            res[k][i] = r[k]
    return res


def run_track(year: int, bounds: dict, track: str) -> pd.DataFrame:
    """跑一条轨道 (4 个输出)."""
    problem = make_problem(bounds)
    X = sobol_sample.sample(problem, N_SAMPLE, calc_second_order=False)
    print(f"  采样 {X.shape[0]} 点, 开始模拟 ...", flush=True)
    t0 = time.time()
    Y = evaluate(X, year)
    print(f"  模拟完成 {time.time() - t0:.1f}s", flush=True)

    rows = []
    for out_name in OUTPUTS:
        y = Y[out_name]
        if np.std(y) < 1e-12:
            print(f"    !! {out_name} 输出无变异, 跳过")
            continue
        Si = sobol_analyze_module.analyze(problem, y, calc_second_order=False,
                                          print_to_console=False)
        for j, pname in enumerate(PARAM_NAMES):
            rows.append(dict(
                Year=year, Track=track, Output=out_name,
                Output_label=OUTPUTS[out_name],
                Parameter=pname,
                S1=float(Si["S1"][j]),
                S1_conf=float(Si["S1_conf"][j]),
                ST=float(Si["ST"][j]),
                ST_conf=float(Si["ST_conf"][j]),
            ))
    return pd.DataFrame(rows)


def main():
    print("=" * 66)
    print("阶段 B: Sobol 全局敏感性分析 (双轨: 后验 vs 先验)")
    print("=" * 66)

    all_rows = []
    for year in YEARS:
        print(f"\n--- {year} ---")
        pb = posterior_bounds(year)
        print(f"  后验区间 CCx={pb['CCx']}  HI0={pb['HI0']}")

        df_b = run_track(year, pb, "Bayes_posterior")
        df_p = run_track(year, PRIOR_BOUNDS, "Prior_uniform")
        all_rows += [df_b, df_p]

    df = pd.concat(all_rows, ignore_index=True)
    df.to_csv(OUT / "sobol_indices.csv", index=False, encoding="utf-8-sig")
    print(f"\n✓ sobol_indices.csv ({len(df)} rows)")

    # ---------- 校准吸收率 CAI ----------
    cai_rows = []
    for (year, out_name), g in df.groupby(["Year", "Output"]):
        b = g[g.Track == "Bayes_posterior"].set_index("Parameter")
        p = g[g.Track == "Prior_uniform"].set_index("Parameter")
        for pname in PARAM_NAMES:
            st_p = float(p.loc[pname, "ST"])
            st_b = float(b.loc[pname, "ST"])
            if abs(st_p) > 1e-9:
                cai = (st_p - st_b) / st_p
            else:
                cai = np.nan
            cai_rows.append(dict(
                Year=year, Output=out_name, Parameter=pname,
                ST_prior=st_p, ST_bayes=st_b, CAI=cai,
                Absorbed=bool(cai > 0) if np.isfinite(cai) else None,
            ))
    cai = pd.DataFrame(cai_rows)
    cai.to_csv(OUT / "sobol_CAI.csv", index=False, encoding="utf-8-sig")
    print(f"✓ sobol_CAI.csv")

    # ---------- 图 1: 四年 Y13 的 S1/ST 堆叠 (Bayes 轨) ----------
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    for ax, out_name, title in [
        (axes[0], "Y_13pct", "产量 Y13"),
        (axes[1], "ET_mm", "季总耗水 ET"),
    ]:
        sub = df[(df.Track == "Bayes_posterior") & (df.Output == out_name)]
        piv_s1 = sub.pivot(index="Parameter", columns="Year", values="S1")
        piv_st = sub.pivot(index="Parameter", columns="Year", values="ST")
        piv_s1 = piv_s1.loc[PARAM_NAMES]
        piv_st = piv_st.loc[PARAM_NAMES]
        x = np.arange(len(PARAM_NAMES))
        w = 0.17
        cmap = plt.get_cmap("tab10")
        for i, year in enumerate(YEARS):
            ax.bar(x + i * w - 1.5 * w, piv_s1[year], w,
                   label=f"{year} 一阶", color=cmap(i), alpha=0.95)
            ax.bar(x + i * w - 1.5 * w, piv_st[year] - piv_s1[year], w,
                   bottom=piv_s1[year], color=cmap(i), alpha=0.35, hatch="//")
        ax.set_xticks(x)
        ax.set_xticklabels(PARAM_NAMES, rotation=30, ha="right")
        ax.set_ylabel("Sobol 指数")
        ax.set_title(f"{title} – 后验轨道 (实心=一阶 S1, 斜纹=交互 ST−S1)")
        ax.grid(axis="y", alpha=0.3)
    axes[0].legend(fontsize=8, ncol=2)
    fig.suptitle("四年 Sobol 敏感性指数（输入分布 = MCMC 校准后验）", fontsize=13)
    fig.tight_layout()
    fig.savefig(OUT / "fig_sobol_S1_ST.png", dpi=150)
    plt.close(fig)
    print("✓ fig_sobol_S1_ST.png")

    # ---------- 图 2: Bayes vs Prior (ST 对比, 四年平均) ----------
    st = df[df.Output == "Y_13pct"].groupby(["Track", "Parameter"])["ST"].mean()
    pb = st.loc["Bayes_posterior"].reindex(PARAM_NAMES)
    pp = st.loc["Prior_uniform"].reindex(PARAM_NAMES)
    fig, ax = plt.subplots(figsize=(10, 5))
    x = np.arange(len(PARAM_NAMES))
    ax.bar(x - 0.2, pp, 0.4, label="先验轨道 ST (无信息)", color="#8FAADC", edgecolor="k", lw=0.5)
    ax.bar(x + 0.2, pb, 0.4, label="后验轨道 ST (已校准)", color="#C00000", edgecolor="k", lw=0.5)
    for i in range(len(PARAM_NAMES)):
        ax.plot([i - 0.2, i + 0.2], [pp.iloc[i], pb.iloc[i]], "k--", lw=0.8, alpha=0.6)
    ax.set_xticks(x)
    ax.set_xticklabels(PARAM_NAMES, rotation=30, ha="right")
    ax.set_ylabel("总效应指数 ST")
    ax.set_title("产量 Y13：校准如何改变参数重要性\n（虚线下降 = 校准吸收了不确定性；上升 = 校准后更敏感）")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT / "fig_sobol_bayes_vs_prior.png", dpi=150)
    plt.close(fig)
    print("✓ fig_sobol_bayes_vs_prior.png")

    # ---------- 图 3: ST 热图 (参数 × 年份, Bayes 轨, Y13) ----------
    sub = df[(df.Track == "Bayes_posterior") & (df.Output == "Y_13pct")]
    piv = sub.pivot(index="Parameter", columns="Year", values="ST").reindex(PARAM_NAMES)
    fig, ax = plt.subplots(figsize=(8, 5))
    im = ax.imshow(piv.values, cmap="YlOrRd", aspect="auto", vmin=0)
    ax.set_xticks(range(len(YEARS)))
    ax.set_xticklabels(YEARS)
    ax.set_yticks(range(len(PARAM_NAMES)))
    ax.set_yticklabels(PARAM_NAMES)
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            v = piv.values[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center",
                    color="white" if v > 0.5 else "black", fontsize=9)
    ax.set_title("产量 Y13 总效应指数 ST 的年际变化（后验轨道）")
    fig.colorbar(im, ax=ax, label="ST")
    fig.tight_layout()
    fig.savefig(OUT / "fig_sobol_heatmap.png", dpi=150)
    plt.close(fig)
    print("✓ fig_sobol_heatmap.png")

    # ---------- 摘要 ----------
    top = (df[(df.Track == "Bayes_posterior") & (df.Output == "Y_13pct")]
           .groupby("Parameter")["ST"].mean().sort_values(ascending=False))
    cai_y = cai[cai.Output == "Y_13pct"].groupby("Parameter")["CAI"].mean()
    summary = {
        "Note": "Bayes 轨输入分布 = MCMC 校准后验; Prior 轨 = 均匀先验. CAI>0 表示校准吸收了不确定性.",
        "Top_ST_bayes_Y13": {k: float(v) for k, v in top.items()},
        "CAI_mean_Y13": {k: float(v) for k, v in cai_y.items()},
        "Y13_variance_explained_bayes": float(top.sum()),
    }
    (OUT / "sobol_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("✓ sobol_summary.json")

    print("\n=== 产量 Y13 平均 ST 排序 (后验轨道) ===")
    for k, v in top.items():
        print(f"  {k:<14} ST={v:.4f}   CAI={cai_y.get(k, float('nan')):+.3f}")
    print("\n阶段 B 完成 ✅")


if __name__ == "__main__":
    main()
