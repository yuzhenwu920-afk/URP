# -*- coding: utf-8 -*-
"""阶段 D: 四年时序性分析.

四块内容
--------
D1 参数后验的年际漂移  : 8 个参数的四年后验分布 (小提琴图), 看哪些参数年际稳定/漂移.
D2 气候驱动归因        : WP_early / WP_late / HI0 的年际变化 vs 年降水量 / ET0 / 灌溉量.
D3 跨年迁移稳健性(创新): 把第 i 年优化出的灌溉方案, 放到第 j 年的气候与参数下评估,
                        构成 4x4 迁移矩阵. 对角线 = 逐年特定方案, 非对角 = 跨年套用.
                        量化"一套通用方案"相对"逐年定制"要付出多少产量代价.
D4 通用 vs 定制方案    : 由 D3 矩阵推荐一套四年通用灌溉方案, 并与逐年定制对比.

诚实边界: 只有 4 个年份, 不足以做严格的时序趋势检验(Mann-Kendall 等),
本阶段只做描述性比较与相关性分析, 不做趋势显著性声称.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aquacrop_surrogate as A

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DengXian", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

OUT = Path(__file__).resolve().parent / "output"
CACHE = OUT / "raw_npz_cache"
YEARS = [2019, 2020, 2021, 2022]
PARAM_NAMES = A.PARAM_NAMES
N_SAMPLE_DRAW = 2500          # 每个参数每年抽取的展示样本数


# ============================================================
# D1: 后验样本
# ============================================================
def load_draws(year: int, n: int = N_SAMPLE_DRAW, seed: int = 3) -> dict[str, np.ndarray]:
    f = CACHE / f"DI_{year}.npz"
    rng = np.random.default_rng(seed + year)
    out = {}
    d = np.load(f, allow_pickle=False)
    for j, name in enumerate(PARAM_NAMES[:5]):
        v = d["phase1"][:, j]
        out[name] = v[rng.choice(len(v), min(n, len(v)), replace=False)]
    for j, name in enumerate(PARAM_NAMES[5:]):
        v = d["phase2"][:, j]
        out[name] = v[rng.choice(len(v), min(n, len(v)), replace=False)]
    return out


def main():
    print("=" * 66)
    print("阶段 D: 四年时序性分析")
    print("=" * 66)

    draws = {y: load_draws(y) for y in YEARS}

    # ---------- D1: 小提琴图 ----------
    fig, axes = plt.subplots(2, 4, figsize=(17, 8))
    cmap = plt.get_cmap("tab10")
    for idx, name in enumerate(PARAM_NAMES):
        ax = axes[idx // 4, idx % 4]
        data = [draws[y][name] for y in YEARS]
        v = ax.violinplot(data, positions=range(len(YEARS)), showmedians=True,
                          showextrema=True)
        for i, b in enumerate(v["bodies"]):
            b.set_facecolor(cmap(i))
            b.set_alpha(0.75)
            b.set_edgecolor("black")
            b.set_linewidth(0.6)
        for part in ("cbars", "cmins", "cmaxes", "cmedians"):
            if part in v:
                v[part].set_color("black")
                v[part].set_linewidth(1.0)
        # 后验均值连线, 看漂移方向
        means = [float(np.mean(draws[y][name])) for y in YEARS]
        ax.plot(range(len(YEARS)), means, "o--", color="crimson", ms=5, lw=1.4,
                label="后验均值" if idx == 0 else None)
        ax.set_xticks(range(len(YEARS)))
        ax.set_xticklabels(YEARS)
        ax.set_title(name, fontsize=11)
        ax.grid(axis="y", alpha=0.3)
    axes[0, 0].legend(fontsize=8)
    fig.suptitle("D1  八个参数的四年后验分布与年际漂移（红线 = 后验均值轨迹）", fontsize=13)
    fig.tight_layout()
    fig.savefig(OUT / "fig_D1_posterior_drift.png", dpi=150)
    plt.close(fig)
    print("✓ fig_D1_posterior_drift.png")

    # D1 统计表
    drift_rows = []
    for name in PARAM_NAMES:
        for y in YEARS:
            v = draws[y][name]
            drift_rows.append(dict(Parameter=name, Year=y,
                                   Mean=float(np.mean(v)), SD=float(np.std(v, ddof=1)),
                                   CV_pct=float(100 * np.std(v, ddof=1) / np.mean(v)) if np.mean(v) else np.nan))
    drift = pd.DataFrame(drift_rows)
    pivot = drift.pivot(index="Parameter", columns="Year", values="Mean").reindex(PARAM_NAMES)
    spread = (pivot.max(axis=1) - pivot.min(axis=1)) / pivot.mean(axis=1) * 100
    drift_summary = pd.DataFrame(dict(
        Mean_2019=pivot[2019], Mean_2020=pivot[2020], Mean_2021=pivot[2021], Mean_2022=pivot[2022],
        Interannual_spread_pct=spread.round(2)))
    drift_summary.to_csv(OUT / "D1_parameter_drift.csv", encoding="utf-8-sig")
    print("✓ D1_parameter_drift.csv")

    # ---------- D2: 气候驱动归因 ----------
    clim = pd.DataFrame([dict(
        Year=y,
        Rain_mm=A.YEAR_DATA[y]["rain_annual"],
        ET0_mm=A.YEAR_DATA[y]["et0_annual"],
        Irr_mm=A.YEAR_DATA[y]["irr_obs"],
        Y13_obs=A.YEAR_DATA[y]["y13_obs"],
        WP_early_mean=float(np.mean(draws[y]["WP_early"])),
        WP_late_mean=float(np.mean(draws[y]["WP_late"])),
        HI0_mean=float(np.mean(draws[y]["HI0"])),
        CCx_mean=float(np.mean(draws[y]["CCx"])),
        Kcb_mean=float(np.mean(draws[y]["Kcb"])),
    ) for y in YEARS])
    clim["Aridity"] = clim.ET0_mm / clim.Rain_mm
    clim.to_csv(OUT / "D2_climate_attribution.csv", index=False, encoding="utf-8-sig")
    print("✓ D2_climate_attribution.csv")

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6))
    for ax, (pcol, pname, unit) in zip(axes, [
        ("WP_early_mean", "WP_early", "g/m²"),
        ("WP_late_mean", "WP_late", "g/m²"),
        ("HI0_mean", "HI0", "—"),
    ]):
        ax2 = ax.twinx()
        ax.plot(clim.Year, clim[pcol], "o-", color="crimson", lw=1.8, ms=7, label=pname)
        ax.set_ylabel(f"{pname} ({unit})", color="crimson")
        ax.tick_params(axis="y", labelcolor="crimson")
        ax2.bar(clim.Year, clim.Rain_mm, alpha=0.28, color="steelblue", label="降水量")
        ax2.plot(clim.Year, clim.ET0_mm, "s--", color="darkgreen", lw=1.4, label="ET0")
        ax2.set_ylabel("水分 (mm)")
        ax.set_xticks(clim.Year)
        ax.set_title(f"{pname} 年际变化 vs 水分供给")
        ax.grid(alpha=0.3)
        # 相关系数
        r_rain = np.corrcoef(clim[pcol], clim.Rain_mm)[0, 1]
        r_et0 = np.corrcoef(clim[pcol], clim.ET0_mm)[0, 1]
        ax.text(0.03, 0.94, f"r(降水)={r_rain:+.2f}\nr(ET0)={r_et0:+.2f}",
                transform=ax.transAxes, fontsize=8, va="top",
                bbox=dict(boxstyle="round", fc="wheat", alpha=0.5))
        if pcol == "WP_early":
            ax2.legend(fontsize=8, loc="lower right")
    fig.suptitle("D2  参数年际变化的水分驱动归因（n=4，仅描述性相关，不做趋势检验）", fontsize=13)
    fig.tight_layout()
    fig.savefig(OUT / "fig_D2_climate_attribution.png", dpi=150)
    plt.close(fig)
    print("✓ fig_D2_climate_attribution.png")

    # ---------- D3: 跨年迁移矩阵 (创新) ----------
    sched = pd.read_csv(OUT / "optimal_irrigation_schedule.csv")
    # 复原每年膝点方案, 并统一转成"播后第 X 天"的相对天数,
    # 否则跨年套用时绝对日期会因播期不同而错位(甚至变成负索引被丢弃).
    from datetime import date as _date
    knee_sched = {}
    for y in YEARS:
        s = sched[sched.Year == y].sort_values("Event")
        plant = _date.fromisoformat(A.YEAR_DATA[y]["plant"])
        knee_sched[y] = [((_date.fromisoformat(d) - plant).days, m)
                         for d, m in zip(s.Date.tolist(), s.Optimal_mm.tolist())]

    # 统一的后验样本生成器 (与阶段 C 完全一致: seed=7, k=8)
    def posterior_samples(year: int, k: int = 8, seed: int = 7):
        rng = np.random.default_rng(seed + year)
        d = np.load(CACHE / f"DI_{year}.npz", allow_pickle=False)
        p1, p2 = d["phase1"], d["phase2"]
        i1 = rng.integers(0, len(p1), k)
        i2 = rng.integers(0, len(p2), k)
        out = []
        for a, b in zip(i1, i2):
            v = dict(zip(PARAM_NAMES[:5], p1[a]))
            v.update(dict(zip(PARAM_NAMES[5:], p2[b])))
            out.append(v)
        return out

    post = {y: posterior_samples(y) for y in YEARS}

    M = np.zeros((4, 4))
    Mstd = np.zeros((4, 4))
    for i, y_opt in enumerate(YEARS):          # 方案来源年
        for j, y_clim in enumerate(YEARS):     # 应用年 (气候+参数)
            ys = []
            for p in post[y_clim]:
                r = A.simulate(p, y_clim, irrigation=knee_sched[y_opt])
                ys.append(r["Y_13pct"])
            M[i, j] = float(np.mean(ys))
            Mstd[i, j] = float(np.std(ys))

    migr = pd.DataFrame(M, index=[f"方案{y}" for y in YEARS],
                        columns=[f"用于{y}" for y in YEARS])
    migr.to_csv(OUT / "D3_transfer_matrix.csv", encoding="utf-8-sig")
    print("✓ D3_transfer_matrix.csv")

    fig, ax = plt.subplots(figsize=(7.2, 6))
    im = ax.imshow(M, cmap="RdYlGn", aspect="auto")
    ax.set_xticks(range(4))
    ax.set_xticklabels([f"{y}" for y in YEARS])
    ax.set_yticks(range(4))
    ax.set_yticklabels([f"{y}" for y in YEARS])
    ax.set_xlabel("应用年份（气候 + 参数）")
    ax.set_ylabel("方案来源年份")
    for i in range(4):
        for j in range(4):
            ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center",
                    fontsize=10, fontweight="bold" if i == j else "normal",
                    color="black")
    ax.set_title("D3  灌溉方案跨年迁移矩阵 (产量 t/ha)\n对角=逐年定制, 非对角=跨年套用")
    fig.colorbar(im, ax=ax, label="Y13 (t/ha)")
    fig.tight_layout()
    fig.savefig(OUT / "fig_D3_transfer_matrix.png", dpi=150)
    plt.close(fig)
    print("✓ fig_D3_transfer_matrix.png")

    diag = np.diag(M)
    # 通用方案 = 使四年平均产量最高的那一行
    row_mean = M.mean(axis=1)
    best_universal = YEARS[int(np.argmax(row_mean))]
    universal_mean = float(row_mean.max())
    custom_mean = float(diag.mean())
    transfer_loss = custom_mean - universal_mean

    # ---------- D4: 通用 vs 定制 ----------
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    ax = axes[0]
    x = np.arange(4)
    w = 0.38
    ax.bar(x - w / 2, diag, w, label="逐年定制方案", color="#C00000", edgecolor="k", lw=0.5)
    ax.bar(x + w / 2, M[YEARS.index(best_universal)], w,
           label=f"通用方案 (来自 {best_universal})", color="#8FAADC", edgecolor="k", lw=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels(YEARS)
    ax.set_ylabel("产量 Y13 (t/ha)")
    ax.set_title(f"D4  逐年定制 vs 一套通用\n"
                 f"定制均值={custom_mean:.3f}  通用均值={universal_mean:.3f}  "
                 f"通用代价={transfer_loss:.3f} t/ha ({100*transfer_loss/custom_mean:.2f}%)")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)

    ax = axes[1]
    loss_per_year = diag - M[YEARS.index(best_universal)]
    ax.bar(YEARS, loss_per_year, color=["#C00000" if v > 0 else "#2E7D32" for v in loss_per_year],
           edgecolor="k", lw=0.5)
    ax.axhline(0, color="k", lw=0.8)
    ax.set_ylabel("通用方案相对定制的产量差 (t/ha)")
    ax.set_title("通用方案在各年的产量代价\n（负值=通用方案反而更好）")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT / "fig_D4_universal_vs_custom.png", dpi=150)
    plt.close(fig)
    print("✓ fig_D4_universal_vs_custom.png")

    summary = dict(
        D1_interannual_spread_pct={k: float(v) for k, v in spread.items()},
        D2_climate=clim.to_dict("records"),
        D3_transfer_matrix={f"scheme_{YEARS[i]}": {f"year_{YEARS[j]}": float(M[i, j])
                                                   for j in range(4)} for i in range(4)},
        D3_diag_mean=custom_mean,
        D3_best_universal_year=int(best_universal),
        D3_universal_mean=universal_mean,
        D3_transfer_loss_t_ha=float(transfer_loss),
        D3_transfer_loss_pct=float(100 * transfer_loss / custom_mean),
        D4_loss_per_year={int(YEARS[i]): float(loss_per_year[i]) for i in range(4)},
        Caveat="n=4 年, 仅描述性比较与相关分析, 未做趋势显著性检验.",
    )
    (OUT / "D_timeseries_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("✓ D_timeseries_summary.json")

    print("\n=== D1 参数年际离散度 (极差/均值, %) ===")
    print(spread.sort_values(ascending=False).round(2).to_string())
    print(f"\n=== D3 跨年迁移 ===")
    print(migr.round(3).to_string())
    print(f"\n推荐通用方案: {best_universal} 年方案")
    print(f"  定制均值 {custom_mean:.3f} vs 通用均值 {universal_mean:.3f} t/ha")
    print(f"  通用代价 {transfer_loss:.3f} t/ha ({100*transfer_loss/custom_mean:.2f}%)")
    print("\n阶段 D 完成 ✅")


if __name__ == "__main__":
    main()
