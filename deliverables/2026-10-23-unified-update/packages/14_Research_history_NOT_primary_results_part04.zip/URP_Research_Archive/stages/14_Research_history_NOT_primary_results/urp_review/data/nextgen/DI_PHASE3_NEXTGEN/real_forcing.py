# -*- coding: utf-8 -*-
"""真实逐日气象驱动 (替换原先的合成气象).

数据来源: `inputs/DI_Climate_YYYY_FINAL.csv` (逐日 Tmin/Tmax/Precip/ETo, 全年 365 天)

两个必须处理的细节 (已由年度总量反推校验通过):

1) **生长季窗口** —— 气候文件是全年数据, 而模型只模拟生长季。
   窗口起点与天数取自各年结果包内 `preflight.json` 的 **"Dates" 字段(最权威)**,
   并用 "Old_ETo 年度总量" 与 "降水年度总量" 双重匹配交叉校验:

       | 年   | 窗口起点   | 天数 | Old_ETo  | 匹配 audit | 降水    | 匹配模型 | preflight.Dates |
       |------|-----------|------|----------|-----------|---------|----------|-----------------|
       | 2019 | 2019-04-18| 151  | 519.302  | 519.302224 ✓ | 177.869 | 177.869 ✓ | 04-18~09-15 ✓ |
       | 2020 | 2020-04-20| 152  | 536.294  | 536.293971 ✓ | 113.465 | 113.465 ✓ | 04-20~09-18 ✓ |
       | 2021 | 2021-04-27| 148  | 519.276  | 519.275598 ✓ | 143.323 | 143.323 ✓ | 04-27~09-21 ✓ |
       | 2022 | 2022-04-17| 148  | 521.941  | (无 audit)   | 151.384 | 151.384 ✓ | 04-17~09-11 ✓ |

   注意 2021/2022 的模拟起点与播种日不同; WP 切换日(Switch)各年为
   83 / 85 / 77 / 79 天, 亦取自 preflight.json。

2) **ETo 风速纠偏** —— 气候文件里的 ETo 列是**纠偏前**的 Old_ETo
   (2019: 519.302 = audit.Old_ETo_mm 519.302224), 而模型实际使用
   逐小时标量风速纠偏后的 B_ETo (2019: 595.622895)。
   因缺逐小时风速, 这里按**年度常数比例**缩放:
       ETo_corrected = Old_ETo_daily × (B_ETo_annual / Old_ETo_annual)
   2019–2021 的因子由 audit 直接给出; 2022 无 audit, 取三年均值。
   ⚠ 残余不确定性: 纠偏在日内并非均匀, 本近似保留约 ±1–2% 的日尺度误差。
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"

YEARS = (2019, 2020, 2021, 2022)
CLIMATE_FILES = {y: INPUTS / f"DI_Climate_{y}_FINAL.csv" for y in YEARS}

# 模型实际模拟窗口 (起点, 天数)
# 权威来源: 各年结果包内 preflight.json 的 "Dates" 字段, 四年完全一致
WINDOWS = {
    2019: ("2019-04-18", 151),   # preflight: 2019-04-18 ~ 2019-09-15
    2020: ("2020-04-20", 152),   # preflight: 2020-04-20 ~ 2020-09-18
    2021: ("2021-04-27", 148),   # preflight: 2021-04-27 ~ 2021-09-21
    2022: ("2022-04-17", 148),   # preflight: 2022-04-17 ~ 2022-09-11
}

# ETo 风速纠偏因子 = B_ETo / Old_ETo
ETO_SCALE = {
    2019: 595.622895 / 519.302224,   # 1.146968
    2020: 632.258270 / 536.293971,   # 1.178940
    2021: 612.930889 / 519.275598,   # 1.180358
    2022: None,                       # 无 audit, 运行时取三年均值
}

_AUDIT_OLD = {2019: 519.302224, 2020: 536.293971, 2021: 519.275598}
_AUDIT_B = {2019: 595.622895, 2020: 632.258270, 2021: 612.930889}
_AUDIT_RAIN = {2019: 177.868755, 2020: 113.464779, 2021: 143.32285, 2022: 151.383806}

_cache: dict[int, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}


def _scale(year: int) -> float:
    if ETO_SCALE.get(year) is not None:
        return float(ETO_SCALE[year])
    vals = [ETO_SCALE[y] for y in (2019, 2020, 2021)]
    return float(np.mean(vals))


def load_forcing(year: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """返回 (dates, et0_corrected_mm, rain_mm), 长度 = 该年生长季天数."""
    if year in _cache:
        return _cache[year]

    f = CLIMATE_FILES[year]
    if not f.exists():
        raise FileNotFoundError(f"缺少气象文件: {f}")

    df = pd.read_csv(f)
    df.columns = [str(c).strip().lstrip("\ufeff") for c in df.columns]
    df["date"] = pd.to_datetime(df["date"])

    start, n = WINDOWS[year]
    sub = df[df["date"] >= start].head(n)
    if len(sub) != n:
        raise RuntimeError(f"{year} 窗口天数不足: {len(sub)} != {n}")

    dates = sub["date"].to_numpy()
    et0 = sub["ETo_mm"].to_numpy(float) * _scale(year)
    rain = sub["Precip_mm"].to_numpy(float)

    _cache[year] = (dates, et0, rain)
    return _cache[year]


def et0_daily(year: int) -> np.ndarray:
    return load_forcing(year)[1]


def rain_daily(year: int) -> np.ndarray:
    return load_forcing(year)[2]


def year_summary() -> pd.DataFrame:
    """核验表: 真实驱动的年度总量 vs 模型 audit 值."""
    rows = []
    for y in YEARS:
        _, et0, rain = load_forcing(y)
        rows.append(dict(
            Year=y, Window=f"{WINDOWS[y][0]} +{WINDOWS[y][1]}d", Days=len(et0),
            ETo_corrected=float(et0.sum()),
            ETo_audit_B=_AUDIT_B.get(y, np.nan),
            ETo_match=(abs(et0.sum() - _AUDIT_B[y]) < 0.05) if y in _AUDIT_B else None,
            Rain=float(rain.sum()), Rain_audit=_AUDIT_RAIN.get(y, np.nan),
            Rain_match=abs(rain.sum() - _AUDIT_RAIN[y]) < 0.5,
            ETo_scale=_scale(y),
        ))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    print("=" * 96)
    print("真实逐日气象驱动 —— 年度总量核验")
    print("=" * 96)
    df = year_summary()
    print(df.to_string(index=False))
    print()
    print("逐日样本 (2019 前 5 天):")
    d, e, r = load_forcing(2019)
    for i in range(5):
        print(f"  {pd.Timestamp(d[i]).date()}  ETo={e[i]:6.3f}  Rain={r[i]:6.3f}")
    print()
    print("对比: 原先合成气象用季节钟形曲线 + 随机暴雨; 现在为真实观测序列。")
