"""Fresh-process check against original kernels, with no numerical install."""
from pathlib import Path
import os,sys,json,importlib.util
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1];PROJECT=R/'model_snapshots/DI_PHASE3_NEXTGEN_UPDATED';PARENT=R/'dependencies/2021_fmulch'
os.environ['URP_PROJECT']=str(PROJECT);sys.path.insert(0,str(PARENT/'code'))
from scenario_engine import Engine
def main():
    results=[];cases=[f'old_{y}' for y in range(2019,2023)]+['new_fm050','new_fm075','new_fm085']
    names=[f'Window{i}_mm' for i in range(1,5)]
    for case in cases:
        source=pd.read_csv(R/'runs'/case/'seed31/per_target_results.csv');target=source[source.Target_ID.eq('Observed_0.95')].sort_values('Irrigation_mm').iloc[0]
        ident=json.loads((R/'runs'/case/'seed31/IDENTITY.json').read_text());base=np.array(ident['Decision_space']['baseline_amounts'])
        if case.startswith('old'):
            year=int(case[-4:]);spec=importlib.util.spec_from_file_location('original_kernel_adapter',PROJECT/'real_model/four_year_adapter.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
            def run(x):return a.simulate(params=ident['Parameters'],year=year,management=dict(kind='stage_amounts',values=dict(zip(names,x))),accelerate=False)
            e=None
        else:
            e=Engine(case[4:],False,tag='single_objective_unaccelerated');e.install()
            def run(x):return e.run(x)
        try:
            for label,x in [('DI',base),('Independent_95pct_candidate',target[names].to_numpy(float))]:
                s=run(x)
                if label=='DI':
                    state=json.loads((R/'runs'/case/'seed31/STATUS.json').read_text());expected=state['Baseline']
                else:expected=target
                fields=['Y_13pct','Irrigation_mm','ET_mm','Profile_final_mm'];delta=max(abs(s[k]-expected[k]) for k in fields);assert delta<1e-8,(case,label,delta)
                results.append(dict(Case=case,Control=label,Maximum_absolute_difference=delta))
        finally:
            if e:e.restore()
    out=dict(Status='PASS',Original_unaccelerated_replays=len(results),No_project_numerical_acceleration_install=True,Maximum_difference=max(x['Maximum_absolute_difference'] for x in results),Results=results)
    (R/'verification/UNACCELERATED_CHECK.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
