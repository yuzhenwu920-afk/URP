"""Threshold minima from explicitly declared finite archives, plus full replays."""
from pathlib import Path
import json,hashlib,time
import numpy as np
import pandas as pd
from exact_engine import ExactEngine,R
from run_comparison import CASES,ALGOS,SEEDS,OBS
CONTROL=[f'Window{i}_mm' for i in range(1,5)]

def choose(a,target):
    f=a[a.Y_13pct.ge(target-1e-9)]
    if len(f):return f.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False]).iloc[0]
    return None

def main():
    status=json.loads((R/'verification/SEARCH_STATUS.json').read_text());assert status['Status']=='COMPLETE'
    summaries=[];convergence=[];pooled=[];prior_rows=[];unique_replays={};metadata=[]
    oldfull=pd.read_csv(R/'tables/Source_old_full_range_NSAG3_front.csv')
    oldgated=pd.read_csv(R/'tables/Source_old_gated_NSGA3_front.csv').rename(columns={'Y13':'Y_13pct'})
    newprior=pd.read_csv(R/'tables/Source_new_NSAG3_front.csv')
    for case in CASES:
        meta=json.loads((R/'runs'/case/'seed31/IDENTITY.json').read_text());metadata.append(meta)
        zero=next(x['Zero'] for x in status['Runs'] if x['Case']==case and x['Seed']==31)
        baseline=next(x['Baseline'] for x in status['Runs'] if x['Case']==case and x['Seed']==31)
        targets=[('No_yield_requirement',0.)]+[tuple(t) for t in meta['Targets']]
        if case.startswith('old'):
            prior=pd.concat([oldfull[oldfull.Year.eq(meta['Year'])],oldgated[oldgated.Year.eq(meta['Year'])]],ignore_index=True)
            reference_scope='historical full-range NSGA-III plus gated NSGA-III; unequal external budget'
        else:
            prior=newprior[newprior.Scenario.eq(case[4:])].copy();reference_scope='historical 3-seed NSGA-III, 30000 evaluations; external budget'
        for tid,target in targets:
            best=choose(prior,target)
            prior_rows.append(dict(Case=case,Target_ID=tid,Target_Y13=target,Historical_status='FOUND_IN_ARCHIVE' if best is not None else 'NOT_FOUND_IN_ARCHIVE',Historical_best_I_mm=float(best.Irrigation_mm) if best is not None else np.nan,Historical_Y13=float(best.Y_13pct) if best is not None else np.nan,Reference_scope=reference_scope))
        for seed in SEEDS:
            folder=R/'runs'/case/f'seed{seed}'
            raw=pd.read_csv(folder/'per_target_results.csv');raw['Phase']='Independent_threshold_search';summaries.append(raw)
            queries=pd.read_csv(folder/'all_objective_queries.csv.gz');queries['Phase']='Independent_threshold_search'
            if (folder/'refinement_queries.csv.gz').exists():
                extra=pd.read_csv(folder/'refinement_queries.csv.gz');summaries.append(pd.read_csv(folder/'refinement_per_target_results.csv'));queries=pd.concat([queries,extra],ignore_index=True)
            for algo in ALGOS:
                archive=queries[queries.Algorithm.eq(algo)].copy()
                # Include analytically evaluated zero and DI setup controls.
                anchors=pd.DataFrame([dict(**zero,**dict(zip(CONTROL,np.zeros(4))),Query=0,Target_ID='setup_zero'),dict(**baseline,**dict(zip(CONTROL,np.asarray(meta['Decision_space']['baseline_amounts']))),Query=0,Target_ID='setup_DI')])
                archive=pd.concat([archive,anchors],ignore_index=True)
                for tid,target in targets:
                    best=choose(archive,target)
                    common=dict(Case=case,Year=meta['Year'],Algorithm=algo,Seed=seed,Target_ID=tid,Target_Y13=target,Scope='minimum among all controls queried by this algorithm/seed across its threshold sweep; not a new optimization',Available_objective_queries=int((queries.Algorithm==algo).sum()))
                    if best is None:pooled.append(dict(**common,Status='NO_FEASIBLE_FOUND_IN_SWEEP_ARCHIVE'));continue
                    row={k:best[k] for k in CONTROL+['Y_13pct','Irrigation_mm','Planned_irrigation_mm','ET_mm','Es_mm','Tr_mm','Profile_final_mm','Root1m_final_mm','Root1m_initial_mm','Max_actual_event_mm']}
                    row.update(common);row.update(Status='FEASIBLE_FOUND',Yield_margin_t_ha=float(best.Y_13pct-target),Source_target_ID=best.Target_ID)
                    pooled.append(row)
                    key=(case,*[float(row[k]) for k in CONTROL]);unique_replays[key]=row
                for (tid,phase),g in queries[queries.Algorithm.eq(algo)].groupby(['Target_ID','Phase'],sort=False):
                    v=g[g.Query.mod(8).eq(0)|g.Query.eq(1)].copy()
                    convergence.append(v[['Case','Year','Algorithm','Seed','Target_ID','Target_Y13','Phase','Query','Best_feasible_I_mm','Best_violation_t_ha']])
    raw=pd.concat(summaries,ignore_index=True);pool=pd.DataFrame(pooled);prior=pd.DataFrame(prior_rows)
    pool=pool.merge(prior,on=['Case','Target_ID','Target_Y13'],how='left',validate='many_to_one')
    pool['Gap_to_historical_I_mm']=pool.Irrigation_mm-pool.Historical_best_I_mm
    raw.to_csv(R/'tables/Independent_per_target_results.csv',index=False)
    raw[raw.Phase.eq('Independent_threshold_search')].to_csv(R/'tables/Independent_only_results.csv',index=False)
    raw[raw.Phase.eq('Refinement_95pct')].to_csv(R/'tables/Refinement_95pct_results.csv',index=False)
    pool.to_csv(R/'tables/Within_method_sweep_archive_minima.csv',index=False)
    prior.to_csv(R/'tables/Historical_NSGA3_threshold_reference.csv',index=False)
    pd.concat(convergence,ignore_index=True).to_csv(R/'tables/Convergence_history.csv',index=False)
    (R/'verification/MODEL_CASE_IDENTITIES.json').write_text(json.dumps(metadata,indent=2))
    # Minima for nested feasible sets must be nondecreasing in the threshold.
    for _,g in pool.groupby(['Case','Algorithm','Seed']):
        v=g[g.Status.eq('FEASIBLE_FOUND')].sort_values('Target_Y13')
        assert np.diff(v.Irrigation_mm).min(initial=0)>=-1e-8
    metrics=[]
    for (case,algo,tid,target),g in pool.groupby(['Case','Algorithm','Target_ID','Target_Y13'],sort=False):
        v=g[g.Status.eq('FEASIBLE_FOUND')]
        metrics.append(dict(Case=case,Algorithm=algo,Target_ID=tid,Target_Y13=target,Seeds=len(g),Feasible_seeds=len(v),I_median_mm=v.Irrigation_mm.median(),I_min_mm=v.Irrigation_mm.min(),I_max_mm=v.Irrigation_mm.max(),Y_achieved_min=v.Y_13pct.min(),Y_achieved_max=v.Y_13pct.max(),Historical_best_I_mm=g.Historical_best_I_mm.iloc[0]))
    m=pd.DataFrame(metrics)
    best=m.groupby(['Case','Target_ID']).I_min_mm.min().rename('Best_across_new_methods_I_mm')
    m=m.join(best,on=['Case','Target_ID']);m['Median_excess_vs_best_new_mm']=m.I_median_mm-m.Best_across_new_methods_I_mm
    m.to_csv(R/'tables/Algorithm_seed_summary.csv',index=False)
    m[m.Target_ID.eq('Observed_0.95')].to_csv(R/'tables/At_95pct_observed_summary.csv',index=False)
    # Replay every DISTINCT selected archive control through the full adapter.
    replay=[];events=[];checks=[]
    for case in CASES:
        e=ExactEngine(case)
        for key,row in unique_replays.items():
            if key[0]!=case:continue
            x=np.asarray(key[1:]);s,w,g=e.reference(x)
            diff=max(abs(float(s[k])-float(row[k])) for k in ['Y_13pct','Irrigation_mm','ET_mm','Es_mm','Tr_mm','Profile_final_mm'])
            assert diff<1e-8,(case,diff)
            assert s['Max_daily_balance_residual_mm']<1e-8
            id=hashlib.sha256((case+repr(tuple(x))).encode()).hexdigest()[:14]
            replay.append(dict(Control_ID=id,Case=case,**dict(zip(CONTROL,x)),**{k:v for k,v in s.items() if k!='irrigation_events'},Fixed_0_1m_final_mm=row['Root1m_final_mm'],Fixed_0_1m_initial_mm=row['Root1m_initial_mm'],Fast_vs_full_maximum_difference=diff))
            for ev in s['irrigation_events']:events.append(dict(Control_ID=id,Case=case,**ev))
        checks.append(dict(Case=case,Selected_controls_replayed=sum(v['Case']==case for v in replay)))
        print('FULL REPLAY',case,checks[-1]['Selected_controls_replayed'],flush=True)
    full=pd.DataFrame(replay);full.to_csv(R/'tables/Full_adapter_selected_control_replays.csv',index=False);pd.DataFrame(events).to_csv(R/'tables/Selected_event_schedules.csv',index=False)
    budgets=[];selected=[]
    for case in CASES:
        feasible=pool[(pool.Case==case)&(pool.Target_ID=='Observed_0.95')&pool.Status.eq('FEASIBLE_FOUND')]
        best=feasible.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False]).iloc[0];x=best[CONTROL].to_numpy(float)
        found=full[full.Case.eq(case)]
        hit=found[np.max(abs(found[CONTROL].to_numpy()-x),axis=1)<1e-9].iloc[0]
        identity=next(z for z in metadata if z['Case']==case);base=np.asarray(identity['Decision_space']['baseline_amounts'])
        e=ExactEngine(case);b,_,_=e.reference(base)
        deltaI=b['Irrigation_mm']-hit.Irrigation_mm;deltaET=b['ET_mm']-hit.ET_mm;deltaS=b['Profile_final_mm']-hit.Profile_final_mm
        budgets.append(dict(Case=case,Algorithm=best.Algorithm,Seed=int(best.Seed),Target_Y13=best.Target_Y13,Achieved_Y13=hit.Y_13pct,DI_I_mm=b['Irrigation_mm'],Candidate_I_mm=hit.Irrigation_mm,Reduction_I_mm=deltaI,Reduction_ET_mm=deltaET,Reduction_final_full_profile_storage_mm=deltaS,Other_flux_difference_mm=deltaI-deltaET-deltaS,Storage_share_of_I_reduction_pct=100*deltaS/deltaI,DI_final_full_profile_mm=b['Profile_final_mm'],Candidate_final_full_profile_mm=hit.Profile_final_mm,Scope='whole hydrological profile, not root-zone-only; same forcing and initial state'))
        selected.append(dict(**best.to_dict(),Control_ID=hit.Control_ID))
    pd.DataFrame(budgets).to_csv(R/'tables/Best_95pct_irrigation_reduction_budget.csv',index=False);pd.DataFrame(selected).to_csv(R/'tables/Overall_best_95pct_candidates.csv',index=False)
    check=dict(Status='PASS',Raw_per_target_runs=len(raw),Sweep_archive_rows=len(pool),Actual_distinct_full_adapter_replays=len(full),Maximum_fast_full_difference=float(full.Fast_vs_full_maximum_difference.max()),Maximum_full_replay_daily_balance_residual_mm=float(full.Max_daily_balance_residual_mm.max()),Nested_constraint_minima_monotone=True,No_synthetic_feasible_points=True,Unresolved_thresholds_not_interpolated=True,No_interpolated_model_responses=True,Checks=checks)
    (R/'verification/AGGREGATION_CHECK.json').write_text(json.dumps(check,indent=2));print(json.dumps(check,indent=2))
if __name__=='__main__':main()
