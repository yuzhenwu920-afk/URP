"""Check solver accounting, feasibility, complete replays and document outputs."""
from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import fitz
from PIL import Image,ImageDraw
from openpyxl import load_workbook
R=Path(__file__).resolve().parents[1]
def main():
    a=json.loads((R/'verification/SEARCH_STATUS.json').read_text());b=json.loads((R/'verification/REFINEMENT_STATUS.json').read_text());assert a['Status']==b['Status']=='COMPLETE'
    assert len(a['Runs'])==len(b['Runs'])==21
    all_queries=0;actual=0;identities=[]
    for folder in sorted((R/'runs').glob('*/*')):
        if not folder.is_dir():continue
        first=pd.read_csv(folder/'all_objective_queries.csv.gz');second=pd.read_csv(folder/'refinement_queries.csv.gz');raw=pd.read_csv(folder/'per_target_results.csv')
        assert len(raw)==28
        for v in [first,second]:
            for _,g in v.groupby(['Algorithm','Target_ID']):
                assert len(g)==384 and g.Query.tolist()==list(range(1,385))
            for c in ['Y_13pct','Irrigation_mm','Planned_irrigation_mm','ET_mm','Profile_final_mm']:assert np.isfinite(v[c]).all()
            meta=json.loads((folder/'IDENTITY.json').read_text());cap=meta['Seasonal_cap_mm']
            assert v[[f'Window{i}_mm' for i in range(1,5)]].ge(-1e-9).all().all()
            assert v.Planned_irrigation_mm.le(cap+1e-8).all()
            assert v.Irrigation_mm.le(v.Planned_irrigation_mm+1e-8).all()
            assert (v.Feasible==v.Y_13pct.ge(v.Target_Y13-1e-9)).all()
            all_queries+=len(v);actual+=int((~v.Exact_cache_hit).sum())
        identities.append(meta)
    assert all_queries==a['Total_objective_queries']+b['Total_objective_queries']
    assert actual==a['Actual_optimization_model_calls']+b['Actual_optimization_model_calls']
    pools=pd.read_csv(R/'tables/Within_method_sweep_archive_minima.csv');assert len(pools)==672
    for _,g in pools.groupby(['Case','Algorithm','Seed']):
        v=g[g.Status.eq('FEASIBLE_FOUND')].sort_values('Target_Y13');assert np.diff(v.Irrigation_mm).min(initial=0)>=-1e-8
    ag=json.loads((R/'verification/AGGREGATION_CHECK.json').read_text());assert ag['Status']=='PASS'
    original_kernel_check=json.loads((R/'verification/UNACCELERATED_CHECK.json').read_text());assert original_kernel_check['Status']=='PASS'
    # Freeze original dependency identities against the previously verified bundle.
    previous=R/'verification/FROZEN_MODEL_SOURCE_HASHES.json'
    if previous.exists():
        original=json.loads(previous.read_text());checked=0
        for item in original:
            p=R/item['Path']
            if p.exists():assert hashlib.sha256(p.read_bytes()).hexdigest()==item['SHA256'],str(p);checked+=1
    else:checked=None
    figures=pd.read_csv(R/'tables/Figure_captions.csv')
    for id in figures.Figure_ID:
        for ext in ['png','pdf','svg']:assert (R/'figures'/f'{id}.{ext}').stat().st_size>1000
        im=Image.open(R/'figures'/f'{id}.png');assert abs(im.info['dpi'][0]-600)<1
    with zipfile.ZipFile(R/'documents/URP_Single_Objective_Comparison_Report.docx') as z:
        assert z.testzip() is None;assert len([n for n in z.namelist() if n.startswith('word/media/')])==6
    wb=load_workbook(R/'documents/URP_Single_Objective_Comparison_Data.xlsx',read_only=True);assert wb['Raw threshold searches'].max_row==673
    doc=fitz.open(R/'documents/URP_Single_Objective_Comparison_Report.pdf');txt='\n'.join(p.get_text() for p in doc)
    for value in ['253,440','384','0.85','95%','NSGA','DE']:assert value in txt,value
    assert len(doc)>=8
    cols=3;cw,ch=480,700;out=Image.new('RGB',(cw*cols,ch*((len(doc)+cols-1)//cols)),'#D9D9D9');draw=ImageDraw.Draw(out)
    for i,p in enumerate(doc):
        pix=p.get_pixmap(matrix=fitz.Matrix(.8,.8),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((460,665));x=i%cols*cw+10;y=i//cols*ch+25;out.paste(im,(x,y));draw.text((x,y-18),f'Page {i+1}',fill='black')
    out.save(R/'verification/Report_contact_sheet.jpg',quality=93)
    cols=2;out=Image.new('RGB',(1500,1650),'#D9D9D9');draw=ImageDraw.Draw(out)
    for i,id in enumerate(figures.Figure_ID):
        im=Image.open(R/'figures'/f'{id}_preview.jpg');im.thumbnail((730,505));x=i%2*750+10;y=i//2*550+30;out.paste(im,(x,y));draw.text((x,y-18),id,fill='black')
    out.save(R/'verification/Figure_contact_sheet.jpg',quality=94)
    result=dict(Status='PASS',Model_cases=7,Algorithms=4,Seeds=3,Independent_scalar_problems=588,Analytically_zero_minima=12,Nontrivial_independent_searches=576,Continuation_searches=84,Total_objective_queries=all_queries,Actual_optimization_model_calls=actual,Full_selected_control_replays=ag['Actual_distinct_full_adapter_replays'],Original_unaccelerated_replays=original_kernel_check['Original_unaccelerated_replays'],Maximum_fast_full_difference=ag['Maximum_fast_full_difference'],Maximum_full_daily_balance_residual_mm=ag['Maximum_full_replay_daily_balance_residual_mm'],Original_model_dependency_files_checked=checked,Nested_constraint_minima_monotone=True,English_figure_groups=6,Figure_dpi=600,PDF_pages=len(doc),Workbook_sheets=len(wb.sheetnames),No_synthetic_feasible_points=True,Exact_model_no_surrogate=True,Historical_NSGA3_budget_not_matched=True,No_global_optimality_or_field_validation_claim=True)
    (R/'verification/DELIVERY_CHECK.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
