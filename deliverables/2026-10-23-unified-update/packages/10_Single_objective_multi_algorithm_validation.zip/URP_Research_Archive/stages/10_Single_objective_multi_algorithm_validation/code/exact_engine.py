"""Direct execution of the SAME annual model, with full diagnostic replay later.

No surrogate or response interpolation. Avoid repeated dataframe audits inside
the optimizer; independently verify outputs against the full original adapter.
"""
from pathlib import Path
import sys,os,json,importlib,importlib.util,copy,time
import numpy as np
R=Path(__file__).resolve().parents[1]
PROJECT=Path(os.environ.get('URP_PROJECT',str(R/'model_snapshots/DI_PHASE3_NEXTGEN_UPDATED')))
PARENT=Path(os.environ.get('URP_FMULCH_PARENT',str(R/'dependencies/2021_fmulch')))
os.environ['URP_PROJECT']=str(PROJECT)
NAMES=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']

class ExactEngine:
    def __init__(self,case):
        self.case=case;self.parent_engine=None
        if case.startswith('new_'):
            sys.path.insert(0,str(PARENT/'code'));from scenario_engine import Engine
            self.sc=case[4:];e=Engine(self.sc,True,tag='single_objective');self.parent_engine=e
            self.adapter,self.m,self.data,self.params,self.year=e.adapter,e.m,e.data,e.params,2021
        else:
            self.year=int(case[-4:]);spec=importlib.util.spec_from_file_location('single_objective_original_adapter',PROJECT/'real_model/four_year_adapter.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
            import pandas as pd
            cfg=json.loads((PROJECT/'project_config.json').read_text());v=pd.read_csv(PROJECT/cfg['centers']).set_index('Year').loc[self.year]
            self.adapter=a;self.m,self.data=a._load(self.year);self.params=v[NAMES].to_dict()
        self.space=self.adapter.management_space(self.year);self.base=np.array(self.space['baseline_amounts'],float);self.cap=float(self.base.sum())
        sys.path.insert(0,str(PROJECT/'real_model'));import numerical_acceleration;numerical_acceleration.install()
        self.template=self.adapter._template(self.year,tuple(float(self.params[k]) for k in NAMES))
        self.event_indexes=self.template._clock_struct.time_span.get_indexer(self.data['schedule'].Date)
        self.events_stage=np.array(self.space['event_stages']);self.events_weight=np.array(self.space['event_weights'])
        self.offset=len(self.template._urp_prefix[0])-1
        self.late=[d>=self.m.SWITCH for d in self.m.DATES[self.offset:]]
        self.wp=[self.m.effective_wp(self.template._urp_full_fco2,self.params[k]) for k in ['WP_early','WP_late']]
        p=self.data['soil'].profile;self.weights=np.clip(1-p.z_top.to_numpy(float),0,p.dz.to_numpy(float))*1000
        self.root_initial=float(np.dot(self.data['theta'],self.weights))
        self.step=importlib.import_module('aquacrop.timestep.run_single_timestep');self.core=importlib.import_module('aquacrop.core');self.active=False
    def activate(self):
        assert not self.active;self.old_evap=self.step.soil_evaporation;self.old_stop=self.core.check_model_is_finished
        self.step.soil_evaporation=self.adapter._evap_wrapper(self.old_evap)
        self.core.check_model_is_finished=lambda current_time,*args:bool(current_time>=self.m.HARVEST)
        self.active=True
    def restore(self):
        if self.active:self.step.soil_evaporation=self.old_evap;self.core.check_model_is_finished=self.old_stop;self.active=False
    def run(self,x):
        assert self.active
        m=copy.deepcopy(self.template);amounts=np.asarray(x)[self.events_stage]*self.events_weight
        daily=np.zeros(len(m._clock_struct.time_span));daily[self.event_indexes]=amounts
        im=m._param_struct.IrrMngt;im.Schedule=daily;im.MaxIrr=float(amounts.max()+.1);im.MaxIrrSeason=float(amounts.sum()+.1)
        sc=m._param_struct.Seasonal_Crop_List[0]
        for late in self.late:
            sc.WP,sc.fCO2=self.wp[int(late)]
            m._clock_struct,m._init_cond,m._param_struct,m._outputs=m._perform_timestep()
        assert m._clock_struct.model_is_finished and len(m._outputs.final_stats)==1
        wf=m._outputs.water_flux
        s=dict(Y_13pct=float(m._outputs.final_stats.iloc[0]['Dry yield (tonne/ha)'])/.87,Irrigation_mm=float(wf.IrrDay.sum()),Planned_irrigation_mm=float(amounts.sum()),ET_mm=float((wf.Es+wf.Tr).sum()),Es_mm=float(wf.Es.sum()),Tr_mm=float(wf.Tr.sum()),Profile_final_mm=float(m._init_cond.th.sum()*100),Root1m_final_mm=float(np.dot(m._init_cond.th,self.weights)),Root1m_initial_mm=self.root_initial,Max_actual_event_mm=float(wf.IrrDay.max()))
        return s
    def reference(self,x,accelerate=True):
        assert not self.active
        if self.parent_engine:
            self.parent_engine.install()
            try:return self.parent_engine.run(x,True)
            finally:self.parent_engine.restore()
        return self.adapter.simulate(params=self.params,year=self.year,management=dict(kind='stage_amounts',values=dict(zip(self.space['names'],x))),details=True,accelerate=accelerate)

def verify_and_time(case):
    e=ExactEngine(case);rng=np.random.default_rng(61);X=[e.base,np.zeros(4),e.base*.55]+[rng.dirichlet(np.ones(4))*rng.uniform(0,e.cap) for _ in range(9)]
    refs=[e.reference(x)[0] for x in X];e.activate()
    try:
        fast=[e.run(x) for x in X];diff=max(abs(a[k]-b[k]) for a,b in zip(refs,fast) for k in ['Y_13pct','Irrigation_mm','ET_mm','Profile_final_mm'])
        assert diff<1e-8,(case,diff)
        t=time.monotonic()
        for _ in range(100):e.run(rng.dirichlet(np.ones(4))*rng.uniform(0,e.cap))
        return dict(Case=case,Checks=len(X),Maximum_difference=diff,Seconds_per_100=time.monotonic()-t)
    finally:e.restore()
if __name__=='__main__':
    rows=[verify_and_time(case) for case in ['old_2019','old_2020','old_2021','old_2022','new_fm050','new_fm075','new_fm085']]
    (R/'verification/EXACT_ENGINE_CHECK.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
