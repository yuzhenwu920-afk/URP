"""Independent scalar min-irrigation searches at prespecified yield thresholds.

4 algorithms x 3 seeds x 7 cases, 384 objective queries per nontrivial target.
Exact response memoization: targets do not change model physics, and only the
requested response is returned. No interpolated/surrogate model evaluations.
"""
from pathlib import Path
import os,json,time,contextlib,hashlib,concurrent.futures,multiprocessing
import numpy as np
import pandas as pd
from scipy.optimize import differential_evolution,dual_annealing
from pymoo.core.problem import Problem
from pymoo.algorithms.soo.nonconvex.ga import GA
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.optimize import minimize
from exact_engine import ExactEngine,R
CASES=[f'old_{y}' for y in range(2019,2023)]+['new_fm050','new_fm075','new_fm085']
ALGOS=['GA','NSGA2_1obj','GSA','DE'];SEEDS=[31,73,109];POP=32;BUDGET=384
OBS={2019:16.55,2020:17.29,2021:15.86,2022:14.08}
FRACTIONS=[.50,.70,.85,.95,1.]

def dump(path,data):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2,allow_nan=False));os.replace(tmp,path)
def repair(z):
    z=np.clip(np.asarray(z,float),0,1);total=z.sum();return z/max(total,1.)
class StopBudget(Exception):pass

class Evaluation:
    def __init__(self,engine,cache,target,algo,seed,index):
        self.e,self.cache,self.target,self.algo,self.seed,self.index=engine,cache,float(target),algo,seed,index
        self.rows=[];self.best=np.inf;self.best_violation=np.inf;self.calls=0
    def score(self,z):
        if len(self.rows)>=BUDGET:raise StopBudget()
        original=np.asarray(z,float);v=repair(original);x=v*self.e.cap;key=x.astype('<f8').tobytes();hit=key in self.cache
        if hit:s=self.cache[key]
        else:s=self.e.run(x);self.cache[key]=s;self.calls+=1
        violation=max(0.,self.target-s['Y_13pct'])
        feasible=bool(violation<=1e-9)
        # Feasible responses occupy [0,1], every infeasible response exceeds 1.
        f=float(s['Irrigation_mm']/self.e.cap) if feasible else float(1.+violation/max(self.target,1e-12))
        if feasible:self.best=min(self.best,s['Irrigation_mm'])
        self.best_violation=min(self.best_violation,violation)
        self.rows.append(dict(Query=len(self.rows)+1,Case=self.e.case,Year=self.e.year,Algorithm=self.algo,Seed=self.seed,Target_ID=self.index,Target_Y13=self.target,**dict(zip(self.e.space['names'],x)),**s,Feasible=feasible,Violation_t_ha=violation,Scalar_fitness=f,Exact_cache_hit=hit,Best_feasible_I_mm=None if not np.isfinite(self.best) else self.best,Best_violation_t_ha=self.best_violation))
        return f
class ScalarProblem(Problem):
    def __init__(self,ev):self.ev=ev;super().__init__(n_var=4,n_obj=1,xl=np.zeros(4),xu=np.ones(4))
    def _evaluate(self,X,out,*args,**kwargs):out['F']=np.asarray([self.ev.score(z) for z in X])[:,None]

def initial_population(base,cap,seed):
    rng=np.random.default_rng(seed);a=rng.dirichlet(np.ones(4),POP)*rng.uniform(0,1,POP)[:,None]
    anchors=[np.zeros(4),base/cap]+[base/cap*f for f in np.linspace(.1,.9,9)]+[np.eye(4)[j]*v for v in [.25,.5] for j in range(4)]
    for i,x in enumerate(anchors):a[i]=x
    return a

def run_one(ev,X):
    start=time.monotonic()
    try:
        if ev.algo in ['GA','NSGA2_1obj']:
            cls=GA if ev.algo=='GA' else NSGA2
            algo=cls(pop_size=POP,sampling=X.copy(),crossover=SBX(prob=.9,eta=15),mutation=PM(prob=1.,prob_var=.25,eta=20),eliminate_duplicates=False)
            minimize(ScalarProblem(ev),algo,('n_gen',BUDGET//POP),seed=ev.seed,verbose=False)
        elif ev.algo=='DE':
            differential_evolution(ev.score,[(0.,1.)]*4,strategy='best1bin',maxiter=BUDGET//POP-1,popsize=POP//4,init=X.copy(),mutation=(.5,1.),recombination=.7,rng=np.random.default_rng(ev.seed),polish=False,updating='immediate',tol=0.,atol=0.)
        else:
            initial=[ev.score(x) for x in X]
            best=X[int(np.argmin(initial))]
            dual_annealing(ev.score,[(0.,1.)]*4,x0=best,initial_temp=1.,restart_temp_ratio=2e-5,visit=2.62,accept=-5.,no_local_search=True,maxfun=BUDGET-POP,rng=np.random.default_rng(ev.seed))
        # Fill an early solver stop with independent global probes, disclosed in
        # the run table. Usually only needed if SciPy's convergence test fires.
        fallback=0;rng=np.random.default_rng(ev.seed+8173)
        while len(ev.rows)<BUDGET:
            ev.score(rng.dirichlet(np.ones(4))*rng.uniform());fallback+=1
    except StopBudget:fallback=0
    assert len(ev.rows)==BUDGET
    frame=pd.DataFrame(ev.rows);feasible=frame[frame.Feasible]
    q=frame.sort_values(['Violation_t_ha','Irrigation_mm']).iloc[0] if feasible.empty else feasible.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False]).iloc[0]
    summary={k:q[k].item() if isinstance(q[k],np.generic) else q[k] for k in q.index if k not in ['Exact_cache_hit','Best_feasible_I_mm','Best_violation_t_ha']}
    summary.update(Status='FEASIBLE_FOUND' if len(feasible) else 'NO_FEASIBLE_FOUND_WITHIN_BUDGET',Objective_queries=len(frame),Actual_model_calls=ev.calls,Exact_cache_hits=len(frame)-ev.calls,Wall_seconds=time.monotonic()-start,Random_fallback_queries=fallback)
    return frame,summary

def task(args):
    case,seed=args;folder=R/'runs'/case/f'seed{seed}';folder.mkdir(parents=True,exist_ok=True)
    state=folder/'STATUS.json'
    if state.exists():
        prev=json.loads(state.read_text())
        if prev['Status']=='COMPLETE':return prev
        raise RuntimeError('Incomplete result kept, refusing to append: '+str(folder))
    with (folder/'run.log').open('w',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        t=time.monotonic();e=ExactEngine(case);e.activate();cache={};allrows=[];summaries=[]
        try:
            zero=e.run(np.zeros(4));baseline=e.run(e.base)
            targets=[(f'DI_{f:.2f}',f*baseline['Y_13pct']) for f in FRACTIONS]+[('Observed_0.95',.95*OBS[e.year]),('Observed_1.00',OBS[e.year])]
            X=initial_population(e.base,e.cap,seed)
            identity=dict(Case=case,Year=e.year,Seed=seed,Parameters=e.params,Decision_space=e.space,Seasonal_cap_mm=e.cap,Root_max_m=2.3 if case.startswith('old') else 1.,fMulch=0. if case.startswith('old') else dict(new_fm050=.5,new_fm075=.75,new_fm085=.85)[case],MulchPct=75.,Precipitation='original frozen GEE input; no forcing changes',Single_objective='minimize actual seasonal irrigation',Constraint='model Y13 >= target',Additional_storage_floor=False,Additional_event_cap=False,Budget_per_nontrivial_target=BUDGET,Targets=targets,Common_initial_population=X.tolist(),No_old_NSGA_controls_in_initial_population=True,Algorithm_order=ALGOS,Timing_scope='actual warm-cache wall time; not a fair standalone speed ranking')
            dump(folder/'IDENTITY.json',identity);dump(state,dict(Status='RUNNING',Case=case,Seed=seed))
            for algo in ALGOS:
                for target_id,target in targets:
                    if target<=zero['Y_13pct']+1e-9:
                        summaries.append(dict(Case=case,Year=e.year,Algorithm=algo,Seed=seed,Target_ID=target_id,Target_Y13=target,Status='ZERO_IRRIGATION_PROVEN_MINIMUM',Objective_queries=0,Actual_model_calls=0,**dict(zip(e.space['names'],np.zeros(4))),**zero,Feasible=True,Violation_t_ha=0.,Scalar_fitness=0.,Wall_seconds=0.,Exact_cache_hits=0,Random_fallback_queries=0))
                    else:
                        frame,summary=run_one(Evaluation(e,cache,target,algo,seed,target_id),X);allrows.append(frame);summaries.append(summary)
                    print(case,seed,algo,target_id,summaries[-1]['Status'],summaries[-1]['Irrigation_mm'],flush=True)
                    dump(folder/'progress.json',dict(Case=case,Seed=seed,Completed_targets=len(summaries),Planned_targets=28,Algorithm=algo,Target_ID=target_id))
            rows=pd.concat(allrows,ignore_index=True);rows.to_csv(folder/'all_objective_queries.csv.gz',index=False,compression='gzip');pd.DataFrame(summaries).to_csv(folder/'per_target_results.csv',index=False)
            e.restore()
            result=dict(Status='COMPLETE',Case=case,Seed=seed,Objective_queries=len(rows),Actual_optimization_model_calls=len(cache),Setup_model_calls=2,Seconds=time.monotonic()-t,Targets=len(targets),Per_algorithm_targets=len(targets),Zero=zero,Baseline=baseline)
            dump(state,result);return result
        except Exception as ex:dump(state,dict(Status='FAILED',Case=case,Seed=seed,Error=repr(ex)));raise
        finally:e.restore()

def main():
    config=dict(Cases=CASES,Algorithms=ALGOS,Seeds=SEEDS,Population=POP,Objective_queries_per_nontrivial_target=BUDGET,Targets_DI_fractions=FRACTIONS,Additional_targets=['95pct_observed','100pct_observed'],No_MCMC_reruns=True,Shared_initial_population=True,Historical_reference_not_used_for_warm_starts=True,No_global_optimum_claim=True)
    dump(R/'verification/CONFIG.json',config)
    status=dict(Status='RUNNING',Runs=[]);dump(R/'verification/SEARCH_STATUS.json',status)
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn')) as pool:
        tasks=[pool.submit(task,(case,seed)) for case in CASES for seed in SEEDS]
        for f in concurrent.futures.as_completed(tasks):
            result=f.result();status['Runs'].append(result);dump(R/'verification/SEARCH_STATUS.json',status);print('COMPLETE',result['Case'],result['Seed'],'queries',result['Objective_queries'],'model calls',result['Actual_optimization_model_calls'],'sec',round(result['Seconds'],1),flush=True)
    status['Status']='COMPLETE';status['Total_objective_queries']=sum(x['Objective_queries'] for x in status['Runs']);status['Actual_optimization_model_calls']=sum(x['Actual_optimization_model_calls'] for x in status['Runs']);status['Setup_model_calls']=2*len(status['Runs']);dump(R/'verification/SEARCH_STATUS.json',status)
    print(json.dumps({k:v for k,v in status.items() if k!='Runs'},indent=2))
if __name__=='__main__':main()
