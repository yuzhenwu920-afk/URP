"""Create a stable, checksum-verified archive after all outputs are finished."""
from pathlib import Path
import csv,json,zipfile,hashlib
R=Path(__file__).resolve().parents[1];NAME='URP_Single_Objective_Comparison_20261021'
def keep(p):
    if not p.is_file():return False
    rel=p.relative_to(R)
    if any(x in rel.parts for x in ['__pycache__','input_audit','output_real']):return False
    if p.suffix in ['.pyc','.nbi','.nbc','.log','.tmp']:return False
    if p.name in ['MANIFEST.csv','SHA256SUMS.txt',NAME+'.zip']:return False
    return rel.parts[0] in ['code','tables','runs','figures','documents','verification','model_snapshots','dependencies'] or rel.name in ['README.md','requirements.txt']
def main():
    check=json.loads((R/'verification/DELIVERY_CHECK.json').read_text());assert check['Status']=='PASS'
    files=sorted(p for p in R.rglob('*') if keep(p));records=[dict(Path=p.relative_to(R).as_posix(),Bytes=p.stat().st_size,SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
    with (R/'MANIFEST.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['Path','Bytes','SHA256']);w.writeheader();w.writerows(records)
    (R/'SHA256SUMS.txt').write_text(''.join(f"{a['SHA256']}  {a['Path']}\n" for a in records))
    target=R/(NAME+'.zip')
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files+[R/'MANIFEST.csv',R/'SHA256SUMS.txt']:z.write(p,NAME+'/'+p.relative_to(R).as_posix())
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for a in records:assert hashlib.sha256(z.read(NAME+'/'+a['Path'])).hexdigest()==a['SHA256']
    result=dict(Archive=str(target),Bytes=target.stat().st_size,SHA256=hashlib.sha256(target.read_bytes()).hexdigest(),Payload_files=len(files),ZIP_integrity='PASS',Every_payload_hash='PASS')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
