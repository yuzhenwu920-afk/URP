"""Equal extra 384-query continuation at the scientifically central 95% gate.

Each method starts ONLY from its own sweep archive; historical NSGA-III controls
and other algorithms' solutions are not shared. This is a separate refinement
phase; raw independent threshold results remain available.
"""
from pathlib import Path
import contextlib,json,time,concurrent.futures,multiprocessing
import numpy as np
import pandas as pd
from exact_engine import ExactEngine,R
from run_comparison import CASES,SEEDS,ALGOS,POP,Evaluation,run_one,dump
CONTROL=[f'Window{i}_mm' for i in range(1,5)]
def task(args):
    case,seed=args;folder=R/'runs'/case/f'seed{seed}';state=folder/'REFINEMENT_STATUS.json'
    if state.exists():
        prev=json.loads(state.read_text());assert prev['Status']=='COMPLETE';return prev
    with (folder/'refinement.log').open('w',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        e=ExactEngine(case);e.activate();cache={};rows=[];summaries=[];t=time.monotonic()
        source=pd.read_csv(folder/'all_objective_queries.csv.gz');original=pd.read_csv(folder/'per_target_results.csv');target=original.loc[original.Target_ID.eq('Observed_0.95'),'Target_Y13'].iloc[0]
        try:
            for algo in ALGOS:
                pool=source[(source.Algorithm==algo)&source.Y_13pct.ge(target-1e-9)].sort_values('Irrigation_mm');assert len(pool)
                center=pool.iloc[0][CONTROL].to_numpy(float)/e.cap
                rng=np.random.default_rng(seed+991);X=np.clip(center+rng.normal(0,.035,(POP,4)),0,1)
                X[0]=center;X[1]=e.base/e.cap
                for j in range(8):X[j+2]=np.clip(center+np.eye(4)[j//2]*(.02 if j%2 else -.02),0,1)
                for j in range(26,POP):X[j]=rng.dirichlet(np.ones(4))*rng.uniform()
                # Same local-population construction for every method. The
                # center differs only because prior method searches differ.
                ev=Evaluation(e,cache,target,algo,seed,'Observed_0.95');f,s=run_one(ev,X)
                f['Phase']='Refinement_95pct';s['Phase']='Refinement_95pct';s['Parent_sweep_best_I_mm']=float(pool.iloc[0].Irrigation_mm)
                rows.append(f);summaries.append(s)
            pd.concat(rows).to_csv(folder/'refinement_queries.csv.gz',index=False,compression='gzip');pd.DataFrame(summaries).to_csv(folder/'refinement_per_target_results.csv',index=False)
            result=dict(Status='COMPLETE',Case=case,Seed=seed,Objective_queries=sum(len(v) for v in rows),Actual_optimization_model_calls=len(cache),Seconds=time.monotonic()-t)
            dump(state,result);return result
        finally:e.restore()
def main():
    assert json.loads((R/'verification/SEARCH_STATUS.json').read_text())['Status']=='COMPLETE'
    status=dict(Status='RUNNING',Runs=[]);dump(R/'verification/REFINEMENT_STATUS.json',status)
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn')) as pool:
        futures=[pool.submit(task,(case,seed)) for case in CASES for seed in SEEDS]
        for f in concurrent.futures.as_completed(futures):
            status['Runs'].append(f.result());dump(R/'verification/REFINEMENT_STATUS.json',status);print('REFINED',status['Runs'][-1]['Case'],status['Runs'][-1]['Seed'],flush=True)
    status.update(Status='COMPLETE',Total_objective_queries=sum(v['Objective_queries'] for v in status['Runs']),Actual_optimization_model_calls=sum(v['Actual_optimization_model_calls'] for v in status['Runs']))
    dump(R/'verification/REFINEMENT_STATUS.json',status)
if __name__=='__main__':main()
