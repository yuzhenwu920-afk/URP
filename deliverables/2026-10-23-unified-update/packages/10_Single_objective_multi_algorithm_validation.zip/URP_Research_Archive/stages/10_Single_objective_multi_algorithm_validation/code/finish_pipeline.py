"""Finish dependent analysis after the running independent searches complete."""
from pathlib import Path
import json,time,subprocess,sys,os
R=Path(__file__).resolve().parents[1]
def main():
    start=time.monotonic()
    while True:
        state=json.loads((R/'verification/SEARCH_STATUS.json').read_text())
        if state['Status']=='COMPLETE':break
        for p in (R/'runs').glob('*/*/STATUS.json'):
            a=json.loads(p.read_text())
            if a['Status']=='FAILED':raise RuntimeError(a)
        if time.monotonic()-start>1800:raise TimeoutError('Independent search did not complete')
        time.sleep(5)
    env=os.environ.copy();env['MPLCONFIGDIR']='/tmp/urp_single_mpl';env['XDG_CACHE_HOME']='/tmp/urp_single_cache'
    for name in ['refine_95pct.py','aggregate_results.py','build_outputs.py']:
        print('START',name,flush=True);subprocess.run([sys.executable,'code/'+name],cwd=R,env=env,check=True);print('DONE',name,flush=True)
    subprocess.run(['soffice','-env:UserInstallation=file:///tmp/urp_single_soffice','--headless','--convert-to','pdf','--outdir','documents','documents/URP_Single_Objective_Comparison_Report.docx'],cwd=R,env=env,check=True)
    subprocess.run([sys.executable,'code/check_delivery.py'],cwd=R,env=env,check=True)
if __name__=='__main__':main()
