"""English publication figures, data workbook and a Chinese scientific report."""
from pathlib import Path
import json,importlib.metadata,math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl.styles import Font,PatternFill,Alignment
R=Path(__file__).resolve().parents[1];F=R/'figures';D=R/'documents';F.mkdir(exist_ok=True);D.mkdir(exist_ok=True)
ALGOS=['GA','NSGA2_1obj','GSA','DE'];COLORS=dict(GA='#0072B2',NSGA2_1obj='#D55E00',GSA='#009E73',DE='#A45A9F');LABEL=dict(GA='GA',NSGA2_1obj='NSGA-II (one objective)',GSA='GSA',DE='DE');MARK=dict(GA='o',NSGA2_1obj='s',GSA='^',DE='D');LINE=dict(GA='-',NSGA2_1obj='--',GSA='-.',DE=':')
CASES=[f'old_{y}' for y in range(2019,2023)]+['new_fm050','new_fm075','new_fm085']
SHORT={**{f'old_{y}':f'{y} | historical' for y in range(2019,2023)},'new_fm050':'2021 | fMulch 0.50','new_fm075':'2021 | fMulch 0.75','new_fm085':'2021 | fMulch 0.85'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.titlesize':15,'axes.labelsize':13,'legend.fontsize':12,'xtick.labelsize':12,'ytick.labelsize':12,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.17,'pdf.fonttype':42,'svg.fonttype':'none'})
def save(fig,id):
    for ext in ['png','pdf','svg']:fig.savefig(F/f'{id}.{ext}',dpi=600,bbox_inches='tight',pad_inches=.12)
    plt.close(fig);im=Image.open(F/f'{id}.png').convert('RGB');im.thumbnail((2300,2300));im.save(F/f'{id}_preview.jpg',quality=94)
def main():
    summary=pd.read_csv(R/'tables/Algorithm_seed_summary.csv');pool=pd.read_csv(R/'tables/Within_method_sweep_archive_minima.csv');prior=pd.read_csv(R/'tables/Historical_NSGA3_threshold_reference.csv');budget=pd.read_csv(R/'tables/Best_95pct_irrigation_reduction_budget.csv');hist=pd.read_csv(R/'tables/Convergence_history.csv');raw=pd.read_csv(R/'tables/Independent_per_target_results.csv')
    status=json.loads((R/'verification/SEARCH_STATUS.json').read_text());refined=json.loads((R/'verification/REFINEMENT_STATUS.json').read_text());ids=json.loads((R/'verification/MODEL_CASE_IDENTITIES.json').read_text())
    meta={v['Case']:v for v in ids};baseline={v['Case']:v['Baseline'] for v in status['Runs']};zero={v['Case']:v['Zero'] for v in status['Runs']}
    captions=[]
    def curve(ax,case):
        for algo in ALGOS:
            g=summary[(summary.Case==case)&(summary.Algorithm==algo)&summary.Feasible_seeds.eq(3)&summary.Target_Y13.ge(zero[case]['Y_13pct'])].sort_values('Target_Y13')
            yy=np.r_[zero[case]['Y_13pct'],g.Target_Y13];xx=np.r_[0.,g.I_median_mm]
            ax.plot(xx,yy,c=COLORS[algo],ls=LINE[algo],marker=MARK[algo],ms=4,lw=1.8,label=LABEL[algo])
            ax.fill_betweenx(yy,np.r_[0.,g.I_min_mm],np.r_[0.,g.I_max_mm],color=COLORS[algo],alpha=.07)
        q=prior[(prior.Case==case)&prior.Historical_best_I_mm.notna()&prior.Target_Y13.ge(zero[case]['Y_13pct'])].sort_values('Target_Y13')
        ax.plot(np.r_[0.,q.Historical_best_I_mm],np.r_[zero[case]['Y_13pct'],q.Target_Y13],c='#475D67',lw=1.5,ls=(0,(2,2)),label='Historical NSGA-III*')
        ax.scatter([0],[zero[case]['Y_13pct']],s=45,facecolors='white',edgecolors='#243C48',zorder=6,label='Zero-irrigation yield')
        ax.scatter([baseline[case]['Irrigation_mm']],[baseline[case]['Y_13pct']],marker='*',s=90,c='#243C48',zorder=6,label='DI model baseline')
        obs=next(t[1]/.95 for t in meta[case]['Targets'] if t[0]=='Observed_0.95');ax.axhline(.95*obs,color='#AE8172',ls=(0,(2,3)),lw=.8)
        ax.set(xlabel='Minimum irrigation found (mm)',ylabel='Required grain yield (t ha⁻¹)',xlim=(-5,meta[case]['Seasonal_cap_mm']*1.035),ylim=(0,obs*1.06))
    fig,axs=plt.subplots(2,2,figsize=(12,8.1))
    for ax,case in zip(axs.flat,CASES[:4]):curve(ax,case);ax.set_title(case[-4:])
    fig.suptitle('Single-objective minimum-irrigation searches | historical four-year models',fontsize=15,y=1.08)
    h,l=axs.flat[0].get_legend_handles_labels();fig.legend(h,l,loc='upper center',bbox_to_anchor=(.5,1.045),ncol=3,frameon=False)
    fig.text(.5,-.012,'Maximum root depth 2.30 m; fMulch = 0.  Bands: range across three seeds.  *External, unequal search budget.',ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.02,1,.97]);save(fig,'S01_Four_year_minimum_irrigation_EN')
    captions.append(('S01_Four_year_minimum_irrigation_EN','Historical four-year models: yield-constrained irrigation minimization','GA denotes real-coded genetic algorithm, GSA generalized simulated annealing, and DE differential evolution; NSGA-II is used with one objective. Each method minimizes actual irrigation subject to a prescribed Y13 threshold. Curves show median threshold minima from its own complete sweep archive; bands span three seeds and are not confidence intervals. Open circles show actual modeled zero-irrigation yield. The star is the DI model baseline. Historical NSGA-III is an external archive with a different evaluation budget. Lines join discrete tested requirements; they do not establish global optimality.'))
    fig,axs=plt.subplots(1,3,figsize=(13,4.9),sharey=True)
    for ax,case in zip(axs,CASES[4:]):curve(ax,case);ax.set_title(SHORT[case]);ax.set_xticks([0,200,400,633.47],['0','200','400','633.47'])
    for ax in axs[1:]:ax.set_ylabel('')
    fig.suptitle('2021 conditional pilot models | maximum root depth 1.00 m',fontsize=15,y=1.14)
    h,l=axs[0].get_legend_handles_labels();fig.legend(h,l,loc='upper center',bbox_to_anchor=(.5,1.10),ncol=3,frameon=False)
    fig.text(.5,-.04,'Separate conditional parameter sets; original GEE forcing.  No added storage floor or event hardware cap.',ha='center',fontsize=9)
    fig.tight_layout();save(fig,'S02_2021_three_fMulch_minimum_irrigation_EN')
    captions.append(('S02_2021_three_fMulch_minimum_irrigation_EN','2021 conditional models: three fMulch scenarios','The three panels use different previously selected conditional parameter sets at fMulch 0.50, 0.75 and 0.85; this is not a parameter-fixed one-factor mulch experiment. Maximum root depth is 1.00 m. The original GEE weather, initial soil water, original event dates and four irrigation windows are retained. No terminal-storage floor is added. The 500-step parent fits have not demonstrated posterior convergence. Other plotting conventions follow S01.'))
    # Actual response points are real evaluated controls, not target values.
    fig,ax=plt.subplots(figsize=(9,5.4));case='new_fm085'
    for algo in ALGOS:
        v=pool[(pool.Case==case)&(pool.Algorithm==algo)&pool.Status.eq('FEASIBLE_FOUND')]
        keep=v.sort_values('Irrigation_mm').groupby('Target_ID',sort=False).head(1).drop_duplicates(['Irrigation_mm','Y_13pct']).sort_values('Irrigation_mm')
        ax.plot(keep.Irrigation_mm,keep.Y_13pct,c=COLORS[algo],ls=LINE[algo],marker=MARK[algo],ms=5,lw=1.5,label=LABEL[algo])
    proportional=pd.read_csv(R/'tables/Source_new_proportional_responses.csv');proportional=proportional[proportional.Scenario.eq('fm085')].sort_values('Irrigation_mm')
    ax.plot(proportional.Irrigation_mm,proportional.Y_13pct,c='#89949A',ls='--',lw=1.3,label='Proportional DI response (prior run)')
    front=pd.read_csv(R/'tables/Source_new_NSAG3_front.csv');front=front[front.Scenario.eq('fm085')].sort_values('Irrigation_mm');ax.plot(front.Irrigation_mm,front.Y_13pct,c='#263F49',alpha=.6,lw=1.5,label='Historical NSGA-III front*')
    ax.scatter([633.47],[baseline[case]['Y_13pct']],marker='*',s=140,c='#243C48');ax.axhline(15.067,c='#AE8172',ls=':',lw=1,label='95% of published DI yield')
    ax.set(xlim=(0,650),ylim=(0,17),xlabel='Actual seasonal irrigation (mm)',ylabel='Achieved grain yield at 13% moisture (t ha⁻¹)',title='2021, fMulch = 0.85 | actual evaluated solutions')
    ax.legend(loc='lower right',frameon=False,fontsize=10.5);fig.tight_layout();save(fig,'S03_2021_actual_yield_irrigation_EN')
    captions.append(('S03_2021_actual_yield_irrigation_EN','Actual achieved yield and irrigation for the 2021 fMulch 0.85 model','Markers are actual evaluated solutions, selected as the lowest-irrigation feasible candidate over three seeds for each method and requirement. The y-axis is achieved model yield, whereas S01–S02 show required yield. No missing or failed thresholds are imputed. The prior proportional response changes all original event amounts by a common factor; optimized solutions redistribute amounts among four windows. The historical NSGA-III front uses a different search budget.'))
    fig,ax=plt.subplots(figsize=(10.5,6));gate=pool[pool.Target_ID.eq('Observed_0.95')]
    for j,case in enumerate(CASES):
        ax.axhspan(j-.45,j+.45,color='#E8EFF2',alpha=.4 if j%2==0 else .12)
        for k,algo in enumerate(ALGOS):
            g=gate[(gate.Case==case)&(gate.Algorithm==algo)&gate.Status.eq('FEASIBLE_FOUND')]
            yy=j+(k-1.5)*.16;ax.scatter(g.Irrigation_mm,np.repeat(yy,len(g)),c=COLORS[algo],marker=MARK[algo],s=35,label=LABEL[algo] if j==0 else None)
        p=prior[(prior.Case==case)&prior.Target_ID.eq('Observed_0.95')].iloc[0]
        if np.isfinite(p.Historical_best_I_mm):ax.scatter(p.Historical_best_I_mm,j,c='#253D49',marker='|',s=200,label='Historical NSGA-III*' if j==0 else None)
    ax.set_yticks(range(7),[SHORT[c] for c in CASES]);ax.invert_yaxis();ax.set(xlabel='Minimum irrigation found at 95% published yield (mm)',title='Three-seed variability at the shared yield requirement')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.12),ncol=3,frameon=False);fig.tight_layout();save(fig,'S04_95pct_yield_algorithm_comparison_EN')
    captions.append(('S04_95pct_yield_algorithm_comparison_EN','Algorithm and seed comparison at 95% of published DI yield','Each colored marker is the minimum feasible irrigation in one method/seed archive, including the equal 384-query continuation at this requirement. Three seeds are displayed separately. Dark ticks show historical NSGA-III archive minima, which are references rather than equal-budget competitors. The requirement is 95% of the observed yield level, not a 95% probability of success.'))
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.8))
    for ax,case in zip(axs,['old_2021','new_fm085']):
        for algo in ALGOS:
            v=hist[(hist.Case==case)&(hist.Algorithm==algo)&hist.Target_ID.eq('Observed_0.95')&hist.Phase.eq('Independent_threshold_search')]
            st=v.groupby('Query').Best_feasible_I_mm.agg(['median','min','max'])
            ax.plot(st.index,st['median'],color=COLORS[algo],ls=LINE[algo],lw=1.8,label=LABEL[algo]);ax.fill_between(st.index,st['min'],st['max'],color=COLORS[algo],alpha=.08)
        ax.set(title=SHORT[case],xlabel='Objective queries in independent target run',ylabel='Best feasible irrigation so far (mm)',xlim=(0,384))
    fig.legend(*axs[0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.5,-.12),ncol=2,frameon=False);fig.suptitle('Convergence at 95% published yield | independent phase',fontsize=15,y=1.02);fig.tight_layout();save(fig,'S05_2021_convergence_EN')
    captions.append(('S05_2021_convergence_EN','Convergence at the 95% observed-yield requirement','Lines show the median incumbent feasible irrigation across three seeds during the 384-query independent run; shading spans the seed minimum and maximum. Setup initial populations contain the DI baseline, ensuring a feasible anchor at this requirement. The later equally budgeted 384-query continuation is reported separately. Convergence here assesses numerical search, not correctness of the model water-stress response.'))
    fig,ax=plt.subplots(figsize=(11,5.7));xx=np.arange(7);positive=np.zeros(7);negative=np.zeros(7)
    for col,label,color in [('Reduction_ET_mm','Reduction in ET','#0072B2'),('Reduction_final_full_profile_storage_mm','Lower final profile storage','#D55E00'),('Other_flux_difference_mm','Other water-flux differences','#8E9DA5')]:
        val=budget.set_index('Case').loc[CASES,col].to_numpy();bottom=np.where(val>=0,positive,negative);ax.bar(xx,val,bottom=bottom,width=.62,color=color,label=label)
        positive+=np.maximum(val,0);negative+=np.minimum(val,0)
    ax.scatter(xx,budget.set_index('Case').loc[CASES,'Reduction_I_mm'],marker='D',s=40,c='#203945',zorder=5,label='Total irrigation reduction')
    ax.axhline(0,c='#203945',lw=.8);ax.set_xticks(xx,[SHORT[c].replace(' | ','\n') for c in CASES]);ax.tick_params(axis='x',labelsize=9);ax.set(ylabel='DI baseline minus selected candidate (mm)',title='Water-budget accounting for best-found 95%-yield candidates')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.15),ncol=2,frameon=False);fig.tight_layout();save(fig,'S06_Irrigation_reduction_water_budget_EN')
    captions.append(('S06_Irrigation_reduction_water_budget_EN','Water-budget decomposition of irrigation reduction','For each model, the lowest-irrigation 95%-yield candidate found across the four methods and three seeds is compared with its own DI baseline. The storage term is the complete hydrological profile at the common calendar endpoint, not the root zone alone. Other differences close the accounting for runoff, drainage, groundwater and surface-storage terms. Irrigation reductions must not be interpreted as equal reductions in ET or as validated sustainable field savings.'))
    pd.DataFrame(captions,columns=['Figure_ID','Title','English_caption']).to_csv(R/'tables/Figure_captions.csv',index=False)
    # Diagnostic of late-budget improvement, without inventing convergence.
    late=[]
    for (case,algo,seed,tid,phase),v in hist.groupby(['Case','Algorithm','Seed','Target_ID','Phase']):
        a=v[v.Query.le(288)].sort_values('Query').tail(1);b=v.sort_values('Query').tail(1)
        if len(a) and len(b):late.append(dict(Case=case,Algorithm=algo,Seed=seed,Target_ID=tid,Phase=phase,I_at_75pct_budget_mm=a.Best_feasible_I_mm.iloc[0],I_final_mm=b.Best_feasible_I_mm.iloc[0],Last_quarter_improvement_mm=a.Best_feasible_I_mm.iloc[0]-b.Best_feasible_I_mm.iloc[0]))
    pd.DataFrame(late).to_csv(R/'tables/Late_budget_improvement.csv',index=False)
    common=summary.groupby(['Case','Target_ID']).Feasible_seeds.min().eq(3)
    mm=summary.join(common.rename('Common_feasible'),on=['Case','Target_ID'])
    mm=mm[mm.Common_feasible&mm.Target_Y13.gt(mm.Case.map({c:v['Y_13pct'] for c,v in zero.items()}))].copy()
    mm['Family']=np.where(mm.Case.str.startswith('old'),'Historical four-year','New 2021 three-fMulch')
    mm['Seasonal_cap_mm']=mm.Case.map({k:v['Seasonal_cap_mm'] for k,v in meta.items()})
    mm['Excess_pct_cap']=100*mm.Median_excess_vs_best_new_mm/mm.Seasonal_cap_mm;mm['Seed_range_mm']=mm.I_max_mm-mm.I_min_mm
    perf=mm.groupby(['Family','Algorithm']).agg(Common_feasible_thresholds=('Target_ID','size'),Mean_excess_vs_new_best_mm=('Median_excess_vs_best_new_mm','mean'),Mean_excess_pct_cap=('Excess_pct_cap','mean'),Median_three_seed_range_mm=('Seed_range_mm','median')).reset_index()
    perf.to_csv(R/'tables/Descriptive_algorithm_performance.csv',index=False)
    workbook()
    report(meta,baseline,summary,pool,budget,status,refined,captions)
    packages=['aquacrop','numpy','pandas','numba','scipy','pymoo','matplotlib','python-docx','openpyxl','PyMuPDF','pillow','emcee']
    (R/'requirements.txt').write_text('\n'.join(f'{p}=={importlib.metadata.version(p)}' for p in packages)+'\n')
    print('Created six figure groups, Excel and Word.')

def workbook():
    names={'Method performance':'Descriptive_algorithm_performance','95pct comparison':'At_95pct_observed_summary','Algorithm summaries':'Algorithm_seed_summary','Raw threshold searches':'Independent_per_target_results','Sweep archive minima':'Within_method_sweep_archive_minima','Historical references':'Historical_NSGA3_threshold_reference','Convergence':'Convergence_history','Late budget changes':'Late_budget_improvement','Full adapter replays':'Full_adapter_selected_control_replays','Event schedules':'Selected_event_schedules','Water budgets':'Best_95pct_irrigation_reduction_budget','Best 95pct controls':'Overall_best_95pct_candidates','Figure captions':'Figure_captions'}
    with pd.ExcelWriter(D/'URP_Single_Objective_Comparison_Data.xlsx',engine='openpyxl') as x:
        for sheet,name in names.items():pd.read_csv(R/'tables'/f'{name}.csv').to_excel(x,sheet_name=sheet,index=False)
        for ws in x.book.worksheets:
            ws.freeze_panes='D2';ws.auto_filter.ref=ws.dimensions;ws.row_dimensions[1].height=44
            for c in ws[1]:c.fill=PatternFill('solid',fgColor='20586B');c.font=Font(color='FFFFFF',bold=True);c.alignment=Alignment(wrap_text=True,vertical='center')
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width=min(35,max(12,max(len(str(c.value or '')) for c in list(col)[:80])+1))
                for c in list(col)[1:]:
                    if isinstance(c.value,float):c.number_format='0.000'

def report(meta,baseline,summary,pool,budget,status,refined,captions):
    doc=Document();s=doc.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7);s.left_margin=s.right_margin=Cm(1.7);s.top_margin=s.bottom_margin=Cm(1.6)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2']:
        st=doc.styles[name];st.font.name='Noto Sans CJK SC';st._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.styles['Normal'].font.size=Pt(10);doc.styles['Normal'].paragraph_format.line_spacing=1.12;doc.styles['Normal'].paragraph_format.space_after=Pt(5)
    doc.styles['Title'].font.size=Pt(23);doc.styles['Heading 1'].font.size=Pt(15);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('20586B');doc.styles['Heading 2'].font.size=Pt(12)
    footer=s.footer.paragraphs[0];footer.alignment=2;footer.add_run('URP · 单目标算法验证 · 2026-10-21 | ');fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)
    def p(t):return doc.add_paragraph(t)
    def h(t):doc.add_heading(t,level=1)
    def table(headers,rows):
        t=doc.add_table(rows=1,cols=len(headers));t.style='Light Shading Accent 1'
        for c,v in zip(t.rows[0].cells,headers):c.text=str(v)
        rep=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(rep)
        for vals in rows:
            for c,v in zip(t.add_row().cells,vals):c.text=str(v)
        for row in t.rows:
            row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
            for cell in row.cells:
                for pa in cell.paragraphs:
                    for ru in pa.runs:ru.font.size=Pt(8)
    def figure(i,analysis):
        id,title,cap=captions[i];doc.add_heading(title,level=2);doc.add_picture(str(F/f'{id}_preview.jpg'),width=Cm(17.1))
        doc.paragraphs[-1].paragraph_format.keep_with_next=True
        cp=p(cap);cp.paragraph_format.keep_with_next=True
        ap=p('解析：'+analysis);ap.paragraph_format.keep_together=True
    doc.add_heading('单目标灌水优化与多算法验证',0);p('历史四年模型与2021年三个地膜情景｜产量门槛扫描｜2026年10月21日')
    headline=budget[budget.Case.eq('new_fm085')].iloc[0]
    mm=summary[summary.Case.eq('new_fm085')&summary.Target_ID.eq('Observed_0.95')]
    p(f'本轮要点：最新2021年fMulch=0.85模型，在95%观测产量门槛（15.067 t/ha）下，新单目标方法最低找到{headline.Candidate_I_mm:.2f} mm；四种方法的三种子中位数为{mm.I_median_mm.min():.2f}—{mm.I_median_mm.max():.2f} mm。减灌对应ET减少{headline.Reduction_ET_mm:.2f} mm、整个剖面季末储水减少{headline.Reduction_final_full_profile_storage_mm:.2f} mm。数值求解交叉证据与田间物理验证应分开判断。')
    h('1. 问题如何从双目标变为单目标')
    p('对每个给定产量要求q，求解：min I_actual(x)，约束Y13(x)≥q；x为四个灌水窗口的计划总量，x_j≥0，Σx_j≤当年实测季节灌水量。原灌水日期和窗口内分配比例固定，保留原模型实际收获后取消灌水的规则。只最小化灌水而不限制产量时，零灌水就是平凡最优，因此必须逐级设置产量要求。')
    p('本次q取各模型DI基准产量的50%、70%、85%、95%、100%，另加观测产量的95%和100%。这是ε约束扫描；每个子问题只有灌水量一个目标。连接得到“要求产量—最低找到灌水量”的离散曲线。它与一条固定灌水比例的响应曲线含义不同，也不是全局最优的数学证明。')
    p('统一标量适应度：可行时F=I_actual/I_cap；不满足产量要求时F=1+(q−Y13)/q。可行解优于不可行解，不可行解按产量缺口排序。所有算法使用同一可行优先规则与数值容差。四维归一化候选经共同径向修复满足季节上限，原四窗口控制的可达范围不变。')
    h('2. 两套模型和边界')
    table(['模型','根深 m','fMulch','固定内容'],[('历史2019—2022',2.3,0,'原中心参数、GEE气象、土壤和初始水分'),('最新2021情景',1.0,'0.50 / 0.75 / 0.85','各自条件拟合参数与原气象、土壤、初始水分')])
    p('三种fMulch对应三个不同条件拟合参数集，不是保持参数不变的单因子地膜试验。覆膜率均为75%。本次不更换降水、不重新MCMC、不增加季末储水约束或额外单次设备上限；这是原问题的数值求解交叉检查，不是修正其物理设定。根深1 m时仍保留原2.4 m水文域。500步pilot尚未证明后验收敛。')
    h('3. 四种方法的求解思路与公平设置')
    table(['方法','机制','本次设置'],[('连续实数GA','选择、交叉、变异；适合非光滑黑箱','32个体；SBX p=0.9, η=15；PM η=20，变量概率0.25'),('NSGA-II单目标','保留框架但只优化一个标量','与GA相同种群与交叉/变异；单目标下非支配排序退化为目标排序'),('广义模拟退火GSA','单轨迹随机搜索，接受部分劣解以跳出局部区域','SciPy dual_annealing；初温1，visit=2.62，accept=-5；关闭局部搜索'),('差分进化DE','利用种群差分产生候选，适合连续变量','best1bin；种群32；F∈[0.5,1]；CR=0.7；关闭额外polish')])
    p('每个非平凡产量要求、每种方法、每个种子均384次目标查询，三个种子为31/73/109。共同初始样本含零灌、DI、同比例灌水、单窗口锚点和随机点，不使用历史NSGA-III候选作热启动。95%观测产量门槛再给每种方法额外384次延续搜索，仅从其自身前一阶段档案初始化，其他算法和历史前沿的解不共享。')
    p('若零灌已满足某门槛，则由灌水非负可直接证明该子问题最小值为0，各方法共同跳过其随机搜索。若SciPy提前终止，剩余查询预算以预设随机全局探测补足并单独记录。原始独立结果与方法自身档案筛选结果分开保存。')
    p('确定性模型响应采用完全相同控制向量的精确缓存，绝不插值或使用代理模型。公平预算按算法请求的目标查询计数，缓存命中仍计入预算；实际模型调用单独记录。共享缓存会影响实际墙钟耗时，故本报告不以暖缓存耗时排名算法速度。')
    q=status['Total_objective_queries']+refined['Total_objective_queries'];calls=status['Actual_optimization_model_calls']+refined['Actual_optimization_model_calls']
    check=json.loads((R/'verification/AGGREGATION_CHECK.json').read_text())
    p(f'实际完成：独立阶段{status["Total_objective_queries"]:,}次查询，门槛延续{refined["Total_objective_queries"]:,}次，共{q:,}次；优化过程实际模型调用{calls:,}次，另有设置和验证调用。对{check["Actual_distinct_full_adapter_replays"]}个不同入选控制使用完整原适配器复算，最大主要输出差异{check["Maximum_fast_full_difference"]:.2e}，每日水量平衡最大残差{check["Maximum_full_replay_daily_balance_residual_mm"]:.2e} mm。')
    h('4. 如何读本报告中的曲线')
    p('保留两种结果：第一种是每个门槛独立求解的原始结果；第二种是在每个方法/种子自身完整扫描档案中，筛选满足该门槛的最低灌水控制。后者利用所有已评价点，保证嵌套门槛下的最低找到灌水量不随产量要求升高而下降；它是事后筛选，不是额外求解或数据平滑。论文主图采用后者，原始独立结果完整留表。')
    p('每种方法在同一模型内获得相同总预算。历史NSGA-III使用不同、通常更大的预算，作为外部参考；不能据本次曲线或实际耗时给NSGA-III作公平速度排名。“预算内未找到可行解”不等于证明数学不可行。图中三种子的范围不是统计置信区间。')
    doc.add_page_break();figure(0,'四年分别使用自己的固定参数、实测DI日程和原气象。比较同一产量要求下各方法的横向距离；更靠左代表在已搜索控制中用水更少。若新方法找到比历史档案更靠左的有效解，说明原档案仍有改进空间；若更靠右，也可能仅因本次预算或搜索策略不足。')
    figure(1,'三幅图用于判断300—350 mm附近的解是否只由NSGA-III产生。多种求解器接近只能支持数值一致性，不能证明土壤供水、蒸腾胁迫或地膜参数在田间正确。观测100%产量门槛未找到解时保留缺失，不外推到目标线。')
    figure(2,'该图将纵轴改为实际模拟产量，所有点都是实际评价过的控制；可与固定比例灌水响应和历史前沿直接对照。即使多个算法得到类似低水高产点，也仍需用分层含水量、ET/Es以及亏缺灌溉观测验证模型。')
    h('5. 最关键的95%观测产量门槛')
    perf=pd.read_csv(R/'tables/Descriptive_algorithm_performance.csv')
    p('综合精度用共同找到可行解的产量门槛作描述性比较：各方法的三种子灌水中位数，减去本轮各方法/种子联合档案中的最低值。平均超额越小，表示更接近本轮找到的最好解；它不是相对全局最优的误差，也不做小样本显著性推断。')
    table(['模型组','方法','平均超额 I/mm','三种子极差中位/mm'],[('历史四年' if t.Family.startswith('Historical') else '最新2021三情景',t.Algorithm,f'{t.Mean_excess_vs_new_best_mm:.2f}',f'{t.Median_three_seed_range_mm:.2f}') for _,t in perf.iterrows()])
    gate=summary[summary.Target_ID.eq('Observed_0.95')]
    table(['模型','方法','最低 I/mm','三种子中位 I/mm','范围/mm','历史NSGA-III/mm'],[(SHORT[t.Case],t.Algorithm,f'{t.I_min_mm:.2f}',f'{t.I_median_mm:.2f}',f'{t.I_min_mm:.2f}—{t.I_max_mm:.2f}',f'{t.Historical_best_I_mm:.2f}') for _,t in gate.iterrows()])
    figure(3,'先看不同种子的离散程度，再看方法之间的差距。靠近历史NSGA-III不构成全局最优证明；明显高于其他方法时，应结合收敛图判断预算是否足够，不宜直接宣布某方法物理上不合理。')
    figure(4,'曲线末端若仍明显下降，表示本预算下尚有搜索改善迹象。两种模型的差异不能归因于算法，因为根深、地膜与条件参数也不同。84组模型×算法×种子组合均保留目标查询日志，门槛延续阶段另行保留。')
    h('6. 水量账决定如何解释“节水”')
    table(['模型','最低找到 I/mm','减灌/mm','ET减少/mm','季末剖面储水减少/mm'],[(SHORT[t.Case],f'{t.Candidate_I_mm:.2f}',f'{t.Reduction_I_mm:.2f}',f'{t.Reduction_ET_mm:.2f}',f'{t.Reduction_final_full_profile_storage_mm:.2f}') for _,t in budget.iterrows()])
    figure(5,'整个水文剖面季末储水差反映两种管理留下的库存不同，不能全部解释成作物额外吸水，更不能与0—1 m根区储水混用。如果减灌主要由库存差而非ET减少构成，应表述为有储水代价的条件性减灌潜力。是否能跨季恢复，需要实测含水量和休闲期补给核查。')
    h('7. 是否可以据此锁定原NSGA-III方案？')
    best=pool[pool.Target_ID.eq('Observed_0.95')&pool.Status.eq('FEASIBLE_FOUND')].sort_values('Irrigation_mm').groupby('Case').head(1)
    p(f'本轮七组模型在95%观测产量门槛下，最低找到灌水量与历史NSGA-III档案门槛解的差值为{best.Gap_to_historical_I_mm.min():+.2f}至{best.Gap_to_historical_I_mm.max():+.2f} mm。这支持主要权衡关系的数值一致性。部分新解优于历史有限档案，故不宜把原档案当成已证明的全局最优；历史预算又不同，不能据这些差值作正式算法效率排名。')
    p('本试验可以回答“单目标ε约束求解能否重现原双目标档案的主要权衡、是否发现更低灌水解、各算法对随机种子是否敏感”。它不能回答“300—350 mm一定足够田间玉米稳产”，也不能替代对原降水来源、初始储水、深层土壤扩展及水分胁迫过程的验证。')
    p('若独立方法在可接受数值差距内接近原方案，可将其作为原前沿的数值交叉证据。若出现更优点，应先完整模型回放，再将该点加入候选档案；若各法差距较大或末期仍在改善，则需增加匹配预算，不能草率认定已经全局收敛。季末储水和其他物理约束若后续正式更改，应统一重新求解，不能把本次无新增储水约束的曲线直接当作新物理约束下的结果。')
    p('论文可写：“采用产量门槛扫描将双目标问题转化为一系列最小灌水单目标问题，并使用实数GA、单目标NSGA-II、广义模拟退火和差分进化进行交叉求解。比较在一致的评价预算、控制域和固定模型条件下进行。报告有限搜索档案中的最低可行灌水量及随机种子差异，未将其解释为全局最优证明。同步给出ET与土壤库存变化，区分减灌与耗水减少。”')
    h('8. 交付与复现')
    p('figures含六组英文600dpi PNG、PDF和SVG。Excel含独立子问题结果、方法自身扫描档案最小值、历史参考、收敛、完整模型复算、逐次灌水日程及水量账。runs含逐次目标查询CSV.gz、独立结果、延续结果、配置及状态。model_snapshots和dependencies仅包含本次固定参数回放所需依赖，不含全量MCMC后验链。')
    p('复现：安装requirements.txt；python code/exact_engine.py；python code/run_comparison.py；python code/refine_95pct.py；python code/aggregate_results.py；python code/build_outputs.py。脚本为防止混入重复记录会拒绝覆盖未完成运行，完整已有结果会跳过。建议在复制出的独立目录复现。报告PDF由Word另行导出。')
    doc.save(D/'URP_Single_Objective_Comparison_Report.docx')
if __name__=='__main__':main()
