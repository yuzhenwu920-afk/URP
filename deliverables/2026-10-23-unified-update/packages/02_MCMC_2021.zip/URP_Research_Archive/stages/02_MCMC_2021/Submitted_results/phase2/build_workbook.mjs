
import fs from 'node:fs/promises';import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';
const out=process.argv[2],require=createRequire(process.argv[3]+'/entry.cjs');const {Workbook,SpreadsheetFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool')).href);
const tables=JSON.parse(await fs.readFile(out+'/workbook_tables.json','utf8')),wb=Workbook.create();
for(const [name,rows] of Object.entries(tables)){const sh=wb.worksheets.add(name);sh.showGridLines=false;sh.getRangeByIndexes(0,0,rows.length,rows[0].length).values=rows;
 const used=sh.getUsedRange();used.format.font={name:'Arial',size:10};used.format.rowHeight=20;used.setNumberFormat('0.000000');used.format.verticalAlignment='center';
 for(let j=0;j<rows[0].length;j++){const width=Math.max(18,Math.min(80,Math.max(...rows.map(r=>typeof r[j]==='string'?r[j].length:0))+3));sh.getRangeByIndexes(0,j,rows.length,1).format.columnWidth=width;
  if(rows[0][j]==='Date'){sh.getRangeByIndexes(1,j,rows.length-1,1).values=rows.slice(1).map(r=>[new Date(r[j]+'T00:00:00Z')]);sh.getRangeByIndexes(1,j,rows.length-1,1).setNumberFormat('yyyy-mm-dd');}
  if(rows[0][j]==='Year')sh.getRangeByIndexes(1,j,rows.length-1,1).setNumberFormat('0');if(rows[0][j]==='WB_daily_max')sh.getRangeByIndexes(1,j,rows.length-1,1).setNumberFormat('0.00E+00');}
 sh.getRangeByIndexes(0,0,1,rows[0].length).format={fill:'#28455D',font:{name:'Arial',bold:true,color:'#FFFFFF'},rowHeight:35,wrapText:true};sh.freezePanes.freezeRows(1);}
wb.recalculate();console.log((await wb.inspect({kind:'table',range:'Summary!A1:C14',include:'values,formulas',tableMaxRows:14,tableMaxCols:3})).ndjson);
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#SPILL!',options:{useRegex:true,maxResults:20}})).ndjson);
for(const [name,rows] of Object.entries(tables)){for(let j=0;j<rows[0].length;j+=6){const end=String.fromCharCode(64+Math.min(rows[0].length,j+6));const png=await wb.render({sheetName:name,range:`${String.fromCharCode(65+j)}1:${end}${Math.min(rows.length,14)}`,scale:1,format:'png'});await fs.writeFile(out+'/'+name+'_'+j+'.png',new Uint8Array(await png.arrayBuffer()));}}
await(await SpreadsheetFile.exportXlsx(wb)).save(out+'/DI_2021_phase2_review.xlsx');process.exit(0);
