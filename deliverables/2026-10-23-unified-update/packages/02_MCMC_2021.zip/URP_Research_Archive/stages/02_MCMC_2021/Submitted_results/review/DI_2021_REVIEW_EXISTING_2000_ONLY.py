"""Review/export an EXISTING complete 2021 phase-2 chain; never sample.

This program requires the previously written 32-walker x 2000-step checkpoint.
If that checkpoint is absent, short, malformed or scientifically incompatible, it
stops immediately. It cannot initialize, extend or restart an MCMC chain.
"""
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
import argparse, hashlib, importlib.util, json, os, shutil, subprocess, sys, zipfile
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from emcee.autocorr import integrated_time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJECT=Path(r'C:/Users/Lenovo/PycharmProjects/PythonProject/DI_2021_OneClick')
PHASE1_ZIP=Path(__file__).resolve().parent/'MCMC_Article_Results_2021.zip'
STEPS=2000                 # Total phase-2 steps, not additional steps.
WALKERS=32                 # One ensemble; coupled walkers are not independent chains.
SEED=42
sys.dont_write_bytecode=True

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def clean(v):
    if isinstance(v,dict): return {str(k):clean(x) for k,x in v.items()}
    if isinstance(v,(list,tuple,np.ndarray)): return [clean(x) for x in v]
    if isinstance(v,(np.bool_,)): return bool(v)
    if isinstance(v,(np.integer,)): return int(v)
    if isinstance(v,(float,np.floating)): return float(v) if np.isfinite(v) else None
    if isinstance(v,(Path,pd.Timestamp)): return str(v)
    return v
def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(clean(v),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(q,p)
def portable_contract(v,ignore_versions=False):
    d=json.loads(json.dumps(clean(v)))
    hashes=d.pop('phase1_checkpoint_sha256',{})
    d['phase1_checkpoint_sha256_values']=sorted(hashes.values())
    if ignore_versions:d.pop('versions',None)
    return d
def find_existing_output(requested=None):
    if requested is not None:return requested.resolve()
    here=Path(__file__).resolve().parent;desktop=Path.home()/'Desktop'
    direct=here/'phase2_and_review_results'
    roots=[]
    for p in [here,here.parent,desktop]:
        if p.is_dir() and p not in roots:roots.append(p)
    found=[]
    for root in roots:
        p=root/'phase2_and_review_results/checkpoints/biomass_yield/ensemble_1.npz'
        if p.is_file():found.append(p.resolve())
    if not found and desktop.is_dir():
        found=[p.resolve() for p in desktop.rglob('ensemble_1.npz') if p.parent.name=='biomass_yield' and p.parent.parent.name=='checkpoints']
    found=list(dict.fromkeys(found))
    if len(found)==1:return found[0].parents[2]
    if len(found)>1:raise RuntimeError('REVIEW ONLY: multiple phase-2 checkpoints found; pass --output.\n'+'\n'.join(map(str,found)))
    return direct
def metric(obs,sim,weights=None):
    a,b=np.asarray(obs,float),np.asarray(sim,float)
    if a.shape!=b.shape or not len(a) or not np.isfinite(a).all() or not np.isfinite(b).all(): raise ValueError('Invalid paired data')
    w=np.ones(len(a)) if weights is None else np.asarray(weights,float)
    if (w<0).any() or w.sum()<=0: raise ValueError('Invalid weights')
    w=w/w.sum();d=b-a;ma=np.sum(w*a);mb=np.sum(w*b);va=np.sum(w*(a-ma)**2);vb=np.sum(w*(b-mb)**2)
    r=float(np.sum(w*(a-ma)*(b-mb))/np.sqrt(va*vb)) if len(a)>1 and va>0 and vb>0 else None
    return dict(N=len(a),R_Square=float(1-np.sum(w*d*d)/va) if len(a)>1 and va>0 else None,
                Pearson=r,Pearson_squared=r*r if r is not None else None,RMSE=float(np.sqrt(np.sum(w*d*d))),
                MAE=float(np.sum(w*abs(d))),Bias=float(np.sum(w*d)))
def selftest():
    q=metric([1,2,3],[2,3,4]);assert abs(q['R_Square']+.5)<1e-12 and q['Pearson']==1
    assert metric([1],[1])['R_Square'] is None and metric([1,2],[1,2])['RMSE']==0

def locate_archive_sampling(out,zippath):
    if zippath.is_dir():
        candidates=list(zippath.rglob('canopy_transpiration_diagnostics.json'))
        if len(candidates)!=1: raise RuntimeError('Extracted phase-1 folder must contain exactly one sampling directory')
        return candidates[0].parent
    cache=out/'phase1_archive';marker=cache/'archive_sha256.json';h=sha(zippath)
    if marker.exists() and read(marker).get('sha256')==h:
        candidates=list(cache.rglob('canopy_transpiration_diagnostics.json'))
        if len(candidates)==1:return candidates[0].parent
    if cache.exists(): shutil.rmtree(cache)
    cache.mkdir(parents=True)
    with zipfile.ZipFile(zippath) as z:
        for info in z.infolist():
            dest=(cache/info.filename).resolve()
            if cache.resolve() not in dest.parents and dest!=cache.resolve(): raise RuntimeError('Unsafe ZIP member')
            z.extract(info,cache)
    write(marker,dict(sha256=h,source=str(zippath)))
    candidates=list(cache.rglob('canopy_transpiration_diagnostics.json'))
    if len(candidates)!=1: raise RuntimeError('ZIP must contain exactly one 2021 sampling directory')
    return candidates[0].parent

def load_original(project,out):
    source=project/'DI_2021_MCMC_ONE_CLICK.py'
    spec=importlib.util.spec_from_file_location('di2021_original',source)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    modules={k:mod._embedded_module(k) for k in ['sampler','diagnostics','audit_hooks','ensemble_pipeline']}
    runner=mod._embedded_module('runner');m,data,start,folder=runner.load('2021',out)
    return source,modules,runner,m,data,start,folder

def verify_phase1(sampling,runner,m,data,start,source,out,archive):
    diag=read(sampling/'canopy_transpiration_diagnostics.json')
    paths=sorted((sampling/'checkpoints/canopy_transpiration').glob('ensemble_*.npz'))
    if len(paths)!=4: raise RuntimeError('Expected four complete phase-1 ensembles in ZIP')
    raw=[];logs=[];contracts=[];hashes={str(p):sha(p) for p in paths}
    for p in paths:
        with np.load(p,allow_pickle=False) as z:
            x=z['history'];lp=z['logs'];c=json.loads(str(z['contract'].item()))
            if x.shape!=(2000,32,5) or lp.shape!=(2000,32) or not np.isfinite(x).all() or not np.isfinite(lp).all():
                raise RuntimeError('Incomplete/nonfinite phase-1 checkpoint: '+p.name)
            raw.append(x);logs.append(lp);contracts.append(c)
    raw=np.stack(raw);logs=np.stack(logs)
    base=contracts[0]
    for e,c in enumerate(contracts):
        if any(clean(c.get(k))!=clean(base.get(k)) for k in base if k!='ensemble') or c.get('ensemble')!=e:
            raise RuntimeError('Phase-1 ensemble contracts differ beyond ensemble number')
    current=runner.contract('2021',m,data,m.PHASE1_NAMES,start,'canopy_transpiration',
                            SimpleNamespace(seed=base['seed'],walkers=base['walkers'],smoke=False))
    scientific=['case','phase','names','fixed','priors','normal_priors','prior_sd','center','sigmas','targets','seed','ensembles','walkers','mode','switch','files']
    bad=[k for k in scientific if clean(current.get(k))!=clean(base.get(k))]
    if bad: raise RuntimeError('Current code/data scientific contract differs: '+','.join(bad))
    # Patch versions changed after sampling. Recompute one terminal walker per ensemble.
    endpoint=[]
    for e,p in enumerate(paths):
        j=int(np.argmax(logs[e,-1]));actual=m.logprob(raw[e,-1,j],m.PHASE1_NAMES,start,'canopy_transpiration',data)
        diff=float(actual-logs[e,-1,j]);endpoint.append(dict(Ensemble=e+1,Walker=j,Stored=logs[e,-1,j],Current=actual,Difference=diff))
        if not np.isfinite(actual) or abs(diff)>1e-8: raise RuntimeError('Phase-1 endpoint cannot be reproduced')
    tau=np.array([integrated_time(a,tol=0) for a in raw]);burn=int(np.ceil(5*tau.max()))
    if burn!=diag['Burn_in'] or raw.shape[1]-burn<100: raise RuntimeError('Phase-1 burn-in mismatch')
    point=dict(start,**dict(zip(m.PHASE1_NAMES,map(float,raw[:,burn:].mean((0,1,2))))))
    initial=m.simulate(data,point,'DI')[0]
    report=dict(Archive_sha256=sha(archive) if Path(archive).is_file() else None,Archive_source=str(archive),
                Archive_kind='zip' if Path(archive).is_file() else 'extracted_directory',Checkpoint_sha256=hashes,Original_diagnostics=diag,
                Archived_versions=base['versions'],Current_versions=current['versions'],Version_drift=base['versions']!=current['versions'],
                Endpoint_logposterior_reproduction=endpoint,Burn_in=burn,Tau=tau,Values=point,Metrics=initial,
                Phase1_converged=bool(diag['Converged']),Joint_posterior=False)
    write(out/'phase1_mean_handoff.json',report)
    return raw,logs,burn,point,base,hashes,diag

def load_existing_phase2_only(out,runner,m,data,fixed,hashes):
    names=m.PHASE2_NAMES
    args=SimpleNamespace(seed=SEED,walkers=WALKERS,smoke=False)
    cn=runner.contract('2021',m,data,names,fixed,'biomass_yield',args)
    cn.update(ensembles=1,phase1_checkpoint_sha256=hashes,phase1_burn=read(out/'phase1_mean_handoff.json')['Burn_in'],
              handoff='retained phase-1 arithmetic mean',scope='conditional; not joint posterior')
    path=out/'checkpoints/biomass_yield/ensemble_1.npz'
    if not path.is_file():
        raise FileNotFoundError('REVIEW ONLY: existing 2000-step checkpoint not found: '+str(path))
    with np.load(path,allow_pickle=False) as z:
        required={'history','logs','accepted','contract'}
        if not required.issubset(z.files): raise RuntimeError('REVIEW ONLY: checkpoint is missing required arrays')
        chain=np.asarray(z['history']);logp=np.asarray(z['logs']);accepted=np.asarray(z['accepted'])
        saved=json.loads(str(z['contract'].item()))
    if chain.shape!=(STEPS,WALKERS,len(names)) or logp.shape!=(STEPS,WALKERS) or accepted.shape!=(STEPS,WALKERS):
        raise RuntimeError(f'REVIEW ONLY: expected {(STEPS,WALKERS,len(names))}, found {chain.shape}; no sampling was started')
    if not np.isfinite(chain).all() or not np.isfinite(logp).all():
        raise RuntimeError('REVIEW ONLY: checkpoint contains nonfinite values')
    if portable_contract(saved,True)!=portable_contract(cn,True):
        raise RuntimeError('REVIEW ONLY: checkpoint scientific contract mismatch; no sampling was started')
    j=int(np.argmax(logp[-1]));actual=float(m.logprob(chain[-1,j],names,fixed,'biomass_yield',data));stored=float(logp[-1,j])
    if not np.isfinite(actual) or abs(actual-stored)>1e-8:
        raise RuntimeError(f'REVIEW ONLY: saved phase-2 endpoint cannot be reproduced ({stored} vs {actual})')
    write(out/'phase2_checkpoint_audit.json',dict(
        Checkpoint=str(path),SHA256=sha(path),Shape=list(chain.shape),Saved_versions=saved.get('versions'),
        Current_versions=cn.get('versions'),Version_drift=saved.get('versions')!=cn.get('versions'),
        Endpoint_walker=j,Stored_logposterior=stored,Current_logposterior=actual,Difference=actual-stored,
        Scientific_contract_match=True,Sampling_started=False))
    print('REVIEW ONLY: loaded existing checkpoint',path,'shape',chain.shape,flush=True)
    return chain,logp,accepted,cn

def diagnostics(chain,accepted,m,status_phase1):
    tau=integrated_time(chain,tol=0);valid=bool(np.isfinite(tau).all() and (tau>0).all())
    burn=int(np.ceil(5*tau.max())) if valid else len(chain);post=chain[burn:]
    rows=[]
    if len(post):
        for j,k in enumerate(m.PHASE2_NAMES):
            z=post[:,:,j];lo,hi=m.PRIOR_BOUNDS[k];half=len(z)//2
            rows.append(dict(Parameter=k,Mean=z.mean(),SD=z.std(ddof=1),P025=np.quantile(z,.025),Median=np.quantile(z,.5),P975=np.quantile(z,.975),
                Prior_low=lo,Prior_high=hi,Boundary_mass_1pct=np.mean((z<=lo+.01*(hi-lo))|(z>=hi-.01*(hi-lo))),
                Half_shift_SD=(z[half:].mean()-z[:half].mean())/z.std(),Tau=tau[j]))
    d=dict(Shape=list(chain.shape),Burn_in=burn,Retained_correlated_draws=int(post.shape[0]*post.shape[1]),Tau=tau,
           Tau_trusted_50tau=bool(valid and len(chain)>=50*tau.max()),Acceptance_by_walker=accepted.mean(0),
           Parameter_summary=rows,Correlation=np.corrcoef(post.reshape(-1,len(m.PHASE2_NAMES)).T) if len(post) else None,
           Rhat=None,Rhat_note='One ensemble; coupled walkers are not independent chains',Phase1_converged=status_phase1,
           Joint_posterior=False,Independent_validation=False,Zero_irrigation_validated=False)
    return d,post

def sensitivity(m,data,p1raw,p1logs,b1,basepoint,phase2point,out):
    cases={'pooled_mean':phase2point.copy()}
    for e in range(4):
        cases[f'ensemble_{e+1}_mean']=dict(phase2point,**dict(zip(m.PHASE1_NAMES,map(float,p1raw[e,b1:].mean((0,1))))))
    ix=np.unravel_index(np.argmax(p1logs[:,b1:]),p1logs[:,b1:].shape)
    cases['phase1_sampled_MAP']=dict(phase2point,**dict(zip(m.PHASE1_NAMES,map(float,p1raw[:,b1:][ix]))))
    names=m.PHASE2_NAMES;bounds=np.array([m.PRIOR_BOUNDS[k] for k in names]).T;width=bounds[1]-bounds[0]
    rows=[];fits=[]
    for label,p in cases.items():
        print('Sensitivity',label,flush=True)
        def residual(q):
            v=dict(p,**dict(zip(names,map(float,bounds[0]+q*width))))
            s,g,cc,bio=m.simulate(data,v,'DI')
            prior=[(v[k]-data['center'][k])/m.PRIOR_SD[k] for k in names if k in m.NORMAL_PRIORS]
            return np.r_[(bio.Biomass_t_ha-bio.Observed_B_t_ha)/bio.Sigma_assumed,(s['Y_dry']-m.YDRY_TARGET)/m.SIGMA_Y,prior]
        attempts=[]
        start_audit=[]
        for initial in [[phase2point[k] for k in names],[basepoint[k] for k in names]]:
            raw=np.asarray(initial,float);q_raw=(raw-bounds[0])/width
            if not np.isfinite(q_raw).all(): raise RuntimeError(f'Nonfinite sensitivity start for {label}')
            # The archived model start can legitimately predate the narrowed phase-2 priors.
            # Project only the optimizer start into the open feasible interval; the model,
            # posterior samples and prior bounds themselves are not altered.
            q0=np.clip(q_raw,1e-8,1-1e-8)
            projected=bounds[0]+q0*width
            start_audit.append(dict(Raw=dict(zip(names,map(float,raw))),
                                    Projected=dict(zip(names,map(float,projected))),
                                    Projection_applied=bool(not np.array_equal(q_raw,q0))))
            fit=least_squares(residual,q0,bounds=(np.full(len(names),1e-8),np.full(len(names),1-1e-8)),
                              diff_step=1e-4,max_nfev=40,ftol=1e-7,xtol=1e-7,gtol=1e-7)
            attempts.append(fit)
        best=min(attempts,key=lambda x:x.cost);adjusted=dict(p,**dict(zip(names,map(float,bounds[0]+best.x*width))))
        fits.append(dict(Case=label,Success=bool(best.success),Cost=best.cost,Optimality=best.optimality,Start_audit=start_audit,Start_costs=[x.cost for x in attempts],
                         Start_parameters=[(bounds[0]+x.x*width).tolist() for x in attempts],Parameters=adjusted,
                         Meaning='Two-start local conditional MAP optimization; not MCMC or global-optimum proof'))
        for mode,v in [('fixed_phase2_mean',p),('conditional_MAP_refit',adjusted)]:
            s=m.simulate(data,v,'DI')[0];z=m.simulate(data,v,'zero')[0]
            rows.append(dict(Case=label,Mode=mode,**v,Y13=s['Y_13pct'],Zero_Y13=z['Y_13pct'],Zero_loss_pct=100*(1-z['Y_13pct']/s['Y_13pct']),
                             Tr=s['Tr_mm'],Es=s['Es_mm'],ET=s['ET_mm'],CC_RMSE=s['CC_RMSE'],B_RMSE=s['B_RMSE'],WB_daily_max=s['Max_daily_balance_residual_mm']))
        write(out/'sensitivity_progress.json',dict(Rows=rows,Fits=fits))
    return pd.DataFrame(rows),fits

def postprocess(project,out,source,m,data,start,p1raw,p1logs,b1,phase1point,chain,accepted,diag1,smoke):
    d2,post=diagnostics(chain,accepted,m,bool(diag1['Converged']));write(out/'sampling_diagnostics.json',d2)
    if smoke:
        write(out/'run_status.json',dict(State='SMOKE_COMPLETE',Sampling_complete=True,Inference=False));return
    if len(post)<100: raise RuntimeError('No adequate retained phase-2 samples; increase total steps')
    mean=post.mean((0,1));point=dict(phase1point,**dict(zip(m.PHASE2_NAMES,map(float,mean))))
    s,g,cc,bio=m.simulate(data,point,'DI');z=m.simulate(data,point,'zero')[0]
    cc=cc.rename(columns={'Observed_CC':'CC_observed','canopy_cover':'CC_simulated'});cc['Residual']=cc.CC_simulated-cc.CC_observed
    cc['Source']='Field LAI-derived CC; calibration, not independent validation'
    bio=bio.rename(columns={'Observed_B_t_ha':'B_observed_t_ha','Biomass_t_ha':'B_simulated_t_ha'})
    bio['Source']='Digitized biomass with assumed sigma; calibration, not independent validation'
    ccm=metric(cc.CC_observed,cc.CC_simulated);ccw=metric(cc.CC_observed,cc.CC_simulated,cc.Weight);bm=metric(bio.B_observed_t_ha,bio.B_simulated_t_ha)
    if abs(ccm['RMSE']-s['CC_RMSE'])>1e-12 or abs(bm['RMSE']-s['B_RMSE'])>1e-12: raise RuntimeError('Metric reproduction failed')
    yieldrow=dict(Year=2021,yield_observed=m.Y13_PUBLISHED,yield_simulated=s['Y_13pct'],yield_calibration_target=m.Y13_TARGET,
                  Units='t/ha at 13% moisture',Error_vs_published_pct=100*(s['Y_13pct']/m.Y13_PUBLISHED-1),
                  Error_vs_internal_target_pct=100*(s['Y_13pct']/m.Y13_TARGET-1),yield_dry_simulated=s['Y_dry'],
                  yield_dry_calibration_target=m.YDRY_TARGET,Yield_R_Square=None,Yield_Pearson=None,Reason='One annual yield pair; correlations undefined')
    flux=pd.DataFrame([dict(Variable=k,Observed_or_target=t,Simulated=s[k],Error_pct=100*(s[k]/t-1),Units='mm',Role=role)
                       for k,t,role in [('Tr_mm',m.TR_TARGET,'calibration target'),('Es_mm',m.ES_TARGET,'approximate target'),
                                        ('ET_mm',m.ET_OBS,'derived check; not separate likelihood term')]])
    sens,fits=sensitivity(m,data,p1raw,p1logs,b1,start,point,out)
    ranges={mode:{k:dict(Min=df[k].min(),Max=df[k].max(),Range=df[k].max()-df[k].min()) for k in ['Y13','Zero_Y13','Zero_loss_pct','Tr','Es','ET','B_RMSE']}
            for mode,df in sens.groupby('Mode')}
    summary=dict(Year=2021,CCR_Square=ccm['R_Square'],Pearson=ccm['Pearson'],Pearson_squared=ccm['Pearson_squared'],CC=ccm,CC_weighted=ccw,
                 Biomass=bm,Yield=yieldrow,Flux=flux.to_dict('records'),DI=s,Zero=z,Zero_loss_pct=100*(1-z['Y_13pct']/s['Y_13pct']),
                 Phase2_parameters=d2['Parameter_summary'],Sensitivity_ranges=ranges,All_local_refits_success=all(x['Success'] for x in fits),
                 Definitions={'R_Square':'1-SSE/SST; not Pearson squared','Pearson':'date-matched observed/simulated correlation',
                              'yield_observed':'published 13%-moisture yield; internal target separately retained'},
                 Limitations=['Conditional phase 2; not an 8-parameter joint posterior','Phase-1 original diagnostic flag retained',
                              'CC and biomass are calibration evidence, not independent validation','Zero irrigation is an unvalidated counterfactual',
                              'Representative-point refits are local optimization, not resampling or Sobol analysis'])
    frames={'CC_pairs':cc,'Biomass_pairs':bio,'Yield_comparison':pd.DataFrame([yieldrow]),'Flux_comparison':flux,
            'Phase2_parameters':pd.DataFrame(d2['Parameter_summary']),'Sensitivity':sens,'Daily_growth':g}
    for name,df in frames.items(): df.to_csv(out/(name+'.csv'),index=False,encoding='utf-8-sig',na_rep='NA')
    write(out/'summary.json',summary);write(out/'conditional_refits.json',fits);write(out/'conditional_mean_model.json',dict(values=point,DI=s,Zero=z))
    fig,ax=plt.subplots(1,3,figsize=(14,4));ax[0].plot(g.Date,g.canopy_cover,label='Simulated');ax[0].scatter(cc.Date,cc.CC_observed,c='k',label='LAI-derived');ax[0].legend();ax[0].set_ylabel('CC fraction');ax[0].tick_params(axis='x',rotation=35)
    ax[1].scatter(cc.CC_observed,cc.CC_simulated);ax[1].plot([0,1],[0,1],'k--');ax[1].set(xlabel='Observed CC',ylabel='Simulated CC',title=f'R2={ccm["R_Square"]:.4f}; r={ccm["Pearson"]:.4f}')
    ax[2].plot(g.Date,g.Biomass_t_ha,label='Simulated');ax[2].scatter(bio.Date,bio.B_observed_t_ha,c='k',label='Digitized');ax[2].legend();ax[2].set_ylabel('Biomass t/ha');ax[2].tick_params(axis='x',rotation=35)
    fig.suptitle('2021 conditional-mean model: calibration, not independent validation');fig.tight_layout();fig.savefig(out/'model_fit.png',dpi=150);plt.close(fig)
    report=f'''# 2021 第二阶段与综合诊断\n\nCCR_Square={ccm['R_Square']:.6f}；Pearson r={ccm['Pearson']:.6f}；CC RMSE={ccm['RMSE']:.6f}。\n\nyield_observed={m.Y13_PUBLISHED} t/ha；内部目标={m.Y13_TARGET} t/ha；yield_simulated={s['Y_13pct']:.6f} t/ha。单年产量R²和Pearson不适用。\n\n代表点敏感性范围：\n\n{json.dumps(clean(ranges),ensure_ascii=False,indent=2)}\n\n第一阶段原诊断状态、条件推断、非独立验证和零灌溉未验证等范围声明均保留。本程序不执行Sobol或NSGA-III。\n'''
    (out/'结果说明.md').write_text(report,encoding='utf-8')
    tables={'Summary':[['Metric','Value','Definition'],['CCR_Square',ccm['R_Square'],'1-SSE/SST; unweighted'],['Pearson',ccm['Pearson'],'r; not r squared'],
              ['Pearson_squared',ccm['Pearson_squared'],'r squared'],['CC_RMSE',ccm['RMSE'],'fraction'],['CC_MAE',ccm['MAE'],'fraction'],['CC_N',ccm['N'],'matched dates'],
              ['yield_observed',m.Y13_PUBLISHED,'published; t/ha at 13% moisture'],['yield_simulated',s['Y_13pct'],'conditional mean parameters'],
              ['yield_calibration_target',m.Y13_TARGET,'internal target'],['Yield_R_Square','NA','one annual observation'],['Yield_Pearson','NA','one annual observation'],
              ['B_RMSE',bm['RMSE'],'t/ha; calibration'],['Phase1_converged',bool(diag1['Converged']),'original flag retained']]}
    for name in ['CC_pairs','Biomass_pairs','Yield_comparison','Flux_comparison','Phase2_parameters','Sensitivity']:
        df=frames[name];tables[name]=[list(df.columns)]+[[str(v.date()) if isinstance(v,pd.Timestamp) else None if pd.isna(v) else v for v in row] for row in df.itertuples(index=False,name=None)]
    write(out/'workbook_tables.json',tables);export_xlsx(out)
    write(out/'run_status.json',dict(State='COMPLETE_REVIEW_EXPORTED',Sampling_complete=True,Inference_validated=False,
          Phase1_converged=bool(diag1['Converged']),Phase2_tau_trusted_50tau=d2['Tau_trusted_50tau'],Joint_posterior=False))

def export_xlsx(out):
    deps=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies';node=deps/'node/bin/node.exe';packages=deps/'node/node_modules'
    if not node.is_file() or not (packages/'@oai/artifact-tool').is_dir():
        write(out/'xlsx_status.json',dict(Available=False,CSV_JSON_complete=True));return
    builder=out/'build_workbook.mjs';builder.write_text(WORKBOOK_JS,encoding='utf-8')
    run=subprocess.run([str(node),str(builder),str(out),str(packages)],check=False)
    book=out/'DI_2021_phase2_review.xlsx'
    if not book.is_file(): raise RuntimeError('Excel export did not create workbook')
    verify_xlsx(out,book,run.returncode)

def verify_xlsx(out,book,code):
    tables=read(out/'workbook_tables.json');ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(book) as z:
        if z.testzip() is not None: raise RuntimeError('XLSX CRC failure')
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist(): strings=[''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',ns)]
        for i,(name,rows) in enumerate(tables.items(),1):
            tree=ET.fromstring(z.read(f'xl/worksheets/sheet{i}.xml'));cells={}
            for c in tree.findall('.//s:sheetData/s:row/s:c',ns):
                v=c.find('s:v',ns);v=v.text if v is not None else None;t=c.get('t')
                if t=='s':v=strings[int(v)]
                elif t=='inlineStr':v=''.join(c.find('s:is',ns).itertext())
                elif t=='b':v=v=='1'
                elif t=='d':v=(datetime.fromisoformat(v.replace('Z','+00:00')).replace(tzinfo=None)-datetime(1899,12,30)).total_seconds()/86400
                elif t!='str' and v is not None:v=float(v)
                cells[c.get('r')]=v
            for ri,row in enumerate(rows,1):
                for j,want in enumerate(row):
                    addr=chr(65+j)+str(ri);got=cells.get(addr)
                    if ri>1 and rows[0][j]=='Date' and want is not None: want=(datetime.fromisoformat(want)-datetime(1899,12,30)).days
                    ok=(isinstance(want,(int,float)) and not isinstance(want,bool) and isinstance(got,(int,float)) and abs(got-want)<=1e-9*max(1,abs(want))) or got==want or want is None and got in (None,'')
                    if not ok: raise RuntimeError(f'XLSX mismatch {name}!{addr}')
    write(out/'xlsx_verification.json',dict(All_exported_cells_match=True,ZIP_CRC_valid=True,Renderer_return_code=code))

WORKBOOK_JS=r'''
import fs from 'node:fs/promises';import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';
const out=process.argv[2],require=createRequire(process.argv[3]+'/entry.cjs');const {Workbook,SpreadsheetFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool')).href);
const tables=JSON.parse(await fs.readFile(out+'/workbook_tables.json','utf8')),wb=Workbook.create();
for(const [name,rows] of Object.entries(tables)){const sh=wb.worksheets.add(name);sh.showGridLines=false;sh.getRangeByIndexes(0,0,rows.length,rows[0].length).values=rows;
 const used=sh.getUsedRange();used.format.font={name:'Arial',size:10};used.format.rowHeight=20;used.setNumberFormat('0.000000');used.format.verticalAlignment='center';
 for(let j=0;j<rows[0].length;j++){const width=Math.max(18,Math.min(80,Math.max(...rows.map(r=>typeof r[j]==='string'?r[j].length:0))+3));sh.getRangeByIndexes(0,j,rows.length,1).format.columnWidth=width;
  if(rows[0][j]==='Date'){sh.getRangeByIndexes(1,j,rows.length-1,1).values=rows.slice(1).map(r=>[new Date(r[j]+'T00:00:00Z')]);sh.getRangeByIndexes(1,j,rows.length-1,1).setNumberFormat('yyyy-mm-dd');}
  if(rows[0][j]==='Year')sh.getRangeByIndexes(1,j,rows.length-1,1).setNumberFormat('0');if(rows[0][j]==='WB_daily_max')sh.getRangeByIndexes(1,j,rows.length-1,1).setNumberFormat('0.00E+00');}
 sh.getRangeByIndexes(0,0,1,rows[0].length).format={fill:'#28455D',font:{name:'Arial',bold:true,color:'#FFFFFF'},rowHeight:35,wrapText:true};sh.freezePanes.freezeRows(1);}
wb.recalculate();console.log((await wb.inspect({kind:'table',range:'Summary!A1:C14',include:'values,formulas',tableMaxRows:14,tableMaxCols:3})).ndjson);
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#SPILL!',options:{useRegex:true,maxResults:20}})).ndjson);
for(const [name,rows] of Object.entries(tables)){for(let j=0;j<rows[0].length;j+=6){const end=String.fromCharCode(64+Math.min(rows[0].length,j+6));const png=await wb.render({sheetName:name,range:`${String.fromCharCode(65+j)}1:${end}${Math.min(rows.length,14)}`,scale:1,format:'png'});await fs.writeFile(out+'/'+name+'_'+j+'.png',new Uint8Array(await png.arrayBuffer()));}}
await(await SpreadsheetFile.exportXlsx(wb)).save(out+'/DI_2021_phase2_review.xlsx');process.exit(0);
'''

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--project',type=Path,default=PROJECT);ap.add_argument('--phase1-zip',type=Path,default=PHASE1_ZIP)
    ap.add_argument('--output',type=Path);ap.add_argument('--preflight-only',action='store_true')
    args=ap.parse_args();selftest();project=args.project.resolve();zippath=args.phase1_zip.resolve()
    local_root=Path(__file__).resolve().parent;local_zip=local_root/'MCMC_Article_Results_2021.zip';local_dir=local_root/'MCMC_Article_Results_2021'
    if not zippath.exists() and local_zip.is_file(): zippath=local_zip
    if not zippath.exists() and local_dir.is_dir(): zippath=local_dir
    if not zippath.exists(): raise FileNotFoundError('Place MCMC_Article_Results_2021.zip or its extracted MCMC_Article_Results_2021 folder beside this program')
    out=find_existing_output(args.output)
    if not out.is_dir():raise FileNotFoundError('REVIEW ONLY: phase2_and_review_results folder was not found on this computer: '+str(out))
    lock=out/'.run.lock'
    try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError: raise SystemExit('Output is locked. Confirm no copy is running, then delete only .run.lock and run again.')
    os.write(fd,str(os.getpid()).encode());os.close(fd)
    try:
        sampling=locate_archive_sampling(out,zippath);source,mods,runner,m,data,start,folder=load_original(project,out)
        p1raw,p1logs,b1,p1point,base,hashes,diag1=verify_phase1(sampling,runner,m,data,start,source,out,zippath)
        print('PREFLIGHT PASSED; complete phase 1 read from ZIP; burn-in',b1,flush=True)
        if args.preflight_only:
            write(out/'run_status.json',dict(State='PREFLIGHT_ONLY',Sampling_started=False));return
        write(out/'run_status.json',dict(State='REVIEWING_EXISTING_PHASE2',Sampling_started=False,Phase1_converged=diag1['Converged'],Joint_posterior=False))
        chain,logp,accepted,cn=load_existing_phase2_only(out,runner,m,data,p1point,hashes)
        postprocess(project,out,source,m,data,start,p1raw,p1logs,b1,p1point,chain,accepted,diag1,False)
        current={str(p):sha(p) for p in sorted((sampling/'checkpoints/canopy_transpiration').glob('*.npz'))}
        if current!=hashes: raise RuntimeError('Phase-1 source changed during run')
        print('COMPLETE:',out,flush=True)
    except BaseException as exc:
        write(out/'run_status.json',dict(State='INTERRUPTED' if isinstance(exc,KeyboardInterrupt) else 'FAILED',Error=str(exc),Checkpoint_preserved=True));raise
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':main()
