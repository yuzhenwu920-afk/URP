# DI 2021 complete portable review package

This package includes the recovered formal phase-2 checkpoint. It does not run or extend MCMC.

## Included evidence

- phase 1 source archive: four `2000 x 32 x 5` canopy/transpiration ensembles;
- phase 2 checkpoint: `2000 x 32 x 3` for `WP_early, WP_late, HI0`;
- formal saved mode: `sampling`;
- phase-1 handoff burn-in: 347;
- phase-2 checkpoint SHA-256: `24A3FA72B51D1A5A8CAD35DF5084ECCB15439A4600B5F3932006D4153175722E`.

## Run

Keep the complete extracted folder structure unchanged. Open
`DI_2021_REVIEW_EXISTING_2000_ONLY.py` with the AquaCrop PyCharm interpreter and click Run.

The program:

1. verifies the phase-1 archive and hashes;
2. requires the exact phase-2 shapes `(2000,32,3)`, `(2000,32)`, `(2000,32)`;
3. verifies finite values and the portable scientific contract;
4. recomputes a saved phase-2 terminal log-posterior when package patch versions differ;
5. runs diagnostics, six representative-point sensitivity checks and exports CSV/JSON/figures/Excel.

It contains no call to `run_ensemble`. Missing or incompatible data causes an immediate `REVIEW ONLY` error; sampling is never started.

Success requires console `COMPLETE` and `phase2_and_review_results/run_status.json` state `COMPLETE_REVIEW_EXPORTED`.

The results remain conditional on the retained phase-1 mean, not an eight-parameter joint posterior. Original phase-1 convergence status and the non-independent-validation limitations are retained.
