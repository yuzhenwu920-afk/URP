from pathlib import Path
import json,re,hashlib
import pandas as pd
import numpy as np
import fitz
from PIL import Image,ImageDraw
from docx import Document
from docx.oxml.ns import qn
from paper_content import FIGS,D,BLOCKS
from english_text import english_blocks
ROOT=Path(__file__).resolve().parents[1]
def alltext(doc):
 text=[p.text for p in doc.paragraphs]
 for t in doc.tables:
  for r in t.rows:
   for c in r.cells:text.extend(p.text for p in c.paragraphs)
 return '\n'.join(text)
def main():
 maps=[];docs=[];edges=[]
 for lang in ['CN','EN']:
  stem=f'URP_Manuscript_{lang}_Updated_20261023';d=Document(ROOT/'documents'/(stem+'.docx'));text=alltext(d)
  assert len(d.inline_shapes)==15 and len(d.tables)==10
  for s in ['209.83','306.50','264.50','257.47','457','596','399','996','81.09','96.72']:
   assert s in text,(lang,s)
  for s in ['218.36、312.42','366.17','R̂≤1.0048','ESS≥3200','W = (W₁, W₂, W₃, W₄)']:assert s not in text,(lang,'stale',s)
  if lang=='EN':assert not re.search('[\u4e00-\u9fff]',text)
  for t in d.tables:
   b=t._tbl.tblPr.find(qn('w:tblBorders'));assert b is not None
   for side in ['left','right','insideV','insideH']:assert b.find(qn('w:'+side)).get(qn('w:val'))=='nil'
  p=ROOT/f'tables/Manuscript_figure_table_map_{lang}.csv';maps.append(pd.read_csv(p));docs.append(dict(File=stem,Figures=15,Three_line_tables=10))
 assert maps[0].equals(maps[1]);assert len(BLOCKS)==len(english_blocks())
 table=pd.read_csv(ROOT/'tables/Manuscript_Table_7.csv');np.testing.assert_allclose(table['Selected I (mm)'],D.Optimized_I_mm,atol=.005,rtol=0);np.testing.assert_allclose(table['Selected yield (t ha⁻¹)'],D.Optimized_Y13,atol=.0005,rtol=0)
 events=pd.read_csv(ROOT/'tables/FiveStage_Optimized_every_irrigation_event.csv');s=pd.read_csv(ROOT/'tables/FiveStage_Five_stage_totals_and_event_counts.csv')
 for r in D.itertuples():
  e=events[events.Year==r.Year];z=s[(s.Year==r.Year)&(s.Control_ID=='Selected_95pct')];assert len(z)==5 and (z.Positive_events<=3).all();assert abs(e.Actual_mm.sum()-r.Optimized_I_mm)<1e-7;assert abs(z.Actual_mm.sum()-r.Optimized_I_mm)<1e-7
 mid=Document(ROOT/'documents/URP_Midterm_Report_Updated_20261023.docx');txt=alltext(mid)
 for t in ['X2026100190937','吴雨臻','李承昊','段璞','廖人宽','457596','455505','209.83','306.50','264.50','257.47','已报销经费：____________元']:assert t in txt,t
 for t in ['完整的新真实模型Sobol及NSGA-III实验尚待执行','正式优化结果仍需补充','35.6%—57.8%']:assert t not in txt,t
 assert len(mid.inline_shapes)==7 # institutional cover logo plus six evidence images
 cjk=[]
 for _,(name,_,_) in FIGS.items():
  f=fitz.open(ROOT/'figures'/(name+'.pdf'));text=''.join(p.get_text() for p in f)
  if re.search('[\u4e00-\u9fff]',text):cjk.append(name)
 assert not cjk
 pages=[]
 for p in sorted((ROOT/'documents').glob('*.pdf')):
  d=fitz.open(p);thumbs=[]
  for i,pg in enumerate(d):
   pix=pg.get_pixmap(matrix=fitz.Matrix(.45,.45));im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((260,335));can=Image.new('RGB',(285,365),'white');can.paste(im,(10,8));ImageDraw.Draw(can).text((10,347),str(i+1),fill='black');thumbs.append(can)
   for b in pg.get_text('dict')['blocks']:
    for line in b.get('lines',[]):
     for sp in line['spans']:
      margin=0 if p.name=='URP_All_Current_English_Figures_20261023.pdf' else 12
      if sp['bbox'][0]<margin-.1 or sp['bbox'][2]>pg.rect.width-margin+.1:edges.append(dict(File=p.name,Page=i+1,Text=sp['text']))
  contact=Image.new('RGB',(1425,365*((len(thumbs)+4)//5)),'#D2DBDF')
  for i,im in enumerate(thumbs):contact.paste(im,((i%5)*285,(i//5)*365))
  contact.save(ROOT/'analysis'/(p.stem+'_contact.jpg'),quality=88);pages.append(dict(File=p.name,Pages=len(d)))
 assert not edges,edges[:10]
 atlas=fitz.open()
 for name,title,note in FIGS.values():
  with fitz.open(ROOT/'figures'/(name+'.pdf')) as f:atlas.insert_pdf(f)
 atlas.save(ROOT/'documents/URP_All_Current_English_Figures_20261023.pdf');assert len(atlas)==15
 result=dict(Status='PASS',Manuscripts=docs,Aligned_CN_EN_blocks=len(BLOCKS),Documents=pages,English_figure_groups=15,Current_event_rows=len(events),Per_stage_maximum=3,Season_totals_reconciled=True,Actual_reimbursement_blank=True,Signatures_reserved=True,PDF_edge_spans=edges,Source_optimization_commit='20f1616556f5aeb79329b7ead22faa28f9fcda6a',New_model_runs_in_document_update=False)
 (ROOT/'analysis/DOCUMENT_AND_DATA_QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
