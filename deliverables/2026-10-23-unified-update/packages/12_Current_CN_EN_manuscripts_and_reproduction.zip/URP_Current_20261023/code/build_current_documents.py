from pathlib import Path
import json,re,shutil
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION_START,WD_ORIENT
from openpyxl.styles import Font,PatternFill,Alignment
import legacy_renderer as L
from paper_content import TITLE,TITLE_EN,ABSTRACT,ABSTRACT_EN,KEYWORDS,BLOCKS,FIGS,D,A,ST
from english_text import english_blocks
ROOT=Path(__file__).resolve().parents[1];TB=ROOT/'tables';OUT=ROOT/'documents';HIST=ROOT/'source/historical_four_window_tables'
L.ROOT=ROOT;L.TB=TB;L.OUT=OUT;L.FIGS=FIGS
def read(n):return pd.read_csv(TB/n if (TB/n).exists() else HIST/n)
L.read=read
def five(n):return read('FiveStage_'+n)
def data_tables():
 tt=L.tables()
 tt['candidates']=('Selected five-stage NSGA-III schedules at 95% observed yield.',['Year','Recorded I\n(mm)','Selected I\n(mm)','Selected yield\n(t ha⁻¹)','I reduction\n(%)','Yield RE\n(%)','ET\n(mm)'],[[int(r.Year),f'{r.Original_I_mm:.2f}',f'{r.Optimized_I_mm:.2f}',f'{r.Optimized_Y13:.3f}',f'{r.I_reduction_pct:.2f}',f'{r.Yield_RE_vs_observed_pct:.2f}',f'{r.Optimized_ET_mm:.2f}'] for r in D.itertuples()],'The primary candidate minimizes actual irrigation within the feasible nondominated union of the five formal NSGA-III final populations. Yield RE uses the published annual observation.')
 tt['water_ledger']=('Water-balance decomposition for the selected five-stage schedules.',['Year','I reduction\n(mm)','ET decrease\n(mm)','Lower final S\n(mm)','Other losses\n(mm)','Storage share\n(%)'],[[int(r.Year),f'{r.I_reduction_mm:.2f}',f'{r.ET_reduction_mm:.2f}',f'{r.Lower_final_storage_mm:.2f}',f'{r.Other_loss_reduction_mm:.2f}',f'{r.Storage_difference_share_pct:.2f}'] for r in D.itertuples()],'Differences are recorded schedule minus selected candidate. Storage integrates the unchanged 0–2.4 m simulated profile. Signed components sum to irrigation reduction.')
 ss=ST[ST.Control_ID=='Selected_95pct']
 tt['stage_totals']=('Five-stage actual irrigation totals and event counts.',['Year','Seedling\n(mm)','Jointing\n(mm)','Heading\n(mm)','Grain filling\n(mm)','Maturity\n(mm)','Positive\nevents','Events\n≥0.1 mm'],[[int(r.Year)]+[f'{ss[(ss.Year==r.Year)&(ss.Stage==j)].Actual_mm.iloc[0]:.3f}' for j in range(1,6)]+[int(r.Positive_events),int(r.Events_ge_0p1mm)] for r in D.itertuples()],'All exact positive depths count as events after same-day merging; ≥0.1 mm counts are additional descriptive statistics. Stage totals use unrounded source controls.')
 rows=[]
 for y in range(2019,2023):
  q=A[A.Year==y].set_index('Algorithm');rows.append([y,f'{q.loc["NSGA3","Minimum_I_mm"]:.3f}',f'{q.loc["NSGA2","Minimum_I_mm"]:.3f}',f'{q.loc["NSGA3","Minimum_I_mm"]-q.loc["NSGA2","Minimum_I_mm"]:+.3f}',f'{q.loc["NSGA3","Normalized_union_HV"]:.6f}',f'{q.loc["NSGA2","Normalized_union_HV"]:.6f}'])
 tt['algorithms']=('Final feasible-population union metrics from five seeds.',['Year','NSGA-III min I\n(mm)','NSGA-II min I\n(mm)','III minus II\n(mm)','NSGA-III\nHV','NSGA-II\nHV'],rows,'Each method shares the disclosed recorded and four-window initialization anchors, objectives and constraints. The primary calendar follows NSGA-III; hypervolume uses the stated annual normalization.')
 return tt
def refs():
 return json.loads((ROOT/'source/paper_evidence_20261022/REFERENCE_EVIDENCE_revised.json').read_text())
def para(d,text,**kw):return L.para(d,text,**kw)
def header(d,lang):
 p=d.sections[0].header.paragraphs[0];p.clear();p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;L.font(p.add_run('URP | 2019–2022 DI maize | Five-stage individual-event scheduling'),8)
def figure(d,key,num):
 name,title,note=FIGS[key];landscape=key=='pareto'
 if landscape:
  sec=d.add_section(WD_SECTION_START.NEW_PAGE);sec.orientation=WD_ORIENT.LANDSCAPE;sec.page_width=Cm(29.7);sec.page_height=Cm(21);sec.left_margin=sec.right_margin=Cm(1.3);sec.top_margin=sec.bottom_margin=Cm(1.0)
 im=Image.open(ROOT/'figures'/(name+'.png')).convert('RGB');im.thumbnail((3400,3400));p=ROOT/'analysis/word_figures'/(name+'.jpg');p.parent.mkdir(exist_ok=True);im.save(p,quality=96,subsampling=0)
 width=min(25.5 if landscape else 17.0,(15.4 if landscape else 11.2)*im.width/im.height)
 pp=d.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER;pp.paragraph_format.line_spacing=1;pp.paragraph_format.keep_with_next=True;pp.add_run().add_picture(str(p),width=Cm(width))
 pp=para(d,f'Figure {num}. {title}',size=9.2,bold=True,indent=False,keep=True);pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para(d,note,size=8.7,indent=False)
 if landscape:
  sec=d.add_section(WD_SECTION_START.NEW_PAGE);sec.orientation=WD_ORIENT.PORTRAIT;sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=sec.right_margin=Cm(1.9);sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.7)
def manuscript(lang):
 title=TITLE if lang=='CN' else TITLE_EN;abstract=ABSTRACT if lang=='CN' else ABSTRACT_EN;blocks=BLOCKS if lang=='CN' else english_blocks();d=Document();L.setup(d,title);header(d,lang)
 d.core_properties.subject='Five-stage update, 2026-10-23; verified optimization source 20f1616556f5aeb79329b7ead22faa28f9fcda6a'
 p=para(d,title,size=17,bold=True,indent=False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 p=para(d,'吴雨臻  李承昊  段璞' if lang=='CN' else 'Yuzhen Wu, Chenghao Li, Pu Duan',indent=False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 p=para(d,'中国农业大学土地科学与技术学院，北京 100193' if lang=='CN' else 'College of Land Science and Technology, China Agricultural University, Beijing 100193, China',size=9.5,indent=False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para(d,('摘要：' if lang=='CN' else 'Abstract: ')+abstract,size=10,indent=False)
 para(d,('关键词：'+KEYWORDS if lang=='CN' else 'Keywords: film-mulched drip irrigation; maize; AquaCrop; MCMC; Sobol analysis; irrigation scheduling'),size=9.5,indent=False)
 md=['# '+title,'',abstract,''];mapping=[];fn=tn=0;tt=data_tables()
 for i,(kind,x) in enumerate(blocks):
  if kind.startswith('h'):L.head(d,x,int(kind[-1]));md+=['#'*int(kind[-1])+' '+x,'']
  elif kind=='p':para(d,x,keep=i+1<len(blocks) and blocks[i+1][0]=='tab');md +=[x,'']
  elif kind=='eq':
   p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;L.font(p.add_run(x[0]+'    ('+x[1]+')'),10.5);md +=[x[0]+' ('+x[1]+')','']
  elif kind=='fig':
   fn+=1;figure(d,x,fn);mapping.append(dict(Type='Figure',Number=fn,Key=x,File=FIGS[x][0]));md +=[f'![Figure {fn}](../figures/{FIGS[x][0]}.png)','',f'Figure {fn}. '+FIGS[x][1]+' '+FIGS[x][2],'']
  elif kind=='tab':
   tn+=1;title,heads,rows,note=tt[x];L.table(d,tn,title,heads,rows,note,widths=[2.4,1.2,7,2.2,4.4] if x=='parameters' else None);mapping.append(dict(Type='Table',Number=tn,Key=x,File=f'Manuscript_Table_{tn}.csv'));pd.DataFrame(rows,columns=[h.replace('\n',' ') for h in heads]).to_csv(TB/f'Manuscript_Table_{tn}.csv',index=False,encoding='utf-8-sig');md +=[f'Table {tn}. '+title,'',L.markdown_table(heads,rows),'',note,'']
 L.head(d,'参考文献' if lang=='CN' else 'References')
 for r in refs():
  txt=r.get('EN',r['CN']) if lang=='EN' else r['CN'];txt=f'[{r["number"]}] '+txt+(' DOI: '+r['DOI']+'.' if r.get('DOI') else '');pp=para(d,txt,size=8.8,indent=False);pp.paragraph_format.space_after=Pt(2);pp.paragraph_format.line_spacing=1.1;pp.paragraph_format.keep_together=True;md +=[txt,'']
 base=f'URP_Manuscript_{lang}_Updated_20261023';d.save(OUT/(base+'.docx'));(OUT/(base+'.md')).write_text('\n'.join(md));pd.DataFrame(mapping).to_csv(TB/f'Manuscript_figure_table_map_{lang}.csv',index=False)
 assert fn==15 and tn==10
 print(base,fn,'figures',tn,'tables',flush=True)
def water(v):return f'{v:.2e}' if 0<abs(v)<1e-5 else f'{v:.6f}'
def supplement():
 d=Document();L.setup(d,'Supplementary methods, diagnostics and irrigation event schedules');header(d,'EN')
 p=para(d,'补充资料 / Supplementary methods, diagnostics and event schedules',size=16,bold=True,indent=False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para(d,'本补充资料与2026年10月23日中英文稿对应。参数校准与Sobol沿用已核验来源；优化主体采用2026年10月22日完成的五期30维搜索。来源版本、旧控制空间及条件结构试验分别记录。')
 para(d,'This supplement accompanies both updated manuscripts. Calibration and Sobol data retain their verified sources. Main optimization uses the five-stage, 30-dimensional searches completed on 22 October 2026. Earlier control spaces and conditional structural experiments are recorded separately.',indent=False)
 L.head(d,'S1 数据来源与执行日历 / Input provenance and model calendar')
 a=read('New_upload_data_audit.csv');L.table(d,'S1','Newly supplied data compared with frozen model inputs.',['Year','Weather rows','Max weather difference','RS rows','RS label'],[[int(r.Year),int(r.Climate_rows),f'{r.Max_absolute_weather_difference:.1f}',int(r.RS_rows),r.RS_treatment_label] for r in a.itertuples()],'The two supplied 2021 remote-sensing files are byte-identical. Remote-sensing inputs remain auxiliary; calibration uses DI LAI-derived CC and digitized biomass.')
 para(d,'Water totals use actual executed daily dates. The annual scripts retain their end-boundary conventions; phenological date eligibility is the intersection listed in Table S4. Raw reference weather and model-used audited ETo are separately retained.',indent=False)
 L.head(d,'S2 校准先验 / Calibration priors')
 pr=read('Audit_Recorded_prior_distributions.csv');L.table(d,'S2','Recorded annual phase-specific priors.',['Year','Phase','Parameter','Family','Support','Center','Scale'],[[int(r.Year),int(r.Phase),r.Parameter,'Uniform' if r.Prior_family=='uniform' else 'Truncated normal',f'{r.Lower:g}–{r.Upper:g}','–' if pd.isna(r.Gaussian_center) else f'{r.Gaussian_center:g}','–' if pd.isna(r.Gaussian_scale) else f'{r.Gaussian_scale:g}'] for r in pr.itertuples()],'The common independent Sobol support is a separate experiment from these annual MCMC priors.')
 L.head(d,'S3 原链诊断 / Original-chain diagnostics')
 dx=read('Actual_sampling_diagnostics_and_center_stability.csv');L.table(d,'S3','Time-preserving diagnostics and retained-mean sensitivity.',['Year','Phase','Independent ensembles','Worst R̂','Min group bulk ESS','Max τ','Burn-in shift (SD)'],[[int(r.Year),int(r.Phase),int(r.Independent_ensembles),'–' if pd.isna(r.Maximum_Rhat) else f'{r.Maximum_Rhat:.4f}','–' if pd.isna(r.Minimum_group_bulk_ESS) else f'{r.Minimum_group_bulk_ESS:.2f}',f'{r.Maximum_tau:.2f}',f'{r.Maximum_burnin_mean_shift_SD:.4f}'] for r in dx.itertuples()],'Stage-1 extrema summarize matched walker-index comparisons across four independently initialized ensembles while preserving time. Dependent groups are not added to form a pooled ESS. Stage 2 has one independent ensemble per year.')
 para(d,'四年阶段一保留均值对截取方式较稳定，分布采样精度由R̂、ESS和τ另行量化。2021年短时续链记录独立归档：公共链长2532步时最差R̂为1.0888、最小组bulk ESS为33.64。该补充计算未替换主分析参数中心。')
 para(d,'Retained means and distributional precision are evaluated separately. A separately archived 2021 continuation has a common length of 2532 steps, worst R̂=1.0888 and minimum matched-group bulk ESS=33.64; it does not replace the four-year parameter centers used here.',indent=False)
 L.head(d,'S4 五期日期界限 / Five-stage date bounds')
 b=five('Five_stage_schedule_bounds.csv');L.table(d,'S4','Eligible dates for all five stages in all years.',['Year','Stage','First date','Last date','Max events'],[[int(r.Year),r.Stage_name.replace('_',' '),r.First_allowed_date,r.Last_allowed_date,3] for r in b.itertuples()],'Dates follow the reported phenological observations [1], intersected with the executed model calendar. Every stage is eligible even where the recorded schedule has no event.')
 events=five('Optimized_every_irrigation_event.csv')
 for y in range(2019,2023):
  L.head(d,f'S{y-2014} {y}年逐次日程 / Individual events in {y}')
  z=events[events.Year==y];L.table(d,f'S{y-2014}',f'Every positive-depth event in the selected {y} schedule.',['Stage','Date','Model day (1-based)','Actual depth (mm)','Reading'],[[r.Stage_name.replace('_',' '),r.Date,int(r.DAP),water(r.Actual_mm),'Trace <0.1 mm' if r.Actual_mm<.1 else '≥0.1 mm'] for r in z.itertuples()],'Model day 1 is the planting date; calendar dates are explicit. Numerical traces are retained without changing the evaluated controls. Zero slots are available in the complete source table.')
 L.head(d,'S9 单次量与实施条件 / Event magnitude and implementation conditions')
 base=five('Baseline_and_selected_water_ledger.csv');base=base[base.Scenario=='Original_DI'].set_index('Year');L.table(d,'S9','Maximum event depths and spacing.',['Year','Recorded max (mm)','Selected max (mm)','Events ≥0.1 mm','Min positive-event gap (d)'],[[int(r.Year),f'{base.loc[r.Year,"Max_actual_event_mm"]:.2f}',f'{r.Max_event_mm:.2f}',int(r.Events_ge_0p1mm),int(r.Minimum_positive_event_gap_days)] for r in D.itertuples()],'No additional equipment cap, minimum-event-depth constraint, spacing constraint or terminal-water floor is imposed. Gaps include exact trace events.')
 L.head(d,'S10 原控制空间补充试验 / Earlier control-space diagnostics')
 para(d,'前期四窗口单目标求解、2021年1 m根深与不同fMulch条件重校准，以及降水替换试验均保持原始结果。相应试验分别回答固定日期空间的算法重复性、条件结构改变及降水来源敏感性，主文五期日程采用本轮新搜索。完整源码、响应和图件见归档05—10及15—16阶段。')
 para(d,'Earlier scalar comparisons retain four fixed-date windows. The 2021 1 m root-depth/mulch conditional refits and rainfall substitutions retain their own settings. Their results answer distinct control-space, structural and forcing questions; current five-stage calendars use the new searches. Complete source code and results are indexed by research stage.',indent=False)
 scalar=read('Scalar_Overall_best_95pct_candidates.csv');cols=['Case','Algorithm','Irrigation_mm','Y_13pct'];pd.DataFrame(scalar[cols]).to_csv(TB/'Supplementary_earlier_scalar_minima.csv',index=False)
 L.table(d,'S10','Earlier scalar-search archive minima in the corresponding fixed-date spaces.',['Case','Method','I min (mm)','Yield (t ha⁻¹)'],[[r.Case,r.Algorithm,f'{r.Irrigation_mm:.2f}',f'{r.Y_13pct:.3f}'] for r in scalar.itertuples()],'These are earlier control-space diagnostics; the present 30D comparison is in main Table 10. Historical NSGA-III reference budgets differ from the scalar-query budgets.')
 L.head(d,'S11 数值复现 / Numerical reproduction')
 q=json.loads((ROOT/'source/current_optimization_source.json').read_text());para(d,'The search source is pinned to Git commit '+q['Git_commit']+'. All 457,596 query rows, date bounds, per-stage limits and seasonal budgets were checked. Full-model selected-point replays and 12 fresh unaccelerated original-equation replays agree within 1.14×10⁻¹³. Source JSON records separately count exact cache hits, setup, preflight and postprocessing calls. Four first seeds retain 9,999 queries after duplicate initialization; no synthetic rows were added. This manuscript update performs no new MCMC, Sobol or optimization runs.',indent=False)
 d.save(OUT/'URP_Supplementary_Methods_and_Schedules_20261023.docx')
def guide():
 d=Document();L.setup(d,'English figure interpretations');header(d,'EN');para(d,'英文图件解析 / English figure interpretations',size=16,bold=True,indent=False)
 rows=[]
 for i,(key,(name,title,note)) in enumerate(FIGS.items(),1):
  L.head(d,f'Figure {i}. '+title);p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;im=Image.open(ROOT/'figures'/(name+'.png'));p.add_run().add_picture(str(ROOT/'figures'/(name+'.png')),width=Cm(min(17,10.5*im.width/im.height)));para(d,note,size=9.5,indent=False)
  index=next(j for j,(k,x) in enumerate(BLOCKS) if k=='fig' and x==key)
  explanation=next(x for k,x in reversed(BLOCKS[:index]) if k=='p')
  en=next(x for k,x in reversed(english_blocks()[:index]) if k=='p')
  para(d,explanation);para(d,en,size=9.5,indent=False)
  rows.append(dict(Figure=i,Key=key,File=name,Caption=title,Interpretation=note))
 d.save(OUT/'URP_All_Figure_Interpretations_Updated_20261023.docx');pd.DataFrame(rows).to_csv(TB/'Current_Figure_Interpretations.csv',index=False,encoding='utf-8-sig')
def workbook():
 with pd.ExcelWriter(TB/'URP_All_Current_Data_20261023.xlsx',engine='openpyxl') as w:
  for i,p in enumerate(sorted(TB.glob('*.csv')),1):
   q=pd.read_csv(p);q.to_excel(w,sheet_name=f'{i:02d}_'+p.stem[:27],index=False)
  for s in w.book.worksheets:
   s.freeze_panes='A2';s.auto_filter.ref=s.dimensions;s.row_dimensions[1].height=32
   for c in s[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='245568');c.alignment=Alignment(wrap_text=True,vertical='center');s.column_dimensions[c.column_letter].width=min(38,max(12,len(str(c.value or ''))+2))
def main():
 OUT.mkdir(exist_ok=True);(ROOT/'analysis/word_figures').mkdir(exist_ok=True)
 manuscript('CN');manuscript('EN');supplement();guide();workbook()
if __name__=='__main__':main()
