"""Current paper blocks; all revised optimization values come from verified CSVs."""
from pathlib import Path
import copy
import pandas as pd
import legacy_paper_content as previous
ROOT=Path(__file__).resolve().parents[1]
D=pd.read_csv(ROOT/'tables/FiveStage_Four_year_result_comparison.csv').sort_values('Year')
A=pd.read_csv(ROOT/'tables/FiveStage_Algorithm_comparison.csv')
ST=pd.read_csv(ROOT/'tables/FiveStage_Five_stage_totals_and_event_counts.csv')
TITLE='基于AquaCrop模型的膜下滴灌玉米参数校准与五生育期灌溉制度优化'
TITLE_EN='AquaCrop parameter calibration and five-stage irrigation scheduling for film-mulched drip-irrigated maize'
KEYWORDS=previous.KEYWORDS
def vals(col,digits=2):return '、'.join(f'{v:.{digits}f}' for v in D[col])
def ev(col,digits=2):return ', '.join(f'{v:.{digits}f}' for v in D[col])
def rng(col,digits=2):return f'{D[col].min():.{digits}f}～{D[col].max():.{digits}f}'
ABSTRACT=(
 '为明确西北旱区膜下滴灌玉米灌水量、灌水时序与产量的响应关系，以甘肃武威2019—2022年滴灌玉米为研究对象，结合气象、土壤、冠层覆盖度、生物量及产量资料，采用分阶段马尔科夫链蒙特卡洛（MCMC）方法校准AquaCrop模型，运用Sobol方法识别主要敏感参数，并通过NSGA-III和NSGA-II分析五生育期灌水日程与产量的权衡关系。结果表明：（1）四年冠层覆盖度和地上生物量的校准决定系数分别为0.9306～0.9932和0.9685～0.9966，籽粒产量相对偏差为−4.18%～0.92%；（2）晚期水分生产率、参考收获指数、早期水分生产率和基础作物系数的产量总效应指数四年均值分别为0.396、0.206、0.164和0.145，年度平均敏感性排序一致；'
 f'（3）每个生育期设置最多3个可选灌水事件，同时优化逐次日期和水量。在既定模型参数、初始水分和年度气象条件下，以观测产量的95%为门槛，四年代表方案的灌水量分别为{vals("Optimized_I_mm")} mm，较原日程减少{rng("I_reduction_pct")}%；'
 f'（4）优化前后蒸散量下降{rng("ET_reduction_pct")}%，季末剖面储水差解释了{rng("Storage_difference_share_pct")}%的减灌水量。研究将多指标参数校准、五期逐次灌水与土壤储水核算相衔接，为同类条件下膜下滴灌玉米灌溉制度的分析与评价提供依据。')
ABSTRACT_EN=(
 'Irrigation amount and timing jointly regulate maize production in arid northwestern China. Using four years (2019–2022) of film-mulched drip-irrigated maize observations from Wuwei, Gansu, we combined staged Markov chain Monte Carlo (MCMC) calibration of a project-specific AquaCrop implementation, Sobol sensitivity analysis, and NSGA-III/NSGA-II irrigation scheduling. Calibration used canopy cover, water use, biomass and grain yield. Canopy-cover and biomass calibration coefficients of determination ranged from 0.9306 to 0.9932 and from 0.9685 to 0.9966, respectively; grain-yield biases ranged from −4.18% to 0.92%. Mean total-effect yield indices were 0.396 for late water productivity, 0.206 for reference harvest index, 0.164 for early water productivity and 0.145 for the basal crop coefficient, with consistent annual-mean rankings. '
 f'Up to three optional irrigation events were allocated to each of five phenological stages, and individual depths and dates were optimized jointly. At a yield gate of 95% of observed yield, selected seasonal depths were {ev("Optimized_I_mm")} mm, reducing irrigation by {D.I_reduction_pct.min():.2f}–{D.I_reduction_pct.max():.2f}% relative to recorded schedules under the same annual model settings. '
 f'Evapotranspiration decreased by {D.ET_reduction_pct.min():.2f}–{D.ET_reduction_pct.max():.2f}%, whereas lower terminal profile storage accounted for {D.Storage_difference_share_pct.min():.2f}–{D.Storage_difference_share_pct.max():.2f}% of the irrigation differences. Linking staged calibration, individual-event scheduling and soil-water accounting clarifies the water sources supporting high-yield candidates under the specified seasonal conditions.')

BLOCKS=copy.deepcopy(previous.BLOCKS)
def replace_section(start,end,blocks):
 a=next(i for i,(k,t) in enumerate(BLOCKS) if k.startswith('h') and t.startswith(start))
 b=next(i for i,(k,t) in enumerate(BLOCKS[a+1:],a+1) if k.startswith('h') and t.startswith(end))
 BLOCKS[a:b]=blocks

NEW26=[
 ('h2','2.6 五生育期逐次灌水优化与算法对照'),
 ('p','依据田间观测记录的生育进程[1]，将每年玉米生育期划分为苗期、拔节期、抽穗期、灌浆期和成熟期。各期均设置3个可选灌水槽位，以15个连续灌水量和15个整数日期构成30维决策变量。日期取值范围为当年相应生育期与原模型执行日历的交集；零水量槽位不执行，同日槽位合并计量。各年全部五期均参与搜索，最终每期实际灌水次数为0～3次。具体年度日期界限见附表S4。'),
 ('p','采用NSGA-III和NSGA-II求解产量最大、实际季节灌水量最小的双目标问题[8–10]，形式见式（9）。正式搜索要求Y₁₃≥0.95Yobs，计划总量及实际执行量均不超过原DI季节总量；95%表示确定的产量水平门槛。两算法均采用100个体、100代和5个种子（31、73、109、151、199），共同以原实测日程及前期四窗口可行日程作为公开初值，另加入日期扰动和随机控制量。每年NSGA-III首个种子的重复初值规范化后为99个，仍完整执行100代；四年两算法正式查询合计399 996次，其余种子按100个不同初值执行。'),
 ('eq',('min F(x) = [Iactual(x), −Y₁₃(x)]；x = (w₁,…,w₁₅,d₁,…,d₁₅)','9')),
 ('p','主候选取正式NSGA-III五种子最终种群可行非支配解并集中的最低灌水解。另以3个种子、80个体、60代开展移除产量门槛的全范围搜索，四年共57 600次，以覆盖零灌水至高产平台；正式与补充搜索合计457 596次目标查询，对应455 505次搜索内实际前向模型调用。精确缓存命中与实际调用分别记录，全部逐代种群及逐次查询均保存。'),
 ('p','本轮采用各年已知逐日天气开展回顾性日程优化，固定作物参数、土壤、初始含水量、覆膜及根系设置，联合调整每次灌水量和日期。灌溉管理器的单次与季节执行上限随候选日程设置，以完整执行计划；设备供水能力、最小事件水量、最小间隔和季末储水底线作为后续制度细化条件，未附加到本轮目标中。报告同时给出原始正水量事件数和≥0.1 mm事件数，微量正数保留在源表中。'),
 ('p','前期还在固定日期四窗口空间内，将优化写为给定产量门槛q下的单目标最小灌水问题（式10），比较实数遗传算法、单目标NSGA-II、广义模拟退火和差分进化[8,10–12]。该组结果作为原控制空间下的算法与低水量机制诊断列于补充资料；本轮30维五期日程的算法比较使用上述NSGA-III与NSGA-II记录。'),
 ('eq',('min Iactual(x)，s.t. Y₁₃(x) ≥ q，Iactual(x) ≤ IDI','10')),
]
replace_section('2.6','2.7',NEW26)
NEW34=[('h2','3.4 五生育期灌水量与产量的帕累托关系'),
 ('p','图11展示四年全范围五期NSGA-III非支配前沿。蓝色虚线连接已计算的非支配解，红点为标注解，括号内依次给出苗期、拔节期、抽穗期、灌浆期和成熟期的实际灌水合计；橙色空心点标示正式95%门槛主候选。各年前沿呈增加后逐渐趋于平台的关系。零灌水情景保留当年降水和初始土壤水，四年产量分别为9.071、6.184、6.140和5.850 t·ha⁻¹。'),('fig','pareto'),
 ('p',f'四年主候选灌水量分别为{vals("Optimized_I_mm")} mm，较原DI日程分别减少{vals("I_reduction_pct")}%，对应产量为{vals("Optimized_Y13",3)} t·ha⁻¹（表7）。2021年候选相对模型DI基准的产量差为{D.set_index("Year").loc[2021,"Yield_RE_vs_model_pct"]:.2f}%，相对田间观测值为{D.set_index("Year").loc[2021,"Yield_RE_vs_observed_pct"]:.2f}%。因此，产量门槛、观测偏差及相对模型基准的变化分别列示。'),('tab','candidates'),
 ('p',f'与前期四窗口代表方案相比，本轮灌水量分别变化{vals("New_minus_old_I_mm")} mm。新控制空间同时增加了灌水日期和事件分配自由度，且精确包含原日程与旧可行方案。相同物理设定下，低灌水高产区间在两种控制空间中均出现，水量来源需进一步结合蒸散与储水差额解释。')]
replace_section('3.4','3.5',NEW34)
r21=D.set_index('Year').loc[2021]
NEW35=[('h2','3.5 减灌水量的水量来源'),
 ('p',f'原日程与五期主候选的水量差额见图12及表8。四年ET分别下降{vals("ET_reduction_mm")} mm，占基准ET的{vals("ET_reduction_pct")}%；季末全剖面储水分别下降{vals("Lower_final_storage_mm")} mm，解释了{vals("Storage_difference_share_pct")}%的灌水差额。实际蒸散变化较小，而季末水状态发生明显变化。'),('fig','decomposition'),('tab','water_ledger'),
 ('p',f'2021年少灌{r21.I_reduction_mm:.2f} mm，其中{r21.ET_reduction_mm:.2f} mm对应ET下降、{r21.Other_loss_reduction_mm:.2f} mm对应其他损失下降，{r21.Lower_final_storage_mm:.2f} mm对应季末储水差。原日程由{r21.Initial_profile_mm:.2f}增储至{r21.Original_final_profile_mm:.2f} mm，五期候选则由相同初值降至{r21.Optimized_final_profile_mm:.2f} mm，消耗初始储水{r21.Initial_profile_mm-r21.Optimized_final_profile_mm:.2f} mm。减少基准日程增储与增加初始储水利用共同支撑了该年的较低季节灌水量。逐日与季节水量核算及完整模型回放均通过核对，未加速原始方程回放的最大输出差约为1.14×10⁻¹³。')]
replace_section('3.5','3.6',NEW35)
NEW36=[('h2','3.6 五期水量分配、逐次日程与算法对照'),
 ('p','图13按实际日期绘制四年主候选的每次灌水量，完整日程见附表S5—S8。四年正水量事件数依次为12、13、9和8，其中≥0.1 mm事件分别为8、8、3和6；两种计数对应同一组未取整控制量。2021年≥0.1 mm的事件为6月15日92.959 mm、6月28日85.822 mm和7月29日85.634 mm，其余微量正数同时保留在源表中。'),('fig','calendar'),
 ('p','五期总量与次数见图14和表9。2021年水量主要分配在拔节期178.782 mm和灌浆期85.634 mm，其他阶段合计约0.084 mm。2019年则将较多水量分配在苗期与抽穗期。阶段合计、逐次实际执行量及模型季节灌水量相互核对，最大差小于10⁻⁷ mm。各期允许0～3次，并非要求每期都灌满3次。'),('fig','stage_totals'),('tab','stage_totals'),
 ('p','两算法五种子的种群超体积变化见图15，最终种群并集指标见表10。NSGA-III与NSGA-II年度最低灌水量之差的绝对值为0.03～1.47 mm，得到相近但不完全相同的权衡关系。主日程按既定NSGA-III选择规则确定；NSGA-II的最低水量及各自最高产量另表给出。共同初值、相同目标和约束下的算法对照与逐日物理核算相互补充。'),('fig','algorithm'),('tab','algorithms')]
replace_section('3.6','4 讨论',NEW36)
for i,(kind,t) in enumerate(BLOCKS):
 if kind=='p' and t.startswith('气象驱动包括'):
  BLOCKS[i]=(kind,t.replace('参考蒸散量ETo。','参考蒸散量ETo[14]。'))
 if kind=='p' and t.startswith('灌水总量与作物蒸散需求'):
  BLOCKS[i]=(kind,f'灌水总量与作物蒸散需求通过降水、初始储水及季末储水变化相联系。Qin等[16]从耗水分量讨论充分灌溉条件下覆膜滴灌的作用。本研究2021年减灌{r21.I_reduction_mm:.2f} mm，而ET仅下降{r21.ET_reduction_mm:.2f} mm，季末储水差达到{r21.Lower_final_storage_mm:.2f} mm。该高产平台体现了既定初值、参数和单季边界下的灌溉—储水替代关系。')
 if kind=='p' and t.startswith('（3）在既定模型'):
  BLOCKS[i]=(kind,f'（3）以五生育期、每期最多3个可选事件构建30维日期—水量控制空间。在95%观测产量门槛下，四年NSGA-III主候选为{vals("Optimized_I_mm")} mm，较原日程减少{rng("I_reduction_pct")}%。五期总量和逐次日程均已输出，两种遗传算法的年度最低灌水量差为0.03～1.47 mm。')
 if kind=='p' and t.startswith('（4）优化前后ET'):
  BLOCKS[i]=(kind,f'（4）五期优化后ET下降{rng("ET_reduction_pct")}%，季末储水差解释了{rng("Storage_difference_share_pct")}%的减灌量。2021年储水差为{r21.Lower_final_storage_mm:.2f} mm，占该年减灌量的{r21.Storage_difference_share_pct:.2f}%。将作物生长、逐次供水和储水变化统一分析，可明确单季灌溉优化的水量来源及跨季应用条件。')
replace_section('4.3','5 结论',[
 ('h2','4.3 生育期日程、事件尺度与制度应用'),
 ('p','五期划分与文献中的作物生育过程对应，逐次日期—水量联合优化进一步细化了灌溉决策。某些阶段的水量集中与当年作物过程及储水缓冲共同有关。各年优化日期是在已知年度天气、固定参数和初始墒情下求得的回顾性候选；实际轮灌安排可结合未来天气和当地供水条件作滚动调整。'),
 ('p','单次水量与季节总量需同时评价。四年候选的最大单次水量分别为81.721 mm以上的年度实际最大值，具体完整数值见附表S9。2022年最大单次达到181.31 mm，而原日程最大单次为85.85 mm，反映了本轮未额外施加设备单次上限时的集中供水倾向。将管网能力、最低可执行水量、灌水间隔和允许季末储水配套纳入，可进一步形成实施尺度的制度。'),
 ('p','前期四窗口空间中的四种单目标算法对照帮助识别了较低灌水区间的可重复性；本轮五期空间中的NSGA-II与NSGA-III对照进一步补充了时序自由度变化后的证据。两组试验的控制空间和初值方式分别记录。所有候选均与相应日期、季节水量账及模型设定联结，从而使算法结果与水分过程解释保持一致。')])
# Replace the deliberately explicit event-magnitude sentence using source values.
for i,(k,t) in enumerate(BLOCKS):
 if k=='p' and t.startswith('单次水量与季节总量需同时评价'):
  BLOCKS[i]=(k,t.replace('81.721 mm以上的年度实际最大值',vals('Max_event_mm',2)+' mm'))

FIGS=copy.deepcopy(previous.FIGS)
FIGS.pop('scalar')
FIGS['pareto']=('Fig11_Five_stage_Pareto_fronts_EN','Five-stage NSGA-III yield–irrigation fronts and individual-event schedules across four years.','Red labels give rounded actual totals for Seedling, Jointing, Heading, Grain filling and Maturity. Stars show original DI model baselines; orange open circles show formal selected candidates. The displayed full-range fronts pool three 80-individual, 60-generation supplemental searches per year. Irrigation cancelled after crop termination is excluded from actual totals.')
FIGS['decomposition']=('Fig12_Irrigation_reduction_components_EN','Water-balance components of irrigation reduction under the selected five-stage schedules.','Percentages indicate the terminal-storage difference divided by the irrigation reduction. ET, storage and other-loss differences use identical annual forcing and initial soil water.')
FIGS['calendar']=('Fig13_Optimized_event_calendar_EN','Every optimized irrigation date and depth in the selected four-year schedules.','Colors indicate five phenological stages, with up to three optional events in each stage. Positive-depth event counts include trace numerical amounts; counts for depths ≥0.1 mm are reported separately. All exact positive depths remain in the source table.')
FIGS['stage_totals']=('Fig14_Five_stage_totals_EN','Five-stage irrigation totals and positive-depth event counts.','Gray bars show recorded DI schedules and colored bars show selected schedules. Counts include merged exact positive depths. Stage sums reconcile with actually executed seasonal irrigation.')
FIGS['algorithm']=('Fig15_Algorithm_search_history_EN','NSGA-III and NSGA-II population hypervolume across formal searches.','Lines show five-seed means and shading shows seed ranges. Algorithms share disclosed recorded-schedule and four-window initialization anchors. Final feasible-population union metrics are tabulated separately.')

