"""Verify that the editorial citation revision preserves all scientific data."""
from pathlib import Path
import hashlib,json,re
import pandas as pd
from docx import Document

ROOT=Path(__file__).resolve().parents[1]
PREVIOUS=Path('/workspace/urp_integrated_update_20261023')

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def texts(path):
 d=Document(path)
 return [p.text for p in d.paragraphs]+[p.text for t in d.tables for row in t.rows for c in row.cells for p in c.paragraphs]

def main():
 docs=[]
 for lang in ['CN','EN']:
  p=ROOT/f'documents/URP_Manuscript_{lang}_Updated_20261023.docx'
  d=Document(p);paragraphs=[p.text for p in d.paragraphs]
  i=paragraphs.index('参考文献' if lang=='CN' else 'References')
  body='\n'.join(paragraphs[:i]+[p.text for t in d.tables for r in t.rows for c in r.cells for p in c.paragraphs])
  assert not re.search(r'王尚今|王尚金|学长|\bWang\s*\[1\]',body)
  before=texts(PREVIOUS/'documents'/p.name)
  ref=next(p for p in paragraphs[i+1:] if p.startswith('[1] '))
  assert ref in before
  for key in ['209.83','306.50','264.50','257.47','48','37','2.4','100','[1]']:assert key in body,(lang,key)
  docs.append({'Language':lang,'Named_source_author_in_body':False,'Full_reference_1_preserved':True,'Existing_observation_provenance_retained':True})
 figures=0
 for p in (ROOT/'figures').iterdir():
  if p.is_file():assert sha(p)==sha(PREVIOUS/'figures'/p.name);figures+=1
 tables=0
 for p in (ROOT/'tables').glob('*.csv'):
  old=PREVIOUS/'tables'/p.name
  if not old.exists():continue
  a=pd.read_csv(p);b=pd.read_csv(old)
  assert list(a.columns)==list(b.columns) and a.shape==b.shape,p.name
  numeric=a.select_dtypes('number').columns.tolist()
  pd.testing.assert_frame_equal(a[numeric],b[numeric],check_exact=True)
  if p.name!='Current_Figure_Interpretations.csv':pd.testing.assert_frame_equal(a,b,check_exact=True)
  tables+=1
 evidence='source/paper_evidence_20261022/REFERENCE_EVIDENCE_revised.json'
 assert sha(ROOT/evidence)==sha(PREVIOUS/evidence)
 for name in ['URP_Supplementary_Methods_and_Schedules_20261023.docx','URP_All_Figure_Interpretations_Updated_20261023.docx','URP_Midterm_Report_Updated_20261023.docx']:
  assert not re.search(r'王尚今|王尚金|学长|\bWang\s*\[1\]','\n'.join(texts(ROOT/'documents'/name))),name
 result={'Status':'PASS','Change':'Citation and data-source wording only','Manuscripts':docs,'Figure_files_byte_identical':figures,'CSV_tables_numeric_values_identical':tables,'Reference_metadata_identical':True,'New_model_runs':False}
 (ROOT/'analysis/CITATION_REVISION_QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
