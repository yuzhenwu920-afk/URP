"""Fill the authorized administrative form with current project evidence."""
from pathlib import Path
import shutil,importlib.util,inspect,json
from docx import Document
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'midterm';OLD=Path('/workspace/urp_final_research_archive_20261021/stages/13_Project_midterm_report')
def main():
 for name in ['template','evidence','figures']:
  if not (OUT/name).exists():shutil.copytree(OLD/name,OUT/name)
 renderer=OUT/'template/original_midterm_renderer.py'
 spec=importlib.util.spec_from_file_location('midterm_base',renderer);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=OUT
 m.MEMBERS=[['吴雨臻（组长）','统筹、核心模型与结果解释','统筹四年研究路线，组织MCMC复核、敏感性与五生育期逐次灌水优化，归纳储水机制与实施条件，完成核心论证及成果整合。'],['李承昊','数据处理、评价与图表','整理气象、遥感、CC和生物量配对，协助逐日水量及逐次日程核对，制作英文图表和数据工作簿，支持论文及报告完善。'],['段璞','文献、归档与校对','核对文献、试验生育期及土壤资料，整理科研阶段索引、原始代码与结果记录，参与中英文稿、报告和归档校对。']]
 m.PROGRESS=[
 ('1. 资料与模型基础。','围绕立项灌溉制度优化目标，聚焦甘肃武威2019—2022年膜下滴灌玉米，贯通气象、审计ETo、遥感辅助CC、LAI换算CC、初始水、灌水、生物量及产量资料，四年模型均可调用并复现基准。'),
 ('2. 分阶段校准及原链诊断。','完成四年两阶段MCMC成果接入与复核，阶段一为5个冠层/耗水参数，阶段二为3个生产参数。原每组32 walkers、2000步，共16组阶段一和4组阶段二；已检查时间结构、边界邻近集中和中心稳定性，另保存2021短时续链及根深/覆膜条件试验。'),
 ('3. 真实模型Sobol分析。','完成八参数六输出、三个随机化序列及N128—N512递增分析，N512主结果61440次模型评估，完成年度排序与数值区间检查。产量主要敏感参数为晚期WP、HI0、早期WP及Kcb。'),
 ('4. 五生育期逐次灌水优化。','依据文献划分苗期、拔节期、抽穗期、灌浆期、成熟期，各期最多3个可选事件，同时优化15个水量与15个日期。四年NSGA-III/II正式及全范围补充搜索均已完成，保存457596条目标查询、455505次搜索内实际模型调用、每代种群和逐次日程。'),
 ('5. 机制分析与成果整合。','完成根深、覆膜、降水替换、储水与水量审计及原控制空间单目标求解器验证。现已统一五期论文、图表与中期报告，中英文稿各15图、10张三线表，转入导师审阅、实施条件细化与结题表达。')]
 m.RESULTS=[
 ('1. 形成四年可追溯校准结果。','48个CC和37个生物量配对可追溯。CC的R²cal为0.9306—0.9932，生物量为0.9685—0.9966；年度产量偏差−4.18%至+0.92%。原链诊断与参数中心分别归档，明确模型过程拟合和分布采样精度的评价口径。'),
 ('2. 获得年度敏感性规律。','共同独立范围下，产量ST四年均值为晚期WP 0.396、HI0 0.206、早期WP 0.164、Kcb 0.145；年度平均排序稳定，保留逐年幅度与数值区间。'),
 ('3. 获得五期候选及逐次日程。','95%观测产量门槛下，四年主候选为209.83、306.50、264.50、257.47 mm，对应产量15.725、16.427、15.068、13.390 t/ha，减灌36.40%—58.25%。每期合计、每次日期与水量均已导出，两种遗传算法最低水量差0.03—1.47 mm。'),
 ('4. 明确水量组成并完成整合。','ET下降1.89%—5.98%，季末储水差解释81.09%—96.72%的减灌量。2021年少灌368.97 mm中ET仅少11.46 mm，储水差356.85 mm。完整方程回放及全部查询检查通过，形成中英文论文、英文图件、逐次日程、工作簿及分阶段科研包。')]
 m.PROBLEMS=[
 ('1. 参数分布采样精度。','原阶段一最差R̂约1.122—1.181，最小组bulk ESS约17.79—25.34，中心对截取较稳定。现阶段按原保留均值开展确定性计算；后续结合可辨识性、独立初始化和误差尺度补强分布精度。'),
 ('2. 季末储水与设备条件。','本轮目标中未额外加入季末储水底线、设备单次能力、最小事件水量与间隔。2022候选最大单次181.31 mm，高于原85.85 mm；已单列核对，后续依据田间设备与水分资料细化实施方案。'),
 ('3. 资料与结构依据。','保留土壤实测1 m与模拟2.4 m剖面的区别；补充原始站点日雨量、分层水分与蒸散分量证据，联合评估初值、覆膜与根系设定。'),
 ('4. 成果范围与后续表达。','当前成果集中于DI玉米的模型校准、敏感性、优化与诊断。与导师核定结题范围，完善论文审阅、数据引用及阶段报告；已完成计算与论文发表、田间试验等成果类型分别统计。')]
 m.SCHEDULE=[['10月下旬','完成五期结果、图表、引文与阶段归档交叉核对，提交导师审阅。','统一版本的中英文稿、中期报告和数据索引。'],['11月上中旬','结合分层水分与设备信息讨论季末储水、单次能力和间隔约束。','实施条件核对表及必要补充分析方案。'],['11月下旬','完善采样精度和误差解释，按导师意见修订正文及补充资料。','修订稿、逐图解析和方法说明。'],['12月','按学校节点完成结题、答辩和科研材料交接。','结题文稿、展示图表及完整归档。']]
 source=inspect.getsource(m.build)
 pairs={
 '截至2026-10-19的已核验成果':'截至2026-10-23的五生育期优化及诊断成果',
 '2026年10月19日（请按实际提交日核定）':'2026年10月23日（请按实际提交日核定）',
 '附件1、2展示四年CC与生物量过程；随附CSV提供逐点来源与复算指标；采样汇总表记录既有两阶段成果；2022接入核验文件和19项验证记录提供复现证明。18组四年图及六包同步记录保存在原交付分支，随附填写说明给出索引。':'附件1—6展示四年CC、生物量、Sobol、五期前沿、逐次灌水及水量来源。论文图表、逐代种群、逐次查询、日程与日水量账均在本版分阶段归档及统一索引中提供。',
 '对照立项书2026年11—12月成果总结阶段拟定下列安排，具体日期按学校节点核定。':'主要计算模块已完成，以下安排侧重证据补强、导师审阅、实施条件细化及结题表达，按学校节点核定。',
 '执行顺序以各年模型可调用、基准复现通过为前提；正式敏感性、节水率与推荐灌溉方案须在真实模型实验完成后报告。':'四年真实模型、敏感性及五期优化均已完成；后续以设备能力、墒情与季末储水要求细化实施方案。',
 '证据口径：2019—2021使用已核验的原始均值点输出，2022使用本轮原模型冻结均值点回放；本图属于校准拟合评价，不是独立验证。':'证据口径：四年原模型中心与源数据均已核对，本图报告校准配对及均值轨迹；采样精度由独立诊断另行量化。',
 '48个CC配对均与各年逐日输出对应日期一致。2022资料完整性和原模型预审已通过；四年图均包含真实年度数据，不采用插值补位。源表位于随附evidence/four_year_source_data目录。':'四年48个CC配对均有对应日期的模型输出，图件含全部年度。数据来源与数值见本版工作簿及年度模型档案。',
 '图2  实线为模型逐日输出，空心点为校准生物量资料；单位为t/ha。各面板坐标范围统一，不删去不利于拟合的观测点。颜色与附件1一致。':'图2  四年观测与模拟生物量散点，虚线为1:1关系；单位为t/ha，R²cal与RMSE按全部37个配对计算。',
 '本阶段结果的适用边界':'生物量评价与后续分析',
 '四年共37个生物量配对。现有拟合支持过程描述与数值复现，不能据此提前给出正式Sobol参数排名、优化节水率、未知年份的普适灌溉制度或独立田间验证结论。下一阶段将完成真实模型敏感性与优化实验，再补充相应图表。':'四年37个生物量配对描述主要生长过程。正式Sobol、五期逐次日程优化与水量核算均已完成，结果见后附英文图及中英文稿。',
 '2019—2021使用已核验原输出；2022使用本轮原模型冻结均值点回放。以上均为校准拟合。':'四年校准配对和均值轨迹已核对；当前五期优化与水量核算另附证据。',
 "'new_MCMC_run':False,'full_real_Sobol_or_optimization_completed':False":"'MCMC_rerun_in_this_document_update':False,'full_real_Sobol_or_optimization_completed':True,'five_stage_optimization_completed':True",
 }
 for a,b in pairs.items():
  assert a in source,a
  source=source.replace(a,b)
 for src,dst in [('Fig04_CC_calibration_EN','midterm_CC_four_years'),('Fig05_Biomass_calibration_EN','midterm_biomass_four_years')]:shutil.copy2(ROOT/'figures'/(src+'.png'),OUT/'figures'/(dst+'.png'))
 exec(compile(source,str(OUT/'build_midterm_form_current.py'),'exec'),m.__dict__);m.build();(OUT/'build_midterm_form_current.py').write_text(source)
 d=Document(OUT/'URP_midterm_report.docx')
 for title,name,caption in [
 ('附件3  四年Sobol敏感性','Fig09_Sobol_four_outputs_EN','图3  三序列N512均值；四年使用共同独立参数范围，比较输出主导参数及年度稳定性。'),
 ('附件4  五生育期帕累托前沿','Fig11_Five_stage_Pareto_fronts_EN','图4  五期各最多3个可选事件；括号为五期实际水量合计，空心圈为正式95%观测产量候选。'),
 ('附件5  优化后的每次灌水日期及水量','Fig13_Optimized_event_calendar_EN','图5  四年每次正水量事件；微量正数在源表保留。完整日程、五期合计及≥0.1 mm事件数见随附工作簿和逐次日程Word。'),
 ('附件6  减灌水量来源','Fig12_Irrigation_reduction_components_EN','图6  减灌分解为ET、季末储水及其他损失差；2021年368.97 mm减灌中，356.85 mm为季末储水差，ET仅少11.46 mm。')]:
  d.add_page_break();m.para(d,title,14,True,after=12,keep=True);p=d.add_paragraph();m.fmt(p,10,after=6,align=m.WD_ALIGN_PARAGRAPH.CENTER);p.paragraph_format.line_spacing=1;p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(ROOT/'figures'/(name+'.png')),width=m.Cm(16.5));m.para(d,caption,10.5,after=8)
 d.core_properties.subject='截至2026-10-23；四年五期逐次日程、真实链诊断与当前论文统一；报销及审核签名留空'
 d.save(OUT/'URP_midterm_report.docx');shutil.copy2(OUT/'URP_midterm_report.docx',ROOT/'documents/URP_Midterm_Report_Updated_20261023.docx')
 (OUT/'README.md').write_text('项目编号X2026100190937，人员、导师和联系方式沿用正式立项资料；组长、李、段按用户确认的贡献次序分配工作，无虚构百分比。报告截至2026年10月23日，写明四年校准、Sobol、五期逐次优化及诊断已完成。实际报销、导师和专家意见、签名保留空白，提交日期按实际学校节点核定。\n')
 print('Current midterm report built with six evidence attachments',flush=True)
if __name__=='__main__':main()
