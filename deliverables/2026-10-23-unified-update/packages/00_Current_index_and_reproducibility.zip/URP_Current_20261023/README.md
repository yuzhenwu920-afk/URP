# URP 当前统一交付版 · 2026-10-23

本版把已核验的四年五生育期优化结果同步到**中文论文、英文论文、中期报告、逐图解析、图册、数据工作簿与全阶段归档索引**。主要结果的计算版本为2026-10-22，文稿整合版本为2026-10-23。本次根据最新意见统一数据来源表述：正文以既有田间观测资料及编号引文说明来源，作者姓名与完整学位论文信息保留在参考文献中。图表数值、五期日程及模型计算结果沿用已核验版本。

## 当前文件

- `documents/URP_Manuscript_CN_Updated_20261023.docx/pdf`：中文完整稿，15张全英文图、10张三线表。
- `documents/URP_Manuscript_EN_Updated_20261023.docx/pdf`：对应英文完整稿；与中文稿逐内容块及图表顺序对应。
- `documents/URP_Midterm_Report_Updated_20261023.docx/pdf`：沿用学校模板，写明四年校准、Sobol、五期逐次优化及诊断已完成。项目编号X2026100190937，实际报销、审核意见和签名留空。
- `documents/URP_Supplementary_Methods_and_Schedules_20261023.docx/pdf`：先验、真实原链诊断、五期日期界限、四年全部逐次日程、单次水量与历史控制空间诊断。
- `documents/URP_All_Figure_Interpretations_Updated_20261023.docx/pdf`：15组当前主图，中英文解析。
- `documents/URP_All_Current_English_Figures_20261023.pdf`：15组当前英文矢量图册。
- `tables/URP_All_Current_Data_20261023.xlsx`：当前图表数据与原始精度CSV汇总；逐次日程可按年度直接筛选。
- `figures/`：15组450 dpi PNG、矢量PDF、SVG。当前流程图也已改为五期、最多15个可选事件。

## 统一结果口径

五期为苗期、拔节期、抽穗期、灌浆期、成熟期。每期最多3个可选事件，以15个连续水量和15个整数日期联合优化；零量不执行、同日合并，全部阶段均允许搜索。

主候选取正式NSGA-III五种子最终种群可行非支配解并集中的最低实际灌水量，门槛为95%观测产量。四年灌水量209.831581、306.498954、264.499975、257.465253 mm，对应产量15.724632、16.427293、15.068415、13.389806 t/ha。源表保留全部小水量；≥0.1 mm的事件数另列统计。

固定原四年参数中心、逐日天气、初始水、土壤结构、MulchPct=75%、fMulch=0、Zmin=0.30 m、Zmax=2.30 m、2.4 m剖面。五期日期优化是年度已知天气下的回顾性计算。设备单次上限、最小量、间隔和季末储水底线没有新增为硬约束，单次最大值和储水变化均在正文与补充表报告。

减灌36.40%—58.25%，ET下降1.89%—5.98%；储水差解释81.09%—96.72%的减灌。2021年减灌368.97 mm，其中ET差11.46 mm、储水差356.85 mm、其他损失差0.66 mm。

原MCMC采样诊断沿用真实时间序列结果，参数中心稳定性与R̂、ESS分开说明。当前文稿未把模型拟合或本次优化更新写成重新完成长链收敛。原单目标四算法、根深1 m、fMulch条件试验、降水替换等各自保留原控制空间与物理设定，在补充资料和阶段索引中单列。

## 全部阶段包

全部阶段总包包含当前文件与所有既有科研阶段压缩包。当前索引按来源和作用区分：01原始资料、02四年MCMC、03原模型、04 Sobol、05当前五期优化、06—10结构/根深/覆膜/降水/单目标试验、11当前图表、12当前论文、13当前中期、14研究历史、15原链诊断、16短时续链。以前的四窗口主优化和旧稿包放在`history/`，其数据作为过程记录保存，当前论文统一使用05的新五期结果。

05包解压根目录为`URP_Five_Stage_Multi_Event`；原始科研阶段包沿用`URP_Research_Archive`；本次文稿工程包根目录为`URP_Current_20261023`。按各包根目录合并即可，索引记录每个包的实际根目录。完整原始逐查询与每代种群保存在05的四个年度运行包中。

## 重新生成文稿

Python 3.12，依赖numpy、pandas、scipy、matplotlib、Pillow、python-docx、openpyxl、PyMuPDF。PDF转换使用LibreOffice和Noto CJK字体。原数值计算版本见05结果包requirements。

```bash
python code/build_current_documents.py
python code/build_current_midterm.py
soffice --headless --convert-to pdf --outdir documents documents/*.docx
python code/validate_current.py
```

本版执行文稿及归档整合，无新增MCMC、Sobol或优化计算。结果来源固定于Git提交`20f1616556f5aeb79329b7ead22faa28f9fcda6a`。逐项核对、哈希与远程下载记录随交付保存。
