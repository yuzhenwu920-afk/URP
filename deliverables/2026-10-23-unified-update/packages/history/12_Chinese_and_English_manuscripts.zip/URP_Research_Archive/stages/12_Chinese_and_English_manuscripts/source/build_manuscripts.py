from pathlib import Path
import json,re,csv,shutil,hashlib,os
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION_START, WD_ORIENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from manuscript_content import *
ROOT=Path(__file__).resolve().parents[1];ST=ROOT/'stages';OUT=ST/'12_Chinese_and_English_manuscripts'
OUT.mkdir(exist_ok=True);(OUT/'source').mkdir(exist_ok=True);(OUT/'word_figures').mkdir(exist_ok=True)
FIG=ST/'11_English_figures_tables_and_interpretations';TB=FIG/'tables';FINAL=FIG/'Final_revision'
def pth(base,n):return base/'figures'/n
FIGS={
 'workflow':(pth(FIG,'Figure1_three_column_EN.png'),'Overall framework. Three patterned columns connect sources, staged calibration and decision analysis. Historical four-year analyses and later structural/forcing diagnostics remain separate evidence levels; completing a workflow does not certify MCMC convergence.'),
 'environment':(pth(FIG,'Figure10_environment_EN.png'),'Environmental drivers within the actual model calendars in 2019–2022. Precipitation and reference evapotranspiration retain their input values. ETo is an atmospheric reference demand, not actual crop ET; calendar differences are documented in the source tables.'),
 'cc':(pth(FIG,'F02_CC_trajectories_EN.png'),'Four-year canopy-cover calibration. Lines show deterministic trajectories at frozen phase-specific centers; symbols are field-LAI-derived CC used in calibration. Annual sample sizes are 12, 13, 11 and 12. Values are fractions. These are in-sample fits, not posterior predictive bands or independent validation.'),
 'biomass':(pth(FIG,'F05_Biomass_pairs_EN.png'),'Observed–simulated aboveground dry-biomass pairs for four years (n=9, 10, 8 and 10). The 1:1 relation and calibration error statistics assess agreement. Published-figure digitization and assumed observation uncertainty are retained; high correlation alone does not establish unbiased prediction.'),
 'bounds':(pth(FIG,'F07_parameter_intervals_EN.png'),'Retained-sample empirical intervals for eight parameters, with annual supports. Parameters close to support boundaries remain visible. Intervals are phase-specific empirical quantiles of correlated samples, not a certified eight-dimensional joint posterior. Boundary-neighborhood mass is quantified separately in the source table.'),
 'water':(pth(FIG,'F09_annual_water_budget_EN.png'),'Annual baseline inflow, outflow and storage change. Inflow includes actual irrigation and rainfall plus other modeled inputs if present; outflow includes ET and losses. Storage is plotted as final minus initial water, not the absolute terminal stock. Connecting four years is descriptive and does not constitute a trend test.'),
 'pooled':(pth(FINAL,'F13_Pooled_biomass_regression_EN.png'),'Pooled four-year biomass regression using all 37 calibration pairs. Observed biomass is X and simulated biomass is Y. The solid line is OLS and the dashed line is 1:1; OLS R² and Pearson r are shown. Dates are repeated within years, and no independent-observation significance test is inferred.'),
 'sobol':(pth(FIG,'R01_Sobol_four_outputs_2x2_EN.png'),'Four-year total-effect Sobol indices for yield, biomass, seasonal ET and maximum canopy cover. Cells average three N=512 scrambles per year under the same eight independent uniform input ranges. A common scale supports comparison. Tr and Es results are supplied separately; ST is not normalized to sum to one.'),
 'yield_sobol':(pth(FINAL,'R02_Sobol_Yield_CI_Four_years_and_mean_EN.png'),'Four-year yield S1 and ST. Colored symbols average three N=512 scrambles. Error bars are approximate 95% numerical bootstrap intervals for that mean, using 512 independent complete-block resamples within each scramble. Diamonds are equal-weight four-year means; gray segments are across-year ranges, not confidence intervals. These do not represent posterior or field predictive uncertainty.'),
 'pareto':(pth(FINAL,'R03_Pareto_four_years_annotated_EN.png'),'Full-range NSGA-III best-found fronts: blue dashed envelopes, red evaluated controls and rounded (W1, W2, W3, W4) allocations in mm. Stars are DI model baselines. The 95% yield line is a reference only. These supplemental searches total 57,600 evaluations, separate from the formal gated experiment; historical Zmax=2.30 m and fMulch=0 apply. Exact controls are archived. Lines do not prove global optimality or field validity.'),
 'decomposition':(pth(FIG,'S07_Irrigation_reduction_decomposition_EN.png'),'Partition of irrigation reduction between the historical DI baseline and selected candidate. ET, terminal-storage and other-loss differences are separated using identical forcing and initial water. A lower terminal stock is not equivalent to reduced consumptive use; part of the difference reflects avoided baseline storage gain.'),
 'mulch':(pth(ST/'08_2021_mulch_conditional_calibration_and_optimization','T01_Yield_irrigation_comparison.png'),'2021 irrigation–yield responses under separately refitted fMulch=0.50, 0.75 and 0.85 settings, each with maximum root depth 1 m and 75% cover. Fixed-schedule proportional responses and optimized envelopes have different meanings. These are short-chain conditional pilots, not independently validated physical factor estimates.'),
 'rainfall':(pth(ST/'09_Rainfall_and_data_provenance_audit','P02_Cumulative_precipitation_4years_EN.png'),'Cumulative precipitation from the supplied GEE series and approximate digitization of the thesis daily figure. Matched calendar windows, broken axes and digitization limitations are retained. The graph reconstruction and WHCNS balance-input total are not raw gauge truth; original daily gauge records remain unavailable.'),
 'scalar':(pth(ST/'10_Single_objective_multi_algorithm_validation','S04_95pct_yield_algorithm_comparison_EN.png'),'Minimum irrigation found at 95% of observed yield by GA, one-objective NSGA-II, generalized simulated annealing and differential evolution. Historical four-year and conditional 2021 mulch settings remain separate. Independent queries, equal-budget refinement and within-method archive summaries are distinguished in the tables. Historical NSGA-III references have unequal budgets and do not establish a fair performance ranking.'),
}
def load(n):return pd.read_csv(TB/n)
def tables():
    a=load('Table3_calibration_performance.csv'); sel=load('Table5_selected_candidates.csv'); par=load('Table2_parameter_definitions.csv')
    sob=load('Sobol_four_year_descriptive_means.csv');sob=sob[sob.Output=='Y_13pct'].sort_values('ST_four_year_mean',ascending=False)
    fm=json.loads((ST/'08_2021_mulch_conditional_calibration_and_optimization/RESULT_SUMMARY.json').read_text())['Results']
    s=pd.read_csv(ST/'10_Single_objective_multi_algorithm_validation/tables/Overall_best_95pct_candidates.csv')
    out={
      'study':('Study data and annual DI observations.', ['Year','Irrigation\n(mm)','Events','Yobs\n(t ha⁻¹)','CC/B\npairs','ETobs\n(mm)','Es,obs\n(mm)'],
       [[y,i,n,yo,npair,et,es] for y,i,n,yo,npair,et,es in zip([2019,2020,2021,2022],[445.27,559.76,633.47,404.84],[8,8,7,5],[16.55,17.29,15.86,14.08],['12/9','13/10','11/8','12/10'],[661.45,637.03,626.81,584.11],[76,79,78,81])],
       'Observed aggregates follow thesis Table 4-1 and printed p.39; data pairs include LAI conversion and biomass digitization. The 2021 event sum differs by 0.01 mm from the rounded published irrigation total.'),
      'parameters':('Parameter roles and common Sobol input supports.', ['Parameter','Stage','Definition','Unit','Uniform\nsupport'],
       [[r.Parameter,int(r.Stage),r.Meaning,r.Unit,f'{r.Sobol_lower:g}–{r.Sobol_upper:g}'] for r in par.itertuples()],
       'Supports define common independent Sobol inputs, not correlated MCMC posterior distributions or necessarily each year’s phase-specific prior density. Annual priors and centers are archived separately.'),
      'fit':('Four-year calibration performance at frozen centers.', ['Year','CC R²cal','CC RMSE','B R²cal','B RMSE\n(t ha⁻¹)','Ysim\n(t ha⁻¹)','Y bias\n(%)'],
       [[int(r.Year),f'{r.CC_R2_cal:.4f}',f'{r.CC_RMSE:.4f}',f'{r.Biomass_R2_cal:.4f}',f'{r.Biomass_RMSE_t_ha:.4f}',f'{r.Baseline_Y13_t_ha:.3f}',f'{r.Yield_bias_pct:+.2f}'] for r in a.itertuples()],
       'R²cal=1−SSE/SST uses observations as the reference. CC is a fraction; B is aboveground dry biomass. One annual yield pair does not support a within-year yield R². All metrics are in-sample.'),
      'sensitivity':('Descriptive yield sensitivity across four fixed years.', ['Parameter','S1 mean','ST mean','ST minimum','ST maximum'],
       [[r.Parameter,f'{r.S1_four_year_mean:.3f}',f'{r.ST_four_year_mean:.3f}',f'{r.ST_year_min:.3f}',f'{r.ST_year_max:.3f}'] for r in sob.itertuples()],
       'Three scrambles are averaged within each year, then years receive equal weights. Annual ranges are descriptive, not confidence limits; indices are not for a pooled climate distribution.'),
      'candidates':('Historical gated NSGA-III candidates and water-source differences.', ['Year','Iopt\n(mm)','Yopt\n(t ha⁻¹)','I decrease\n(%)','ET decrease\n(mm)','Lower Send\n(mm)','Storage share\n(%)'],
       [[int(r.Year),f'{r.Candidate_irrigation_mm:.2f}',f'{r.Candidate_Y13:.3f}',f'{r.Irrigation_reduction_pct:.2f}',f'{r.ET_reduction_mm:.2f}',f'{r.Lower_final_soil_storage_mm:.2f}',f'{r.Storage_difference_share_of_irrigation_reduction_pct:.2f}'] for r in sel.itertuples()],
       'Candidates follow the original minimum-irrigation rule within the gated NSGA-III union. Different archive queries can find slightly different minima. No terminal-storage floor or additional hardware event cap was enforced.'),
      'mulch_table':('Separately refitted 2021 mulch scenarios at 1 m maximum root depth.', ['fMulch','DI Y13\n(t ha⁻¹)','DI Es\n(mm)','DI ET\n(mm)','Zero-I Y13\n(t ha⁻¹)','NSGA-III I95\n(mm)'],
       [[r['fMulch'],f"{r['DI_Y13']:.3f}",f"{r['DI_Es_mm']:.2f}",f"{r['DI_ET_mm']:.2f}",f"{r['Zero_Y13']:.3f}",f'{ii:.2f}'] for r,ii in zip(fm,[319.11182603775944,282.720592557964,287.5341842651938])],
       'All cases use 75% cover and separately refitted 500-step pilots. I95 is the best found at Y13≥15.067 t ha⁻¹, not the full observed 15.86 t ha⁻¹. Es is below the thesis-reported 78 mm in all three cases. Convergence is not certified.'),
      'scalar_table':('New scalar-search archive minima at 95% observed yield.', ['Case','Method','Imin\n(mm)','Y achieved\n(t ha⁻¹)','Old NSGA-III\nreference I (mm)','Difference\n(mm)'],
       [[r.Case.replace('old_','Historical ').replace('new_fm050','2021 f=0.50').replace('new_fm075','2021 f=0.75').replace('new_fm085','2021 f=0.85'),r.Algorithm,f'{r.Irrigation_mm:.2f}',f'{r.Y_13pct:.3f}',f'{r.Historical_best_I_mm:.2f}',f'{r.Gap_to_historical_I_mm:+.2f}'] for r in s.itertuples()],
       'These are minima over each method’s own threshold-sweep archive, subsequently compared across methods; they are not all independent 384-query runs. Historical reference budgets differ. A negative difference indicates a slightly smaller new archive value, not proven algorithmic superiority.'),
    }
    return out

def font(run,lang='EN',size=11,bold=False):
    run.font.name='Times New Roman' if lang=='EN' else 'Noto Serif CJK SC';run.font.size=Pt(size);run.bold=bold
    f=run._element.get_or_add_rPr().get_or_add_rFonts();f.set(qn('w:eastAsia'),'Noto Serif CJK SC');return run
def para(d,txt,lang='EN',size=11,bold=False,keep=False):
    p=d.add_paragraph();p.paragraph_format.space_after=Pt(6);p.paragraph_format.line_spacing=1.25;p.paragraph_format.keep_with_next=keep
    font(p.add_run(txt),lang,size,bold);return p
def style(d,lang):
    s=d.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7);s.left_margin=s.right_margin=Cm(2.1);s.top_margin=Cm(1.8);s.bottom_margin=Cm(1.8);s.header_distance=Cm(.75);s.footer_distance=Cm(.75)
    for n in ['Normal','Body Text']:
        st=d.styles[n];st.font.name='Times New Roman' if lang=='EN' else 'Noto Serif CJK SC';st.font.size=Pt(11);st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC')
    h=s.header.paragraphs[0];h.alignment=WD_ALIGN_PARAGRAPH.RIGHT;font(h.add_run('URP | 2019–2022 DI maize | Manuscript draft'),lang,8)
    f=s.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');f._p.append(field)
    d.core_properties.author='吴雨臻、李承昊、段璞';d.core_properties.subject='Research manuscript draft; 2026-10-21 evidence freeze'
def heading(d,txt,lang,level=2):
    p=d.add_paragraph(style=f'Heading {level}');p.paragraph_format.space_before=Pt(10);p.paragraph_format.space_after=Pt(6)
    font(p.add_run(txt),lang,14 if level==1 else 12,True);return p
def three_line(d,num,item,lang):
    title,heads,rows,note=item;para(d,f'Table {num}. {title}','EN',10,True,True)
    t=d.add_table(rows=1,cols=len(heads));t.autofit=True
    for c,x in zip(t.rows[0].cells,heads):c.text=str(x)
    for rr in rows:
        for c,x in zip(t.add_row().cells,rr):c.text=str(x)
    pr=t._tbl.tblPr;b=OxmlElement('w:tblBorders')
    for edge in ['top','bottom','left','right','insideH','insideV']:
        e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single' if edge in ['top','bottom'] else 'nil');e.set(qn('w:sz'),'10' if edge in ['top','bottom'] else '0');e.set(qn('w:color'),'000000');b.append(e)
    pr.append(b)
    for i,row in enumerate(t.rows):
        if i==0:
            repeat=OxmlElement('w:tblHeader');row._tr.get_or_add_trPr().append(repeat)
        trp=row._tr.get_or_add_trPr();trp.append(OxmlElement('w:cantSplit'))
        for c in row.cells:
            mar=OxmlElement('w:tcMar')
            for edge in ['top','bottom','left','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:w'),'65');e.set(qn('w:type'),'dxa');mar.append(e)
            c._tc.get_or_add_tcPr().append(mar)
            if i==0:
                bb=OxmlElement('w:tcBorders');e=OxmlElement('w:bottom');e.set(qn('w:val'),'single');e.set(qn('w:sz'),'6');bb.append(e);c._tc.get_or_add_tcPr().append(bb)
            for p in c.paragraphs:
                p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.05;p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.keep_with_next=(i<len(t.rows)-1)
                for r in p.runs:font(r,'EN',9 if len(heads)>5 else 9.5,i==0)
    para(d,'Note. '+note,'EN',9)
    return t
def embed(d,key,num,lang):
    path,cap=FIGS[key]
    if not path.exists():raise FileNotFoundError(path)
    landscape=(key=='pareto')
    if landscape:
        s=d.add_section(WD_SECTION_START.NEW_PAGE);s.orientation=WD_ORIENT.LANDSCAPE;s.page_width=Cm(29.7);s.page_height=Cm(21);s.top_margin=s.bottom_margin=Cm(1.0);s.left_margin=s.right_margin=Cm(1.35)
    im=Image.open(path).convert('RGB'); im.thumbnail((2600,2600),Image.Resampling.LANCZOS)
    dest=OUT/'word_figures'/f'{key}.jpg';im.save(dest,quality=96,subsampling=0)
    p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.line_spacing=1;p.paragraph_format.space_after=Pt(3);p.paragraph_format.keep_with_next=True
    p.add_run().add_picture(str(dest),width=Cm(25.0 if landscape else 16.5))
    para(d,f'Figure {num}. '+cap,'EN',9.5)
    if landscape:
        s=d.add_section(WD_SECTION_START.NEW_PAGE);s.orientation=WD_ORIENT.PORTRAIT;s.page_width=Cm(21);s.page_height=Cm(29.7);s.top_margin=s.bottom_margin=Cm(1.8);s.left_margin=s.right_margin=Cm(2.1)

def make(lang):
    d=Document();style(d,lang);title=TITLE_CN if lang=='CN' else TITLE_EN;d.core_properties.title=title
    p=para(d,title,lang,18,True);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p=para(d,'吴雨臻、李承昊、段璞' if lang=='CN' else 'Yuzhen Wu, Chenghao Li, Pu Duan',lang,11);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    para(d,'中国农业大学土地科学与技术学院；指导教师：廖人宽教授' if lang=='CN' else 'College of Land Science and Technology, China Agricultural University; project advisor: Prof. Renkuan Liao',lang,10)
    para(d,'论文完整初稿｜数据与结果冻结至2026年10月21日｜作者与投稿信息待项目组核定' if lang=='CN' else 'Full manuscript draft | Evidence freeze: 21 October 2026 | Author/submission details require team verification',lang,9)
    heading(d,'摘要' if lang=='CN' else 'Abstract',lang)
    para(d,ABSTRACT_CN if lang=='CN' else ABSTRACT_EN,lang)
    para(d,'关键词：滴灌玉米；MCMC；Sobol；NSGA-III；土壤储水；水量平衡' if lang=='CN' else 'Keywords: drip-irrigated maize; MCMC; Sobol; NSGA-III; soil-water storage; water balance',lang,10)
    fn=tn=0; log=[]; md=['# '+title,'',ABSTRACT_CN if lang=='CN' else ABSTRACT_EN,'']
    for zh,en,cz,ce,figs,tabs in SECTIONS:
        h=zh if lang=='CN' else en;heading(d,h,lang,1 if re.match(r'^\d ',h) else 2);md += ['## '+h,'']
        for text in (cz if lang=='CN' else ce):para(d,text,lang);md += [text,'']
        if 'pareto' in figs:
            fn+=1;embed(d,'pareto',fn,lang);log.append(dict(type='figure',number=fn,key='pareto',path=str(FIGS['pareto'][0].relative_to(ST))))
            md += [f'![Figure {fn}]({os.path.relpath(FIGS["pareto"][0],OUT)})','',f'Figure {fn}. '+FIGS['pareto'][1],'']
        for tab in tabs:
            tn+=1;three_line(d,tn,tables()[tab],lang);log.append(dict(type='table',number=tn,key=tab));md += [f'Table {tn}. '+tables()[tab][0],'']
        for key in [key for key in figs if key!='pareto']:
            fn+=1;embed(d,key,fn,lang);log.append(dict(type='figure',number=fn,key=key,path=str(FIGS[key][0].relative_to(ST))))
            md += [f'![Figure {fn}]({os.path.relpath(FIGS[key][0],OUT)})','',f'Figure {fn}. '+FIGS[key][1],'']
    heading(d,'参考文献' if lang=='CN' else 'References',lang,1)
    for i,r in enumerate(REFS,1):
        txt=f'[{i}] '+r[0 if lang=='CN' else 1]+(' https://doi.org/'+r[2] if r[2] else '')
        para(d,txt,lang,9.5);md += [txt,'']
    name='URP_Manuscript_CN' if lang=='CN' else 'URP_Manuscript_EN';d.save(OUT/(name+'.docx'));(OUT/(name+'.md')).write_text('\n'.join(md),encoding='utf-8')
    (OUT/'source'/f'FIGURE_TABLE_MAP_{lang}.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
    print(name,'figures',fn,'tables',tn,'paragraphs',len(d.paragraphs))
def source_assets():
    shutil.copy2(Path(__file__).with_name('manuscript_content.py'),OUT/'source/manuscript_content.py')
    shutil.copy2(__file__,OUT/'source/build_manuscripts.py')
    for key,it in tables().items():pd.DataFrame(it[2],columns=it[1]).to_csv(OUT/'source'/f'Table_{key}.csv',index=False)
    refs=[dict(number=i,CN=r[0],EN=r[1],DOI=r[2],verification_evidence=r[3]) for i,r in enumerate(REFS,1)]
    (OUT/'source/REFERENCE_EVIDENCE.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2))
    lib=ST/'01_Raw_data_and_references/literature'
    (lib/'REFERENCE_EVIDENCE.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2))
    # Crossref access is not claimed as successful; supplied paper and official repositories are the evidence.
    failed=lib/'verified_references.json'
    if failed.exists():failed.rename(lib/'Crossref_lookup_attempts_NOT_verification.json')
    (lib/'README.md').write_text('参考文献依据用户提供的论文原件及已取得的官方emcee、SALib、pymoo、AquaCrop和SciPy文档交叉核对，REFERENCE_EVIDENCE.json逐条记录。Crossref接口受网络域名限制，失败请求独立保留，不作为在线验证成功证据。官方文档摘录仅作书目与方法核对，不替换本项目已固定的执行版本。\n\n未取得其他期刊论文全文，故不伪称附有全部引用PDF。正文只据对应文献支持的通用方法或数据来源，不借用棉花论文的实证百分数。\n',encoding='utf-8')
    (OUT/'README.md').write_text('中英文为同一结果、同一图表顺序的完整论文初稿，各14图、7张三线表；不是仅有章节标题的骨架。\n\n所有图中文字、单位、图例及图注为英文；四年均有实际年度数据。图10采用横向整页，另有四个单年清晰版。原始600dpi PNG、PDF、SVG在11号图表包，正文嵌入高质量缩图以控制Word大小。source保存源文、图表映射、表格CSV和参考文献依据。\n\n历史四年fMulch0/root2.3m与后续2021三覆膜/root1m分别论述。无法认证充分收敛、尚未实施的独立田间验证、设备与储水约束均明确披露，不把模型计算完成写为研究限制消失。\n',encoding='utf-8')
if __name__=='__main__':
    source_assets();make('CN');make('EN')
