# 四年滴灌玉米的分阶段贝叶斯校准、敏感性分析与灌溉优化：区分减灌潜力与土壤储水代价

为检验干旱区作物模型优化所得较大减灌幅度的物理依据，本研究整合甘肃武威2019—2022年滴灌玉米资料，对AquaCrop两阶段马尔科夫链蒙特卡洛（MCMC）校准成果进行溯源复核，在统一独立参数范围下开展Sobol分析，并比较NSGA-III与NSGA-II的灌水—产量权衡。另以2021年根深1 m及三个覆膜蒸发调整因子的条件重校准、降水替换和四种单目标算法开展诊断。四年冠层覆盖度和生物量的样本内决定系数分别为0.9306—0.9932和0.9685—0.9966，但原链尚未全面通过严格收敛检查，部分参数存在边界邻近集中。产量总效应指数的四年描述均值以晚期水分生产率（0.396）和收获指数（0.206）为主。原四年中心参数方案在达到95%观测产量门槛时，灌水量较实际日程下降35.6%—57.8%，蒸散量仅下降1.4%—5.2%；季末剖面储水差解释约83.2%—97.4%的减灌水量。2021年覆膜条件重校准和独立求解器比较仍给出较低灌水解，说明现象不能仅归因于某一算法或单一覆膜系数。结果支持单季模型条件下的灌水权衡探索，但不足以确立可持续田间灌水定额。建议在确认初始水、根区水分过程、季末储水底线及单次灌水能力后，再开展联合不确定性与跨季验证。

## 1 引言

干旱灌区的节水决策既涉及当季产量，也涉及降水、初始土壤水、灌水和季末储水之间的分配。武威覆膜玉米试验提供了作物生长和水分过程资料[1]，但实际日程的总灌水量并不自动等于作物的最低需水量。反之，模型找到较低灌水解也不自动证明田间存在同等可实施的节水潜力。尤其应区分田间减灌、实际蒸散下降与跨季土壤水变化；三者涉及不同的管理尺度[13]。

AquaCrop以冠层覆盖、蒸腾、生物量和收获指数等过程连接水分条件与产量[3,4]。MCMC可刻画给定模型及观测误差假设下的参数分布[5]，Sobol分析可量化声明输入分布下各参数对输出方差的贡献[6,7]，进化算法可描述产量与用水的相互制约[8–10]。这些环节必须各自检验：过程拟合不能替代采样诊断，参数敏感性不能替代可辨识性，搜索收敛也不能替代物理验证。

Liu等[2]提出了数据—模型—MCMC—敏感性—多目标优化的棉花灌溉分析框架，为本文的组织提供参照。本文不移用其棉田参数或节水率，也不将其土壤水分阈值控制与本研究固定日期上的灌水量控制混同。针对本项目曾出现的300—350 mm附近高产平台，重点需要回答：水量从何而来、何时发生胁迫，以及改变求解器或覆膜结构能否改变这一结论。

本研究的目的为：（1）复核四年滴灌玉米两阶段校准、过程拟合和参数边界证据；（2）在共同参数范围下分析六个输出的年度敏感性及其稳定性；（3）以双目标与单目标对照解释减灌幅度，并通过储水账、根深、覆膜和降水诊断界定可用结论。研究贡献在于将优化前沿与完整水量来源联系，而非将多个已有算法串联本身作为新算法。

## 2 材料与方法

## 2.1 总体框架与研究范围

研究按“来源分级—分阶段校准复核—公共范围敏感性—固定窗口优化—候选回代—机制诊断”展开（图1）。2019—2022年为同一试验区的四个年度滴灌情景，不能当作四个独立地块。项目申报书提出的不同灌溉方式比较在本稿中收敛为资料较完整的滴灌玉米分析；尚未完成的喷灌对照、遥感动态同化和联合稳健优化不列为已实现方法。

区分三个证据层次：四年历史主分析采用原两阶段冻结参数；四年根深1 m对照仅改变结构、未重新校准；2021年根深1 m与三个覆膜系数采用各自条件重校准的短链试验。上述结果分表呈现，不混合计算年度均值或统一节水率。

![Figure 1](../11_English_figures_tables_and_interpretations/figures/Figure1_three_column_EN.png)

Figure 1. Overall framework. Three patterned columns connect sources, staged calibration and decision analysis. Historical four-year analyses and later structural/forcing diagnostics remain separate evidence levels; completing a workflow does not certify MCMC convergence.

## 2.2 试验区、资料与来源口径

资料来自石羊河试验站的覆膜玉米研究，试验区位于甘肃武威，约37°52′N、102°52′E，海拔约1581 m[1]。论文报道地下水埋深约40—50 m；因此本研究不以浅地下水补给解释高产低灌水。原试验土壤性质的观测剖面约1 m，不能把更深层模型外推当作实测土壤组成。图2展示各年实际进入模型日历的气象驱动，参考蒸散ETo与作物实际蒸散ET严格区分[14]。

四年实际灌水合计分别为445.27、559.76、633.47、404.84 mm，事件数为8、8、7、5；发表文献中2021年633.46 mm与输入逐次合计相差0.01 mm，保留这一舍入差异。产量目标按项目的13%含水率口径为16.55、17.29、15.86、14.08 t ha⁻¹。四年田间LAI换算CC共有48对（12、13、11、12），地上干生物量共有37对（9、10、8、10），后者含论文图数字化近似值；二者用于校准，不属于独立验证（表1）。

原始气象与NDVI/遥感文件、ETo审计序列、初始含水量、灌水日程和论文原件均在归档包中分别保存。遥感CCquad按原文件百分数转比例，但2019—2021年文件带BI标签，2022年标签不完整，因此不作为DI独立验证或动态同化数据。GEE驱动的产品、ROI及日期时区尚缺完整导出元数据。论文明确报告DI季节土壤蒸发为76、79、78、81 mm；ET观测汇总为661.45、637.03、626.81、584.11 mm[1]。这些汇总与模型逐日输出分列，不能将论文另一章的WHCNS模拟量改称观测。

Table 1. Study data and annual DI observations.

![Figure 2](../11_English_figures_tables_and_interpretations/figures/Figure10_environment_EN.png)

Figure 2. Environmental drivers within the actual model calendars in 2019–2022. Precipitation and reference evapotranspiration retain their input values. ETo is an atmospheric reference demand, not actual crop ET; calendar differences are documented in the source tables.

## 2.3 模型过程、结构设定与水量账

采用项目修订的AquaCrop-OSPy实现，复现环境固定为AquaCrop-OSPy 3.1.0及归档的Python依赖。冠层发育决定潜在蒸腾，水分胁迫作用于冠层、气孔及衰老；分时期有效WP将归一化蒸腾转换为生物量，再由调整收获指数得到干籽粒产量[3,4]。输出统一为Y13=Ydry/0.87。前、后期WP的切换沿用各年度源码中的日期，不将修改后的分段实现误写成未经修改的默认AquaCrop。

四年历史设定为MulchPct=75%、fMulch=0、Zmin=0.30 m、Zmax=2.30 m；其中fMulch=0关闭额外覆膜抑制结构，仅作为历史复现基线，不能解释为75%塑料地膜的实测物理系数。模型覆膜关系为Es,mul=Es,pot×(1−fMulch×MulchPct/100)。2021年的fMulch=0.50、0.75、0.85试验均采用Zmax=1.00 m并分别重拟合；覆盖率不随优化改变。

对整个模拟剖面同时记录初末储水、降水、实际执行灌水、ET、径流、排水、毛管上升与外部入流。采用ΔS=P+I+CR+GWin−ET−R−D−TD，储水包含土壤和地表积水（若存在）。年度三线图采用入流、出流与ΔS，绝对季末水量另表提供。剖面总储水不等于根区可利用水，1 m与全剖面的变化在诊断中分列。

## 2.4 两阶段MCMC、拟合与边界诊断

阶段一校准CCx、CGC_CD、CDC_CD、SenescenceCD、Kcb，阶段二在其交接点条件下校准WP_early、WP_late、HI0。似然中的数据源、误差尺度和先验由原年度配置及源码给出；生物量的误差含数字化与相对误差假设，不冒充已知重复观测标准差。采样使用emcee ensemble方法[5]。原正式记录每组32个walkers、2000步，每年阶段一4个ensemble、阶段二1个。原始检查点及burn-in和保留段记录全部保存。

以原始tau、R-hat及ESS记录评估采样局限，保留行数不作为有效独立样本量，walkers不作为独立链。阶段一与条件阶段二的样本不拼接成所谓八维联合后验。两阶段保留样本的算术中心仅作为确定性下游运行点。2021条件重拟合每阶段4个ensemble、每组10个walkers、500步，作为先导诊断，不作充分收敛声明。

CC和生物量采用R²cal=1−Σ(sim−obs)²/Σ(obs−meanobs)²、RMSE和样本数评价；年产量每年仅一个配对，不计算单年产量R²。四年生物量汇总回归以观测为X、模拟为Y，另报告OLS R²和Pearson r，不与1:1预测误差指标混称。边界邻近集中定义为先验支持宽度上下各1%的样本比例，并与经验2.5%—97.5%分位区间共同展示。

Table 2. Parameter roles and common Sobol input supports.

## 2.5 公共输入空间下的Sobol分析

八参数采用四年相同的独立均匀物理范围（表2），而非从相关MCMC样本各列独立抽样后仍声称保留联合后验。计算一阶Si与总效应STi，定义分别为Var[E(Y|Xi)]/Var(Y)和E[Var(Y|X−i)]/Var(Y)[6,7]。输出包括Y13、生物量、Tr、Es、ET和最大CC。

样本量由N=128、256递增至512，采用三个独立scramble（101、202、303）。无二阶矩阵时每个设计包含N(D+2)=5120次模型计算；四年N512主分析共61440次。每种子512次bootstrap提供数值估计区间。年度均值先平均三个scramble，四年均值再按1/4等权；比较年度排序相关与指数范围。

R02合并图保留原R02_Sobol_Yield_CI的S1/ST含义。本次从完整A/AB/B响应块出发，逐scramble独立重采样512次，构造三scramble均值的近似95%数值区间；未新增作物模型计算。灰线另表示年际极差。该均值是四个固定年度的描述摘要，不是把气候年份作为随机输入重新计算的总体Sobol指数。ST不强制加和为1。

## 2.6 灌溉优化、候选选择与单目标核验

优化变量为四个固定日期窗口的灌水量x=(W1,W2,W3,W4)，窗口内保持原日期及分配权重，目标为同时最大化Y13、最小化实际执行季节灌水I。正式搜索满足Y13≥0.95Yobs且I≤IDI，未把0.95解释为95%概率。NSGA-III与NSGA-II均为100个体×100代、5个种子（31、73、109、151、199），四年合计400000次评估[8–10]。中心点主候选按NSGA-III并集内最低灌水规则选择，不称几何膝点。

原模型基准灌溉管理上限用于完整执行原日程，不是校准参数。原优化没有额外施加原最大单次灌水设备约束或季末储水底线；实际执行量、取消量与计划量分别检查。为补足原高产门槛图未显示的低水量段，另进行三种子×80个体×60代的全范围搜索，四年合计57600次，移除产量门槛但保留季节上限。图中虚线仅连接有限搜索的非支配解，不代表一条固定日程的连续剂量响应或数学全局最优。

最后将问题改写为对每个给定产量门槛q求min I(x)，约束Y13(x)≥q及相同上限。比较实数GA、单目标NSGA-II、广义模拟退火和差分进化[8,10–12]。四年历史设定和2021三覆膜条件设定共七情景；每个非平凡门槛、算法、种子分配384次目标查询，95%观测门槛另给同等384次追加预算。只允许各方法自己的档案作热启动。逐门槛独立结果、追加结果和跨门槛档案最小值分列；旧NSGA-III为预算不等的外部参照，不据此排名。

## 2.7 结构、降水与水量来源诊断

2021年针对fMulch=0.50、0.75、0.85各自进行两阶段500步试验，再以冻结条件拟合参数进行三种子×100个体×100代NSGA-III。累计记录120000个MCMC状态及90000次优化评估。fMulch不以拟合400 mm灌水结论为目标；用CC、生物量、产量、Es、ET及储水共同评价。原四年根深1 m的冻结参数试验另存档，不与条件重校准混称。

将GEE降水与论文日降水图的数字化近似在相同日期窗口内比较，检查大雨事件、月累计和日期偏移。图轴断裂及像素读取误差保留。论文表5-13的降水为WHCNS水量平衡输入，并非原始逐日雨量站记录，故不作为无误差真值。224次固定参数降水替换用于判断原候选与2021平台是否对降水来源敏感；未借此重新优化。

主解释采用同一初值、同一降水下的基准—候选差额账：Ibase−Iopt=(ETbase−ETopt)+(Lbase−Lopt)+(Send,base−Send,opt)，其中L为径流、深层排水等净输出，并计入必要的地表储水与外部入流调整。所有完整账在源表列示；数值闭合只验证内部守恒，不能证明土壤性质或作物耗水过程正确。

## 3 结果

## 3.1 生长过程拟合与采样限制

四年CC均复现了主要冠层上升与高覆盖期，但2022年的拟合误差较大（图3）。CC的R²cal为0.9306—0.9932、RMSE为0.0316—0.0596；生物量R²cal为0.9685—0.9966、RMSE为0.5562—1.2520 t ha⁻¹（图4、表3）。中心参数的籽粒产量偏差依次为+0.92%、−2.81%、−4.18%、−0.02%。这些是样本内拟合，不宜写成独立验证精度。

长链诊断并不与拟合指标同等乐观。阶段一的2000步仅约为最大tau的25.4—31.5倍，低于50tau经验参考；部分R-hat与ESS未通过原严格标准。阶段二每年仅一个ensemble，即使某些tau长度参考通过，也不足以认证独立链间一致性。因此后续曲线应表述为“保留样本中心条件下的确定性模拟”，而非已经充分采样的联合后验预测。

Table 3. Four-year calibration performance at frozen centers.

![Figure 3](../11_English_figures_tables_and_interpretations/figures/F02_CC_trajectories_EN.png)

Figure 3. Four-year canopy-cover calibration. Lines show deterministic trajectories at frozen phase-specific centers; symbols are field-LAI-derived CC used in calibration. Annual sample sizes are 12, 13, 11 and 12. Values are fractions. These are in-sample fits, not posterior predictive bands or independent validation.

![Figure 4](../11_English_figures_tables_and_interpretations/figures/F05_Biomass_pairs_EN.png)

Figure 4. Observed–simulated aboveground dry-biomass pairs for four years (n=9, 10, 8 and 10). The 1:1 relation and calibration error statistics assess agreement. Published-figure digitization and assumed observation uncertainty are retained; high correlation alone does not establish unbiased prediction.

## 3.2 参数边界、年度水量与四年回归

图5保留了八参数经验分位区间及各自支持域。2019和2020年CCx在上界1%邻近带中的质量约为22.14%和23.06%；2020和2021年WP_early在下界邻近带中的质量约为11.43%和23.65%。因此只能说样本没有越出支持域，不能声称不存在“撞墙”或参数完全可辨识。生理参数年际中心的变化也可能包含数据误差与参数补偿，不能直接当作真实年际生理漂移。

年度水量三线图满足入流减出流等于储水变化（图6）。2021年基准全剖面储水由535.7增至705.7 mm，增储约170.0 mm；这不等于作物当季需要额外消耗170 mm，而可能使后续减灌方案通过少增储甚至耗储仍维持蒸腾。四年37个生物量配对的汇总OLS相关度较高（图7），但相关性与1:1误差分别报告；图中的年内重复日期不用于独立样本显著性检验。

![Figure 5](../11_English_figures_tables_and_interpretations/figures/F07_parameter_intervals_EN.png)

Figure 5. Retained-sample empirical intervals for eight parameters, with annual supports. Parameters close to support boundaries remain visible. Intervals are phase-specific empirical quantiles of correlated samples, not a certified eight-dimensional joint posterior. Boundary-neighborhood mass is quantified separately in the source table.

![Figure 6](../11_English_figures_tables_and_interpretations/figures/F09_annual_water_budget_EN.png)

Figure 6. Annual baseline inflow, outflow and storage change. Inflow includes actual irrigation and rainfall plus other modeled inputs if present; outflow includes ET and losses. Storage is plotted as final minus initial water, not the absolute terminal stock. Connecting four years is descriptive and does not constitute a trend test.

![Figure 7](../11_English_figures_tables_and_interpretations/Final_revision/figures/F13_Pooled_biomass_regression_EN.png)

Figure 7. Pooled four-year biomass regression using all 37 calibration pairs. Observed biomass is X and simulated biomass is Y. The solid line is OLS and the dashed line is 1:1; OLS R² and Pearson r are shown. Dates are repeated within years, and no independent-observation significance test is inferred.

## 3.3 敏感性层级与年度稳定性

图8的统一色标显示，不同输出的主导参数并不相同：产量以晚期WP和HI0为主，生物量以晚期WP、早期WP和Kcb为主，ET以Kcb为主，最大冠层覆盖以CCx为主。产量、总生物量、ET和最大CC的八参数年度均值排序在四年间完全一致，配对Spearmanρ均为1.00；这仅指这些固定年度均值的描述排序。

产量ST的四年均值约为晚期WP 0.396、HI0 0.206、早期WP 0.164、Kcb 0.145（图9、表4）。晚期WP年度ST约0.353—0.426，说明排序稳定不等于幅度不变。2022年早期WP与Kcb接近并列，逐scramble排名会互换，不能用四年均值消除这一数值不确定性。原24项输出×年份筛查中23项通过，未通过项如实保留。

Table 4. Descriptive yield sensitivity across four fixed years.

![Figure 8](../11_English_figures_tables_and_interpretations/figures/R01_Sobol_four_outputs_2x2_EN.png)

Figure 8. Four-year total-effect Sobol indices for yield, biomass, seasonal ET and maximum canopy cover. Cells average three N=512 scrambles per year under the same eight independent uniform input ranges. A common scale supports comparison. Tr and Es results are supplied separately; ST is not normalized to sum to one.

![Figure 9](../11_English_figures_tables_and_interpretations/Final_revision/figures/R02_Sobol_Yield_CI_Four_years_and_mean_EN.png)

Figure 9. Four-year yield S1 and ST. Colored symbols average three N=512 scrambles. Error bars are approximate 95% numerical bootstrap intervals for that mean, using 512 independent complete-block resamples within each scramble. Diamonds are equal-weight four-year means; gray segments are across-year ranges, not confidence intervals. These do not represent posterior or field predictive uncertainty.

## 3.4 四年前沿与减灌水候选

图10将全范围补充搜索整理为四年2×2前沿，零灌溉、低灌溉及平台段同时显示，红点的四元组给出固定窗口水量，完整未取整值见源表。零灌溉模拟产量约为9.071、6.184、6.140、5.850 t ha⁻¹，均低于DI基准；这与原图只截取95%门槛以上的高产局部不同。零灌溉并非无水条件，仍包含各年的初始水和降水，也无零灌溉田间验证。

正式有门槛实验的四年主候选灌水量为218.36、312.42、267.30、260.78 mm，较实际DI减少50.96%、44.19%、57.80%、35.58%（表5）。候选产量贴近95%观测门槛，因此包含约5%的观测产量下降，不能写成“完全不减产”。NSGA-II/III同预算结果相近，现有证据不支持NSGA-III显著优越。2020年主候选最大单次水量约179.9 mm，超出原实测最大单次，提示原约束尚不能保证设施可实施。

![Figure 10](../11_English_figures_tables_and_interpretations/Final_revision/figures/R03_Pareto_four_years_annotated_EN.png)

Figure 10. Full-range NSGA-III best-found fronts: blue dashed envelopes, red evaluated controls and rounded (W1, W2, W3, W4) allocations in mm. Stars are DI model baselines. The 95% yield line is a reference only. These supplemental searches total 57,600 evaluations, separate from the formal gated experiment; historical Zmax=2.30 m and fMulch=0 apply. Exact controls are archived. Lines do not prove global optimality or field validity.

Table 5. Historical gated NSGA-III candidates and water-source differences.

## 3.5 减灌水量主要对应储水差

图11对各年减灌水差额进行分解。四年ET仅下降约33.33、15.25、8.63、24.25 mm，即5.22%、2.50%、1.43%、4.06%；季末储水差分别为190.52、230.75、356.71、119.81 mm。储水项解释的减灌比例约为83.96%、93.29%、97.42%、83.17%，明显大于ET项。

2021年的366.17 mm减灌水量由8.63 mm较低ET、356.71 mm较低季末储水及约0.84 mm其他损失差构成。基准增储约170.0 mm，候选相对初值耗储约186.7 mm；不能把两者之和全部称为额外根区“透支”。对既有点施加季末剖面水不低于DI基准的事后筛选，四年减灌比例降至约8.75%、0.56%、0.23%、7.01%，但这些是筛查点，不是新增约束下重新求得的最优值。

![Figure 11](../11_English_figures_tables_and_interpretations/figures/S07_Irrigation_reduction_decomposition_EN.png)

Figure 11. Partition of irrigation reduction between the historical DI baseline and selected candidate. ET, terminal-storage and other-loss differences are separated using identical forcing and initial water. A lower terminal stock is not equivalent to reduced consumptive use; part of the difference reflects avoided baseline storage gain.

## 3.6 根深、覆膜与降水补充试验

将最大根深限制为1 m能明显改变零灌溉响应，但不能据此认定原前沿只由深根误差造成。2021年三个覆膜条件重校准的DI产量分别为15.170、15.444、15.487 t ha⁻¹，Es约57.35、49.90、45.71 mm，ET约618.90、590.37、600.10 mm（图12、表6）。不同输出并非同时随fMulch单调改善；这些Es均低于论文2021年的78 mm汇总，必须保留蒸发分量的拟合矛盾。

三个覆膜情景的NSGA-III搜索在95%观测门槛处分别找到约319.11、282.72、287.53 mm方案，但没有找到满足15.86 t ha⁻¹观测全产量的方案。固定参数、拟合参数变化与短链边界补偿共同影响曲线，不能把差值当作仅由地膜系数导致的净物理效应，更不能选择一个系数强行得到400 mm。水分胁迫、冠层和0—1 m储水时序已全部归档。

相同论文DI日期窗口内，GEE降水总量为184.37、113.46、143.36、151.71 mm，论文日图近似重建为156.59、98.48、147.02、170.36 mm（图13）。总量接近不代表逐日事件一致，尤其不能忽略断轴暴雨。固定参数替换表明降水差异会移动产量和水量账，但没有消除2021年350 mm附近的平台现象。由于仍缺原始日雨量与同期含水量序列，本项只构成驱动敏感性检验。

Table 6. Separately refitted 2021 mulch scenarios at 1 m maximum root depth.

![Figure 12](../08_2021_mulch_conditional_calibration_and_optimization/figures/T01_Yield_irrigation_comparison.png)

Figure 12. 2021 irrigation–yield responses under separately refitted fMulch=0.50, 0.75 and 0.85 settings, each with maximum root depth 1 m and 75% cover. Fixed-schedule proportional responses and optimized envelopes have different meanings. These are short-chain conditional pilots, not independently validated physical factor estimates.

![Figure 13](../09_Rainfall_and_data_provenance_audit/figures/P02_Cumulative_precipitation_4years_EN.png)

Figure 13. Cumulative precipitation from the supplied GEE series and approximate digitization of the thesis daily figure. Matched calendar windows, broken axes and digitization limitations are retained. The graph reconstruction and WHCNS balance-input total are not raw gauge truth; original daily gauge records remain unavailable.

## 3.7 单目标多求解器核验

七情景四算法的验证累计253440次目标查询，精确缓存后实际优化模型调用217084次；508个唯一控制量经完整适配器回放，另有14个新鲜未加速模型核对。记录的最大输出差约2.84×10⁻¹³，支持计算实现的一致性。

在95%观测门槛处，新单目标跨方法档案的四年最低灌水约217.95、313.01、268.61、261.46 mm；2021三覆膜情景为316.48、280.15、286.86 mm（图14、表7）。相对各自历史NSGA-III参照差异为−2.63至+1.33 mm，且求解预算不同。这说明低灌水解并非只出现在NSGA-III；不能据此证明它们代表田间真实需水量，或据跨方法最小值认定某算法总体最优。

Table 7. New scalar-search archive minima at 95% observed yield.

![Figure 14](../10_Single_objective_multi_algorithm_validation/figures/S04_95pct_yield_algorithm_comparison_EN.png)

Figure 14. Minimum irrigation found at 95% of observed yield by GA, one-objective NSGA-II, generalized simulated annealing and differential evolution. Historical four-year and conditional 2021 mulch settings remain separate. Independent queries, equal-budget refinement and within-method archive summaries are distinguished in the tables. Historical NSGA-III references have unequal budgets and do not establish a fair performance ranking.

## 4 讨论

## 4.1 如何解释300—350 mm附近的高产平台

在本模型中，灌溉不是作物唯一水源。初始水与有效降水可以与适时灌水共同支撑蒸腾，因此一定幅度的减灌有物理可能；但“地膜减少蒸散”不足以解释原2021年366 mm的减灌水量。水量账显示ET仅下降约9 mm，主要变化是季末储水。原600余mm日程在模型中包含较大增储，候选则允许显著降低终值。只优化当季产量与灌水、不约束季末状态时，算法会利用这一可行空间。

因此合理的论文表述是：在既定初始条件、气象、参数中心和单季边界下，搜索得到保持95%观测产量的较低灌水方案；其主要代价为较低季末储水。不能写成武威覆膜玉米普遍只需300 mm、实际600 mm均属浪费，或优化已经证明保水措施可减少同等ET。高产平台首先是条件模型结果，应进一步用根区含水量、关键期胁迫和次季补水核验。

## 4.2 拟合、识别与不确定性不能相互替代

CC过程与生物量的高拟合度为模型提供约束，但不足以唯一识别WP、HI0、Kcb、根系及覆膜的组合效应。MCMC边界集中、阶段条件化和样本相关削弱了直接概率解释。参考框架[2]可借鉴其结构，但本研究必须保留自己的诊断结果；不能因为参考研究使用参数均值优化，就省略均值候选的条件不确定性。

后续宜以多套独立初始化长链、可解释的先验范围和观测误差模型检查识别性；在校准与检验之间保留独立水分过程资料。若要报告稳健达标概率，应建立合适的联合参数及天气情景，而不是把两阶段相关保留行简单拼接或把经验扰动比例当作田间概率。

## 4.3 覆膜系数不应成为修饰结论的旋钮

覆盖面积与地膜抑制蒸发效能是不同参数。固定75%覆盖并不证明fMulch=0或0.85为真值；论文其他模型中的地膜参数也不能直接移作AquaCrop的同名系数。fMulch剖面与条件重校准能帮助识别结构敏感性，但参数补偿可能使充分灌溉产量变化小而Es与零灌溉产量变化明显。

本试验中降低fMulch并没有使全部产量、水量分量和边界诊断同步改善，也没有自动将最小灌水提升到400 mm。选择依据应是独立Es/Tr、土壤水分、覆盖事实和多输出误差，而非结果是否更接近直觉。若多个结构均可拟合，应报告结构包络或开展多情景稳健搜索。

## 4.4 从可重复计算到可实施制度

多算法数值接近有助于排除单一求解器异常，但多个算法调用同一结构和边界条件，也会重复同一物理偏差。原问题至少仍缺三类实施条件：单次输水与入渗能力；关键生育期根区水分底线；季末或跨季储水要求。原DI终值不必就是唯一合理阈值，所以上述“终值不低于DI”筛查只是保守诊断，不宜直接规定为普遍农学约束。

建议首先取得2021年0—1 m分层含水量原始时间序列、日雨量与田间Es/Tr依据，统一采样时间及层厚后核对CC与胁迫。在此基础上定义可解释的储水容许亏缺、硬件事件上限和轮灌规则，再重做有约束优化，随后进行跨季或留一年检验。当前稿不把这些建议写成已经完成的田间试验。

## 5 结论

（1）四年DI玉米的样本内冠层、生物量和季节产量拟合总体较好，但边界邻近集中、阶段条件化和长链诊断限制仍存在，不能据此认证完整联合后验或独立预测精度。

（2）在共同独立物理范围下，主要输出的年度均值敏感性层级一致；晚期WP和HI0主导产量。年度均值与数值区间应共同报告，四年描述均值不代表所有气候或后验分布。

（3）原中心参数候选降低灌水35.6%—57.8%，但大部分差额来自季末储水差而非ET下降。2021年覆膜条件重拟合、降水替换与单目标多算法检验未消除低灌水现象，进一步说明应优先检验水量来源和实施约束，而非调整参数追求预设灌水量。当前结果为可追溯的模型探索证据，尚不是可持续田间灌水定额。

## 数据、代码、贡献与声明

数据与代码可用性：原件、四年检查点、模型版本、设计矩阵、完整响应、逐代与逐查询记录、英文图及源表按科研阶段归档，附SHA256和清单；原始日雨量与仪器全量数据未取得的部分明确列出。参考文献PDF仅包含项目组提供的原件，其他引用提供书目信息和DOI。

贡献说明（项目组核定稿）：吴雨臻负责统筹、模型分析与核心论证；李承昊负责数据处理、配对评价与图表；段璞负责文献、归档和校对；廖人宽教授为项目指导教师。论文正式作者、排序、通讯作者及贡献须由相关人员在投稿前确认。计算、归档与文字整理使用AI辅助，科学判断、引用核对和最终内容由项目组负责；AI不列为作者。

利益冲突与资助：项目编号X2026100190937；未虚构外部基金、已报销额、投稿录用或田间新增试验。正式利益冲突、资助表述与数据许可应由作者提交前核定。本文为基于现有记录的完整论文初稿，所有未开展的独立验证与稳健优化仅作为后续工作。

[1] 王尚今. 不同灌溉方式下覆膜玉米田水热氮传输及作物生长的观测与模拟[D]. 北京: 中国农业大学, 2023.

[2] Liu, Y., Wang, Y., Šimůnek, J., & Liao, R. (2025). An integrated data assimilation, crop modeling, and multi-objective optimization framework for improving cotton irrigation water use efficiency. Agricultural Water Management, 319, 109774. https://doi.org/10.1016/j.agwat.2025.109774

[3] Steduto, P., Hsiao, T. C., Raes, D., & Fereres, E. (2009). AquaCrop—The FAO crop model to simulate yield response to water: I. Concepts and underlying principles. Agronomy Journal, 101(3), 426–437. https://doi.org/10.2134/agronj2008.0139s

[4] Kelly, T. D., & Foster, T. (2021). AquaCrop-OSPy: Bridging the gap between research and practice in crop-water modeling. Agricultural Water Management, 254, 106976. https://doi.org/10.1016/j.agwat.2021.106976

[5] Foreman-Mackey, D., Hogg, D. W., Lang, D., & Goodman, J. (2013). emcee: The MCMC Hammer. Publications of the Astronomical Society of the Pacific, 125, 306–312. https://doi.org/10.1086/670067

[6] Sobol’, I. M. (2001). Global sensitivity indices for nonlinear mathematical models and their Monte Carlo estimates. Mathematics and Computers in Simulation, 55(1–3), 271–280. https://doi.org/10.1016/S0378-4754(00)00270-6

[7] Saltelli, A., Annoni, P., Azzini, I., Campolongo, F., Ratto, M., & Tarantola, S. (2010). Variance based sensitivity analysis of model output. Design and estimator for the total sensitivity index. Computer Physics Communications, 181(2), 259–270. https://doi.org/10.1016/j.cpc.2009.09.018

[8] Deb, K., Pratap, A., Agarwal, S., & Meyarivan, T. (2002). A fast and elitist multiobjective genetic algorithm: NSGA-II. IEEE Transactions on Evolutionary Computation, 6(2), 182–197. https://doi.org/10.1109/4235.996017

[9] Deb, K., & Jain, H. (2014). An evolutionary many-objective optimization algorithm using reference-point-based nondominated sorting approach, Part I: Solving problems with box constraints. IEEE Transactions on Evolutionary Computation, 18(4), 577–601. https://doi.org/10.1109/TEVC.2013.2281535

[10] Blank, J., & Deb, K. (2020). pymoo: Multi-objective optimization in Python. IEEE Access, 8, 89497–89509. https://doi.org/10.1109/ACCESS.2020.2990567

[11] Storn, R., & Price, K. (1997). Differential evolution—A simple and efficient heuristic for global optimization over continuous spaces. Journal of Global Optimization, 11, 341–359. https://doi.org/10.1023/A:1008202821328

[12] Xiang, Y., Gubian, S., Suomela, B., & Hoeng, J. (2013). Generalized simulated annealing for global optimization: The GenSA package. The R Journal, 5(1), 13–28. https://doi.org/10.32614/RJ-2013-002

[13] Grafton, R. Q., Williams, J., Perry, C. J., et al. (2018). The paradox of irrigation efficiency. Science, 361(6404), 748–750. https://doi.org/10.1126/science.aat9314

[14] Allen, R. G., Pereira, L. S., Raes, D., & Smith, M. (1998). Crop evapotranspiration: Guidelines for computing crop water requirements. FAO Irrigation and Drainage Paper 56. FAO, Rome.
