# Staged Bayesian calibration, sensitivity analysis and irrigation optimization for drip-irrigated maize: separating reduced irrigation from soil-water storage costs

Large modeled reductions in irrigation require a physical explanation before they can inform field management. We reconstructed staged Markov chain Monte Carlo (MCMC) calibration for drip-irrigated maize in Wuwei, China, during 2019–2022, evaluated Sobol sensitivity under common independent parameter ranges, and compared NSGA-III with NSGA-II for irrigation–yield trade-offs. Supplemental diagnostics included conditional recalibration for a 1 m maximum root depth and three mulch evaporation factors in 2021, rainfall substitution, and four single-objective optimizers. Within-calibration coefficients of determination were 0.9306–0.9932 for canopy cover and 0.9685–0.9966 for biomass. However, strict convergence was not established throughout the archived chains, and some parameter distributions accumulated near their bounds. Late-period water productivity and harvest index dominated yield sensitivity, with four-year descriptive mean total-effect indices of 0.396 and 0.206. Historical center-parameter candidates meeting 95% of observed yield reduced applied irrigation by 35.6–57.8%, whereas evapotranspiration decreased by only 1.4–5.2%. Differences in end-of-season profile storage accounted for approximately 83.2–97.4% of the irrigation reduction. Conditional mulch recalibration and alternative solvers retained low-irrigation solutions, indicating that the phenomenon cannot be attributed solely to one optimizer or mulch coefficient. The results quantify conditional, single-season trade-offs rather than validated sustainable irrigation requirements. Initial water, root-zone dynamics, terminal storage and event delivery limits should be verified before uncertainty-aware and multi-season management recommendations are developed.

## 1 Introduction

Irrigation decisions in arid regions involve both seasonal yield and the allocation of rainfall, initial soil water, applied irrigation and terminal storage. The mulched-maize experiments in Wuwei provide crop and water-process observations [1], but the irrigation applied in a field schedule is not necessarily the minimum crop requirement. Conversely, a low-irrigation model solution does not establish an equally large, implementable field saving. Applied-water reduction, consumptive-use reduction and changes in stored soil water must be distinguished [13].

AquaCrop links water availability to crop yield through canopy development, transpiration, biomass accumulation and harvest index [3,4]. MCMC characterizes parameter distributions conditional on model and observation assumptions [5], Sobol analysis partitions output variance under a declared input distribution [6,7], and evolutionary optimization identifies management trade-offs [8–10]. Each component requires its own assessment: good process fit does not demonstrate sampling convergence, sensitivity does not establish identifiability, and repeatable optimization does not establish physical validity.

The cotton irrigation framework of Liu et al. [2] motivates the sequence from data and crop modeling to MCMC, sensitivity analysis and multi-objective optimization. Its crop parameters, savings estimates and soil-moisture-threshold controls are not transferred to the present fixed-date, irrigation-amount problem. The high-yield plateau previously found around 300–350 mm particularly requires a process explanation: which water sources sustain transpiration, when stress develops, and whether alternative solvers or mulch settings change the result.

We therefore aimed to (1) audit four-year staged calibration, process fit and parameter boundaries; (2) assess annual sensitivity patterns for six outputs under common input ranges; and (3) interpret reduced irrigation using dual- and single-objective searches together with storage, root-depth, mulch and rainfall diagnostics. The contribution is the explicit linkage between optimized trade-offs and their water sources, rather than a new optimization algorithm.

## 2 Materials and methods

## 2.1 Overall framework and study scope

The workflow comprises source classification, staged-calibration audit, common-range sensitivity analysis, fixed-window optimization, candidate replay and mechanism diagnostics (Fig. 1). The years 2019–2022 represent four annual DI scenarios at one experimental location, not four independent fields. Although the project proposal considered different irrigation methods, the present analysis is restricted to the better documented DI maize data. Sprinkler comparisons, dynamic remote-sensing assimilation and joint robust optimization are not claimed as completed methods.

Three evidence levels are kept separate: the historical four-year analysis uses frozen staged parameters; the four-year 1 m root-depth experiment changes structure without recalibration; and the 2021 1 m scenarios use separate short-chain conditional recalibrations for three mulch factors. Their outputs are not pooled into a single annual mean or universal savings estimate.

![Figure 1](../11_English_figures_tables_and_interpretations/figures/Figure1_three_column_EN.png)

Figure 1. Overall framework. Three patterned columns connect sources, staged calibration and decision analysis. Historical four-year analyses and later structural/forcing diagnostics remain separate evidence levels; completing a workflow does not certify MCMC convergence.

## 2.2 Site, observations and data provenance

The data originate from mulched-maize experiments at the Shiyanghe station near Wuwei, Gansu, China (approximately 37°52′N, 102°52′E; 1581 m elevation) [1]. Reported groundwater depth was approximately 40–50 m, so shallow-groundwater supply is not invoked to explain high yields at low irrigation. Measured soil-property information extends to about 1 m; deeper modeled properties must be treated as extrapolations. Figure 2 presents the weather drivers within the actual model calendars. Reference evapotranspiration, ETo, is distinguished from actual crop evapotranspiration, ET [14].

Recorded irrigation totals were 445.27, 559.76, 633.47 and 404.84 mm, delivered in 8, 8, 7 and 5 events. The 0.01 mm difference between the 2021 event sum and the published 633.46 mm total is retained as rounding. Annual yield targets, on the project’s 13% grain-moisture basis, were 16.55, 17.29, 15.86 and 14.08 t ha⁻¹. There were 48 LAI-derived canopy-cover pairs (12, 13, 11 and 12 per year) and 37 aboveground dry-biomass pairs (9, 10, 8 and 10). Biomass includes approximate digitization from published graphics. These are calibration data rather than independent validation data (Table 1).

The archive separates original weather, NDVI/remote-sensing files, audited ETo, initial water, irrigation schedules and source papers. Remote-sensing CCquad percentages were converted to fractions, but BI labels in 2019–2021 and incomplete treatment metadata in 2022 preclude using these files as independent DI validation or dynamic assimilation. Product, ROI and timezone metadata for the GEE weather export remain incomplete. The source thesis explicitly reports DI seasonal soil evaporation of 76, 79, 78 and 81 mm and observational ET aggregates of 661.45, 637.03, 626.81 and 584.11 mm [1]. These aggregates are distinguished from model time series and WHCNS-simulated quantities reported elsewhere in the thesis.

Table 1. Study data and annual DI observations.

![Figure 2](../11_English_figures_tables_and_interpretations/figures/Figure10_environment_EN.png)

Figure 2. Environmental drivers within the actual model calendars in 2019–2022. Precipitation and reference evapotranspiration retain their input values. ETo is an atmospheric reference demand, not actual crop ET; calendar differences are documented in the source tables.

## 2.3 Model processes, structural settings and water accounting

The project-specific AquaCrop-OSPy implementation was replayed in an environment pinned to AquaCrop-OSPy 3.1.0 and archived Python dependencies. Canopy development controls potential transpiration; water stress affects expansion, stomatal behavior and senescence. Period-specific effective water productivity converts normalized transpiration into biomass, and adjusted harvest index determines dry grain yield [3,4]. Outputs follow Y13=Ydry/0.87. Early/late WP switching dates follow the annual source code; this modified implementation is not described as an unmodified default model.

Historical four-year settings were MulchPct=75%, fMulch=0, Zmin=0.30 m and Zmax=2.30 m. Here fMulch=0 disables additional mulch evaporation suppression and is retained only as a historical structural baseline, not a measured physical coefficient for plastic film. The model relation is Es,mul=Es,pot×(1−fMulch×MulchPct/100). The 2021 fMulch=0.50, 0.75 and 0.85 scenarios each use Zmax=1.00 m and their own conditional refit. Cover percentage is not optimized.

The full modeled profile ledger records initial and final storage, precipitation, actually delivered irrigation, ET, runoff, drainage, capillary rise and external inflow. The balance is ΔS=P+I+CR+GWin−ET−R−D−TD, including surface storage when present. The annual three-line plot uses inflow, outflow and storage change; absolute terminal storage is tabulated separately. Total profile storage is not synonymous with root-accessible water, so root-zone and full-profile changes are distinguished in the diagnostics.

## 2.4 Staged MCMC, fit assessment and boundary diagnostics

Stage 1 calibrates CCx, CGC_CD, CDC_CD, SenescenceCD and Kcb; stage 2 calibrates WP_early, WP_late and HI0 conditional on the stage-1 handoff. Annual code and configurations define likelihood data, error scales and priors. Biomass errors include digitization and assumed relative uncertainty, not known replicate-observation standard deviations. Sampling uses the emcee ensemble method [5]. Archived runs have 32 walkers and 2000 steps per ensemble, with four stage-1 ensembles and one stage-2 ensemble per year. Checkpoints and burn-in/retention records are preserved.

Archived autocorrelation, R-hat and effective-sample-size diagnostics are used to describe sampling limitations. Retained rows are not counted as independent information, and walkers are not treated as independent chains. Stage-1 and conditional stage-2 draws are not combined into an eight-dimensional joint posterior. Arithmetic centers of retained phase-specific samples serve only as deterministic downstream parameter settings. The 2021 conditional refits use four ensembles per stage, ten walkers and 500 steps; they are pilot diagnostics without a claim of adequate convergence.

Canopy cover and biomass are evaluated using R²cal=1−Σ(sim−obs)²/Σ(obs−meanobs)², RMSE and sample size. There is only one seasonal grain-yield pair per year, so annual yield R² is not reported. The pooled biomass regression uses observed values on X and simulated values on Y, with separate OLS R² and Pearson r. Boundary-neighborhood mass is defined within 1% of each prior-support width and displayed alongside empirical 2.5–97.5% intervals.

Table 2. Parameter roles and common Sobol input supports.

## 2.5 Sobol analysis under a common input space

The same independent uniform physical ranges are used for all eight parameters in all years (Table 2). Independent resampling of marginal MCMC columns is not mislabeled as preserving a joint posterior. First-order Si and total-effect STi are defined as Var[E(Y|Xi)]/Var(Y) and E[Var(Y|X−i)]/Var(Y), respectively [6,7]. Outputs are Y13, biomass, transpiration, soil evaporation, ET and maximum canopy cover.

Base sample sizes increase from N=128 and 256 to 512, with three independent scrambles (101, 202 and 303). Without a second-order matrix, each final design requires N(D+2)=5120 model evaluations, totaling 61,440 for the four-year N512 analysis. Numerical intervals use 512 bootstrap resamples per scramble. Three-scramble estimates are averaged within years before equal weighting across the four years. Annual rank agreement and variation in index magnitude are assessed separately.

The revised R02 figure preserves the S1/ST interpretation of the original R02_Sobol_Yield_CI. Complete A/AB/B response blocks are independently resampled within each scramble, using 512 replicates, to obtain approximate 95% numerical intervals for the three-scramble mean. This postprocessing requires no additional crop-model evaluations. Gray segments separately represent across-year ranges. The four-year mean describes four fixed scenarios; it is not a Sobol index recalculated for a pooled climate distribution. Total-effect indices are not forced to sum to one.

## 2.6 Irrigation optimization, candidate selection and scalar validation

Decision variables are irrigation amounts x=(W1,W2,W3,W4) in four fixed-date windows. Original event dates and within-window allocation weights are retained. The objectives maximize Y13 and minimize actually delivered seasonal irrigation I, subject to Y13≥0.95Yobs and I≤IDI. The factor 0.95 is a yield level, not a probability. NSGA-III and NSGA-II each use 100 individuals, 100 generations and five seeds (31, 73, 109, 151 and 199), totaling 400,000 evaluations across four years [8–10]. Main center-parameter candidates minimize irrigation within the pooled NSGA-III solutions; they are not geometric knees.

Baseline irrigation-manager caps ensure execution of recorded schedules and are not calibrated parameters. The original optimization does not additionally enforce the original maximum event as a hardware limit or impose a terminal-storage floor. Delivered, cancelled and planned amounts are tracked separately. To reveal the low-irrigation region omitted by the high-yield gate, supplemental full-range searches use three seeds, 80 individuals and 60 generations per year, totaling 57,600 evaluations. The yield gate is removed while the seasonal cap is retained. Lines join finite-search nondominated solutions; they are neither a fixed-schedule continuous dose response nor a proof of global optimality.

Finally, each prescribed yield threshold q defines the scalar problem min I(x), subject to Y13(x)≥q and the same irrigation cap. Real-coded GA, one-objective NSGA-II, generalized simulated annealing and differential evolution are compared [8,10–12]. Seven cases comprise the four historical years and three conditional 2021 mulch settings. Each nontrivial threshold/algorithm/seed receives 384 objective queries, with an equal additional 384-query budget at the 95%-observed threshold. Warm starts use only each method’s own archive. Independent-threshold, refinement and across-threshold archive results are kept separate. Historical NSGA-III outputs have an unequal external budget and are not used for a fair performance ranking.

## 2.7 Structural, rainfall and water-source diagnostics

For each 2021 fMulch value (0.50, 0.75 and 0.85), two-stage 500-step pilot fits are followed by NSGA-III using fixed conditional parameters, three seeds, 100 individuals and 100 generations. These experiments record 120,000 MCMC states and 90,000 optimization evaluations. No mulch value is selected to force a preferred 400 mm irrigation conclusion. Evaluation considers canopy, biomass, yield, Es, ET and storage jointly. The separate four-year frozen-parameter 1 m root-depth trial is not mislabeled as conditional recalibration.

GEE rainfall is compared with approximate digitization of the published daily rainfall figure over matched dates, including major storms, monthly sums and date-shift checks. Broken axes and pixel-reading limitations are retained. Rainfall in thesis Table 5-13 is an input to a WHCNS water-balance simulation, not an original daily gauge record, and is not treated as error-free truth. A total of 224 fixed-parameter rainfall substitutions tests the original candidates and 2021 plateau without reoptimizing them.

The main interpretation uses the baseline-minus-candidate ledger under the same initial state and rainfall: Ibase−Iopt=(ETbase−ETopt)+(Lbase−Lopt)+(Send,base−Send,opt), where L denotes net losses such as runoff and drainage, with surface storage and external inflows adjusted when necessary. Complete balances are tabulated. Numerical closure checks internal conservation; it does not establish the accuracy of soil properties or crop water use.

## 3 Results

## 3.1 Crop-process fit and sampling limitations

All years reproduce the principal canopy rise and high-cover period, although the 2022 canopy fit is weaker (Fig. 3). Canopy R²cal ranges from 0.9306 to 0.9932, with RMSE 0.0316–0.0596. Biomass R²cal ranges from 0.9685 to 0.9966, with RMSE 0.5562–1.2520 t ha⁻¹ (Fig. 4; Table 3). Center-parameter grain-yield biases are +0.92%, −2.81%, −4.18% and −0.02%. These are within-calibration results, not independent validation accuracy.

Sampling diagnostics are less favorable than the fit statistics. Stage-1 chains span only approximately 25.4–31.5 times their maximum estimated autocorrelation time, below a 50-tau heuristic; some archived R-hat and ESS criteria also fail. Stage 2 has only one ensemble per year, so satisfying a length heuristic in some cases does not establish independent-chain agreement. Downstream curves are therefore described as deterministic simulations conditional on retained-sample centers, not fully sampled joint-posterior predictions.

Table 3. Four-year calibration performance at frozen centers.

![Figure 3](../11_English_figures_tables_and_interpretations/figures/F02_CC_trajectories_EN.png)

Figure 3. Four-year canopy-cover calibration. Lines show deterministic trajectories at frozen phase-specific centers; symbols are field-LAI-derived CC used in calibration. Annual sample sizes are 12, 13, 11 and 12. Values are fractions. These are in-sample fits, not posterior predictive bands or independent validation.

![Figure 4](../11_English_figures_tables_and_interpretations/figures/F05_Biomass_pairs_EN.png)

Figure 4. Observed–simulated aboveground dry-biomass pairs for four years (n=9, 10, 8 and 10). The 1:1 relation and calibration error statistics assess agreement. Published-figure digitization and assumed observation uncertainty are retained; high correlation alone does not establish unbiased prediction.

## 3.2 Parameter boundaries, annual water balance and pooled regression

Figure 5 retains empirical intervals and parameter-specific supports. Upper-neighborhood mass for CCx is approximately 22.14% in 2019 and 23.06% in 2020; lower-neighborhood mass for early WP is approximately 11.43% in 2020 and 23.65% in 2021. Thus, remaining inside the prior support does not demonstrate the absence of boundary effects or complete parameter identifiability. Annual center shifts may reflect observation error and parameter compensation rather than true physiological change.

The annual three-line ledger satisfies inflow minus outflow equals storage change (Fig. 6). In 2021, baseline profile storage increases from 535.7 to 705.7 mm, a gain of approximately 170.0 mm. This is not additional seasonal crop consumption: alternative schedules can maintain transpiration while storing less water or drawing down storage. The pooled 37-pair biomass regression shows high association (Fig. 7), but OLS correlation and 1:1 prediction error remain distinct. Repeated within-year dates are not used for an independent-sample significance test.

![Figure 5](../11_English_figures_tables_and_interpretations/figures/F07_parameter_intervals_EN.png)

Figure 5. Retained-sample empirical intervals for eight parameters, with annual supports. Parameters close to support boundaries remain visible. Intervals are phase-specific empirical quantiles of correlated samples, not a certified eight-dimensional joint posterior. Boundary-neighborhood mass is quantified separately in the source table.

![Figure 6](../11_English_figures_tables_and_interpretations/figures/F09_annual_water_budget_EN.png)

Figure 6. Annual baseline inflow, outflow and storage change. Inflow includes actual irrigation and rainfall plus other modeled inputs if present; outflow includes ET and losses. Storage is plotted as final minus initial water, not the absolute terminal stock. Connecting four years is descriptive and does not constitute a trend test.

![Figure 7](../11_English_figures_tables_and_interpretations/Final_revision/figures/F13_Pooled_biomass_regression_EN.png)

Figure 7. Pooled four-year biomass regression using all 37 calibration pairs. Observed biomass is X and simulated biomass is Y. The solid line is OLS and the dashed line is 1:1; OLS R² and Pearson r are shown. Dates are repeated within years, and no independent-observation significance test is inferred.

## 3.3 Sensitivity hierarchy and annual stability

The common color scale in Fig. 8 reveals output-specific controls: late WP and HI0 dominate yield; late WP, early WP and Kcb dominate biomass; Kcb dominates ET; and CCx dominates maximum canopy cover. Annual-mean rankings of the eight parameters are identical across years for yield, biomass, ET and maximum cover, with pairwise Spearman rho=1.00. This describes the mean rankings of these four fixed annual scenarios only.

Four-year mean yield ST values are approximately 0.396 for late WP, 0.206 for HI0, 0.164 for early WP and 0.145 for Kcb (Fig. 9; Table 4). Late-WP ST varies from about 0.353 to 0.426, so rank stability does not imply invariant magnitude. Early WP and Kcb are nearly tied in 2022 and exchange ranks among scrambles; averaging across years does not remove this uncertainty. Of the 24 output-by-year numerical screening checks, 23 pass, and the remaining case is retained rather than suppressed.

Table 4. Descriptive yield sensitivity across four fixed years.

![Figure 8](../11_English_figures_tables_and_interpretations/figures/R01_Sobol_four_outputs_2x2_EN.png)

Figure 8. Four-year total-effect Sobol indices for yield, biomass, seasonal ET and maximum canopy cover. Cells average three N=512 scrambles per year under the same eight independent uniform input ranges. A common scale supports comparison. Tr and Es results are supplied separately; ST is not normalized to sum to one.

![Figure 9](../11_English_figures_tables_and_interpretations/Final_revision/figures/R02_Sobol_Yield_CI_Four_years_and_mean_EN.png)

Figure 9. Four-year yield S1 and ST. Colored symbols average three N=512 scrambles. Error bars are approximate 95% numerical bootstrap intervals for that mean, using 512 independent complete-block resamples within each scramble. Diamonds are equal-weight four-year means; gray segments are across-year ranges, not confidence intervals. These do not represent posterior or field predictive uncertainty.

## 3.4 Four-year fronts and reduced-irrigation candidates

Figure 10 presents the supplemental full-range fronts in a four-year 2×2 layout, including zero irrigation, the low-water region and the plateau. Four-tuples at selected red points report fixed-window allocations; exact unrounded values are supplied. Zero-irrigation yields are approximately 9.071, 6.184, 6.140 and 5.850 t ha⁻¹, all below DI baselines. The original high-yield panels displayed only the region above the 95% gate. Zero irrigation still includes initial soil water and rainfall and has no corresponding zero-irrigation field validation.

Main candidates from the formal gated experiment apply 218.36, 312.42, 267.30 and 260.78 mm, reducing recorded DI irrigation by 50.96%, 44.19%, 57.80% and 35.58% (Table 5). Their yields lie near 95% of observed yield, so they involve approximately 5% yield loss relative to observations and cannot be called loss-free. Equal-budget NSGA-II and NSGA-III outcomes are close, with no evidence of clear NSGA-III superiority. The 2020 candidate reaches approximately 179.9 mm in one event, above the recorded maximum event, demonstrating that original constraints do not establish delivery feasibility.

![Figure 10](../11_English_figures_tables_and_interpretations/Final_revision/figures/R03_Pareto_four_years_annotated_EN.png)

Figure 10. Full-range NSGA-III best-found fronts: blue dashed envelopes, red evaluated controls and rounded (W1, W2, W3, W4) allocations in mm. Stars are DI model baselines. The 95% yield line is a reference only. These supplemental searches total 57,600 evaluations, separate from the formal gated experiment; historical Zmax=2.30 m and fMulch=0 apply. Exact controls are archived. Lines do not prove global optimality or field validity.

Table 5. Historical gated NSGA-III candidates and water-source differences.

## 3.5 Storage differences explain most of the irrigation reduction

The reduction ledger (Fig. 11) shows ET decreases of only about 33.33, 15.25, 8.63 and 24.25 mm, equivalent to 5.22%, 2.50%, 1.43% and 4.06%. Terminal-storage differences are 190.52, 230.75, 356.71 and 119.81 mm. Storage accounts for approximately 83.96%, 93.29%, 97.42% and 83.17% of the irrigation reduction, substantially exceeding the ET contribution.

The 2021 irrigation reduction of 366.17 mm comprises 8.63 mm lower ET, 356.71 mm lower terminal storage and approximately 0.84 mm in other-loss differences. Baseline storage increases by about 170.0 mm, whereas the candidate draws down storage by about 186.7 mm from the common initial condition. Their sum should not all be labeled additional root-zone depletion. Post-filtering existing solutions to require terminal profile storage no lower than the DI baseline reduces the observed irrigation-reduction percentages to about 8.75%, 0.56%, 0.23% and 7.01%. These are screened points, not optima from a new constrained search.

![Figure 11](../11_English_figures_tables_and_interpretations/figures/S07_Irrigation_reduction_decomposition_EN.png)

Figure 11. Partition of irrigation reduction between the historical DI baseline and selected candidate. ET, terminal-storage and other-loss differences are separated using identical forcing and initial water. A lower terminal stock is not equivalent to reduced consumptive use; part of the difference reflects avoided baseline storage gain.

## 3.6 Root-depth, mulch and rainfall experiments

Restricting maximum root depth to 1 m changes zero-irrigation responses, but does not establish excessive rooting depth as the sole cause of the original front. Conditional 2021 DI yields for the three mulch settings are 15.170, 15.444 and 15.487 t ha⁻¹; Es is approximately 57.35, 49.90 and 45.71 mm; and ET is approximately 618.90, 590.37 and 600.10 mm (Fig. 12; Table 6). All outputs do not improve monotonically with fMulch. These Es values are below the thesis-reported 78 mm for 2021, and this component-level discrepancy must be retained.

The three NSGA-III searches find approximately 319.11, 282.72 and 287.53 mm at 95% of observed yield, but none finds the full observed 15.86 t ha⁻¹ target. Structural changes, refitted parameters and short-chain boundary compensation all affect the curves, so differences are not interpreted as a pure causal effect of mulch alone. A coefficient should not be chosen to force a desired 400 mm answer. Water-stress, canopy and 0–1 m storage time series are preserved in the archive.

Over matched thesis DI windows, GEE rainfall totals are 184.37, 113.46, 143.36 and 151.71 mm, compared with approximately digitized totals of 156.59, 98.48, 147.02 and 170.36 mm (Fig. 13). Similar seasonal sums do not establish agreement in daily events, particularly where broken-axis storms occur. Fixed-parameter substitutions shift outputs but do not remove the 2021 plateau around 350 mm. Without raw daily gauge and simultaneous soil-moisture observations, this is a forcing-sensitivity experiment rather than validation.

Table 6. Separately refitted 2021 mulch scenarios at 1 m maximum root depth.

![Figure 12](../08_2021_mulch_conditional_calibration_and_optimization/figures/T01_Yield_irrigation_comparison.png)

Figure 12. 2021 irrigation–yield responses under separately refitted fMulch=0.50, 0.75 and 0.85 settings, each with maximum root depth 1 m and 75% cover. Fixed-schedule proportional responses and optimized envelopes have different meanings. These are short-chain conditional pilots, not independently validated physical factor estimates.

![Figure 13](../09_Rainfall_and_data_provenance_audit/figures/P02_Cumulative_precipitation_4years_EN.png)

Figure 13. Cumulative precipitation from the supplied GEE series and approximate digitization of the thesis daily figure. Matched calendar windows, broken axes and digitization limitations are retained. The graph reconstruction and WHCNS balance-input total are not raw gauge truth; original daily gauge records remain unavailable.

## 3.7 Single-objective multi-solver verification

The seven-case, four-method comparison uses 253,440 objective queries and 217,084 actual optimization model calls after exact caching. A total of 508 unique controls is replayed with the full adapter, plus 14 fresh unaccelerated checks. The recorded maximum output discrepancy is approximately 2.84×10⁻¹³, supporting numerical implementation consistency.

At 95% of observed yield, minima across the new within-method archives are approximately 217.95, 313.01, 268.61 and 261.46 mm for the historical years, and 316.48, 280.15 and 286.86 mm for the three conditional 2021 mulch cases (Fig. 14; Table 7). Differences from their historical NSGA-III references range from −2.63 to +1.33 mm under unequal external budgets. Low-irrigation solutions are therefore not unique to NSGA-III. This does not establish field water requirements or justify declaring one algorithm universally best from cross-method minima.

Table 7. New scalar-search archive minima at 95% observed yield.

![Figure 14](../10_Single_objective_multi_algorithm_validation/figures/S04_95pct_yield_algorithm_comparison_EN.png)

Figure 14. Minimum irrigation found at 95% of observed yield by GA, one-objective NSGA-II, generalized simulated annealing and differential evolution. Historical four-year and conditional 2021 mulch settings remain separate. Independent queries, equal-budget refinement and within-method archive summaries are distinguished in the tables. Historical NSGA-III references have unequal budgets and do not establish a fair performance ranking.

## 4 Discussion

## 4.1 Interpreting a high-yield plateau near 300–350 mm

Irrigation is not the only crop water source in this model. Initial water and effective rainfall can combine with well-timed irrigation to sustain transpiration, making some reduction physically plausible. However, “mulch reduces evapotranspiration” cannot explain the original 2021 reduction of about 366 mm: ET falls by only about 9 mm. The major difference is terminal storage. The >600 mm schedule produces substantial modeled storage gain, while candidates are allowed to end with much less stored water. A single-season optimizer without a terminal-state constraint can exploit this feasible space.

The defensible interpretation is that, under fixed initial conditions, weather, center parameters and single-season boundaries, lower-irrigation solutions can reach 95% of observed yield at the cost of lower terminal storage. It is not evidence that mulched maize throughout Wuwei requires only 300 mm, that all irrigation above this is wasted, or that equivalent ET savings have been demonstrated. Root-zone moisture, critical-period stress and subsequent-season replenishment are needed to test the plateau.

## 4.2 Fit, identifiability and uncertainty are distinct

Strong canopy and biomass fits constrain the model but do not uniquely identify combined WP, HI0, Kcb, rooting and mulch effects. Boundary accumulation, conditional staging and sample dependence limit probabilistic interpretation. The structure of the reference framework [2] is useful, but its use of parameter means does not remove the need to disclose this project’s diagnostics or conditional uncertainty.

Further work should assess identifiability with independently initialized longer runs, interpretable supports and observation-error models, while reserving independent water-process observations for evaluation. Robust yield-attainment probabilities require an appropriate joint parameter and weather scenario model. Concatenating correlated phase-specific draws or interpreting empirical perturbation frequencies as field probabilities is insufficient.

## 4.3 The mulch factor should not be tuned to a preferred conclusion

Covered area and evaporation-suppression efficiency are separate quantities. A fixed 75% cover does not establish either fMulch=0 or 0.85 as the true value. A mulch parameter in another model cannot be transferred directly to AquaCrop by name. Parameter profiles and conditional recalibration diagnose structural sensitivity, but compensation can leave well-watered yield similar while altering Es and zero-irrigation yield.

Reducing fMulch did not simultaneously improve all yield, flux and sampling diagnostics, nor did it automatically move minimum irrigation to 400 mm. Selection should rely on independent Es/Tr, soil moisture, actual cover and multi-output errors rather than whether a curve agrees with intuition. If several structures remain compatible with observations, a structural envelope or multi-scenario robust search is preferable.

## 4.4 From repeatable computation to implementable schedules

Agreement among optimizers helps exclude an isolated solver anomaly, but all methods can reproduce the same structural bias when calling the same model and boundary conditions. Implementation still requires event delivery and infiltration limits, critical-stage root-zone water constraints, and terminal or multi-season storage requirements. The DI terminal state is not necessarily the uniquely correct agronomic threshold, so the “no lower than DI storage” filter remains a conservative diagnostic.

The next empirical priority is the original 2021 layer-wise 0–1 m moisture series, daily gauge rainfall and field Es/Tr evidence. Sampling times and layer thicknesses should be harmonized before evaluating canopy and stress responses. Interpretable allowable depletion, hardware event limits and rotation rules can then support new constrained searches, followed by multi-season or leave-one-year-out evaluation. These recommendations are not presented as field experiments already completed.

## 5 Conclusions

(1) Four-year DI maize canopy, biomass and seasonal yield show good within-calibration agreement, but boundary accumulation, conditional staging and sampling limitations preclude certifying a complete joint posterior or independent predictive accuracy.

(2) Common independent physical ranges yield consistent annual-mean sensitivity hierarchies, with late WP and HI0 dominating grain yield. Annual values and numerical intervals remain necessary; a four-year descriptive mean does not generalize to all climates or posterior distributions.

(3) Historical center-parameter candidates reduce applied irrigation by 35.6–57.8%, but most of the difference is terminal storage rather than lower ET. Conditional mulch refits, rainfall substitutions and multiple scalar solvers do not remove the 2021 low-irrigation pattern. Water sources and implementation constraints therefore deserve priority over tuning to a predetermined irrigation amount. The archive supports traceable model exploration, not a validated sustainable field quota.

## Data, code, contributions and declarations

Data and code availability: original files, four-year checkpoints, model versions, designs, complete responses, generation/query records, English figures and source tables are organized by research stage with SHA256 manifests. Missing raw gauge and full instrument records are explicitly identified. Full-text reference PDFs are limited to papers supplied by the project team; other references are supplied as bibliographic records and DOI links.

Draft project contributions: Yuzhen Wu coordinated the project, model analysis and central interpretation; Chenghao Li processed data, evaluated pairs and prepared figures; Pu Duan supported literature, archiving and proofreading. Professor Renkuan Liao advised the project. Formal authorship, order, correspondence and contributions require confirmation by the people concerned before submission. AI assisted computation, archiving and drafting; the project team remains responsible for scientific judgment, references and final content. AI is not an author.

Funding and declarations: project X2026100190937. No external grant, reimbursed expenditure, acceptance claim or additional field experiment is invented. Formal conflict-of-interest, funding and data-permission statements require author verification before submission. This is a full manuscript draft based on existing records; independent validation and robust optimization not yet undertaken are described only as future work.

[1] Wang, S. (2023). Observation and simulation of water, heat, and nitrogen transport and crop growth in maize fields under different irrigation methods. Master’s thesis, China Agricultural University, Beijing. [In Chinese.]

[2] Liu, Y., Wang, Y., Šimůnek, J., & Liao, R. (2025). An integrated data assimilation, crop modeling, and multi-objective optimization framework for improving cotton irrigation water use efficiency. Agricultural Water Management, 319, 109774. https://doi.org/10.1016/j.agwat.2025.109774

[3] Steduto, P., Hsiao, T. C., Raes, D., & Fereres, E. (2009). AquaCrop—The FAO crop model to simulate yield response to water: I. Concepts and underlying principles. Agronomy Journal, 101(3), 426–437. https://doi.org/10.2134/agronj2008.0139s

[4] Kelly, T. D., & Foster, T. (2021). AquaCrop-OSPy: Bridging the gap between research and practice in crop-water modeling. Agricultural Water Management, 254, 106976. https://doi.org/10.1016/j.agwat.2021.106976

[5] Foreman-Mackey, D., Hogg, D. W., Lang, D., & Goodman, J. (2013). emcee: The MCMC Hammer. Publications of the Astronomical Society of the Pacific, 125, 306–312. https://doi.org/10.1086/670067

[6] Sobol’, I. M. (2001). Global sensitivity indices for nonlinear mathematical models and their Monte Carlo estimates. Mathematics and Computers in Simulation, 55(1–3), 271–280. https://doi.org/10.1016/S0378-4754(00)00270-6

[7] Saltelli, A., Annoni, P., Azzini, I., Campolongo, F., Ratto, M., & Tarantola, S. (2010). Variance based sensitivity analysis of model output. Design and estimator for the total sensitivity index. Computer Physics Communications, 181(2), 259–270. https://doi.org/10.1016/j.cpc.2009.09.018

[8] Deb, K., Pratap, A., Agarwal, S., & Meyarivan, T. (2002). A fast and elitist multiobjective genetic algorithm: NSGA-II. IEEE Transactions on Evolutionary Computation, 6(2), 182–197. https://doi.org/10.1109/4235.996017

[9] Deb, K., & Jain, H. (2014). An evolutionary many-objective optimization algorithm using reference-point-based nondominated sorting approach, Part I: Solving problems with box constraints. IEEE Transactions on Evolutionary Computation, 18(4), 577–601. https://doi.org/10.1109/TEVC.2013.2281535

[10] Blank, J., & Deb, K. (2020). pymoo: Multi-objective optimization in Python. IEEE Access, 8, 89497–89509. https://doi.org/10.1109/ACCESS.2020.2990567

[11] Storn, R., & Price, K. (1997). Differential evolution—A simple and efficient heuristic for global optimization over continuous spaces. Journal of Global Optimization, 11, 341–359. https://doi.org/10.1023/A:1008202821328

[12] Xiang, Y., Gubian, S., Suomela, B., & Hoeng, J. (2013). Generalized simulated annealing for global optimization: The GenSA package. The R Journal, 5(1), 13–28. https://doi.org/10.32614/RJ-2013-002

[13] Grafton, R. Q., Williams, J., Perry, C. J., et al. (2018). The paradox of irrigation efficiency. Science, 361(6404), 748–750. https://doi.org/10.1126/science.aat9314

[14] Allen, R. G., Pereira, L. S., Raes, D., & Smith, M. (1998). Crop evapotranspiration: Guidelines for computing crop water requirements. FAO Irrigation and Drainage Paper 56. FAO, Rome.
