"""Assemble all scientific stages, preserving earlier raw archive bytes."""
from pathlib import Path
import os,csv,json,hashlib,shutil,zipfile
import pandas as pd
from docx import Document
from docx.shared import Pt
import legacy_renderer as L
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'delivery';PKG=OUT/'packages';OLD=Path('/workspace/urp_final_research_archive_20261021/delivery');NEW=Path('/workspace/urp_five_stage_multi_event_20261022/delivery')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def valid(p):return p.is_file() and '__pycache__' not in p.parts and 'lo_profile' not in p.parts and not p.name.endswith(('.pyc','.tmp','.nbc','.nbi')) and not p.name.startswith('.~lock.')
def linked(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():assert digest(dst)==digest(src);return
 os.link(src,dst)
def zipped(path,entries):
 path.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as z:
  for p,name in sorted(entries,key=lambda x:x[1]):z.write(p,name)
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 assert path.stat().st_size<100_000_000,(path.name,path.stat().st_size)
def tree(root,prefix):return [(p,prefix+'/'+str(p.relative_to(root))) for p in root.rglob('*') if valid(p)]
def record(p,stage,role,source,root):
 with zipfile.ZipFile(p) as z:count=len(z.infolist())
 return dict(Stage=stage,Role=role,File=str(p.relative_to(OUT)),Bytes=p.stat().st_size,Files=count,SHA256=digest(p),Extraction_root=root,Source=source)
def revision_note():
 d=Document();L.setup(d,'URP统一更新说明');L.para(d,'URP统一更新说明（2026年10月23日）',size=16,bold=True,indent=False)
 for h,t in [
 ('1 更新范围','中文和英文正文采用同一五期结果，均为15张英文图、10张三线表。同步更新摘要、决策变量、算法统计、主候选、五期总量、逐次日程、水量解释、讨论与结论；原始资料和既有链按原计算版本保留。'),
 ('2 五期与逐次灌水','苗期、拔节期、抽穗期、灌浆期、成熟期每期最多3个可选事件，联合优化15水量及15整数日期。全部阶段均开放，零量取消、同日合并；阶段合计与逐次量、模型总量一致。'),
 ('3 科学口径','四年主模型继续使用原参数均值、气象及初值，fMulch=0、Zmax=2.30 m。2021根深1 m和不同fMulch条件拟合、原四窗口单目标算法保持各自实验设定，未混成五期的新算法验证。原链R̂、ESS及均值稳定性分别表述。'),
 ('4 当前结果','四年代表方案209.83、306.50、264.50、257.47 mm；2021减灌368.97 mm中储水差356.85 mm、ET差11.46 mm。所有主文表格与逐图解析使用同一来源，单次水量和实施条件另表列明。'),
 ('5 中期与归档','项目编号、成员及导师沿用正式材料。报告按主要计算已完成填写，实际报销及导师/专家签字留空。当前文件以本版索引为入口，旧稿和旧四窗口阶段包放入history，保存完整研究过程。')]:L.head(d,h);L.para(d,t)
 d.save(ROOT/'documents/URP_Update_Notes_20261023.docx')
def main():
 qa=json.loads((ROOT/'analysis/DOCUMENT_AND_DATA_QA.json').read_text());assert qa['Status']=='PASS'
 OUT.mkdir(exist_ok=True);PKG.mkdir(exist_ok=True);rows=[]
 previous=pd.read_csv(OLD/'PACKAGE_INDEX.csv')
 for r in previous.itertuples():
  src=OLD/r.filename;assert digest(src)==r.sha256
  historical=r.filename.startswith(('00_','05_','11_','12_','13_','URP_Final_'))
  dst=PKG/('history' if historical else '')/r.filename;linked(src,dst)
  rows.append(record(dst,r.stage,'Historical_before_five_stage' if historical else 'Retained_source_or_supplement',str(src),'URP_Research_Archive'))
 print('Preserved all 29 earlier ZIPs byte-for-byte; active/supplemental and historical roles indexed',flush=True)
 for p in sorted(NEW.glob('*.zip')):
  dst=PKG/'05_Current_five_stage'/p.name;linked(p,dst);rows.append(record(dst,'05_Five_stage_optimization','Current_main_optimization',str(p),'URP_Five_Stage_Multi_Event'))
 for stage,source in [('15_Original_MCMC_diagnostics',Path('/workspace/urp_original_chain_diagnostic_20261022')),('16_2021_short_continuation',Path('/workspace/urp_2021_mcmc_30min_validation_20261022'))]:
  dest=PKG/(stage+'.zip');zipped(dest,tree(source,'URP_Research_Archive/stages/'+stage));rows.append(record(dest,stage,'Current_sampling_diagnostic',str(source),'URP_Research_Archive'));print('Packaged',stage,flush=True)
 # Current figure set and interpretations are a separate small stage package.
 entries=tree(ROOT/'figures','URP_Current_20261023/figures')+tree(ROOT/'tables','URP_Current_20261023/tables')
 for p in (ROOT/'documents').glob('*'):
  if valid(p) and ('Figure' in p.name or 'Figures' in p.name):entries.append((p,'URP_Current_20261023/documents/'+p.name))
 dest=PKG/'11_Current_English_figures_tables.zip';zipped(dest,entries);rows.append(record(dest,'11_Current_English_figures_tables','Current_figures_and_data','Current integrated project','URP_Current_20261023'))
 # A complete, relocatable manuscript-generation project (all inputs included).
 entries=[]
 for folder in ['code','documents','figures','tables','source','midterm']:entries+=tree(ROOT/folder,'URP_Current_20261023/'+folder)
 entries += [(ROOT/'README.md','URP_Current_20261023/README.md'),(ROOT/'requirements.txt','URP_Current_20261023/requirements.txt'),(ROOT/'analysis/DOCUMENT_AND_DATA_QA.json','URP_Current_20261023/analysis/DOCUMENT_AND_DATA_QA.json')]
 dest=PKG/'12_Current_CN_EN_manuscripts_and_reproduction.zip';zipped(dest,entries);rows.append(record(dest,'12_Current_CN_EN_manuscripts','Current_manuscript_project','Current integrated project','URP_Current_20261023'))
 entries=tree(ROOT/'midterm','URP_Current_20261023/midterm')
 entries += [(p,'URP_Current_20261023/documents/'+p.name) for p in (ROOT/'documents').glob('URP_Midterm_Report_Updated_20261023.*')]
 dest=PKG/'13_Current_project_midterm_report.zip';zipped(dest,entries);rows.append(record(dest,'13_Current_project_midterm_report','Current_administrative_report','Current integrated project','URP_Current_20261023'))
 # Standalone documents remain convenient to open without unpacking stage ZIPs.
 for p in (ROOT/'documents').iterdir():
  if valid(p):shutil.copy2(p,OUT/p.name)
 for p in (NEW).iterdir():
  if p.name.startswith('URP_Optimized_Every_Event_Schedule_') and p.suffix in ['.docx','.pdf']:shutil.copy2(p,OUT/p.name)
 shutil.copy2(ROOT/'tables/URP_All_Current_Data_20261023.xlsx',OUT/'URP_All_Current_Data_20261023.xlsx')
 shutil.copy2(ROOT/'analysis/DOCUMENT_AND_DATA_QA.json',OUT/'DOCUMENT_AND_DATA_QA.json')
 shutil.copy2(ROOT/'figures/Fig11_Five_stage_Pareto_fronts_EN.png',OUT/'Preview_Current_Four_year_Pareto_EN.png')
 quick=[(p,'URP_Current_Documents/'+p.name) for p in OUT.iterdir() if valid(p) and p.name!='README.md' and p.suffix in ['.docx','.pdf','.xlsx','.md']]
 quick.append((ROOT/'README.md','URP_Current_Documents/README.md'))
 zipped(OUT/'URP_Current_Papers_Midterm_and_Figures_20261023.zip',quick)
 pd.DataFrame(rows).to_csv(OUT/'PACKAGE_INDEX.csv',index=False,encoding='utf-8-sig')
 index_entries=[(ROOT/'README.md','URP_Current_20261023/README.md'),(OUT/'PACKAGE_INDEX.csv','URP_Current_20261023/PACKAGE_INDEX.csv'),(OUT/'DOCUMENT_AND_DATA_QA.json','URP_Current_20261023/DOCUMENT_AND_DATA_QA.json')]
 for n in ['Manuscript_figure_table_map_CN.csv','Manuscript_figure_table_map_EN.csv','Current_Figure_Interpretations.csv']:index_entries.append((ROOT/'tables'/n,'URP_Current_20261023/tables/'+n))
 dest=PKG/'00_Current_index_and_reproducibility.zip';zipped(dest,index_entries);rows.insert(0,record(dest,'00_Current_index','Current_index','Current integrated project','URP_Current_20261023'))
 pd.DataFrame(rows).to_csv(OUT/'PACKAGE_INDEX.csv',index=False,encoding='utf-8-sig')
 ncurrent=sum(r['Role']!='Historical_before_five_stage' for r in rows);nhist=len(rows)-ncurrent
 lines=['# URP 最新统一交付 · 2026-10-23','', '**[下载全部阶段总包（含所有原始资料、代码、链、结果及本次更新）](https://codeload.github.com/yuzhenwu920-afk/URP/zip/refs/heads/delivery/urp-all-stages-20261022)**','', '[论文、中期、图册与数据速取包](URP_Current_Papers_Midterm_and_Figures_20261023.zip)','', '[中文Word](URP_Manuscript_CN_Updated_20261023.docx) · [英文Word](URP_Manuscript_EN_Updated_20261023.docx) · [中期Word](URP_Midterm_Report_Updated_20261023.docx) · [数据Excel](URP_All_Current_Data_20261023.xlsx)','',f'当前/保留来源阶段包 {ncurrent} 个；旧版过程包 {nhist} 个，合计 {len(rows)} 个阶段ZIP。原有29个压缩包均按原字节保留；本次增加当前五期结果、原链诊断、短时续链及更新稿件。','', '中英文主稿各15组英文图、10张三线表；逐次日程42条正水量记录，含全部微量源值。中期主要计算已完成，实际报销和审核签字留空。当前结果固定于20f1616556f5aeb79329b7ead22faa28f9fcda6a的五期模型计算，本次整合无新增模型搜索。','', '05_Current_five_stage 内六包共同解压为URP_Five_Stage_Multi_Event。当前文稿工程、图表与中期解压到URP_Current_20261023。原来源阶段包沿用URP_Research_Archive；history请另放历史目录，保持其原有实验版本。索引ZIP内部清单不含自身哈希，自身校验见外层SHA256SUMS。','', '|阶段|用途|压缩包|MB|','|---|---|---|---:|']
 for r in rows:lines.append(f'|{r["Stage"]}|{r["Role"]}|[{Path(r["File"]).name}]({r["File"]})|{r["Bytes"]/1e6:.1f}|')
 (OUT/'README.md').write_text('\n'.join(lines)+'\n')
 aliases={'URP_Manuscript_CN.docx':'URP_Manuscript_CN_Updated_20261023.docx','URP_Manuscript_CN.pdf':'URP_Manuscript_CN_Updated_20261023.pdf','URP_Manuscript_EN.docx':'URP_Manuscript_EN_Updated_20261023.docx','URP_Manuscript_EN.pdf':'URP_Manuscript_EN_Updated_20261023.pdf','URP_midterm_report.docx':'URP_Midterm_Report_Updated_20261023.docx','URP_midterm_report.pdf':'URP_Midterm_Report_Updated_20261023.pdf'}
 for dst,src in aliases.items():shutil.copy2(OUT/src,OUT/dst)
 result=dict(Status='PASS',Stage_archives=len(rows),Current_or_retained_source_archives=ncurrent,Historical_archives=nhist,Previous_29_archives_preserved_with_identical_SHA256=True,New_model_runs=False,Package_bytes=sum(r['Bytes'] for r in rows),All_new_ZIPs_CRC='PASS',Main_figures=15,Main_three_line_tables=10,Query_rows=457596,Search_model_calls=455505)
 (OUT/'ARCHIVE_QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 files=[p for p in OUT.rglob('*') if valid(p) and p.name!='SHA256SUMS.txt'];(OUT/'SHA256SUMS.txt').write_text('\n'.join(f'{digest(p)}  {p.relative_to(OUT)}' for p in sorted(files))+'\n')
 print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
