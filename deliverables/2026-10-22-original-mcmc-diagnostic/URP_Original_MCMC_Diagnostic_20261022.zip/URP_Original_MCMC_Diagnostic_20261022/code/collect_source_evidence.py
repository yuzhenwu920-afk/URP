"""Extract verifiable code and observation evidence without running AquaCrop."""
from pathlib import Path
import ast,hashlib,json,shutil
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
ARCH=Path('/workspace/urp_final_research_archive_20261021')
evidence=[];coverage=[];handoffs=[]
for y in [2019,2020,2021,2022]:
    base=ARCH/'stages'/f'02_MCMC_{y}'/'OneClick_stage1_and_inputs'
    source=base/f'DI_{y}_MCMC_ONE_CLICK.py'
    if not source.exists():
        source=Path(f'/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/real_model/model_{y}/DI_{y}_MCMC_ONE_CLICK.py')
        base=source.parent
    dest=ROOT/'source'/str(y)/'original_code_and_inputs';dest.mkdir(parents=True,exist_ok=True)
    text=source.read_text(encoding='utf-8-sig');shutil.copyfile(source,dest/source.name)
    with np.load(ROOT/'source'/str(y)/'phase1/ensemble_1.npz') as z:c=json.loads(z['contract'].item())
    with np.load(ROOT/'source'/str(y)/'phase2/ensemble_1.npz') as z:c2=json.loads(z['contract'].item())
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    expected=c['files'].get(source.name)
    assert digest==expected, (y,digest,expected)
    code_lines=text.splitlines()
    for label,s in [
        ('initialization_cluster','random.normal(0,.06,dim)'),
        ('integer_senescence','c.SenescenceCD=int(round'),
        ('mulch_setting','f_mulch=0.'),
        ('phase1_likelihood','ll=-.5*np.sum(cc.Weight'),
        ('annual_aggregate_flux_likelihood',"s['Tr_mm']-TR_TARGET"),
        ('phase2_likelihood',"bio.Biomass_t_ha-bio.Observed_B_t_ha"),
        ('normal_prior',"if k in NORMAL_PRIORS: prior"),
        ('default_stretch_move','sampler=emcee.EnsembleSampler(walkers,dim,logp)'),
    ]:
        found=[(i+1,line.strip()) for i,line in enumerate(code_lines) if s in line]
        for line,excerpt in found:evidence.append(dict(Year=y,Item=label,Source=str((dest/source.name).relative_to(ROOT)),Line=line,Excerpt=excerpt,Source_SHA256=digest))
    inputs=base/'data/inputs'
    field=next(inputs.glob('*FIELD_CC*'));bio=next(inputs.glob('*BIOMASS*'))
    for p in [field,bio,base/'data/start.json']:
        if p.exists():shutil.copyfile(p,dest/p.name)
    f=pd.read_csv(field);f=f[f.Year.eq(y)&f.Irrigation.eq('DI')].copy();f.Date=pd.to_datetime(f.Date)
    b=pd.read_csv(bio)
    if 'Year' in b:b=b[b.Year.eq(y)]
    if 'Treatment' in b:b=b[b.Treatment.eq('DI')]
    if 'Included' in b:b=b[b.Included.astype(str).str.lower().eq('true')]
    b=b.copy();b.Date=pd.to_datetime(b.Date)
    # Date anchor taken from unchanged original model source CFG, via AST only.
    tree=ast.parse(text);cfg=None
    for n in ast.walk(tree):
        if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='CFG' for a in n.targets):
            try:cfg=ast.literal_eval(n.value)
            except (ValueError,TypeError):pass
    if cfg is None:
        # Complete embedded model source is a string constant; parse it separately.
        for n in ast.walk(tree):
            if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str) and 'CFG =' in n.value.value:
                for a in ast.walk(ast.parse(n.value.value)):
                    if isinstance(a,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CFG' for t in a.targets):
                        try:cfg=ast.literal_eval(a.value)
                        except (ValueError,TypeError):pass
    # Annual model calendar is a separately verified original output.
    cal=pd.read_csv(ARCH/'stages/11_English_figures_tables_and_interpretations/tables/Annual_model_calendar.csv')
    cr=cal[cal.Year.eq(y)].iloc[0]
    # Column name is explicit in the archived table; tolerate standard variants.
    plant_col=next(k for k in cal if k.lower() in ['plant','planting','planting_date','start','model_start','plant_date'])
    plant=pd.Timestamp(cr[plant_col])
    sen=c2['fixed']['SenescenceCD'];fdap=(f.Date-plant).dt.days
    coverage.append(dict(Year=y,Phase1_CC_pairs=len(f),Phase2_biomass_pairs=len(b),Annual_yield_targets=1,
        Annual_Tr_targets=1,Annual_Es_targets=1,CC_first_date=f.Date.min().date(),CC_last_date=f.Date.max().date(),
        Planting_date=plant.date(),Senescence_handoff_days=sen,
        CC_observations_after_handoff_senescence=int((fdap>=round(sen)).sum()),
        CC_assumed_sigma=c['sigmas'][0],Tr_assumed_sigma_mm=c['sigmas'][1],Es_assumed_sigma_mm=c['sigmas'][2],
        Yield_dry_assumed_sigma_t_ha=c['sigmas'][3],Biomass_sigma_min=b.Sigma_assumed.min(),Biomass_sigma_max=b.Sigma_assumed.max(),
        Field_CC_source='Thesis digitized LAI transformed to CC',Biomass_source='Thesis approximate digitization',
        Within_season_daily_Tr_or_Es_in_likelihood=False))
    raw=[]
    for e in range(1,5):
        with np.load(ROOT/'source'/str(y)/f'phase1/ensemble_{e}.npz') as z:raw.append(z['history'])
    raw=np.stack(raw);burn=c2['phase1_burn'];means=raw[:,burn:].mean((0,1,2))
    for k,mu in zip(c['names'],means):
        handoffs.append(dict(Year=y,Parameter=k,Recomputed_retained_mean=mu,Recorded_phase2_fixed=c2['fixed'][k],
            Absolute_difference=abs(mu-c2['fixed'][k]),Handoff_rule=c2['handoff']))
pd.DataFrame(evidence).to_csv(ROOT/'tables/Code_evidence.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(coverage).to_csv(ROOT/'tables/Observation_coverage.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(handoffs).to_csv(ROOT/'tables/Phase1_to_phase2_handoff.csv',index=False,encoding='utf-8-sig')
assert max(x['Absolute_difference'] for x in handoffs)<1e-12
print(pd.DataFrame(coverage).to_string(index=False))
print('Original source hashes and all 20 phase1 handoff coordinates verified.')
