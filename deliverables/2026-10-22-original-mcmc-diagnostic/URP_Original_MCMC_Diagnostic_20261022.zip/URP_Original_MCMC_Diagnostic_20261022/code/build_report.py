"""Chinese interpretation report, English figure captions, and a vector atlas."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import fitz
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parents[1]

def load(n):return pd.read_csv(ROOT/'tables'/f'{n}.csv')
def font(r,size=10.5,bold=False):
    r.font.name='Noto Serif CJK SC';r.font.size=Pt(size);r.bold=bold
    r._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC')
    return r
def para(d,s,size=10.5,bold=False,keep=False):
    p=d.add_paragraph();p.paragraph_format.space_after=Pt(6);p.paragraph_format.line_spacing=1.3;p.paragraph_format.keep_with_next=keep
    font(p.add_run(s),size,bold);return p
def head(d,s,level=1):
    p=d.add_paragraph(style=f'Heading {level}');p.paragraph_format.space_before=Pt(11);p.paragraph_format.space_after=Pt(7)
    font(p.add_run(s),14 if level==1 else 12,True);return p
def table(d,title,headers,rows,note=''):
    para(d,title,10,True,True);t=d.add_table(rows=1,cols=len(headers))
    for c,s in zip(t.rows[0].cells,headers):c.text=str(s)
    for row in rows:
        for c,s in zip(t.add_row().cells,row):c.text=str(s)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','bottom','left','right','insideH','insideV']:
        b=OxmlElement('w:'+side);b.set(qn('w:val'),'single' if side in ['top','bottom'] else 'nil');b.set(qn('w:sz'),'9');borders.append(b)
    t._tbl.tblPr.append(borders)
    for i,row in enumerate(t.rows):
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        if i==0:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        for c in row.cells:
            if i==0:
                bb=OxmlElement('w:tcBorders');b=OxmlElement('w:bottom');b.set(qn('w:val'),'single');b.set(qn('w:sz'),'5');bb.append(b);c._tc.get_or_add_tcPr().append(bb)
            for p in c.paragraphs:
                p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3)
                for r in p.runs:font(r,8.5,i==0)
    if note:para(d,note,9)
    return t
def figure(d,key,n,cn):
    p=d.add_paragraph();p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(ROOT/'figures'/f'{key}.png'),width=Cm(16.6))
    para(d,f'Figure {n}. '+CAP[key],9)
    para(d,'图解：'+cn,10)

CN={
'D01_Independent_ensemble_convergence_EN':'四年第一阶段均未达到严格阈值。这里的 ESS 是“每个固定 walker 编号跨四个独立 ensemble”的诊断组数值，并非四年样本的总 ESS；不能把 32 组 ESS 相加。各参数组中位 R̂ 也约为 1.032–1.068，问题并非只发生在一个极端 walker。',
'D02_Autocorrelation_length_and_acceptance_EN':'第一阶段的时间长度不足；第二阶段 2020/2021 也未达到 50τ 长度参考，而 2019/2022 达到这一参考仍不代表独立链验证通过。接受率不低，只说明提议经常被接受，不能保证链已充分探索分布。',
'D03_Phase1_four_year_trace_blocks_EN':'四组 ensemble 的均值轨迹有共同覆盖区，未见均值完全分离为几个相距很远的群。轨迹中仍有长时间起伏；平滑均值图不足以取代 R̂、ESS 和尾部诊断。阴影为原规则丢弃部分，未重新挑选窗口。',
'D04_Phase2_conditional_traces_EN':'三参数条件链总体仍有移动，但每年只有一个 ensemble，不能把淡色 walker 轨迹当成独立链。第二阶段承接第一阶段保留样本的算术均值，未传播第一阶段全部不确定性。',
'D05_Boundary_mass_four_years_EN':'撞墙必须按年份、参数讨论：2019/2020 的 CCx 上界附近堆积突出，2020/2021 的 WP_early 下界附近堆积突出，HI0 在 2020/2021 上界附近也有堆积。原值都在支持域内；邻界堆积不是代码把样本强制截成边界值的证据。',
'D06_Prior_to_sample_contraction_EN':'CDC_CD 的经验分布宽度接近真实先验宽度，显示现有证据对它提供的信息有限。CCx、CGC_CD 收缩较强，但收缩本身不证明后验正确，也不消除其混合问题。',
'D07_Late_season_prior_overlap_EN':'CDC_CD 保留了约 92%–97% 的先验标准差。每年衰老时间点之后仅有 1–2 个 CC 数据点，且 SenescenceCD 在模型中被四舍五入为整数日，后期参数的连续细调缺少充分观测分辨率。',
'D08_Phase_specific_correlation_matrices_EN':'相关性按阶段分别计算，没有伪造八参数联合后验。第一阶段相关矩阵条件数仅约 2.48–3.50，不能把四年第一阶段未收敛都归咎于极端强的线性参数相关。',
'D09_WP_HI_compensation_EN':'WP_late 增大与 HI0 减小可以部分抵消，使产量仍接近目标。2019 年此关系最明显。2021 年相关约 −0.463，属于可见补偿，不能夸大为完全不可辨识。',
'D10_Ensemble_location_and_time_drift_EN':'四组第一阶段均值最大跨度约为 0.204 个保留样本标准差；各组前后半段均值最大变化约为 0.187 个标准差。分布位置没有表现为巨大分离，但有限混合、尾部与 Monte Carlo 误差仍未满足严格条件。',
'D11_Autocorrelation_four_years_EN':'短间隔状态高度相关，因此保存了几十万行不等于有几十万个独立后验样本。增加 walkers、稀疏抽取或平滑轨迹都不能替代足够长的时间探索。',
'D12_Burnin_and_ensemble_functional_checks_EN':'简单丢掉前 1000 步反而提高了最差 R̂，表明不能用增加 burn-in 掩盖不足。四个独立 ensemble 的均值与 CDF 等时间序列也存在混合问题，原结论不是仅由“最差 walker”这个保守标准造成的。',
}

REASONS=[
    ('首要：链长相对依赖时间不足','直接数值证据','四年第一阶段仅 25.38、27.11、28.83、31.55τ；全部第一阶段参数均未满足 R̂/ESS 严格联合标准。','时间探索不足直接限制有效信息量；τ 自身也有短链估计误差，50τ 不是保证。'),
    ('后期参数观测信息薄弱','样本与观测结构共同支持','CDC_CD 样本 SD/先验 SD=0.917–0.968；衰老时间之后各年 CC 观测仅 2、2、1、2 个。','宽而近先验的后期方向更难被数据辨明；不能仅靠高 CC 拟合优度确认参数唯一性。'),
    ('局部边界堆积','直接样本证据','CCx 上界 1% 邻域：2019/2020 为 22.14%/23.06%；WP_early 下界邻域：2020/2021 为 11.43%/23.65%。','约束截断与偏斜可使探索更慢，并提示模型/数据或支持域张力；不是所有年份的共同唯一原因。'),
    ('参数补偿','直接相关证据；因果程度待验证','条件第二阶段 WP_late–HI0 的 r 依次为 −0.871、−0.595、−0.463、−0.645。','产量由生物量与收获指数共同决定，单个年末产量不能区分所有贡献；第一阶段线性相关程度并不极端。'),
    ('连续参数对应离散物候','代码机制已确认；影响待量化','SenescenceCD=int(round(...))，小于一日的部分参数变化不改变对应物候日。','响应呈台阶，叠加有限观测会降低细微参数变化的辨识；本轮未做替代实现试验，不能量化其贡献。'),
    ('独立验证设计不足','已确认的设计限制','第一阶段四组均围绕同一确定性起点，以约 6% 支持域宽度扰动；第二阶段每年仅一组。','起点未刻意广泛分散，隐藏模态仍不能排除；第二阶段缺少跨独立 ensemble 的检验，不等同于已证明其不收敛。'),
    ('条件推断与年度先验差异','已确认；不等同于数值收敛原因','第二阶段固定第一阶段均值；2022 为不同正态先验与较窄 WP/HI0 域。','影响不确定性和年度可比性，可能解释部分参数偏移；不能作为参数有偏或无偏的证明。'),
    ('固定物理结构或输入误差','尚未归因','原结构保留 fMulch=0、默认根系与既定初始水、误差权重和降水；本轮未改模型。','可能影响估计的物理意义与外推，但原链诊断不能证明其中哪一项导致未收敛。'),
]

def build():
    global CAP
    CAP=json.loads((ROOT/'figures/FIGURE_CAPTIONS_EN.json').read_text())
    s=load('Sampling_and_convergence_summary');p=load('Parameter_diagnostics');cov=load('Observation_coverage')
    d=Document();sec=d.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=sec.right_margin=Cm(2.1);sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.8)
    for sty in ['Normal','Body Text']:
        d.styles[sty].font.name='Noto Serif CJK SC';d.styles[sty].font.size=Pt(10.5)
        d.styles[sty]._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC')
    h=sec.header.paragraphs[0];h.alignment=WD_ALIGN_PARAGRAPH.RIGHT;font(h.add_run('URP · Original MCMC diagnostic · 2019–2022'),8)
    f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER
    q=OxmlElement('w:fldSimple');q.set(qn('w:instr'),'PAGE');f._p.append(q)
    d.core_properties.title='URP四年原始MCMC链诊断与未收敛原因归纳';d.core_properties.author='URP研究小组';d.core_properties.subject='Read-only diagnostic; original checkpoints and priors preserved'
    para(d,'四年原始 MCMC 链诊断\n与未收敛原因归纳',20,True)
    para(d,'2019—2022 年 DI 玉米 · 2026-10-22',11)
    para(d,'本轮范围：复核原始 20 组正式检查点、1,280,000 行已存状态；重新计算诊断并核查代码和观测结构。新增采样 0 步、模型调用 0 次。原参数范围、原物理设置与原拟合结果保持原样。',11)
    head(d,'结论先行')
    para(d,'原链的主要问题是：第一阶段时间探索与有效样本信息不足，部分后期参数约束弱，个别年份有明显边界堆积；第二阶段还存在水分生产力与收获指数的补偿，并缺少独立 ensemble 重复验证。现有证据不支持把它概括为“所有参数都偏了”，也不支持写成“参数已经被证明无偏”。',11,True)
    para(d,'四年第一阶段最差 R̂ 分别为 1.181、1.174、1.124、1.122；最小组内 bulk ESS 为 17.8、19.2、24.9、25.3。各参数中位组 R̂ 约为 1.032–1.068，说明并非只有一个极端 walker 才会失败。另一方面，四组均值最大跨度仅 0.204 个样本 SD，前后半段最大位置漂移仅 0.187 SD；观察到的是混合不充分，并没有看到均值相距很远的几个完全分离群。')
    para(d,'第二阶段每年只有一个独立 ensemble，所以结论应写成“缺少独立重复链收敛认证”；其中 2019/2022 满足 50τ 时间长度参考、2020/2021 未满足，均不能据此单独认证最终条件后验。')
    head(d,'1 资料、单位与诊断方法')
    para(d,'20 份原始 NPZ 均通过逐文件 SHA256 核对，history 维度、有限值、终点与记录支持域一致。每年第一阶段 4×2000×32×5，第二阶段 1×2000×32×3。2022 第二阶段取后补正式包，未用早期回退合成样本或 smoke test。此前的 2021 根深 1 m／覆膜短链 pilot 不混入本轮原链。')
    para(d,'独立性单位是 ensemble。第一阶段对固定 walker 编号，跨四个独立 ensemble 组成四条时间序列，用 ArviZ 计算秩归一化、折叠、分裂 R̂ 和 bulk/tail ESS [1,2]；报告 32 组的中位、最差及分位数，不把相关组 ESS 相加。另对四条 ensemble 均值、SD 和固定分位点 CDF 时间序列作辅助检验。第二阶段不计算独立 ensemble R̂。')
    para(d,'沿用原 burn-in=ceil(5×最大 τ)，并完整保留所有原始链。emcee τ 按原时间顺序重算 [2,3]；2000≥50τ 仅为原流程的长度参考。R̂<1.01、bulk/tail ESS≥400 采用原流程严格标准，不把每一位 walker 当作独立链。相关矩阵、年度均值差、边界占比和分段漂移均为描述统计，不对相关样本作独立样本显著性检验。')
    rows=[]
    for r in s.itertuples():
        rows.append([r.Year,r.Phase,r.Independent_ensembles,r.Burn_in,f'{r.Max_tau:.1f}',f'{r.Steps_over_max_tau:.1f}',f'{r.Acceptance_mean:.1%}',f'{r.Worst_matched_walker_Rhat:.3f}' if r.Phase==1 else '不可计算'])
    table(d,'表1 原始链结构与重新计算结果',['年份','阶段','独立组','丢弃步','最大τ','步数/τ','接受率','最差R̂'],rows,'阶段1：五参数联合链；阶段2：三参数条件联合链。样本行数是相关状态数，不能当成独立样本量。')
    figure(d,'D01_Independent_ensemble_convergence_EN',1,CN['D01_Independent_ensemble_convergence_EN'])
    head(d,'2 未收敛首先表现为有效时间不足')
    para(d,'四年第一阶段平均接受率为 44.2%、45.0%、47.2%、50.7%；各年第二阶段为 63.6%、58.6%、57.2%、64.8%。所有 walker 在保留期都接受过提议；第一阶段最长连续拒绝约 14–50 步。因此未发现普遍“卡死不动”或全体提议被拒绝的现象。接受率正常与充分混合是不同问题。')
    para(d,'第一阶段 2000 步仅约 25–32 个最大估计 τ，低于原 50τ 长度参考。有限链估计的 τ 还可能不稳定，不能把目前估计值直接当作未来所需链长的保证。存储 20 多万行或追加 walkers 增加的是相关状态数量，不能替代每条时间序列对慢方向的充分探索。')
    figure(d,'D02_Autocorrelation_length_and_acceptance_EN',2,CN['D02_Autocorrelation_length_and_acceptance_EN'])
    para(d,'为判断是否只是最差 walker 的保守判据造成“假警报”，对四个独立 ensemble 的均值时间序列另作检验：每年最差 R̂ 为 1.110、1.182、1.100、1.169。它们也没有全部通过，说明问题并非单纯的最差组统计。')
    para(d,'在不补任何新步的情况下改为丢弃前 1000 步，最差 R̂ 升至 1.347、1.281、1.264、1.176。保留长度减少本身会恶化有限样本诊断；这一结果说明不能通过扩大 burn-in 或挑选平滑片段来宣称原链已收敛。')
    figure(d,'D12_Burnin_and_ensemble_functional_checks_EN',3,CN['D12_Burnin_and_ensemble_functional_checks_EN'])
    head(d,'3 观测薄弱方向、边界与补偿')
    table(d,'表2 各年的观测分辨率',['年份','CC点数','生物量点数','年末产量数','衰老点之后CC数','每日Tr/Es约束'],
        [[int(r.Year),int(r.Phase1_CC_pairs),int(r.Phase2_biomass_pairs),1,int(r.CC_observations_after_handoff_senescence),'无，仅年总量'] for r in cov.itertuples()],
        '衰老点采用原第二阶段固定的第一阶段均值，四舍五入为模型物候日；点数随这一定义而变。CC由论文LAI数字化转换，生物量为近似读图值。')
    para(d,'第一阶段主要用 CC 时间序列、季节 Tr 与 Es 各一个总量约束五参数。年总量能限制总耗水，却不能精确定位每天的蒸发、蒸腾或晚期衰老轨迹。CDC_CD 样本 SD/实际截断正态先验 SD 四年为 0.917、0.919、0.968、0.951，后验样本几乎保留了先验宽度；这与衰老期 CC 观测稀少一致。它支持“有限信息”，但不能单凭先验重叠就认定参数完全不可辨识。')
    para(d,'源代码把连续 SenescenceCD 四舍五入为整数日，因而一日内的一些参数调整不会改变对应物候日。这个机制已从代码确认；它可能使目标响应台阶化，但本轮未替换实现，不能声称它已被证明是主要未收敛原因。')
    figure(d,'D07_Late_season_prior_overlap_EN',4,CN['D07_Late_season_prior_overlap_EN'])
    para(d,'边界堆积需区分年份与参数。全体原状态都在其记录支持域内，但 2019/2020 的 CCx 上界 1% 邻域分别含 22.14%/23.06% 样本；2020/2021 的 WP_early 下界 1% 邻域分别含 11.43%/23.65%，HI0 上界邻域分别含 7.23%/9.79%。这提示局部截断、模型/数据张力或参数相互补偿，不能证明真实参数必在界外，也不能直接要求扩界。')
    figure(d,'D05_Boundary_mass_four_years_EN',5,CN['D05_Boundary_mass_four_years_EN'])
    para(d,'第二阶段用 8–10 个近似生物量点和一个年末产量约束 WP_early、WP_late、HI0。产量由生物量及 HI 共同决定，后期 WP 与 HI0 的负相关是可解释的补偿。四年 r 分别为 −0.871、−0.595、−0.463、−0.645；2019 条件相关矩阵条件数约 20.63，补偿最强。第一阶段条件数约 2.48–3.50，相关程度中等，不能把第一阶段的所有未收敛都描述为严重的线性狭长谷。仿射不变 ensemble 方法可以缓解线性尺度/相关问题，但不保证有限时间内完整混合 [3,4]。')
    figure(d,'D09_WP_HI_compensation_EN',6,CN['D09_WP_HI_compensation_EN'])
    head(d,'4 四年参数偏移应如何解释')
    para(d,'2022 的 normal_priors 覆盖全部活跃参数，前三年只有 CDC_CD、SenescenceCD 用正态先验；2022 条件阶段 WP_early=[10,22]、WP_late=[20,38]、HI0=[0.35,0.50]，前三年为 [10,40]、[10,40]、[0.35,0.60]。正态中心也不同。因此四年链不是相同先验下的四次等价重复，更不能直接合并为一个“四年公共后验”。')
    para(d,'数据更新引起的先验—样本中心移动、不同年度独立拟合产生的差异、有限采样造成的 Monte Carlo 误差，以及模型相对于未知真实生理参数的统计偏差，是四个不同概念。当前只能量化前两类移动并诊断第三类；没有已知真值或独立参数测量，不能证明第四类为零。')
    para(d,'原阶段二固定阶段一保留样本算术均值，20 个固定坐标均与重算均值一致，误差小于 10⁻¹²。这是有记录的条件推断，并未传播阶段一完整联合不确定性；不能把两阶段任意配对成八维联合后验。条件推断限制了不确定性解释，但不意味着条件阶段的 Markov 链必然不收敛。')
    figure(d,'D10_Ensemble_location_and_time_drift_EN',7,CN['D10_Ensemble_location_and_time_drift_EN'])
    head(d,'5 原因归纳与证据强度')
    for title,strength,ev,meaning in REASONS:
        head(d,title,2);para(d,'证据层级：'+strength+'。'+ev);para(d,'解释：'+meaning)
    para(d,'目前没有发现原检查点损坏、参数超出记录支持域、阶段一到阶段二均值传递错误，或所有 walker 长期停止移动的迹象。也没有足够证据把未收敛具体归咎于地膜系数、根深或土壤黏粒含量。本轮仅验证诊断及记录一致性，未重放原似然与前向模型，故不据此认证全部物理实现。',10.5,True)
    head(d,'6 对原论文与后续分析的影响')
    para(d,'可保留：冻结参数中心下的确定性 CC、生物量、产量拟合；明确公共独立输入范围下的 Sobol 结果；冻结中心下的条件灌溉优化。它们各有用途，但不构成可靠后验收敛或田间外推验证。若原文把它们称为“已充分收敛后验的预测”“完整后验不确定性”“参数无偏证明”，这些表述应撤回或改成条件性、探索性结论。')
    para(d,'不能据本轮计算认证：后验尾部、窄可信区间、跨阶段协方差、年度参数的无偏性，以及优化候选达到产量门槛的后验概率。95%观测产量门槛仍只是一个确定性产量水平，不是95%概率保证。固定 fMulch、根深与初始储水可能影响校准和外推；这属于物理结构/输入审计，需要单独试验，不能与数值收敛混为一谈。')
    head(d,'可直接放入论文的表述',2)
    paper='对2019—2022年原始分阶段MCMC检查点的回溯诊断表明，第一阶段虽在不同独立ensemble间形成相近的参数位置分布，但秩归一化分裂R̂与有效样本量尚未达到预设严格标准，其时间长度仅为最大估计自相关时间的25–32倍。未收敛信号伴随后期冠层参数的弱信息约束及个别参数的邻界集中；第二阶段还表现出水分生产力与收获指数的补偿。由于每年第二阶段仅有一个条件ensemble，且固定了第一阶段均值，本研究不将这些样本解释为已充分验证的八参数联合后验，也不据此声称参数无偏。现有拟合及灌溉优化结果应作为冻结参数中心和既定物理结构下的条件性模型结果。'
    para(d,paper,11)
    head(d,'7 若后续继续，最小验证顺序')
    for s0 in [
        '先保留本轮原链作为基线，原参数支持域与物理设置不变；若另行授权采样，优先延续这些链并增加每个第二阶段的独立 ensemble，再按完整诊断自适应判断是否足够，不按固定步数宣称收敛。',
        '核实后期 CC/LAI 和物候原始数据，增加衰老阶段观测分辨率；检查读图误差、LAI→CC转换和季节通量权重是否与证据质量一致。原参数边界先作物理解释，再决定是否需要调整。',
        '对 WP–HI 补偿和整日物候采用针对性的剖面/替代参数化试验，并保持相同先验和数据作比较；比较须分开记录，不能覆盖原链。',
        '只有在采样足够可靠后，再考虑已知真值的重复参数恢复或模拟校准，检查系统误差与覆盖率；一次“真值落在区间内”或统计不显著都不能证明无偏。',
    ]:para(d,s0)
    para(d,'本轮已完成诊断，不执行以上拟议修复或新增采样。',10.5,True)
    head(d,'参考文献与方法依据')
    refs=[
        '[1] Vehtari A, Gelman A, Simpson D, Carpenter B, Bürkner P-C. Rank-normalization, folding, and localization: An improved R-hat for assessing convergence of MCMC. Bayesian Analysis, 2021, 16(2): 667–718. doi:10.1214/20-BA1221.',
        '[2] ArviZ 0.22.0 documentation: arviz.rhat; arviz.ess. 本轮实际计算版本记录于 verification/COMPUTATION.json。https://python.arviz.org/en/stable/api/diagnostics.html',
        '[3] Foreman-Mackey D, Hogg D W, Lang D, Goodman J. emcee: The MCMC Hammer. Publications of the Astronomical Society of the Pacific, 2013, 125: 306–312. doi:10.1086/670067. Autocorrelation analysis: https://emcee.readthedocs.io/en/stable/tutorials/autocorr/',
        '[4] Goodman J, Weare J. Ensemble samplers with affine invariance. Communications in Applied Mathematics and Computational Science, 2010, 5(1): 65–80. doi:10.2140/camcos.2010.5.65.',
    ]
    for r in refs:para(d,r,9)
    head(d,'交付物与复算入口')
    para(d,'figures/：12组英文 PNG 与矢量 PDF；docs/：本报告与英文图册；tables/：完整诊断 CSV 和 Excel；source/：20份原始检查点、合同、原始代码及本轮所需证据输入；code/：只读复核与出图代码；verification/：完整性、数值复现和文件检查。Excel 中原采样表与描述统计不包含伪造的第二阶段 R̂。')
    para(d,'复算步骤见根目录 README.md；校验入口为 code/verify_delivery.py。',9)
    d.save(ROOT/'docs/URP_Original_MCMC_Diagnostic_CN.docx')
    allpdf=fitz.open()
    for key in sorted(CAP):
        with fitz.open(ROOT/'figures'/f'{key}.pdf') as src:allpdf.insert_pdf(src)
    allpdf.save(ROOT/'docs/Original_MCMC_English_Figure_Atlas.pdf',garbage=4,deflate=True);allpdf.close()
    fig_md=['# 原始 MCMC 图件逐图解析','所有图采用英文标签；经验分布均保留相关样本和未认证收敛的限制。']
    for key in sorted(CAP):fig_md.extend(['',f'## {key}',CAP[key],'',CN[key]])
    (ROOT/'docs/Figure_interpretations.md').write_text('\n'.join(fig_md),encoding='utf-8')
    (ROOT/'docs/Paper_ready_diagnostic_paragraph_CN.txt').write_text(paper,encoding='utf-8')
    reasons=pd.DataFrame(REASONS,columns=['可能原因','证据强度','实际证据','解释与边界'])
    reasons.to_csv(ROOT/'tables/Unconverged_causes_evidence_CN.csv',index=False,encoding='utf-8-sig')
    with pd.ExcelWriter(ROOT/'tables/Original_MCMC_diagnostics.xlsx',engine='openpyxl',mode='a',if_sheet_exists='replace') as writer:
        for name in ['Code_evidence','Observation_coverage','Phase1_to_phase2_handoff','Unconverged_causes_evidence_CN']:
            load(name).to_excel(writer,sheet_name=name[:31],index=False)
    md=['# 四年原始 MCMC 诊断结果','',
        '已检查20份原始正式检查点、1,280,000行存储状态；未新增采样、未修改支持域或物理设置。','',
        '第一阶段四年均未通过原严格诊断；第二阶段均仅一个独立ensemble，不能作独立链收敛认证。','',
        '| 年份 | 第一阶段最差 R̂ | 最小组内 bulk ESS | 步数/最大τ |','|---|---:|---:|---:|']
    for r in s[s.Phase.eq(1)].itertuples():md.append(f'| {r.Year} | {r.Worst_matched_walker_Rhat:.3f} | {r.Worst_matched_walker_bulk_ESS:.1f} | {r.Steps_over_max_tau:.1f} |')
    md+=['','ESS 是 matched-walker 诊断组的值，不是全部存储行的 pooled ESS；相关组 ESS 不相加。','']
    for title,strength,ev,meaning in REASONS:md.extend([f'**{title}（{strength}）**：{ev} {meaning}',''])
    md.extend(['不能把未收敛称为参数“无偏”的证明，也不能把四年年度差异直接认定为统计偏差。','',paper])
    (ROOT/'docs/Diagnostic_summary_CN.md').write_text('\n'.join(md),encoding='utf-8')
    print('Chinese Word, figure atlas, interpretations, evidence matrix, and workbook built.')

if __name__=='__main__':build()
