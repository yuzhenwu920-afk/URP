"""English publication figures from the original-chain diagnostic tables only."""
from pathlib import Path
import json,os
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import LogNorm
import numpy as np
import pandas as pd
from scipy.stats import truncnorm,uniform
YEARS=[2019,2020,2021,2022]
P1=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb'];P2=['WP_early','WP_late','HI0']
COLORS=['#0072B2','#D55E00','#009E73','#A45A9F']
LABEL={'CCx':r'$CC_x$','CGC_CD':r'$CGC_{CD}$','CDC_CD':r'$CDC_{CD}$','SenescenceCD':r'$Senescence_{CD}$','Kcb':r'$K_{cb}$','WP_early':r'$WP_{early}$','WP_late':r'$WP_{late}$','HI0':r'$HI_0$'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.titlesize':12,'axes.labelsize':11,
    'xtick.labelsize':9.5,'ytick.labelsize':9.5,'legend.fontsize':9.5,'axes.spines.top':False,
    'axes.spines.right':False,'grid.alpha':.22,'grid.color':'#c4cbd1','pdf.fonttype':42,'ps.fonttype':42})
CAPTIONS={}

def table(n):return pd.read_csv(ROOT/'tables'/f'{n}.csv')
def save(fig,name,caption):
    fig.savefig(ROOT/'figures'/f'{name}.png',dpi=300,bbox_inches='tight',facecolor='white')
    fig.savefig(ROOT/'figures'/f'{name}.pdf',bbox_inches='tight',facecolor='white')
    plt.close(fig);CAPTIONS[name]=caption
def foot(fig,s):fig.text(.5,.015,s,ha='center',va='bottom',fontsize=9,color='#425563')
def grid(ax):ax.grid(True,linewidth=.7);ax.set_axisbelow(True)

def overview():
    p=table('Parameter_diagnostics').query('Phase==1');s=table('Sampling_and_convergence_summary')
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.4),layout='constrained')
    for ax,col,title,norm,cmap in [(axs[0],'Rhat_max','(a) Worst matched-walker rank R-hat',None,'YlOrRd'),
                                  (axs[1],'ESS_bulk_min','(b) Minimum bulk ESS within matched groups',LogNorm(vmin=15,vmax=55),'Blues_r')]:
        a=p.pivot(index='Parameter',columns='Year',values=col).reindex(P1).to_numpy()
        im=ax.imshow(a,aspect='auto',cmap=cmap,norm=norm,vmin=1 if norm is None else None,vmax=1.2 if norm is None else None)
        ax.set_xticks(range(4),YEARS);ax.set_yticks(range(5),[LABEL[k] for k in P1]);ax.set_title(title,pad=12)
        for i in range(5):
                for j in range(4):ax.text(j,i,f'{a[i,j]:.3f}' if col=='Rhat_max' else f'{a[i,j]:.1f}',ha='center',va='center',fontsize=11,
                    color='white' if (col=='Rhat_max' and a[i,j]>1.13) or (col=='ESS_bulk_min' and a[i,j]<28) else '#152a36')
        fig.colorbar(im,ax=ax,shrink=.8,pad=.02)
    fig.suptitle('Original phase-1 MCMC: all four years miss the strict diagnostic criteria',fontsize=14)
    save(fig,'D01_Independent_ensemble_convergence_EN',
         'Phase-1 diagnostics after the original tau-based burn-in. Each group contains one matched walker index from each of four independent ensembles; walkers in an ensemble are not independent chains. Cells show the maximum rank-normalized folded split R-hat and minimum bulk ESS over 32 dependent groups. ESS values are not summed. Reference criteria are R-hat<1.01 and bulk/tail ESS>=400 within each group. The displayed ESS is not the pooled effective sample size.')
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.3));fig.subplots_adjust(bottom=.21,top=.82,wspace=.3)
    x=np.arange(4)
    for ph,color,offset in [(1,COLORS[0],-.18),(2,COLORS[1],.18)]:
        z=s[s.Phase.eq(ph)].set_index('Year').loc[YEARS];bars=axs[0].bar(x+offset,z.Steps_over_max_tau,width=.32,color=color,label=f'Phase {ph}')
        for b,v in zip(bars,z.Steps_over_max_tau):axs[0].text(b.get_x()+b.get_width()/2,v+1,f'{v:.1f}',ha='center',fontsize=9)
    axs[0].axhline(50,color='#626f77',ls='--',lw=1.2,label=r'$50\tau$ length reference')
    axs[0].set(xticks=x,xticklabels=YEARS,ylabel=r'Stored steps / maximum estimated $\tau$',ylim=(0,73),title='(a) Time length relative to autocorrelation')
    axs[0].legend(loc='upper left',fontsize=8.5);grid(axs[0])
    a=table('Acceptance_and_rejections')
    for ph,marker,offset in [(1,'o',-.12),(2,'s',.12)]:
        for i,y in enumerate(YEARS):
            z=a.query('Year==@y and Phase==@ph');mu=z.Acceptance_mean.mean()
            axs[1].errorbar(i+offset,mu,yerr=[[mu-z.Acceptance_min.min()],[z.Acceptance_max.max()-mu]],color=COLORS[ph-1],marker=marker,capsize=4,ms=6,label=f'Phase {ph}' if i==0 else None)
    axs[1].set(xticks=x,xticklabels=YEARS,ylim=(.25,.8),ylabel='Proposal acceptance fraction',title='(b) Active movement does not certify mixing')
    axs[1].legend(loc='lower right');grid(axs[1])
    fig.suptitle('Original MCMC length and acceptance',fontsize=15)
    foot(fig,'All checkpoints contain 2000 steps per walker. The 50-tau rule is a length heuristic, not a convergence proof.')
    save(fig,'D02_Autocorrelation_length_and_acceptance_EN',
         'Original chain length divided by maximum emcee IAT, alongside acceptance fractions. Phase 1 has four ensembles per year; phase 2 has one. Error bars span the observed walker acceptance range. All walkers make accepted post-burn moves. A satisfactory acceptance fraction does not establish convergence. IAT estimates from short chains can themselves be unstable; 50*tau is an inherited length reference.')

def traces():
    t=table('Trace_blocks_50_steps');p=table('Parameter_diagnostics')
    fig,axs=plt.subplots(5,4,figsize=(12.5,11.6),sharex=True);fig.subplots_adjust(top=.9,bottom=.08,left=.08,right=.99,hspace=.35,wspace=.27)
    for i,k in enumerate(P1):
        for j,y in enumerate(YEARS):
            ax=axs[i,j];z=t.query('Year==@y and Phase==1 and Parameter==@k')
            b=p.query('Year==@y and Phase==1').Burn_in.iloc[0];ax.axvspan(0,b,color='#cbd2d6',alpha=.5,lw=0)
            for e,c in enumerate(COLORS,1):
                u=z[z.Ensemble.eq(e)];ax.plot(u.Step_midpoint,u.Mean,color=c,lw=1.25)
            if i==0:ax.set_title(str(y))
            if j==0:ax.set_ylabel(LABEL[k])
            if i==4:ax.set_xlabel('MCMC step')
            ax.ticklabel_format(axis='y',style='plain',useOffset=False);ax.tick_params(axis='y',labelsize=8.5);grid(ax)
    fig.suptitle('Phase 1: independent-ensemble trajectories',fontsize=16,y=.98)
    fig.legend([Line2D([],[],color=c,lw=2) for c in COLORS],[f'Ensemble {i}' for i in range(1,5)],loc='upper center',bbox_to_anchor=(.5,.955),ncol=4,frameon=False)
    foot(fig,'Lines are 50-step block means across 32 coupled walkers; gray areas are the original discarded warm-up.')
    save(fig,'D03_Phase1_four_year_trace_blocks_EN',
         'Phase-1 independent-ensemble trajectories for all five parameters and four years. Each point averages a non-overlapping 50-step block across the 32 coupled walkers. Smoothing is for readability and does not demonstrate convergence. Gray regions mark the original burn-in. Raw time-ordered checkpoints and unsmoothed diagnostic statistics are provided.')
    fig,axs=plt.subplots(3,4,figsize=(12.5,8),sharex=True);fig.subplots_adjust(top=.87,bottom=.1,left=.08,right=.99,hspace=.3,wspace=.27)
    for j,y in enumerate(YEARS):
        with np.load(ROOT/'source'/str(y)/'phase2/ensemble_1.npz') as z:raw=z['history']
        b=p.query('Year==@y and Phase==2').Burn_in.iloc[0]
        for i,k in enumerate(P2):
            ax=axs[i,j];ax.axvspan(0,b,color='#cbd2d6',alpha=.5,lw=0)
            for w in [0,6,12,18,24,30]:ax.plot(np.arange(0,2000,5),raw[::5,w,i],color=COLORS[j],alpha=.16,lw=.6)
            u=t.query('Year==@y and Phase==2 and Parameter==@k');ax.plot(u.Step_midpoint,u.Mean,color=COLORS[j],lw=1.6)
            if i==0:ax.set_title(str(y))
            if j==0:ax.set_ylabel(LABEL[k])
            if i==2:ax.set_xlabel('MCMC step')
            ax.ticklabel_format(axis='y',style='plain',useOffset=False);grid(ax)
    fig.suptitle('Phase 2: conditional single-ensemble trajectories',fontsize=16)
    foot(fig,'Faint lines: six representative coupled walkers. Bold: 50-step block mean. Independent-ensemble R-hat is unavailable.')
    save(fig,'D04_Phase2_conditional_traces_EN',
         'Phase-2 trajectories conditional on the retained phase-1 arithmetic-mean handoff. Faint lines show six fixed walker indices at a plotting stride of five; bold lines average all walkers in 50-step time blocks. These walkers are coupled and must not be used as independent convergence chains. All statistics use full, unthinned checkpoints.')

def boundary_and_identification():
    p=table('Parameter_diagnostics'); pri=table('Recorded_prior_distributions')
    fig,axs=plt.subplots(2,1,figsize=(11,8.2));fig.subplots_adjust(top=.9,bottom=.13,hspace=.35,left=.08,right=.97)
    labels=[];low=[];up=[]
    for y in YEARS:
        for k in P1+P2:
            r=p.query('Year==@y and Parameter==@k').iloc[0];labels.append((y,k));low.append(r.Lower_1pct_mass*100);up.append(r.Upper_1pct_mass*100)
    low=np.array(low).reshape(4,8).T;up=np.array(up).reshape(4,8).T
    for ax,a,title in [(axs[0],low,'(a) Mass in the lowest 1% of recorded support'),(axs[1],up,'(b) Mass in the highest 1% of recorded support')]:
        im=ax.imshow(a.T,aspect='auto',cmap='YlOrRd',vmin=0,vmax=25)
        ax.set_xticks(range(8),[LABEL[k] for k in P1+P2]);ax.set_yticks(range(4),YEARS);ax.set_title(title,pad=9)
        ax.axvline(4.5,color='white',lw=2)
        for i in range(4):
            for j in range(8):ax.text(j,i,f'{a[j,i]:.1f}%',ha='center',va='center',fontsize=10)
        fig.colorbar(im,ax=ax,pad=.015,label='Retained correlated sample mass (%)')
    fig.suptitle('Boundary concentration is localized, not universal',fontsize=15)
    foot(fig,'A boundary band is 1% of that parameter\'s recorded support. Annual phase-2 supports and prior densities differ.')
    save(fig,'D05_Boundary_mass_four_years_EN',
         'Empirical retained-sample mass in the lower and upper 1% bands of each recorded support. Phase 1 and conditional phase 2 are separated by the white divider. CCx upper-band masses are 22.14% and 23.06% in 2019 and 2020; WP_early lower-band masses are 11.43% and 23.65% in 2020 and 2021. This is neighborhood accumulation, not evidence that values were numerically clipped to an endpoint. A uniform prior assigns 1% mass to such a band; Gaussian-prior band masses are recorded separately.')
    fig,axs=plt.subplots(1,2,figsize=(11.6,4.8));fig.subplots_adjust(top=.85,bottom=.23,wspace=.35)
    for ax,phase,names in [(axs[0],1,P1),(axs[1],2,P2)]:
        for j,y in enumerate(YEARS):
            z=p.query('Year==@y and Phase==@phase').set_index('Parameter').loc[names]
            ax.plot(np.arange(len(names)),z.SD_over_prior_SD,color=COLORS[j],marker='o',lw=1.4,label=str(y))
        ax.axhline(1,color='#5b6870',ls='--',lw=1);ax.set(xticks=range(len(names)),xticklabels=[LABEL[k] for k in names],ylim=(0,1.1),ylabel='Retained-sample SD / actual prior SD',title=f'({"a" if phase==1 else "b"}) Phase {phase}')
        ax.tick_params(axis='x',rotation=22);grid(ax)
    fig.legend([Line2D([],[],color=c,marker='o') for c in COLORS],list(map(str,YEARS)),ncol=4,loc='upper center',bbox_to_anchor=(.5,.95),frameon=False)
    foot(fig,'Ratios describe observed contraction only. Near-one values suggest limited learning under the specified prior; convergence remains uncertified.')
    save(fig,'D06_Prior_to_sample_contraction_EN',
         'Retained-sample SD relative to the analytical SD of the actual recorded prior (including truncation for normal priors). CDC_CD retains 91.7–96.8% of prior SD, consistent with limited late-season information. This is a descriptive contraction diagnostic, not a calibrated measure of identifiability or parameter bias. The 2022 priors have different density families and phase-2 supports.')
    fig,axs=plt.subplots(2,4,figsize=(12,7));fig.subplots_adjust(top=.87,bottom=.13,hspace=.4,wspace=.3)
    for j,y in enumerate(YEARS):
        with np.load(ROOT/'source'/str(y)/'phase1_figure_samples.npz') as z:samp=z['samples'].reshape(-1,5)
        c=json.loads((ROOT/'source'/str(y)/'phase1/ensemble_1.contract.json').read_text())
        for i,k in enumerate(['CDC_CD','SenescenceCD']):
            ax=axs[i,j];idx=P1.index(k);lo,hi=c['priors'][k];mu,sd=c['center'][k],c['prior_sd'][k]
            d=truncnorm((lo-mu)/sd,(hi-mu)/sd,loc=mu,scale=sd);x=np.linspace(lo,hi,300)
            ax.hist(samp[:,idx],bins=32,density=True,color=COLORS[j],alpha=.4,edgecolor='none')
            ax.plot(x,d.pdf(x),color='#354e5b',ls='--',lw=1.7)
            ax.set_title(str(y) if i==0 else '');ax.set_xlabel(LABEL[k]);ax.set_ylabel('Density' if j==0 else '');grid(ax)
    fig.suptitle('Late-season parameters: recorded prior and retained-sample distributions',fontsize=15)
    foot(fig,'Dashed: actual truncated-normal prior. Filled histogram: phase-1 correlated sample distribution, deterministic plotting subsample.')
    save(fig,'D07_Late_season_prior_overlap_EN',
         'Phase-1 CDC_CD and SenescenceCD distributions overlaid on their actual truncated-normal priors. There are only 2, 2, 1 and 2 CC observations on or after the rounded senescence handoff in 2019–2022. The forward model rounds SenescenceCD to integer days, giving a piecewise response. Prior-like CDC_CD marginals support weak information but do not alone establish the cause of all mixing failures.')

def compensation_and_drift():
    c=table('Phase_specific_correlations');p=table('Parameter_diagnostics');e=table('Independent_ensemble_summaries')
    fig,axs=plt.subplots(2,4,figsize=(12,7.2));fig.subplots_adjust(top=.9,bottom=.13,hspace=.38,wspace=.26)
    for j,y in enumerate(YEARS):
        for i,(phase,names) in enumerate([(1,P1),(2,P2)]):
            a=c.query('Year==@y and Phase==@phase').pivot(index='Parameter_1',columns='Parameter_2',values='Pearson_r').reindex(index=names,columns=names).to_numpy()
            ax=axs[i,j];im=ax.imshow(a,cmap='RdBu_r',vmin=-1,vmax=1)
            ax.set_xticks(range(len(names)),[LABEL[k] for k in names],rotation=55,ha='right',fontsize=8.5)
            ax.set_yticks(range(len(names)),[LABEL[k] for k in names],fontsize=8.5)
            ax.set_title(f'{y} | phase {phase}',fontsize=11)
            for ii in range(len(names)):
                for jj in range(len(names)):
                    if ii!=jj:ax.text(jj,ii,f'{a[ii,jj]:.2f}',ha='center',va='center',fontsize=8.5,color='white' if abs(a[ii,jj])>.65 else '#172c38')
    fig.suptitle('Within-phase parameter compensation across the four years',fontsize=15)
    foot(fig,'Pearson correlations from all retained rows; descriptive only. No cross-phase or cross-year joint posterior is constructed.')
    save(fig,'D08_Phase_specific_correlation_matrices_EN',
         'Within-phase Pearson correlations from all retained time-ordered sample rows after flattening only for descriptive correlation. Separate panels preserve the 5-D phase-1 and 3-D conditional phase-2 dependence structures. The strongest pair is 2019 WP_late–HI0 (r=-0.871); corresponding correlations are -0.595, -0.463 and -0.645 in 2020–2022. These correlations show compensation, not causally identified parameter errors or an eight-dimensional joint posterior.')
    fig,axs=plt.subplots(1,4,figsize=(12,3.8));fig.subplots_adjust(top=.79,bottom=.25,wspace=.3)
    for j,y in enumerate(YEARS):
        with np.load(ROOT/'source'/str(y)/'phase2_figure_samples.npz') as z:s=z['samples'].reshape(-1,3)
        ax=axs[j];ax.hexbin(s[:,1],s[:,2],gridsize=30,mincnt=1,cmap='Blues',linewidths=0)
        r=c.query('Year==@y and Phase==2 and Parameter_1=="WP_late" and Parameter_2=="HI0"').Pearson_r.iloc[0]
        ax.set(title=f'{y} | r = {r:.3f}',xlabel=LABEL['WP_late']);ax.set_ylabel(LABEL['HI0'] if j==0 else '');grid(ax)
    fig.suptitle('Late water productivity and harvest index trade off in conditional calibration',fontsize=14)
    foot(fig,'Density uses a deterministic sample subset; the correlations use all retained rows. Each year has one conditional ensemble.')
    save(fig,'D09_WP_HI_compensation_EN',
         'Conditional phase-2 WP_late–HI0 joint sample distributions. Because final yield depends on both biomass formation and harvest index, multiple pairs can give similar yields. Approximate biomass observations reduce but do not remove this trade-off. Correlations are descriptive for the existing samples; there is no independent-ensemble convergence certification for phase 2.')
    fig,axs=plt.subplots(1,2,figsize=(11.7,4.8));fig.subplots_adjust(top=.79,bottom=.24,wspace=.3)
    for ax,col,title in [(axs[0],'Ensemble_mean_span_SD','(a) Span of independent ensemble means'),(axs[1],'Max_absolute_ensemble_half_shift_SD','(b) Largest within-ensemble half-window shift')]:
        for j,y in enumerate(YEARS):
            z=p.query('Year==@y and Phase==1').set_index('Parameter').loc[P1]
            ax.plot(range(5),z[col],color=COLORS[j],marker='o',label=str(y))
        ax.set(xticks=range(5),xticklabels=[LABEL[k] for k in P1],ylim=(0,.25),ylabel='Difference / pooled retained-sample SD',title=title)
        ax.tick_params(axis='x',rotation=25);grid(ax)
    fig.suptitle('Mean locations look fairly stable while stricter mixing diagnostics still fail',fontsize=14,y=1.01)
    fig.legend([Line2D([],[],color=c,marker='o') for c in COLORS],list(map(str,YEARS)),ncol=4,loc='upper center',bbox_to_anchor=(.5,.96),frameon=False)
    foot(fig,'No significance test is inferred from these correlated draws. Modest mean differences do not certify full-distribution convergence.')
    save(fig,'D10_Ensemble_location_and_time_drift_EN',
         'Phase-1 differences normalized by pooled retained-sample SD. The span of four ensemble means is at most 0.204 SD; each ensemble\'s difference between equal early and late retained halves is at most 0.187 SD. This supports modest observed location drift rather than gross between-ensemble separation, but it does not override failed rank R-hat/ESS diagnostics or exclude unsampled modes.')

def supplementary():
    a=table('Within_walker_ACF')
    fig,axs=plt.subplots(2,4,figsize=(12,6.6));fig.subplots_adjust(top=.87,bottom=.14,hspace=.3,wspace=.25)
    for j,y in enumerate(YEARS):
        for i,(phase,names) in enumerate([(1,P1),(2,P2)]):
            ax=axs[i,j]
            for m,k in enumerate(names):
                z=a.query('Year==@y and Phase==@phase and Parameter==@k').groupby('Lag').Mean_within_walker_ACF.mean()
                ax.plot(z.index,z.values,lw=1.5,label=LABEL[k])
            ax.axhline(0,color='#7b858b',lw=.6);ax.set(title=f'{y} | phase {phase}',ylim=(-.13,1.02),xlabel='Lag (steps)' if i==1 else '',ylabel='Mean within-walker ACF' if j==0 else '');grid(ax)
            if j==0:ax.legend(fontsize=8,loc='upper right')
    fig.suptitle('Autocorrelation persists despite frequent accepted proposals',fontsize=15)
    foot(fig,'ACFs are centered and normalized within each retained walker trajectory, then averaged; walker independence is not assumed.')
    save(fig,'D11_Autocorrelation_four_years_EN',
         'Mean within-walker autocorrelation for all sampled parameters. Each retained walker time series is centered and normalized separately; ACFs are then averaged within ensemble and, for phase 1, over the four ensembles. This display is not a pooled ESS estimate. Acceptance can be frequent while samples remain strongly time dependent.')
    b=table('Burnin_sensitivity').query('Phase==1');f=table('Ensemble_functional_diagnostics')
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.6));fig.subplots_adjust(top=.83,bottom=.23,wspace=.3)
    for j,y in enumerate(YEARS):
        z=b[b.Year.eq(y)].groupby('Discard_steps').Rhat_max.max();axs[0].plot(range(2),z.values,color=COLORS[j],marker='o',label=str(y))
    axs[0].axhline(1.01,color='#5f6d76',ls='--',lw=1);axs[0].set(xticks=[0,1],xticklabels=['Original tau-based burn-in','Discard 1000 steps'],ylabel='Worst matched-walker rank R-hat',title='(a) Longer discard does not rescue the diagnosis',ylim=(.99,1.38));grid(axs[0])
    for j,y in enumerate(YEARS):
        z=f.query('Year==@y and Functional=="mean"').set_index('Parameter').loc[P1]
        axs[1].plot(range(5),z.Rhat,color=COLORS[j],marker='o',label=str(y))
    axs[1].axhline(1.01,color='#5f6d76',ls='--',lw=1);axs[1].set(xticks=range(5),xticklabels=[LABEL[k] for k in P1],ylabel='Rank R-hat of ensemble-mean time series',title='(b) Independent ensemble functionals also disagree',ylim=(.99,1.2));axs[1].tick_params(axis='x',rotation=23);grid(axs[1])
    fig.legend([Line2D([],[],color=c,marker='o') for c in COLORS],list(map(str,YEARS)),ncol=4,loc='upper center',bbox_to_anchor=(.5,.96),frameon=False)
    foot(fig,'Discard sensitivity is not a search for a passing window. Functional R-hat assesses that ensemble statistic, not pooled draw ESS.')
    save(fig,'D12_Burnin_and_ensemble_functional_checks_EN',
         'Sensitivity checks using the same unchanged checkpoints. Discarding the first 1000 steps raises the worst matched-walker R-hat to 1.347, 1.281, 1.264 and 1.176 across 2019–2022; shorter retained length is one reason. Four independent ensemble-mean time series also fail for some parameters (annual worst R-hat 1.110, 1.182, 1.100 and 1.169), so the finding is not solely a single extreme walker comparison. Neither check licenses post hoc selection of a passing segment.')

if __name__=='__main__':
    overview();traces();boundary_and_identification();compensation_and_drift();supplementary()
    (ROOT/'figures/FIGURE_CAPTIONS_EN.json').write_text(json.dumps(CAPTIONS,indent=2),encoding='utf-8')
    print(f'{len(CAPTIONS)} English figure groups exported as PNG + vector PDF.')
