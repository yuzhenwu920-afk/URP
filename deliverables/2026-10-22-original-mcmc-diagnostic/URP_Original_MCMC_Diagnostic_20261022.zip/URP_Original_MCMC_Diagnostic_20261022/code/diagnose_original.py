"""Read-only audit of the 20 original DI MCMC checkpoints; no model calls/sampling.

Independent ensembles are replication units. Coupled walkers are NEVER relabelled
as independent chains. Matched-walker diagnostic groups are reported separately;
their ESS values are not added. Phase 2 has no between-ensemble R-hat.
"""
from pathlib import Path
import argparse, hashlib, importlib.metadata, json, os, shutil, sys, time, warnings
ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(ROOT/'.cache/matplotlib'))
os.environ.setdefault('NUMBA_CACHE_DIR', str(ROOT/'.cache/numba'))
import numpy as np
import pandas as pd
import arviz as az
from emcee.autocorr import integrated_time
from scipy.stats import spearmanr, truncnorm

DEFAULT_ARCHIVE = Path('/workspace/urp_final_research_archive_20261021')
YEARS = [2019, 2020, 2021, 2022]
P1 = ['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb']
P2 = ['WP_early','WP_late','HI0']

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def clean(v):
    if isinstance(v, dict): return {str(k):clean(x) for k,x in v.items()}
    if isinstance(v, (list,tuple,np.ndarray)): return [clean(x) for x in v]
    if isinstance(v, (np.integer,)): return int(v)
    if isinstance(v, (np.bool_,)): return bool(v)
    if isinstance(v, (float,np.floating)): return float(v) if np.isfinite(v) else None
    if isinstance(v, Path): return str(v)
    return v

def write_json(p, v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(clean(v), ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def save(name, rows):
    df = rows if isinstance(rows,pd.DataFrame) else pd.DataFrame(rows)
    df.to_csv(ROOT/'tables'/f'{name}.csv', index=False, encoding='utf-8-sig')
    return df

def diag(x):
    """x: independent ensemble, time. Rank-normalized folded split R-hat."""
    return dict(Rhat=float(az.rhat(x,method='rank')),
                ESS_bulk=float(az.ess(x,method='bulk')),
                ESS_tail=float(az.ess(x,method='tail')))

def tau(x):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        return np.asarray(integrated_time(x,tol=0,quiet=True),float)

def rejection_run(a):
    m = c = 0
    for v in a:
        c = 0 if v else c+1
        m = max(m,c)
    return m

def prior_dist(c,k):
    lo,hi = c['priors'][k]
    if k in c['normal_priors']:
        mu,sd = c['center'][k],c['prior_sd'][k]
        d = truncnorm((lo-mu)/sd,(hi-mu)/sd,loc=mu,scale=sd)
        return d, 'truncated_normal'
    from scipy.stats import uniform
    return uniform(loc=lo,scale=hi-lo), 'uniform'

def main(archive):
    t0=time.time()
    for folder in ['source','tables','figures','verification','docs']: (ROOT/folder).mkdir(exist_ok=True)
    use_archive=archive.exists()
    mp=archive/'verification/FORMAL_MCMC_CHECKPOINTS.json' if use_archive else ROOT/'source/FORMAL_MCMC_CHECKPOINTS.json'
    manifest=json.loads(mp.read_text())
    sampling_path=archive/'stages/11_English_figures_tables_and_interpretations/tables/TableS2_MCMC_sampling.csv' if use_archive else ROOT/'source/Original_sampling_reference.csv'
    original_sampling=pd.read_csv(sampling_path)
    if use_archive:
        shutil.copyfile(mp,ROOT/'source/FORMAL_MCMC_CHECKPOINTS.json')
        shutil.copyfile(sampling_path,ROOT/'source/Original_sampling_reference.csv')
    source_records=[]; arrays={}; contracts={}; acceptance={}; logs={}
    for rec in manifest:
        p=archive/'stages'/rec['path'] if use_archive else ROOT/'source'/str(rec['Year'])/f"phase{rec['Phase']}"/Path(rec['path']).name
        digest=sha(p)
        assert digest==rec['sha256'], f'Original source changed: {p}'
        e=int(p.stem.split('_')[-1]);y=rec['Year'];ph=rec['Phase']
        dest=ROOT/'source'/f'{y}'/f'phase{ph}'/p.name
        dest.parent.mkdir(parents=True,exist_ok=True)
        if p.resolve()!=dest.resolve():shutil.copyfile(p,dest)
        with np.load(p,allow_pickle=False) as z:
            h=z['history'].copy(); lp=z['logs'].copy(); a=z['accepted'].copy()
            c=json.loads(z['contract'].item())
            assert list(h.shape)==rec['shape'] and np.isfinite(h).all() and np.isfinite(lp).all()
            assert np.array_equal(h[-1],z['position']) and np.array_equal(lp[-1],z['logp'])
            assert h.shape[:2]==a.shape==lp.shape
            names=c['names']; lo=np.array([c['priors'][k][0] for k in names]);hi=np.array([c['priors'][k][1] for k in names])
            assert np.all(h>=lo) and np.all(h<=hi)
            source_records.append(dict(Year=y,Phase=ph,Ensemble=e,Archive_relative_path=rec['path'],
                Delivered_relative_path=str(dest.relative_to(ROOT)),SHA256=digest,Shape=str(h.shape),
                Finite=True,Endpoint_match=True,Within_recorded_support=True))
            key=(y,ph); arrays.setdefault(key,[]).append(h);logs.setdefault(key,[]).append(lp)
            acceptance.setdefault(key,[]).append(a);contracts.setdefault(key,[]).append(c)
        write_json(dest.with_suffix('.contract.json'),c)
    save('Checkpoint_integrity',source_records)
    summaries=[]; walker_groups=[]; param_rows=[]; ensemble_rows=[]; ac_rows=[]; tau_rows=[]
    prefix_rows=[]; func_rows=[]; windows=[]; pair_rows=[]; matrices=[]; block_rows=[]; prior_rows=[]
    burn_sensitivity=[]; source_checks=[]; evidence=[]; bounds=[]; ensemble_tests=[]
    for (y,ph),raw in arrays.items():
        raw=np.stack(raw); lp=np.stack(logs[y,ph]); a=np.stack(acceptance[y,ph])
        cs=contracts[y,ph]; c=cs[0]; names=c['names']; E,T,W,D=raw.shape
        for other in cs[1:]:
            assert {k:v for k,v in c.items() if k!='ensemble'}=={k:v for k,v in other.items() if k!='ensemble'}
        tt=np.stack([tau(x) for x in raw]); b=int(np.ceil(5*tt.max())); ret=raw[:,b:]
        old=original_sampling.query('Year==@y and Phase==@ph').iloc[0]
        assert b==old.Integer_group_burn
        assert np.isclose(tt.max(),old.Group_max_tau,rtol=1e-9)
        z=ret.reshape(-1,D); sd=z.std(0,ddof=1)
        cp=np.corrcoef(z.T); sp=spearmanr(z,axis=0).statistic
        vals=np.linalg.eigvalsh(cp)
        matrices.append(dict(Year=y,Phase=ph,Correlation_condition_number=vals[-1]/vals[0],
            Smallest_eigenvalue=vals[0],Largest_eigenvalue=vals[-1],Effective_correlation_rank=np.sum(vals)**2/np.sum(vals**2)))
        for i in range(D):
            for j in range(D):
                pair_rows.append(dict(Year=y,Phase=ph,Parameter_1=names[i],Parameter_2=names[j],
                    Pearson_r=cp[i,j],Spearman_r=sp[i,j],N_correlated_rows=len(z)))
        group=[]
        if E>=4:
            for w in range(W):
                for j,k in enumerate(names):
                    d=diag(ret[:,:,w,j]); d.update(Year=y,Phase=ph,Walker_index=w,Parameter=k)
                    walker_groups.append(d);group.append(d)
            gd=pd.DataFrame(group)
        else: gd=pd.DataFrame()
        for j,k in enumerate(names):
            dist,kind=prior_dist(c,k);lo,hi=c['priors'][k];width=hi-lo
            vv=z[:,j]; q=np.quantile(vv,[.025,.25,.5,.75,.975]); prior_sd=float(dist.std())
            prior_rows.append(dict(Year=y,Phase=ph,Parameter=k,Prior_family=kind,Lower=lo,Upper=hi,
                Gaussian_center=c['center'][k] if kind=='truncated_normal' else np.nan,
                Gaussian_scale=c['prior_sd'][k] if kind=='truncated_normal' else np.nan,
                Truncated_prior_mean=dist.mean(),Truncated_prior_SD=prior_sd,
                Prior_lower_1pct_mass=dist.cdf(lo+.01*width),Prior_upper_1pct_mass=1-dist.cdf(hi-.01*width)))
            means=ret[:,:,:,j].mean((1,2));n=ret.shape[1];half=n//2
            early=ret[:,:half,:,j].mean((1,2));late=ret[:,-half:,:,j].mean((1,2))
            rr=gd[gd.Parameter==k] if E>=4 else None
            row=dict(Year=y,Phase=ph,Parameter=k,Ensembles=E,Burn_in=b,Retained_steps=n,
                Correlated_rows=len(vv),Mean=vv.mean(),SD=sd[j],Median=q[2],P025=q[0],P975=q[-1],
                Prior_low=lo,Prior_high=hi,Prior_family=kind,SD_over_prior_SD=sd[j]/prior_sd,
                Central95_width_over_prior95_width=(q[-1]-q[0])/(dist.ppf(.975)-dist.ppf(.025)),
                Lower_1pct_mass=np.mean(vv<=lo+.01*width),Upper_1pct_mass=np.mean(vv>=hi-.01*width),
                Upper_5pct_mass=np.mean(vv>=hi-.05*width),Lower_5pct_mass=np.mean(vv<=lo+.05*width),
                Mean_distance_from_nearest_bound_in_SD=min(vv.mean()-lo,hi-vv.mean())/sd[j],
                Ensemble_mean_span_SD=np.ptp(means)/sd[j] if E>1 else np.nan,
                Pooled_half_shift_SD=(late.mean()-early.mean())/sd[j],
                Max_absolute_ensemble_half_shift_SD=max(abs(late-early))/sd[j],
                Tau_max=tt[:,j].max(),Raw_steps_over_tau=T/tt[:,j].max(),
                Rhat_max=rr.Rhat.max() if E>=4 else np.nan,
                Rhat_median=rr.Rhat.median() if E>=4 else np.nan,
                Rhat_p90=rr.Rhat.quantile(.9) if E>=4 else np.nan,
                Fraction_groups_Rhat_below_1_01=np.mean(rr.Rhat<1.01) if E>=4 else np.nan,
                ESS_bulk_min=rr.ESS_bulk.min() if E>=4 else np.nan,
                ESS_bulk_median=rr.ESS_bulk.median() if E>=4 else np.nan,
                ESS_tail_min=rr.ESS_tail.min() if E>=4 else np.nan)
            param_rows.append(row)
            # Ensemble-level moments and fixed CDF indicators are functions of a
            # Markov-state vector, so 4 independently seeded ensembles remain
            # independent time series. Passing these does not replace marginal
            # matched-walker checks, and ESS here belongs to that functional only.
            if E>=4:
                series={'mean':ret[:,:,:,j].mean(2),'SD':ret[:,:,:,j].std(2)}
                for prob in [.1,.5,.9]:
                    v=np.quantile(vv,prob)
                    series[f'CDF_at_pooled_q{int(100*prob):02d}']=(ret[:,:,:,j]<=v).mean(2)
                for label,series_x in series.items():
                    func_rows.append(dict(Year=y,Phase=ph,Parameter=k,Functional=label,**diag(series_x)))
            for e in range(E):
                v=ret[e,:,:,j].ravel(); dd=raw[e,:,:,j]
                ensemble_rows.append(dict(Year=y,Phase=ph,Ensemble=e+1,Parameter=k,
                    Mean=v.mean(),Median=np.median(v),SD=v.std(ddof=1),P025=np.quantile(v,.025),P975=np.quantile(v,.975),
                    Half_shift_SD=(late[e]-early[e])/sd[j],First_step_prior_width_SD=dd[0].std()/width,
                    Last_500_minus_previous_500_SD=(dd[-500:].mean()-dd[-1000:-500].mean())/sd[j]))
                tau_rows.append(dict(Year=y,Phase=ph,Ensemble=e+1,Parameter=k,Tau=tt[e,j],
                    Raw_steps_over_tau=T/tt[e,j],Length_reference_50_tau=50*tt[e,j]))
                # ACF: average of individually centered per-walker ACFs; no
                # assertion that walkers are independent.
                tr=ret[e,:,:,j].T;tr=tr-tr.mean(1,keepdims=True)
                fft=np.fft.rfft(tr,n=2*tr.shape[1],axis=1)
                ac=np.fft.irfft(fft*fft.conj(),n=2*tr.shape[1],axis=1)[:,:tr.shape[1]]
                ac=ac/ac[:,[0]];av=ac.mean(0)
                for lag in range(0,301,5):
                    ac_rows.append(dict(Year=y,Phase=ph,Ensemble=e+1,Parameter=k,Lag=lag,Mean_within_walker_ACF=av[lag]))
                for t in range(0,T,50):
                    qwin=dd[t:t+50].ravel()
                    windows.append(dict(Year=y,Phase=ph,Ensemble=e+1,Parameter=k,Step_midpoint=t+25,
                        Block_start=t,Block_end=min(t+50,T),Mean=qwin.mean(),Median=np.median(qwin),
                        P10=np.quantile(qwin,.1),P90=np.quantile(qwin,.9)))
            for e in range(E):
                for block in range(4):
                    start=b+block*(T-b)//4;end=b+(block+1)*(T-b)//4
                    v=raw[e,start:end,:,j].ravel()
                    block_rows.append(dict(Year=y,Phase=ph,Ensemble=e+1,Parameter=k,Retained_quarter=block+1,
                        Start_step=start,End_step=end,Mean=v.mean(),SD=v.std(),Lower_1pct_mass=np.mean(v<=lo+.01*width),
                        Upper_1pct_mass=np.mean(v>=hi-.01*width)))
        for e in range(E):
            acc=a[e].mean(0);postacc=a[e,b:].mean(0)
            ensemble_tests.append(dict(Year=y,Phase=ph,Ensemble=e+1,Acceptance_mean=acc.mean(),
                Acceptance_min=acc.min(),Acceptance_max=acc.max(),Postburn_acceptance_mean=postacc.mean(),
                Walkers_zero_postburn_accepts=int(np.sum(a[e,b:].sum(0)==0)),
                Longest_postburn_rejection_run=max(rejection_run(a[e,b:,w]) for w in range(W)),
                Mean_logp_first100=lp[e,:100].mean(),Mean_logp_last500=lp[e,-500:].mean()))
        for length in [500,1000,1500,2000]:
            prefix=raw[:,:length]; pt=np.stack([tau(v) for v in prefix]);pb=int(np.ceil(5*pt.max()))
            for j,k in enumerate(names):
                prefix_rows.append(dict(Year=y,Phase=ph,Parameter=k,Prefix_steps=length,Tau_max=pt[:,j].max(),
                    Prefix_steps_over_tau=length/pt[:,j].max(),Suggested_burn_prefix=pb,
                    Note='Finite-chain estimate, not a validated stopping-length prediction'))
        # Equal postburn windows allow sensitivity to discard length, never
        # selected post hoc to make a convergence pass.
        if E>=4:
            for discard in [b,1000]:
                for j,k in enumerate(names):
                    qq=[diag(raw[:,discard:,w,j]) for w in range(W)]
                    burn_sensitivity.append(dict(Year=y,Phase=ph,Parameter=k,Discard_steps=discard,
                        Rhat_max=max(v['Rhat'] for v in qq),Rhat_median=np.median([v['Rhat'] for v in qq]),
                        ESS_bulk_min=min(v['ESS_bulk'] for v in qq),Mean=raw[:,discard:,:,j].mean()))
        else:
            for j,k in enumerate(names):
                for discard in [b,1000]:
                    burn_sensitivity.append(dict(Year=y,Phase=ph,Parameter=k,Discard_steps=discard,
                        Rhat_max=np.nan,Rhat_median=np.nan,ESS_bulk_min=np.nan,Mean=raw[:,discard:,:,j].mean()))
        paramdf=pd.DataFrame(param_rows).query('Year==@y and Phase==@ph')
        summaries.append(dict(Year=y,Phase=ph,Independent_ensembles=E,Walkers_per_ensemble=W,
            Steps_per_walker=T,Correlated_stored_rows=E*T*W,Burn_in=b,Retained_correlated_rows=ret.size//D,
            Max_tau=tt.max(),Steps_over_max_tau=T/tt.max(),Length_reference_50tau=50*tt.max(),
            Meets_50tau_reference=bool(T>=50*tt.max()),Acceptance_mean=a.mean(),
            Acceptance_min=a.mean(1).min(),Acceptance_max=a.mean(1).max(),
            Worst_matched_walker_Rhat=paramdf.Rhat_max.max() if E>=4 else np.nan,
            Worst_matched_walker_bulk_ESS=paramdf.ESS_bulk_min.min() if E>=4 else np.nan,
            Status='STRICT_CRITERIA_NOT_MET' if ph==1 else 'SINGLE_ENSEMBLE_INDEPENDENT_RHAT_UNAVAILABLE',
            Largest_absolute_half_drift_SD=paramdf.Max_absolute_ensemble_half_shift_SD.max(),
            Largest_ensemble_mean_span_SD=paramdf.Ensemble_mean_span_SD.max() if E>=4 else np.nan,
            Largest_boundary_1pct_mass=max(paramdf.Lower_1pct_mass.max(),paramdf.Upper_1pct_mass.max())))
        # Retained samples for joint figures are phase-specific only.
        thin=ret[:,::8].reshape(E,-1,D)
        np.savez_compressed(ROOT/'source'/f'{y}'/f'phase{ph}_figure_samples.npz',
            samples=thin,names=np.asarray(names),burn_in=b,within_walker_stride=8,
            note='Deterministic plot subsample; not independent samples; no cross-phase matching')
        print(f'{y} phase {ph}: burn={b}, max tau={tt.max():.2f}, ensembles={E}',flush=True)
    tables={
        'Sampling_and_convergence_summary':summaries,'Parameter_diagnostics':param_rows,
        'Matched_walker_groups':walker_groups,'Independent_ensemble_summaries':ensemble_rows,
        'Ensemble_functional_diagnostics':func_rows,'Within_walker_ACF':ac_rows,
        'Tau_by_ensemble':tau_rows,'Tau_prefix_sensitivity':prefix_rows,
        'Trace_blocks_50_steps':windows,'Retained_quarter_summaries':block_rows,
        'Phase_specific_correlations':pair_rows,'Correlation_eigenstructure':matrices,
        'Recorded_prior_distributions':prior_rows,'Burnin_sensitivity':burn_sensitivity,
        'Acceptance_and_rejections':ensemble_tests}
    for name,rows in tables.items(): tables[name]=save(name,rows)
    # Cross-year comparisons do not assume one true shared parameter or identical priors.
    shifts=[];pr=tables['Parameter_diagnostics']
    for ph,names in [(1,P1),(2,P2)]:
        for k in names:
            for aidx,ya in enumerate(YEARS):
                for yb in YEARS[aidx+1:]:
                    x=pr.query('Year==@ya and Phase==@ph and Parameter==@k').iloc[0]
                    z=pr.query('Year==@yb and Phase==@ph and Parameter==@k').iloc[0]
                    shifts.append(dict(Phase=ph,Parameter=k,Year_A=ya,Year_B=yb,
                        Mean_difference_B_minus_A=z.Mean-x.Mean,
                        Difference_over_pooled_SD=(z.Mean-x.Mean)/np.sqrt((x.SD**2+z.SD**2)/2),
                        Empirical_central95_intervals_overlap=bool(max(x.P025,z.P025)<=min(x.P975,z.P975)),
                        Same_recorded_prior=contracts[ya,ph][0]['priors'][k]==contracts[yb,ph][0]['priors'][k]
                          and contracts[ya,ph][0]['normal_priors']==contracts[yb,ph][0]['normal_priors'],
                        Interpretation='Descriptive annual difference; not parameter bias or hypothesis test'))
    tables['Cross_year_descriptive_shifts']=save('Cross_year_descriptive_shifts',shifts)
    with pd.ExcelWriter(ROOT/'tables/Original_MCMC_diagnostics.xlsx',engine='openpyxl') as writer:
        for name,df in tables.items():df.to_excel(writer,sheet_name=name[:31],index=False)
        pd.DataFrame(source_records).to_excel(writer,sheet_name='Checkpoint_integrity',index=False)
    for name,df in tables.items():
        if name=='Trace_blocks_50_steps':continue
        assert not np.isinf(df.select_dtypes(include='number').to_numpy()).any(),name
    versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','pandas','arviz','emcee','matplotlib','python-docx']}
    write_json(ROOT/'verification/COMPUTATION.json',dict(
        Original_checkpoint_count=len(source_records),Original_rows=sum(np.prod(r['shape'][:2]) for r in manifest),
        Checkpoint_SHA256_all_match=True,New_MCMC_steps=0,New_model_calls=0,Original_priors_changed=False,
        Original_physics_changed=False,Stages_pooled_into_8D_joint_posterior=False,
        Diagnostics_backend='ArviZ rank-normalized folded split Rhat and bulk/tail ESS',
        Independent_replication_unit='Ensemble, not individual walkers',
        Phase1_diagnostic_groups='Four independent time series for each fixed walker index; 32 groups are dependent and their ESS are never summed',
        Phase2_Rhat='Not computed: only one independent ensemble',
        Summary_source='Original full checkpoints, all time ordering preserved',
        Versions=versions,Python=sys.version,Runtime_seconds=time.time()-t0))
    print(tables['Sampling_and_convergence_summary'].to_string(index=False),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,default=DEFAULT_ARCHIVE)
    main(parser.parse_args().archive)
