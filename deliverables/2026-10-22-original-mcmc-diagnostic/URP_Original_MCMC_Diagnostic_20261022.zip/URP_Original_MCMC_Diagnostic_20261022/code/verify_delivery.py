"""Verify provenance and reproducibility, not a declaration of convergence."""
from pathlib import Path
import hashlib,json,zipfile
import numpy as np
import pandas as pd
import fitz
from docx import Document
ROOT=Path(__file__).resolve().parents[1]
def load(n):return pd.read_csv(ROOT/'tables'/f'{n}.csv')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks={}
m=json.loads((ROOT/'source/FORMAL_MCMC_CHECKPOINTS.json').read_text())
counts=0
for r in m:
    p=ROOT/'source'/str(r['Year'])/f"phase{r['Phase']}"/Path(r['path']).name
    assert sha(p)==r['sha256']
    with np.load(p,allow_pickle=False) as z:
        h=z['history'];c=json.loads(z['contract'].item());assert list(h.shape)==r['shape']
        assert np.isfinite(h).all() and np.isfinite(z['logs']).all()
        assert np.array_equal(h[-1],z['position'])
        counts+=h.shape[0]*h.shape[1]
        if r['Phase']==2:assert c['ensembles']==1
assert len(m)==20 and counts==1280000
checks['Original_checkpoints']=20;checks['Original_correlated_rows']=counts
checks['All_original_checkpoint_hashes_match']=True
old=pd.read_csv(ROOT/'source/Original_diagnostic_reference.csv')
new=load('Parameter_diagnostics')
z=old[old.Phase.eq(1)].merge(new,on=['Year','Phase','Parameter'],suffixes=('_old','_new'),validate='one_to_one')
assert len(z)==20
diffs={k:float(np.max(abs(z[k+'_old']-z[k+'_new']))) for k in ['Rhat_max','ESS_bulk_min','ESS_tail_min']}
assert max(diffs.values())<1e-8
checks['Reproduction_max_absolute_differences']=diffs
assert new[new.Phase.eq(2)].Rhat_max.isna().all()
assert load('Matched_walker_groups').shape[0]==640
assert set(load('Matched_walker_groups').Year)=={2019,2020,2021,2022}
assert load('Phase1_to_phase2_handoff').Absolute_difference.max()<1e-12
checks['Phase2_Rhat_not_manufactured']=True
checks['Phase1_mean_handoff_max_error']=float(load('Phase1_to_phase2_handoff').Absolute_difference.max())
assert load('Acceptance_and_rejections').Walkers_zero_postburn_accepts.sum()==0
checks['Walkers_with_no_postburn_acceptance']=0
figs=json.loads((ROOT/'figures/FIGURE_CAPTIONS_EN.json').read_text())
assert len(figs)==12
for stem in figs:
    assert (ROOT/'figures'/f'{stem}.png').is_file()
    with fitz.open(ROOT/'figures'/f'{stem}.pdf') as pdf:
        assert len(pdf)==1
        assert pdf[0].get_text().strip()
checks['English_figure_groups']=len(figs)
atlas=ROOT/'docs/Original_MCMC_English_Figure_Atlas.pdf'
with fitz.open(atlas) as pdf:assert len(pdf)==12
checks['Vector_atlas_pages']=12
doc=Document(ROOT/'docs/URP_Original_MCMC_Diagnostic_CN.docx')
assert len(doc.inline_shapes)==7 and len(doc.tables)==2
text='\n'.join(p.text for p in doc.paragraphs)
for s in ['1.181','1.174','1.124','1.122','22.14%','23.65%','不能证明']:
    # The report uses an expanded wording for the final limitation.
    if s=='不能证明':assert '不能证明第四类为零' in text
    else:assert s in text,s
checks['Word_figures']=len(doc.inline_shapes);checks['Word_three_line_tables']=len(doc.tables)
with zipfile.ZipFile(ROOT/'docs/URP_Original_MCMC_Diagnostic_CN.docx') as z:
    assert z.testzip() is None
with fitz.open(ROOT/'docs/URP_Original_MCMC_Diagnostic_CN.pdf') as pdf:
    assert len(pdf)>5
    checks['Report_PDF_pages']=len(pdf)
    for page in pdf:
        txt=page.get_text();assert '\ufffd' not in txt
checks['Purpose']='File integrity and exact diagnostic reproduction; scientific convergence is NOT asserted'
checks['Passed']=True
(ROOT/'verification/FINAL_QA.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(checks,ensure_ascii=False,indent=2))
