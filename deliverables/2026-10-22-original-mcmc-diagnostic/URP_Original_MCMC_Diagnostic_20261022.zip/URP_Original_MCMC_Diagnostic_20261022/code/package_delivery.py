"""Package the diagnostic supplement with file-by-file checksums."""
from pathlib import Path
import argparse,csv,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
DEFAULT_OUT=Path('/workspace/URP/deliverables/2026-10-22-original-mcmc-diagnostic')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main(out):
    out.mkdir(parents=True,exist_ok=True)
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '.cache' not in p.parts and '__pycache__' not in p.parts
                 and p.name not in ['FILE_MANIFEST.csv','SHA256SUMS.txt'])
    rows=[dict(Path=str(p.relative_to(ROOT)),Bytes=p.stat().st_size,SHA256=sha(p)) for p in files]
    with (ROOT/'FILE_MANIFEST.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['Path','Bytes','SHA256']);w.writeheader();w.writerows(rows)
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(f"{r['SHA256']}  {r['Path']}" for r in rows)+
                                    '\n'+sha(ROOT/'FILE_MANIFEST.csv')+'  FILE_MANIFEST.csv\n',encoding='utf-8')
    files+= [ROOT/'FILE_MANIFEST.csv',ROOT/'SHA256SUMS.txt']
    archive=out/'URP_Original_MCMC_Diagnostic_20261022.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for p in files:z.write(p,arcname='URP_Original_MCMC_Diagnostic_20261022/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for r in rows:
            assert hashlib.sha256(z.read('URP_Original_MCMC_Diagnostic_20261022/'+r['Path'])).hexdigest()==r['SHA256']
    for p in [ROOT/'docs/URP_Original_MCMC_Diagnostic_CN.docx',ROOT/'docs/URP_Original_MCMC_Diagnostic_CN.pdf',
              ROOT/'docs/Original_MCMC_English_Figure_Atlas.pdf',ROOT/'tables/Original_MCMC_diagnostics.xlsx',
              ROOT/'docs/Diagnostic_summary_CN.md',ROOT/'docs/Figure_interpretations.md',ROOT/'verification/FINAL_QA.json']:
        shutil.copyfile(p,out/p.name)
    sums=[f'{sha(p)}  {p.name}' for p in sorted(out.iterdir()) if p.is_file() and p.suffix in ['.zip','.pdf','.docx','.xlsx']]
    (out/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n',encoding='utf-8')
    info=dict(File=archive.name,Bytes=archive.stat().st_size,SHA256=sha(archive),
              Included_files=len(files),Zip_CRC_and_all_manifest_hashes_pass=True,
              Source_raw_checkpoints=20,Original_state_rows=1280000,New_model_calls=0,New_MCMC_steps=0)
    (out/'PACKAGE_VERIFICATION.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
    print(json.dumps(info,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=DEFAULT_OUT);main(p.parse_args().out)
