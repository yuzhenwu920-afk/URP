# 四年原始 MCMC 链诊断（2026-10-22）

本轮只诊断原链并归纳原因，不改参数域、不改模型、不新增 MCMC。

**主结论**：四年第一阶段均未达到原严格收敛标准；第二阶段每年仅一个独立 ensemble，独立重复链收敛诊断不可计算。链长与自相关时间不匹配是直接信号，后期冠层信息薄弱、局部边界堆积和条件第二阶段 WP–HI 补偿提供进一步解释。没有发现所有 walkers 卡死、参数超域或阶段均值传递错误。不能证明参数无偏，也不能把未收敛直接等同于所有参数有偏。

## 文件

- `docs/URP_Original_MCMC_Diagnostic_CN.docx`：中文完整诊断、原因证据等级、论文可用表述、下一步建议。
- `docs/URP_Original_MCMC_Diagnostic_CN.pdf`：同版 PDF。
- `docs/Diagnostic_summary_CN.md`：快速阅读。
- `docs/Original_MCMC_English_Figure_Atlas.pdf`：12 页英文矢量图册。
- `docs/Figure_interpretations.md`：每图英文图注与中文解析。
- `tables/Original_MCMC_diagnostics.xlsx`：全部指标与取证表；相同内容另存为 CSV。
- `figures/`：12 组 300 dpi PNG 与矢量 PDF，覆盖 2019、2020、2021、2022。
- `source/2019` 至 `source/2022`：20 份原始正式 NPZ、原合同、匹配代码、观测证据输入。每一原链包含全部 2000 步和 32 个 walkers，不是仅提供抽稀样本。
- `verification/`：完整性与重算核验。

第一阶段独立单位为四个 ensemble；32 个 matched-walker 诊断组相互依赖，ESS 不相加，也不是全部存储行的总 ESS。第二阶段不把 walkers 当独立链，R̂ 保留为空。

5 维第一阶段与 3 维条件第二阶段分别诊断，不拼成 8 维后验，不合并四年为共享参数后验。2022 采用不同先验，须分别解读。

## 复算

Python 3.12，安装 `requirements.txt` 后：

```bash
python code/diagnose_original.py --archive /path/to/nonexistent
python code/make_figures.py
python code/build_report.py
```

第一条在原完整归档不存在时自动读取本包 `source/`。若原归档存在，可显式传入其根目录。本轮不运行 AquaCrop，不运行 MCMC，只读取已保存历史；无需 aquacrop 依赖。`collect_source_evidence.py` 是原归档取证脚本，结果与对应证据文件已附带。

使用 LibreOffice 将 Word 转为 PDF（不需要修改文档内容）。`code/verify_delivery.py` 检查原链哈希、已有诊断的数值复现、图表与报告，不以“通过收敛”为文件校验的通过条件。

本轮未重放原模型似然；链/合同的完整性核验不构成对原物理实现的完整认证。所有原正式计算与此前论文均保留，本轮为独立诊断补充。
