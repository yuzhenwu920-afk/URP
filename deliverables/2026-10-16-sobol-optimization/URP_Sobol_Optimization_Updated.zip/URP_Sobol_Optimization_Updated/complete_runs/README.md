# 完整计算结果的无损数值封装

原始逐次响应和全部种群数值均保留，没有截断小数、降低精度或删除样本。

Sobol：design.npy为全部八参数设计；all_response_columns.npz逐列保存原JSON响应（各灌水事件量展开为列），LOSSLESS_REPACK.json记录原事件日期/阶段与源文件哈希；response_matrix.npy为六主输出。N128和N512均保留，NESTED_REUSE.json说明完全相同前缀的精确复用。

优化：all_evaluations_columns.npz包含100代内全部新评估的水量账和输出；all_generations.npz包含Generation、X、F、G、CV，每个数组首维是代数。与逐代原件逐位核对通过；固定参数、变量映射、预算和约束见run.json。

读取逐次响应：from read_complete_results import load_columns; df=load_columns(path)。或运行 python read_complete_results.py archive.npz --csv responses.csv。部分浮点列用XOR无损编码压缩，解码后逐位恢复原始float64；这仅是文件存储，不参与科学模型计算，也不近似任何响应。字符串和布尔列保持相应类型。逐代all_generations.npz可直接用np.load读取。

所有COMPLETE均指计算完成；Sobol筛查稳定性另见scramble_checks.csv。MCMC原严格收敛限制没有因本轮计算而解除。
