﻿# 2022 Sobol 与 NSGA III 后续分析工作包

这是 2022 年从冻结模型、Phase1、Phase2 到后续真实模型 Sobol 和 NSGA III 的集中工作目录。

## 推荐顺序

1. `01_frozen_model`：确认正式模型脚本及依赖。
2. `02_phase1_results`：阶段一完整结果归档。
3. `03_phase2_complete`：阶段二一键程序、2000 步链、诊断和均值模型。
4. `04_phase2_review`：最终复核表、图和结果说明。
5. `05_downstream_inputs`：后续分析使用的参数向量、区间、诊断和审计门。
6. `06_real_model_sobol`：真实 Modified DI 模型 Sobol 程序。
7. `07_nsga3_method`：NSGA III 方法与 2022 启动规格。
8. `08_provenance`：文件哈希和包信息。

## Phase2 状态

- 32 walkers × 2000 steps 已完成。
- burn-in 163；τ约 30.39、31.46、32.58。
- WP early 13.8601，WP late 31.4977，HI0 0.40132。
- 推断是条件于 Phase1 代表点的第二阶段结果，不是八参数联合后验。

## Sobol 第一次正式运行

先使用 `06_real_model_sobol/input_spaces` 中的 2022 global physical prior。建议从 N=128 和三个随机种子开始；若排序或置信区间不稳定，再提高至 N=512。local marginal 95 range 只能作为局部响应敏感性补充。

## 重要边界

代理模型只可用于预筛选，最终 Sobol 指数和 Pareto 候选必须由真实 Modified DI 模型产生。
