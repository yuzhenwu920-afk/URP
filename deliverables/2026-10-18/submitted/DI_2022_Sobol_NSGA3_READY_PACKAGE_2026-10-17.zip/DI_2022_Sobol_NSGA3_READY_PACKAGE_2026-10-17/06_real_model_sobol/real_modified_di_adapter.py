from __future__ import annotations

import copy
import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd


class RealModifiedDIAdapter:
    """Unified, cached interface to the four audited annual Modified DI models."""

    def __init__(self, pycharm_root: str | Path, audit_output: str | Path):
        self.pycharm_root = Path(pycharm_root).resolve()
        self.audit_output = Path(audit_output).resolve()
        self.audit_output.mkdir(parents=True, exist_ok=True)
        self._state: dict[int, dict] = {}

    def _load(self, year: int) -> dict:
        if year in self._state:
            return self._state[year]
        source = self.pycharm_root / f"DI_{year}_OneClick" / f"DI_{year}_MCMC_ONE_CLICK.py"
        if not source.is_file():
            raise FileNotFoundError(source)
        spec = importlib.util.spec_from_file_location(f"di_{year}_formal_adapter", source)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        for name in ["sampler", "diagnostics", "audit_hooks", "ensemble_pipeline"]:
            module._embedded_module(name)
        runner = module._embedded_module("runner")
        model, data, start, folder = runner.load(str(year), self.audit_output / str(year))
        state = {"module": module, "runner": runner, "model": model, "data": data, "start": start, "folder": folder}
        self._state[year] = state
        return state

    def prior_bounds(self, year: int) -> dict[str, tuple[float, float]]:
        return dict(self._load(year)["model"].PRIOR_BOUNDS)

    def simulate(self, params: dict, year: int, irrigation=None, mode: str = "DI") -> dict:
        state = self._load(year)
        model, data = state["model"], state["data"]
        full = dict(state["start"], **params)
        if irrigation is not None:
            data = copy.copy(data)
            data["schedule"] = pd.DataFrame(irrigation, columns=["Date", "Depth"])
            data["schedule"]["Date"] = pd.to_datetime(data["schedule"]["Date"])
            data["schedule"]["Depth"] = pd.to_numeric(data["schedule"]["Depth"], errors="raise")
        summary, growth, cc_pairs, biomass_pairs = model.simulate(data, full, mode)
        irrigation_mm = float(summary["Irrigation_mm"])
        y13 = float(summary["Y_13pct"])
        result = dict(summary)
        result.update(
            {
                "B_t_ha": float(summary["B_last"]),
                "Irr_mm": irrigation_mm,
                "WP_Irr_kg_m3": 100.0 * y13 / irrigation_mm if irrigation_mm > 0 else np.nan,
                "WP_ET_kg_m3": 100.0 * y13 / float(summary["ET_mm"]) if summary["ET_mm"] > 0 else np.nan,
            }
        )
        if abs(result["ET_mm"] - result["Tr_mm"] - result["Es_mm"]) > 1e-8:
            raise RuntimeError("ET identity failed")
        if abs(result["Water_balance_residual_mm"]) > 1e-8 or abs(result["Max_daily_balance_residual_mm"]) > 1e-8:
            raise RuntimeError("Water-balance audit failed")
        return result
