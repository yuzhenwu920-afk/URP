@echo off
set PYTHONUTF8=1
"C:\Users\Lenovo\PycharmProjects\PythonProject\.venv\Scripts\python.exe" "%~dp0REAL_MODIFIED_DI_SOBOL_ONE_CLICK.py"
pause
