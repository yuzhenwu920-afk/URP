from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
from scipy.stats import qmc


PARAMETERS = ["CCx", "CGC_CD", "CDC_CD", "SenescenceCD", "Kcb", "WP_early", "WP_late", "HI0"]
OUTPUTS = ["Y_13pct", "B_last", "Tr_mm", "Es_mm", "ET_mm", "MaxCC"]
TRACKS = ["global_physical_prior", "local_marginal_95_range"]
YEARS = [2019, 2020, 2021, 2022]
SEEDS = [101, 202, 303]


def atomic_json(path: Path, obj: object) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_problem(space_dir: Path, track: str, year: int) -> dict:
    path = space_dir / f"A10_SALib_problem_{track}_{year}.json"
    problem = json.loads(path.read_text(encoding="utf-8"))
    if problem["names"] != PARAMETERS or len(problem["bounds"]) != len(PARAMETERS):
        raise RuntimeError(f"Input-space contract mismatch: {path}")
    return problem


def make_design(problem: dict, n: int, seed: int) -> tuple[np.ndarray, np.ndarray, list[np.ndarray]]:
    if n < 4 or n & (n - 1):
        raise ValueError("--n-base must be a power of two and at least 4")
    unit = qmc.Sobol(d=2 * len(PARAMETERS), scramble=True, seed=seed).random_base2(int(math.log2(n)))
    bounds = np.asarray(problem["bounds"], dtype=float)
    lo, hi = bounds[:, 0], bounds[:, 1]
    a = lo + unit[:, : len(PARAMETERS)] * (hi - lo)
    b = lo + unit[:, len(PARAMETERS) :] * (hi - lo)
    ab = []
    for j in range(len(PARAMETERS)):
        x = a.copy()
        x[:, j] = b[:, j]
        ab.append(x)
    return a, b, ab


def estimators(ya: np.ndarray, yb: np.ndarray, yab: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    variance = float(np.var(np.concatenate([ya, yb]), ddof=1))
    if not np.isfinite(variance) or variance <= 0:
        raise RuntimeError("Output variance is zero or non-finite")
    s1 = np.mean(yb[:, None] * (yab - ya[:, None]), axis=0) / variance
    st = 0.5 * np.mean((ya[:, None] - yab) ** 2, axis=0) / variance
    return s1, st, variance


def bootstrap_ci(
    ya: np.ndarray, yb: np.ndarray, yab: np.ndarray, seed: int, repeats: int = 500
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    n, d = yab.shape
    s1_boot = np.empty((repeats, d))
    st_boot = np.empty((repeats, d))
    for r in range(repeats):
        idx = rng.integers(0, n, n)
        s1_boot[r], st_boot[r], _ = estimators(ya[idx], yb[idx], yab[idx])
    return (
        np.quantile(s1_boot, 0.025, axis=0),
        np.quantile(s1_boot, 0.975, axis=0),
        np.quantile(st_boot, 0.025, axis=0),
        np.quantile(st_boot, 0.975, axis=0),
    )


def evaluate_experiment(adapter, year: int, design: np.ndarray, checkpoint: Path, save_every: int) -> np.ndarray:
    n = len(design)
    values = np.full((n, len(OUTPUTS)), np.nan, dtype=float)
    start = 0
    if checkpoint.is_file():
        old = np.load(checkpoint)
        if tuple(old["values"].shape) == tuple(values.shape):
            values[:] = old["values"]
            done = np.flatnonzero(np.isfinite(values).all(axis=1))
            start = int(done[-1] + 1) if done.size and np.array_equal(done, np.arange(done[-1] + 1)) else 0
    for i in range(start, n):
        params = dict(zip(PARAMETERS, map(float, design[i])))
        result = adapter.simulate(params, year)
        values[i] = [float(result[k]) for k in OUTPUTS]
        if (i + 1) % save_every == 0 or i + 1 == n:
            np.savez_compressed(checkpoint, values=values)
            print(f"{year}: {i + 1}/{n}", flush=True)
    if not np.isfinite(values).all():
        raise RuntimeError(f"Non-finite output in {checkpoint}")
    return values


def write_rows(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def parse_int_list(text: str) -> list[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def parse_str_list(text: str) -> list[str]:
    return [x.strip() for x in text.split(",") if x.strip()]


def main() -> None:
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Four-year real Modified DI Sobol screening with checkpoints")
    parser.add_argument("--project-root", type=Path, default=Path(r"C:\Users\Lenovo\PycharmProjects\PythonProject"))
    parser.add_argument("--adapter", type=Path, default=here / "real_modified_di_adapter.py")
    parser.add_argument("--space-dir", type=Path, default=here / "input_spaces")
    parser.add_argument("--output", type=Path, default=here / "real_sobol_results")
    parser.add_argument("--n-base", type=int, default=128)
    parser.add_argument("--years", default="2019,2020,2021,2022")
    parser.add_argument("--tracks", default=",".join(TRACKS))
    parser.add_argument("--seeds", default=",".join(map(str, SEEDS)))
    parser.add_argument("--save-every", type=int, default=10)
    args = parser.parse_args()

    years = parse_int_list(args.years)
    tracks = parse_str_list(args.tracks)
    seeds = parse_int_list(args.seeds)
    if any(y not in YEARS for y in years) or any(t not in TRACKS for t in tracks):
        raise ValueError("Unsupported year or track")

    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    checkpoint_dir = out / "checkpoints"
    checkpoint_dir.mkdir(exist_ok=True)

    import importlib.util

    spec = importlib.util.spec_from_file_location("real_modified_di_adapter", args.adapter.resolve())
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    adapter = module.RealModifiedDIAdapter(args.project_root, out / "adapter_audit")

    plan = {
        "status": "RUNNING",
        "model": "real Modified DI AquaCrop-OSPy annual sources",
        "interpretation": "independent-input response sensitivity; not joint-posterior Sobol",
        "n_base": args.n_base,
        "years": years,
        "tracks": tracks,
        "seeds": seeds,
        "parameters": PARAMETERS,
        "outputs": OUTPUTS,
        "sample_count_per_experiment": args.n_base * (len(PARAMETERS) + 2),
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "experiments_complete": 0,
        "experiments_total": len(years) * len(tracks) * len(seeds),
    }
    atomic_json(out / "run_status.json", plan)
    rows: list[dict] = []
    try:
        for year in years:
            baseline = adapter.simulate({}, year)
            if abs(float(baseline["Water_balance_residual_mm"])) > 1e-8:
                raise RuntimeError(f"Baseline water ledger failed for {year}")
            for track in tracks:
                problem = load_problem(args.space_dir, track, year)
                for seed in seeds:
                    a, b, ab = make_design(problem, args.n_base, seed)
                    design = np.vstack([a, b, *ab])
                    design_file = checkpoint_dir / f"design_{year}_{track}_N{args.n_base}_seed{seed}.npz"
                    np.savez_compressed(design_file, design=design)
                    response_file = checkpoint_dir / f"responses_{year}_{track}_N{args.n_base}_seed{seed}.npz"
                    response = evaluate_experiment(adapter, year, design, response_file, args.save_every)
                    n = args.n_base
                    ya, yb = response[:n], response[n : 2 * n]
                    yab = np.stack([response[(2 + j) * n : (3 + j) * n] for j in range(len(PARAMETERS))], axis=1)
                    for used_n in sorted(set([max(4, n // 2), n])):
                        for k, output in enumerate(OUTPUTS):
                            s1, st, var = estimators(ya[:used_n, k], yb[:used_n, k], yab[:used_n, :, k])
                            s1lo, s1hi, stlo, sthi = bootstrap_ci(
                                ya[:used_n, k], yb[:used_n, k], yab[:used_n, :, k], seed + 10000 + k + used_n
                            )
                            for j, parameter in enumerate(PARAMETERS):
                                rows.append(
                                    {
                                        "Year": year,
                                        "Track": track,
                                        "N_base": used_n,
                                        "Seed": seed,
                                        "Output": output,
                                        "Parameter": parameter,
                                        "S1": s1[j],
                                        "S1_CI_low": s1lo[j],
                                        "S1_CI_high": s1hi[j],
                                        "ST": st[j],
                                        "ST_CI_low": stlo[j],
                                        "ST_CI_high": sthi[j],
                                        "Output_variance": var,
                                        "Absolute_first_order_effect": s1[j] * var,
                                        "Absolute_total_effect": st[j] * var,
                                        "Model": "Real_Modified_DI",
                                        "Probability_space": "independent_uniform",
                                    }
                                )
                    plan["experiments_complete"] += 1
                    atomic_json(out / "run_status.json", plan)
                    write_rows(out / "real_model_sobol_indices.csv", rows)
        plan["status"] = "COMPLETE_REAL_MODEL_SCREENING"
        plan["completed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        plan["result_sha256"] = sha256(out / "real_model_sobol_indices.csv")
        atomic_json(out / "run_status.json", plan)
        print("COMPLETE_REAL_MODEL_SCREENING", flush=True)
    except Exception as exc:
        plan["status"] = "FAILED_RESUMABLE"
        plan["error"] = repr(exc)
        atomic_json(out / "run_status.json", plan)
        raise


if __name__ == "__main__":
    main()
