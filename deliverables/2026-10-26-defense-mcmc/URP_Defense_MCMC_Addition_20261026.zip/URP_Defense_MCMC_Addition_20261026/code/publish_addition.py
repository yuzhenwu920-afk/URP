"""Deliver the preserved user deck and the single new MCMC diagnostic page."""
from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,urllib.request,zipfile
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'delivery';REPO=Path('/workspace/URP');DEST='deliverables/2026-10-26-defense-mcmc';BRANCH='delivery/urp-review-20261015'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(REPO),*a]).decode().strip()
def run(*a):subprocess.run(['git','-C',str(REPO),*a],check=True)
def main():
 qa=json.loads((ROOT/'analysis/PRESENTATION_QA.json').read_text());assert qa['Status']=='PASS'
 assert git('branch','--show-current')==BRANCH and not git('status','--porcelain')
 original_main=git('ls-remote','origin','refs/heads/main').split()[0]
 for p in (ROOT/'documents').iterdir():
  if p.is_file():shutil.copy2(p,OUT/p.name)
 shutil.copy2(ROOT/'analysis/Added_MCMC_Slide.png',OUT/'Added_MCMC_Slide.png')
 shutil.copy2(ROOT/'analysis/Preview_Main_Slides.jpg',OUT/'Preview_Main_Slides.jpg')
 shutil.copy2(ROOT/'analysis/PRESENTATION_QA.json',OUT/'PRESENTATION_QA.json')
 archive=OUT/'URP_Defense_MCMC_Addition_20261026.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for folder in ['source','data','figures','documents','code']:
   for p in sorted((ROOT/folder).rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts:z.write(p,'URP_Defense_MCMC_Addition_20261026/'+str(p.relative_to(ROOT)))
  for p,n in [(ROOT/'README.md','README.md'),(ROOT/'analysis/PRESENTATION_QA.json','analysis/PRESENTATION_QA.json'),(ROOT/'analysis/Added_MCMC_Slide.png','analysis/Added_MCMC_Slide.png')]:z.write(p,'URP_Defense_MCMC_Addition_20261026/'+n)
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 (OUT/'README.md').write_text('''# URP答辩：第4页后新增MCMC收敛性页（2026-10-26）

**[下载新版PPT](URP_Defense_5min_MCMC_20261026.pptx)** · [新增页单页预览](Added_MCMC_Convergence_Page_20261026.pdf) · [9页主讲PDF](URP_Defense_5min_MCMC_20261026.pdf) · [完整资料ZIP](URP_Defense_MCMC_Addition_20261026.zip)

以本次上传的修改版为底稿，原12页正文与原图全部保留。仅在第4页后新增1页，后续4个主讲页码顺延，备注与讲稿时间重新分配。现为9页主讲、4页隐藏备答，建议主讲合计300秒。

新增页展示2021年原始采样轨迹和四年第一阶段Rhat/bulk ESS汇总，明确“参数中心较稳定，严格收敛判据尚待满足”。使用普通字符与大字排版，无新增MCMC计算。

[更新讲稿Word](URP_Defense_Speaker_Script_MCMC_20261026.docx) · [讲稿PDF](URP_Defense_Speaker_Script_MCMC_20261026.pdf) · [含备答13页PDF](URP_Defense_5min_MCMC_With_Backup_20261026.pdf) · [保全与排版核验](PRESENTATION_QA.json)

![新增MCMC页](Added_MCMC_Slide.png)

完整ZIP含上传底稿原字节副本、新版PPT/PDF、讲稿、原链代表轨迹、原诊断汇总、检查点来源哈希、绘图与插页代码。原12页XML按原字节恢复，仅替换旧第5至8页的页码；原有5个媒体文件逐字节一致。
''')
 files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt')
 (OUT/'SHA256SUMS.txt').write_text('\n'.join(f'{sha(p)}  {p.name}' for p in files)+'\n')
 shutil.copytree(OUT,REPO/DEST,dirs_exist_ok=True)
 for p,prefix in [(REPO/'README.md','deliverables/'),(REPO/'deliverables/README.md','')]:
  old=p.read_text().replace('最新：URP五分钟答辩大字精简版（2026-10-25）','此前：URP五分钟答辩大字精简版（2026-10-25）')
  first,rest=old.split('\n',1);entry=f'**[最新：保留用户改稿，在第4页后新增MCMC收敛性页（2026-10-26）]({prefix}2026-10-26-defense-mcmc/)**：9页主讲、4页隐藏备答，附真实采样轨迹、四年诊断、更新讲稿和300秒安排。\n\n';p.write_text(first+'\n\n'+entry+rest.lstrip())
 run('add','-f','--',DEST,'README.md','deliverables/README.md');run('-c','gc.auto=0','commit','-m','Preserve user-edited defense and insert original-chain convergence diagnostic after slide four');run('-c','pack.window=0','-c','gc.auto=0','push','origin','HEAD:refs/heads/'+BRANCH)
 head=git('rev-parse','HEAD');base='https://raw.githubusercontent.com/yuzhenwu920-afk/URP/'+head+'/'+DEST+'/'
 def check(p):
  target=ROOT/'analysis/remote_downloads'/p.name;target.parent.mkdir(exist_ok=True)
  with urllib.request.urlopen(urllib.request.Request(base+p.name,headers={'User-Agent':'URP-defense-check'}),timeout=60) as r,target.open('wb') as f:
   assert r.status==200;shutil.copyfileobj(r,f)
  assert sha(target)==sha(p)
  if p.suffix in ['.pptx','.docx','.zip']:
   with zipfile.ZipFile(target) as z:assert z.testzip() is None
  return {'File':p.name,'HTTP':200,'Bytes':p.stat().st_size,'SHA256':sha(p)}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:checks=list(pool.map(check,files))
 assert git('ls-remote','origin','refs/heads/main').split()[0]==original_main
 result={'Status':'PASS','Content_commit':head,'Source_input_SHA256':qa['User_edited_source_SHA256'],'Main_unchanged':original_main,'Main_slides':9,'Hidden_backups':4,'Planned_seconds':300,'Remote_downloads':checks}
 proof=ROOT/'analysis/REMOTE_DOWNLOAD_VERIFICATION.json';proof.write_text(json.dumps(result,ensure_ascii=False,indent=2));shutil.copy2(proof,REPO/DEST/proof.name)
 run('add','-f','--',DEST+'/REMOTE_DOWNLOAD_VERIFICATION.json');run('-c','gc.auto=0','commit','-m','Verify downloads of the user-preserving MCMC defense update');run('-c','gc.auto=0','push','origin','HEAD:refs/heads/'+BRANCH)
 print(json.dumps({'Status':'PASS','Content_commit':head,'Verification_commit':git('rev-parse','HEAD'),'Downloaded_files':len(checks),'PPTX':base+'URP_Defense_5min_MCMC_20261026.pptx','Added_page_PDF':base+'Added_MCMC_Convergence_Page_20261026.pdf','Main_PDF':base+'URP_Defense_5min_MCMC_20261026.pdf','ZIP':base+archive.name},ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
