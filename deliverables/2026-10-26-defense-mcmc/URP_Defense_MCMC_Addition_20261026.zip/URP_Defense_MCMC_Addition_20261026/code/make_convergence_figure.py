"""Plot actual original chain dynamics; do not infer convergence from appearance."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[1]
def main():
 d=pd.read_csv(ROOT/'data/2021_representative_raw_traces.csv')
 summary=pd.read_csv(ROOT/'data/Sampling_and_convergence_summary.csv')
 burn=int(summary[(summary.Year==2021)&(summary.Phase==1)].Burn_in.iloc[0])
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':15,'axes.labelsize':15,'axes.titlesize':16,'xtick.labelsize':13.5,'ytick.labelsize':13.5,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#819991','text.color':'#163D3B','axes.labelcolor':'#163D3B','axes.unicode_minus':False,'grid.alpha':.25,'pdf.fonttype':42,'svg.fonttype':'none'})
 fig,axs=plt.subplots(2,1,figsize=(7.7,4.35),layout='constrained',sharex=True)
 colors=['#25759B','#C28B36','#3D9279','#9564A5']
 for ax,parameter,title in zip(axs,['CGC_CD','CDC_CD'],['Canopy growth (CGC)','Canopy decline (CDC)']):
  ax.axvspan(0,burn,color='#D9E0DB',alpha=.48,lw=0)
  for e,c in zip(range(1,5),colors):
   s=d[(d.Parameter==parameter)&(d.Ensemble==e)].sort_values('Step')
   # Original stored states are plotted, without smoothing or pooling walkers.
   ax.plot(s.Step,s.Value,color=c,lw=.65,alpha=.68)
  ax.axvline(burn,color='#70857C',ls='--',lw=1)
  ax.set_title(title,loc='left',weight='bold',pad=6);ax.set(xlim=(0,2000));ax.grid(axis='y')
 fig.supylabel('Parameter value',fontsize=15)
 axs[-1].set_xlabel('Iteration');axs[-1].set_xticks([0,500,1000,1500,2000])
 handles=[Line2D([],[],color=c,lw=2,label=f'E{i}') for i,c in enumerate(colors,1)]
 fig.legend(handles=handles,loc='outside upper center',ncol=4,frameon=False,fontsize=13.5)
 for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'figures/MCMC_2021_Raw_Traces_EN.{ext}',dpi=330,bbox_inches='tight',facecolor='white')
 plt.close(fig)
 print('Raw trace figure saved; burn-in boundary',burn,flush=True)
if __name__=='__main__':main()
