"""Validate the one-page insertion and byte-level preservation of the user deck."""
from pathlib import Path
import json,re,hashlib,zipfile,xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import fitz
from PIL import Image,ImageDraw
from pptx import Presentation
ROOT=Path(__file__).resolve().parents[1]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def norm(s):return re.sub(r'\s+','',s)
def main():
 base=ROOT/'source/User_Edited_Base_20261026.pptx';out=ROOT/'documents/URP_Defense_5min_MCMC_20261026.pptx'
 meta=json.loads((ROOT/'data/PROVENANCE.json').read_text());assert sha(base)==meta['Base_uploaded_file_SHA256']
 with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
  assert b.testzip() is None
  for i in range(1,13):
   name=f'ppt/slides/slide{i}.xml';old=a.read(name);new=b.read(name)
   if 5<=i<=8:
    new=new.replace(f'<a:t>{i+1}</a:t>'.encode(),f'<a:t>{i}</a:t>'.encode(),1)
   assert new==old,('Original slide body changed',i)
   rel=f'ppt/slides/_rels/slide{i}.xml.rels';assert a.read(rel)==b.read(rel)
  media=[n for n in a.namelist() if n.startswith('ppt/media/') and not n.endswith('/')]
  for n in media:assert a.read(n)==b.read(n),n
 p=Presentation(out);assert len(p.slides)==13
 assert [s._element.get('show','1') for s in p.slides]==['1']*9+['0']*4
 assert '收敛性' in next(sh.text for sh in p.slides[4].shapes if sh.has_text_frame and sh.text.strip())
 # python-pptx renames part objects lazily when slides are accessed after load;
 # confirm insertion from the actual saved package relationship instead.
 with zipfile.ZipFile(out) as z:
  ns={'p':'http://schemas.openxmlformats.org/presentationml/2006/main'}
  xml=ET.fromstring(z.read('ppt/presentation.xml'));ids=xml.find('p:sldIdLst',ns)
  rid=ids[4].get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
  rels={x.get('Id'):x.get('Target') for x in ET.fromstring(z.read('ppt/_rels/presentation.xml.rels'))}
  assert rels[rid].endswith('slides/slide13.xml'),rels[rid]
 timing=pd.read_csv(ROOT/'data/Updated_slide_timing_and_scripts.csv');assert len(timing)==9 and timing.Duration_seconds.sum()==300 and timing.End_seconds.iloc[-1]==300
 for i,s in enumerate(list(p.slides)[:9],1):assert f'主讲第{i}页' in s.notes_slide.notes_text_frame.text
 summary=pd.read_csv(ROOT/'data/Sampling_and_convergence_summary.csv');summary=summary[summary.Phase==1].sort_values('Year')
 np.testing.assert_allclose(summary.Worst_matched_walker_Rhat,[1.180635911028,1.174,1.123921405399,1.122],atol=.0006)
 values='\n'.join(sh.text for sh in p.slides[4].shapes if sh.has_text_frame)
 for r in summary.itertuples():
  assert f'{r.Worst_matched_walker_Rhat:.3f}' in values
  assert f'{r.Worst_matched_walker_bulk_ESS:.2f}' in values
 assert '尚待满足' in values and '400' in values and '1.01' in values
 for x in ['R̂','≥','≤','²','→','□','�']:assert x not in values,x
 traces=pd.read_csv(ROOT/'data/2021_representative_raw_traces.csv');assert len(traces)==16000 and (traces.Walker_index==0).all()
 assert traces.groupby(['Parameter','Ensemble']).size().eq(2000).all()
 main=fitz.open(ROOT/'documents/URP_Defense_5min_MCMC_20261026.pdf');full=fitz.open(ROOT/'documents/URP_Defense_5min_MCMC_With_Backup_20261026.pdf')
 assert len(main)==9 and len(full)==13
 pg=main[4];rendered=norm(pg.get_text());missing=[];overflow=[];fonts=set()
 for sh in p.slides[4].shapes:
  if sh.has_text_frame:
   for para in sh.text_frame.paragraphs:
    if norm(para.text) and norm(para.text) not in rendered:missing.append(para.text)
 for b in pg.get_text('dict')['blocks']:
  for line in b.get('lines',[]):
   for sp in line['spans']:
    x0,y0,x1,y1=sp['bbox']
    if min(x0,y0)<-.5 or x1>pg.rect.width+.5 or y1>pg.rect.height+.5:overflow.append(sp['text'])
    if re.search('[\u4e00-\u9fff]',sp['text']):fonts.add(sp['font']);assert 'CJK' in sp['font']
 assert not missing,missing;assert not overflow,overflow
 one=fitz.open();one.insert_pdf(main,from_page=4,to_page=4);one.save(ROOT/'documents/Added_MCMC_Convergence_Page_20261026.pdf')
 pix=pg.get_pixmap(matrix=fitz.Matrix(1.6,1.6));im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.save(ROOT/'analysis/Added_MCMC_Slide.png')
 thumbs=[]
 for i,page in enumerate(main):
  pix=page.get_pixmap(matrix=fitz.Matrix(.7,.7));im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((480,270));cell=Image.new('RGB',(500,300),'white');cell.paste(im,(10,5));ImageDraw.Draw(cell).text((12,280),f'{i+1:02d}'+(' ADDED MCMC' if i==4 else ''),fill='black');thumbs.append(cell)
 contact=Image.new('RGB',(1500,900),'#DCE6DE')
 for i,im in enumerate(thumbs):contact.paste(im,((i%3)*500,(i//3)*300))
 contact.save(ROOT/'analysis/Preview_Main_Slides.jpg',quality=92)
 result={'Status':'PASS','User_edited_source_SHA256':sha(base),'Original_slide_XMLs_preserved':12,'Original_slide_media_preserved':len(media),'Only_original_slide_body_changes':'Four footer page numbers, old 5-8 to 6-9','New_slide_position':5,'Main_slides':9,'Hidden_backup_slides':4,'Planned_seconds':300,'Main_PDF_pages':9,'Full_PDF_pages':13,'New_slide_rendered_text_missing':missing,'New_slide_page_overflows':overflow,'Chinese_render_fonts':sorted(fonts),'Original_raw_trace_states':16000,'New_MCMC_runs':False,'Strict_convergence_reference_met':False}
 (ROOT/'analysis/PRESENTATION_QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
