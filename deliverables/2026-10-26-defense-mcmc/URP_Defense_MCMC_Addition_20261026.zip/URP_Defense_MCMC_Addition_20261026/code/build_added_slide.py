"""Insert one diagnostic slide into the user's edited deck without rebuilding it."""
from pathlib import Path
import copy,json,re,zipfile,hashlib
import pandas as pd
from PIL import Image
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN,MSO_AUTO_SIZE
from pptx.oxml.xmlchemy import OxmlElement
from docx import Document
from docx.shared import Cm
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'documents';BASE=ROOT/'source/User_Edited_Base_20261026.pptx'
FONT='Microsoft YaHei';INK='163D3B';TEAL='0C7B74';MUTED='647C77';LINE='D9E4DC';BG='F6F8F5'
COLORS={2019:'287BA3',2020:'CE892E',2021:'2A9178',2022:'9565A6'}
TIMES=[15,30,35,35,35,30,45,50,25]
NEW_SCRIPT='拟合精度之后，还需要检查采样过程。左图以2021年为例，展示四组独立初始化原链中代表walker的真实参数轨迹；右表汇总四年的诊断结果。参数中心较稳定，但Rhat仍高于1.01，最小组有效样本量低于400。因此我们把过程拟合与分布采样精度分开报告，并将改进链的混合程度和有效样本量作为后续重点。'
def color(x):return RGBColor.from_string(x)
def text(s,t,x,y,w,h,size=22,bold=False,c=INK,align=PP_ALIGN.LEFT):
 sh=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=sh.text_frame;tf.clear();tf.auto_size=MSO_AUTO_SIZE.NONE;tf.word_wrap=True;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=Pt(0)
 for i,line in enumerate(t.split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.alignment=align;p.line_spacing=1.10;p.space_before=p.space_after=Pt(0)
  r=p.add_run();r.text=line;r.font.name=FONT;r.font.size=Pt(size);r.font.bold=bold;r.font.color.rgb=color(c)
  rp=r._r.get_or_add_rPr();ea=OxmlElement('a:ea');ea.set('typeface',FONT);rp.append(ea)
 return sh
def box(s,x,y,w,h,fill='FFFFFF',edge=None,rounded=False):
 sh=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h));sh.fill.solid();sh.fill.fore_color.rgb=color(fill)
 if edge:sh.line.color.rgb=color(edge);sh.line.width=Pt(.7)
 else:sh.line.fill.background()
 if rounded:sh.adjustments[0]=.1
 return sh
def picture(s,path,x,y,w,h):
 im=Image.open(path);ratio=im.width/im.height;ww=min(w,h*ratio);hh=ww/ratio
 return s.shapes.add_picture(str(path),Inches(x+(w-ww)/2),Inches(y+(h-hh)/2),width=Inches(ww),height=Inches(hh))
def title(s):return next(sh.text for sh in s.shapes if sh.has_text_frame and sh.text.strip())
def actual_notes(s):
 note=s.notes_slide.notes_text_frame.text
 m=re.search(r'【口播稿】\s*\n(.*?)(?:\n\s*【|\Z)',note,re.S)
 return m.group(1).strip() if m else note

def add_diagnostic(prs):
 s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=color(BG)
 text(s,'MCMC动态采样与校准 马尔可夫链收敛性',.56,.43,12.25,.78,32,True)
 box(s,.56,1.27,.70,.04,TEAL)
 text(s,'2021年原链动态轨迹',.66,1.65,7.42,.47,23,True)
 picture(s,ROOT/'figures/MCMC_2021_Raw_Traces_EN.png',.50,2.10,7.70,4.02)
 box(s,8.42,1.65,4.29,4.55,'FFFFFF',LINE,True)
 text(s,'四年阶段一诊断',8.67,1.88,3.80,.48,23,True)
 for x,t,w in [(8.68,'年份',.90),(9.78,'Rhat',1.12),(11.18,'bulk ESS',1.34)]:text(s,t,x,2.52,w,.39,18,True,c=MUTED)
 d=pd.read_csv(ROOT/'data/Sampling_and_convergence_summary.csv');d=d[d.Phase==1].sort_values('Year')
 for i,r in enumerate(d.itertuples()):
  y=3.03+i*.57
  box(s,8.66,y-.11,3.75,.009,LINE)
  text(s,str(r.Year),8.68,y,.91,.45,20,True,c=COLORS[r.Year])
  text(s,f'{r.Worst_matched_walker_Rhat:.3f}',9.82,y,1.15,.45,22,True)
  text(s,f'{r.Worst_matched_walker_bulk_ESS:.2f}',11.28,y,1.08,.45,22,True)
 text(s,'参考：Rhat小于1.01\nbulk ESS至少400',8.68,5.46,3.78,.65,17,c=MUTED)
 box(s,.56,6.36,12.20,.72,'E7F1EC',rounded=True)
 text(s,'参数中心较稳定，严格收敛判据尚待满足',.80,6.49,11.72,.43,22,True,c=TEAL)
 text(s,'5',12.05,7.16,.72,.25,14,c=MUTED,align=PP_ALIGN.RIGHT)
 s.notes_slide.notes_text_frame.text='主讲第5页 MCMC动态采样与校准 马尔可夫链收敛性\n时间：01:55至02:30（35秒）\n\n【口播稿】\n'+NEW_SCRIPT+'\n\n【数据与切页提示】\n左图为2021年原始阶段一4个独立ensemble的同编号walker 0轨迹，完整2000步；两参数为CGC_CD与CDC_CD，不作时间平滑，不把耦合walker当作独立链。灰区为原诊断预热段347步，E1至E4为独立初始化ensemble。右表为每年全部5个阶段一参数及匹配walker组中最差Rhat与最小bulk ESS，保留原时间轴计算；ESS不跨依赖组相加。阶段二每年只有1个独立ensemble，按条件校准另行报告。原链未达到Rhat小于1.01、bulk/tail ESS至少400的参考目标；中心对截取较稳定不等于分布已经充分收敛。本次只新增展示页，无新MCMC计算。'
 return s

def preserve_original_slide_parts(temp,output):
 """Restore every original slide XML byte, changing only four page-number runs."""
 with zipfile.ZipFile(BASE) as src,zipfile.ZipFile(temp) as made:
  old=src.namelist();replacements={}
  for j in range(1,13):
   name=f'ppt/slides/slide{j}.xml';blob=src.read(name)
   if 5<=j<=8:
    token=f'<a:t>{j}</a:t>'.encode();assert blob.count(token)==1,(j,blob.count(token));blob=blob.replace(token,f'<a:t>{j+1}</a:t>'.encode(),1)
   replacements[name]=blob
   rel=f'ppt/slides/_rels/slide{j}.xml.rels'
   if rel in old:replacements[rel]=src.read(rel)
  with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
   for info in made.infolist():out.writestr(info,replacements.get(info.filename,made.read(info.filename)))
  with zipfile.ZipFile(output) as out:assert out.testzip() is None

def main():
 prs=Presentation(BASE);assert len(prs.slides)==12
 assert [s._element.get('show','1') for s in prs.slides]==['1']*8+['0']*4
 new=add_diagnostic(prs)
 sid=prs.slides._sldIdLst[-1];prs.slides._sldIdLst.remove(sid);prs.slides._sldIdLst.insert(4,sid)
 assert prs.slides[4]==new
 rows=[];elapsed=0
 for i,seconds in enumerate(TIMES):
  slide=prs.slides[i];t=title(slide)
  # Footer numbering is changed in the original XML at package-restoration time.
  note=slide.notes_slide.notes_text_frame.text
  note=re.sub(r'^主讲第\d+页[^\n]*',f'主讲第{i+1}页 {t}',note,count=1)
  fmt=lambda n:f'{n//60:02d}:{n%60:02d}'
  note=re.sub(r'时间：[^\n]*',f'时间：{fmt(elapsed)}至{fmt(elapsed+seconds)}（{seconds}秒）',note,count=1)
  note=note.replace('主讲第8页结束即为5分钟','主讲第9页结束即为5分钟')
  if i==3:
   a='我们同时单独检查了原链，发现有效样本量仍需提高，因此将过程拟合与分布采样精度分别报告。'
   if a in note:note=note.replace(a,'下一页进一步检查采样过程与链的收敛性。')
  slide.notes_slide.notes_text_frame.text=note
  rows.append({'Slide':i+1,'Title':t,'Duration_seconds':seconds,'Start_seconds':elapsed,'End_seconds':elapsed+seconds,'Script':actual_notes(slide)})
  elapsed+=seconds
 assert elapsed==300
 out=OUT/'URP_Defense_5min_MCMC_20261026.pptx';temp=ROOT/'analysis/generated_before_preservation.pptx';prs.save(temp);preserve_original_slide_parts(temp,out)
 pd.DataFrame(rows).to_csv(ROOT/'data/Updated_slide_timing_and_scripts.csv',index=False,encoding='utf-8-sig')
 d=Document();sec=d.sections[0];sec.top_margin=sec.bottom_margin=Cm(1.8);sec.left_margin=sec.right_margin=Cm(2.0)
 st=d.styles['Normal'];st.font.name=FONT;st.font.size=Pt(11);st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),FONT);st.paragraph_format.line_spacing=1.25
 d.add_heading('URP五分钟答辩讲稿：新增MCMC收敛性页',0)
 d.add_paragraph('以用户上传的修改版为底稿，保留原正文与版式。在第4页后新增第5页。主讲9页，建议时间总计300秒，随后4页仍为隐藏备答。')
 table=d.add_table(rows=1,cols=4);table.style='Light Shading Accent 1'
 for c,t in zip(table.rows[0].cells,['页码','主题','用时','累计']):c.text=t
 for r in rows:
  for c,t in zip(table.add_row().cells,[str(r['Slide']),r['Title'],str(r['Duration_seconds'])+'秒',f"{r['End_seconds']//60}:{r['End_seconds']%60:02d}"]):c.text=t
 for r in rows:d.add_heading(f"第{r['Slide']}页 {r['Title']}（{r['Duration_seconds']}秒）",1);d.add_paragraph(r['Script'])
 d.add_heading('新增页的数据解释',1);d.add_paragraph('参数轨迹只是直观展示，收敛性同时用保留时间结构的Rhat与有效样本量判断。四年阶段一原链未达到严格参考标准；保留均值的稳定性与分布采样精度分开说明，未把拟合精度写成收敛证明。')
 d.save(OUT/'URP_Defense_Speaker_Script_MCMC_20261026.docx')
 (OUT/'URP_Defense_Speaker_Script_MCMC_20261026.md').write_text('# 更新讲稿\n\n'+'\n\n'.join(f"## 第{r['Slide']}页 {r['Title']}｜{r['Duration_seconds']}秒\n\n{r['Script']}" for r in rows))
 print(out,flush=True)
 print('Main slides 9; hidden backups 4; planned time 300 seconds',flush=True)
if __name__=='__main__':main()
