# URP答辩：在用户修改版第4页后新增MCMC收敛性页

本版以2026年10月26日上传的PPT为唯一底稿，保留原12页正文、版式和图像。在原第4页后插入第5页“MCMC动态采样与校准 马尔可夫链收敛性”。原第5至8页页码顺延为6至9，讲稿与用时同步调整。

## 文件

- `documents/URP_Defense_5min_MCMC_20261026.pptx`：9页主讲，另4页隐藏备答。
- `documents/URP_Defense_5min_MCMC_20261026.pdf`：9页主讲PDF。
- `documents/URP_Defense_5min_MCMC_With_Backup_20261026.pdf`：含备答的13页PDF。
- `documents/Added_MCMC_Convergence_Page_20261026.pdf`：单独查看新增页。
- `documents/URP_Defense_Speaker_Script_MCMC_20261026.docx/pdf`：更新后的逐页讲稿和时间表，讲稿同样嵌入PPT备注。
- `source/User_Edited_Base_20261026.pptx`：上传底稿原字节副本。
- `data/`：真实原链轨迹、原诊断汇总、参数诊断与检查点来源哈希。
- `figures/`：新增页采样轨迹PNG、矢量PDF/SVG。
- `code/`：绘图、插页、正文保全与核验脚本。

## 新增页解释

左图展示2021年第一阶段4个独立初始化ensemble的同编号walker 0：CGC_CD和CDC_CD两个参数，2000步完整存储状态，不作时间平滑或walker平均。灰色预热区的边界为347步。完整轨迹共16,000个记录值，来源检查点SHA256已经核对。

右侧汇总四年第一阶段的最差匹配组Rhat和最小组bulk ESS。四年最差Rhat为1.181、1.174、1.124、1.122，最小组bulk ESS为17.79、19.18、24.94、25.34。参考目标为Rhat小于1.01、bulk/tail ESS至少400。

当前证据显示保留均值相对稳定，严格分布采样参考标准尚未满足。图中轨迹用于直观展示，分布精度由保留时间结构的诊断共同评价；未把高拟合精度写成收敛证明。阶段二每年仅一个独立ensemble，保持条件校准的原说明。本次无新增MCMC采样。

## 5分钟安排

|新页码|内容|建议用时|累计|
|---|---|---:|---:|
|1|封面|15秒|0:15|
|2|研究聚焦|30秒|0:45|
|3|研究流程|35秒|1:20|
|4|生长数据拟合精度|35秒|1:55|
|5|新增：MCMC采样与收敛性|35秒|2:30|
|6|Sobol敏感性|30秒|3:00|
|7|NSGA帕累托前沿|45秒|3:45|
|8|土壤储水分析|50秒|4:35|
|9|研究优势与扩展|25秒|5:00|

## 再生成

Python 3.12；依赖python-pptx、python-docx、numpy、pandas、matplotlib、Pillow、PyMuPDF。PDF使用LibreOffice。PPT字体使用微软雅黑/Arial，新增页采用普通字符，来源细节置于备注。

```bash
python code/make_convergence_figure.py
python code/build_added_slide.py
export FONTCONFIG_FILE="$PWD/code/fontconfig.xml"
soffice --headless --convert-to pdf --outdir documents documents/URP_Defense_5min_MCMC_20261026.pptx documents/URP_Defense_Speaker_Script_MCMC_20261026.docx
mkdir -p analysis/full_preview
soffice --headless --convert-to 'pdf:impress_pdf_Export:{"ExportHiddenSlides":{"type":"boolean","value":"true"}}' --outdir analysis/full_preview documents/URP_Defense_5min_MCMC_20261026.pptx
cp analysis/full_preview/URP_Defense_5min_MCMC_20261026.pdf documents/URP_Defense_5min_MCMC_With_Backup_20261026.pdf
python code/validate_addition.py
```

核验覆盖原12页XML正文保全、原媒体字节一致、插入位置、隐藏备答、300秒用时、原始轨迹来源及新增页排版。
