"""Optional: regenerate the Chinese guide, editable three-line tables and atlases.

Install requirements_reports.txt to merge the existing vector PDF figures.
Ordinary run_all.py does not require PyMuPDF.
"""
from pathlib import Path
import json
import pandas as pd
from docx import Document
from docx.shared import Pt, Cm
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

ROOT=Path(__file__).resolve().parent


def font(run,size=10.5,bold=False):
    run.font.name='DejaVu Sans';run.font.size=Pt(size);run.bold=bold
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Microsoft YaHei')


def paragraph(doc,text,size=10.5,bold=False):
    p=doc.add_paragraph();font(p.add_run(text),size,bold);return p


def setup(doc):
    section=doc.sections[0];section.page_width=Cm(21);section.page_height=Cm(29.7)
    section.left_margin=section.right_margin=Cm(1.7)
    normal=doc.styles['Normal'];normal.font.size=Pt(10.5)
    normal._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Microsoft YaHei')


def three_line_table(doc,heads,rows):
    t=doc.add_table(rows=1,cols=len(heads))
    for c,h in zip(t.rows[0].cells,heads):c.text=str(h)
    for row in rows:
        for c,v in zip(t.add_row().cells,row):c.text=str(v)
    borders=OxmlElement('w:tblBorders')
    for edge in ['top','bottom','left','right','insideH','insideV']:
        element=OxmlElement('w:'+edge);element.set(qn('w:val'),'single' if edge in ['top','bottom'] else 'nil')
        element.set(qn('w:sz'),'10');borders.append(element)
    t._tbl.tblPr.append(borders)
    for i,row in enumerate(t.rows):
        if i==0:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        for c in row.cells:
            if i==0:
                b=OxmlElement('w:tcBorders');line=OxmlElement('w:bottom');line.set(qn('w:val'),'single');line.set(qn('w:sz'),'5');b.append(line);c._tc.get_or_add_tcPr().append(b)
            for p in c.paragraphs:
                p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:font(r,8.5,i==0)
    return t


def main():
    folder=ROOT/'outputs/documents';folder.mkdir(parents=True,exist_ok=True)
    d=Document();setup(d)
    paragraph(d,'URP论文图表：PyCharm复现说明',17,True)
    paragraph(d,'对应上传修订稿的15幅图与10张表。',11)
    for line in (ROOT/'START_HERE_CN.md').read_text(encoding='utf-8').splitlines():
        if not line.strip() or line.startswith('```'):continue
        if line.startswith('#'):
            paragraph(d,line.lstrip('# '),13,True)
        else:paragraph(d,line,10)
    paragraph(d,'逐图脚本索引',13,True)
    index=pd.read_csv(ROOT/'FIGURE_TABLE_INDEX.csv',keep_default_na=False)
    for r in index[index.Type=='Figure'].itertuples():
        paragraph(d,f'Figure {r.Number}. {r.Name}',11,True)
        paragraph(d,r.Script,9)
        paragraph(d,'数据：'+(r.Data_files or '流程节点；无数值观测'),9)
    d.save(folder/'URP_PyCharm_复现说明.docx')

    from tables_core import table_spec
    d=Document();setup(d);paragraph(d,'URP论文十张可编辑三线表',17,True)
    for i in range(1,11):
        title,heads,rows,note,_=table_spec(i)
        paragraph(d,f'Table {i}. {title}',11,True)
        three_line_table(d,heads,rows);paragraph(d,'Note. '+note,9)
        if i<10:d.add_page_break()
    d.save(folder/'URP_All_10_Editable_Tables.docx')

    try:
        import fitz
    except ImportError:
        print('Word documents created. Install requirements_reports.txt for vector PDF atlases.')
        return
    for kind,name in [('figures','URP_All_15_Figures.pdf'),('tables','URP_All_10_Tables.pdf')]:
        merged=fitz.open()
        for p in sorted((ROOT/'outputs'/kind).glob('*.pdf')):
            with fitz.open(p) as part:merged.insert_pdf(part)
        merged.save(folder/name,garbage=4,deflate=True);merged.close()
    print('Guide, editable tables and vector atlases generated.')


if __name__=='__main__':main()
