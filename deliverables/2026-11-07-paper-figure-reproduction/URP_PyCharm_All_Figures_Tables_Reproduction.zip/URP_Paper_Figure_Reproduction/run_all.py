"""PyCharm entry point: validate sources, rebuild the 15 figures and 10 tables."""
from pathlib import Path
import os
import argparse
import runpy
import json
import time

ROOT=Path(__file__).resolve().parent
for variable in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[variable]='1'
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
os.environ.setdefault('MPLBACKEND','Agg')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figure',type=int,action='append',help='Only this figure (repeatable).')
    parser.add_argument('--table',type=int,action='append',help='Only this table (repeatable).')
    args=parser.parse_args()
    start=time.perf_counter()
    from prepare_data import main as prepare
    prepare()
    selected=bool(args.figure or args.table)
    figures=args.figure or ([] if selected else list(range(1,16)))
    tables=args.table or ([] if selected else list(range(1,11)))
    for i in figures:
        if not 1<=i<=15:parser.error('Figure must be 1–15')
        path=next((ROOT/'figure_scripts').glob(f'figure_{i:02d}_*.py'))
        runpy.run_path(str(path),run_name='__main__')
    from tables_core import render_one, export_all
    if tables==list(range(1,11)):
        export_all()
    else:
        for i in tables:
            if not 1<=i<=10:parser.error('Table must be 1–10')
            render_one(i)
    report=dict(Status='COMPLETE',Figures=figures,Tables=tables,Seconds=time.perf_counter()-start)
    (ROOT/'outputs/RUN_SUMMARY.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('Done. Results: '+str(ROOT/'outputs'),flush=True)


if __name__=='__main__':main()
