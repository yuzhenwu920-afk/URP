"""Optional, independently reproducible block-bootstrap check for Figure 10.

The figure itself uses its unchanged archived intervals. This calculation
records a NEW seed instead of pretending to recover a missing historical RNG
state. It never overwrites the paper's original bootstrap widths.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
PARAMS=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
SEED=20261107
RESAMPLES=512


def main():
    out=ROOT/'outputs/sobol_bootstrap_recheck';out.mkdir(parents=True,exist_ok=True)
    rows=[]
    archived=pd.read_csv(ROOT/'data/paper/R02_annual_scramble_mean_bootstrap.csv').set_index(['Year','Parameter'])
    for year in [2019,2020,2021,2022]:
        rng=np.random.default_rng(SEED+year)
        seed_estimates=[];bootstrap=[]
        for seed in [101,202,303]:
            raw=np.load(ROOT/f'data/sobol/{year}_seed{seed}/response_matrix.npy',allow_pickle=False)[:,0]
            y=(raw-raw.mean())/raw.std()
            a,b=y[::10],y[9::10];ab=np.column_stack([y[(k+1)::10] for k in range(8)])
            v=np.var(np.r_[a,b]);seed_estimates.append(np.stack([
                np.mean(b[:,None]*(ab-a[:,None]),axis=0)/v,
                .5*np.mean((a[:,None]-ab)**2,axis=0)/v]))
            # Resample complete A/B/AB rows together; never individual outputs.
            ids=rng.integers(0,len(a),size=(RESAMPLES,len(a)))
            aa,bb,xx=a[ids],b[ids],ab[ids]
            variance=np.var(np.concatenate([aa,bb],axis=1),axis=1)
            first=np.mean(bb[:,:,None]*(xx-aa[:,:,None]),axis=1)/variance[:,None]
            total=.5*np.mean((aa[:,:,None]-xx)**2,axis=1)/variance[:,None]
            bootstrap.append(np.stack([first,total],axis=1))
        estimates=np.mean(seed_estimates,axis=0)
        draws=np.mean(bootstrap,axis=0)
        widths=1.959963984540054*np.std(draws,axis=0,ddof=1)
        np.savez_compressed(out/f'{year}_bootstrap_draws.npz',draws=draws,seed=np.array(SEED+year))
        for k,p in enumerate(PARAMS):
            old=archived.loc[(year,p)]
            if not np.allclose(estimates[:,k],old[['S1','ST']].to_numpy(float),atol=1e-12,rtol=0):
                raise ValueError('Point estimates changed')
            rows.append(dict(Year=year,Parameter=p,S1=estimates[0,k],ST=estimates[1,k],
                             New_S1_halfwidth=widths[0,k],New_ST_halfwidth=widths[1,k],
                             Archived_S1_halfwidth=old.S1_bootstrap95_halfwidth,
                             Archived_ST_halfwidth=old.ST_bootstrap95_halfwidth,
                             New_seed=SEED+year,Resamples=RESAMPLES))
        print('Bootstrap recheck',year,'complete',flush=True)
    pd.DataFrame(rows).to_csv(out/'New_seed_vs_archived_intervals.csv',index=False,encoding='utf-8-sig')
    (out/'METHOD.json').write_text(json.dumps(dict(
        Status='COMPLETE',Seed_rule='20261107 + year',Resamples=512,
        Procedure='Independent complete response-block bootstrap within each scramble; equal mean of three scramble estimates; normal 95% halfwidth.',
        Replaces_paper_intervals=False,Historical_rng_state_recovered=False,
        Interpretation='A new seeded method check; original Figure 10 remains exactly reproducible from its frozen CI table.'
    ),indent=2),encoding='utf-8')


if __name__=='__main__':main()
