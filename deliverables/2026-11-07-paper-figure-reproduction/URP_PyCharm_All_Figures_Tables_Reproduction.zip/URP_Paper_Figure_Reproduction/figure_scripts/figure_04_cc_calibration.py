"""Figure 04: CC_calibration.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Calibration_daily_growth.csv, F02_CC_calibration_pairs.csv, Table3_calibration_performance.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(4, 'Figure_04_CC_calibration')

def main():
 d=read('Calibration_daily_growth.csv');p=read('F02_CC_calibration_pairs.csv');m=read('Table3_calibration_performance.csv');fig,axs=plt.subplots(2,2,figsize=(7.6,4.8),layout='constrained',sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y];o=p[p.Year==y];r=m[m.Year==y].iloc[0];ax.plot(pd.to_datetime(s.Date),s.canopy_cover,c=C[y],lw=1.7);ax.scatter(pd.to_datetime(o.Date),o.CC_observed,facecolor='white',edgecolor='#243C48',s=25,zorder=3);ax.set_ylim(-.025,1.06);ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));ax.text(.035,.95,f'$R^2_{{cal}}$ = {r.CC_R2_cal:.3f}\nRMSE = {r.CC_RMSE:.3f}\n$n$ = {len(o)}',transform=ax.transAxes,va='top',fontsize=8.6);panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Canopy cover (fraction)')
 fig.legend(handles=[Line2D([],[],c='#526F7B',lw=1.7,label='Simulation'),Line2D([],[],marker='o',mfc='white',mec='#243C48',ls='',label='LAI-derived observations')],loc='outside upper center',ncol=2,frameon=False);save(fig,'Fig04_CC_calibration_EN')

if __name__ == "__main__":
    main()
