"""Figure 01: Research_workflow.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：流程节点及版式由本文件明确给出；本图不含测量数据。
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(1, 'Figure_01_Research_workflow')

def main():
 fig,ax=plt.subplots(figsize=(8.1,3.35));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
 items=[('Data preparation',['Temperature, rainfall\nand reference ET','Soil profile and\ninitial water','DI schedule and\nmulch coverage','LAI-derived CC,\nbiomass and yield'],'#EAF3F8','///'),('Model calibration',['AquaCrop\nprocess simulation','Stage 1: canopy and\nwater-use parameters','Stage 2: water productivity\nand harvest index','Fit, sampling and\nboundary diagnostics'],'#EAF3ED','...'),('Sensitivity and\noptimization',['Sobol analysis:\nsix model outputs','NSGA-II / NSGA-III:\nfive stages; up to 15 events','Yield targets and\nsolver comparison','Water balance and\nstorage analysis'],'#F9F0E6','\\\\')]
 for i,(title,lines,color,hatch) in enumerate(items):
  x=.01+i*.34
  ax.add_patch(FancyBboxPatch((x,.12),.30,.81,boxstyle='round,pad=.008,rounding_size=.012',facecolor=color,edgecolor='#61747E',linewidth=.7,hatch=hatch,zorder=0))
  ax.text(x+.15,.845,title,ha='center',va='center',fontsize=10.5,weight='bold',bbox=dict(facecolor=color,edgecolor='none',pad=2))
  for j,line in enumerate(lines):
   yy=.655-j*.15;ax.text(x+.15,yy,line,ha='center',va='center',fontsize=8.4,linespacing=1.15,bbox=dict(facecolor='white',alpha=.96,edgecolor='none',pad=3))
  if i<2:ax.annotate('',xy=(x+.337,.51),xytext=(x+.303,.51),arrowprops=dict(arrowstyle='->',color='#435A66',lw=1.5))
 save(fig,'Fig01_Research_workflow_EN')

if __name__ == "__main__":
    main()
