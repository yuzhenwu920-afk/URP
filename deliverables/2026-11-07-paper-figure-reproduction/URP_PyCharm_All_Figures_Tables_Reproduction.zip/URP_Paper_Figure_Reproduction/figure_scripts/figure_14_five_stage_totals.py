"""Figure 14: Five_stage_totals.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Five_stage_totals_and_event_counts.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(14, 'Figure_14_Five_stage_totals')

def main():
 d=read('Five_stage_totals_and_event_counts.csv');fig,axs=plt.subplots(2,2,figsize=(8.3,5.2),layout='constrained',sharey=True);x=np.arange(5)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  a=d[(d.Year==y)&(d.Control_ID=='Original_DI')].set_index('Stage').loc[range(1,6)];b=d[(d.Year==y)&(d.Control_ID=='Selected_95pct')].set_index('Stage').loc[range(1,6)]
  ax.bar(x-.18,a.Actual_mm,width=.34,color='#CCD5D9',edgecolor='white',lw=.5);ax.bar(x+.18,b.Actual_mm,width=.34,color=YEAR_COLORS[y],edgecolor='white',lw=.5)
  for j,r in enumerate(b.itertuples()):ax.text(j+.18,r.Actual_mm+5,f'n={r.Positive_events}',ha='center',fontsize=8)
  ax.set_xticks(x,SHORT,rotation=22,ha='right');ax.grid(axis='y');ax.set_axisbelow(True);panel(ax,i,str(y))
  if i%2==0:ax.set_ylabel('Stage irrigation total (mm)')
 fig.legend(handles=[Patch(fc='#CCD5D9',label='Original DI schedule'),Patch(fc='#0072B2',label='Optimized schedule; n = positive-depth events')],loc='outside upper center',ncol=2,frameon=False);save(fig,'R05_Five_stage_totals_and_counts_EN')

if __name__ == "__main__":
    main()
