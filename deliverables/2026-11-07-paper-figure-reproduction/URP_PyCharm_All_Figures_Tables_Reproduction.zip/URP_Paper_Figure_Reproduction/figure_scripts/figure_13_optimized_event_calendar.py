"""Figure 13: Optimized_event_calendar.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Optimized_every_irrigation_event.csv, Four_year_result_comparison.csv, Five_stage_schedule_bounds.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(13, 'Figure_13_Optimized_event_calendar')

def main():
 d=read('Optimized_every_irrigation_event.csv');summary=read('Four_year_result_comparison.csv').set_index('Year');bounds=read('Five_stage_schedule_bounds.csv');fig,axs=plt.subplots(2,2,figsize=(8.9,5.5),layout='constrained')
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y];r=summary.loc[y]
  for j in range(5):
   b=bounds[(bounds.Year==y)&(bounds.Stage==j+1)].iloc[0];ax.axvspan(pd.Timestamp(b.First_allowed_date),pd.Timestamp(b.Last_allowed_date),fc=STAGE_COLORS[j],alpha=.055,zorder=0);v=s[s.Stage==j+1];ax.bar(pd.to_datetime(v.Date),v.Actual_mm,width=1.1,color=STAGE_COLORS[j],edgecolor='white',lw=.3,zorder=3)
  ymax=max(s.Actual_mm.max()*1.25,20);ax.set_ylim(0,ymax);ax.text(.03,.96,f'I = {r.Optimized_I_mm:.2f} mm; Y = {r.Optimized_Y13:.3f} t ha$^{{-1}}$\n{int(r.Positive_events)} positive-depth events',transform=ax.transAxes,va='top',fontsize=8.5);ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));ax.grid(axis='y');ax.set_axisbelow(True);panel(ax,i,str(y))
  if i%2==0:ax.set_ylabel('Individual irrigation depth (mm)')
 fig.legend(handles=[Patch(fc=c,label=t) for c,t in zip(STAGE_COLORS,SHORT)],loc='outside upper center',ncol=5,frameon=False,fontsize=8.5);save(fig,'R06_Optimized_event_calendar_EN')

if __name__ == "__main__":
    main()
