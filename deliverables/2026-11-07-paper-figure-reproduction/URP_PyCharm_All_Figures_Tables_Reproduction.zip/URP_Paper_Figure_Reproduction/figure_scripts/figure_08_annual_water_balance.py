"""Figure 08: Annual_water_balance.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：F09_annual_water_budget.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(8, 'Figure_08_Annual_water_balance')

def main():
 d=read('F09_annual_water_budget.csv');fig,ax=plt.subplots(figsize=(7.3,2.8),layout='constrained');x=np.arange(4)
 for col,label,color,marker in [('Inflow_mm','Inflow: irrigation + precipitation','#0072B2','o'),('Outflow_mm','Outflow: ET + water losses','#D55E00','s'),('Storage_change_mm','Storage change: final − initial','#009E73','D')]:ax.plot(x,d[col],c=color,marker=marker,lw=1.7,label=label)
 ax.axhline(0,c='#8C9EA5',lw=.7);ax.set_xticks(x,YEARS);ax.set_ylabel('Seasonal water balance (mm)');grid(ax);ax.legend(loc='upper left',bbox_to_anchor=(.0,1.24),ncol=1,frameon=False,fontsize=8.7);save(fig,'Fig08_Annual_water_balance_EN')

if __name__ == "__main__":
    main()
