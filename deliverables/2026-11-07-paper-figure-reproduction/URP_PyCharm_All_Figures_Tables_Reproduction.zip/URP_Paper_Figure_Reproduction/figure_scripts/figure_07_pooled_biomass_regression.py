"""Figure 07: Pooled_biomass_regression.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：F05_Biomass_calibration_pairs.csv, Pooled_biomass_regression_verified.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(7, 'Figure_07_Pooled_biomass_regression')

def main():
 d=read('F05_Biomass_calibration_pairs.csv');r=read('Pooled_biomass_regression_verified.csv').iloc[0];fig,ax=plt.subplots(figsize=(5.4,3.9),layout='constrained');x=np.array([0,42]);ax.plot(x,x,ls='--',c='#82959D',lw=1,label='1:1 line');ax.plot(x,r.Intercept+r.Slope*x,c='#263E49',lw=1.5,label='Pooled OLS fit')
 for y in YEARS:
  s=d[d.Year==y];ax.scatter(s.B_observed_t_ha,s.B_simulated_t_ha,s=28,c=C[y],label=str(y),zorder=3,edgecolor='white',lw=.4)
 ax.text(.04,.95,f'$y$ = {r.Slope:.3f}$x$ + {r.Intercept:.3f}\nOLS $R^2$ = {r.OLS_R2:.4f}\nPearson $r$ = {r.Pearson_r:.4f}\n$n$ = {int(r.N)}',transform=ax.transAxes,va='top',fontsize=9);ax.set(xlim=(0,42),ylim=(0,42),xlabel='Observed biomass (t ha$^{-1}$)',ylabel='Simulated biomass (t ha$^{-1}$)');grid(ax);ax.legend(loc='lower right',ncol=2,frameon=False,fontsize=8.5);save(fig,'Fig07_Pooled_biomass_regression_EN')

if __name__ == "__main__":
    main()
