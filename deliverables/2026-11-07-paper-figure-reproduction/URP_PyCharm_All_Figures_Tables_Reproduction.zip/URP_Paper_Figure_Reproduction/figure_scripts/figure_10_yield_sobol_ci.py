"""Figure 10: Yield_Sobol_CI.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：R02_annual_scramble_mean_bootstrap.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(10, 'Figure_10_Yield_Sobol_CI')

def main():
 d=read('R02_annual_scramble_mean_bootstrap.csv');fig,axs=plt.subplots(1,2,figsize=(7.8,4.1),layout='constrained',sharey=True)
 for i,(ax,col) in enumerate(zip(axs,['S1','ST'])):
  for j,y in enumerate(YEARS):
   s=d[d.Year==y].set_index('Parameter').loc[PARAMS];ax.errorbar(s[col],np.arange(8)+(j-1.5)*.14,xerr=s[col+'_bootstrap95_halfwidth'],fmt='o',ms=3.4,c=C[y],lw=.7,capsize=1.7,label=str(y))
  means=d.groupby('Parameter')[col].mean().loc[PARAMS];ax.scatter(means,np.arange(8)+.35,marker='D',c='#263E49',s=21,label='Four-year mean',zorder=4);ax.set_yticks(range(8),LABELS);ax.set_ylim(7.7,-.6);ax.set_xlim(-.025,.51);ax.set_xlabel('Sobol index');panel(ax,i,'First-order effect ($S_1$)' if col=='S1' else 'Total effect ($S_T$)');ax.grid(axis='x')
 handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=5,frameon=False,fontsize=8.3);save(fig,'Fig10_Yield_Sobol_CI_EN')

if __name__ == "__main__":
    main()
