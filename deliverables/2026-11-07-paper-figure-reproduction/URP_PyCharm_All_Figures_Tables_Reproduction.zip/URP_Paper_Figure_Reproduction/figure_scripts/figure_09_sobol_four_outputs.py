"""Figure 09: Sobol_four_outputs.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Sobol_annual_means_and_ranks.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(9, 'Figure_09_Sobol_four_outputs')

def main():
 d=read('Sobol_annual_means_and_ranks.csv');outs=[('Y_13pct','Grain yield'),('B_t_ha','Aboveground biomass'),('ET_mm','Seasonal evapotranspiration'),('MaxCC','Maximum canopy cover')];fig,axs=plt.subplots(2,2,figsize=(7.7,5.0),layout='constrained')
 for i,(ax,(o,t)) in enumerate(zip(axs.flat,outs)):
  a=d[d.Output==o].pivot(index='Year',columns='Parameter',values='ST_mean').loc[YEARS,PARAMS].to_numpy();im=ax.imshow(a,vmin=0,vmax=1,cmap='YlGnBu',aspect='auto');ax.set_xticks(range(8),LABELS,rotation=45,ha='right',fontsize=8);ax.set_yticks(range(4),YEARS);panel(ax,i,t)
  for j in range(4):
   for k in range(8):ax.text(k,j,f'{a[j,k]:.2f}',ha='center',va='center',fontsize=7.4,color='white' if a[j,k]>.48 else '#203640')
 fig.colorbar(im,ax=list(axs.flat),location='right',fraction=.025,pad=.015,label='Total-effect Sobol index ($S_T$)');save(fig,'Fig09_Sobol_four_outputs_EN')

if __name__ == "__main__":
    main()
