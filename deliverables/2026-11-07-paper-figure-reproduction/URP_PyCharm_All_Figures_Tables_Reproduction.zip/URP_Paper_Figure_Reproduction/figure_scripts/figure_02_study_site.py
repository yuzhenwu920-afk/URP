"""Figure 02: Study_site.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：assets/china_provinces_context.geojson
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(2, 'Figure_02_Study_site')

def main():
 fig,(ax,bx)=plt.subplots(1,2,figsize=(7.4,2.8),gridspec_kw={'width_ratios':[1.15,1]},layout='constrained')
 path=ROOT/'assets/china_provinces_context.geojson'
 if not path.exists():
  raise FileNotFoundError(path)
 if path.exists():
  for f in json.loads(path.read_text(encoding='utf-8'))['features']:
   g=f['geometry'];polys=g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']]
   for poly in polys:
    ax.add_patch(Polygon(poly[0],facecolor='#EAF1F2' if f['properties']['name']!='甘肃省' else '#C0DCD6',edgecolor='#72868B',lw=.35))
  ax.set(xlim=(73,136),ylim=(17,55));ax.set_aspect(1.15);ax.set_xticks([80,100,120]);ax.set_yticks([20,35,50]);ax.set_xlabel('Longitude (°E)');ax.set_ylabel('Latitude (°N)')
 else:ax.set(xlim=(100,105),ylim=(36,40),xlabel='Longitude (°E)',ylabel='Latitude (°N)')
 lon,lat=102+52/60,37+52/60;ax.scatter(lon,lat,marker='*',s=105,c='#D55E00',zorder=10);ax.annotate('Shiyanghe station\nWuwei, Gansu',xy=(lon,lat),xytext=(114,45),fontsize=8,arrowprops=dict(arrowstyle='-',lw=.7),bbox=dict(facecolor='white',edgecolor='none',alpha=.9,pad=2));panel(ax,0,'Study-site location')
 bx.axis('off');bx.set(xlim=(-25,465),ylim=(-60,275));bx.set_aspect('equal');bx.add_patch(Rectangle((0,0),400,200,facecolor='#EAF3ED',edgecolor='#52756B',lw=1.2))
 for k in range(10,200,18):bx.plot([5,395],[k,k],color='#9DC1B5',lw=1)
 bx.annotate('',xy=(0,-22),xytext=(400,-22),arrowprops=dict(arrowstyle='<->',lw=.8));bx.text(200,-28,'400 m',ha='center',va='top',fontsize=9)
 bx.annotate('',xy=(423,0),xytext=(423,200),arrowprops=dict(arrowstyle='<->',lw=.8));bx.text(435,100,'200 m',rotation=90,va='center',fontsize=9)
 bx.text(200,106,'Drip-irrigated maize field\n75% film coverage',ha='center',va='center',fontsize=10,bbox=dict(facecolor='white',alpha=.9,edgecolor='none',pad=4))
 bx.text(200,248,"37°52′ N, 102°52′ E  |  1581 m",ha='center',fontsize=9);bx.text(200,-58,'Field-size schematic; orientation is illustrative',ha='center',fontsize=7.8,color='#536872');panel(bx,1,'DI field dimensions')
 save(fig,'Fig02_Study_site_EN')

if __name__ == "__main__":
    main()
