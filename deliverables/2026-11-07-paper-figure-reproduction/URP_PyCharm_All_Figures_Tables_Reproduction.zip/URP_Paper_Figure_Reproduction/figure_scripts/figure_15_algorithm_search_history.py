"""Figure 15: Algorithm_search_history.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Generation_history.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(15, 'Figure_15_Algorithm_search_history')

def main():
 d=read('Generation_history.csv');d=d[d.Scope=='formal'];fig,axs=plt.subplots(2,2,figsize=(8.2,5.1),layout='constrained')
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  for algo,color,label in [('NSGA3','#0072B2','NSGA-III'),('NSGA2','#D55E00','NSGA-II')]:
   s=d[(d.Year==y)&(d.Algorithm==algo)].groupby('Generation').Hypervolume.agg(['mean','min','max']);ax.plot(s.index,s['mean'],c=color,lw=1.4,label=label);ax.fill_between(s.index,s['min'],s['max'],color=color,alpha=.12,lw=0)
  ax.set_xlim(1,100);panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Normalized population hypervolume')
  if i>=2:ax.set_xlabel('Generation')
 handles,labels=axs.flat[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=2,frameon=False);save(fig,'R10_Algorithm_convergence_EN')

if __name__ == "__main__":
    main()
