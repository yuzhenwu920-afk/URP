"""Figure 05: Biomass_calibration.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：F05_Biomass_calibration_pairs.csv, Table3_calibration_performance.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(5, 'Figure_05_Biomass_calibration')

def main():
 d=read('F05_Biomass_calibration_pairs.csv');m=read('Table3_calibration_performance.csv');fig,axs=plt.subplots(2,2,figsize=(7.4,4.8),layout='constrained',sharex=True,sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y];r=m[m.Year==y].iloc[0];ax.plot([0,42],[0,42],ls='--',color='#88969E',lw=1);ax.scatter(s.B_observed_t_ha,s.B_simulated_t_ha,c=C[y],s=28,edgecolors='white',lw=.4,zorder=3);ax.set(xlim=(0,42),ylim=(0,42));ax.text(.04,.95,f'$R^2_{{cal}}$ = {r.Biomass_R2_cal:.3f}\nRMSE = {r.Biomass_RMSE_t_ha:.2f} t ha$^{{-1}}$\n$n$ = {len(s)}',transform=ax.transAxes,va='top',fontsize=8.6);panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Simulated biomass (t ha$^{-1}$)')
  if i>=2:ax.set_xlabel('Observed biomass (t ha$^{-1}$)')
 save(fig,'Fig05_Biomass_calibration_EN')

if __name__ == "__main__":
    main()
