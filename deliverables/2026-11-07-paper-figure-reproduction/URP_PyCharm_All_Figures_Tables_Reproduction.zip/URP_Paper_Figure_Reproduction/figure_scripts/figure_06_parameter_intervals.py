"""Figure 06: Parameter_intervals.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Audit_Parameter_diagnostics.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(6, 'Figure_06_Parameter_intervals')

def main():
 d=read('Audit_Parameter_diagnostics.csv');fig,axs=plt.subplots(2,4,figsize=(8.0,4.0),layout='constrained');units=['fraction','d$^{-1}$','d$^{-1}$','d','–','g m$^{-2}$','g m$^{-2}$','fraction']
 for i,(ax,p,u) in enumerate(zip(axs.flat,PARAMS,units)):
  s=d[d.Parameter==p]
  for k,y in enumerate(YEARS):
   r=s[s.Year==y].iloc[0];ax.plot([r.Prior_low,r.Prior_high],[k,k],c='#CBD3D6',lw=3,zorder=1);ax.plot([r.P025,r.P975],[k,k],c=C[y],lw=2,zorder=2);ax.scatter(r.Mean,k,c=C[y],s=19,zorder=3)
  ax.set_yticks(range(4),[str(y) for y in YEARS] if i%4==0 else []);ax.invert_yaxis();ax.set_xlabel(u);ax.set_title(LABELS[i],weight='bold',fontsize=10);ax.grid(axis='x');ax.tick_params(axis='x',labelsize=8)
 fig.legend(handles=[Line2D([],[],c='#CBD3D6',lw=3,label='Prior support'),Line2D([],[],c='#526F7B',lw=2,marker='o',label='Retained mean and 2.5–97.5% interval')],loc='outside upper center',ncol=2,frameon=False);save(fig,'Fig06_Parameter_intervals_EN')

if __name__ == "__main__":
    main()
