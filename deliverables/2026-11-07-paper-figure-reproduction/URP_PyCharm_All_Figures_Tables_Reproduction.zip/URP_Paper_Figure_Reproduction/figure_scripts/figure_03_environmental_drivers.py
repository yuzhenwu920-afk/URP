"""Figure 03: Environmental_drivers.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Environmental_drivers_used.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(3, 'Figure_03_Environmental_drivers')

def main():
 d=read('Environmental_drivers_used.csv');fig,axs=plt.subplots(2,2,figsize=(7.6,4.6),layout='constrained',sharey=True)
 ymax=max(d.Precipitation_mm.max(),d.Reference_ET0_mm_d.max())*1.15
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y];x=pd.to_datetime(s.Date);ax.bar(x,s.Precipitation_mm,color='#72AED0',width=1.2,zorder=2,alpha=.85);ax.plot(x,s.Reference_ET0_mm_d,color='#D55E00',lw=1.05);ax.set_ylim(0,ymax);ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Daily water flux (mm d$^{-1}$)')
 handles=[Line2D([],[],color='#72AED0',lw=6,label='Precipitation'),Line2D([],[],color='#D55E00',label='Reference evapotranspiration (ETo)')]
 fig.legend(handles=handles,loc='outside upper center',ncol=2,frameon=False);save(fig,'Fig03_Environmental_drivers_EN')

if __name__ == "__main__":
    main()
