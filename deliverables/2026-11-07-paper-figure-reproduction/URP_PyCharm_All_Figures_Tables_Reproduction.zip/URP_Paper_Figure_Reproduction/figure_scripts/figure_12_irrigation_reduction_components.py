"""Figure 12: Irrigation_reduction_components.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Four_year_result_comparison.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(12, 'Figure_12_Irrigation_reduction_components')

def main():
 d=read('Four_year_result_comparison.csv');fig,ax=plt.subplots(figsize=(7.5,3.4),layout='constrained');x=np.arange(4);pos=np.zeros(4);neg=np.zeros(4)
 for col,label,color,hatch in [('ET_reduction_mm','Lower evapotranspiration','#E69F00',''),('Lower_final_storage_mm','Lower end-of-season storage','#56A0B9','///'),('Other_loss_reduction_mm','Lower other losses','#899A86','')]:
  vals=d[col].to_numpy();bottom=np.where(vals>=0,pos,neg);ax.bar(x,vals,bottom=bottom,width=.55,color=color,hatch=hatch,label=label,edgecolor='white',lw=.6);pos+=np.maximum(vals,0);neg+=np.minimum(vals,0)
 for j,r in d.iterrows():ax.text(j,pos[j]+7,f'{r.Storage_difference_share_pct:.1f}%',ha='center',fontsize=9)
 ax.axhline(0,c='#869BA5',lw=.7);ax.set_xticks(x,YEARS);ax.set_ylabel('Irrigation reduction components (mm)');ax.set_ylim(min(0,neg.min()*1.2),pos.max()*1.23);ax.grid(axis='y');ax.set_axisbelow(True);ax.legend(frameon=False,loc='upper left',fontsize=8.5);save(fig,'R09_Water_balance_decomposition_EN')

if __name__ == "__main__":
    main()
