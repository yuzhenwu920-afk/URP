"""Figure 11: Five_stage_Pareto_fronts.

从真实归档表格重新绘制；不读取参考PNG作为绘图输入。
数据文件：Full_range_Pareto_front.csv, Pareto_display_points.csv, Four_year_result_comparison.csv
直接在PyCharm运行本文件，或运行项目根目录run_all.py。
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *
begin_figure(11, 'Figure_11_Five_stage_Pareto_fronts')

def draw_front(ax,y,i,single=False):
 f=read('Full_range_Pareto_front.csv');s=f[f.Year==y].sort_values('Irrigation_mm');labels=read('Pareto_display_points.csv');labels=labels[labels.Year==y];summary=read('Four_year_result_comparison.csv').set_index('Year').loc[y]
 ax.plot(s.Irrigation_mm,s.Y_13pct,'--',c='#527DF4',lw=1.6,zorder=2)
 ax.scatter(labels.Irrigation_mm,labels.Y_13pct,s=22,c='#D33F35',edgecolors='white',lw=.5,zorder=4)
 for k,(_,r) in enumerate(labels.iterrows()):
  totals=[r[f'S{j}_actual_total_mm'] for j in range(1,6)];txt='('+', '.join(str(int(round(v))) for v in totals)+')';dx=7 if k<3 else -7;dy=-20 if k%2==0 else 12
  ax.annotate(txt,(r.Irrigation_mm,r.Y_13pct),xytext=(dx,dy),textcoords='offset points',ha='left' if dx>0 else 'right',va='center',fontsize=8 if single else 7.7,bbox=dict(boxstyle='round,pad=.15',fc='white',ec='#A9B6BD',lw=.45,alpha=.95))
 ax.scatter(summary.Original_I_mm,summary.Original_Y13,marker='*',s=95,c='#245568',zorder=5);ax.scatter(summary.Optimized_I_mm,summary.Optimized_Y13,marker='o',s=64,facecolor='white',edgecolor='#D55E00',lw=1.6,zorder=6)
 ax.axhline(summary.Yield_gate,c='#AE7772',ls=':',lw=1);ax.set_xlim(-summary.Original_I_mm*.025,summary.Original_I_mm*1.07);ax.set_ylim(0,20);panel(ax,i,str(y));grid(ax)

def main():
 fig,axs=plt.subplots(2,2,figsize=(9.4,6.2),layout='constrained',sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  draw_front(ax,y,i)
  if i%2==0:ax.set_ylabel('Grain yield at 13% moisture (t ha$^{-1}$)')
  if i>=2:ax.set_xlabel('Actual seasonal irrigation (mm)')
 handles=[Line2D([],[],ls='--',c='#527DF4',label='NSGA-III front'),Line2D([],[],marker='o',c='#D33F35',ls='',label='Evaluated solutions'),Line2D([],[],marker='*',c='#245568',ls='',label='Original DI model baseline'),Line2D([],[],marker='o',mfc='white',mec='#D55E00',ls='',label='Selected 95% yield solution'),Line2D([],[],ls=':',c='#AE7772',label='95% observed yield')]
 fig.legend(handles=handles,loc='outside upper center',ncol=3,frameon=False,fontsize=8.7);save(fig,'R03_Five_stage_multi_event_Pareto_4years_EN')

if __name__ == "__main__":
    main()
