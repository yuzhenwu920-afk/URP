"""Rebuild all ten manuscript tables from source data, then draw three-line tables."""
import textwrap
import common as G
from common import ROOT, YEARS, PARAMS, pd, np, plt, read, sha
from prepare_data import ensure_prepared


def table_spec(number):
    ensure_prepared()
    if number == 1:
        d=read('DI_soil_profile_thesis_Table2_1.csv')
        heads=['Depth\n(cm)','Sand\n(%)','Silt\n(%)','Clay\n(%)','Bulk density\n(g cm⁻³)','Texture']
        rows=[[r.Depth_cm,f'{r.Sand_pct:.2f}',f'{r.Silt_pct:.2f}',f'{r.Clay_pct:.2f}',f'{r.Bulk_density_g_cm3:.2f}',r.Texture] for r in d.itertuples()]
        return 'Measured soil properties of the DI field',heads,rows,'Source: Wang (2023), Table 2-1. Particle fractions: >0.05 mm, 0.002–0.05 mm and <0.002 mm.',[.12,.12,.12,.12,.22,.30]
    if number == 2:
        study=read('Table1_study_data.csv').set_index('Year');t=read('Calibration_targets_from_original_code.csv').set_index('Year')
        heads=['Year','Irrigation\n(mm)','Observed yield\n(t ha⁻¹)','CC / B\npairs','ET reference\n(mm)','Es target\n(mm)']
        rows=[[y,f'{study.loc[y,"DI_irrigation_mm"]:.2f}',f'{t.loc[y,"Y13_PUBLISHED"]:.2f}',f'{int(study.loc[y,"CC_pairs"])} / {int(study.loc[y,"Biomass_pairs"])}',f'{t.loc[y,"ET_OBS"]:.2f}',f'{t.loc[y,"ES_TARGET"]:g}'] for y in YEARS]
        return 'Annual DI data and calibration targets',heads,rows,'Yield is at 13% moisture. Es is the archived approximate/reconstructed calibration target. The original manuscript label “Es,obs” is clarified here; numerical values are unchanged. Event-sum irrigation for 2021 is 633.47 mm.',[.09,.17,.21,.15,.20,.18]
    if number == 3:
        d=read('Table2_parameter_definitions.csv')
        heads=['Parameter','Phase','Meaning','Unit','Sobol range']
        rows=[[r.Parameter,int(r.Stage),r.Meaning,r.Unit,f'{r.Sobol_lower:g}–{r.Sobol_upper:g}'] for r in d.itertuples()]
        return 'Calibrated parameters and common independent Sobol ranges',heads,rows,'These are common independent uniform Sobol ranges. Annual MCMC prior families and supports are separately archived.',[.15,.07,.47,.13,.18]
    if number == 4:
        d=read('central_vectors_with_provenance.csv').set_index('Year')
        heads=['Parameter','Unit','2019','2020','2021','2022'];units=['fraction','d⁻¹','d⁻¹','d','–','g m⁻²','g m⁻²','fraction'];digits=[4,4,4,2,4,3,3,4]
        rows=[[p,u]+[f'{d.loc[y,p]:.{k}f}' for y in YEARS] for p,u,k in zip(PARAMS,units,digits)]
        return 'Phase-specific retained means used in deterministic simulations',heads,rows,'Recalculated from 20 complete original checkpoints using the archived phase-specific burn-in. Phase 2 is conditional on phase 1.',[.21,.15,.16,.16,.16,.16]
    if number == 5:
        d=read('Table3_calibration_performance.csv');t=read('Calibration_targets_from_original_code.csv').set_index('Year')
        heads=['Year','CC\nR²cal','CC\nRMSE','Biomass\nR²cal','B RMSE\n(t ha⁻¹)','Observed Y\n(t ha⁻¹)','Simulated Y\n(t ha⁻¹)','Yield RE\n(%)']
        rows=[[int(r.Year),f'{r.CC_R2_cal:.4f}',f'{r.CC_RMSE:.4f}',f'{r.Biomass_R2_cal:.4f}',f'{r.Biomass_RMSE_t_ha:.4f}',f'{t.loc[r.Year,"Y13_PUBLISHED"]:.2f}',f'{r.Baseline_Y13_t_ha:.3f}',f'{r.Yield_bias_pct:+.2f}'] for r in d.itertuples()]
        return 'Calibration performance for canopy cover, biomass and grain yield',heads,rows,'R²cal = 1 − SSE/SST. CC is a fraction; biomass is aboveground dry matter. These are calibration comparisons, not new independent validation observations.',[.07,.11,.11,.13,.15,.15,.15,.13]
    if number == 6:
        d=read('Sobol_four_year_descriptive_means.csv');d=d[d.Output=='Y_13pct'].sort_values('ST_four_year_mean',ascending=False)
        heads=['Parameter','Mean S₁','Mean Sₜ','Minimum Sₜ','Maximum Sₜ']
        rows=[[r.Parameter,f'{r.S1_four_year_mean:.3f}',f'{r.ST_four_year_mean:.3f}',f'{r.ST_year_min:.3f}',f'{r.ST_year_max:.3f}'] for r in d.itertuples()]
        return 'Four-year descriptive yield sensitivity under common input ranges',heads,rows,'Each annual value averages three N=512 scrambles; the four annual values receive equal weight. Total-effect indices need not sum to one.',[.25,.18,.18,.20,.20]
    if number in [7,8,9]:
        d=read('Four_year_result_comparison.csv')
        if number == 7:
            heads=['Year','Recorded I\n(mm)','Selected I\n(mm)','Selected yield\n(t ha⁻¹)','I reduction\n(%)','Yield RE\n(%)','ET\n(mm)']
            rows=[[int(r.Year),f'{r.Original_I_mm:.2f}',f'{r.Optimized_I_mm:.2f}',f'{r.Optimized_Y13:.3f}',f'{r.I_reduction_pct:.2f}',f'{r.Yield_RE_vs_observed_pct:.2f}',f'{r.Optimized_ET_mm:.2f}'] for r in d.itertuples()]
            return 'Selected five-stage NSGA-III schedules at 95% observed yield',heads,rows,'The candidate minimizes actual irrigation within the feasible nondominated union of five formal NSGA-III final populations. Yield RE uses published observed yield.',[.08,.15,.15,.18,.16,.14,.14]
        if number == 8:
            heads=['Year','I reduction\n(mm)','ET decrease\n(mm)','Lower final S\n(mm)','Other losses\n(mm)','Storage share\n(%)']
            rows=[[int(r.Year),f'{r.I_reduction_mm:.2f}',f'{r.ET_reduction_mm:.2f}',f'{r.Lower_final_storage_mm:.2f}',f'{r.Other_loss_reduction_mm:.2f}',f'{r.Storage_difference_share_pct:.2f}'] for r in d.itertuples()]
            return 'Water-balance decomposition of irrigation reduction',heads,rows,'Differences are recorded DI minus selected candidate. Storage integrates the unchanged 0–2.4 m simulated profile. Signed components sum to irrigation reduction.',[.08,.18,.18,.20,.18,.18]
        stage=read('Five_stage_totals_and_event_counts.csv');stage=stage[stage.Control_ID=='Selected_95pct']
        heads=['Year','Seedling\n(mm)','Jointing\n(mm)','Heading\n(mm)','Grain filling\n(mm)','Maturity\n(mm)','Positive\nevents','Events\n≥0.1 mm']
        rows=[[int(r.Year)]+[f'{stage[(stage.Year==r.Year)&(stage.Stage==j)].Actual_mm.iloc[0]:.3f}' for j in range(1,6)]+[int(r.Positive_events),int(r.Events_ge_0p1mm)] for r in d.itertuples()]
        return 'Five-stage actual irrigation totals and event counts',heads,rows,'All exact positive depths count as events after same-day merging; ≥0.1 mm counts are additional statistics. Unrounded controls and numerical traces are retained.',[.07,.14,.14,.14,.15,.13,.12,.14]
    if number == 10:
        d=read('Algorithm_comparison.csv')
        heads=['Year','NSGA-III min I\n(mm)','NSGA-II min I\n(mm)','III minus II\n(mm)','NSGA-III\nHV','NSGA-II\nHV'];rows=[]
        for y in YEARS:
            q=d[d.Year==y].set_index('Algorithm');a=q.loc['NSGA3'];b=q.loc['NSGA2']
            rows.append([y,f'{a.Minimum_I_mm:.3f}',f'{b.Minimum_I_mm:.3f}',f'{a.Minimum_I_mm-b.Minimum_I_mm:+.3f}',f'{a.Normalized_union_HV:.6f}',f'{b.Normalized_union_HV:.6f}'])
        return 'Final feasible-population union metrics from five seeds',heads,rows,'Both algorithms share disclosed initialization anchors, objectives and constraints. HV uses the original annual normalization and reference point (0, 1.01).',[.08,.21,.21,.18,.16,.16]
    raise ValueError('Table number must be 1–10')


def render_one(number):
    G._used={}
    title,heads,rows,note,widths=table_spec(number)
    folder=ROOT/'outputs/tables';folder.mkdir(parents=True,exist_ok=True)
    frame=pd.DataFrame(rows,columns=[h.replace('\n',' ') for h in heads])
    frame.to_csv(folder/f'Table_{number:02d}.csv',index=False,encoding='utf-8-sig')
    with pd.ExcelWriter(folder/f'Table_{number:02d}.xlsx',engine='openpyxl') as writer:
        frame.to_excel(writer,index=False,sheet_name=f'Table_{number:02d}')
        s=writer.book.active;s.freeze_panes='A2'
        for col in s.columns:s.column_dimensions[col[0].column_letter].width=min(45,max(14,len(str(col[0].value))+2))
    lines=textwrap.wrap('Note. '+note,115)
    height=1.2+(len(rows)+1)*.33+len(lines)*.18
    fig,ax=plt.subplots(figsize=(10.8,height));ax.axis('off')
    fig.subplots_adjust(left=.025,right=.975,top=.82,bottom=.18+len(lines)*.025)
    table=ax.table(cellText=[[str(v) for v in row] for row in rows],colLabels=heads,
                   cellLoc='center',loc='center',colWidths=widths)
    table.auto_set_font_size(False);table.set_fontsize(9.5);table.scale(1,1.9)
    for (r,c),cell in table.get_celld().items():
        cell.set_facecolor('white');cell.visible_edges='';cell.set_edgecolor('black')
        if r==0:cell.visible_edges='TB';cell.set_linewidth(1.0);cell.get_text().set_weight('bold')
        if r==len(rows):cell.visible_edges='B';cell.set_linewidth(1.0)
        if number==3 and c==2:
            cell.get_text().set_text('\n'.join(textwrap.wrap(cell.get_text().get_text(),40)))
    fig.text(.5,.96,f'Table {number}. {title}',ha='center',va='top',weight='bold',fontsize=12)
    fig.text(.03,.025,'\n'.join(lines),ha='left',va='bottom',fontsize=8.7)
    for ext in ['png','pdf','svg']:
        meta={'Software':'URP reproducible plotting 20261107'} if ext=='png' else (
            {'CreationDate':None,'ModDate':None} if ext=='pdf' else {'Date':None})
        fig.savefig(folder/f'Table_{number:02d}.{ext}',dpi=350,bbox_inches='tight',facecolor='white',metadata=meta)
    from PIL import Image
    import hashlib,json
    with Image.open(folder/f'Table_{number:02d}.png') as image:
        pixel_hash=hashlib.sha256(image.convert('RGBA').tobytes()).hexdigest()
    (folder/f'Table_{number:02d}.provenance.json').write_text(json.dumps(dict(
        Table=number,Title=title,Inputs=G._used,PNG_pixel_sha256=pixel_hash,
        Column_note=note,No_vertical_rules=True),ensure_ascii=False,indent=2),encoding='utf-8')
    plt.close(fig)
    print(f'Table {number:02d}: CSV / XLSX / PNG / PDF / SVG',flush=True)
    return frame


def export_all():
    frames={i:render_one(i) for i in range(1,11)}
    with pd.ExcelWriter(ROOT/'outputs/URP_All_10_Tables.xlsx',engine='openpyxl') as writer:
        for i,d in frames.items():d.to_excel(writer,index=False,sheet_name=f'Table_{i:02d}')
    return frames


if __name__=='__main__':export_all()
