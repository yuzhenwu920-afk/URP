"""Optional: replay original DI and selected five-stage schedules, all four years.

Install requirements_model_replay.txt first. This does not resample or search.
The raw original model sources remain unchanged under model_replay/source/.
"""
from pathlib import Path
import os
import sys
import json
import argparse
import gc
import shutil
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
for name in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:
    os.environ.setdefault(name,'1')
os.environ.setdefault('NUMBA_CACHE_DIR',str(ROOT/'.cache/numba'))
sys.path.insert(0,str(ROOT/'model_replay/code'))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--year',type=int,action='append')
    args=parser.parse_args()
    # Run in a disposable model snapshot so the hashed source inputs stay intact.
    work=ROOT/'outputs/model_replay/working_model_snapshot'
    shutil.copytree(ROOT/'model_replay/source/model_snapshot',work,dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__','output_real','*.nbc','*.nbi'))
    import timing_engine
    timing_engine.PROJECT=work
    from multi_event_engine import MultiEventEngine, CONTROL_NAMES
    selected=pd.read_csv(ROOT/'data/optimization/Selected_95pct_candidates.csv',float_precision='round_trip').set_index('Year')
    expected=pd.read_csv(ROOT/'data/optimization/Four_year_result_comparison.csv',float_precision='round_trip').set_index('Year')
    out=ROOT/'outputs/model_replay';out.mkdir(parents=True,exist_ok=True)
    checks=[]
    for y in args.year or [2019,2020,2021,2022]:
        print(f'Initializing original {y} model...',flush=True)
        engine=MultiEventEngine(y)
        engine.activate()
        try:
            for tag,controls in [('Original_DI',engine.base),('Selected_95pct',selected.loc[y,CONTROL_NAMES].to_numpy(float))]:
                result,water,growth=engine.run(controls,use_prefix=False,details=True)
                reference=json.loads((ROOT/f'model_replay/reference/{y}_{tag}_complete_replay.json').read_text(encoding='utf-8'))['Summary']
                keys=['Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','B_t_ha','MaxCC','Profile_final_mm']
                error=max(abs(result[k]-reference[k]) for k in keys)
                if error>1e-7:raise ValueError(f'{y} {tag}: forward replay mismatch {error}')
                water.to_csv(out/f'{y}_{tag}_daily_water.csv',index=False)
                growth.to_csv(out/f'{y}_{tag}_daily_growth.csv',index=False)
                checks.append(dict(Year=y,Scenario=tag,Maximum_difference=error,Settings=engine.settings,Result=result))
                print(y,tag,'maximum numerical difference',error,flush=True)
        finally:
            engine.restore()
        del engine;gc.collect()
    (out/'FORWARD_MODEL_REPLAY.json').write_text(json.dumps(dict(Status='PASS',Replays=checks,New_MCMC=False,New_optimization=False),ensure_ascii=False,indent=2),encoding='utf-8')
    print('Forward-model replay PASS',flush=True)


if __name__=='__main__':main()
