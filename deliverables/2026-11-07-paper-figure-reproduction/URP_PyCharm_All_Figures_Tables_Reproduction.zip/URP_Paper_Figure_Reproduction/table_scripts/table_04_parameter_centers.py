"""Table 4: parameter_centers. Rebuild values and draw a three-line table."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tables_core import render_one

if __name__ == '__main__':
    render_one(4)
