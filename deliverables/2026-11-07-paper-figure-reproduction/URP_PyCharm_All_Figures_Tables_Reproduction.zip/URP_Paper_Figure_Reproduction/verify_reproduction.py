"""Check numerical table values, source/code hashes and reference PNG pixels.

Exact pixels are checked when requested. Platform font-engine differences are
reported separately from data failures; they are never called a numerical pass.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import re
import numpy as np
import pandas as pd
from PIL import Image

ROOT=Path(__file__).resolve().parent


def normalized(value):
    s=str(value).strip().translate(str.maketrans({'⁻':'-','¹':'1','²':'2','³':'3','–':'-','−':'-'}))
    s=re.sub(r'\s+','',s)
    try:return ('number',float(s))
    except ValueError:return ('text',s)


def table_values():
    checks=[]
    for i in range(1,11):
        a=pd.read_csv(ROOT/f'outputs/tables/Table_{i:02d}.csv',dtype=str,keep_default_na=False)
        b=pd.read_csv(ROOT/f'reference/uploaded_tables/Table_{i:02d}.csv',dtype=str,keep_default_na=False)
        if a.shape!=b.shape:raise ValueError(f'Table {i}: shape changed')
        for row in range(len(a)):
            for col in range(len(a.columns)):
                x,y=normalized(a.iat[row,col]),normalized(b.iat[row,col])
                same=(x[0]==y[0]) and (abs(x[1]-y[1])<1e-10 if x[0]=='number' else x[1]==y[1])
                checks.append(dict(Table=i,Row=row+1,Column=col+1,Value=a.iat[row,col],Uploaded_value=b.iat[row,col],Match=same))
                if not same:raise ValueError(f'Table {i}, row {row+1}, column {col+1}: {x} != {y}')
    pd.DataFrame(checks).to_csv(ROOT/'outputs/validation/Table_cells_vs_uploaded_manuscript.csv',index=False,encoding='utf-8-sig')
    return len(checks)


def pixel_inventory():
    result={}
    for folder in ['figures','tables']:
        for p in sorted((ROOT/'outputs'/folder).glob('*.png')):
            with Image.open(p) as im:
                result[f'{folder}/{p.name}']=dict(Size=list(im.size),RGBA_SHA256=hashlib.sha256(im.convert('RGBA').tobytes()).hexdigest())
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--strict-pixels',action='store_true',help='Fail on any raster pixel difference.')
    args=parser.parse_args()
    from prepare_data import main as validate_data
    data=validate_data();cells=table_values()
    current=pixel_inventory()
    reference=json.loads((ROOT/'REFERENCE_RENDER_HASHES.json').read_text(encoding='utf-8'))
    mismatches=[n for n,v in reference.items() if current.get(n)!=v]
    code=json.loads((ROOT/'CODE_SHA256.json').read_text(encoding='utf-8'))
    changed=[n for n,h in code.items() if hashlib.sha256((ROOT/n).read_bytes()).hexdigest()!=h]
    report=dict(Status='PASS' if not changed and not mismatches else 'REVIEW',
                Numeric_data=data['Status'],Manuscript_table_cells_matched=cells,
                Figures=15,Tables=10,Reference_PNG_files=len(reference),
                Pixel_identical=not mismatches,Pixel_differences=mismatches,Changed_code=changed,
                Intentional_header_change='Table 2: Es,obs becomes Es target; data values unchanged.',
                Python=platform.python_version(),Platform=platform.platform())
    out=ROOT/'outputs/validation/REPRODUCTION_CHECK.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if changed or (args.strict_pixels and mismatches):raise SystemExit(1)
    return report


if __name__=='__main__':main()
