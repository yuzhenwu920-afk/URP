"""Recalculate numerical plotting data from the archived evidence.

This runs deterministic data checks, not a new MCMC/Sobol/NSGA search.
The original Figure-10 bootstrap widths are frozen statistical inputs;
their source hashes are checked and their point estimates are recomputed.
"""
from pathlib import Path
import hashlib
import json
import re
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DERIVED = ROOT / 'outputs/derived'
AUDIT = ROOT / 'outputs/validation'
YEARS = [2019, 2020, 2021, 2022]
PARAMS = ['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
OUTPUTS = ['Y_13pct','B_t_ha','Tr_mm','Es_mm','ET_mm','MaxCC']
CHECKS = []
_prepared = False


def read(folder, name):
    return pd.read_csv(ROOT/'data'/folder/name, encoding='utf-8-sig', float_precision='round_trip')


def record(name, actual, expected, tolerance=1e-9, **context):
    a, b = np.asarray(actual, float), np.asarray(expected, float)
    if a.shape != b.shape:
        raise ValueError(f'{name}: shape mismatch {a.shape} != {b.shape}')
    error = float(np.max(np.abs(a-b))) if a.size else 0.
    passed = bool(np.isfinite(a).all() and np.isfinite(b).all() and error <= tolerance)
    CHECKS.append(dict(Check=name, Max_absolute_error=error, Tolerance=tolerance,
                       Pass=passed, **context))
    if not passed:
        raise ValueError(f'{name}: {error:g} exceeds {tolerance:g}; {context}')


def write(d, name):
    d.to_csv(DERIVED/name, index=False, encoding='utf-8-sig', float_format='%.17g')


def verify_hashes():
    manifest = ROOT/'INPUT_SHA256.json'
    if not manifest.exists():
        raise FileNotFoundError('INPUT_SHA256.json is missing; do not use an incomplete package.')
    hashes = json.loads(manifest.read_text(encoding='utf-8'))
    for name, expected in hashes.items():
        p = ROOT/name
        actual = hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else 'MISSING'
        if actual != expected:
            raise ValueError('Input checksum changed: ' + name)
    CHECKS.append(dict(Check='Immutable input SHA256', Files=len(hashes), Pass=True))


def model_folder(year):
    return ROOT/f'model_replay/source/model_snapshot/real_model/model_{year}'


def targets():
    result = []
    for year in YEARS:
        source = model_folder(year)/f'DI_{year}_MCMC_ONE_CLICK.py'
        s = source.read_text(encoding='utf-8-sig')
        row = {'Year': year}
        for name in ['ET_OBS', 'ES_TARGET', 'Y13_PUBLISHED', 'Y13_TARGET']:
            match = re.search(r'^'+name+r'\s*=\s*([0-9.]+)', s, flags=re.M)
            if not match:
                raise ValueError(f'Missing {name} in original {year} model')
            row[name] = float(match.group(1))
        row['Es_role'] = 'Approximate/reconstructed calibration target; not a newly measured independent annual observation'
        row['Source'] = str(source.relative_to(ROOT))
        result.append(row)
    d = pd.DataFrame(result)
    write(d, 'Calibration_targets_from_original_code.csv')
    return d.set_index('Year')


def fit_metrics(observed, simulated):
    observed, simulated = np.asarray(observed), np.asarray(simulated)
    residual = simulated-observed
    return 1-float(residual@residual)/float(np.sum((observed-observed.mean())**2)), float(np.sqrt(np.mean(residual**2)))


def calibration_and_weather(t):
    cc = read('paper','F02_CC_calibration_pairs.csv')
    bio = read('paper','F05_Biomass_calibration_pairs.csv')
    daily = read('paper','Calibration_daily_growth.csv')
    env = read('paper','Environmental_drivers_used.csv')
    archived_fit = read('paper','Table3_calibration_performance.csv').set_index('Year')
    calendar = read('paper','Annual_model_calendar.csv').set_index('Year')
    fit, climate = [], []
    record('CC pair count', np.array([len(cc)]), np.array([48]), 0)
    record('Biomass pair count', np.array([len(bio)]), np.array([37]), 0)
    for y in YEARS:
        folder = model_folder(y)/'data/inputs'
        field = pd.read_csv(next(folder.glob('FIELD_CC_FILE_*')), float_precision='round_trip')
        field = field[(field.Year == y)&(field.Irrigation == 'DI')].set_index('Date')
        a, b = cc[cc.Year == y], bio[bio.Year == y]
        record('LAI-to-CC equation', field.Field_CC.to_numpy(),
               1.005*(1-np.exp(-.6*field.LAI.to_numpy()))**1.2, Year=y)
        record('Calibration CC observations match source', a.CC_observed.to_numpy(),
               field.loc[a.Date, 'Field_CC'].to_numpy(), Year=y)
        raw_b = pd.read_csv(next(folder.glob('BIOMASS_FILE_*')), float_precision='round_trip')
        if 'Year' in raw_b:
            raw_b = raw_b[raw_b.Year == y]
        if 'Treatment' in raw_b:
            raw_b = raw_b[raw_b.Treatment == 'DI']
        raw_b = raw_b.set_index('Date')
        record('Digitized biomass matches source', b.B_observed_t_ha.to_numpy(),
               raw_b.loc[b.Date, 'Observed_B_t_ha'].to_numpy(), Year=y)
        g = daily[daily.Year == y].set_index('Date')
        record('CC pairs match daily simulation', a.CC_simulated.to_numpy(),
               g.loc[a.Date,'canopy_cover'].to_numpy(), Year=y)
        # Both files preserve the original biomass conversion in the model.
        record('Biomass pairs match daily simulation', b.B_simulated_t_ha.to_numpy(),
               g.loc[b.Date,'biomass'].to_numpy()/100., Year=y)
        r2cc, rmsecc = fit_metrics(a.CC_observed, a.CC_simulated)
        r2b, rmseb = fit_metrics(b.B_observed_t_ha, b.B_simulated_t_ha)
        basegrowth = read('optimization',f'{y}_Original_DI_daily_growth.csv')
        ysim = float(basegrowth.DryYield.iloc[-1])/.87
        bias = (ysim/t.loc[y,'Y13_PUBLISHED']-1)*100
        vals = [r2cc,rmsecc,r2b,rmseb,ysim,bias]
        cols = ['CC_R2_cal','CC_RMSE','Biomass_R2_cal','Biomass_RMSE_t_ha','Baseline_Y13_t_ha','Yield_bias_pct']
        record('Calibration performance recalculated', np.array(vals), archived_fit.loc[y,cols].to_numpy(float), Year=y)
        fit.append(dict(Year=y,**dict(zip(cols,vals))))
        e = env[env.Year == y]
        weather = pd.read_csv(next(folder.glob('WEATHER_FILE_*')), float_precision='round_trip').set_index('date')
        eto = pd.read_csv(next(folder.glob('ETO_FILE_*')), float_precision='round_trip').set_index('Date')
        record('Weather precipitation matches original source', e.Precipitation_mm.to_numpy(),
               weather.loc[e.Date,'Precip_mm'].to_numpy(), Year=y)
        record('Audited ETo-B matches model forcing', e.Reference_ET0_mm_d.to_numpy(),
               eto.loc[e.Date,'ETo_B_mm'].to_numpy(), Year=y)
        record('Annual model calendar', np.array([len(e),e.Precipitation_mm.sum(),e.Reference_ET0_mm_d.sum()]),
               calendar.loc[y,['Calendar_days','Rain_mm','Actual_used_ETo_mm']].to_numpy(float), Year=y)
        climate.append(dict(Year=y,Days=len(e),Rain_mm=e.Precipitation_mm.sum(),
                            ETo_mm=e.Reference_ET0_mm_d.sum(),Source='actual executed model dates'))
    write(pd.DataFrame(fit), 'Table3_calibration_performance.csv')
    write(pd.DataFrame(climate), 'Verified_annual_weather_totals.csv')
    x, y = bio.B_observed_t_ha.to_numpy(), bio.B_simulated_t_ha.to_numpy()
    slope = float(np.dot(x-x.mean(),y-y.mean())/np.sum((x-x.mean())**2))
    intercept = float(y.mean()-slope*x.mean())
    r = float(np.corrcoef(x,y)[0,1])
    pooled = dict(N=len(x),Slope=slope,Intercept=intercept,OLS_R2=r*r,Pearson_r=r,
                  RMSE=float(np.sqrt(np.mean((y-x)**2))),X='Observed aboveground dry biomass',Y='Simulated aboveground dry biomass')
    old = read('paper','Pooled_biomass_regression_verified.csv').iloc[0]
    cols = ['N','Slope','Intercept','OLS_R2','Pearson_r','RMSE']
    record('Pooled four-year biomass regression', np.array([pooled[k] for k in cols]),old[cols].to_numpy(float))
    write(pd.DataFrame([pooled]),'Pooled_biomass_regression_verified.csv')


def mcmc_intervals():
    reference = read('paper','Audit_Parameter_diagnostics.csv')
    rows, centers = [], []
    for year in YEARS:
        central = {'Year':year}
        for phase in [1,2]:
            old = reference[(reference.Year==year)&(reference.Phase==phase)].set_index('Parameter')
            burn = int(old.Burn_in.iloc[0]); arrays=[]
            paths = sorted((ROOT/f'data/mcmc/{year}/phase{phase}').glob('ensemble_*.npz'))
            record('Original independent ensemble count',np.array([len(paths)]),np.array([4 if phase==1 else 1]),0,Year=year,Phase=phase)
            for p in paths:
                with np.load(p,allow_pickle=False) as z:
                    contract = json.loads(str(z['contract'])); names=contract['names']
                    record('Original stored steps',np.array([z['history'].shape[0]]),np.array([2000]),0,Year=year,Phase=phase)
                    arrays.append(z['history'][burn:])
            samples = np.stack(arrays).reshape(-1,len(names))
            quantiles = np.quantile(samples,[.025,.975],axis=0)
            for j,name in enumerate(names):
                r = old.loc[name].to_dict(); r.update(Year=year,Phase=phase,Parameter=name,
                    Mean=float(samples[:,j].mean()),P025=float(quantiles[0,j]),P975=float(quantiles[1,j]))
                record('Original-chain mean and empirical interval',
                       np.array([r['Mean'],r['P025'],r['P975']]),
                       old.loc[name,['Mean','P025','P975']].to_numpy(float),Year=year,Parameter=name)
                rows.append(r);central[name]=r['Mean']
        centers.append(central)
    new = pd.DataFrame(centers)
    ref = read('paper','central_vectors_with_provenance.csv')
    record('Parameter centers used downstream',new[PARAMS].to_numpy(),ref[PARAMS].to_numpy())
    write(pd.DataFrame(rows),'Audit_Parameter_diagnostics.csv')
    write(new,'central_vectors_with_provenance.csv')


def sobol_indices():
    seed_rows=[]
    for year in YEARS:
        for seed in [101,202,303]:
            p = ROOT/f'data/sobol/{year}_seed{seed}'
            y = np.load(p/'response_matrix.npy',allow_pickle=False)
            design = np.load(p/'design.npy',allow_pickle=False)
            record('Complete Saltelli design shape',np.array(design.shape),np.array([5120,8]),0,Year=year,Seed=seed)
            record('Complete Saltelli response shape',np.array(y.shape),np.array([5120,6]),0,Year=year,Seed=seed)
            if not np.isfinite(y).all() or not np.isfinite(design).all():raise ValueError('Nonfinite Sobol data')
            old = pd.read_csv(p/'indices.csv',float_precision='round_trip').set_index(['Output','Parameter'])
            for j,output in enumerate(OUTPUTS):
                v=(y[:,j]-y[:,j].mean())/y[:,j].std()
                a,b=v[::10],v[9::10];ab=np.column_stack([v[(k+1)::10] for k in range(8)])
                variance=np.var(np.r_[a,b]);s1=np.mean(b[:,None]*(ab-a[:,None]),axis=0)/variance
                st=.5*np.mean((a[:,None]-ab)**2,axis=0)/variance
                for k,name in enumerate(PARAMS):
                    record('Sobol point estimates from raw response blocks',np.array([s1[k],st[k]]),
                           old.loc[(output,name),['S1','ST']].to_numpy(float),Year=year,Seed=seed,Output=output,Parameter=name)
                    seed_rows.append(dict(Year=year,Seed=seed,Output=output,Parameter=name,S1=s1[k],ST=st[k]))
    seeds=pd.DataFrame(seed_rows);write(seeds,'Sobol_recomputed_seed_indices.csv')
    annual=seeds.groupby(['Year','Output','Parameter'],as_index=False).agg(S1_mean=('S1','mean'),ST_mean=('ST','mean'))
    annual['ST_rank']=annual.groupby(['Year','Output']).ST_mean.rank(ascending=False,method='min')
    old=read('paper','Sobol_annual_means_and_ranks.csv')
    keys=['Year','Output','Parameter'];a=annual.set_index(keys).sort_index();b=old.set_index(keys).sort_index()
    record('Annual Sobol means',a[['S1_mean','ST_mean']].to_numpy(),b[['S1_mean','ST_mean']].to_numpy())
    write(annual,'Sobol_annual_means_and_ranks.csv')
    four=annual.groupby(['Output','Parameter'],as_index=False).agg(
        S1_four_year_mean=('S1_mean','mean'),ST_four_year_mean=('ST_mean','mean'),
        ST_year_min=('ST_mean','min'),ST_year_max=('ST_mean','max'))
    write(four,'Sobol_four_year_descriptive_means.csv')
    ci=read('paper','R02_annual_scramble_mean_bootstrap.csv')
    yield_means=annual[annual.Output=='Y_13pct'].set_index(['Year','Parameter'])
    ci=ci.set_index(['Year','Parameter']).sort_index()
    record('Figure 10 bootstrap-table point estimates',ci[['S1','ST']].to_numpy(),
           yield_means.sort_index()[['S1_mean','ST_mean']].to_numpy())
    if (ci[['S1_bootstrap95_halfwidth','ST_bootstrap95_halfwidth']]<0).any().any():raise ValueError('Negative CI width')


def nd(d):
    d=d.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False],kind='mergesort').drop_duplicates(['Irrigation_mm','Y_13pct'])
    keep=[];best=-np.inf
    for i,r in d.iterrows():
        if r.Y_13pct>best:keep.append(i);best=r.Y_13pct
    return d.loc[keep].reset_index(drop=True)


def hypervolume_2d(d, observation, cap):
    q=nd(d); previous_i=1.01; total=0.
    for r in q.sort_values('Y_13pct',ascending=False).itertuples():
        i=r.Irrigation_mm/cap; value=r.Y_13pct/observation
        if i<previous_i:
            total+=(previous_i-i)*value; previous_i=i
    return total


def optimization_and_water(t):
    old=read('optimization','Four_year_result_comparison.csv').set_index('Year')
    slots=read('optimization','All_selected_schedule_slots.csv')
    oldstage=read('optimization','Five_stage_totals_and_event_counts.csv')
    recomputed_stage=slots.groupby(['Year','Control_ID','Stage','Stage_name'],as_index=False).agg(
        Planned_mm=('Planned_mm','sum'),Actual_mm=('Actual_mm','sum'),
        Positive_events=('Actual_mm',lambda x:int((x>0).sum())),
        Events_ge_0p1mm=('Actual_mm',lambda x:int((x>=.1).sum())))
    keys=['Year','Control_ID','Stage'];cols=['Planned_mm','Actual_mm','Positive_events','Events_ge_0p1mm']
    record('Stage totals and exact positive event counts',recomputed_stage.set_index(keys).sort_index()[cols].to_numpy(),
           oldstage.set_index(keys).sort_index()[cols].to_numpy())
    if (recomputed_stage.Positive_events>3).any():raise ValueError('More than three events in a stage')
    write(recomputed_stage,'Five_stage_totals_and_event_counts.csv')
    events=slots[(slots.Control_ID=='Selected_95pct')&(slots.Actual_mm>0)].sort_values(['Year','Date'])
    oldevents=read('optimization','Optimized_every_irrigation_event.csv').sort_values(['Year','Date'])
    record('All 42 exact positive irrigation depths',events.Actual_mm.to_numpy(),oldevents.Actual_mm.to_numpy())
    record('Positive irrigation event count',np.array([len(events)]),np.array([42]),0)
    if not (events.Date.to_numpy()==oldevents.Date.to_numpy()).all():raise ValueError('Event date mismatch')
    for r in slots.itertuples():
        if not (r.Eligible_window_start<=r.Date<=r.Eligible_window_end):raise ValueError('Irrigation outside stage dates')
    write(events,'Optimized_every_irrigation_event.csv')
    budgets=[];summary=[];ledgers=[]
    for year in YEARS:
        result=old.loc[year].to_dict();result['Year']=year;scenario={}
        for tag in ['Original_DI','Selected_95pct']:
            w=read('optimization',f'{year}_{tag}_daily_water.csv')
            g=read('optimization',f'{year}_{tag}_daily_growth.csv')
            delta_profile=w.Profile_final_of_day_mm.to_numpy()-w.Profile_initial_of_day_mm.to_numpy()
            delta_surface=np.diff(np.r_[0.,w.surface_storage.to_numpy()])
            balance=(w.Precipitation+w.IrrDay+w.CR+w.GwIn-w.Tr-w.Es-w.Runoff-w.DeepPerc-w.TileDrain).to_numpy()-delta_profile-delta_surface
            record('Daily physical water balance',balance,np.zeros(len(balance)),1e-7,Year=year,Scenario=tag)
            record('Continuous daily storage accounting',w.Profile_initial_of_day_mm.to_numpy()[1:],w.Profile_final_of_day_mm.to_numpy()[:-1],Year=year,Scenario=tag)
            r=dict(Year=year,Scenario=tag,Irrigation_mm=w.IrrDay.sum(),Precipitation_mm=w.Precipitation.sum(),
                   Capillary_rise_mm=w.CR.sum(),Groundwater_inflow_mm=w.GwIn.sum(),Transpiration_mm=w.Tr.sum(),
                   Soil_evaporation_mm=w.Es.sum(),Evapotranspiration_mm=w.Tr.sum()+w.Es.sum(),Runoff_mm=w.Runoff.sum(),
                   Deep_percolation_mm=w.DeepPerc.sum(),Tile_drainage_mm=w.TileDrain.sum(),
                   Soil_profile_initial_mm=w.Profile_initial_of_day_mm.iloc[0],Soil_profile_final_mm=w.Profile_final_of_day_mm.iloc[-1],
                   Surface_initial_mm=0.,Surface_final_mm=w.surface_storage.iloc[-1],Y13=g.DryYield.max()/.87)
            r['Inflow_mm']=r['Irrigation_mm']+r['Precipitation_mm']+r['Capillary_rise_mm']+r['Groundwater_inflow_mm']
            r['Outflow_mm']=r['Evapotranspiration_mm']+r['Runoff_mm']+r['Deep_percolation_mm']+r['Tile_drainage_mm']
            r['Storage_change_mm']=r['Soil_profile_final_mm']+r['Surface_final_mm']-r['Soil_profile_initial_mm']
            r['Closure_residual_mm']=r['Inflow_mm']-r['Outflow_mm']-r['Storage_change_mm']
            record('Seasonal physical water balance',np.array([r['Closure_residual_mm']]),np.array([0.]),1e-7,Year=year,Scenario=tag)
            scenario[tag]=r;ledgers.append(r)
            if tag=='Original_DI':budgets.append(r)
        base,opt=scenario['Original_DI'],scenario['Selected_95pct']
        di=base['Irrigation_mm']-opt['Irrigation_mm'];det=base['Evapotranspiration_mm']-opt['Evapotranspiration_mm']
        ds=base['Soil_profile_final_mm']-opt['Soil_profile_final_mm']
        dl=sum(base[k]-opt[k] for k in ['Runoff_mm','Deep_percolation_mm','Tile_drainage_mm'])
        record('Irrigation-reduction decomposition',np.array([di]),np.array([det+ds+dl]),1e-7,Year=year)
        recalc=dict(Original_I_mm=base['Irrigation_mm'],Original_Y13=base['Y13'],Optimized_I_mm=opt['Irrigation_mm'],
                    Optimized_Y13=opt['Y13'],I_reduction_mm=di,I_reduction_pct=100*di/base['Irrigation_mm'],
                    Yield_RE_vs_observed_pct=100*(opt['Y13']/t.loc[year,'Y13_PUBLISHED']-1),
                    ET_reduction_mm=det,Lower_final_storage_mm=ds,Other_loss_reduction_mm=dl,
                    Storage_difference_share_pct=100*ds/di,Optimized_ET_mm=opt['Evapotranspiration_mm'])
        keys=list(recalc);record('Selected-candidate summary recomputed',np.array([recalc[k] for k in keys]),old.loc[year,keys].to_numpy(float),1e-7,Year=year)
        result.update(recalc);summary.append(result)
        es=events[events.Year==year]
        record('Executed daily irrigation equals event sum',np.array([opt['Irrigation_mm']]),np.array([es.Actual_mm.sum()]),1e-7,Year=year)
        planned=slots[(slots.Year==year)&(slots.Control_ID=='Selected_95pct')]
        daily_event=es.groupby('Date').Actual_mm.sum()
        dw=read('optimization',f'{year}_Selected_95pct_daily_water.csv').set_index('Date')
        record('Each irrigation date and depth',daily_event.to_numpy(),dw.loc[daily_event.index,'IrrDay'].to_numpy(),1e-7,Year=year)
    budget=pd.DataFrame(budgets);arch=read('paper','F09_annual_water_budget.csv')
    cols=['Inflow_mm','Outflow_mm','Storage_change_mm','Evapotranspiration_mm']
    record('Annual budget displayed in Figure 8',budget[cols].to_numpy(),arch[cols].to_numpy(),1e-7)
    write(budget,'F09_annual_water_budget.csv');write(pd.DataFrame(summary),'Four_year_result_comparison.csv')
    write(pd.DataFrame(ledgers),'Recomputed_baseline_and_selected_water_ledger.csv')

    final=read('optimization','Formal_final_population_fronts.csv')
    algoref=read('optimization','Algorithm_comparison.csv').set_index(['Year','Algorithm'])
    history=read('optimization','Generation_history.csv');formal=history[history.Scope=='formal']
    record('Formal generation records',np.array([len(formal)]),np.array([4000]),0)
    algorithms=[]
    for (year,algo),s in final.groupby(['Year','Algorithm']):
        q=nd(s);cap=float(old.loc[year,'Original_I_mm']);obs=float(t.loc[year,'Y13_PUBLISHED'])
        hv=hypervolume_2d(q,obs,cap)
        record('Final-population union hypervolume and minimum I',np.array([hv,q.Irrigation_mm.min()]),
               algoref.loc[(year,algo),['Normalized_union_HV','Minimum_I_mm']].to_numpy(float),1e-10,Year=year,Algorithm=algo)
        algorithms.append(dict(Year=year,Algorithm=algo,Normalized_union_HV=hv,
                               Minimum_I_mm=q.Irrigation_mm.min(),Maximum_Y13=q.Y_13pct.max(),Front_size=len(q)))
        if algo=='NSGA3':record('Primary solution is minimum formal final-population NSGA-III I',np.array([q.Irrigation_mm.min()]),np.array([old.loc[year,'Optimized_I_mm']]),1e-8,Year=year)
        for seed,ss in s.groupby('Seed'):
            hv_seed=hypervolume_2d(ss,obs,cap)
            last=formal[(formal.Year==year)&(formal.Algorithm==algo)&(formal.Seed==seed)&(formal.Generation==100)]
            record('Final-generation hypervolume from archived solutions',np.array([hv_seed]),last.Hypervolume.to_numpy(),1e-10,Year=year,Algorithm=algo,Seed=int(seed))
    write(pd.DataFrame(algorithms),'Algorithm_comparison.csv')
    front=read('optimization','Full_range_Pareto_front.csv')
    labels=read('optimization','Pareto_display_points.csv')
    for year,s in front.groupby('Year'):
        q=nd(s);record('Full-range front is nondominated',np.array([len(q)]),np.array([len(s)]),0,Year=year)
        sums=s[[f'S{j}_actual_total_mm' for j in range(1,6)]].sum(axis=1)
        record('All Pareto labels use five actual stage totals',sums.to_numpy(),s.Irrigation_mm.to_numpy(),1e-7,Year=year)
    for r in labels.itertuples():
        s=front[(front.Year==r.Year)&(front.Control_ID==r.Control_ID)]
        record('Label point belongs to evaluated Pareto front',s[['Irrigation_mm','Y_13pct']].to_numpy(),np.array([[r.Irrigation_mm,r.Y_13pct]]))


def main():
    global _prepared
    CHECKS.clear();DERIVED.mkdir(parents=True,exist_ok=True);AUDIT.mkdir(parents=True,exist_ok=True)
    verify_hashes();t=targets();calibration_and_weather(t);mcmc_intervals();sobol_indices();optimization_and_water(t)
    pd.DataFrame(CHECKS).to_csv(AUDIT/'Numerical_data_checks.csv',index=False,encoding='utf-8-sig')
    report=dict(Status='PASS',Checks=len(CHECKS),Original_chain_checkpoints=20,
                Calibration_pairs=dict(CC=48,Biomass=37),Sobol_response_rows=61440,
                Formal_generation_records=4000,Positive_irrigation_events=42,
                Model_search_rerun=False,All_figure_points_kept=True,
                Figure10_CI='Archived bootstrap widths reproduced from hashed source; point estimates independently recomputed. Historical RNG state is not recovered.',
                Table2_label_correction='Es,obs -> Es target; numbers preserved.',
                Scope='Deterministic numerical reconstruction and plotting from existing URP experiments')
    (AUDIT/'DATA_VALIDATION_SUMMARY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    _prepared=True
    print(f'Data validation PASS: {len(CHECKS)} checks',flush=True)
    return report


def ensure_prepared():
    if not _prepared:
        main()


if __name__=='__main__':main()
