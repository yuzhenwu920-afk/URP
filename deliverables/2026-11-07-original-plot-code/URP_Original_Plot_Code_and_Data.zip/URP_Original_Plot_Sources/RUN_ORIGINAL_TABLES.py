"""Invoke original manuscript table-generation functions; do not change values."""
from pathlib import Path
import sys
import pandas as pd
from docx import Document
from RUN_ORIGINAL_PLOTS import UTF8Path

ROOT=Path(__file__).resolve().parent


def main():
    root=ROOT/'original/paper';sys.path.insert(0,str(root/'code'))
    import build_current_documents as original
    original.ROOT=UTF8Path(root);original.TB=root/'tables'
    original.HIST=root/'source/historical_four_window_tables'
    original.L.ROOT=UTF8Path(root);original.L.TB=root/'tables'
    folder=ROOT/'outputs/tables';folder.mkdir(parents=True,exist_ok=True)
    specs=original.data_tables()
    order=['soil','study','parameters','centers','fit','sensitivity','candidates','water_ledger','stage_totals','algorithms']
    document=Document();original.L.setup(document,'URP original manuscript tables')
    for number,key in enumerate(order,1):
        title,heads,rows,note=specs[key]
        pd.DataFrame(rows,columns=[h.replace('\n',' ') for h in heads]).to_csv(
            folder/f'Manuscript_Table_{number}.csv',index=False,encoding='utf-8-sig')
        original.L.table(document,number,title,heads,rows,note)
        if number<10:document.add_page_break()
    document.save(folder/'Original_10_Three_Line_Tables.docx')
    print('Original table functions completed:',folder)


if __name__=='__main__':main()
