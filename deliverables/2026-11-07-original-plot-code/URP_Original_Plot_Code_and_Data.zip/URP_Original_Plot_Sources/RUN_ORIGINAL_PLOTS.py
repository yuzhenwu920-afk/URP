"""Invoke the historical URP plotting functions without rewriting them.

Only reads archived CSV/GeoJSON; does not run MCMC, Sobol sampling or NSGA.
The functions stay byte-for-byte unchanged under original/.
"""
from pathlib import Path
import sys
import importlib.util

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs/figures'
OUT.mkdir(parents=True,exist_ok=True)


class UTF8Path(type(Path())):
    """Read the original UTF-8 JSON correctly on Chinese Windows as well."""
    def read_text(self,encoding=None,errors=None):
        return super().read_text(encoding=encoding or 'utf-8-sig',errors=errors)


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module


def main():
    paper_root=ROOT/'original/paper'
    paper=load('urp_original_paper_plots',paper_root/'code/nonoptimization_figures.py')
    paper.ROOT=UTF8Path(paper_root);paper.TB=paper_root/'tables';paper.OUT=OUT
    for name in ['workflow','site','environment','cc','biomass','parameters','pooled','water','sobol','yield_ci']:
        getattr(paper,name)()
        print('Original paper function:',name,flush=True)

    opt_root=ROOT/'original/optimization'
    sys.path.insert(0,str(opt_root/'code'))
    opt=load('urp_original_optimization_plots',opt_root/'code/make_figures.py')
    opt.TB=opt_root/'tables'
    original_save=opt.save
    filenames={
        'R03_Five_stage_multi_event_Pareto_4years_EN':'Fig11_Five_stage_Pareto_fronts_EN',
        'R09_Water_balance_decomposition_EN':'Fig12_Irrigation_reduction_components_EN',
        'R06_Optimized_event_calendar_EN':'Fig13_Optimized_event_calendar_EN',
        'R05_Five_stage_totals_and_counts_EN':'Fig14_Five_stage_totals_EN',
        'R10_Algorithm_convergence_EN':'Fig15_Algorithm_search_history_EN'
    }
    def save_with_paper_filenames(fig,name):
        opt.OUT=OUT if name in filenames else OUT/'extra_original_year_panels'
        opt.OUT.mkdir(parents=True,exist_ok=True)
        original_save(fig,filenames.get(name,name))
    opt.save=save_with_paper_filenames
    for name in ['pareto','balance','event_calendar','stage_totals','convergence']:
        getattr(opt,name)()
        print('Original five-stage function:',name,flush=True)
    print('Finished. Original plotting functions were used; no model fitting or search was rerun.')
    print('Output:',OUT)


if __name__=='__main__':main()
