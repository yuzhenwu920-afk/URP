"""Chinese audit interpretation with two English figures and full numeric workbook."""
import json,hashlib,platform,importlib.metadata
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openpyxl.styles import Font,PatternFill,Alignment
from pilot_engine import ROOT
T=ROOT/'tables';LABEL={'I000':'零灌水','I050':'50% DI','I400':'400mm','I075':'75% DI','I100':'原DI'}
def read(name):return pd.read_csv(T/(name+'.csv'))

def main():
    a=read('Scenario_water_and_stress_summary');a['Scheme']=a.Scenario.map(LABEL);meta=json.loads((ROOT/'verification/INITIAL_WATER_AUDIT.json').read_text())
    reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text());shallow=read('Shallow_1p1m_domain_check');sens=read('Initial_water_assumed_sensitivity')
    with pd.ExcelWriter(ROOT/'URP_2021_Water_Audit_Data.xlsx',engine='openpyxl') as writer:
        index=[]
        for i,p in enumerate(sorted(T.glob('*.csv')),1):
            name=f'{i:02d}_'+p.stem[:27];df=pd.read_csv(p);df.to_excel(writer,sheet_name=name,index=False);index.append(dict(Sheet=name,CSV=p.name,Rows=len(df)))
        pd.DataFrame(index).to_excel(writer,sheet_name='INDEX',index=False)
        for ws in writer.book:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            for c in ws[1]:c.font=Font(name='Calibri',bold=True,color='FFFFFF',size=10);c.fill=PatternFill('solid',fgColor='275767');c.alignment=Alignment(wrap_text=True)
            for column in ws.columns:
                ws.column_dimensions[column[0].column_letter].width=min(36,max(13,max(len(str(c.value or '')) for c in list(column)[:25])+2))
                for c in list(column)[1:]:
                    c.font=Font(name='Calibri',size=10)
                    if isinstance(c.value,float):c.number_format='0.0000'
                    if c.row%2==0:c.fill=PatternFill('solid',fgColor='F0F5F6')
    doc=Document();sec=doc.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=sec.right_margin=Cm(1.65);sec.top_margin=sec.bottom_margin=Cm(1.55)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
        st=doc.styles[name];st.font.name='DejaVu Sans';st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.styles['Normal'].font.size=Pt(10.5);doc.styles['Normal'].paragraph_format.line_spacing=1.10;doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    doc.styles['Title'].font.size=Pt(21);doc.styles['Heading 1'].font.size=Pt(14.5);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('275767');doc.styles['Caption'].font.size=Pt(9)
    footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER;footer.add_run('URP · 2021年水分胁迫与含水量审计 · ')
    pg=OxmlElement('w:fldSimple');pg.set(qn('w:instr'),'PAGE');footer._p.append(pg)
    md=[]
    def p(text,style=None):doc.add_paragraph(text,style);md.append(text+'\n')
    def h(text):doc.add_heading(text,1);md.append('\n## '+text+'\n')
    def table(title,df,columns):
        doc.add_heading(title,2);tab=doc.add_table(rows=1,cols=len(columns));tab.style='Light Shading Accent 1'
        flag=OxmlElement('w:tblHeader');tab.rows[0]._tr.get_or_add_trPr().append(flag)
        for cell,(_,label,_) in zip(tab.rows[0].cells,columns):cell.text=label
        for _,row in df.iterrows():
            for cell,(key,_,digits) in zip(tab.add_row().cells,columns):
                v=row[key];cell.text='—' if pd.isna(v) else str(v) if digits is None else f'{v:.{digits}f}'
        for i,row in enumerate(tab.rows):
            flag=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(flag)
            for cell in row.cells:
                for para in cell.paragraphs:
                    para.paragraph_format.space_after=Pt(3);para.paragraph_format.keep_with_next=i<len(tab.rows)-1
                    for run in para.runs:run.font.size=Pt(8.5)
        md.append(df[[k for k,_,_ in columns]].to_csv(index=False))
    def fig(i,height=13):
        rr=reg[i-1];path=ROOT/'figures'/(rr['ID']+'.png');im=Image.open(path);w,hh=im.size;im.thumbnail((2400,2600));embed=ROOT/'verification/word_figures'/(rr['ID']+'.png');embed.parent.mkdir(parents=True,exist_ok=True);im.save(embed,optimize=True)
        para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER;para.paragraph_format.keep_with_next=True;para.add_run().add_picture(str(embed),width=Cm(min(17.5,height*w/hh)))
        p(f"图W-{i:02d} · {rr['Title']}",'Caption');p('解析：'+rr['Interpretation_CN']);p('解释边界：'+rr['Boundary_CN'],'Caption');p('数据：'+', '.join(rr['Source_tables']),'Caption')
        md.append(f"![{rr['Title']}](figures/{rr['ID']}.png)\n")
    doc.add_heading('2021年DI玉米\n水分胁迫与含水量审计',0)
    p('最大根深1m · 五种灌水量 · 两张机制图 · 2026-10-21','Subtitle')
    p('沿用上一轮2021年500步、10walkers、4组独立ensemble试跑选定的参数，逐日观察原模型的胁迫函数、根深、分层水量和灌水执行。没有重新校准MCMC，也没有进行新的NSGA-III搜索；未收敛短链与参数边界问题仍保留。')
    p('已完成两组全英文图：①不同水量的水分胁迫与冠层；②0—1m根域储水及1—2.4m根域以下储水。每图另有CSV、Excel和PNG/PDF/SVG，全部记录来自模型实际回放。')
    table('五情景摘要',a,[('Scheme','情景',None),('Irrigation_mm','实际灌水mm',2),('Y_13pct','Y13 t/ha',3),('ET_mm','ET mm',2),('Root1m_final_mm','根层季末储水mm',2)])
    p('400mm是本轮新增的精确400.00mm情景；此前201点曲线中的邻近点为399.0861mm，不能将两者数据混写。原DI总量仍为633.47mm，所有日期和事件比例保留。')
    h('1 图一：不同灌水量的水分胁迫')
    fig(1,13)
    table('气孔限制及衰老系数的诊断天数',a,[('Scheme','情景',None),('Stomatal_eligible_days','有效蒸腾日',0),('Stomatal_stress_days_Ks_lt_0p95','气孔Ks<0.95天',0),('Stomatal_severe_days_Ks_lt_0p5','气孔Ks<0.5天',0),('Senescence_stress_days_Ks_lt_0p95','衰老Ks<0.95天',0)])
    p('读图先看气孔限制与冠层：400mm情景仅2个有效蒸腾日的气孔Ks<0.95，75% DI和原DI均为0天。400mm情景有少量早期扩展限制，但既有冠层已接近平台，晚期冠层与充分灌水很接近，因此蒸腾与产量趋近平台。零灌水则出现持续气孔与衰老胁迫，提前结束生长，原收获产量保留。')
    p('系数含义：Ks=1表示对应缺水限制未触发，数值越低限制越强；并非“Ks=0.8就减产20%”。扩展窗口内计算的系数也不代表整个窗口每天都需要等量新增冠层，接近CCx后，扩展系数下降不一定造成同比例冠层损失。')
    p('本版本AquaCrop在蒸腾计算中使用sto_lin，并与通气系数取最小值；本轮通气系数记录均为1，主要限制来自缺水及可提取土壤水。未使用另一个非线性sto系数冒充实际蒸腾限制。原函数可按较湿的表土或根区相对亏缺计算胁迫；逐次调用的Dr、TAW和选择记录均已保存。')
    p('前三面板只显示明确的过程窗口；无函数调用或生长结束后的记录保持缺失，不补成Ks=1。0.95/0.5是本次统计阈值，不是重新校准的生理参数；日数不能代替不同生育阶段的产量敏感性。实测CC仅来自原DI，不能据此宣称其余水量已有独立验证。')
    h('2 图二：储水量如何随灌水改变')
    fig(2,13)
    table('分域储水与净下渗审计（mm）',a,[('Scheme','情景',None),('Root1m_change_mm','0—1m储水变化',2),('Below1m_change_mm','1—2.4m储水变化',2),('Net_downward_flux_1m_balance_derived_mm','1m边界净下渗*',2),('DeepPerc_mm','2.4m底排水',2)])
    p('*1m边界净下渗由0—1m土层与地表合并水量账反推，属于模型控制体计算，不是独立实测通量。上表正储水变化表示积存，负值表示耗储；根区以下的储水不计作根系直接可用水。全部情景1m以下直接根系取水为0。')
    low=a[a.Scenario=='I400'].iloc[0];full=a[a.Scenario=='I100'].iloc[0]
    p(f'400mm与原DI比较：少灌{full.Irrigation_mm-low.Irrigation_mm:.2f}mm，ET只减少{full.ET_mm-low.ET_mm:.2f}mm；0—1m季末储水少{full.Root1m_final_mm-low.Root1m_final_mm:.2f}mm，1—2.4m季末储水少{full.Below1m_final_mm-low.Below1m_final_mm:.2f}mm。平台对应的少灌主要改变储水和根区以下水分去向，不能直接称为同等幅度的耗水节约。')
    p('0—1m是为横向比较统一采用的固定土层，幼苗根深从0.30m动态增长，并非播种即能取遍1m土层。日期使用日末对应的次日零时，初始点为4月27日模拟开始前，末点为9月22日日历边界。')
    h('3 初始含水量来源审计')
    p('冻结CSV的Source/Notes明确声明：浅层来自论文图3-9/3-10近似读图，>1m保留ERA5-Land，非原始表列土壤含水观测。因此技术上“文件已锁定”不等于科学上已验证为4月27日播前实测。论文传感器位于20、40、60、80、100cm；点深度读数转换成整层平均水量同样包含假设。')
    p('关键跨界层：原0.9—1.2m单元已将0.9—1m图件资料与1—1.2m ERA5混合，统一θ=0.224675。随后保守重映射为0.1m网格时，0.9—1.0、1.0—1.1、1.1—1.2m都沿用该平均值。总水量守恒，但源资料在1m处的空间区分未恢复；当前根内最后0.1m也含混合来源。没有原分量时不能反推唯一正确的细层θ，更不能把该层全部标成纯实测。')
    prof=read('Initial_water_hydraulic_source_audit');root=prof[prof.zMid<=1].copy();root['Depth']=root.apply(lambda r:f'{r.z_top:.1f}—{r.zBot:.1f}',axis=1);root['Source_CN']=np.where(root.Contains_mixed_cross_1m_source,'图件+ERA5混合','图件近似重建')
    table('根内初始含水与模型水力参数',root,[('Depth','土层m',None),('Initial_theta','初始θ',4),('th_fc','模型FC',3),('th_wp','模型WP',3),('Source_CN','含水量来源',None)])
    p(f"0—1m初始储水{meta['Initial_root1m_mm']:.2f}mm；模型FC对应{meta['Root1m_FC_storage_mm']:.2f}mm，WP对应{meta['Root1m_WP_storage_mm']:.2f}mm。初始净高于FC {meta['Root1m_net_initial_minus_FC_mm']:.2f}mm；逐层只计正超额则为{meta['Root1m_above_FC_gross_mm']:.2f}mm，两者不同是因为0.9—1.0m低于该层FC。9个根内网格初值高于各自FC，但全部未超模型饱和含水率。")
    p('高于FC不自动等于数据错误，灌后非平衡状态可短时高于FC；需要核对取值日期、灌前/灌后位置和整田代表性。FC/WP沿用原砂/黏质地转换（OrgMat=2%），并非由本轮重新测定。论文不同点深度θ与一维整层平均θ也不应未经说明直接等同。')
    h('4 两项条件检验：初始水与计算剖面')
    p('初始水检验只改变0—1mθ，保留新校准参数；设置全根层θ±0.03m³/m³（总储水±30mm）及逐层高于FC部分截到模型FC三个诊断分支。±0.03是假设扰动，不是测量误差或95%区间；FC截断也不是已经认可的修正，原图仍采用冻结初值。')
    b=sens.pivot(index='Scenario',columns='Initial_case',values='Y13').reindex(a.Scenario).reset_index();b['Scheme']=b.Scenario.map(LABEL)
    table('初始含水假设下的产量（t/ha）',b,[('Scheme','情景',None),('Original','原初值',3),('Root_theta_minus_0p03','初始减30mm',3),('Root_theta_plus_0p03','初始加30mm',3),('Root_theta_capped_at_model_FC','逐层截至FC',3)])
    p('400mm情景原产量15.04499t/ha，初始减30mm后15.00556t/ha，逐层截至FC后15.03325t/ha。这些有限扰动只引起小幅产量变化，不能把平台全部归因于初始水偏多；也不代表其他初始剖面形状、田间水力参数或干旱年误差已被排除。')
    table('最浅计算剖面复核',shallow,[('Scenario','情景',None),('DeepPerc_1p1m_mm','1.1m底排水mm',2),('Difference_Y13','产量差',8),('Difference_ET_mm','ET差mm',8)])
    p('将水文计算域从2.4m缩到1.1m（根深1.0m外加AquaCrop要求的0.1m无根缓冲层），五个情景的产量和ET均与原域一致。原2.4m深层积水在浅域表现为较多底排水，因此不能把原DeepPerc=0误读为没有水越过1m根层。这个对照说明本轮产量平台未依赖1.1m以下的水文计算域；0.9—1.0m混合初值及原水力转换的证据限制仍在。')
    h('5 如何完善模型与论文表述')
    p('优先补齐播前及收获后0—1m按深度的原始含水率、观测点在滴头/膜内/行间的位置及整层代表性；分开整理0.9—1m与1m以下初值。如果后续获得原始值，应在保留来源与时间记录后再重映射和校准，不能静默覆盖冻结重建资料。')
    p('优化阶段应将原DI及候选的季末根域储水共同报告，或采用有实测依据的允许耗储约束及跨季回补核算。原DI本身也耗储约48.47mm，不宜机械要求所有方案季末储水≥播前，否则可能连原DI都被排除。原事件执行上限不等同设备极限。')
    p('400mm水分胁迫偏轻的原因还涉及原有缺水响应阈值、较湿表土/根区选择、一维根系提取和滴灌局部湿润的表达。需要用亏缺灌水下的CC、分层含水、ET和产量共同检验；现有8参数没有校准全部胁迫机制，单纯延长链不能解决这些结构问题。')
    p('采样方面仍需在确认输入后延长链、改善混合，继续报告WP_early贴近下限、HI0贴近上限。当前两个图可用于“模型机制与水量审计”小节，不能作为已经独立验证400mm足够灌水或已证实高节水率的证据。')
    p('可用于论文的表述：在最大有效根深固定为1.0m的2021年条件下，固定校准试跑参数并同比例改变原DI日程水量，逐日记录模型水分胁迫系数和分域储水。400mm情景的气孔限制较短，蒸腾趋近充分灌溉水平；相较原DI的减灌主要改变土壤耗储和根区以下水分去向。结果受初始含水重建、土壤水力转换及未充分验证的亏缺胁迫响应约束。')
    h('6 数据、复现与检验范围')
    p('两图提供600dpi PNG、PDF、SVG；Excel汇总全部CSV。每情景有148天逐日状态、24层含水/根系取水、逐次胁迫函数调用、原水量与生长输出；主审计共有740个日记录，另有5个最浅计算域回放及20个初值敏感性回放。')
    p('只读观察器与无观察器独立回放的标量、逐日CC/生物量和主要通量一致；水量账闭合至1e−7mm以内，1m以下直接根系取水为0。数学闭合说明数值记账一致，不证明初始含水或低水情景已获田间验证。')
    p('复现入口：URP_PROJECT指向随包model_snapshots/DI_PHASE3_NEXTGEN_UPDATED，然后运行run_water_audit.py → plot_water_audit.py → build_water_report.py。本报告没有重跑MCMC，上一轮完整链在原交付目录保留；本包保留参数、诊断与原代码/输入快照。图件源CSV和来源哈希均随包。')
    p('参考：王尚今，2023，《不同灌溉方式下覆膜玉米田水热氮传输及作物生长的观测与模拟》，中国农业大学硕士学位论文。重点核对PDF第23页测量方法、第42页图3-10、第19页土壤质地、第21页灌水事件及第63页DI产量/ET。')
    doc.save(ROOT/'URP_2021_Water_Audit_Report.docx');(ROOT/'URP_2021_Water_Audit_Report.md').write_text('\n'.join(md))
    packages=['numpy','pandas','scipy','aquacrop','emcee','numba','llvmlite','matplotlib','python-docx','openpyxl','Pillow','PyMuPDF']
    versions={k:importlib.metadata.version(k) for k in packages};(ROOT/'requirements.txt').write_text('\n'.join(k+'=='+v for k,v in versions.items())+'\n');(ROOT/'ENVIRONMENT.json').write_text(json.dumps(dict(Python=platform.python_version(),Packages=versions),indent=2))
    print('Word:',len(doc.inline_shapes),'figures,',len(doc.tables),'tables')

if __name__=='__main__':main()
