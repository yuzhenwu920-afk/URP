"""Unaccelerated verification, reproducible inventory, ZIP validation and delivery staging."""
from pathlib import Path
import json,hashlib,zipfile,shutil,contextlib
import numpy as np
import pandas as pd
import fitz
from docx import Document
from PIL import Image
from pilot_engine import ROOT
from run_water_audit import Engine,SCENARIOS

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    summary=pd.read_csv(ROOT/'tables/Scenario_water_and_stress_summary.csv');checks=[]
    with (ROOT/'verification/UNACCELERATED_CHECK.log').open('w') as log,contextlib.redirect_stdout(log):
        e=Engine(False)
        for label,amount in SCENARIOS:
            s,w,g=e.run(amount);base=summary[summary.Scenario.eq(label)].iloc[0]
            difference={k:abs(float(s[k])-float(base[k])) for k in ['Y_13pct','Irrigation_mm','ET_mm','Tr_mm','Es_mm','Profile_initial_mm','Profile_final_mm','DeepPerc_mm']}
            assert max(difference.values())<1e-8
            previous=pd.read_csv(ROOT/'tables'/f'{label}_growth.csv')
            np.testing.assert_allclose(g[['canopy_cover','biomass']],previous[['canopy_cover','biomass']],atol=1e-8,rtol=0)
            checks.append(dict(Scenario=label,Maximum_absolute_difference=max(difference.values()),Status='PASS'))
    reg=json.loads((ROOT/'FIGURE_REGISTRY.json').read_text());assert len(reg)==2
    figures=[]
    for r in reg:
        p=ROOT/'figures'/(r['ID']+'.png');im=Image.open(p);assert im.width>4000 and im.height>3000
        figures.append(dict(File=p.name,Width=im.width,Height=im.height))
    f1=pd.read_csv(ROOT/'tables/W01_Figure_source_data.csv');f2=pd.read_csv(ROOT/'tables/W02_Figure_source_data.csv')
    assert len(f1)==740 and len(f2)==745
    assert f1.groupby('Scenario').size().eq(148).all() and f2.groupby('Scenario').size().eq(149).all()
    doc=Document(ROOT/'URP_2021_Water_Audit_Report.docx');pdf=fitz.open(ROOT/'URP_2021_Water_Audit_Report.pdf')
    assert len(doc.inline_shapes)==2 and all(len(p.get_text())>80 for p in pdf)
    result=dict(Status='PASS',Unaccelerated_replays=checks,Figure_count=2,Figures=figures,Figure1_source_rows=740,Figure2_source_rows=745,
        Report_pages=len(pdf),Report_tables=len(doc.tables),MCMC_reruns=0,Parameters='2021 1m-root short-chain pilot; formal convergence not achieved',
        Low_irrigation_field_validation=False,Initial_soil_water_field_validation=False)
    (ROOT/'verification/FINAL_DATA_CHECK.json').write_text(json.dumps(result,indent=2))
    selected=[]
    for folder in ['code','tables','figures','sources','verification','model_snapshots']:
        selected.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.tmp','.lock'])
    selected.extend(ROOT/name for name in ['README.md','FIGURE_REGISTRY.json','URP_2021_Water_Audit_Report.docx','URP_2021_Water_Audit_Report.pdf','URP_2021_Water_Audit_Report.md','URP_2021_Water_Audit_Data.xlsx','ENVIRONMENT.json','requirements.txt'])
    selected=sorted(selected);manifest=dict(Date='2026-10-21',Scope='2021 1m root pilot: five irrigation amounts, daily water stress, storage and source audit',
        MCMC_reruns=0,Formal_parent_MCMC_convergence=False,Files=[dict(Path=str(p.relative_to(ROOT)),Bytes=p.stat().st_size,SHA256=sha(p)) for p in selected])
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));selected.append(ROOT/'MANIFEST.json')
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+str(p.relative_to(ROOT)) for p in selected)+'\n');selected.append(ROOT/'SHA256SUMS.txt')
    archive=ROOT.parent/'URP_2021_Water_Stress_Storage_Audit_20261021.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in selected:z.write(p,'URP_2021_Water_Audit/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for p in manifest['Files']:assert hashlib.sha256(z.read('URP_2021_Water_Audit/'+p['Path'])).hexdigest()==p['SHA256']
    target=Path('/workspace/URP/deliverables/2026-10-21-2021-water-audit');target.mkdir(parents=True,exist_ok=True)
    for p in [archive,ROOT/'README.md',ROOT/'URP_2021_Water_Audit_Report.docx',ROOT/'URP_2021_Water_Audit_Report.pdf',ROOT/'URP_2021_Water_Audit_Data.xlsx',
        ROOT/'figures/W01_Water_stress_and_canopy.png',ROOT/'figures/W02_Root_domain_and_deep_storage.png',ROOT/'tables/Scenario_water_and_stress_summary.csv',
        ROOT/'tables/W01_Figure_source_data.csv',ROOT/'tables/W02_Figure_source_data.csv',ROOT/'verification/FINAL_DATA_CHECK.json']:
        shutil.copy2(p,target/p.name)
    check=dict(Status='PASS',Archive_bytes=archive.stat().st_size,Archive_SHA256=sha(archive),Files=len(selected),ZIP_CRC='PASS',All_manifest_hashes='PASS')
    (target/'PACKAGE_CHECK.json').write_text(json.dumps(check,indent=2));(target/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in sorted(target.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt')+'\n')
    print(json.dumps(check,indent=2))

if __name__=='__main__':main()
