"""Exactly two English figure groups: stress/CC and separated soil storage."""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.lines import Line2D
from pilot_engine import ROOT
T=ROOT/'tables';F=ROOT/'figures'
SC=['I000','I050','I400','I075','I100']
COL={'I000':'#7A858C','I050':'#0072B2','I400':'#D55E00','I075':'#009E73','I100':'#6A51A3'}
LS={'I000':':','I050':'-','I400':'-','I075':'--','I100':(0,(6,2))}
LABEL={'I000':'0 mm','I050':'316.74 mm (50% DI)','I400':'400.00 mm','I075':'475.10 mm (75% DI)','I100':'633.47 mm (DI)'}
REG=[]
def read(name):return pd.read_csv(T/(name+'.csv'))
def style(ax):
    ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.14,zorder=0)
    ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    ax.set_xlim(pd.Timestamp('2021-04-27'),pd.Timestamp('2021-09-23'))
def save(fig,name,title,interpretation,boundary,sources):
    for ext in ['png','pdf','svg']:fig.savefig(F/(name+'.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig);REG.append(dict(ID=name,Title=title,Interpretation_CN=interpretation,Boundary_CN=boundary,Source_tables=sources))

def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.titlesize':12.5,'axes.labelsize':12,'xtick.labelsize':10.5,'ytick.labelsize':10.5,'legend.fontsize':10,'pdf.fonttype':42,'svg.fonttype':'none'})
    daily={s:read(s+'_daily') for s in SC};summary=read('Scenario_water_and_stress_summary');meta=json.loads((ROOT/'verification/INITIAL_WATER_AUDIT.json').read_text())
    handles=[Line2D([],[],color=COL[s],ls=LS[s],lw=2,label=LABEL[s]) for s in SC]
    fig,axs=plt.subplots(2,2,figsize=(11.6,8.0),sharex=True)
    fig.subplots_adjust(left=.08,right=.985,bottom=.115,top=.81,hspace=.20,wspace=.22)
    plot1=[]
    for s,d in daily.items():
        date=pd.to_datetime(d.Date);tadj=d.DAP-d.Delayed_days
        masks=[(tadj>=d.Emergence_dap)&(tadj<d.CanopyDevEnd_dap)&(~d.Protected_seed_before)&(d.CC>1e-8),
            d.Tr_potential_actual_canopy_mm>1e-8,(d.CC>1e-8)&(~d.Protected_seed_before)]
        for ax,col,mask in zip(axs.ravel()[:3],['Ks_exp_computed','Ks_sto_linear_computed','Ks_sen_computed'],masks):
            ax.plot(date,d[col].where(mask),color=COL[s],ls=LS[s],lw=1.65)
        axs[1,1].plot(date,d.CC,color=COL[s],ls=LS[s],lw=1.8)
        amount=float(summary.loc[summary.Scenario.eq(s),'Irrigation_mm'].iloc[0])
        plot1.append(pd.DataFrame(dict(Scenario=s,Date=d.Date,Actual_seasonal_irrigation_mm=amount,
            Expansion_Ks=d.Ks_exp_computed.where(masks[0]),Stomatal_linear_Ks=d.Ks_sto_linear_computed.where(masks[1]),
            Senescence_Ks=d.Ks_sen_computed.where(masks[2]),Canopy_cover=d.CC)))
    pd.concat(plot1,ignore_index=True).to_csv(T/'W01_Figure_source_data.csv',index=False)
    cc=pd.read_csv(ROOT/'sources/Field_CC_2021.csv');axs[1,1].scatter(pd.to_datetime(cc.Date),cc.Observed_CC,s=25,facecolor='white',edgecolor='#263D48',lw=1,zorder=6)
    cc.to_csv(T/'Observed_DI_CC.csv',index=False)
    titles=['(a) Canopy-expansion coefficient','(b) Stomatal water-stress coefficient (linear)','(c) Drought-senescence coefficient','(d) Simulated canopy cover']
    for i,(ax,title) in enumerate(zip(axs.ravel(),titles)):
        ax.set_title(title,loc='left');ax.set_ylim(-.035,1.065);ax.set_yticks([0,.25,.5,.75,1]);style(ax)
        if i<3:ax.set_ylabel(r'Water-stress coefficient $K_s$')
        else:ax.set_ylabel('Canopy cover (fraction)')
        for date in pd.to_datetime(read('Actual_event_schedules').Date.unique()):ax.axvline(date,color='#667580',lw=.6,alpha=.14,zorder=0)
    for ax in axs[-1]:ax.set_xlabel('Date in 2021')
    handles.append(Line2D([],[],ls='none',marker='o',mfc='white',mec='#263D48',label='Observed DI CC (panel d)'))
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.53,.945),ncol=3,fontsize=9.6,frameon=False)
    fig.suptitle('2021 water stress | calibrated pilot, maximum root depth 1.00 m',fontsize=14,y=.995)
    fig.supxlabel(r'$K_s=1$: no drought limitation; lower $K_s$: stronger limitation. Coefficients shown only in stated process windows.',fontsize=9,y=.018)
    save(fig,'W01_Water_stress_and_canopy','Water stress and canopy responses under five irrigation amounts',
        '前三面板分别显示冠层扩展、气孔和衰老的模型缺水胁迫系数；1表示不受该项缺水限制，越低胁迫越强。第四面板给出冠层响应，实测CC仅对应原DI条件。细灰竖线是原灌水日期。',
        '读取真实函数调用；气孔面板使用本版本蒸腾实际采用的sto_lin。扩展只显示模型扩展期且非种子保护期，气孔只显示潜在蒸腾大于零的日子，衰老只显示非保护期且仍有绿冠层的日子。断线不补成无胁迫；系数不等于独立观测或百分比减产。',
        ['All_scenarios_daily.csv','Scenario_water_and_stress_summary.csv','I*_stress_function_calls.csv'])
    fig,axs=plt.subplots(2,1,figsize=(10.4,8.2),sharex=True)
    fig.subplots_adjust(left=.105,right=.985,bottom=.115,top=.81,hspace=.25)
    plot2=[]
    for s,d in daily.items():
        times=pd.DatetimeIndex([pd.Timestamp(d.Storage_time_start.iloc[0])]+pd.to_datetime(d.Storage_time_end).tolist())
        top=np.r_[d.Root1m_start_mm.iloc[0],d.Root1m_end_mm.to_numpy()]
        below=np.r_[d.Below1m_start_mm.iloc[0],d.Below1m_end_mm.to_numpy()]-d.Below1m_start_mm.iloc[0]
        axs[0].plot(times,top,color=COL[s],ls=LS[s],lw=1.85)
        axs[1].plot(times,below,color=COL[s],ls=LS[s],lw=1.85)
        amount=float(summary.loc[summary.Scenario.eq(s),'Irrigation_mm'].iloc[0])
        plot2.append(pd.DataFrame(dict(Scenario=s,Boundary_time=times,Actual_seasonal_irrigation_mm=amount,
            Storage_0_1m_mm=top,Storage_change_1_2p4m_mm=below,Model_FC_0_1m_mm=meta['Root1m_FC_storage_mm'],
            Model_WP_0_1m_mm=meta['Root1m_WP_storage_mm'])))
    pd.concat(plot2,ignore_index=True).to_csv(T/'W02_Figure_source_data.csv',index=False)
    axs[0].axhline(meta['Root1m_FC_storage_mm'],color='#4E6470',ls='--',lw=1)
    axs[0].axhline(meta['Root1m_WP_storage_mm'],color='#A37554',ls=':',lw=1.2)
    axs[0].text(pd.Timestamp('2021-09-20'),meta['Root1m_FC_storage_mm']+4,f"Model FC: {meta['Root1m_FC_storage_mm']:.1f} mm",ha='right',fontsize=9,color='#4E6470')
    axs[0].text(pd.Timestamp('2021-09-20'),meta['Root1m_WP_storage_mm']+4,f"Model WP: {meta['Root1m_WP_storage_mm']:.1f} mm",ha='right',fontsize=9,color='#8F694D')
    axs[0].scatter(pd.Timestamp('2021-04-27'),meta['Initial_root1m_mm'],s=34,color='#263D48',zorder=6,clip_on=False)
    axs[0].annotate(f"Initial storage: {meta['Initial_root1m_mm']:.2f} mm",xy=(pd.Timestamp('2021-04-27'),meta['Initial_root1m_mm']),xytext=(10,8),textcoords='offset points',fontsize=9)
    axs[0].set(ylabel='Water storage in 0–1 m (mm)',ylim=(80,355),title='(a) Storage in the fixed 0–1 m root domain')
    axs[1].axhline(0,color='#6C7C84',lw=.8)
    axs[1].set(ylabel='Storage change in 1–2.4 m (mm)',xlabel='Date in 2021',title='(b) Storage below the maximum root depth, relative to the initial state')
    for ax in axs:style(ax)
    fig.legend(handles=handles[:5],loc='upper center',bbox_to_anchor=(.54,.945),ncol=3,fontsize=9.8,frameon=False)
    fig.suptitle('2021 soil-water storage | maximum root depth 1.00 m',fontsize=14,y=.995)
    fig.supxlabel('Panel (a) uses a fixed depth for comparison; growing roots do not access the full 1 m from planting. FC/WP are model-derived.',fontsize=9,y=.018)
    save(fig,'W02_Root_domain_and_deep_storage','Root-domain storage and water retained below the maximum root depth',
        '上图统一采用0—1m固定土层储水，横向比较各灌水情景，虚线为模型田持水量与萎蔫点对应储水；下图单列1—2.4m储水的相对初值变化，避免把根区以下存水当作根系可用水。',
        '日期是日末状态对应的次日零时，含4月27日模拟前初值。根深动态增长，0—1m固定层不等于幼苗期实际可达根域。FC/WP来自原质地转换；初值来自近似重建。深层没有根系直接取水，底边界位于2.4m。',
        ['All_scenarios_daily.csv','Initial_water_hydraulic_source_audit.csv','Scenario_water_and_stress_summary.csv'])
    (ROOT/'FIGURE_REGISTRY.json').write_text(json.dumps(REG,ensure_ascii=False,indent=2));print('Created exactly two English figure groups')

if __name__=='__main__':main()
