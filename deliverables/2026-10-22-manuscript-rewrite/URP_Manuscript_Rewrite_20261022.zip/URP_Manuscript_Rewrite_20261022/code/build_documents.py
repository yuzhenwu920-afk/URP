from pathlib import Path
import re,json,csv,shutil
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from paper_content import TITLE,ABSTRACT,KEYWORDS,BLOCKS,FIGS
ROOT=Path(__file__).resolve().parents[1];TB=ROOT/'tables';OUT=ROOT/'documents';YEARS=[2019,2020,2021,2022]
def read(n):return pd.read_csv(TB/n)
def markdown_table(heads,rows):
 return '\n'.join(['| '+' | '.join(h.replace('\n',' ') for h in heads)+' |','| '+' | '.join(['---']*len(heads))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def font(r,size=10.5,bold=False,english=False):
 r.font.name='Times New Roman';r.font.size=Pt(size);r.bold=bold
 ff=r._element.get_or_add_rPr().get_or_add_rFonts();ff.set(qn('w:eastAsia'),'Noto Serif CJK SC');return r
def setup(d,title):
 s=d.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7);s.left_margin=s.right_margin=Cm(1.9);s.top_margin=Cm(1.8);s.bottom_margin=Cm(1.7);s.header_distance=Cm(.7);s.footer_distance=Cm(.75)
 for n in ['Normal','Body Text']:
  st=d.styles[n];st.font.name='Times New Roman';st.font.size=Pt(10.5);st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC')
  st.paragraph_format.line_spacing=1.25;st.paragraph_format.space_after=Pt(5)
 for n in ['Heading 1','Heading 2']:
  st=d.styles[n];st.font.color.rgb=RGBColor.from_string('000000');st.font.name='Times New Roman';st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC');st.paragraph_format.keep_with_next=True;st.paragraph_format.space_before=Pt(9);st.paragraph_format.space_after=Pt(5)
 h=s.header.paragraphs[0];h.alignment=WD_ALIGN_PARAGRAPH.RIGHT;font(h.add_run('膜下滴灌玉米参数校准与灌溉制度优化'),8)
 p=s.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f)
 d.core_properties.title=title;d.core_properties.author='吴雨臻；李承昊；段璞';d.core_properties.subject='2019–2022 DI maize; source-linked manuscript revision, 2026-10-22'
def para(d,text,size=10.5,bold=False,indent=True,keep=False,english=False):
 p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY;p.paragraph_format.first_line_indent=Pt(21) if indent else Pt(0);p.paragraph_format.keep_with_next=keep;p.paragraph_format.widow_control=True
 # Citations are superscript, preserving literal reference ranges and punctuation.
 for a in re.split(r'(\[\d+(?:[–,\-]\d+)*\])',text):
  if not a:continue
  r=font(p.add_run(a),size,bold,english)
  if re.fullmatch(r'\[\d+(?:[–,\-]\d+)*\]',a):r.font.superscript=True;r.font.size=Pt(size-1)
 return p
def head(d,t,level=1):
 p=d.add_paragraph(style=f'Heading {level}');font(p.add_run(t),13 if level==1 else 11.5,True);return p
def table(d,num,title,heads,rows,note='',english=True,widths=None):
 p=para(d,f'Table {num}. {title}',9.5,True,False,True,True);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 t=d.add_table(rows=1,cols=len(heads));t.autofit=False
 if widths is None:widths=[17.2/len(heads)]*len(heads)
 for c,w in zip(t.columns,widths):c.width=Cm(w)
 for c,x in zip(t.rows[0].cells,heads):c.text=str(x)
 for vals in rows:
  for c,x in zip(t.add_row().cells,vals):c.text=str(x)
 b=OxmlElement('w:tblBorders')
 for edge in ['top','bottom','left','right','insideH','insideV']:
  z=OxmlElement('w:'+edge);z.set(qn('w:val'),'single' if edge in ['top','bottom'] else 'nil');z.set(qn('w:sz'),'10');z.set(qn('w:color'),'000000');b.append(z)
 t._tbl.tblPr.append(b)
 for i,row in enumerate(t.rows):
  row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
  if i==0:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
  for c,w in zip(row.cells,widths):
   c.width=Cm(w)
   if i==0:
    bb=OxmlElement('w:tcBorders');z=OxmlElement('w:bottom');z.set(qn('w:val'),'single');z.set(qn('w:sz'),'5');bb.append(z);c._tc.get_or_add_tcPr().append(bb)
   for p in c.paragraphs:
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3);p.paragraph_format.line_spacing=1.05;p.paragraph_format.keep_with_next=(i<len(t.rows)-1 and len(rows)<=8) or i==0
    for r in p.runs:font(r,8.7 if len(heads)>6 else 9,i==0,True)
 if note:para(d,'Note. '+note,8.7,False,False,False,True)
 return t
def tables():
 soil=read('DI_soil_profile_thesis_Table2_1.csv');study=read('Table1_study_data.csv');par=read('Table2_parameter_definitions.csv');cent=read('central_vectors_with_provenance.csv');fit=read('Table3_calibration_performance.csv');sob=read('Sobol_four_year_descriptive_means.csv');sob=sob[sob.Output=='Y_13pct'].sort_values('ST_four_year_mean',ascending=False);can=read('Original_main_NSGA_main_candidates.csv');dec=read('Original_main_Irrigation_saving_decomposition.csv');ledger=read('Original_main_Water_ledger_baseline_and_candidate.csv')
 tt={
 'soil':('Soil properties of the DI field reported by Wang [1], Table 2-1.',['Depth\n(cm)','Sand\n(%)','Silt\n(%)','Clay\n(%)','Bulk density\n(g cm⁻³)','Texture'],[[r.Depth_cm,f'{r.Sand_pct:.2f}',f'{r.Silt_pct:.2f}',f'{r.Clay_pct:.2f}',f'{r.Bulk_density_g_cm3:.2f}',r.Texture] for r in soil.itertuples()],'Particle fractions refer to >0.05 mm, 0.002–0.05 mm and <0.002 mm, respectively.'),
 'study':('Annual DI observations used for crop-model calibration.',['Year','Irrigation\n(mm)','Yobs\n(t ha⁻¹)','CC / B\npairs','ETobs\n(mm)','Es,obs\n(mm)'],[[y,f'{ii:.2f}',f'{yo:.2f}',nb,f'{et:.2f}',str(es)] for y,ii,yo,nb,et,es in zip(YEARS,[445.27,559.76,633.47,404.84],[16.55,17.29,15.86,14.08],['12 / 9','13 / 10','11 / 8','12 / 10'],[661.45,637.03,626.81,584.11],[76,79,78,81])],'Yield is expressed at 13% moisture. The 2021 event sum is 633.47 mm; the published rounded seasonal total is 633.46 mm.'),
 'parameters':('Calibrated parameters and common independent Sobol input ranges.',['Parameter','Phase','Meaning','Unit','Sobol range'],[[r.Parameter,int(r.Stage),r.Meaning,r.Unit,f'{r.Sobol_lower:g}–{r.Sobol_upper:g}'] for r in par.itertuples()],'Annual MCMC prior families and ranges are provided in Table S2. The ranges above define the independent Sobol experiment.'),
 'centers':('Retained-sample parameter means used in deterministic simulations.',['Parameter','Unit','2019','2020','2021','2022'],[[p,u]+[f'{cent.set_index("Year").loc[y,p]:.{digits}f}' for y in YEARS] for p,u,digits in [('CCx','fraction',4),('CGC_CD','d⁻¹',4),('CDC_CD','d⁻¹',4),('SenescenceCD','d',2),('Kcb','–',4),('WP_early','g m⁻²',3),('WP_late','g m⁻²',3),('HI0','fraction',4)]],'Phase 2 is conditional on the corresponding retained mean from phase 1.'),
 'fit':('Calibration performance for canopy cover, biomass and grain yield.',['Year','CC\nR²cal','CC\nRMSE','B\nR²cal','B RMSE\n(t ha⁻¹)','Yobs\n(t ha⁻¹)','Ysim\n(t ha⁻¹)','Yield RE\n(%)'],[[int(r.Year),f'{r.CC_R2_cal:.4f}',f'{r.CC_RMSE:.4f}',f'{r.Biomass_R2_cal:.4f}',f'{r.Biomass_RMSE_t_ha:.4f}',f'{dict(zip(YEARS,[16.55,17.29,15.86,14.08]))[r.Year]:.2f}',f'{r.Baseline_Y13_t_ha:.3f}',f'{r.Yield_bias_pct:+.2f}'] for r in fit.itertuples()],'R²cal = 1 − SSE/SST. Canopy cover is a fraction; biomass is aboveground dry matter.'),
 'sensitivity':('Four-year descriptive yield sensitivity under common input ranges.',['Parameter','Mean S₁','Mean Sₜ','Minimum Sₜ','Maximum Sₜ'],[[r.Parameter,f'{r.S1_four_year_mean:.3f}',f'{r.ST_four_year_mean:.3f}',f'{r.ST_year_min:.3f}',f'{r.ST_year_max:.3f}'] for r in sob.itertuples()],'Each annual estimate averages three scrambles; the four annual estimates receive equal weights.'),
 'candidates':('Representative NSGA-III solutions at 95% observed yield.',['Year','Original I\n(mm)','Optimized I\n(mm)','Optimized Y\n(t ha⁻¹)','I reduction\n(%)','Yield RE\n(%)','ET\n(mm)'],[[int(r.Year),f'{dict(zip(YEARS,[445.27,559.76,633.47,404.84]))[r.Year]:.2f}',f'{r.Irrigation_mm:.2f}',f'{r.Y13:.3f}',f'{r.Water_saving_pct:.2f}',f'{r.Yield_change_vs_observed_pct:.2f}',f'{r.ET_mm:.2f}'] for r in can.itertuples()],'The representative solution minimizes actual irrigation among feasible formal NSGA-III archive solutions. Yield RE is relative to the annual field observation.'),
 'water_ledger':('Water-balance decomposition of the representative irrigation reductions.',['Year','I reduction\n(mm)','ET decrease\n(mm)','Lower Send\n(mm)','Other losses\n(mm)','Storage share\n(%)'],[[int(r.Year),f'{r.Irrigation_saving_mm:.2f}',f'{r.ET_reduction_mm:.2f}',f'{r.Reduced_soil_storage_gain_mm:.2f}',f'{r.Loss_reduction_mm:.2f}',f'{r.Reduced_soil_storage_gain_mm/r.Irrigation_saving_mm*100:.2f}'] for r in dec.itertuples()],'Send refers to the full 2.4 m simulated profile. Initial water and climate are identical between schedules within each year.'),
 }
 return tt
def figure(d,key,num):
 name,title,note=FIGS[key];src=ROOT/'figures'/(name+'.png');cache=ROOT/'analysis/word_figures';cache.mkdir(exist_ok=True)
 im=Image.open(src).convert('RGB');im.thumbnail((2800,2800),Image.Resampling.LANCZOS);dest=cache/(name+'.jpg');im.save(dest,quality=95,subsampling=0)
 width=min(17.0,11.4*im.width/im.height)
 p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.line_spacing=1;p.paragraph_format.space_after=Pt(3);p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(dest),width=Cm(width))
 p=para(d,f'Figure {num}. {title}',9.2,True,False,True,True);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 p=para(d,note,8.8,False,False,False,True);p.paragraph_format.keep_together=True
def references():
 refs=json.loads((ROOT/'source/REFERENCE_EVIDENCE.json').read_text())
 refs.append(dict(number=15,CN='Vehtari A, Gelman A, Simpson D, Carpenter B, Bürkner P C. Rank-normalization, folding, and localization: An improved R̂ for assessing convergence of MCMC[J]. Bayesian Analysis, 2021, 16(2): 667–718.',DOI='10.1214/20-BA1221',verification_evidence='Reference used in the original-chain diagnostic; published article metadata and diagnostic definition.'))
 refs.append(dict(number=16,CN='Qin S, Li S, Kang S, et al. Can the drip irrigation under film mulch reduce crop evapotranspiration and save water under the sufficient irrigation condition?[J]. Agricultural Water Management, 2016, 177: 128–137.',DOI='',verification_evidence='User-supplied Wang 2023 thesis, reference [37], PDF p.102; cited for research topic and component-based interpretation.'))
 (ROOT/'source/REFERENCE_EVIDENCE_revised.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2));return refs
def manuscript():
 d=Document();setup(d,TITLE);p=para(d,TITLE,17,True,False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 p=para(d,'吴雨臻  李承昊  段璞',10.5,False,False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 p=para(d,'中国农业大学土地科学与技术学院，北京 100193',9.5,False,False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para(d,'摘要：'+ABSTRACT,10,False,False);para(d,'关键词：'+KEYWORDS,9.5,False,False)
 fn=tn=0;md=['# '+TITLE,'','吴雨臻　李承昊　段璞','','摘要：'+ABSTRACT,'','关键词：'+KEYWORDS,''];mapping=[];tt=tables()
 for i,(kind,x) in enumerate(BLOCKS):
  if kind.startswith('h'):head(d,x,int(kind[-1]));md+=['#'*int(kind[-1])+' '+x,'']
  elif kind=='p':para(d,x,keep=(i+1<len(BLOCKS) and BLOCKS[i+1][0]=='tab'));md +=[x,'']
  elif kind=='eq':
   p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(7);font(p.add_run(x[0]+'    ('+x[1]+')'),10.5);md +=[x[0]+' ('+x[1]+')','']
  elif kind=='fig':
   fn+=1;figure(d,x,fn);mapping.append(dict(Type='Figure',Number=fn,Key=x,File=FIGS[x][0]));md +=[f'![Figure {fn}](../figures/{FIGS[x][0]}.png)','',f'Figure {fn}. '+FIGS[x][1]+' '+FIGS[x][2],'']
  elif kind=='tab':
   tn+=1;title,heads,rows,note=tt[x];table(d,tn,title,heads,rows,note,widths=([2.4,1.2,7.0,2.2,4.4] if x=='parameters' else None));mapping.append(dict(Type='Table',Number=tn,Key=x,File='Manuscript_Table_'+str(tn)+'.csv'));pd.DataFrame(rows,columns=[h.replace('\n',' ') for h in heads]).to_csv(TB/f'Manuscript_Table_{tn}.csv',index=False,encoding='utf-8-sig');md +=[f'Table {tn}. '+title,'',markdown_table(heads,rows),'',note,'']
 head(d,'参考文献')
 for r in references():
  text=f'[{r["number"]}] '+r['CN']+(' DOI: '+r['DOI']+'.' if r['DOI'] else '');p=para(d,text,8.8,False,False);p.paragraph_format.space_after=Pt(2);p.paragraph_format.keep_together=True;md +=[text,'']
 path=OUT/'URP_Manuscript_CN_Rewritten_20261022.docx';d.save(path);(OUT/'URP_Manuscript_CN_Rewritten_20261022.md').write_text('\n'.join(md));pd.DataFrame(mapping).to_csv(TB/'Manuscript_figure_table_map.csv',index=False)
 print('manuscript',fn,'figures',tn,'tables',len(d.paragraphs),'paragraphs')
def supplement():
 d=Document();setup(d,'论文补充资料与统计口径');p=para(d,'论文补充资料与统计口径',16,True,False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para(d,'本补充资料对应2026年10月22日中文重写稿，记录原始资料接入、年度先验、采样诊断、灌水窗口和结构试验。所有数值来自既有运行记录及其统计汇总。本轮工作为论文重写、原始输入比较和图表重绘，未重新采样或重新求解灌溉模型。')
 head(d,'S1 新上传资料及模型执行日历')
 a=read('New_upload_data_audit.csv')
 table(d,'S1','Reconciliation of newly supplied data with frozen model inputs.',['Year','Climate rows','Weather max difference','RS rows','RS treatment'],[[int(r.Year),int(r.Climate_rows),f'{r.Max_absolute_weather_difference:.1f}',int(r.RS_rows),r.RS_treatment_label] for r in a.itertuples()],'Two supplied 2021 RS files are byte-identical. CCquad is converted from percent to fraction for auxiliary comparison.')
 para(d,'四年气象文件原值与归档输入一致。2019、2021、2022年按“播种日至终止日期两端均计入”汇总的降水，与实际执行日历总量存在差别，原因是模拟终止边界日的纳入方式；逐日值在实际执行日期上的最大差约为1.8×10⁻¹⁵ mm。模型ETo使用经审计的替代列，正文图3展示实际使用的ETo，而不是上传气象表原ETo列。模型日历为2019年4月18日至9月16日、2020年4月20日至9月19日、2021年4月27日至9月22日、2022年4月17日至9月12日，实际执行步数分别为151、152、148和148。')
 para(d,'2019—2021年Maize文件标签为BI；2022年文件没有灌溉处理标签。遥感序列保留为辅助资料。正式DI冠层似然使用论文LAI换算的48个观测点，生物量似然使用37个数字化点；本次重新上传资料没有改变原校准目标。')
 head(d,'S2 年度先验与参数范围')
 pr=read('Audit_Recorded_prior_distributions.csv');rows=[]
 for r in pr.itertuples():rows.append([int(r.Year),int(r.Phase),r.Parameter,'Uniform' if r.Prior_family=='uniform' else 'Truncated normal',f'{r.Lower:g}–{r.Upper:g}','–' if pd.isna(r.Gaussian_center) else f'{r.Gaussian_center:g}','–' if pd.isna(r.Gaussian_scale) else f'{r.Gaussian_scale:g}'])
 table(d,'S2','Annual MCMC prior distributions.',['Year','Phase','Parameter','Family','Support','Normal center','Normal scale'],rows,'The 2022 phase-2 supports differ from 2019–2021. Sobol experiments instead use one common independent uniform support in all years.')
 head(d,'S3 时间结构保留的采样诊断与参数中心')
 dx=read('Actual_sampling_diagnostics_and_center_stability.csv')
 table(d,'S3','Original-chain diagnostics and center sensitivity.',['Year','Phase','Independent ensembles','Worst R̂','Min group bulk ESS','Max τ','Burn-in mean shift (SD)'],[[int(r.Year),int(r.Phase),int(r.Independent_ensembles),'–' if pd.isna(r.Maximum_Rhat) else f'{r.Maximum_Rhat:.4f}','–' if pd.isna(r.Minimum_group_bulk_ESS) else f'{r.Minimum_group_bulk_ESS:.2f}',f'{r.Maximum_tau:.2f}',f'{r.Maximum_burnin_mean_shift_SD:.4f}'] for r in dx.itertuples()],'R̂ and bulk ESS summarize the extrema of 32 matched-walker comparisons across four independent phase-1 ensembles. Groups are dependent and are not added to obtain a pooled ESS.')
 para(d,'原第一阶段每年4个独立ensemble，每组32个walkers、2000步。4个独立ensemble的同编号walker构成一组链间比较，共32组，组内保留“时间步×独立ensemble”的原始顺序。这里报告的是组诊断极值，而不是将各walker随机混合后得到的ESS；它也不是把32组相加后的总体有效样本量。按照R̂<1.01及bulk/tail ESS≥400的判据，四年第一阶段仍存在有效样本不足和时间相关。阶段二每年1个独立ensemble，表中链间R̂、组bulk ESS以空项表示。均值在样本截取下较稳定，与完整分布的采样精度分别报告。')
 para(d,'对上传修订稿中的“R̂≤1.0048、最低bulk ESS=3200”，本稿未作为时间序列收敛结果沿用。正文使用原链诊断表，并通过固定参数均值进行确定性过程模拟。先前30分钟2021年续链试验不替换四年原参数：第一阶段公共链长2532步时最差R̂为1.0888、最小组bulk ESS为33.64，原均值最大变化为0.0087 SD；新增阶段二公共段500步，去除239步后每组保留261步。该试验数据另存独立研究目录。')
 head(d,'S4 四个灌水管理窗口')
 w=read('Four_management_windows.csv');table(d,'S4','Ordered irrigation-event groups used as the four decision variables.',['Year','Window','Event dates','Original total (mm)','Optimized total (mm)'],[[int(r.Year),'W'+str(int(r.Window)),r.Event_dates,f'{r.Baseline_mm:.2f}',f'{r.Optimized_mm:.2f}'] for r in w.itertuples()],'Groups are generated by np.array_split(ordered_event_indices, 4). Original dates and within-window weights are fixed. The grouping is distinct from five phenological stages.')
 para(d,'优化上限随方案计划日程设置为“计划最大单次水量+0.10 mm”和“计划季节水量+0.10 mm”，其作用是执行日程。因此，原最大单次实测水量并非额外的设备约束。2020年代表方案最大单次灌水约179.9 mm，应与原实测单次最大84.78 mm分列解释。')
 head(d,'S5 多目标与单目标结果的对应口径')
 c=read('NSGA_algorithm_comparison.csv');table(d,'S5','Formal equal-budget multi-objective algorithm summaries.',['Year','Algorithm','Union front size','Normalized hypervolume'],[[int(r.Year),r.Algorithm,int(r.Union_front_size),f'{r.Normalized_union_HV:.6f}'] for r in c.itertuples()],'Each algorithm uses 100 individuals, 100 generations and five seeds per year. Hypervolume comparisons use the archived common normalization and reference.')
 s=read('Scalar_Overall_best_95pct_candidates.csv');s=s[s.Case.str.startswith('old_')];table(d,'S6','Historical four-year scalar archive minima at 95% observed yield.',['Year','Method','Minimum I (mm)','Yield (t ha⁻¹)','Maximum event (mm)'],[[int(r.Year),r.Algorithm,f'{r.Irrigation_mm:.2f}',f'{r.Y_13pct:.3f}',f'{r.Max_actual_event_mm:.2f}'] for r in s.itertuples()],'These minima query each method’s own threshold-sweep archive; Figure 13 shows three-seed medians and ranges by method.')
 head(d,'S6 结构与驱动补充试验记录')
 para(d,'四年主结果固定fMulch=0、Zmax=2.30 m，与原MCMC及优化记录一致。2021年根深1 m、fMulch=0.50/0.75/0.85分别条件重校准，每阶段500步、10个walkers、4个独立ensemble，是结构敏感性先导试验。其DI产量为15.170、15.444、15.487 t·ha⁻¹，Es为57.35、49.90、45.71 mm，ET为618.90、590.37、600.10 mm；在95%观测产量门槛处的NSGA-III灌水量为319.11、282.72、287.53 mm。这些结果与四年主参数分开，不通过修改文字将其替换为四年fMulch=0.85结果。')
 para(d,'降水补充核对采用论文逐日降水图数字化近似和同日期GEE序列。按论文DI窗口，GEE降水为184.37、113.46、143.36、151.71 mm，图像重建为156.59、98.48、147.02、170.36 mm。该范围与实际模型执行日历的汇总方式分列。固定参数降水替换试验保留在原降水审计包，正文集中报告与原四年参数一致的主结果。')
 d.save(OUT/'URP_Supplementary_Methods_and_Diagnostics_20261022.docx')
def revision():
 d=Document();setup(d,'论文修改意见落实记录');p=para(d,'论文修改意见落实记录',16,True,False);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para(d,'依据：上传的23页《URP_Manuscript_CN_MCMC诊断口径修订版.pdf》全文与段落旁文字意见；王尚今2023年硕士论文；本次11份上传材料及四年原运行记录。论文参考其“问题—方法—结果—机制解释”的组织方式，采用本项目数据独立撰写。')
 items=[
 ('全文','文字与图表堆积；反复否定式提醒','正文按对应段落依次插入13张英文图和8张英文三线表；每图每表前给出数据解释；计算口径集中在方法与补充资料。'),
 ('第1～2页','摘要重写；突出已完成结果','摘要集中报告四年拟合、主要敏感参数、95%观测产量门槛的灌水量及水量来源。'),
 ('第2页','引言限定为三段','按膜下滴灌优化问题、已有模型与方法依据、本研究方法适配性三段重写；Liu等以正常学术引用介绍。'),
 ('第3页','三层技术路线','重画三列底纹流程图：资料整理、模型校准、敏感性与优化；使用完整英文标签。'),
 ('第4页','位置图高清英文，突出试验地','重画矢量站点位置图和400 m×200 m DI面积示意，依据论文坐标和面积；注明示意方向。'),
 ('第4页','DI土壤表译为英文','按论文表2-1逐层重建6层土壤表，加入砂、粉、黏粒及容重，质地为Silt loam。'),
 ('第4～6页','年度资料汇总三线表，删除Events列','Table 2汇总灌水、观测产量、CC/B配对数、ET及Es，删除事件数列。'),
 ('第5页','重新读入气象与CC文件','本次所有上传文件保留并计算SHA256；四年气象原值一致，两份2021遥感文件字节相同；辅助遥感与DI似然数据分别记录。'),
 ('第6页','建议正文固定fMulch=0.85','四年主结果按实际运行保留fMulch=0；0.85属于2021条件重校准，移至补充资料，不改写为四年主设定。'),
 ('第7页','公式单列居中','正文12个公式居中编号，水量平衡与差额分解分列；变量定义与使用范围紧随正文。'),
 ('第7页','MCMC诊断只写指标、含义、要求','方法简述R̂、bulk/tail ESS和τ及判据；算法分组与完整诊断移至补充资料。'),
 ('第8页','核对四个还是五个时期','源码np.array_split(...,4)为四个管理窗口；五个生育期按田间发育描述；窗口日期和水量列Table S4。'),
 ('第8页','优化方法重写，说明固定参数','写明NSGA-II/III及四个连续单目标算法，列出固定的作物参数、土壤、初值、气象、覆膜、根系和灌水日期。'),
 ('第8页','2.7聚焦水量核算','主文2.7只保留剖面平衡与灌水差额分解；根深、地膜、降水补充试验集中移至S6。'),
 ('第9页','结果重写，补参数、拟合和诊断','Table 4给出8参数4年均值；CC、B、Yield均用原结果。原链R̂和ESS与均值敏感性分别表述。'),
 ('第1/9页','稿件声称R̂≤1.0048、bulk ESS≥3200','替换为保留时间结构的原链记录：年度最差R̂为1.122～1.181、最小组bulk ESS为17.79～25.34；不以混合walker序列的统计量证明收敛。'),
 ('第13页','四年生物量线性拟合','重新以观测X、模拟Y计算：斜率0.9979、截距0.2412、OLS R²0.9892、Pearson r0.9946，37对。'),
 ('第14～16页','Sobol合并图及四年均值','统一2×2输出图，R02合为S1/ST并列，保留年度数值区间和四年均值；以年度平均排序一致解释均值用途。'),
 ('第17页','帕累托按示例样式','四年2×2，蓝虚线、红解点、四窗口标签，完整0至原灌水范围；所有标签对应真实解。'),
 ('第18～22页','突出优化结论、减少枝节','正文围绕灌水—产量、水量来源、多算法一致性论述；2021年减少增储169.97 mm与初值耗储186.74 mm分开解释。'),
 ]
 table(d,'R1','Point-by-point revision record.',['Source page','Comment','Implementation'],items,'Source-page numbering refers to the uploaded annotated manuscript.',english=False,widths=[1.7,4.3,11.2])
 head(d,'结果口径的三个关键决定')
 for t in ['fMulch：主文使用已经实际运行的四年设置0；三个地膜条件试验移至补充资料，四年数据不因文字修改被重新标记。','窗口：优化是4维管理分组，田间是5个生育期，明确两者的含义和日期。','采样：均值稳定性与完整分布精度分开报告；将修订稿中的高ESS和小R̂替换为原时间序列诊断表，保留来源。']:para(d,t)
 d.save(OUT/'URP_Revision_Response_20261022.docx')
 pd.DataFrame(items,columns=['Source_page','Comment','Implementation']).to_csv(TB/'Revision_response_matrix.csv',index=False,encoding='utf-8-sig')
def workbook():
 files=list(TB.glob('*.csv'))
 with pd.ExcelWriter(TB/'URP_Manuscript_Data_and_Revision_20261022.xlsx',engine='openpyxl') as w:
  used=set()
  for i,p in enumerate(files):
   name=re.sub(r'[^A-Za-z0-9_ ]','_',p.stem)[:27]
   if name in used:name=f'{i:02d}_'+name[:25]
   used.add(name);pd.read_csv(p).to_excel(w,sheet_name=name,index=False)
  for s in w.book.worksheets:
   s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
   for c in list(s.columns)[:18]:s.column_dimensions[c[0].column_letter].width=min(42,max(12,len(str(c[0].value or ''))+2))
def main():
 OUT.mkdir(exist_ok=True);manuscript();supplement();revision();workbook()
if __name__=='__main__':main()
