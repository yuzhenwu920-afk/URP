from pathlib import Path
import json, shutil, hashlib, urllib.request
import pandas as pd
import numpy as np
from scipy.stats import linregress

ROOT=Path(__file__).resolve().parents[1]
ARCH=Path('/workspace/urp_final_research_archive_20261021')
TB=ARCH/'stages/11_English_figures_tables_and_interpretations/tables'
FINAL=ARCH/'stages/11_English_figures_tables_and_interpretations/Final_revision/tables'
DX=Path('/workspace/urp_original_chain_diagnostic_20261022/tables')
SC=ARCH/'stages/10_Single_objective_multi_algorithm_validation/tables'
INPUTS={
'Manuscript_comments.pdf':'/workspace/attachments/1211958e-ab79-4bba-a1ff-29b62f60f8dc/URP_Manuscript_CN_MCMC诊断口径修订版.pdf',
'Wang_2023_Thesis.pdf':'/workspace/attachments/f580eabd-7919-4758-9212-fe7213dbbd78/王尚今081500水利工程20230621143311.pdf',
'Maize_2022.csv':'/workspace/attachments/4995ef85-037c-4488-a22c-fbdd1baa9cc3/Maize-2022-main.csv',
'Climate_2022.csv':'/workspace/attachments/86be7011-ff2a-4d7d-9525-bfb7bde59e17/DI_Climate_2022_FINAL.csv',
'Maize_2021_A.csv':'/workspace/attachments/21cec978-73e6-444f-bc26-b4d3b2422c83/Maize-2021-main.csv',
'Maize_2021_B.csv':'/workspace/attachments/7f71bf24-ffa8-4b77-b77f-69b91ecc30d5/Maize-2021-main.csv',
'Climate_2021.csv':'/workspace/attachments/e3c62f7e-df25-4f0c-8761-3f14bffc2b58/DI_Climate_2021_FINAL.csv',
'Maize_2020.csv':'/workspace/attachments/7c1de04d-1f19-4543-988d-244658aa5231/Maize-2020-main(2).csv',
'Climate_2020.csv':'/workspace/attachments/8916219a-4d4c-4a8a-9735-a39f2f856427/DI_Climate_2020_FINAL(2).csv',
'Maize_2019.csv':'/workspace/attachments/03fd638e-f161-4423-b620-e68c33fda546/Maize-2019-main(2).csv',
'Climate_2019.csv':'/workspace/attachments/08f9632b-abae-425d-b071-da1c2218129a/DI_Climate_2019_FINAL(2).csv',
}
def save(df,name):df.to_csv(ROOT/'tables'/name,index=False,encoding='utf-8-sig')
def main():
 for p in ['source/uploads','source/method_records','tables','figures','documents','analysis','code']:(ROOT/p).mkdir(parents=True,exist_ok=True)
 manifest=[]
 for name,path in INPUTS.items():
  dst=ROOT/'source/uploads'/name;shutil.copy2(path,dst)
  manifest.append(dict(Name=name,Original_path=path,Bytes=dst.stat().st_size,SHA256=hashlib.sha256(dst.read_bytes()).hexdigest()))
 save(pd.DataFrame(manifest),'Uploaded_file_inventory.csv')
 for n in ['Table1_study_data.csv','Table2_parameter_definitions.csv','Table3_calibration_performance.csv','Table5_selected_candidates.csv','F02_CC_calibration_pairs.csv','F05_Biomass_calibration_pairs.csv','Calibration_daily_growth.csv','central_vectors_with_provenance.csv','Annual_model_calendar.csv','F09_annual_water_budget.csv','Sobol_annual_means_and_ranks.csv','Sobol_four_year_descriptive_means.csv','Sobol_year_pair_rank_agreement.csv','NSGA_algorithm_comparison.csv','NSGA_event_schedules.csv','Original_main_NSGA_main_candidates.csv','Original_main_Water_ledger_baseline_and_candidate.csv','Original_main_Irrigation_saving_decomposition.csv','Full_range_best_found_front.csv','Terminal_storage_screening.csv','Zero_irrigation_reference.csv']:
  shutil.copy2(TB/n,ROOT/'tables'/n)
 for n in ['Pareto_display_points.csv','Pooled_biomass_OLS_summary.csv','Pooled_biomass_observedX_simulatedY_pairs.csv','R02_annual_scramble_mean_bootstrap.csv']:
  shutil.copy2(FINAL/n,ROOT/'tables'/n)
 for n in ['Sampling_and_convergence_summary.csv','Parameter_diagnostics.csv','Burnin_sensitivity.csv','Observation_coverage.csv','Recorded_prior_distributions.csv']:
  shutil.copy2(DX/n,ROOT/'tables'/('Audit_'+n))
 for n in ['Within_method_sweep_archive_minima.csv','At_95pct_observed_summary.csv','Overall_best_95pct_candidates.csv','Independent_only_results.csv']:
  shutil.copy2(SC/n,ROOT/'tables'/('Scalar_'+n))
 shutil.copy2(ARCH/'stages/12_Chinese_and_English_manuscripts/source/REFERENCE_EVIDENCE.json',ROOT/'source/REFERENCE_EVIDENCE.json')
 for n in ['four_year_adapter.py','model_2021/DI_2021_MCMC_ONE_CLICK.py']:
  src=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/real_model')/n;shutil.copy2(src,ROOT/'source/method_records'/src.name)
 # Compare newly supplied weather and RS files against the actual frozen model inputs.
 audit=[];daily=[];rs=[];cal=pd.read_csv(TB/'Annual_model_calendar.csv')
 for year in range(2019,2023):
  clim=pd.read_csv(ROOT/f'source/uploads/Climate_{year}.csv');clim['Date']=pd.to_datetime(clim['date']);clim=clim.sort_values('Date')
  rec=cal[cal.Year==year].iloc[0];w=clim[clim.Date.between(rec.Planting_date,rec.Calendar_cutoff)].copy();w['Year']=year
  frozen=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/real_model')/f'model_{year}/data/inputs'
  candidates=list(frozen.glob('*WEATHER*'))
  old=pd.read_csv(candidates[0]) if candidates else None
  numerical_equal=False;maxdiff=np.nan
  if old is not None:
   odate='date' if 'date' in old else 'Date';old['Date']=pd.to_datetime(old[odate]);joined=clim.merge(old,on='Date',suffixes=('_new','_old'))
   cols=[c for c in ['Tmin_C','Tmax_C','Precip_mm','ETo_mm'] if c+'_new' in joined and c+'_old' in joined]
   maxdiff=max((float(np.nanmax(np.abs(joined[c+'_new']-joined[c+'_old']))) for c in cols),default=np.nan)
   numerical_equal=bool(len(joined)==len(clim)==len(old) and maxdiff<1e-10)
  rsname=f'Maize_{year}_A.csv' if year==2021 else f'Maize_{year}.csv';rr=pd.read_csv(ROOT/'source/uploads'/rsname);rr['Date']=pd.to_datetime(rr['date']);rr['Year']=year;rr['CC_fraction']=rr.CCquad/100
  audit.append(dict(Year=year,Climate_rows=len(clim),Unique_dates=clim.Date.nunique(),Missing_dates=len(pd.date_range(clim.Date.min(),clim.Date.max()).difference(clim.Date)),Tmin_above_Tmax=int((clim.Tmin_C>clim.Tmax_C).sum()),Negative_rain=int((clim.Precip_mm<0).sum()),Raw_ETo_total_model_calendar_mm=w.ETo_mm.sum(),Rain_total_model_calendar_mm=w.Precip_mm.sum(),Frozen_rain_mm=rec.Rain_mm,Max_absolute_weather_difference=maxdiff,Matches_frozen_weather=numerical_equal,RS_rows=len(rr),RS_treatment_label=','.join(rr.IrriMetho.unique()) if 'IrriMetho' in rr else 'not supplied',RS_CC_min=rr.CC_fraction.min(),RS_CC_max=rr.CC_fraction.max(),Source_calendar_start=rec.Planting_date,Source_calendar_end=rec.Calendar_cutoff))
  daily.append(w);rs.append(rr)
 save(pd.DataFrame(audit),'New_upload_data_audit.csv');save(pd.concat(daily,ignore_index=True),'Uploaded_climate_model_calendars.csv');save(pd.concat(rs,ignore_index=True),'Uploaded_RS_CC_auxiliary.csv')
 env=pd.read_csv(TB/'Figure10_daily_environment.csv');temp=pd.concat(daily)[['Year','Date','Tmin_C','Tmax_C','Precip_mm']].copy();temp.Date=temp.Date.dt.strftime('%Y-%m-%d');env=env.merge(temp,on=['Year','Date'],validate='one_to_one');save(env,'Environmental_drivers_used.csv')
 for a in audit:
  s=env[env.Year==a['Year']];a['Executed_model_days']=len(s);a['Rain_on_executed_dates_mm']=s.Precip_mm.sum();a['Max_daily_precip_difference_on_executed_dates']=float(np.abs(s.Precip_mm-s.Precipitation_mm).max())
 save(pd.DataFrame(audit),'New_upload_data_audit.csv')
 soil=pd.DataFrame({'Depth_cm':['0–10','10–20','20–40','40–60','60–80','80–100'],'Sand_pct':[29.70,30.81,19.43,13.22,10.38,11.81],'Silt_pct':[59.66,58.67,68.25,70.58,74.87,76.53],'Clay_pct':[10.64,10.52,12.32,16.20,14.75,11.66],'Bulk_density_g_cm3':[1.65,1.65,1.69,1.29,1.48,1.45],'Texture':['Silt loam']*6});save(soil,'DI_soil_profile_thesis_Table2_1.csv')
 events=pd.read_csv(TB/'NSGA_event_schedules.csv');windows=[]
 for (year,window),s in events.groupby(['Year','Window']):windows.append(dict(Year=year,Window=int(window),Event_dates='; '.join(s.Date),Baseline_mm=s.Baseline_mm.sum(),Optimized_mm=s.Candidate_actual_mm.sum()))
 save(pd.DataFrame(windows),'Four_management_windows.csv')
 # Source regression is recomputed from the requested observed-X, simulated-Y pairs.
 b=pd.read_csv(TB/'F05_Biomass_calibration_pairs.csv');fit=linregress(b.B_observed_t_ha,b.B_simulated_t_ha)
 reg=dict(N=len(b),Slope=fit.slope,Intercept=fit.intercept,OLS_R2=fit.rvalue**2,Pearson_r=fit.rvalue,RMSE=float(np.sqrt(np.mean((b.B_simulated_t_ha-b.B_observed_t_ha)**2))),X='Observed aboveground dry biomass',Y='Simulated aboveground dry biomass')
 save(pd.DataFrame([reg]),'Pooled_biomass_regression_verified.csv')
 # Exact diagnostic numbers, without flattening walkers into time or adding dependent groups.
 dx=pd.read_csv(DX/'Parameter_diagnostics.csv');summary=pd.read_csv(DX/'Sampling_and_convergence_summary.csv')
 burn=pd.read_csv(DX/'Burnin_sensitivity.csv');rows=[]
 for (year,phase),s in dx.groupby(['Year','Phase']):
  bb=burn[(burn.Year==year)&(burn.Phase==phase)];shifts=[]
  for p,z in bb.groupby('Parameter'):
   base=s[s.Parameter==p].iloc[0];shifts.extend(abs(z.Mean-base.Mean)/base.SD)
  rr=summary[(summary.Year==year)&(summary.Phase==phase)].iloc[0]
  rows.append(dict(Year=year,Phase=phase,Maximum_burnin_mean_shift_SD=max(shifts),Maximum_ensemble_mean_span_SD=s.Ensemble_mean_span_SD.max(),Maximum_pooled_half_shift_SD=s.Pooled_half_shift_SD.abs().max(),Maximum_Rhat=rr.Worst_matched_walker_Rhat,Minimum_group_bulk_ESS=rr.Worst_matched_walker_bulk_ESS,Maximum_tau=rr.Max_tau,Independent_ensembles=rr.Independent_ensembles))
 save(pd.DataFrame(rows),'Actual_sampling_diagnostics_and_center_stability.csv')
 # Optional geographical context, never used in the crop-model calculations.
 geo=ROOT/'source/china_provinces_context.geojson';url='https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json'
 if not geo.exists():
  try:
   with urllib.request.urlopen(url,timeout=20) as r:payload=r.read()
   obj=json.loads(payload);assert 'features' in obj;geo.write_bytes(payload)
   (ROOT/'source/map_context_provenance.json').write_text(json.dumps(dict(URL=url,Purpose='Administrative context for site locator; approximate station coordinates from Wang 2023, no parcel georeferencing',SHA256=hashlib.sha256(payload).hexdigest()),ensure_ascii=False,indent=2))
  except Exception as e:(ROOT/'source/map_context_provenance.json').write_text(json.dumps(dict(URL=url,Status='unavailable',Reason=str(e)),indent=2))
 print(pd.DataFrame(audit).to_string(index=False));print(pd.DataFrame(rows).to_string(index=False));print(reg)
if __name__=='__main__':main()
