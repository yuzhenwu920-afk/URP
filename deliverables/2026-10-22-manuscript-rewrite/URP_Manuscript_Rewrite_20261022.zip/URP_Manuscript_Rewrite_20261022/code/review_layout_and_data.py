from pathlib import Path
import json,re
import numpy as np
import pandas as pd
from PIL import Image,ImageDraw
from docx import Document
import fitz
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'analysis'
def contact_figures():
 ims=[]
 for p in sorted((ROOT/'figures').glob('*.png')):
  im=Image.open(p).convert('RGB');im.thumbnail((520,340));can=Image.new('RGB',(550,380),'white');can.paste(im,((550-im.width)//2,15));ImageDraw.Draw(can).text((8,360),p.stem,fill='black');ims.append(can)
 contact=Image.new('RGB',(1650,380*((len(ims)+2)//3)), '#CFD8DC')
 for i,im in enumerate(ims):contact.paste(im,((i%3)*550,(i//3)*380))
 contact.save(OUT/'All_figures_contact.jpg',quality=90)
def review():
 counts={};edge=[]
 for p in (ROOT/'documents').glob('*.pdf'):
  d=fitz.open(p);thumbs=[];pages=[]
  for i,pg in enumerate(d):
   pix=pg.get_pixmap(matrix=fitz.Matrix(.42,.42));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);can=Image.new('RGB',(270,375),'white');can.paste(im,(10,10));ImageDraw.Draw(can).text((12,356),f'Page {i+1}',fill='black');thumbs.append(can)
   pages.append(dict(Page=i+1,Text_chars=len(pg.get_text()),Captions=[b[4].replace('\n',' ') for b in pg.get_text('blocks') if 'Figure ' in b[4] or 'Table ' in b[4]]))
   for b in pg.get_text('dict')['blocks']:
    for l in b.get('lines',[]):
     for s in l['spans']:
      if s['bbox'][0]<15 or s['bbox'][2]>pg.rect.width-15:edge.append(dict(File=p.name,Page=i+1,Text=s['text'],Box=s['bbox']))
  c=Image.new('RGB',(270*5,375*((len(thumbs)+4)//5)),'#CFD8DC')
  for i,im in enumerate(thumbs):c.paste(im,((i%5)*270,(i//5)*375))
  c.save(OUT/(p.stem+'_contact.jpg'),quality=88);counts[p.name]=dict(Pages=len(d),Page_summary=pages)
  if 'Manuscript' in p.name:
   (OUT/'output_manuscript_pdf_text.txt').write_text('\n\n'.join(f'PAGE {i+1}\n'+pg.get_text(sort=True) for i,pg in enumerate(d)))
   for i in [0,3,7,10,13]:
    if i<len(d):d[i].get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(OUT/f'Output_page_{i+1}.png')
 for k,v in counts.items():print(k,'pages',v['Pages'])
 fig_cjk=[]
 for p in (ROOT/'figures').glob('*.pdf'):
  txt=''.join(pg.get_text() for pg in fitz.open(p))
  if re.search(r'[\u4e00-\u9fff]',txt):fig_cjk.append(p.name)
 assert not fig_cjk,fig_cjk
 doc=Document(ROOT/'documents/URP_Manuscript_CN_Rewritten_20261022.docx');assert len(doc.inline_shapes)==13;assert len(doc.tables)==8
 can=pd.read_csv(ROOT/'tables/Original_main_NSGA_main_candidates.csv');assert np.all(can.Y13>=.95*can.Observed_Y13)
 dec=pd.read_csv(ROOT/'tables/Original_main_Irrigation_saving_decomposition.csv');err=dec.Irrigation_saving_mm-(dec.ET_reduction_mm+dec.Reduced_soil_storage_gain_mm+dec.Loss_reduction_mm);assert max(abs(err))<1e-8
 dx=pd.read_csv(ROOT/'tables/Actual_sampling_diagnostics_and_center_stability.csv');assert dx[dx.Phase==1].Maximum_Rhat.min()>1.01;assert dx[dx.Phase==1].Minimum_group_bulk_ESS.max()<400
 a=pd.read_csv(ROOT/'tables/New_upload_data_audit.csv');assert a.Matches_frozen_weather.all();assert a.Missing_dates.sum()==0
 text='\n'.join(p.text for p in doc.paragraphs);forbidden=['不能作为','无偏的','证明MCMC较好的收敛性','最低bulk ESS为3200','尚不是','未开展','此地无银','G老师']
 assert not any(s in text for s in forbidden)
 results=dict(Document_layout=counts,Figures=13,Main_three_line_tables=8,Figure_CJK_labels=fig_cjk,PDF_text_outside_15pt_edge=edge,Water_difference_max_error_mm=float(max(abs(err))),Scientific_sampling_diagnostics='Original time-preserving values retained',New_forward_model_calls_this_revision=0)
 (OUT/'OUTPUT_REVIEW.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('edge_spans',len(edge));print('data and document review passed')
if __name__=='__main__':contact_figures();review()
