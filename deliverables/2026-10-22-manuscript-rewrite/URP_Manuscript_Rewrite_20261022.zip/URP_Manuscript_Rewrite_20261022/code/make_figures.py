from pathlib import Path
import json,string
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon, Rectangle
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parents[1];TB=ROOT/'tables';OUT=ROOT/'figures'
YEARS=[2019,2020,2021,2022];COLORS=['#0072B2','#D55E00','#009E73','#AA4499'];C=dict(zip(YEARS,COLORS))
PARAMS=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
LABELS=['CCx','CGC','CDC','Senescence','Kcb','WP early','WP late','HI0']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.8,'grid.alpha':.23,'grid.color':'#AFBBC3','pdf.fonttype':42,'svg.fonttype':'none','hatch.linewidth':.25})
def read(n):return pd.read_csv(TB/n)
def save(fig,name):
 for ext in ['png','pdf','svg']:fig.savefig(OUT/(name+'.'+ext),dpi=450,bbox_inches='tight',facecolor='white')
 plt.close(fig)
def panel(ax,i,title):ax.set_title(f'({string.ascii_lowercase[i]}) {title}',loc='left',weight='bold',pad=8)
def grid(ax):ax.grid(True,axis='both',zorder=0)
def workflow():
 fig,ax=plt.subplots(figsize=(8.1,3.35));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
 items=[('Data preparation',['Temperature, rainfall\nand reference ET','Soil profile and\ninitial water','DI schedule and\nmulch coverage','LAI-derived CC,\nbiomass and yield'],'#EAF3F8','///'),('Model calibration',['AquaCrop\nprocess simulation','Stage 1: canopy and\nwater-use parameters','Stage 2: water productivity\nand harvest index','Fit, sampling and\nboundary diagnostics'],'#EAF3ED','...'),('Sensitivity and\noptimization',['Sobol analysis:\nsix model outputs','NSGA-II / NSGA-III:\nfour irrigation windows','Yield targets and\nsolver comparison','Water balance and\nstorage analysis'],'#F9F0E6','\\\\')]
 for i,(title,lines,color,hatch) in enumerate(items):
  x=.01+i*.34
  ax.add_patch(FancyBboxPatch((x,.12),.30,.81,boxstyle='round,pad=.008,rounding_size=.012',facecolor=color,edgecolor='#61747E',linewidth=.7,hatch=hatch,zorder=0))
  ax.text(x+.15,.845,title,ha='center',va='center',fontsize=10.5,weight='bold',bbox=dict(facecolor=color,edgecolor='none',pad=2))
  for j,line in enumerate(lines):
   yy=.655-j*.15;ax.text(x+.15,yy,line,ha='center',va='center',fontsize=8.4,linespacing=1.15,bbox=dict(facecolor='white',alpha=.96,edgecolor='none',pad=3))
  if i<2:ax.annotate('',xy=(x+.337,.51),xytext=(x+.303,.51),arrowprops=dict(arrowstyle='->',color='#435A66',lw=1.5))
 save(fig,'Fig01_Research_workflow_EN')
def site():
 fig,(ax,bx)=plt.subplots(1,2,figsize=(7.4,2.8),gridspec_kw={'width_ratios':[1.15,1]},layout='constrained')
 path=ROOT/'source/china_provinces_context.geojson'
 if path.exists():
  for f in json.loads(path.read_text())['features']:
   g=f['geometry'];polys=g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']]
   for poly in polys:
    ax.add_patch(Polygon(poly[0],facecolor='#EAF1F2' if f['properties']['name']!='甘肃省' else '#C0DCD6',edgecolor='#72868B',lw=.35))
  ax.set(xlim=(73,136),ylim=(17,55));ax.set_aspect(1.15);ax.set_xticks([80,100,120]);ax.set_yticks([20,35,50]);ax.set_xlabel('Longitude (°E)');ax.set_ylabel('Latitude (°N)')
 else:ax.set(xlim=(100,105),ylim=(36,40),xlabel='Longitude (°E)',ylabel='Latitude (°N)')
 lon,lat=102+52/60,37+52/60;ax.scatter(lon,lat,marker='*',s=105,c='#D55E00',zorder=10);ax.annotate('Shiyanghe station\nWuwei, Gansu',xy=(lon,lat),xytext=(114,45),fontsize=8,arrowprops=dict(arrowstyle='-',lw=.7),bbox=dict(facecolor='white',edgecolor='none',alpha=.9,pad=2));panel(ax,0,'Study-site location')
 bx.axis('off');bx.set(xlim=(-25,465),ylim=(-60,275));bx.set_aspect('equal');bx.add_patch(Rectangle((0,0),400,200,facecolor='#EAF3ED',edgecolor='#52756B',lw=1.2))
 for k in range(10,200,18):bx.plot([5,395],[k,k],color='#9DC1B5',lw=1)
 bx.annotate('',xy=(0,-22),xytext=(400,-22),arrowprops=dict(arrowstyle='<->',lw=.8));bx.text(200,-28,'400 m',ha='center',va='top',fontsize=9)
 bx.annotate('',xy=(423,0),xytext=(423,200),arrowprops=dict(arrowstyle='<->',lw=.8));bx.text(435,100,'200 m',rotation=90,va='center',fontsize=9)
 bx.text(200,106,'Drip-irrigated maize field\n75% film coverage',ha='center',va='center',fontsize=10,bbox=dict(facecolor='white',alpha=.9,edgecolor='none',pad=4))
 bx.text(200,248,"37°52′ N, 102°52′ E  |  1581 m",ha='center',fontsize=9);bx.text(200,-58,'Field-size schematic; orientation is illustrative',ha='center',fontsize=7.8,color='#536872');panel(bx,1,'DI field dimensions')
 save(fig,'Fig02_Study_site_EN')
def environment():
 d=read('Environmental_drivers_used.csv');fig,axs=plt.subplots(2,2,figsize=(7.6,4.6),layout='constrained',sharey=True)
 ymax=max(d.Precipitation_mm.max(),d.Reference_ET0_mm_d.max())*1.15
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y];x=pd.to_datetime(s.Date);ax.bar(x,s.Precipitation_mm,color='#72AED0',width=1.2,zorder=2,alpha=.85);ax.plot(x,s.Reference_ET0_mm_d,color='#D55E00',lw=1.05);ax.set_ylim(0,ymax);ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Daily water flux (mm d$^{-1}$)')
 handles=[Line2D([],[],color='#72AED0',lw=6,label='Precipitation'),Line2D([],[],color='#D55E00',label='Reference evapotranspiration (ETo)')]
 fig.legend(handles=handles,loc='outside upper center',ncol=2,frameon=False);save(fig,'Fig03_Environmental_drivers_EN')
def cc():
 d=read('Calibration_daily_growth.csv');p=read('F02_CC_calibration_pairs.csv');m=read('Table3_calibration_performance.csv');fig,axs=plt.subplots(2,2,figsize=(7.6,4.8),layout='constrained',sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y];o=p[p.Year==y];r=m[m.Year==y].iloc[0];ax.plot(pd.to_datetime(s.Date),s.canopy_cover,c=C[y],lw=1.7);ax.scatter(pd.to_datetime(o.Date),o.CC_observed,facecolor='white',edgecolor='#243C48',s=25,zorder=3);ax.set_ylim(-.025,1.06);ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));ax.text(.035,.95,f'$R^2_{{cal}}$ = {r.CC_R2_cal:.3f}\nRMSE = {r.CC_RMSE:.3f}\n$n$ = {len(o)}',transform=ax.transAxes,va='top',fontsize=8.6);panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Canopy cover (fraction)')
 fig.legend(handles=[Line2D([],[],c='#526F7B',lw=1.7,label='Simulation'),Line2D([],[],marker='o',mfc='white',mec='#243C48',ls='',label='LAI-derived observations')],loc='outside upper center',ncol=2,frameon=False);save(fig,'Fig04_CC_calibration_EN')
def biomass():
 d=read('F05_Biomass_calibration_pairs.csv');m=read('Table3_calibration_performance.csv');fig,axs=plt.subplots(2,2,figsize=(7.4,4.8),layout='constrained',sharex=True,sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y];r=m[m.Year==y].iloc[0];ax.plot([0,42],[0,42],ls='--',color='#88969E',lw=1);ax.scatter(s.B_observed_t_ha,s.B_simulated_t_ha,c=C[y],s=28,edgecolors='white',lw=.4,zorder=3);ax.set(xlim=(0,42),ylim=(0,42));ax.text(.04,.95,f'$R^2_{{cal}}$ = {r.Biomass_R2_cal:.3f}\nRMSE = {r.Biomass_RMSE_t_ha:.2f} t ha$^{{-1}}$\n$n$ = {len(s)}',transform=ax.transAxes,va='top',fontsize=8.6);panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Simulated biomass (t ha$^{-1}$)')
  if i>=2:ax.set_xlabel('Observed biomass (t ha$^{-1}$)')
 save(fig,'Fig05_Biomass_calibration_EN')
def parameters():
 d=read('Audit_Parameter_diagnostics.csv');fig,axs=plt.subplots(2,4,figsize=(8.0,4.0),layout='constrained');units=['fraction','d$^{-1}$','d$^{-1}$','d','–','g m$^{-2}$','g m$^{-2}$','fraction']
 for i,(ax,p,u) in enumerate(zip(axs.flat,PARAMS,units)):
  s=d[d.Parameter==p]
  for k,y in enumerate(YEARS):
   r=s[s.Year==y].iloc[0];ax.plot([r.Prior_low,r.Prior_high],[k,k],c='#CBD3D6',lw=3,zorder=1);ax.plot([r.P025,r.P975],[k,k],c=C[y],lw=2,zorder=2);ax.scatter(r.Mean,k,c=C[y],s=19,zorder=3)
  ax.set_yticks(range(4),[str(y) for y in YEARS] if i%4==0 else []);ax.invert_yaxis();ax.set_xlabel(u);ax.set_title(LABELS[i],weight='bold',fontsize=10);ax.grid(axis='x');ax.tick_params(axis='x',labelsize=8)
 fig.legend(handles=[Line2D([],[],c='#CBD3D6',lw=3,label='Prior support'),Line2D([],[],c='#526F7B',lw=2,marker='o',label='Retained mean and 2.5–97.5% interval')],loc='outside upper center',ncol=2,frameon=False);save(fig,'Fig06_Parameter_intervals_EN')
def pooled():
 d=read('F05_Biomass_calibration_pairs.csv');r=read('Pooled_biomass_regression_verified.csv').iloc[0];fig,ax=plt.subplots(figsize=(5.4,3.9),layout='constrained');x=np.array([0,42]);ax.plot(x,x,ls='--',c='#82959D',lw=1,label='1:1 line');ax.plot(x,r.Intercept+r.Slope*x,c='#263E49',lw=1.5,label='Pooled OLS fit')
 for y in YEARS:
  s=d[d.Year==y];ax.scatter(s.B_observed_t_ha,s.B_simulated_t_ha,s=28,c=C[y],label=str(y),zorder=3,edgecolor='white',lw=.4)
 ax.text(.04,.95,f'$y$ = {r.Slope:.3f}$x$ + {r.Intercept:.3f}\nOLS $R^2$ = {r.OLS_R2:.4f}\nPearson $r$ = {r.Pearson_r:.4f}\n$n$ = {int(r.N)}',transform=ax.transAxes,va='top',fontsize=9);ax.set(xlim=(0,42),ylim=(0,42),xlabel='Observed biomass (t ha$^{-1}$)',ylabel='Simulated biomass (t ha$^{-1}$)');grid(ax);ax.legend(loc='lower right',ncol=2,frameon=False,fontsize=8.5);save(fig,'Fig07_Pooled_biomass_regression_EN')
def water():
 d=read('F09_annual_water_budget.csv');fig,ax=plt.subplots(figsize=(7.3,2.8),layout='constrained');x=np.arange(4)
 for col,label,color,marker in [('Inflow_mm','Inflow: irrigation + precipitation','#0072B2','o'),('Outflow_mm','Outflow: ET + water losses','#D55E00','s'),('Storage_change_mm','Storage change: final − initial','#009E73','D')]:ax.plot(x,d[col],c=color,marker=marker,lw=1.7,label=label)
 ax.axhline(0,c='#8C9EA5',lw=.7);ax.set_xticks(x,YEARS);ax.set_ylabel('Seasonal water balance (mm)');grid(ax);ax.legend(loc='upper left',bbox_to_anchor=(.0,1.24),ncol=1,frameon=False,fontsize=8.7);save(fig,'Fig08_Annual_water_balance_EN')
def sobol():
 d=read('Sobol_annual_means_and_ranks.csv');outs=[('Y_13pct','Grain yield'),('B_t_ha','Aboveground biomass'),('ET_mm','Seasonal evapotranspiration'),('MaxCC','Maximum canopy cover')];fig,axs=plt.subplots(2,2,figsize=(7.7,5.0),layout='constrained')
 for i,(ax,(o,t)) in enumerate(zip(axs.flat,outs)):
  a=d[d.Output==o].pivot(index='Year',columns='Parameter',values='ST_mean').loc[YEARS,PARAMS].to_numpy();im=ax.imshow(a,vmin=0,vmax=1,cmap='YlGnBu',aspect='auto');ax.set_xticks(range(8),LABELS,rotation=45,ha='right',fontsize=8);ax.set_yticks(range(4),YEARS);panel(ax,i,t)
  for j in range(4):
   for k in range(8):ax.text(k,j,f'{a[j,k]:.2f}',ha='center',va='center',fontsize=7.4,color='white' if a[j,k]>.48 else '#203640')
 fig.colorbar(im,ax=list(axs.flat),location='right',fraction=.025,pad=.015,label='Total-effect Sobol index ($S_T$)');save(fig,'Fig09_Sobol_four_outputs_EN')
def yield_ci():
 d=read('R02_annual_scramble_mean_bootstrap.csv');fig,axs=plt.subplots(1,2,figsize=(7.8,4.1),layout='constrained',sharey=True)
 for i,(ax,col) in enumerate(zip(axs,['S1','ST'])):
  for j,y in enumerate(YEARS):
   s=d[d.Year==y].set_index('Parameter').loc[PARAMS];ax.errorbar(s[col],np.arange(8)+(j-1.5)*.14,xerr=s[col+'_bootstrap95_halfwidth'],fmt='o',ms=3.4,c=C[y],lw=.7,capsize=1.7,label=str(y))
  means=d.groupby('Parameter')[col].mean().loc[PARAMS];ax.scatter(means,np.arange(8)+.35,marker='D',c='#263E49',s=21,label='Four-year mean',zorder=4);ax.set_yticks(range(8),LABELS);ax.set_ylim(7.7,-.6);ax.set_xlim(-.025,.51);ax.set_xlabel('Sobol index');panel(ax,i,'First-order effect ($S_1$)' if col=='S1' else 'Total effect ($S_T$)');ax.grid(axis='x')
 handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=5,frameon=False,fontsize=8.3);save(fig,'Fig10_Yield_Sobol_CI_EN')
def pareto():
 d=read('Full_range_best_found_front.csv');b=read('Original_main_NSGA_main_candidates.csv');display=[];fig,axs=plt.subplots(2,2,figsize=(8.1,5.6),layout='constrained',sharey=True)
 for i,(ax,y) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==y].sort_values('Irrigation_mm');r=b[b.Year==y].iloc[0];ax.plot(s.Irrigation_mm,s.Y_13pct,'--',c='#527DF4',lw=1.4);ax.scatter(float(read('Table1_study_data.csv').set_index('Year').loc[y,'DI_irrigation_mm']),r.Model_baseline_Y13,marker='*',s=85,c='#1E657E',zorder=4)
  target=np.linspace(s.Irrigation_mm.min(),s.Irrigation_mm.max(),6);idx=np.unique([np.argmin(abs(s.Irrigation_mm.to_numpy()-v)) for v in target]);q=s.iloc[idx];ax.scatter(q.Irrigation_mm,q.Y_13pct,s=17,c='#D33F35',edgecolor='white',lw=.4,zorder=4)
  for k,(_,p) in enumerate(q.iterrows()):
   tup=tuple(int(round(p[f'Window{j}_mm'])) for j in range(1,5));txt='(' + ', '.join(map(str,tup)) + ')';dx=7 if k<3 else -7;dy=-19 if k%2==0 else 11
   ax.annotate(txt,(p.Irrigation_mm,p.Y_13pct),xytext=(dx,dy),textcoords='offset points',ha='left' if dx>0 else 'right',fontsize=6.7,color='#354B55',bbox=dict(boxstyle='round,pad=.15',fc='white',ec='#ADB9BF',lw=.4,alpha=.94));display.append(p.to_dict())
  obs=float(read('Table1_study_data.csv').set_index('Year').loc[y,'Observed_Y13_t_ha']);ax.axhline(.95*obs,c='#AE7772',ls=':',lw=.9);ax.set_xlim(-10,read('Table1_study_data.csv').set_index('Year').loc[y,'DI_irrigation_mm']*1.08);ax.set_ylim(0,19.5);panel(ax,i,str(y));grid(ax)
  if i%2==0:ax.set_ylabel('Grain yield (t ha$^{-1}$)')
  if i>=2:ax.set_xlabel('Actual seasonal irrigation (mm)')
 fig.legend(handles=[Line2D([],[],ls='--',c='#527DF4',label='NSGA-III front'),Line2D([],[],marker='o',c='#D33F35',ls='',label='Evaluated solutions'),Line2D([],[],marker='*',c='#1E657E',ls='',label='DI model baseline'),Line2D([],[],ls=':',c='#AE7772',label='95% observed yield')],loc='outside upper center',ncol=2,frameon=False);save(fig,'Fig11_Four_year_Pareto_fronts_EN');pd.DataFrame(display).to_csv(TB/'Figure11_labelled_exact_solutions.csv',index=False)
def decomposition():
 d=read('Original_main_Irrigation_saving_decomposition.csv');fig,ax=plt.subplots(figsize=(7.2,3.05),layout='constrained');x=np.arange(4);bottom=np.zeros(4)
 for col,label,color,hatch in [('ET_reduction_mm','Lower evapotranspiration','#E69F00',''),('Reduced_soil_storage_gain_mm','Lower end-of-season storage','#56A0B9','///'),('Loss_reduction_mm','Lower other water losses','#899A86','')]:
  ax.bar(x,d[col],bottom=bottom,width=.55,label=label,color=color,hatch=hatch,edgecolor='white',lw=.6);bottom+=d[col].to_numpy()
 for j,r in d.iterrows():ax.text(j,bottom[j]+7,f'{r.Reduced_soil_storage_gain_mm/r.Irrigation_saving_mm*100:.1f}%',ha='center',fontsize=9)
 ax.set_xticks(x,YEARS);ax.set(ylim=(0,430),ylabel='Irrigation reduction (mm)');ax.grid(axis='y');ax.set_axisbelow(True);ax.legend(loc='upper left',ncol=1,frameon=False,fontsize=8.5);save(fig,'Fig12_Irrigation_reduction_components_EN')
def scalar():
 d=read('Scalar_At_95pct_observed_summary.csv');d=d[d.Case.str.startswith('old_')];fig,ax=plt.subplots(figsize=(7.3,3.05),layout='constrained');x=np.arange(4);methods=['GA','NSGA2_1obj','GSA','DE'];colors=['#0072B2','#E69F00','#009E73','#AA4499']
 for j,(m,c) in enumerate(zip(methods,colors)):
  s=d[d.Algorithm==m].copy();s['Year']=s.Case.str[-4:].astype(int);s=s.set_index('Year').loc[YEARS];ax.bar(x+(j-1.5)*.17,s.I_median_mm,width=.15,capsize=2,color=c,label={'GA':'GA','NSGA2_1obj':'Single-objective NSGA-II','GSA':'Generalized SA','DE':'Differential evolution'}[m],yerr=np.stack([s.I_median_mm-s.I_min_mm,s.I_max_mm-s.I_median_mm]),error_kw=dict(lw=.65))
 ax.set_xticks(x,YEARS);ax.set(ylim=(0,370),ylabel='Minimum irrigation at 95% observed yield (mm)');ax.grid(axis='y');ax.set_axisbelow(True);ax.legend(loc='upper center',bbox_to_anchor=(.5,1.2),ncol=2,frameon=False,fontsize=8.5);save(fig,'Fig13_Single_objective_solver_comparison_EN')
def main():
 OUT.mkdir(exist_ok=True)
 for f in [workflow,site,environment,cc,biomass,parameters,pooled,water,sobol,yield_ci,pareto,decomposition,scalar]:f();print(f.__name__,flush=True)
if __name__=='__main__':main()
