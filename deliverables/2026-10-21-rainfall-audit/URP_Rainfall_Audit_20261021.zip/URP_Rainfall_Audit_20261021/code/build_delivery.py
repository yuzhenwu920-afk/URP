"""Make traceable tables, English figures and a Chinese interpretation report."""
from pathlib import Path
import json, math, hashlib, importlib.metadata
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from PIL import Image
from scipy.stats import pearsonr
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl.styles import Font, PatternFill, Alignment
R=Path(__file__).resolve().parents[1]
F=R/'figures'; F.mkdir(exist_ok=True)
D=R/'documents'; D.mkdir(exist_ok=True)
BLUE='#0072B2'; ORANGE='#D55E00'; GREEN='#009E73'; PURPLE='#A45A9F'; GREY='#687B86'
YEARS=range(2019,2023)
POLICY_LABELS={'GEE':'Original GEE', 'Graph_approx':'Published-figure reconstruction', 'Graph_minus1day':'Reconstruction shifted -1 day', 'Graph_plus1day':'Reconstruction shifted +1 day', 'GEE_total_to_table':'GEE pattern; published seasonal total', 'Graph_same_GEE_total':'Reconstructed pattern; GEE seasonal total', 'GEE_trace_reassigned':'Trace rainfall redistributed (synthetic)'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':13,'axes.labelsize':11,'legend.fontsize':10,'xtick.labelsize':10,'ytick.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18,'grid.linewidth':.6,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})

def save(fig,name):
    for ext in ['png','pdf','svg']:fig.savefig(F/f'{name}.{ext}',dpi=600,bbox_inches='tight',pad_inches=.12)
    plt.close(fig)
    im=Image.open(F/f'{name}.png').convert('RGB');im.thumbnail((2300,2300));im.save(F/f'{name}_preview.jpg',quality=94)

def extra_tables():
    a=pd.read_csv(R/'tables/Daily_GEE_vs_graph_approx.csv',parse_dates=['Date'])
    s=pd.read_csv(R/'tables/Four_year_rainfall_comparison.csv')
    events=pd.read_csv(R/'tables/Paper_graph_detected_events.csv',parse_dates=['Date'])
    storms=[];weekly=[]
    for year in YEARS:
        d=a[a.Year.eq(year)]; ev=events[events.Year.eq(year)].nlargest(3,'P_digitized_mm')
        for _,e in ev.iterrows():
            row=dict(Year=year,Graphic_date_approx=str(e.Date.date()),Graph_event_approx_mm=e.P_digitized_mm,Date_uncertainty_days=1)
            for radius in [0,1,2]:
                w=d[d.Date.between(e.Date-pd.Timedelta(days=radius),e.Date+pd.Timedelta(days=radius))]
                row[f'GEE_pm{radius}day_sum_mm']=w.Precip_mm.sum();row[f'Graph_pm{radius}day_approx_sum_mm']=w.P_digitized_mm.sum()
            storms.append(row)
        w=pd.read_csv(R/'tables/Seven_day_totals.csv');w=w[w.Year.eq(year)]
        weekly.append(dict(Year=year,Blocks=len(w),Approx_7day_Pearson_r=pearsonr(w.GEE_mm,w.Graph_approx_mm).statistic,Approx_7day_RMSE_mm=float(np.sqrt(np.mean((w.GEE_mm-w.Graph_approx_mm)**2))),Scope='graphic reconstruction, including final partial block; not raw gauge validation'))
    pd.DataFrame(storms).to_csv(R/'tables/Large_storm_window_checks.csv',index=False)
    pd.DataFrame(weekly).to_csv(R/'tables/Seven_day_approx_metrics.csv',index=False)
    replay=pd.read_csv(R/'tables/Frozen_parameter_rainfall_replays.csv')
    old=replay[(replay.Model_family=='Old_four_year_root2p3_f0')&(replay.Control=='Old_selected_95pct')].copy()
    old['Observed_95pct_gate']=old.Observed_Y13*.95;old['Margin_to_gate_t_ha']=old.Y_13pct-old.Observed_95pct_gate
    old.to_csv(R/'tables/Old_candidates_rainfall_sensitivity.csv',index=False)
    new=replay[replay.Model_family.eq('New_2021_root1m_pilot')].copy()
    di=new[new.Control.eq('Proportional_633.47')][['Structure','Rain_policy','Y_13pct']].rename(columns={'Y_13pct':'Matched_DI_Y13'})
    new=new.merge(di,on=['Structure','Rain_policy'],validate='many_to_one');new['Yield_fraction_of_matched_DI']=new.Y_13pct/new.Matched_DI_Y13
    new.to_csv(R/'tables/New_2021_rainfall_sensitivity.csv',index=False)
    budgets=[]
    for (sc,policy),g in new.groupby(['Structure','Rain_policy']):
        hi=g[g.Control.eq('Proportional_633.47')].iloc[0];lo=g[g.Control.eq('Proportional_350')].iloc[0]
        row=dict(Structure=sc,Rain_policy=policy,DI_irrigation_mm=hi.Irrigation_mm,Low_irrigation_mm=lo.Irrigation_mm,DI_Y13=hi.Y_13pct,Low_Y13=lo.Y_13pct)
        for c in ['Irrigation_mm','ET_mm','DeepPerc_mm','Runoff_mm','TileDrain_mm','Profile_initial_mm','Profile_final_mm','Surface_initial_mm','Surface_final_mm','Rain_mm','CR_mm','GwIn_mm','Root1m_final_mm']:
            row['DI_minus_350_'+c]=float(hi[c]-lo[c])
        row['Low_root1m_initial_mm']=lo.Root1m_initial_mm;row['Low_root1m_final_mm']=lo.Root1m_final_mm
        row['Low_profile_initial_mm']=lo.Profile_initial_mm;row['Low_profile_final_mm']=lo.Profile_final_mm
        row['Full_profile_end_storage_share_of_I_reduction_pct']=100*row['DI_minus_350_Profile_final_mm']/row['DI_minus_350_Irrigation_mm']
        rhs=sum(row['DI_minus_350_'+c] for c in ['ET_mm','DeepPerc_mm','Runoff_mm','TileDrain_mm','Profile_final_mm','Surface_final_mm'])-sum(row['DI_minus_350_'+c] for c in ['Profile_initial_mm','Surface_initial_mm','Rain_mm','CR_mm','GwIn_mm'])
        row['Difference_balance_residual_mm']=row['DI_minus_350_Irrigation_mm']-rhs
        assert abs(row['Difference_balance_residual_mm'])<1e-8
        budgets.append(row)
    pd.DataFrame(budgets).to_csv(R/'tables/Storage_budget_DI_vs_350_2021.csv',index=False)
    source=[(21,'2-3','Observed management','DI sowing/harvest dates and irrigation schedules'),(22,'2-2','Published station graphic','Daily rainfall and temperature; rainfall reconstructed approximately'),(39,'3.2.2','Published observational aggregate','PDF49: DI seasonal Es = 76,79,78,81 mm'),(63,'4-1','Published observations','DI ET = 661.45,637.03,626.81,584.11 mm; Y13 = 16.55,17.29,15.86,14.08 t/ha'),(93,'5-13','WHCNS simulated water balance','P inputs = 157,98,150,172 mm; ET/E/T/D columns are simulation outputs')]
    # Third entry is corrected to its PDF page below; body page is 39.
    source[2]=(49,'3-19 accompanying text',*source[2][2:])
    pd.DataFrame(source,columns=['PDF_page','Table_figure_or_section','Evidence_type','Use']).to_csv(R/'tables/Source_evidence_map.csv',index=False)
    return a,s,replay,old,new

def figures(a,s,replay,old,new):
    fig,axs=plt.subplots(2,2,figsize=(11.8,7.4),sharey=True)
    for ax,year in zip(axs.flat,YEARS):
        v=a[a.Year.eq(year)];z=s[s.Year.eq(year)].iloc[0]
        ax.axvspan(pd.Timestamp(z.Paper_DI_start),pd.Timestamp(z.Paper_DI_end_inclusive),color='#DCE6EB',alpha=.32,zorder=0)
        ax.bar(v.Date-pd.Timedelta(hours=5),v.Precip_mm,width=.39,color=BLUE,label='GEE input')
        ax.bar(v.Date+pd.Timedelta(hours=5),v.P_digitized_mm,width=.39,color=ORANGE,label='Published figure (approx.)')
        ax.set(title=str(year),ylim=(0,60),xlim=(pd.Timestamp(f'{year}-04-01'),pd.Timestamp(f'{year}-09-30')),ylabel='Daily precipitation (mm)')
        ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    fig.legend(*axs.flat[0].get_legend_handles_labels(),loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,1.005))
    fig.suptitle('Daily precipitation: GEE input and published station figure',y=1.06,fontsize=16)
    fig.text(.5,-.025,'Shading: published DI crop period. Graphic dates are approximate (±1 day); small bars may be unresolved.',ha='center',fontsize=10)
    fig.tight_layout(rect=[0,.005,1,.98]);save(fig,'P01_Daily_precipitation_4years_EN')
    fig,axs=plt.subplots(2,2,figsize=(11.8,7.4),sharey=True)
    for ax,year in zip(axs.flat,YEARS):
        z=s[s.Year.eq(year)].iloc[0];v=a[a.Year.eq(year)&a.Date.between(z.Paper_DI_start,z.Paper_DI_end_inclusive)]
        ax.plot(v.Date,v.Precip_mm.cumsum(),color=BLUE,lw=2.1,label='GEE input')
        ax.plot(v.Date,v.P_digitized_mm.cumsum(),color=ORANGE,lw=2.1,label='Published figure (approx.)')
        ax.scatter(v.Date.iloc[-1],z.Paper_Table5_13_P_mm,marker='D',s=48,facecolors='none',edgecolors='#253D48',zorder=5,label='Published seasonal P input (Table 5-13)')
        ax.set(title=str(year),ylabel='Cumulative precipitation (mm)',ylim=(0,205),xlim=(v.Date.iloc[0],v.Date.iloc[-1]))
        ax.text(.03,.95,f'GEE: {v.Precip_mm.sum():.1f} mm\nFigure: ≈{v.P_digitized_mm.sum():.1f} mm\nTable 5-13: {z.Paper_Table5_13_P_mm:.0f} mm',transform=ax.transAxes,va='top',fontsize=10)
        ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    fig.legend(*axs.flat[0].get_legend_handles_labels(),loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.5,1.025),fontsize=9)
    fig.suptitle('Matched-period cumulative precipitation',y=1.075,fontsize=16)
    fig.text(.5,-.018,'All three values use the published DI sowing–harvest period, including the harvest day.',ha='center',fontsize=10)
    fig.tight_layout(rect=[0,0,1,.99]);save(fig,'P02_Cumulative_precipitation_4years_EN')
    labels=['Figure reconstruction','Reconstruction −1 day','Reconstruction +1 day','GEE pattern; table total','Reconstruction; GEE total','Trace redistributed*']
    policies=['Graph_approx','Graph_minus1day','Graph_plus1day','GEE_total_to_table','Graph_same_GEE_total','GEE_trace_reassigned']
    fig,axs=plt.subplots(2,2,figsize=(12,7.2),sharex=True)
    for ax,year in zip(axs.flat,YEARS):
        v=old[old.Year.eq(year)].set_index('Rain_policy').loc[policies]
        ax.axvline(0,color=GREY,lw=1);ax.scatter(v.Yield_change_pct,np.arange(6),s=55,c=[ORANGE,ORANGE,ORANGE,BLUE,PURPLE,GREEN],zorder=4)
        for j,dx in enumerate(v.Yield_change_pct):ax.plot([0,dx],[j,j],color=GREY,lw=1.2,alpha=.7)
        ax.set_yticks(range(6),labels);ax.invert_yaxis();ax.set_title(str(year));ax.set_xlabel('Yield change from original GEE (%)')
        ax.set_xlim(-6.3,3.7);ax.grid(axis='y',visible=False)
    fig.suptitle('Existing four-year candidates: rainfall sensitivity at fixed parameters and irrigation',fontsize=15,y=1.035)
    fig.text(.5,-.025,'Historical model: maximum root depth 2.30 m, fMulch = 0.  *Synthetic redistribution; not a station-data correction.',ha='center',fontsize=10)
    fig.tight_layout();save(fig,'P03_Existing_candidates_rainfall_sensitivity_EN')
    fig,axs=plt.subplots(1,3,figsize=(13,4.6),sharey=True)
    colors={'GEE':BLUE,'Graph_approx':ORANGE,'Graph_same_GEE_total':PURPLE,'GEE_trace_reassigned':GREEN}
    ls={'GEE':'-','Graph_approx':'--','Graph_same_GEE_total':'-.','GEE_trace_reassigned':':'}
    for ax,sc in zip(axs,['fm050','fm075','fm085']):
        v=new[(new.Structure==sc)&new.Control.str.startswith('Proportional_')]
        for pol in colors:
            t=v[v.Rain_policy.eq(pol)].sort_values('Irrigation_mm')
            ax.plot(t.Irrigation_mm,t.Y_13pct,marker='o',ms=4,lw=1.8,color=colors[pol],ls=ls[pol],label=POLICY_LABELS[pol])
        ax.axhline(15.86,color='#8D5F51',lw=1,ls=(0,(3,3)),label='Published DI yield (15.86 t ha⁻¹)')
        ax.set(title=f'fMulch = {dict(fm050=.5,fm075=.75,fm085=.85)[sc]:.2f}',xlabel='Seasonal irrigation (mm)',xlim=(0,650),ylim=(0,17))
        ax.set_xticks([0,300,400,633.47],['0','300','400','633.47']);ax.tick_params(axis='x',labelsize=9)
    axs[0].set_ylabel('Grain yield at 13% moisture (t ha⁻¹)')
    handles,labs=axs[0].get_legend_handles_labels();fig.legend(handles,labs,loc='lower center',bbox_to_anchor=(.5,-.14),ncol=2,frameon=False,fontsize=9)
    fig.suptitle('2021 rainfall checks at six fixed proportional-irrigation levels',fontsize=15,y=1.04)
    fig.tight_layout(rect=[0,.04,1,1]);save(fig,'P04_2021_fixed_schedule_rainfall_checks_EN')
    captions=[
        ('P01_Daily_precipitation_4years_EN','Daily precipitation: GEE input and published station figure','Blue bars show uploaded GEE inputs; orange bars are approximate reconstructions of thesis Figure 2-2 (PDF p. 22). Pale shading denotes the published DI crop period. Broken rainfall axes in the source for 2021 and 2022 were reconstructed piecewise. Dates have a ±1-day graphic-reading uncertainty; bars below the resolution limit may be missed. These are not raw daily gauge data.'),
        ('P02_Cumulative_precipitation_4years_EN','Matched-period cumulative precipitation','Cumulative rainfall uses each published DI sowing–harvest period, inclusive of harvest day. Open diamonds indicate the rounded seasonal precipitation inputs reported in WHCNS water balance Table 5-13, not an independently provided daily gauge series. The original AquaCrop endpoint differs by one day in 2019, 2021 and 2022; those original calendars were retained in model replays.'),
        ('P03_Existing_candidates_rainfall_sensitivity_EN','Existing four-year candidates under alternative rainfall inputs','Yield changes are relative to the original GEE forcing. Parameters, irrigation controls, initial soil water and all non-precipitation forcings are fixed. Historical models use maximum root depth 2.30 m and fMulch = 0. Treatments separate changes in total precipitation, graphic timing and intensity distribution, and synthetic redistribution of trace precipitation. These are backtests of existing candidates, not reoptimized Pareto fronts.'),
        ('P04_2021_fixed_schedule_rainfall_checks_EN','2021 fixed-schedule rainfall sensitivity','Each panel uses its own previously selected conditional pilot parameters at maximum root depth 1.00 m. Six evaluated proportional irrigation levels are 0, 300, 350, 400, 500 and 633.47 mm; connecting lines guide the eye and are not a new continuous optimization. Rainfall changes only; fMulch and all other inputs remain fixed within a panel. These 500-step pilot fits have not established posterior convergence. The 350-mm modeled plateau persists under the tested rainfall alternatives.')]
    pd.DataFrame(captions,columns=['Figure_ID','English_title','English_caption']).to_csv(R/'tables/Figure_captions.csv',index=False)
    return captions

def excel():
    sheets={'Seasonal rainfall':'Four_year_rainfall_comparison','Daily approximate':'Daily_GEE_vs_graph_approx','Detected paper bars':'Paper_graph_detected_events','Date shifts':'Date_shift_sensitivity','Monthly rainfall':'Monthly_totals','Seven day rainfall':'Seven_day_totals','Seven day metrics':'Seven_day_approx_metrics','Large storms':'Large_storm_window_checks','All 224 replays':'Frozen_parameter_rainfall_replays','Old candidates':'Old_candidates_rainfall_sensitivity','New 2021 replays':'New_2021_rainfall_sensitivity','Storage budgets':'Storage_budget_DI_vs_350_2021','Forcing treatments':'Small_experiment_rainfall_inputs','RS label audit':'Remote_sensing_label_audit','Sources':'Source_evidence_map','Figure captions':'Figure_captions'}
    with pd.ExcelWriter(D/'Rainfall_audit_data_2019_2022.xlsx',engine='openpyxl') as x:
        for name,file in sheets.items():pd.read_csv(R/'tables'/f'{file}.csv').to_excel(x,sheet_name=name,index=False)
        for ws in x.book.worksheets:
            ws.freeze_panes='C2';ws.auto_filter.ref=ws.dimensions;ws.row_dimensions[1].height=42
            for c in ws[1]:c.font=Font(color='FFFFFF',bold=True);c.fill=PatternFill('solid',fgColor='20586B');c.alignment=Alignment(wrap_text=True,vertical='center')
            for col in ws.columns:
                vals=[len(str(c.value or '')) for c in list(col)[:80]];ws.column_dimensions[col[0].column_letter].width=min(36,max(13,max(vals)+1))
                for c in list(col)[1:]:
                    if isinstance(c.value,float):c.number_format='0.000'

def word(s,old,new,captions):
    doc=Document();sec=doc.sections[0];sec.page_height=Cm(29.7);sec.page_width=Cm(21);sec.top_margin=Cm(1.6);sec.bottom_margin=Cm(1.6);sec.left_margin=Cm(1.7);sec.right_margin=Cm(1.7)
    for st in ['Normal','Title','Subtitle','Heading 1','Heading 2']:
        stl=doc.styles[st];stl.font.name='Noto Sans CJK SC';stl._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.styles['Normal'].font.size=Pt(10);doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    doc.styles['Normal'].paragraph_format.line_spacing=1.15
    doc.styles['Title'].font.size=Pt(24)
    doc.styles['Heading 1'].font.size=Pt(15);doc.styles['Heading 1'].font.color.rgb=RGBColor.from_string('20586B')
    doc.styles['Heading 2'].font.size=Pt(12)
    foot=sec.footer.paragraphs[0];foot.alignment=2;foot.add_run('URP · 降水输入审计 · 2019–2022 | ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');foot._p.append(field)
    def p(text):doc.add_paragraph(text)
    def h(text):doc.add_heading(text,level=1)
    def table(headers,rows):
        t=doc.add_table(rows=1,cols=len(headers));t.style='Light Shading Accent 1'
        for c,v in zip(t.rows[0].cells,headers):c.text=str(v)
        rep=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(rep)
        for vals in rows:
            cells=t.add_row().cells
            for c,v in zip(cells,vals):c.text=str(v)
        for row in t.rows:
            for c in row.cells:
                for pa in c.paragraphs:
                    for ru in pa.runs:ru.font.size=Pt(8)
        return t
    def figure(i,interpretation):
        id,title,cap=captions[i];doc.add_heading(title,level=2);doc.add_picture(str(F/f'{id}_preview.jpg'),width=Cm(17.2));p(cap);p('解析：'+interpretation)
    doc.add_heading('GEE降水核对与优化结果可信度审计',0)
    p('2019—2022年DI玉米｜固定参数补充试验｜2026年10月21日')
    p('目的：先核查降水输入，再判断300—350 mm附近的产量平台能否作为节水结论。保留既有MCMC和NSGA-III成果，本次仅回放降水情景，不重新校准、不重新优化。')
    h('1. 当前最有依据的判断')
    for txt in [
        '四份新上传气象CSV与四年原模型实际输入逐字节一致。发现的是既有输入与论文站点降水之间的差异，不是本次上传版本更新。',
        '按论文DI播种—收获期对齐后，GEE降水相对论文水量平衡表中的P输入：2019和2020偏多，2021和2022偏少。不存在四年一致的“GEE总降水偏大”。',
        '224组固定参数回放已经完成。原先紧贴95%观测产量门槛的候选对降水输入敏感，但最新2021年模型的350 mm产量平台仍然存在；降水差异不足以单独解释该平台。',
        '可以将原结果保留为特定输入和参数条件下的探索性节水潜力；现有证据不能证明300—350 mm为田间稳产定额，也不能把95%产量门槛解释成95%的达标概率。']:
        doc.add_paragraph(txt,style='List Bullet')
    h('2. 数据与证据边界')
    p('论文：王尚今学位论文（用户上传版本，110页）。所有引用以PDF页码为准；图2-2位于PDF第22页，正文存在图号交叉引用误差。用户上传的两份PDF哈希一致，仅保留一份。原始逐日雨量站表并未提供。')
    p('论文WeatherHawk自动气象站约15 min记录一次。图2-2提供4—9月逐日降水柱状图，本次由图形重建近似日值，明确处理2021年的20—50 mm断轴和2022年的30—40 mm断轴。图高读数误差按约±0.35 mm/事件（高值段±0.5 mm），日期按±1日；小于图形可分辨尺度的降雨不能可靠还原。未把图中“无可辨柱”称为原始零雨量。')
    p('独立检查：论文表5-13（PDF第93页）记录WHCNS水量平衡使用的季节P输入157、98、150、172 mm，与图形重建的季节量接近。该表P可用于数量级交叉核对，但不等同于获得原始逐日站点数据；表内ET、E、T、D是WHCNS模拟结果。')
    p('GEE产品、提取地块/点位、空间尺度、时间汇总起止和时区未能从CSV核实。日值差异不能直接归因为UTC，也不能在缺少元数据时认定某一特定GEE产品。')
    doc.add_page_break();h('3. 四年降水对照：统一DI生育期')
    table(['年','论文DI起止（含末日）','GEE (mm)','图重建≈ (mm)','表5-13 P (mm)','GEE−表 (mm)'],[(int(z.Year),f'{z.Paper_DI_start[5:]}—{z.Paper_DI_end_inclusive[5:]}',f'{z.GEE_same_paper_window_mm:.1f}',f'{z.Graph_same_paper_window_approx_mm:.1f}',f'{z.Paper_Table5_13_P_mm:.0f}',f'{z.GEE_minus_paper_table_mm:+.1f}') for _,z in s.iterrows()])
    p('2019年约+17.4%，2020年约+15.8%，2021年约−4.4%，2022年约−11.8%。这些差异是同一论文作物期的输入对照，不是全年对照；多年平均降水164 mm不宜用来直接判定某一年度CSV错误。')
    p('原模型末日分别为2019-09-15、2020-09-18、2021-09-21、2022-09-11，比论文2019、2021、2022的收获日早1天。本次审计总量按论文期比较；模型回放为避免改动原试验，仍保留原模型日历。2019年多出的9月16日GEE降水约6.50 mm，应避免混用177.87 mm（模型期）与184.37 mm（论文期）。')
    figure(0,'2021和2022存在明显的大雨日幅度差异，同时GEE含较多微量降雨日。站点与格点的空间代表性、日汇总规则以及图形读数均可能参与差异。将最大事件按±1、±2日窗口合计的表格也已提供，避免只凭一天的对齐值判错。')
    figure(1,'2021年总雨量相近并不代表降雨时序相同。总量相同而强度与间隔不同，会改变土壤表层湿润持续时间、蒸发、入渗和胁迫，不能只用季节总量替代逐日过程审计。')
    p('日期分辨率会影响相关性：2021年逐日图对照相关系数约0.58，聚合为7日后约0.93；2019年也由约0.50提高至0.93。这支持同时考察事件窗口和累积过程，不能只凭逐日相关性判定气象产品不可用。7日相关仍是与图形近似值的比较，不能充当原始站点验证统计。')
    h('4. 数据和参数检查中应纠正的解释')
    p('已核对四年DI实测灌溉日程和总量，与论文表2-3相符。2021年正文概述633.46 mm、逐次表格加和633.47 mm存在0.01 mm舍入差异，保留模型逐次加和633.47 mm。单次/季节上限仍是执行实测日程的保护上限，不是校准参数。')
    p('重要来源订正：论文PDF第49页明确给出2019—2022年DI季节土壤蒸发量76、79、78、81 mm，并说明微型蒸渗仪观测方法。因此2021年Es=78 mm应标为“论文报告的观测汇总”，而非仅“由图近似重建”。数值目标不变，证据分类订正；本次没有取得其原始日序列和观测误差。')
    p('应使用表4-1（PDF第63页）的观测ET：661.45、637.03、626.81、584.11 mm。不要把表5-13中的WHCNS模拟ET 549、480、533、473 mm误作观测校准目标。ET与分量之间的推导关系和闭合处理意味着不能把ET−Es另当一条独立观测重复加权。')
    p('论文WHCNS的Cfilm=0.75表达覆膜覆盖系数，不能直接等同于AquaCrop的fMulch=0.75。旧四年前沿使用根深2.30 m、fMulch=0；新2021试验使用根深1.00 m和三个条件重拟合情景fMulch=0.50/0.75/0.85。两组结果分开解释。')
    p('遥感CSV的2019—2021年IrriMetho标签为BI，2022年缺少该标签；CCquad数值尺度看起来是百分数。应核实GEE导出地块是否确为DI，不能将BI标签直接当作DI已核实，也不能把80左右的CC值当作0—1比例。该代理资料不替代田间CC观测或雨量站记录。')
    h('5. 小型补充试验：已完成224组')
    p('56组：四年旧模型×DI基准/原95%候选×7种降水输入。168组：最新2021年根深1 m的3个fMulch条件模型×8种既定灌溉方案×7种降水输入。8种管理包括6个同比例灌水水平（0、300、350、400、500、633.47 mm）与已有Opt95、OptOwnDI候选。')
    table(['降水试验','含义'],[(POLICY_LABELS[k],v) for k,v in [('GEE','原输入对照'),('Graph_approx','图重建日值，图外保留原GEE'),('Graph_minus1day','图重建整体提前1天'),('Graph_plus1day','图重建整体推后1天'),('GEE_total_to_table','保留GEE雨日分布，模型期总量缩放至表5-13 P'),('Graph_same_GEE_total','图重建分布，模型期总量缩放回原GEE'),('GEE_trace_reassigned','将>0且<1 mm微量雨移到已有≥1 mm雨日，保持总量；人为诊断')]])
    p('各组只改降水；气温、ETo、灌溉日期与控制量、土壤、初始水分、根系、地膜、作物参数均固定。图重建总量没有强行配平到论文表值。日期不确定性用±1日回放，柱高读数误差未做完整随机传播；不属于统计置信区间。亦未传播完整后验参数不确定性。')
    check=json.loads((R/'verification/PORTABLE_REPLAY_CHECK.json').read_text())
    p(f'质量核验：224组每日水量平衡残差最大2.70×10⁻¹³ mm（数值舍入量级）；另用压缩包内源文件和未加速模型独立复算{check["Independent_replays"]}组，主要输出差异最大{check["Maximum_difference"]:.2e}。平衡闭合仅证明数值守恒，不证明田间过程一定正确。')
    h('6. 结果：原候选对降水输入敏感')
    v=old[old.Rain_policy.eq('Graph_approx')]
    table(['年','既定灌水量 mm','原GEE Y13','图重建 Y13','变化 %','95%门槛'],[(int(t.Year),f'{t.Irrigation_mm:.2f}',f'{t.Reference_Y_13pct:.3f}',f'{t.Y_13pct:.3f}',f'{t.Yield_change_pct:+.2f}',f'{.95*t.Observed_Y13:.3f}') for _,t in v.iterrows()])
    p('原候选本来被选择在门槛附近，图重建降水下均低于该门槛。应看减产幅度：2019约−3.80%、2020约−2.91%、2021约−1.37%、2022仅−0.17%。不能将2022的小幅越界夸大为严重失效，也不能因原GEE中刚好达标就声称方案稳健。')
    figure(2,'2021年旧候选在图重建降水下由15.067降至14.860 t/ha；仅把GEE总量增加到150 mm时为15.113 t/ha；改用图形雨日分布并维持GEE原总量时为14.827 t/ha。分布作用在这个模型中比季节总量的微小差异更显著。这是模型敏感性证据，不是对气象产品偏差成因的最终判定。')
    h('7. 结果：350 mm平台并未被降水替换消除')
    a=new[new.Control.eq('Proportional_350')&new.Rain_policy.isin(['GEE','Graph_approx'])]
    table(['fMulch','雨量输入','350 mm Y13','同输入DI Y13','350/DI'],[(f'{dict(fm050=.5,fm075=.75,fm085=.85)[t.Structure]:.2f}','GEE' if t.Rain_policy=='GEE' else '图重建',f'{t.Y_13pct:.3f}',f'{t.Matched_DI_Y13:.3f}',f'{100*t.Yield_fraction_of_matched_DI:.1f}%') for _,t in a.iterrows()])
    p('图重建降水下，350 mm对应同一雨量输入DI基准产量的约97.9%—100.3%。平台仍然存在，不能承诺补上雨量站数据就会自然变成400或600 mm平台。各fMulch面板使用各自条件拟合参数，差异包含参数补偿，不能视为只改fMulch的单因子结果。')
    figure(3,'本图是既定日程同比例灌水的6点评估，不是NSGA-III新前沿。已有Opt95候选在图重建输入下分别为14.754、14.661、14.728 t/ha，均低于15.067 t/ha门槛；但350 mm附近的高产平台仍在。二者共同说明边界候选脆弱，而模型内部的水分—产量响应仍需过程观测约束。')
    doc.add_heading('同一批回放的水量账：减灌主要去了哪里？',level=2)
    b=pd.read_csv(R/'tables/Storage_budget_DI_vs_350_2021.csv');b=b[(b.Structure=='fm085')&b.Rain_policy.isin(['GEE','Graph_approx'])]
    table(['降水输入','减灌 mm','ET减少 mm','整个剖面季末储水减少 mm','储水差/减灌'],[('GEE' if t.Rain_policy=='GEE' else '图重建',f'{t.DI_minus_350_Irrigation_mm:.2f}',f'{t.DI_minus_350_ET_mm:.2f}',f'{t.DI_minus_350_Profile_final_mm:.2f}',f'{t.Full_profile_end_storage_share_of_I_reduction_pct:.1f}%') for _,t in b.iterrows()])
    p('以fMulch=0.85、原GEE为例，350 mm方案ET仍为595.99 mm，与DI的600.10 mm很接近；两者减灌283.47 mm，却主要对应整个2.4 m水文剖面的季末储水差279.23 mm。350 mm方案1 m根区由324.97降至197.05 mm，整个剖面由535.70降至431.48 mm；DI季末整个剖面为710.71 mm。这里既包括低灌水方案消耗初始储水，也包括高灌水基准在季末留下更多储水，不能把279.23 mm全部说成作物从初始根区多吸走的水。')
    p('固定1 m根区与整个2.4 m水文剖面不能混用。根深1 m不等于模型只模拟1 m深土壤水；深部仍可接受再分配。季末储水差不是额外产水或数值不守恒，而是两种管理下土壤水库存不同。是否允许这种季节性库存差、能否通过休闲期补给恢复，需要分层含水量和跨季节水量账验证。不能把“保持与DI完全相同季末库存”擅自当成唯一田间真值；但提出可持续节水建议前必须交代这一差异。')
    h('8. 不重新优化时，论文可以怎样解释')
    p('建议将原前沿与节水率限定为“原GEE气象强迫、既定土壤水和校准参数下的模型潜力”，补入本次固定候选回放。可保留原始计算记录及方法比较，但不能把替换降水后的固定候选回放写成新的最优前沿，也不能给出经过实测验证的最小灌水定额。')
    doc.add_heading('可直接改写进讨论段的文字',level=2)
    p('“气象强迫的不确定性可能影响灌溉优化结果的外推。以论文站点降水图重建值开展固定参数回放后，原2021年候选产量由15.067降至14.860 t ha⁻¹，低于95%观测产量门槛，表明紧贴约束边界的方案对降水输入敏感。但在根深1 m的三个条件校准情景中，350 mm同比例灌水方案仍可获得同输入DI基准产量的约97.9%—100.3%，因此降水差异不足以独立解释高节水潜力。水量账显示，fMulch=0.85、原GEE情景中减灌283.47 mm主要对应整个剖面季末储水减少279.23 mm，而ET仅减少4.12 mm。因此，本文将其解释为给定模型结构、初始储水与终端库存差异下的条件性潜力，不能将减灌等同于耗水减少或已经验证的田间节水定额。图形降水重建含读数和日期误差，尚需原始雨量站、分层土壤含水量及亏缺灌溉处理数据进一步验证。”')
    p('需避免的表述：“滴灌地膜让玉米只需300 mm水”“已验证节水50%不减产”“95%可靠保证产量”“降水偏大解释了全部乐观结果”。灌水量只是供水的一部分，还包括降雨、初始土壤储水及可能的其他通量；同样，模型守恒不等于根区供水和胁迫响应真实。')
    h('9. 最有价值的下一步')
    for n,t in enumerate([
        '取得GEE产品ID、ROI与导出脚本，以及雨量站原始逐日记录（含日界）。先确认空间代表性、单位和时区，再决定是否替换正式强迫；不要根据产量曲线是否“顺眼”选雨量。',
        '优先用论文图3-10（PDF第42页）的20/40/60/80/100 cm含水量资料核查DI基准时序和分层季节储水消耗。图值可作近似过程检查，原始θ更适合正式约束；不能用本次降水审计替代这一步。',
        '在300、350、400和633.47 mm下追踪同一1 m根区的期初/期末水量、Es/Tr、深渗、冠层、实际水分胁迫和收获指数。固定剖面储水与动态根区定义要分开；核实根深1 m时仍存在的2.4 m水文域如何容纳深层储水，以及实测1 m以下土层的扩展假设与排水处理。防止将初始储水过度消耗或未验证的库存差当作可持续节水。',
        '若DI基准已经无法复现实测ET、Es和土壤水，应先修正强迫/结构并条件重校准。仅高灌水DI拟合良好不足以证明亏缺灌溉响应正确。500步pilot未证明收敛，WP/HI等边界问题也需要正式链诊断。',
        '如正式更换雨量后仍需保留“最优方案”的主结论，应在统一的新输入下重校准并重新优化；若本稿不重优化，则保留条件性潜力定位和补充敏感性证据，暂不提出生产定额。最有说服力的外部验证仍是独立亏缺灌溉处理或田间小区试验。'],1):
        p(f'{n}. {t}')
    h('10. 交付文件与复现')
    p('Excel包含季节/逐日近似/7日/大雨窗口/224组模拟/候选敏感性/图注和来源表。figures中提供4组完整英文PNG（600 dpi）、PDF和SVG；所有图附解析和使用边界。code保留读图、审计、224组回放、未加速独立核验与本报告生成代码。model_snapshots与dependencies仅包含固定参数回放所需的原模型及参数，不是重新运行MCMC的完整后验档案。')
    p('复现顺序：安装requirements.txt；python code/digitize_rainfall.py；python code/audit_inputs.py；python code/run_small_experiment.py；python code/verify_portable_replays.py；python code/build_delivery.py。模型源文件不覆盖，原始CSV和论文哈希见MANIFEST。报告PDF为Word导出版，CSV保留浮点精度，Excel显示位数仅影响显示。')
    doc.save(D/'URP_Rainfall_Audit_and_Interpretation_20261021.docx')

def main():
    a,s,replay,old,new=extra_tables();captions=figures(a,s,replay,old,new);excel();word(s,old,new,captions)
    packages=['aquacrop','numpy','pandas','scipy','numba','matplotlib','python-docx','openpyxl','PyMuPDF','pillow','emcee']
    (R/'requirements.txt').write_text('\n'.join(f'{p}=={importlib.metadata.version(p)}' for p in packages)+'\n')
    (R/'ERRATA.md').write_text('# 来源标注订正\n\n论文PDF第49页正文明确报告四年DI季节Es为76、79、78、81 mm，并说明微型蒸渗仪观测。因此2021年Es=78 mm应标为“论文报告的观测汇总”，不是仅由图近似重建。数值目标不变；未取得原始日序列及其误差。历史交付包保留原样，此处订正证据分类。\n\n表5-13中的ET/E/T/D属于WHCNS模拟输出，不能替代表4-1的观测ET。WHCNS Cfilm=0.75不等同于AquaCrop fMulch=0.75。\n')
    print('Built 4 figure groups, Excel workbook and Word report.')
if __name__=='__main__':main()
