"""Render the exact uploaded PDF on white; avoid premultiplied black masks."""
from pathlib import Path
import fitz
R=Path(__file__).resolve().parents[1]
def main():
    doc=fitz.open(R/'inputs/thesis.pdf');out=R/'paper_pages';out.mkdir(exist_ok=True)
    page=doc[21]
    for year,xref in zip(range(2019,2023),[509,510,511,512]):
        rect=page.get_image_rects(xref)[0]
        page.get_pixmap(matrix=fitz.Matrix(5,5),clip=rect,alpha=False).save(out/f'Figure2_2_{year}_render.png')
    for p in [19,20,21,22,42,49,63,93]:
        tag='PDF022_Figure2_2.png' if p==22 else f'PDF{p:03d}.png'
        doc[p-1].get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False).save(out/tag)
    print('Rendered white-background rainfall panels and evidence pages.')
if __name__=='__main__':main()
