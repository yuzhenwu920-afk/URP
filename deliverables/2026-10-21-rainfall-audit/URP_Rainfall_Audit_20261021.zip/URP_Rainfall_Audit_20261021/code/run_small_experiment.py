"""224 prespecified frozen-parameter replays; NO MCMC or optimization reruns.
Changes only precipitation; all other forcing and management remain fixed.
Published chart reconstructions are diagnostic inputs, not raw station data.
"""
from pathlib import Path
import sys,importlib.util,json,contextlib,hashlib,time,os
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
PROJECT=Path(os.environ.get('URP_PROJECT',str(R/'model_snapshots/DI_PHASE3_NEXTGEN_UPDATED')))
PREVIOUS=Path(os.environ.get('URP_FMULCH_PARENT',str(R/'dependencies/2021_fmulch')))
os.environ['URP_PROJECT']=str(PROJECT)
sys.path.insert(0,str(PREVIOUS/'code'))
from scenario_engine import Engine,SCENARIOS
POLICIES=['GEE','Graph_approx','Graph_minus1day','Graph_plus1day','GEE_total_to_table','Graph_same_GEE_total','GEE_trace_reassigned']
TABLE_TOTAL={2019:157.,2020:98.,2021:150.,2022:172.};OBS={2019:16.55,2020:17.29,2021:15.86,2022:14.08}

def load_adapter():
 spec=importlib.util.spec_from_file_location('rain_test_original',PROJECT/'real_model/four_year_adapter.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);return a

def policies(year,weather,dates):
 dates=pd.DatetimeIndex(dates);w=weather.copy();w['Date']=pd.to_datetime(w.Date);gee=w.set_index('Date').Precipitation.astype(float);window=gee.index.isin(dates)
 dig=pd.read_csv(R/'tables/Paper_graph_daily_rainfall_approx.csv');dig=dig[dig.Year.eq(year)];graph=pd.Series(dig.P_digitized_mm.to_numpy(),index=pd.to_datetime(dig.Date)).reindex(gee.index)
 out={'GEE':gee.copy()}
 for name,shift in [('Graph_approx',0),('Graph_minus1day',-1),('Graph_plus1day',1)]:
  # The plot covers April–September. Outside it, retain original GEE forcing.
  pp=graph.shift(shift);a=gee.copy();a.loc[pp.notna()]=pp[pp.notna()];out[name]=a
 pp=gee.copy();pp.loc[window]*=TABLE_TOTAL[year]/gee.loc[window].sum();out['GEE_total_to_table']=pp
 pp=out['Graph_approx'].copy();pp.loc[window]*=gee.loc[window].sum()/pp.loc[window].sum();out['Graph_same_GEE_total']=pp
 pp=gee.copy();trace=window&(pp>0)&(pp<1);wet=window&(pp>=1);removed=pp[trace].sum();pp.loc[trace]=0;pp.loc[wet]+=removed*pp[wet]/pp[wet].sum();out['GEE_trace_reassigned']=pp
 assert abs(out['GEE_trace_reassigned'][window].sum()-gee[window].sum())<1e-8
 assert abs(out['Graph_same_GEE_total'][window].sum()-gee[window].sum())<1e-8
 result={}
 for name,p in out.items():
  q=w.copy();q['Precipitation']=q.Date.map(p);assert q.Precipitation.notna().all() and q.Precipitation.ge(0).all()
  for c in q:
   if c!='Precipitation':pd.testing.assert_series_equal(q[c],w[c])
  result[name]=q
 return result

def row_of(s,**kwargs):
 r={k:v for k,v in s.items() if k!='irrigation_events'};r.update(kwargs);return r

def main():
 t=time.monotonic();rows=[];curve=[];sources=[];weather_rows=[]
 config=json.loads((PROJECT/'project_config.json').read_text());params=pd.read_csv(PROJECT/config['centers']).set_index('Year');names=['Window1_mm','Window2_mm','Window3_mm','Window4_mm']
 for year in range(2019,2023):
  a=load_adapter();m,data=a._load(year);original=data['weather'].copy();space=a.management_space(year);base=np.array(space['baseline_amounts']);pc=params.loc[year,['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']].to_dict()
  source=pd.read_csv(R/'tables/Original_four_year_candidate_controls.csv');c1=source[source.Year.eq(year)].iloc[0];candidate=c1[names].to_numpy(float)
  for policy,weather in policies(year,original,m.DATES).items():
   data['weather']=weather;a._template.cache_clear()
   for label,x in [('DI_baseline',base),('Old_selected_95pct',candidate)]:
    s,w,g=a.simulate(params=pc,year=year,management=dict(kind='stage_amounts',values=dict(zip(names,x))),details=True)
    assert s['Max_daily_balance_residual_mm']<1e-7
    if policy=='GEE':
     target=config['baseline_reference'][str(year)]['Y_13pct'] if label=='DI_baseline' else c1.Y13
     assert abs(s['Y_13pct']-target)<1e-8
    rows.append(row_of(s,Year=year,Model_family='Old_four_year_root2p3_f0',Structure='historical_f0',Rain_policy=policy,Control=label,Observed_Y13=OBS[year],Meets_95pct_observed=s['Y_13pct']>=.95*OBS[year]-1e-9))
   dw=weather.set_index('Date').loc[m.DATES].copy();dw['Year']=year;dw['Rain_policy']=policy;weather_rows.append(dw.rename_axis('Date').reset_index()[['Year','Rain_policy','Date','Precipitation']])
  data['weather']=original;a._template.cache_clear();print('FOUR_YEAR REPLAY COMPLETE',year,flush=True)
 # New 2021 root1m pilots: actual fixed selected management and fixed original dates.
 choices=pd.read_csv(PREVIOUS/'tables/Selected_front_comparisons.csv',float_precision='round_trip')
 for sc in SCENARIOS:
  e=Engine(sc,True,tag='rain_small_trial');original=e.data['weather'].copy();controls=[(f'Proportional_{amount:g}',e.base*amount/e.cap) for amount in [0,300,350,400,500,633.47]]
  for kind,label in [('At_least_95pct_observed','Existing_Opt95'),('Match_own_DI_model','Existing_OptOwnDI')]:
   v=choices[choices.Scenario.eq(sc)&choices.Selection.eq(kind)].iloc[0];controls.append((label,v[names].to_numpy(float)))
  e.install()
  try:
   for policy,weather in policies(2021,original,e.m.DATES).items():
    e.data['weather']=weather;e.adapter._template.cache_clear()
    for label,x in controls:
     s,w,g=e.run(x,True);assert s['Max_daily_balance_residual_mm']<1e-7
     rows.append(row_of(s,Year=2021,Model_family='New_2021_root1m_pilot',Structure=sc,Rain_policy=policy,Control=label,Observed_Y13=15.86,Meets_95pct_observed=s['Y_13pct']>=.95*15.86-1e-9))
     if label in ['Existing_Opt95','Proportional_350','Proportional_633.47'] and policy in ['GEE','Graph_approx','GEE_trace_reassigned']:
      w.to_csv(R/'tables'/f'{sc}_{policy}_{label}_water.csv',index=False);g.to_csv(R/'tables'/f'{sc}_{policy}_{label}_growth.csv',index=False)
  finally:e.data['weather']=original;e.adapter._template.cache_clear();e.restore()
  print('ROOT1M REPLAY COMPLETE',sc,flush=True)
 a=pd.DataFrame(rows);assert len(a)==224
 reference=a[a.Rain_policy.eq('GEE')][['Year','Model_family','Structure','Control','Y_13pct','Tr_mm','ET_mm','Profile_final_mm','Irrigation_mm']].rename(columns={c:'Reference_'+c for c in ['Y_13pct','Tr_mm','ET_mm','Profile_final_mm','Irrigation_mm']})
 a=a.merge(reference,on=['Year','Model_family','Structure','Control'],how='left',validate='many_to_one')
 for c in ['Y_13pct','Tr_mm','ET_mm','Profile_final_mm','Irrigation_mm']:a['Change_'+c]=a[c]-a['Reference_'+c]
 a['Yield_change_pct']=100*a.Change_Y_13pct/a.Reference_Y_13pct
 a.to_csv(R/'tables/Frozen_parameter_rainfall_replays.csv',index=False);pd.concat(weather_rows,ignore_index=True).to_csv(R/'tables/Small_experiment_rainfall_inputs.csv',index=False)
 status=dict(Status='COMPLETE',Actual_model_replays=len(a),Old_four_year_replays=56,New_2021_root1m_replays=168,Rain_policies=POLICIES,Calibration_reruns=0,Optimization_reruns=0,Weather_changed_only='precipitation',Full_parameter_uncertainty_propagated=False,Graphic_reading_uncertainty='approximate heights and +/-1day shifts',No_claim_of_reoptimized_front=True,Maximum_daily_water_balance_residual_mm=float(a.Max_daily_balance_residual_mm.max()),Seconds=time.monotonic()-t)
 (R/'verification/SMALL_EXPERIMENT.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2),flush=True)
if __name__=='__main__':main()
