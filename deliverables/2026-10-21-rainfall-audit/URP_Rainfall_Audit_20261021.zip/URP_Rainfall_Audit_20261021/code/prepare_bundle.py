"""Freeze minimal original-model dependencies for portable rainfall replay."""
from pathlib import Path
import shutil,json,hashlib
import pandas as pd
R=Path(__file__).resolve().parents[1];P=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED');OLD=Path('/workspace/urp_2021_fmulch_comparison_20261021')
def main():
 dst=R/'model_snapshots/DI_PHASE3_NEXTGEN_UPDATED';(dst/'real_model').mkdir(parents=True,exist_ok=True)
 for y in range(2019,2023):shutil.copytree(P/f'real_model/model_{y}',dst/f'real_model/model_{y}',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','MCMC_Article_Results*'))
 for n in ['four_year_adapter.py','numerical_acceleration.py','root_zone_kernel.py','physical_kernels.py','KERNEL_ARGUMENTS.json']:shutil.copy2(P/'real_model'/n,dst/'real_model'/n)
 cfg=json.loads((P/'project_config.json').read_text());shutil.copy2(P/'project_config.json',dst/'project_config.json');d=dst/cfg['centers'];d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(P/cfg['centers'],d)
 parent=R/'dependencies/2021_fmulch';(parent/'code').mkdir(parents=True,exist_ok=True);shutil.copy2(OLD/'code/scenario_engine.py',parent/'code/scenario_engine.py')
 for sc in ['fm050','fm075','fm085']:
  d=parent/'calibration'/sc;d.mkdir(parents=True,exist_ok=True);shutil.copy2(OLD/'calibration'/sc/'SELECTED_PARAMETERS.json',d/'SELECTED_PARAMETERS.json')
 (parent/'tables').mkdir(exist_ok=True);shutil.copy2(OLD/'tables/Selected_front_comparisons.csv',parent/'tables/Selected_front_comparisons.csv')
 candidates=[]
 for y in range(2019,2023):
  c=pd.read_csv(f'/workspace/urp_true_runs_20261019/compact_results/optimization/{y}/epsilon_candidates.csv').iloc[0].to_dict();c['Year']=y;candidates.append(c)
 pd.DataFrame(candidates).to_csv(R/'tables/Original_four_year_candidate_controls.csv',index=False)
 allfiles=[p for folder in ['model_snapshots','dependencies'] for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
 (R/'verification/MODEL_BUNDLE_MANIFEST.json').write_text(json.dumps([dict(Path=str(p.relative_to(R)),SHA256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(allfiles)],indent=2));print('Bundled',len(allfiles),'source/parameter files')
if __name__=='__main__':main()
