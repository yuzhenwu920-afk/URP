"""Approximate daily rainfall digitization from thesis Figure2-2, with broken axes.
This reconstructs a published graphic, not original gauge measurements.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1]

def runs(x):
    v=np.flatnonzero(x)
    return np.split(v,np.flatnonzero(np.diff(v)>1)+1) if len(v) else []

def digitize(year):
    path=R/'paper_pages'/f'Figure2_2_{year}_render.png';im=Image.open(path).convert('RGB');a=np.asarray(im).astype(float);black=(a.max(2)<65)
    yg=[g for g in runs(black.sum(1)>.68*im.width) if len(g)>0];y0=float(np.median(yg[-1]));yt=float(np.median(yg[0]))
    xg=[g for g in runs(black[int(yt)+5:int(y0)-5].sum(0)>.73*(y0-yt)) if len(g)>0];xl=float(np.median(xg[0]));xr=float(np.median(xg[-1]));dx=(xr-xl)/182.
    blue=(a[:,:,2]-a[:,:,0]>45)&(a[:,:,2]-a[:,:,1]>35)&(a[:,:,2]>110)&(a[:,:,0]<160)&(a[:,:,1]<170)
    keep=np.zeros(blue.shape,bool);keep[int(yt)+3:int(y0)-2,int(xl)+3:int(xr)-2]=True
    # Exclude blue legend rectangle; this region contains no rainfall bars.
    keep[:int(yt)+100,int(xl+.72*(xr-xl)):]=False;blue &=keep
    # All bars have blue support near the baseline. Group adjacent blue columns.
    active=blue[int(y0)-8:int(y0)-2].sum(0)>=1
    groups=runs(active);events=[]
    if year<2021:lower_scale=(y0-yt)/30.;upper_scale=None
    elif year==2021:lower_scale=(y0-262.)/20.;upper_scale=(219.-yt)/10.
    else:lower_scale=(y0-213.)/30.;upper_scale=(175.-yt)/10.
    for group in groups:
        if len(group)<2:continue
        # Split unexpectedly connected bars at nominal daily centres.
        partitions=[group]
        if len(group)>1.4*dx:
            indices=np.rint((group-xl)/dx).astype(int);partitions=[group[indices==k] for k in np.unique(indices)]
        for g in partitions:
            if len(g)<2:continue
            x=float((g[0]+g[-1])/2);day_float=(x-xl)/dx;day=int(np.rint(day_float))
            ys=np.flatnonzero(blue[:,g].any(1))
            if not len(ys):continue
            top=float(ys.min())
            if year==2021 and top<240:p=60-(top-yt)/upper_scale;segment='50-60 mm'
            elif year==2022 and top<195:p=50-(top-yt)/upper_scale;segment='40-50 mm'
            else:p=(y0-top)/lower_scale;segment='lower linear segment'
            if p<.18:continue
            date=pd.Timestamp(f'{year}-04-01')+pd.Timedelta(days=day)
            events.append(dict(Year=year,Date=date.strftime('%Y-%m-%d'),P_digitized_mm=round(p,3),X_center_px=x,Bar_top_px=top,Day_float=day_float,Date_rounding_error_days=day_float-day,Axis_segment=segment,Event_height_uncertainty_mm=.35 if segment=='lower linear segment' else .5,Date_uncertainty_days=1,Source='thesis Figure2-2 PDF22 graphic reconstruction; NOT raw gauge data'))
    ev=pd.DataFrame(events).groupby(['Year','Date'],as_index=False).agg({c:'sum' if c=='P_digitized_mm' else 'first' for c in events[0] if c not in ['Year','Date']})
    dates=pd.date_range(f'{year}-04-01',f'{year}-09-30');daily=pd.DataFrame(dict(Year=year,Date=dates.strftime('%Y-%m-%d'))).merge(ev,on=['Year','Date'],how='left')
    daily['Bar_detected']=daily.P_digitized_mm.notna();daily['P_digitized_mm']=daily.P_digitized_mm.fillna(0);daily['Status']=np.where(daily.Bar_detected,'detected published bar','no detectable bar; not proof of exactly zero rainfall')
    draw=ImageDraw.Draw(im)
    for _,v in ev.iterrows():
        x=v.X_center_px;y=v.Bar_top_px;draw.rectangle([int(x)-4,int(y)-2,int(x)+4,int(y0)],outline='#FF0000',width=1)
        if v.P_digitized_mm>=8:draw.text((x+5,max(yt+5,y-15)),f'{v.Date[5:]}:{v.P_digitized_mm:.1f}',fill='red')
    im.save(R/'verification'/f'Digitization_overlay_{year}.png')
    meta=dict(Year=year,Plot_left_px=xl,Plot_right_px=xr,Zero_y_px=y0,Top_y_px=yt,Days_between_axis_endpoints=182,Pixels_per_day=dx,Lower_pixels_per_mm=lower_scale,Upper_pixels_per_mm=upper_scale,Events=len(ev),Full_Apr_Sep_sum_mm=float(ev.P_digitized_mm.sum()),Maximum_event_mm=float(ev.P_digitized_mm.max()),No_bars_below_approx_0p18mm_resolved=True,Date_uncertainty_days=1,Force_fit_to_GEE_or_paper_table=False)
    return daily,ev,meta

def main():
    daily=[];events=[];meta=[]
    for y in range(2019,2023):
        d,e,m=digitize(y);daily.append(d);events.append(e);meta.append(m)
    pd.concat(daily,ignore_index=True).to_csv(R/'tables/Paper_graph_daily_rainfall_approx.csv',index=False)
    pd.concat(events,ignore_index=True).to_csv(R/'tables/Paper_graph_detected_events.csv',index=False)
    (R/'verification/DIGITIZATION_CALIBRATION.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
