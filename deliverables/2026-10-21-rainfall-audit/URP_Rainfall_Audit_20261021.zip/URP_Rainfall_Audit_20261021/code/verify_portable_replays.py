"""Check bundled source replay without the project's accelerated kernels."""
from pathlib import Path
import json, sys, hashlib, time
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_small_experiment as r

def main():
    t=time.monotonic(); results=[]
    saved=pd.read_csv(r.R/'tables/Frozen_parameter_rainfall_replays.csv')
    config=json.loads((r.PROJECT/'project_config.json').read_text())
    centers=pd.read_csv(r.PROJECT/config['centers']).set_index('Year')
    controls=pd.read_csv(r.R/'tables/Original_four_year_candidate_controls.csv')
    fields=['Y_13pct','ET_mm','Tr_mm','Es_mm','Profile_final_mm','Irrigation_mm']
    names=['Window1_mm','Window2_mm','Window3_mm','Window4_mm']
    def compare(s,year,family,structure,policy,control):
        q=saved[(saved.Year==year)&(saved.Model_family==family)&(saved.Structure==structure)&(saved.Rain_policy==policy)&(saved.Control==control)]
        assert len(q)==1
        diffs={k:abs(float(s[k])-float(q.iloc[0][k])) for k in fields}
        assert max(diffs.values())<1e-8, (year,structure,policy,control,diffs)
        results.append(dict(Year=year,Structure=structure,Rain_policy=policy,Control=control,Maximum_absolute_difference=max(diffs.values())))
    for year in range(2019,2023):
        a=r.load_adapter();m,d=a._load(year);w=d['weather'].copy()
        sp=a.management_space(year);base=np.array(sp['baseline_amounts']);pc=centers.loc[year,['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']].to_dict()
        candidate=controls.loc[controls.Year.eq(year),names].iloc[0].to_numpy(float)
        for policy in ['GEE','Graph_approx']:
            d['weather']=r.policies(year,w,m.DATES)[policy];a._template.cache_clear()
            for label,x in [('DI_baseline',base),('Old_selected_95pct',candidate)]:
                s,_,_=a.simulate(params=pc,year=year,management=dict(kind='stage_amounts',values=dict(zip(names,x))),details=True,accelerate=False)
                compare(s,year,'Old_four_year_root2p3_f0','historical_f0',policy,label)
        print('Unaccelerated verification:',year,flush=True)
    choices=pd.read_csv(r.PREVIOUS/'tables/Selected_front_comparisons.csv')
    for sc in r.SCENARIOS:
        e=r.Engine(sc,False,tag='portable_verification');w=e.data['weather'].copy()
        c=choices[(choices.Scenario==sc)&(choices.Selection=='At_least_95pct_observed')].iloc[0][names].to_numpy(float)
        e.install()
        try:
            for policy in ['GEE','Graph_approx']:
                e.data['weather']=r.policies(2021,w,e.m.DATES)[policy];e.adapter._template.cache_clear()
                for label,x in [('Proportional_350',e.base*350/e.cap),('Existing_Opt95',c)]:
                    s,_,_=e.run(x,True)
                    compare(s,2021,'New_2021_root1m_pilot',sc,policy,label)
        finally:e.restore()
        print('Unaccelerated verification:',sc,flush=True)
    identity=json.loads((r.R/'tables/Model_input_identity.json').read_text())
    for item in identity:
        p=r.R/'inputs'/f"climate{item['Year']}.csv"
        assert hashlib.sha256(p.read_bytes()).hexdigest()==item['Upload_SHA256']==item['Input_SHA256']
    out=dict(Status='PASS',Bundled_source_used=True,Acceleration=False,Independent_replays=len(results),Tolerance=1e-8,Maximum_difference=max(x['Maximum_absolute_difference'] for x in results),Original_uploaded_climate_hashes_unchanged=True,Seconds=time.monotonic()-t,Results=results)
    (r.R/'verification/PORTABLE_REPLAY_CHECK.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({k:v for k,v in out.items() if k!='Results'},indent=2))
if __name__=='__main__':main()
