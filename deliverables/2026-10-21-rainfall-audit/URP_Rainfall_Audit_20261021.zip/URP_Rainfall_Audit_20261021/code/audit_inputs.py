"""Input identity, matched-period approximate rainfall audit and source limitations."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import pearsonr
R=Path(__file__).resolve().parents[1]
PAPER={2019:('04-18','09-16',157),2020:('04-20','09-18',98),2021:('04-27','09-22',150),2022:('04-17','09-12',172)}
def metrics(x,y):
 return dict(Bias_mm=float(np.mean(x-y)),MAE_mm=float(np.mean(abs(x-y))),RMSE_mm=float(np.sqrt(np.mean((x-y)**2))),Pearson_r=float(pearsonr(x,y).statistic))
def main():
 p=pd.read_csv(R/'tables/Paper_graph_daily_rainfall_approx.csv');p['Date']=pd.to_datetime(p.Date);models=json.loads((R/'tables/Model_input_identity.json').read_text());checks=[];daily=[];summaries=[];lags=[];monthly=[];block=[];labels=[]
 for yr in range(2019,2023):
  g=pd.read_csv(R/'inputs'/f'climate{yr}.csv');g['Date']=pd.to_datetime(g.date);d=g.merge(p[p.Year.eq(yr)][['Date','P_digitized_mm','Bar_detected']],on='Date',how='inner');d['Year']=yr;daily.append(d)
  expected=pd.date_range(f'{yr}-01-01',f'{yr}-12-31');assert len(g)==len(expected) and not g.Date.duplicated().any() and g.Date.tolist()==list(expected)
  assert g[['Tmin_C','Tmax_C','Precip_mm','ETo_mm']].notna().all().all() and (g.Precip_mm>=0).all() and (g.Tmin_C<=g.Tmax_C).all()
  mm=next(x for x in models if x['Year']==yr);s,e,total=PAPER[yr];start=pd.Timestamp(f'{yr}-{s}');end=pd.Timestamp(f'{yr}-{e}');mask=(d.Date>=start)&(d.Date<=end);sub=d[mask]
  old=d[d.Date.between(pd.Timestamp(mm['Model_start']),pd.Timestamp(mm['Model_end']))]
  row=dict(Year=yr,Paper_DI_start=start.strftime('%Y-%m-%d'),Paper_DI_end_inclusive=end.strftime('%Y-%m-%d'),Paper_Table5_13_P_mm=total,GEE_same_paper_window_mm=float(sub.Precip_mm.sum()),Graph_same_paper_window_approx_mm=float(sub.P_digitized_mm.sum()),GEE_minus_paper_table_mm=float(sub.Precip_mm.sum()-total),GEE_minus_graph_mm=float(sub.Precip_mm.sum()-sub.P_digitized_mm.sum()),Model_window_GEE_mm=mm['Model_season_P_mm'],Graph_same_model_window_approx_mm=float(old.P_digitized_mm.sum()),Apr_Sep_GEE_mm=float(d.Precip_mm.sum()),Apr_Sep_graph_mm=float(d.P_digitized_mm.sum()),GEE_max_daily_in_paper_window_mm=float(sub.Precip_mm.max()),Graph_max_daily_in_paper_window_approx_mm=float(sub.P_digitized_mm.max()),GEE_wet_days_gt1=int((sub.Precip_mm>=1).sum()),Graph_wet_days_gt1_approx=int((sub.P_digitized_mm>=1).sum()),GEE_trace_days_gt0_lt1=int(((sub.Precip_mm>0)&(sub.Precip_mm<1)).sum()),Input_matches_frozen_model=mm['Input_SHA256']==mm['Upload_SHA256'],Scope='graph rainfall is approximate; Table5-13 is published WHCNS balance input, not raw daily gauge series',**metrics(sub.Precip_mm.to_numpy(),sub.P_digitized_mm.to_numpy()))
  summaries.append(row)
  for lag in range(-2,3):
   y=d.P_digitized_mm.shift(lag);ok=mask&y.notna();lags.append(dict(Year=yr,Graph_shift_days=lag,**metrics(d.loc[ok,'Precip_mm'].to_numpy(),y[ok].to_numpy()),Scope='shift sensitivity for graphic date reading / daily aggregation; not a confirmed timezone correction'))
  for m,a in d.groupby(d.Date.dt.month):monthly.append(dict(Year=yr,Month=int(m),GEE_mm=a.Precip_mm.sum(),Graph_approx_mm=a.P_digitized_mm.sum()))
  for j,a in sub.groupby(((sub.Date-start).dt.days//7)):
   block.append(dict(Year=yr,Block=int(j),Start=str(a.Date.min().date()),End=str(a.Date.max().date()),GEE_mm=float(a.Precip_mm.sum()),Graph_approx_mm=float(a.P_digitized_mm.sum())))
  maize=pd.read_csv(R/'inputs'/f'maize{yr}.csv');labels.append(dict(Year=yr,Rows=len(maize),Irrigation_labels='|'.join(map(str,maize.IrriMetho.unique())) if 'IrriMetho' in maize else 'not provided',CCquad_min=float(maize.CCquad.min()),CCquad_max=float(maize.CCquad.max()),CCquad_scale='appears percent; do not treat max~80 as fraction',Role='remote-sensing CC proxy, not daily precipitation or direct measured CC; BI labels require geometry/export verification'))
  checks.append(dict(Year=yr,Rows=len(g),Date_sequence='PASS',Nonnegative_P='PASS',Tmin_le_Tmax='PASS',Missing_numeric_values=0,Uploaded_climate_SHA_matches_model=mm['Input_SHA256']==mm['Upload_SHA256']))
 pd.concat(daily,ignore_index=True).to_csv(R/'tables/Daily_GEE_vs_graph_approx.csv',index=False);pd.DataFrame(summaries).to_csv(R/'tables/Four_year_rainfall_comparison.csv',index=False);pd.DataFrame(lags).to_csv(R/'tables/Date_shift_sensitivity.csv',index=False);pd.DataFrame(monthly).to_csv(R/'tables/Monthly_totals.csv',index=False);pd.DataFrame(block).to_csv(R/'tables/Seven_day_totals.csv',index=False);pd.DataFrame(labels).to_csv(R/'tables/Remote_sensing_label_audit.csv',index=False)
 (R/'verification/INPUT_CHECK.json').write_text(json.dumps(dict(Status='PASS',Checks=checks,Daily_gauge_raw_data_available=False,GEE_product_ROI_timezone_metadata_available=False,Thesis_duplicates_identical=True,Graphic_data_never_labeled_raw_measurements=True),indent=2));print(pd.DataFrame(summaries).to_string(index=False));print(pd.DataFrame(lags)[['Year','Graph_shift_days','Pearson_r','RMSE_mm']].to_string(index=False))
if __name__=='__main__':main()
