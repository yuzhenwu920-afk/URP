"""Package a stable audit snapshot, excluding caches and unusable black extracts."""
from pathlib import Path
import hashlib, csv, json, zipfile
R=Path(__file__).resolve().parents[1]
NAME='URP_Rainfall_Audit_20261021'
def keep(p):
    rel=p.relative_to(R)
    if not p.is_file() or '__pycache__' in rel.parts:return False
    if 'input_audit' in rel.parts or p.suffix in ['.pyc','.nbc','.nbi','.log']:return False
    if p.name.endswith('_native.png'):return False
    if p.name in ['UPLOAD_PATHS.json','MANIFEST.csv','SHA256SUMS.txt',NAME+'.zip']:return False
    return rel.parts[0] in ['inputs','tables','verification','paper_pages','model_snapshots','dependencies','code','figures','documents'] or rel.name in ['README.md','ERRATA.md','requirements.txt']
def main():
    check=json.loads((R/'verification/DELIVERY_CHECK.json').read_text());assert check['Status']=='PASS'
    files=sorted(p for p in R.rglob('*') if keep(p));rows=[]
    for p in files:rows.append(dict(Path=p.relative_to(R).as_posix(),Bytes=p.stat().st_size,SHA256=hashlib.sha256(p.read_bytes()).hexdigest()))
    with (R/'MANIFEST.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['Path','Bytes','SHA256']);w.writeheader();w.writerows(rows)
    (R/'SHA256SUMS.txt').write_text(''.join(f"{q['SHA256']}  {q['Path']}\n" for q in rows))
    archive=R/(NAME+'.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files+[R/'MANIFEST.csv',R/'SHA256SUMS.txt']:z.write(p,arcname=NAME+'/'+p.relative_to(R).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for q in rows:assert hashlib.sha256(z.read(NAME+'/'+q['Path'])).hexdigest()==q['SHA256']
    print(json.dumps(dict(Archive=str(archive),Payload_files=len(rows),Bytes=archive.stat().st_size,SHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),Archive_check='PASS'),indent=2))
if __name__=='__main__':main()
