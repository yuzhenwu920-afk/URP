"""2021 structural fMulch comparisons with unchanged 1m root and original inputs."""
from pathlib import Path
import contextlib,copy,functools,hashlib,importlib,importlib.util,json,os,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
PROJECT=Path(os.environ.get('URP_PROJECT','/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED'))
SOURCE=PROJECT/'real_model/model_2021/DI_2021_MCMC_ONE_CLICK.py'
SCENARIOS={'fm050':.50,'fm075':.75,'fm085':.85}

def dump(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False));os.replace(tmp,p)

def load(fmulch,accelerated=True,tag='default'):
    spec=importlib.util.spec_from_file_location('original_2021_driver',SOURCE);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    for name in ['sampler','diagnostics','audit_hooks','ensemble_pipeline']:driver._embedded_module(name)
    m=driver._embedded_module('model',SOURCE.parent/'data/model.py');m.OUTPUT_DIR=ROOT/'verification/input_audit'/tag;m.OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
    data=m.load_inputs();m.prepare_soil(data);start=json.loads((SOURCE.parent/'data/start.json').read_text())
    m.PRIOR_BOUNDS.update(WP_early=(10.,40.),WP_late=(10.,40.),HI0=(.35,.60));m.NORMAL_PRIORS={'CDC_CD','SenescenceCD'};data['center'].update(WP_early=25.,WP_late=25.)
    oldcrop=m.crop_for
    def crop(values):c=oldcrop(values);c.Zmin=.30;c.Zmax=1.;return c
    m.crop_for=crop;oldfield=m.field_management
    def field():
        fm=oldfield();fm.f_mulch=float(fmulch);return fm
    m.field_management=field;m.effective_wp=functools.lru_cache(maxsize=128)(m.effective_wp)
    if accelerated:
        sys.path.insert(0,str(PROJECT/'real_model'));import numerical_acceleration;numerical_acceleration.install()
    return driver,m,data,start

class Engine:
    def __init__(self,scenario,accelerated=True,params=None,tag='response'):
        self.scenario=scenario;self.fmulch=SCENARIOS[scenario];self.accelerated=accelerated
        self.driver,self.m,self.data,_=load(self.fmulch,accelerated,tag+'_'+scenario)
        self.params=params if params is not None else json.loads((ROOT/'calibration'/scenario/'SELECTED_PARAMETERS.json').read_text())
        spec=importlib.util.spec_from_file_location('scenario_response_adapter',PROJECT/'real_model/four_year_adapter.py');self.adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.adapter);self.adapter.STATES[2021]=(self.m,self.data)
        self.space=self.adapter.management_space(2021);self.base=np.array(self.space['baseline_amounts']);self.cap=float(self.base.sum())
        p=self.data['soil'].profile;self.weights=np.clip(1-p.z_top.to_numpy(float),0,p.dz.to_numpy(float))*1000
        self.initial_root=float(np.dot(self.data['theta'],self.weights));self.observer=False;self.final={}
    def install(self):
        assert not self.observer;self.original_step=self.m.AquaCropModel._perform_timestep;engine=self
        def observe(model):
            result=engine.original_step(model);clock,cond,param,out=result
            assert float(param.FieldMngt.mulch_pct)==75. and float(param.FieldMngt.f_mulch)==engine.fmulch
            assert float(param.Seasonal_Crop_List[0].Zmax)==1. and float(cond.z_root)<=1+1e-9
            if clock.model_is_finished:engine.final=dict(Root1m_final_mm=float(np.dot(cond.th,engine.weights)),Runtime_fMulch=float(param.FieldMngt.f_mulch))
            return result
        self.m.AquaCropModel._perform_timestep=observe;self.observer=True
    def restore(self):
        if self.observer:self.m.AquaCropModel._perform_timestep=self.original_step;self.observer=False
    def run(self,x,details=False):
        assert self.observer;self.final={};mg=dict(kind='stage_amounts',values=dict(zip(self.space['names'],map(float,x))))
        s,w,g=self.adapter.simulate(params=self.params,year=2021,management=mg,details=True,accelerate=self.accelerated)
        assert self.final;s.update(self.final);s.update(Scenario=self.scenario,fMulch=self.fmulch,Root1m_initial_mm=self.initial_root,Root1m_change_mm=s['Root1m_final_mm']-self.initial_root)
        s['Below1m_initial_mm']=s['Profile_initial_mm']-self.initial_root;s['Below1m_final_mm']=s['Profile_final_mm']-s['Root1m_final_mm'];s['Below1m_change_mm']=s['Below1m_final_mm']-s['Below1m_initial_mm']
        s['Max_actual_event_mm']=max(e['mm'] for e in s['irrigation_events']);s['Exceeds_original_max_event']=bool(s['Max_actual_event_mm']>114.8+1e-8)
        return (s,w,g) if details else s
