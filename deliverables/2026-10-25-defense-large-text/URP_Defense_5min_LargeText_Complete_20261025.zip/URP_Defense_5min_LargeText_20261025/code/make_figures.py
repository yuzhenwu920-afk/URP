"""Presentation-size English figures from the verified current manuscript data."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'data';OUT=ROOT/'figures'
YEARS=[2019,2020,2021,2022]
C={2019:'#287BA3',2020:'#CE892E',2021:'#2A9178',2022:'#9565A6'}
INK='#163D3B';TEAL='#0C7B74';GOLD='#D49B42';GRAY='#708381'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':16,'axes.titlesize':18,'axes.labelsize':16,'xtick.labelsize':14,'ytick.labelsize':14,'legend.fontsize':14,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#849894','axes.labelcolor':INK,'text.color':INK,'xtick.color':INK,'ytick.color':INK,'axes.linewidth':.8,'grid.alpha':.35,'grid.color':'#D8E3DE','pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
def read(n):return pd.read_csv(DATA/n)
def save(fig,name):
 for ext in ['png','pdf','svg']:fig.savefig(OUT/(name+'.'+ext),dpi=320,bbox_inches='tight',facecolor='white')
 plt.close(fig)

def calibration():
 a=read('F02_CC_calibration_pairs.csv');b=read('F05_Biomass_calibration_pairs.csv')
 fig,axs=plt.subplots(1,2,figsize=(9.6,4.6),layout='constrained')
 for ax,d,x,y,lim,title,label in [(axs[0],a,'CC_observed','CC_simulated',1.05,'Canopy cover','Canopy cover (fraction)'),(axs[1],b,'B_observed_t_ha','B_simulated_t_ha',40,'Aboveground biomass','Biomass (t/ha)')]:
  ax.plot([0,lim],[0,lim],ls='--',lw=1.3,c='#8B9C97',zorder=1)
  for yr in YEARS:
   s=d[d.Year==yr];ax.scatter(s[x],s[y],c=C[yr],s=42,alpha=.9,edgecolors='white',linewidth=.5,label=str(yr),zorder=3)
  ax.set(xlim=(0,lim),ylim=(0,lim),xlabel='Observed '+label[0].lower()+label[1:],ylabel='Simulated '+label[0].lower()+label[1:]);ax.set_title(title,loc='left',weight='bold',pad=11);ax.set_aspect('equal');ax.grid();ax.text(.04,.94,f'n = {len(d)}',transform=ax.transAxes,va='top',fontsize=14)
 fig.legend(handles=[Line2D([],[],ls='',marker='o',c=C[y],markersize=8,label=str(y)) for y in YEARS]+[Line2D([],[],ls='--',c='#8B9C97',label='1:1 line')],loc='outside lower center',ncol=5,frameon=False)
 save(fig,'P04_Calibration_EN')

def sobol():
 annual=read('Sobol_annual_means_and_ranks.csv');annual=annual[annual.Output=='Y_13pct'];mean=read('Sobol_four_year_descriptive_means.csv');mean=mean[mean.Output=='Y_13pct'].sort_values('ST_four_year_mean',ascending=False)
 labels={'WP_late':'WP late','HI0':'HI0','WP_early':'WP early','Kcb':'Kcb','CCx':'CCx','CGC_CD':'CGC','CDC_CD':'CDC','SenescenceCD':'Senescence'}
 fig,axs=plt.subplots(1,2,figsize=(10.2,4.6),gridspec_kw={'width_ratios':[1.08,1]},layout='constrained')
 colors=['#0C7B74','#397F94','#D19A43','#8A6D9C']
 for k,p in enumerate(mean.Parameter.iloc[:4]):
  s=annual[annual.Parameter==p].set_index('Year').loc[YEARS];axs[0].plot(YEARS,s.ST_mean,marker='o',ms=6.5,lw=2.2,c=colors[k],label=labels[p])
 axs[0].set(xticks=YEARS,xlabel='Year',ylabel='Total-effect index',ylim=(0,.52));axs[0].set_title('Annual contribution',loc='left',weight='bold',pad=12);axs[0].grid(axis='y');axs[0].legend(loc='upper right',frameon=False,fontsize=13.5)
 values=mean.ST_four_year_mean.to_numpy();y=np.arange(len(mean));axs[1].barh(y,values,color=[TEAL if i<4 else '#C9D9D2' for i in range(8)],height=.62);axs[1].set_yticks(y,[labels[p] for p in mean.Parameter]);axs[1].invert_yaxis();axs[1].set(xlim=(0,.46),xlabel='Four-year mean');axs[1].set_title('Four-year mean ranking',loc='left',weight='bold',pad=12);axs[1].grid(axis='x');axs[1].set_axisbelow(True)
 for j,v in enumerate(values):axs[1].text(v+.007,j,f'{v:.3f}',va='center',fontsize=14)
 save(fig,'P05_Sobol_EN')

def pareto():
 d=read('FiveStage_Full_range_Pareto_front.csv');cmp=read('FiveStage_Four_year_result_comparison.csv').set_index('Year')
 fig,axs=plt.subplots(2,2,figsize=(9.0,5.5),layout='constrained')
 for i,(ax,yr) in enumerate(zip(axs.flat,YEARS)):
  s=d[d.Year==yr].sort_values(['Irrigation_mm','Y_13pct']);s=s.groupby('Irrigation_mm',as_index=False).Y_13pct.max();r=cmp.loc[yr]
  ax.plot(s.Irrigation_mm,s.Y_13pct,'--',c='#4477BB',lw=2.1,zorder=2)
  ii=np.unique(np.linspace(0,len(s)-1,9).astype(int));ax.scatter(s.iloc[ii].Irrigation_mm,s.iloc[ii].Y_13pct,s=20,c='#D95B4E',edgecolors='white',linewidth=.35,zorder=3)
  ax.scatter([r.Original_I_mm],[r.Original_Y13],marker='*',s=125,c=INK,zorder=4)
  ax.axhline(r.Yield_gate,ls=':',c='#C29D70',lw=1.25,zorder=1)
  ax.scatter([r.Optimized_I_mm],[r.Optimized_Y13],facecolors='white',edgecolors='#D79032',linewidths=2.3,s=85,zorder=5)
  ax.set(xlim=(-8,r.Original_I_mm*1.06),ylim=(0,18.3));ax.set_title(str(yr),loc='left',color=C[yr],weight='bold',pad=7);ax.grid();ax.set_yticks([0,5,10,15]);ax.tick_params(labelsize=14)
  if i%2==0:ax.set_ylabel('Yield (t/ha)')
  if i>=2:ax.set_xlabel('Irrigation (mm)')
 handles=[Line2D([],[],c='#4477BB',ls='--',label='Front'),Line2D([],[],marker='o',ls='',c='#D95B4E',label='Solutions'),Line2D([],[],marker='*',ls='',c=INK,markersize=10,label='DI baseline'),Line2D([],[],marker='o',ls='',mfc='white',mec='#D79032',mew=2,label='Selected'),Line2D([],[],ls=':',c='#C29D70',label='95% yield')]
 fig.legend(handles=handles,loc='outside upper center',ncol=2,frameon=False,fontsize=14)
 save(fig,'P06_Pareto_EN')

def water():
 d=read('FiveStage_Four_year_result_comparison.csv');fig,ax=plt.subplots(figsize=(7.3,4.8),layout='constrained');x=np.arange(4);bottom=np.zeros(4)
 for col,label,c,hatch in [('ET_reduction_mm','Lower ET','#D9A24B',''),('Lower_final_storage_mm','Lower terminal storage','#3A8E87','///'),('Other_loss_reduction_mm','Other losses','#BFCFC8','')]:
  v=d[col].to_numpy();ax.bar(x,v,bottom=bottom,width=.56,color=c,hatch=hatch,label=label,edgecolor='white',linewidth=.8);bottom+=v
 for i,r in d.iterrows():
  ax.text(i,bottom[i]+7,f'{r.Storage_difference_share_pct:.1f}%',ha='center',weight='bold',fontsize=14)
 ax.set(xticks=x,xticklabels=YEARS,ylim=(0,435),ylabel='Irrigation reduction (mm)');ax.grid(axis='y');ax.set_axisbelow(True);ax.legend(loc='upper left',frameon=False,fontsize=14);ax.text(.99,.96,'Labels: storage share',ha='right',va='top',transform=ax.transAxes,fontsize=13,color=GRAY)
 save(fig,'P07_Water_components_EN')

def calendar():
 e=read('FiveStage_Optimized_every_irrigation_event.csv');b=read('FiveStage_Five_stage_schedule_bounds.csv');fig,axs=plt.subplots(2,2,figsize=(11.6,5.2),layout='constrained',sharey=True)
 colors=['#AAD4BF','#53998A','#DFC58D','#C6B3CC','#9FB7C8']
 for ax,y in zip(axs.flat,YEARS):
  for r in b[b.Year==y].itertuples():ax.axvspan(pd.to_datetime(r.First_allowed_date),pd.to_datetime(r.Last_allowed_date),color=colors[int(r.Stage)-1],alpha=.18,lw=0)
  d=e[e.Year==y];xx=pd.to_datetime(d.Date);ax.vlines(xx,0,d.Actual_mm,colors=[colors[int(s)-1] for s in d.Stage],lw=3);ax.scatter(xx,d.Actual_mm,c=[colors[int(s)-1] for s in d.Stage],s=38,edgecolors=INK,linewidth=.5,zorder=3)
  ax.set_title(str(y),loc='left',color=C[y],weight='bold');ax.set_ylim(-7,200);ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'));ax.grid(axis='y');ax.set_ylabel('Irrigation (mm)')
 handles=[Line2D([],[],ls='',marker='s',c=c,markersize=9,label=n) for c,n in zip(colors,['Seedling','Jointing','Heading','Grain filling','Maturity'])];fig.legend(handles=handles,loc='outside upper center',ncol=5,frameon=False,fontsize=14)
 save(fig,'B02_Irrigation_calendar_EN')

def main():
 OUT.mkdir(exist_ok=True)
 for f in [calibration,sobol,pareto,water,calendar]:f();print(f.__name__,flush=True)
 with pd.ExcelWriter(DATA/'URP_Defense_Source_Data_20261025.xlsx',engine='openpyxl') as w:
  for i,p in enumerate(sorted(DATA.glob('*.csv')),1):pd.read_csv(p).to_excel(w,sheet_name=f'{i:02d}_'+p.stem[:27],index=False)
  for s in w.book.worksheets:s.freeze_panes='A2';s.auto_filter.ref=s.dimensions

if __name__=='__main__':main()
