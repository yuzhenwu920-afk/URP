"""Package the defense and publish to the already authorized URP delivery branch."""
from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,urllib.request,zipfile
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'delivery';REPO=Path('/workspace/URP');DEST='deliverables/2026-10-25-defense-large-text';BRANCH='delivery/urp-review-20261015'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(REPO),*a]).decode().strip()
def run(*a):subprocess.run(['git','-C',str(REPO),*a],check=True)
def main():
 qa=json.loads((ROOT/'analysis/PRESENTATION_QA.json').read_text());assert qa['Status']=='PASS'
 assert git('branch','--show-current')==BRANCH and not git('status','--porcelain')
 original_main=git('ls-remote','origin','refs/heads/main').split()[0]
 OUT.mkdir(exist_ok=True)
 for p in (ROOT/'documents').iterdir():
  if p.is_file():shutil.copy2(p,OUT/p.name)
 shutil.copy2(ROOT/'data/URP_Defense_Source_Data_20261025.xlsx',OUT/'URP_Defense_Source_Data_20261025.xlsx')
 shutil.copy2(ROOT/'analysis/Preview_Main_Slides.jpg',OUT/'Preview_Main_Slides.jpg')
 shutil.copy2(ROOT/'analysis/PRESENTATION_QA.json',OUT/'PRESENTATION_QA.json')
 entries=[]
 for dirname in ['code','documents','data','figures']:
  for p in (ROOT/dirname).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:entries.append((p,'URP_Defense_5min_LargeText_20261025/'+str(p.relative_to(ROOT))))
 for p,n in [(ROOT/'README.md','README.md'),(ROOT/'analysis/PRESENTATION_QA.json','analysis/PRESENTATION_QA.json'),(ROOT/'analysis/Preview_Main_Slides.jpg','analysis/Preview_Main_Slides.jpg')]:entries.append((p,'URP_Defense_5min_LargeText_20261025/'+n))
 archive=OUT/'URP_Defense_5min_LargeText_Complete_20261025.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p,n in sorted(entries,key=lambda t:t[1]):z.write(p,n)
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 text='''# URP 五分钟答辩：大字精简版（2026-10-25）

**[下载可编辑PPT](URP_Defense_5min_LargeText_20261025.pptx)** · [8页主讲PDF](URP_Defense_5min_LargeText_20261025.pdf) · [完整资料ZIP](URP_Defense_5min_LargeText_Complete_20261025.zip)

已按最新意见删除装饰性英文页眉，页脚仅保留页码；来源说明移入备注。数学上标、帽号等改为普通文字，标题、主要结论和数字放大。8页主讲，建议时间合计300秒；4页隐藏备答，默认放映跳过。主题为最新四年两阶段MCMC、Sobol、五生育期逐次灌水优化与储水机制。全套采用16:9、中文主讲和英文科学图表。

逐页中文讲稿已写入PPT备注：[讲稿Word](URP_5min_Speaker_Script_LargeText_20261025.docx) · [讲稿PDF](URP_5min_Speaker_Script_LargeText_20261025.pdf)。

[含备答的12页PDF](URP_Defense_5min_LargeText_With_Backup_20261025.pdf) · [图表源数据Excel](URP_Defense_Source_Data_20261025.xlsx) · [版面、备注、数据与时间验收](PRESENTATION_QA.json)

![主讲8页预览](Preview_Main_Slides.jpg)

主讲用时：15＋35＋40＋45＋35＋50＋55＋25＝300秒；第8页结束即停。备答含原链诊断、逐次灌水日程、三个关键问题、主要文献。完整ZIP含PPT、全部PDF、讲稿、源数据、高清图及生成代码。

科学结果沿用2026-10-23最新论文，模型版本20f1616556f5aeb79329b7ead22faa28f9fcda6a。本次仅制作答辩、重绘图表，无新增模型运行；四年主设定与2021条件试验分开，采样诊断和水量组成如实说明。
'''
 (OUT/'README.md').write_text(text)
 files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt')
 (OUT/'SHA256SUMS.txt').write_text('\n'.join(f'{digest(p)}  {p.name}' for p in files)+'\n')
 shutil.copytree(OUT,REPO/DEST,dirs_exist_ok=True)
 for path,prefix in [(REPO/'README.md','deliverables/'),(REPO/'deliverables/README.md','')]:
  old=path.read_text().replace('最新：URP五分钟答辩PPT（2026-10-25）','此前：URP五分钟答辩原版（2026-10-25）');link=prefix+'2026-10-25-defense-large-text/'
  entry=f'**[最新：URP五分钟答辩大字精简版（2026-10-25）]({link})**：8页主讲＋4页隐藏备答，含逐页中文讲稿、PDF预览、图表数据与完整源文件。\n\n'
  title,rest=old.split('\n',1);path.write_text(title+'\n\n'+entry+rest.lstrip())
 run('add','-f','--',DEST,'README.md','deliverables/README.md');run('-c','gc.auto=0','commit','-m','Improve defense readability with larger type, plain symbols and minimal footers');run('-c','pack.window=0','-c','gc.auto=0','push','origin','HEAD:refs/heads/'+BRANCH)
 commit=git('rev-parse','HEAD');base='https://raw.githubusercontent.com/yuzhenwu920-afk/URP/'+commit+'/'+DEST+'/'
 def check(p):
  target=ROOT/'analysis/remote_downloads'/p.name;target.parent.mkdir(exist_ok=True)
  with urllib.request.urlopen(urllib.request.Request(base+p.name,headers={'User-Agent':'URP-defense-verification'}),timeout=60) as r,target.open('wb') as f:
   assert r.status==200
   shutil.copyfileobj(r,f)
  assert digest(target)==digest(p)
  if p.suffix in ['.zip','.pptx','.docx','.xlsx']:
   with zipfile.ZipFile(target) as z:assert z.testzip() is None
  return {'File':p.name,'Bytes':p.stat().st_size,'SHA256':digest(p),'HTTP':200}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:checked=list(pool.map(check,files))
 assert git('ls-remote','origin','refs/heads/main').split()[0]==original_main
 result={'Status':'PASS','Delivery_commit':commit,'Delivery_path':DEST,'Main_unchanged':original_main,'Main_slides':8,'Hidden_backup_slides':4,'Planned_seconds':300,'Remote_downloads':checked}
 (ROOT/'analysis/REMOTE_DOWNLOAD_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 proof=REPO/DEST/'REMOTE_DOWNLOAD_VERIFICATION.json';shutil.copy2(ROOT/'analysis/REMOTE_DOWNLOAD_VERIFICATION.json',proof)
 run('add','-f','--',str(proof.relative_to(REPO)));run('-c','gc.auto=0','commit','-m','Verify large-text defense downloads');run('-c','gc.auto=0','push','origin','HEAD:refs/heads/'+BRANCH)
 print(json.dumps({'Status':'PASS','Content_commit':commit,'Verification_commit':git('rev-parse','HEAD'),'Files_downloaded_and_checked':len(checked),'PPTX_URL':base+'URP_Defense_5min_LargeText_20261025.pptx','PDF_URL':base+'URP_Defense_5min_LargeText_20261025.pdf','ZIP_URL':base+archive.name,'ZIP_bytes':archive.stat().st_size},ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
