"""Check presentation render, timing, data consistency and hidden backups."""
from pathlib import Path
import json,re,unicodedata,hashlib
import numpy as np
import pandas as pd
import fitz
from PIL import Image,ImageDraw
from pptx import Presentation

ROOT=Path(__file__).resolve().parents[1]
def norm(s):
 # The PDF renderer emits the combining R-hat glyph as a separate text object,
 # sometimes after its surrounding line; compare the surrounding text in order.
 s=s.replace('R̂','')
 s=unicodedata.normalize('NFKD',s)
 return ''.join(c for c in s if not c.isspace() and not unicodedata.combining(c) and c not in '−⁻¹')
def main():
 p=Presentation(ROOT/'documents/URP_Defense_5min_LargeText_20261025.pptx')
 main=fitz.open(ROOT/'documents/URP_Defense_5min_LargeText_20261025.pdf');full=fitz.open(ROOT/'documents/URP_Defense_5min_LargeText_With_Backup_20261025.pdf')
 assert len(p.slides)==len(full)==12 and len(main)==8
 text='\n'.join(sh.text for slide in p.slides for sh in slide.shapes if sh.has_text_frame)
 for glyph in ['→','×','≥','≤','−','–','—','²','⁻','̂','·','□','�']:assert glyph not in text,glyph
 for slide in p.slides:
  for sh in slide.shapes:
   if sh.has_text_frame and sh.top>int(7.1*914400):assert len(sh.text)<=5,sh.text
 previous=Path('/workspace/urp_defense_5min_20261025/data')
 for old in previous.glob('*.csv'):
  new=ROOT/'data'/old.name
  if old.name!='Slide_timing_and_scripts.csv':assert hashlib.sha256(old.read_bytes()).digest()==hashlib.sha256(new.read_bytes()).digest(),old.name

 assert [s._element.get('show','1') for s in p.slides]==['1']*8+['0']*4
 timeline=pd.read_csv(ROOT/'data/Slide_timing_and_scripts.csv');assert timeline.Duration_seconds.sum()==300 and timeline.Cumulative_seconds.iloc[-1]==300
 notes=0;outside=[];missing=[];shape_edges=[];thumbs=[];chinese_fonts=set()
 for i,pg in enumerate(full):
  s=p.slides[i]
  if i<8:assert '【口播稿】' in s.notes_slide.notes_text_frame.text;notes+=1
  pix=pg.get_pixmap(matrix=fitz.Matrix(1.5,1.5));im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.save(ROOT/f'analysis/Slide_{i+1:02d}.png');small=im.copy();small.thumbnail((600,338));tile=Image.new('RGB',(620,366),'white');tile.paste(small,(10,5));ImageDraw.Draw(tile).text((12,348),f'{i+1:02d}  '+('MAIN' if i<8 else 'BACKUP'),fill='black');thumbs.append(tile)
  for b in pg.get_text('dict')['blocks']:
   for l in b.get('lines',[]):
    for sp in l['spans']:
     if re.search('[\u4e00-\u9fff]',sp['text']):
      chinese_fonts.add(sp['font']);assert 'CJK' in sp['font'],('Chinese fallback font',i+1,sp['font'],sp['text'])
     x0,y0,x1,y1=sp['bbox']
     if x0<-.6 or y0<-.6 or x1>pg.rect.width+.6 or y1>pg.rect.height+.6:outside.append((i+1,sp['text']))
  text=norm(pg.get_text())
  for sh in s.shapes:
   if sh.left<-1000 or sh.top<-1000 or sh.left+sh.width>p.slide_width+1000 or sh.top+sh.height>p.slide_height+1000:shape_edges.append((i+1,sh.name))
   if sh.has_text_frame:
    for para in sh.text_frame.paragraphs:
     t=norm(para.text)
     # Superscript unit extraction can reorder the final minus and one in PDF.
     if len(t)>2 and t not in text:
      if para.text=='产量 / t·ha⁻¹' and '产量/t·ha' in text:continue
      missing.append((i+1,para.text))
 assert not outside,outside;assert not missing,missing;assert not shape_edges,shape_edges
 # Numeric metric was specifically checked after fixing its line wrapping.
 rects=full[3].search_for('4.18%')
 assert rects
 d=pd.read_csv(ROOT/'data/FiveStage_Four_year_result_comparison.csv')
 np.testing.assert_allclose(d.Optimized_I_mm,[209.8315811759,306.4989537268,264.4999754389,257.4652532595],atol=1e-7,rtol=0)
 assert (d.Optimized_Y13>=d.Observed_Y13*.95-1e-8).all()
 np.testing.assert_allclose(d.I_reduction_mm,d.ET_reduction_mm+d.Lower_final_storage_mm+d.Other_loss_reduction_mm,atol=1e-7)
 e=pd.read_csv(ROOT/'data/FiveStage_Optimized_every_irrigation_event.csv')
 assert len(e)==42
 for r in d.itertuples():assert abs(e[e.Year==r.Year].Actual_mm.sum()-r.Optimized_I_mm)<1e-7
 fit=pd.read_csv(ROOT/'data/Table3_calibration_performance.csv');assert np.isclose(fit.CC_R2_cal.min(),.9306,atol=.00005)
 a=pd.read_csv(ROOT/'data/Sobol_annual_means_and_ranks.csv');a=a[a.Output=='Y_13pct']
 for y in range(2019,2023):assert a[a.Year==y].sort_values('ST_mean',ascending=False).Parameter.iloc[:4].tolist()==['WP_late','HI0','WP_early','Kcb']
 preview=Image.new('RGB',(1240,1464),'#DCE6DE')
 for i,t in enumerate(thumbs[:8]):preview.paste(t,((i%2)*620,(i//2)*366))
 preview.save(ROOT/'analysis/Preview_Main_Slides.jpg',quality=92)
 allslides=Image.new('RGB',(1860,1464),'#DCE6DE')
 for i,t in enumerate(thumbs):allslides.paste(t,((i%3)*620,(i//3)*366))
 allslides.save(ROOT/'analysis/Preview_All_Slides.jpg',quality=92)
 result={'Status':'PASS','Main_slides':8,'Backup_slides':4,'Default_slideshow_skips_backup':True,'Planned_main_seconds':300,'Slide_notes_with_script':notes,'Main_PDF_pages':len(main),'Full_PDF_pages':len(full),'PPT_viewport_overflows':shape_edges,'PDF_page_overflows':outside,'Missing_rendered_native_text':missing,'Selected_depths_mm':d.Optimized_I_mm.tolist(),'Source_data_and_water_ledger_checked':True,'Event_rows':len(e),'New_model_runs':False,'Scientific_CSV_data_unchanged':True,'Decorative_English_headers_removed':True,'Footers_reduced_to_page_numbers':True,'Key_title_font_pt':34,'Compatibility_font':'Microsoft YaHei / Arial','Special_math_glyphs_removed':True}
 (ROOT/'analysis/PRESENTATION_QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
 result['Chinese_PDF_fonts_verified']=sorted(chinese_fonts)
 (ROOT/'analysis/PRESENTATION_QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
