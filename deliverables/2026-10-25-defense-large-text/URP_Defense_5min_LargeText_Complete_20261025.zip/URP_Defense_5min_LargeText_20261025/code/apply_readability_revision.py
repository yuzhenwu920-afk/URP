"""One-time source revision: compatible text, larger key labels, fewer footers."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'code/build_defense.py';s=p.read_text()
s=s.replace("FONT='Noto Sans CJK SC';LATIN='DejaVu Sans'","FONT='Microsoft YaHei';LATIN='Arial'\nSOURCE_NOTES={}")
s=s.replace("def txt(s,text,x,y,w,h,size=20,color=INK,bold=False,align=PP_ALIGN.LEFT,font=FONT,valign=MSO_ANCHOR.TOP):",'''def plain(text):
 for a,b in [('t·ha⁻¹','t/ha'),('R̂','Rhat'),('R²cal','R2'),('≥','至少'),('≤','最多'),('×','x'),('→',' '),('·',' '),('｜',' '),('−','-'),('–','至'),('—',' '),('²','2')]:text=str(text).replace(a,b)
 return text
def txt(s,text,x,y,w,h,size=20,color=INK,bold=False,align=PP_ALIGN.LEFT,font=FONT,valign=MSO_ANCHOR.TOP):''')
s=s.replace(" for i,t in enumerate(str(text).split('\\n')):"," for i,t in enumerate(plain(text).split('\\n')):")
s=s.replace("r.font.color.rgb=rgb(color)\n return o",'''r.font.color.rgb=rgb(color)
  from pptx.oxml.xmlchemy import OxmlElement
  rp=r._r.get_or_add_rPr()
  for script in ['ea','cs']:
   el=OxmlElement('a:'+script);el.set('typeface',FONT);rp.append(el)
 return o''')
a=s.index('def new(');b=s.index('def pic(',a)
s=s[:a]+'''def new(title,tag,index,source='',backup=False):
 s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=rgb(BG)
 txt(s,title,.56,.43,12.25,.75,34,INK,True);shape(s,.56,1.27,.70,.04,TEAL)
 footer(s,index,source,backup);return s
def footer(s,index,source='',backup=False,dark=False):
 if source:SOURCE_NOTES[id(s)]=source
 c='AEC8BF' if dark else MUTED
 txt(s,str(index) if not backup else '备答'+str(index),12.05,7.16,.72,.25,14,c,align=PP_ALIGN.RIGHT,font=FONT)
''' + s[b:]
a=s.index('def ribbon(');b=s.index('def notes(',a)
s=s[:a]+'''def ribbon(s,text,y=6.39,fill=PALE,color=TEAL):
 height=.72 if '\\n' not in text else .90
 shape(s,.56,y,12.2,height,fill,rounding=True)
 txt(s,text,.79,y+.12,11.75,height-.18,22,color,True)
''' + s[b:]
a=s.index('def cover():');b=s.index('def data_slide():',a)
s=s[:a]+'''def cover():
 s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=rgb(DARK)
 shape(s,8.06,0,W-8.06,H,'193E3B');txt(s,'URP项目答辩',.68,.50,7,.46,22,'B9D4C8',True)
 shape(s,.68,1.38,.66,.065,GOLD);txt(s,'膜下滴灌玉米\\n灌溉制度优化',.65,1.72,7.15,1.95,46,WHITE,True)
 txt(s,'四年资料\\nMCMC校准  Sobol分析  五期优化',.69,4.02,7.10,1.00,24,'D6E7DE')
 txt(s,'吴雨臻  李承昊  段璞',.70,5.76,6.9,.48,23,WHITE)
 txt(s,'指导教师：廖人宽  中国农业大学',.70,6.35,7.1,.42,19,'B9D4C8')
 for j in range(5):line(s,8.38,5.05+j*.27,12.92,5.05+j*.27,'315953',.7)
 for j in range(3):ellipse(s,8.95+j*.34,1.09+j*.33,3.1-j*.62,3.1-j*.62,None,'315C55',1)
 stages=['苗期','拔节期','抽穗期','灌浆期','成熟期'];pts=[(8.58,4.64),(9.34,4.11),(10.07,3.65),(10.83,3.15),(11.64,2.77)]
 for i,(x,y) in enumerate(pts):
  if i:line(s,*pts[i-1],x,y,'80BAA4',2)
  ellipse(s,x-.085,y-.085,.17,.17,GOLD if i==4 else 'B9D9C4');line(s,x,y+.2,x,5.08,'4D8775',.8);txt(s,stages[i],x-.28,y+.3,1.05,.37,15,'D0E3D6')
 txt(s,'五个生育期',8.55,5.87,4.1,.60,32,WHITE,True)
 txt(s,'校准、分析与灌溉决策',8.55,6.56,4.1,.42,20,'B9D4C8')
 footer(s,1,'2026.10.25；项目编号X2026100190937；基于马尔科夫链的不同灌溉方式灌溉制度优化',dark=True)
 notes(s,1,'本次汇报聚焦DI玉米，正式项目名称保留原立项名称。')

''' + s[b:]
changes={
"'甘肃武威 · 膜下滴灌玉米',.66,1.70,6.1,.45,22":"'甘肃武威 膜下滴灌玉米',.66,1.70,6.1,.53,25",
"6.2,2.55,30":"6.2,2.55,34",
"1.7,.6,31":"1.7,.68,38",
"1.75,.35,15":"1.75,.42,19",
"4.85,.45,21":"4.85,.54,25",
"'年份',7.56,2.65,.9,.32,15":"'年份',7.56,2.65,.9,.41,18",
"'灌水量 / mm',8.68,2.65,1.6,.32,15":"'灌水量 mm',8.68,2.65,1.8,.41,18",
"'产量 / t·ha⁻¹',10.55,2.65,1.8,.32,15":"'产量 t/ha',10.55,2.65,1.9,.41,18",
".95,.4,20,YC":".95,.46,23,YC",
"1.4,.4,20,INK":"1.4,.46,24,INK",
" txt(s,'既有观测资料[1]  ·  产量按13%含水率表示',7.55,6.14,4.85,.28,12.2,MUTED)":" txt(s,'产量按13%含水率表示',7.55,6.09,4.85,.39,18,MUTED)",
"'阶段一 5参数｜阶段二 3参数\\n每组32 walkers × 2000步'":"'先5后3，分阶段校准'",
"'8参数 × 6输出\\nN=512 × 3个随机化序列'":"'8个参数，6类输出'",
"'每期0–3次｜零量取消\\n15个水量＋15个日期'":"'每期最多3次，零量取消'",
"3.48,.44,24":"3.48,.53,26",
"3.48,.79,19":"3.48,.85,22",
"3.48,.53,12.6":"3.48,.57,18",
"  if j<2:txt(s,'→',x+3.92,2.88,.23,.38,21,TEAL,True)":"  # Adjacent cards are ordered by their numbers; no symbol arrows.",
"'五生育期',.60,5.09,1.6,.4,18":"'五生育期',.60,5.09,1.6,.48,21",
"1.88,.35,18":"1.88,.44,22",
"ribbon(s,'固定主设定：覆膜75%  ·  fMulch=0结构基线  ·  最大根深2.30 m',6.18)":"ribbon(s,'五个生育期，联合优化灌水日期与水量',6.18)",
"'晚期WP → HI0 → 早期WP → Kcb：年平均排序一致，贡献幅度存在年际变化'":"'晚期水分生产率是产量的首要敏感参数'",
"'95%观测产量门槛下',9.93,1.70,2.74,.38,16":"'观测产量的95%',9.93,1.67,2.74,.48,21",
".8,.30,15,YC":".8,.38,18,YC",
"1.55,.40,25,INK":"1.55,.49,31,INK",
".45,.22,11,MUTED":".45,.28,15,MUTED",
"'每期0–3次，日期与水量联合调整；候选对应完整的逐次灌水日程'":"'每期最多3次，输出每次灌水日期与水量'",
"'2021 水量账',8.67,2.01,3.72,.4,23":"'2021 水量账 (mm)',8.67,2.01,3.72,.48,25",
"'少灌 368.97 mm',8.67,2.63,3.72,.55,29":"'少灌 368.97',8.67,2.63,3.72,.61,33",
"'季末储水差 / mm'":"'季末储水差'",
"'ET下降 / mm'":"'蒸散减少'",
"'其他损失差 / mm'":"'其他损失'",
"1.72,.45,26,col":"1.72,.54,31,col",
"1.95,.31,14.5":"1.95,.41,19",
"'ET下降1.89%–5.98%；季末储水差解释81.09%–96.72%的减灌量'":"'ET降幅1.89%至5.98%；储水差贡献81.09%至96.72%'",
"'四年多指标校准\\n主要生长与产量轨迹'":"'四年多指标校准\\n重现主要生长过程'",
"'五期、逐次日期与水量\\n形成完整候选日程'":"'五期日期水量优化\\n输出逐次灌水日程'",
"'分解减灌量的组成\\n明确储水缓冲的作用'":"'追踪减灌水量来源\\n解释储水缓冲作用'",
"3.45,.43,23":"3.45,.52,26",
"3.45,.74,18":"3.45,.86,22",
"1.5,.39,19,TEAL":"1.5,.48,22,TEAL",
"10.36,.86,20":"10.36,.90,22",
"11.8,.40,22,WHITE":"11.8,.49,26,WHITE",
"'主模型固定设置',.66,1.77,4.5,.42,22":"'主模型固定设置',.66,1.77,4.5,.51,25",
"'第一阶段4组；第二阶段1组/年'":"'每年阶段一4组，阶段二1组'",
"5.65,.40,18,INK":"5.65,.48,21,INK",
"'最差 R̂'":"'最差Rhat'",
"'最小组 bulk ESS'":"'最小组ESS'",
"w,.34,14.5,MUTED":"w,.42,17,MUTED",
"1,.34,18,YC":"1,.42,21,YC",
"1.45,.34,18,INK":"1.45,.43,22,INK",
"1.57,.34,18,INK":"1.57,.43,22,INK",
"txt(s,'参考：R̂ < 1.01；bulk/tail ESS ≥ 400',6.94,5.64,5.4,.30,13.2,MUTED)":"txt(s,'Rhat参考值：小于1.01；ESS至少400',6.94,5.56,5.4,.44,17,MUTED)",
"'参数中心的过程拟合与分布采样精度分开报告；后续重点提升有效样本量'":"'过程拟合与采样精度分开评价'",
"'B02_Irrigation_calendar_EN',.57,1.64,12.15,4.69":"'B02_Irrigation_calendar_EN',.57,1.53,12.15,4.66",
"ribbon(s,'2021年 ≥0.1 mm：6/15 92.959 mm；6/28 85.822 mm；7/29 85.634 mm')":"ribbon(s,'2021主要3次：6月15日、6月28日、7月29日\\n对应水量：92.959、85.822、85.634 mm',6.24)",
"10.65,.39,20":"10.65,.48,23",
"10.65,.53,15.3":"10.65,.61,18",
}
for a,b in changes.items():
 if a not in s:raise ValueError('Missing source: '+a)
 s=s.replace(a,b)
a=s.index('def calibration_slide():');b=s.index('def sobol_slide():',a)
s=s[:a]+'''def calibration_slide():
 s=new('多指标拟合再现四年主要生长过程','',4,'校准配对48个CC、37个生物量；年度R2由完整配对计算；原链诊断另列备答。')
 pic(s,'P04_Calibration_EN',.48,1.54,9.12,4.83)
 for y,num,label,size in [(1.87,'0.931-0.993','冠层决定系数',27),(3.30,'0.969-0.997','生物量决定系数',27),(4.73,'-4.18%至0.92%','年度产量相对偏差',22)]:
  shape(s,9.80,y-.12,2.90,1.24,WHITE,LINE,True);txt(s,num,10.00,y,2.54,.49,size,TEAL,True,font=LATIN);txt(s,label,10.00,y+.67,2.54,.41,18,MUTED)
 ribbon(s,'多指标拟合与链诊断分别报告')
 notes(s,4,'图中虚线为1:1线。决定系数区间来自各年度源表，不是合并散点OLS指标。完整原链Rhat、ESS见备答。')

''' +s[b:]
a=s.index('def backup_refs():');b=s.index('def manuscripts():',a)
s=s[:a]+'''def backup_refs():
 s=new('主要参考文献与成果入口','',4,'完整文献及DOI见随附REFERENCE_EVIDENCE.json；编号沿用当前论文。',True)
 items=[(1,'王尚今，2023','不同灌溉方式下覆膜玉米田水热氮传输及作物生长的观测与模拟','硕士论文，中国农业大学'),(3,'Steduto et al., 2009','AquaCrop: model concepts and principles','Agronomy Journal, 101, 426-437'),(4,'Kelly and Foster, 2021','AquaCrop-OSPy','Agricultural Water Management, 254'),(5,'Foreman-Mackey et al., 2013','emcee: The MCMC Hammer','PASP, 125, 306-312'),(6,'Sobol, 2001','Global sensitivity indices','Mathematics and Computers in Simulation, 55'),(8,'Deb et al., 2002','NSGA-II','IEEE Transactions on Evolutionary Computation, 6'),(9,'Deb and Jain, 2014','NSGA-III','IEEE Transactions on Evolutionary Computation, 18'),(15,'Vehtari et al., 2021','MCMC convergence diagnostics','Bayesian Analysis, 16, 667-718')]
 for i,(n,author,title,journal) in enumerate(items):
  x=.66+(i//4)*6.23;y=1.59+(i%4)*1.15
  txt(s,f'[{n}]',x,y,.53,.40,17,TEAL,True,font=LATIN);txt(s,author,x+.60,y,5.31,.36,16,INK,True);txt(s,title+'\\n'+journal,x+.60,y+.40,5.31,.70,14.5,MUTED)
 shape(s,.57,6.40,12.12,.62,PALE,rounding=True);link=txt(s,'完整论文与数据：GitHub URP',.80,6.51,11.65,.45,23,TEAL,True)
 link.text_frame.paragraphs[0].runs[0].hyperlink.address='https://github.com/yuzhenwu920-afk/URP/tree/delivery/urp-review-20261015/deliverables/2026-10-23-unified-update'
 s.notes_slide.notes_text_frame.text='备答，不计入5分钟。主要数据来源引用[1]，完整文献题名、作者和DOI在随附元数据与当前论文中保留。'

''' +s[b:]
s=s.replace("d.add_heading(s.shapes[1].text if len(s.shapes)>1 and s.shapes[1].has_text_frame else '备答',2)","d.add_heading(next(sh.text for sh in s.shapes if sh.has_text_frame and sh.text.strip()),2)")
s=s.replace(" for s in list(prs.slides)[8:]:s._element.set('show','0')",''' for s in prs.slides:
  if id(s) in SOURCE_NOTES:s.notes_slide.notes_text_frame.text+='\\n资料来源与补充说明：\\n'+SOURCE_NOTES[id(s)]
 for s in list(prs.slides)[8:]:s._element.set('show','0')''')
s=s.replace('URP_Defense_5min_20261025','URP_Defense_5min_LargeText_20261025').replace('URP_5min_Speaker_Script_20261025','URP_5min_Speaker_Script_LargeText_20261025')
p.write_text(s)

p=ROOT/'code/make_figures.py';s=p.read_text()
s=s.replace("'font.size':14,'axes.titlesize':16,'axes.labelsize':14,'xtick.labelsize':12.5,'ytick.labelsize':12.5,'legend.fontsize':12", "'font.size':16,'axes.titlesize':18,'axes.labelsize':16,'xtick.labelsize':14,'ytick.labelsize':14,'legend.fontsize':14,'axes.unicode_minus':False")
s=s.replace('t ha$^{-1}$','t/ha').replace('Total-effect index ($S_T$)','Total-effect index').replace('Four-year mean $S_T$','Four-year mean')
s=s.replace("fontsize=10.5","fontsize=13.5").replace("fontsize=11)","fontsize=14)").replace("fontsize=12)","fontsize=14)")
s=s.replace("tick_params(labelsize=12)","tick_params(labelsize=14)")
s=s.replace("label='Best-found front'","label='Front'").replace("label='DI model baseline'","label='DI baseline'").replace("label='Selected candidate'","label='Selected'").replace("label='95% observed yield'","label='95% yield'")
s=s.replace("loc='outside upper center',ncol=3,frameon=False,fontsize=13.5","loc='outside upper center',ncol=2,frameon=False,fontsize=14")
s=s.replace("'Actual seasonal irrigation (mm)'","'Irrigation (mm)'")
s=s.replace("fontsize=11,color=GRAY","fontsize=13,color=GRAY")
s=s.replace("fontsize=12);ax.text","fontsize=14);ax.text")
p.write_text(s)
print('Source revised for compatibility and larger type')
