"""Audited URP figure; run directly in PyCharm. Inputs and bootstrap rules
are recorded in audit_recompute.py. No model calibration or search is rerun.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *

begin_figure(12,'Figure_12_Irrigation_reduction_components')
plt.rcParams.update({'font.size':11.2,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10})
def main():
    d=read('Water_decomposition_recomputed.csv');scope=read('Replay_error_scope_audit.csv')
    fig,ax=plt.subplots(figsize=(9.4,4.6),layout='constrained');x=np.arange(4);bottom=np.zeros(4)
    for col,label,color,hatch in [('ET_reduction_mm','Lower ET','#E69F00',''),('Lower_final_storage_mm','Lower modelled end storage (0–2.4 m)','#56A0B9','///'),('Other_loss_reduction_mm','Lower other losses','#899A86','')]:
        vals=d[col].to_numpy();ax.bar(x,vals,bottom=bottom,width=.56,color=color,hatch=hatch,label=label,edgecolor='white',lw=.6);bottom+=vals
    for k,row in d.iterrows():
        ax.text(k,bottom[k]+8,f'$\\Delta I$ = {row.I_reduction_mm:.2f} mm',ha='center',fontsize=10.2)
        ax.text(k,row.ET_reduction_mm+row.Lower_final_storage_mm*.51,f'{row.Storage_difference_share_pct:.1f}%\nfrom end-storage difference',ha='center',va='center',fontsize=10.2,color='#183E4D',bbox=dict(facecolor='white',alpha=.84,edgecolor='none',pad=3))
    ax.set_xticks(x,YEARS);ax.set_ylabel('Reduction relative to DI baseline (mm)');ax.set_ylim(0,bottom.max()*1.18);ax.grid(axis='y');ax.set_axisbelow(True)
    handles,labels=ax.get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=2,frameon=False,fontsize=10.2)
    save(fig)
if __name__=='__main__':main()
