"""Audited URP figure; run directly in PyCharm. Inputs and bootstrap rules
are recorded in audit_recompute.py. No model calibration or search is rerun.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *

begin_figure(7,'Figure_07_Pooled_biomass_regression')
plt.rcParams.update({'font.size':11.2,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10})
def main():
    d=read('F05_Biomass_calibration_pairs.csv');metrics=read('Pooled_biomass_regression_sensitivity.csv').set_index('Subset')
    fig,axs=plt.subplots(1,2,figsize=(10.2,4.8),layout='constrained',sharex=True,sharey=True)
    for i,(ax,subset,title) in enumerate(zip(axs,['All_37_points','Without_2022_27_points'],['All four years','Excluding 2022: sensitivity check'])):
        r=metrics.loc[subset];s=d if i==0 else d[d.Year!=2022];x=np.array([0,42])
        ax.plot(x,x,ls='--',c='#82959D',lw=1);ax.plot(x,r.Intercept+r.Slope*x,c='#263E49',lw=1.5)
        for year in YEARS:
            q=s[s.Year==year];ax.scatter(q.B_observed_t_ha,q.B_simulated_t_ha,s=32,c=C[year],edgecolor='white',lw=.4,zorder=3)
        ax.text(.04,.96,f'$y$ = {r.Slope:.4f}$x$ + {r.Intercept:.4f}\nOLS $R^2$ = {r.OLS_R2:.4f}\nPearson $r$ = {r.Pearson_r:.4f}\nRMSE = {r.RMSE:.4f} t ha$^{{-1}}$\n$n$ = {int(r.N)}',transform=ax.transAxes,va='top',fontsize=10.2)
        ax.set(xlim=(0,42),ylim=(0,42),xlabel='Digitized DI biomass (t ha$^{-1}$)');panel(ax,i,title);grid(ax)
    axs[0].set_ylabel('Simulated biomass (t ha$^{-1}$)')
    handles=[Line2D([],[],marker='o',c=C[y],ls='',label=str(y))for y in YEARS]+[Line2D([],[],c='#263E49',label='OLS fit'),Line2D([],[],c='#82959D',ls='--',label='1:1 line')]
    fig.legend(handles=handles,loc='outside upper center',ncol=6,frameon=False,fontsize=10.2)
    save(fig)
if __name__=='__main__':main()
