"""Audited URP figure; run directly in PyCharm. Inputs and bootstrap rules
are recorded in audit_recompute.py. No model calibration or search is rerun.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *

begin_figure(4,'Figure_04_CC_calibration')
plt.rcParams.update({'font.size':11.2,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10})
def main():
    d=read('Calibration_daily_growth.csv');p=read('CC_LAI_to_daily_trace.csv');m=read('Table3_calibration_performance.csv').set_index('Year')
    v=read('central_vectors_with_provenance.csv').set_index('Year');cal=read('Annual_model_calendar.csv').set_index('Year')
    fig,axs=plt.subplots(2,2,figsize=(9.7,6.0),layout='constrained',sharey=True)
    for i,(ax,year) in enumerate(zip(axs.flat,YEARS)):
        s=d[d.Year==year];o=p[p.Year==year];r=m.loc[year]
        ax.plot(pd.to_datetime(s.Date),s.canopy_cover,c=C[year],lw=1.8)
        ax.scatter(pd.to_datetime(o.Date),o.CC_observed,facecolor='white',edgecolor='#243C48',s=33,zorder=4)
        onset=pd.to_datetime(cal.loc[year,'Planting_date'])+pd.Timedelta(days=float(v.loc[year,'SenescenceCD'])-1)
        ax.axvline(onset,c='#86969D',lw=.9,ls=':');late=int((o.DAP>v.loc[year,'SenescenceCD']).sum())
        ax.text(.03,.94,f'$R^2_{{cal}}$ = {r.CC_R2_cal:.4f}\nRMSE = {r.CC_RMSE:.4f}\n$n$ = {len(o)}; post-onset $n$ = {late}',transform=ax.transAxes,va='top',fontsize=10.2)
        ax.set_ylim(-.025,1.06);ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
        panel(ax,i,str(year));grid(ax)
        if i%2==0:ax.set_ylabel('Canopy cover (fraction)')
        if i>=2:ax.set_xlabel('Date')
    handles=[Line2D([],[],c='#526F7B',lw=1.8,label='Simulation'),Line2D([],[],marker='o',mfc='white',mec='#243C48',ls='',label='DI LAI-derived calibration target'),Line2D([],[],c='#86969D',ls=':',label='Configured senescence onset')]
    fig.legend(handles=handles,loc='outside upper center',ncol=3,frameon=False,fontsize=10.2)
    save(fig)
if __name__=='__main__':main()
