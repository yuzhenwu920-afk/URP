"""Audited URP figure; run directly in PyCharm. Inputs and bootstrap rules
are recorded in audit_recompute.py. No model calibration or search is rerun.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *

begin_figure(11,'Figure_11_Five_stage_Pareto_fronts')
plt.rcParams.update({'font.size':11.2,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10})
def place_labels(fig,ax,rows):
    """Deterministic collision check using the actual text rectangles."""
    fig.canvas.draw();renderer=fig.canvas.get_renderer();occupied=[]
    extent=ax.get_window_extent(renderer)
    for k,row in enumerate(rows.itertuples()):
        text='('+', '.join(str(int(round(getattr(row,f'S{j}_actual_total_mm'))))for j in range(1,6))+')'
        ann=ax.annotate(text,(row.Irrigation_mm,row.Y_13pct),xytext=(8,16),textcoords='offset points',
            fontsize=10.2,va='center',bbox=dict(boxstyle='round,pad=.16',facecolor='white',edgecolor='#A9B6BD',lw=.5,alpha=.97),
            arrowprops=dict(arrowstyle='-',color='#A4B0B7',lw=.5))
        ann.set_in_layout(False)
        candidates=[(8,-20),(8,18),(-8,18),(-8,-20),(8,-39),(-8,37),(8,37),(-8,-39),(8,-58),(-8,56),(8,56),(-8,-58)]
        for dx,dy in candidates:
            ann.set_position((dx,dy));ann.set_ha('left' if dx>0 else 'right')
            ann.update_positions(renderer);ann.update_bbox_position_size(renderer)
            box=ann.get_bbox_patch().get_window_extent(renderer).expanded(1.04,1.22)
            inside=box.x0>extent.x0+2 and box.x1<extent.x1-2 and box.y0>extent.y0+2 and box.y1<extent.y1-2
            if inside and not any(box.overlaps(previous) for previous in occupied):
                occupied.append(box);break
        else:occupied.append(box)

def main():
    front=read('Full_range_Pareto_front.csv');points=read('Pareto_display_points.csv');summary=read('Four_year_result_comparison.csv').set_index('Year');gates=read('Published_vs_internal_yield_gates.csv').set_index('Year')
    fig,axs=plt.subplots(2,2,figsize=(10.6,7.0),layout='constrained',sharey=True)
    label_rows=[]
    for i,(ax,year) in enumerate(zip(axs.flat,YEARS)):
        f=front[front.Year==year].sort_values('Irrigation_mm');p=points[points.Year==year].sort_values('Irrigation_mm');r=summary.loc[year];g=gates.loc[year]
        ax.plot(f.Irrigation_mm,f.Y_13pct,'--',c='#527DF4',lw=1.7,zorder=2)
        # Five labelled evaluated points per year; full solution rows remain in CSV.
        p=p.iloc[np.unique(np.linspace(0,len(p)-1,min(5,len(p))).round().astype(int))]
        ax.scatter(p.Irrigation_mm,p.Y_13pct,s=28,c='#D33F35',edgecolors='white',lw=.5,zorder=4)
        label_rows.append(p)
        ax.scatter(r.Original_I_mm,r.Original_Y13,marker='*',s=110,c='#245568',zorder=5)
        ax.scatter(g.Selected_I_mm,g.Selected_Y13,s=65,facecolor='white',edgecolor='#D55E00',lw=1.7,zorder=6)
        ax.axhline(g.Published_95pct_gate,c='#AE7772',ls=':',lw=1)
        ax.set_xlim(-r.Original_I_mm*.025,r.Original_I_mm*1.07);ax.set_ylim(0,20);panel(ax,i,str(year));grid(ax)
        if i%2==0:ax.set_ylabel('Grain yield at 13% moisture (t ha$^{-1}$)')
        if i>=2:ax.set_xlabel('Actual seasonal irrigation (mm)')
    handles=[Line2D([],[],ls='--',c='#527DF4',label='Full-range NSGA-III front'),Line2D([],[],marker='o',c='#D33F35',ls='',label='Labelled evaluated solutions'),Line2D([],[],marker='*',c='#245568',ls='',label='Original DI model baseline'),Line2D([],[],marker='o',mfc='white',mec='#D55E00',ls='',label='Selected formal solution'),Line2D([],[],ls=':',c='#AE7772',label='95% of published DI yield')]
    fig.legend(handles=handles,loc='outside upper center',ncol=3,frameon=False,fontsize=10.2)
    for ax,p in zip(axs.flat,label_rows):place_labels(fig,ax,p)
    save(fig)
if __name__=='__main__':main()
