"""Audited URP figure; run directly in PyCharm. Inputs and bootstrap rules
are recorded in audit_recompute.py. No model calibration or search is rerun.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *

begin_figure(3,'Figure_03_Environmental_drivers')
plt.rcParams.update({'font.size':11.2,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10})
def main():
    d=read('ETo_daily_comparison.csv');sums=read('ETo_annual_comparison.csv').set_index('Year')
    fig,axs=plt.subplots(2,2,figsize=(10.5,6.1),layout='constrained')
    pmax=d.Precipitation_mm.max()*1.17;emax=max(d.Reference_ET0_mm_d.max(),d.Uploaded_ETo_mm_d.max())*1.25
    for i,(ax,year) in enumerate(zip(axs.flat,YEARS)):
        s=d[d.Year==year];t=pd.to_datetime(s.Date);r=sums.loc[year];other=ax.twinx()
        ax.bar(t,s.Precipitation_mm,width=1.0,color='#87B7CE',alpha=.9)
        other.plot(t,s.Uploaded_ETo_mm_d,c='#7C858C',ls='--',lw=1.05)
        other.plot(t,s.Reference_ET0_mm_d,c='#D55E00',lw=1.3)
        ax.set_ylim(0,pmax);other.set_ylim(0,emax)
        ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
        panel(ax,i,str(year));ax.grid(axis='y');other.grid(False)
        ax.text(.025,.95,f'P = {r.Precipitation_mm:.2f} mm\nETo-B = {r.Used_ETo_B_mm:.2f} mm\nUploaded ETo = {r.Uploaded_ETo_mm:.2f} mm',
            transform=ax.transAxes,va='top',fontsize=10,bbox=dict(facecolor='white',alpha=.87,edgecolor='none',pad=3))
        if i%2==0:ax.set_ylabel('Precipitation (mm d$^{-1}$)')
        if i%2==1:other.set_ylabel('Reference ETo (mm d$^{-1}$)')
        if i>=2:ax.set_xlabel('Date')
    handles=[Line2D([],[],c='#87B7CE',lw=6,label='Precipitation'),Line2D([],[],c='#D55E00',lw=1.6,label='Model forcing: ETo-B'),Line2D([],[],c='#7C858C',ls='--',label='Originally uploaded ETo')]
    fig.legend(handles=handles,loc='outside upper center',ncol=3,frameon=False)
    save(fig)
if __name__=='__main__':main()
