"""Audited URP figure; run directly in PyCharm. Inputs and bootstrap rules
are recorded in audit_recompute.py. No model calibration or search is rerun.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *

begin_figure(9,'Figure_09_Sobol_four_outputs')
plt.rcParams.update({'font.size':11.2,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10})
def main():
    d=read('Sobol_annual_means_and_ranks.csv');outs=[('Y_13pct','Grain yield'),('B_t_ha','Aboveground biomass'),('ET_mm','Seasonal evapotranspiration'),('MaxCC','Maximum canopy cover')]
    fig,axs=plt.subplots(2,2,figsize=(10.6,6.5),layout='constrained')
    for i,(ax,(o,title)) in enumerate(zip(axs.flat,outs)):
        a=d[d.Output==o].pivot(index='Year',columns='Parameter',values='ST_mean').loc[YEARS,PARAMS].to_numpy()
        im=ax.imshow(a,vmin=0,vmax=1,cmap='YlGnBu',aspect='auto');ax.set_xticks(range(8),LABELS,rotation=40,ha='right',fontsize=10.2);ax.set_yticks(range(4),YEARS);panel(ax,i,title)
        for j in range(4):
            for k in range(8):ax.text(k,j,f'{a[j,k]:.3f}',ha='center',va='center',fontsize=10,color='white' if a[j,k]>.48 else '#203640')
    fig.colorbar(im,ax=list(axs.flat),location='right',fraction=.025,pad=.015,label='Total-effect Sobol index ($S_T$)')
    save(fig)
if __name__=='__main__':main()
