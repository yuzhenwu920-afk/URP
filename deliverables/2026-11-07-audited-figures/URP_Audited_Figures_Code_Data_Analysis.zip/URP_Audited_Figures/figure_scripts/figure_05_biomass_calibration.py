"""Audited URP figure; run directly in PyCharm. Inputs and bootstrap rules
are recorded in audit_recompute.py. No model calibration or search is rerun.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *

begin_figure(5,'Figure_05_Biomass_calibration')
plt.rcParams.update({'font.size':11.2,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10})
def main():
    d=read('F05_Biomass_calibration_pairs.csv');m=read('Table3_calibration_performance.csv').set_index('Year')
    fig,axs=plt.subplots(2,2,figsize=(9.3,6.4),layout='constrained',sharex=True,sharey=True)
    for i,(ax,year) in enumerate(zip(axs.flat,YEARS)):
        s=d[d.Year==year];r=m.loc[year]
        ax.plot([0,42],[0,42],ls='--',c='#88969E',lw=1)
        for row in s.itertuples():ax.plot([row.B_observed_t_ha,row.Reread_t_ha],[row.B_simulated_t_ha]*2,c='#8A9CA5',lw=.9,zorder=2)
        ax.scatter(s.B_observed_t_ha,s.B_simulated_t_ha,s=33,c=C[year],edgecolor='white',lw=.6,zorder=3)
        ax.scatter(s.Reread_t_ha,s.B_simulated_t_ha,s=30,marker='D',facecolor='none',edgecolor='#4F626B',lw=.7,zorder=4)
        ax.text(.04,.95,f'$R^2_{{cal}}$ = {r.Biomass_R2_cal:.4f}\nRMSE = {r.Biomass_RMSE_t_ha:.4f} t ha$^{{-1}}$\n$n$ = {len(s)}',transform=ax.transAxes,va='top',fontsize=10.2)
        ax.set(xlim=(0,42),ylim=(0,42));panel(ax,i,str(year));grid(ax)
        if i%2==0:ax.set_ylabel('Simulated biomass (t ha$^{-1}$)')
        if i>=2:ax.set_xlabel('Digitized DI biomass (t ha$^{-1}$)')
    handles=[Line2D([],[],ls='--',c='#88969E',label='1:1 line'),Line2D([],[],marker='o',c='#526F7B',ls='',label='Original calibration target'),Line2D([],[],marker='D',mfc='none',mec='#4F626B',ls='',label='Thesis-bar rereading')]
    fig.legend(handles=handles,loc='outside upper center',ncol=3,frameon=False,fontsize=10.2)
    save(fig)
if __name__=='__main__':main()
