"""Audited URP figure; run directly in PyCharm. Inputs and bootstrap rules
are recorded in audit_recompute.py. No model calibration or search is rerun.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *

begin_figure(10,'Figure_10_Yield_Sobol_CI')
plt.rcParams.update({'font.size':11.2,'axes.titlesize':12,'axes.labelsize':11.5,'xtick.labelsize':10,'ytick.labelsize':10})
def main():
    d=read('Yield_Sobol_seeded_percentile_CI.csv');near=read('Sobol_near_tie_paired_bootstrap.csv').set_index('Year').loc[2022]
    order=['WP_late','HI0','WP_early','Kcb','CCx','CGC_CD','SenescenceCD','CDC_CD'];labs=[dict(zip(PARAMS,LABELS))[p]for p in order]
    fig,axs=plt.subplots(1,2,figsize=(10.2,5.7),layout='constrained',sharey=True)
    for i,(ax,col) in enumerate(zip(axs,['S1','ST'])):
        for j,year in enumerate(YEARS):
            s=d[d.Year==year].set_index('Parameter').loc[order];v=s[col].to_numpy();low=s[col+'_low'].to_numpy();high=s[col+'_high'].to_numpy()
            # Percentile endpoints are drawn explicitly, even if an estimate
            # happens to fall outside its percentile interval.
            yy=np.arange(8)+(j-1.5)*.14
            ax.hlines(yy,low,high,color=C[year],lw=.9);ax.scatter(v,yy,c=C[year],s=20,label=str(year),zorder=3)
            ax.vlines(np.r_[low,high],np.r_[yy-.035,yy-.035],np.r_[yy+.035,yy+.035],color=C[year],lw=.7)
        mean=d.groupby('Parameter')[col].mean().loc[order]
        ax.scatter(mean,np.arange(8)+.36,marker='D',c='#263E49',s=23,label='Four-year descriptive mean',zorder=4)
        ax.set_yticks(range(8),labs);ax.set_ylim(7.7,-.7);ax.set_xlim(-.055,.55);ax.set_xlabel('Sobol index');ax.grid(axis='x')
        panel(ax,i,'First-order effect ($S_1$)' if col=='S1' else 'Total effect ($S_T$)')
    axs[1].text(.56,.29,'2022: WP early minus Kcb\n'+f'$\\Delta S_T$ = {near.Point_difference_WPearly_minus_Kcb:.6f}\n'+f'Paired 95% interval:\n[{near.Paired_bootstrap_difference_low:.4f}, {near.Paired_bootstrap_difference_high:.4f}]',
        transform=axs[1].transAxes,fontsize=10.2,va='center',bbox=dict(boxstyle='round,pad=.45',facecolor='#F4F7F7',edgecolor='#CCD5D8',lw=.6))
    handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside upper center',ncol=3,frameon=False,fontsize=10.2)
    save(fig)
if __name__=='__main__':main()
