"""Build the illustrated Chinese analysis, English captions and audit workbook."""
from pathlib import Path
import json
import pandas as pd
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from analysis_text import FIGURES

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'analysis';OUT.mkdir(exist_ok=True)
DER=ROOT/'outputs/derived'

def read(name):return pd.read_csv(DER/name,encoding='utf-8-sig')

def font(run,size=10.5,bold=False):
    run.font.name='Times New Roman';run.font.size=Pt(size);run.font.bold=bold
    run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'SimSun')

def para(doc,text,size=10.5,bold=False):
    p=doc.add_paragraph();p.paragraph_format.space_after=Pt(6);p.paragraph_format.line_spacing=1.25
    p.paragraph_format.widow_control=True
    r=p.add_run(text);font(r,size,bold);return p

def three_line(doc,headers,rows,width=None):
    t=doc.add_table(rows=1,cols=len(headers));t.autofit=True
    for c,text in zip(t.rows[0].cells,headers):c.text=str(text)
    for row in rows:
        for c,text in zip(t.add_row().cells,row):c.text=str(text)
    for j,row in enumerate(t.rows):
        trpr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
        if j==0:trpr.append(OxmlElement('w:tblHeader'))
        for cell in row.cells:
            tcpr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
            for side in ['top','left','bottom','right']:
                el=OxmlElement('w:'+side);el.set(qn('w:val'),'nil');borders.append(el)
            if j==0:
                for side,sz in [('top','10'),('bottom','5')]:
                    el=borders.find(qn('w:'+side));el.set(qn('w:val'),'single');el.set(qn('w:sz'),sz);el.set(qn('w:color'),'222222')
            if j==len(t.rows)-1:
                el=borders.find(qn('w:bottom'));el.set(qn('w:val'),'single');el.set(qn('w:sz'),'10')
            tcpr.append(borders)
            for p in cell.paragraphs:
                p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3)
                for r in p.runs:font(r,8.7,j==0)
    return t

def configure(d):
    s=d.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7)
    s.top_margin=s.bottom_margin=Cm(1.8);s.left_margin=s.right_margin=Cm(2.0)
    n=d.styles['Normal'];n.font.name='Times New Roman';n.font.size=Pt(10.5)
    n.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'SimSun')
    for key,sz in [('Title',19),('Heading 1',14),('Heading 2',12)]:
        st=d.styles[key];st.font.name='Times New Roman';st.font.size=Pt(sz);st.font.color.rgb=RGBColor.from_string('244A58')
        st.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'SimHei')
    footer=s.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)

def main():
    d=Document();configure(d)
    d.add_heading('URP图表核验与新版解析',0)
    para(d,'2019—2022年膜下滴灌玉米｜图3—15，图6保持原样｜2026年11月7日',10)
    d.add_heading('本次核验结果',1)
    for text in [
      '四年ETo逐日导出已找回。新代码从风速、辐射、气压和温度等分量复现模型使用的B组ETo；图3同时保留原上传序列供对照。',
      'Es的76、79、78、81 mm已在学位论文正文第39页找到明确出处；Tr另有正文第41页报告值，程序中实际采用的派生或取整目标单独列出。',
      '2022年10个生物量点的DI处理、日期、单位和像素来源已补齐。2019年两个早期点重读差超过原读数容差，已保留并列展示；没有改换原校准目标。',
      'Sobol点估计由61,440行原始响应及对应设计复算；图10用公开种子和2048次完整块bootstrap重建区间，并单独计算相近参数的差值区间。',
      '产量筛选统一使用发表的观测值。回放最大差明确区分4个主候选、8个基准及主候选、120个归档回放方案。位置图、流程图和图6不在本次改图范围。']:
        para(d,'• '+text)
    para(d,'本次运行涉及读数核对、统计复算和重绘；未重新运行MCMC或遗传搜索。新旧读数、原始文件及逐项核验记录均随代码包保存。')
    d.add_heading('ETo季节合计的统一口径',2)
    a=read('ETo_annual_comparison.csv')
    three_line(d,['Year','Days','Uploaded ETo\n(mm)','Used ETo-B\n(mm)','Difference\n(mm)','Rain\n(mm)'],
        [[int(r.Year),int(r.Days),f'{r.Uploaded_ETo_mm:.2f}',f'{r.Used_ETo_B_mm:.2f}',f'{r.Difference_mm:.2f}',f'{r.Precipitation_mm:.2f}']for r in a.itertuples()])
    para(d,'注：按模型实际执行日期统计；2019—2022年分别截至9月15日、9月18日、9月21日和9月11日。原表Calendar_cutoff为截止边界，与最后执行日分开记录。',9)
    d.add_page_break();d.add_heading('表2建议替换：文献资料与代码目标分列',1)
    a=read('Table2_Literature_and_derived_targets.csv')
    three_line(d,['Year','ET, lit.\n(mm)','Es, lit.\n(mm)','Tr, lit.\n(mm)','Tr, used\n(mm)','Y13, lit.\n(t/ha)'],
        [[int(r.Year),f'{r.ET_OBS:.2f}',f'{r.ES_TARGET:.0f}',f'{r.Tr_literature_reported_mm:.0f}',f'{r.Tr_used_in_code_mm:.2f}',f'{r.Y13_PUBLISHED:.2f}']for r in a.itertuples()])
    para(d,'lit.为原学位论文报告的DI季节数据：Es见正文第39页（PDF第49页），Tr见第41页（PDF第51页），ET和产量见表4-1、第53页（PDF第63页）。论文分别说明了微型蒸渗仪和热平衡茎流计等观测及水汽闭合处理。它们属于文献报告资料，不是URP新增观测。')
    para(d,'used为冻结校准代码中的实际目标。2019—2021年使用ET−Es，2022年使用503.00 mm；2022年ET−Es为503.11 mm。文献Tr为整数报告值，代码目标的推导和取整方式与该报告值分列，避免把相减结果作为新增独立测量。2021年灌水量还需保留细微口径差：文献表4-1为633.46 mm，原模型逐次日程之和为633.47 mm，本包灌水响应图和优化比较沿用后者。')
    d.add_heading('统计量与来源说明',2)
    para(d,'图4、5的校准R²=1−Σ(y_sim−y_target)²/Σ(y_target−平均值)²；图7的OLS R²来自含截距的回归线。配对RMSE均直接比较模拟与目标，而非回归残差。原图柱状误差棒没有确定的统计定义；本次数字化重读容差也不当作测量标准差。')
    para(d,'ETo-B按FAO-56日尺度Penman–Monteith公式计算，G=0，Δ由Tmean计算，γ=0.000665P，VPD由Tmax/Tmin饱和水汽压均值与露点实际水汽压之差形成，风速取导出Wind2m_B_ms，净辐射取Rn_ERA5_MJ。完整数值过程见audit_recompute.py。历史GEE小时提取脚本及LAI历史取点项目尚未找回，已恢复的逐日导出和LAI数值表则完整收录。')
    for n,info in FIGURES.items():
        d.add_page_break();d.add_heading(f'图{n}　{info["title"]}',1)
        image=next((ROOT/'outputs/figures').glob(f'Figure_{n:02d}_*.png'))
        p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after=Pt(4)
        p.add_run().add_picture(str(image),width=Cm(16.8))
        para(d,info['caption'],9,True)
        for text in info['paragraphs']:para(d,text)
        code=next((ROOT/'figure_scripts').glob(f'figure_{n:02d}_*.py')).name
        para(d,'对应代码：figure_scripts/'+code,8.7)
        para(d,'对应数据：'+ '；'.join(info['data']),8.7)
    d.add_page_break();d.add_heading('附录：关键核验表',1)
    d.add_heading('A1　2022年DI生物量逐点来源重读',2)
    b=read('Biomass_thesis_pixel_recheck.csv');b=b[b.Year==2022]
    three_line(d,['Date','Archived\n(t/ha)','Reread\n(t/ha)','Difference\n(t/ha)'],
        [[r.Date,f'{r.Archived_target_t_ha:.3f}',f'{r.Reread_t_ha:.3f}',f'{r.Reread_minus_archived_t_ha:+.3f}']for r in b.itertuples()])
    para(d,'全部点来自图4-8的橙色DI柱体，分类日期逐项匹配。像素记录包含渲染倍率、裁剪窗口、轴线及柱顶位置；来源图和自动重读代码均在包内。校准所用原数值保持不变。',9)
    d.add_heading('A2　四年发表值门槛与内部目标门槛',2)
    g=read('Published_vs_internal_yield_gates.csv')
    three_line(d,['Year','Published gate','Internal gate','Selected Y13','Published\nmargin','Internal\nmargin'],
        [[int(r.Year),f'{r.Published_95pct_gate:.5f}',f'{r.Internal_95pct_gate:.5f}',f'{r.Selected_Y13:.5f}',f'{r.Margin_vs_published:+.6f}',f'{r.Margin_vs_internal:+.6f}']for r in g.itertuples()])
    para(d,'单位均为t/ha；判定在取整前进行。本包统一按Published gate筛选，Internal gate仅列作口径对照。',9)
    d.add_heading('A3　回放误差的方案范围',2)
    a=read('Replay_error_scope_audit.csv')
    labels=['Four selected','Baseline + selected','All archived controls']
    three_line(d,['Scope','N','Max native difference'],[[label,int(r.N),f'{r.Maximum_native_difference:.6e}']for label,r in zip(labels,a.itertuples())])
    para(d,'原单位差比较各模型变量的自身单位，与以mm表示的逐日守恒残差分列。完整回放表包含比例剂量、前沿标注等多类方案，因此共有120行。',9)
    d.add_heading('参考文献与原始依据',2)
    for text in [
      '[1] 王尚今. 不同灌溉方式下覆膜玉米田水热氮传输及作物生长的观测与模拟[D]. 北京：中国农业大学，2023.',
      '[2] Allen R G, Pereira L S, Raes D, Smith M. Crop evapotranspiration: Guidelines for computing crop water requirements. FAO Irrigation and Drainage Paper 56. Rome: FAO, 1998.',
      '[3] Sobol’ I M. Global sensitivity indices for nonlinear mathematical models and their Monte Carlo estimates[J]. Mathematics and Computers in Simulation, 2001, 55: 271–280. DOI: 10.1016/S0378-4754(00)00270-6.',
      '[4] Saltelli A, Annoni P, Azzini I, et al. Variance based sensitivity analysis of model output. Design and estimator for the total sensitivity index[J]. Computer Physics Communications, 2010, 181: 259–270. DOI: 10.1016/j.cpc.2009.09.018.']:
        para(d,text,9)
    d.save(OUT/'URP_Figure_Analysis_and_Audit_CN.docx')
    md=['# URP新版图表解析','图6保持原样；位置图和流程图不在本次范围。']
    for n,i in FIGURES.items():
        md+=['',f'## 图{n} {i["title"]}','',i['caption'],'']+i['paragraphs']+['','变动：'+i['change'],'数据：'+'；'.join(i['data'])]
    (OUT/'Figure_Analysis_CN.md').write_text('\n\n'.join(md),encoding='utf-8')
    with pd.ExcelWriter(OUT/'Audited_Tables_and_Source_Trace.xlsx',engine='openpyxl') as writer:
        for name,sheet in [('ETo_annual_comparison.csv','ETo_annual'),('Table2_Literature_and_derived_targets.csv','Table2_sources'),('Biomass_thesis_pixel_recheck.csv','Biomass_source'),('Biomass_rereading_sensitivity.csv','Biomass_sensitivity'),('CC_LAI_to_daily_trace.csv','LAI_CC_trace'),('Table3_calibration_performance.csv','Table5_metrics'),('Pooled_biomass_regression_sensitivity.csv','Pooled_regression'),('Yield_Sobol_seeded_percentile_CI.csv','Sobol_new_CI'),('Sobol_near_tie_paired_bootstrap.csv','Sobol_near_ties'),('Published_vs_internal_yield_gates.csv','Yield_gates'),('Replay_error_scope_audit.csv','Replay_scopes'),('Water_decomposition_recomputed.csv','Water_decomposition')]:
            read(name).to_excel(writer,sheet_name=sheet,index=False)
        for ws in writer.book.worksheets:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            for col in ws.columns:
                letter=col[0].column_letter;ws.column_dimensions[letter].width=min(50,max(14,len(str(col[0].value))+2))
    print('Illustrated analysis and audit workbook written:',OUT)

if __name__=='__main__':main()
