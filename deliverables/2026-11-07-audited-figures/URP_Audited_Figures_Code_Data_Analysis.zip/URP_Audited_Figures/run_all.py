"""Run this file in PyCharm; model fitting and Figure 6 are not rerun."""
from pathlib import Path
import runpy
import os
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
os.environ.setdefault('XDG_CACHE_HOME',str(ROOT/'.cache'))
import matplotlib
import common  # Establish the same base style used by a direct figure run.
from audit_recompute import ensure_prepared
def main():
    ensure_prepared()
    for p in sorted((ROOT/'figure_scripts').glob('figure_*.py')):
        with matplotlib.rc_context():
            runpy.run_path(str(p),run_name='__main__')
    from build_report import main as build_report
    build_report()
    import fitz
    combined=fitz.open()
    for p in sorted((ROOT/'outputs/figures').glob('Figure_*.pdf')):
        with fitz.open(p) as one:combined.insert_pdf(one)
    combined.save(ROOT/'analysis/URP_Audited_Figures_EN.pdf')
    print('Complete: figures 3–15 excluding unchanged Figure 6; report and tables built.')
if __name__=='__main__':main()
