"""Rebuild audited plotting tables; no MCMC or optimization is rerun.

ETo: FAO-56 daily PM from the frozen GEE components.
Biomass: independent pixel re-reading of the cited DI bars, preserving the
actual calibration targets. The re-reading is not a second field experiment.
Sobol: original paired design/response blocks, new disclosed bootstrap seed.
Figure 6 and its MCMC intervals are deliberately outside this revision.
"""
from pathlib import Path
import hashlib, json, re
import numpy as np
import pandas as pd
import fitz

ROOT=Path(__file__).resolve().parent
DER=ROOT/'outputs/derived';AUD=ROOT/'outputs/audit'
YEARS=[2019,2020,2021,2022]
PARAMS=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
OUTPUTS=['Y_13pct','B_t_ha','Tr_mm','Es_mm','ET_mm','MaxCC']
BOOT_SEED=20261107;RESAMPLES=2048
_prepared=False;CHECKS=[]

def read(folder,name):
    return pd.read_csv(ROOT/folder/name,encoding='utf-8-sig',float_precision='round_trip')

def write(d,name):
    d.to_csv(DER/name,index=False,encoding='utf-8-sig',float_format='%.17g')

def check(name,a,b,tol=1e-9,**ctx):
    a,b=np.asarray(a,float),np.asarray(b,float)
    assert a.shape==b.shape,(name,a.shape,b.shape)
    error=float(np.max(np.abs(a-b))) if a.size else 0.
    ok=bool(np.isfinite(a).all() and np.isfinite(b).all() and error<=tol)
    CHECKS.append(dict(Check=name,Max_absolute_difference=error,Tolerance=tol,Pass=ok,**ctx))
    if not ok:raise ValueError(f'{name}: {error:g} > {tol:g}; {ctx}')

def groups(mask):
    edges=np.flatnonzero(np.diff(np.r_[False,mask,False]))
    return [(int(i),int(j)) for i,j in zip(edges[::2],edges[1::2])]

def crop_source_pages(doc):
    out=ROOT/'evidence/source_pages';out.mkdir(exist_ok=True)
    for index in [48,49,50,53,57,62]:
        doc[index].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(out/f'Thesis_PDF_page_{index+1}.png')
    (out/'Es_source_verbatim.txt').write_text(doc[48].get_text(),encoding='utf-8')

def reread_biomass_bars(doc,pairs):
    """Bar border centers, not error-bar caps; 50,000 kg/ha axis => 50 t/ha.

    Figure 4-8 has categorical dates. Match the exact selected dates explicitly
    against their labels, rather than deriving dates from equally spaced bars.
    Retain tiny early bars outside the calibration subset in the original PDF.
    """
    results=[];scale=6
    # Approximate windows only locate each panel; exact axis lines are detected.
    limits={2019:(149,270),2020:(274,395),2021:(398,518),2022:(520,648)}
    for year in YEARS:
        ylo,yhi=limits[year];clip=fitz.Rect(160,ylo,500,yhi)
        pix=doc[57].get_pixmap(matrix=fitz.Matrix(scale,scale),clip=clip,alpha=False)
        image=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,3)
        pix.save(ROOT/f'evidence/source_pages/Fig4_8_DI_{year}_6x.png')
        black=image.max(2)<100
        xa,xb=int((174-160)*scale),int((489-160)*scale)
        horizontal=black[:,xa:xb].sum(1)>(xb-xa)*.7
        lines=groups(horizontal)
        # Two full-width frame lines bound each panel.
        assert len(lines)==2,(year,lines)
        top=np.mean(np.arange(*lines[0]));zero=np.mean(np.arange(*lines[1]))
        a=image.astype(float)
        orange=(a[:,:,0]>220)&(a[:,:,1]>140)&(a[:,:,1]<215)&(a[:,:,2]>90)&(a[:,:,2]<175)&((a[:,:,0]-a[:,:,1])>25)
        orange[:int(top)+2]=False;orange[int(zero)-2:]=False
        if year==2019:orange[:int(top+150)]=False # exclude orange legend swatch
        spans=[s for s in groups(orange.sum(0)>0) if s[1]-s[0]>15]
        merged=[]
        for x0,x1 in spans:
            if merged and x0-merged[-1][1]<40:merged[-1]=(merged[-1][0],x1)
            else:merged.append((x0,x1))
        selected=pairs[pairs.Year==year].sort_values('Date')
        spans=merged[-len(selected):]
        assert len(spans)==len(selected),(year,spans)
        for (x0,x1),r in zip(spans,selected.itertuples()):
            rows=np.flatnonzero(orange[:,x0:x1].sum(1)>(x1-x0)*.35)
            fill_top=int(rows[0]);mid=(x0+x1)//2
            xs=np.r_[np.arange(x0+5,mid-5),np.arange(mid+5,x1-5)]
            counts=black[max(0,fill_top-10):fill_top+3,xs].mean(1)
            line=np.flatnonzero(counts>.6)+max(0,fill_top-10)
            if not len(line):raise ValueError(f'No bar top border for {year} {r.Date}')
            bar_top=float(line.mean())
            value=50*(zero-bar_top)/(zero-top)
            delta=value-r.B_observed_t_ha
            # 0.3 t/ha was already the reading allowance in the older records;
            # this is a digitization cross-check, not an observed SD.
            results.append(dict(Year=year,Date=r.Date,Treatment='DI',
                Archived_target_t_ha=r.B_observed_t_ha,Reread_t_ha=value,
                Reread_minus_archived_t_ha=delta,Recheck_tolerance_t_ha=.3,
                Within_digitization_allowance=bool(abs(delta)<=.3),
                Source_pdf='evidence/Wang_2023_Thesis.pdf',PDF_page=58,Printed_page=48,Figure='4-8',
                Panel=f'{"abcd"[YEARS.index(year)]}-{year}',Treatment_color='orange DI (legend checked)',
                Y_axis_units='kg ha-1',Conversion_to_t_ha='divide by 1000',
                Render_scale=scale,Crop_x0_pdf_pt=160,Crop_y0_pdf_pt=ylo,
                Axis_top_px=top,Axis_zero_px=zero,Bar_top_px=bar_top,ROI_x0_px=x0,ROI_x1_px=x1,
                Date_basis='category date label in thesis; not interpolated on a continuous date axis',
                Value_role='original digitized calibration target retained; rereading is a source cross-check',
                Error_bar_role='not interpreted as measured SD; original definition unconfirmed'))
    result=pd.DataFrame(results);write(result,'Biomass_thesis_pixel_recheck.csv')
    checked=pairs.merge(result,on=['Year','Date'],validate='one_to_one',suffixes=('','_recheck'))
    checked['Treatment']='DI';checked['Included']=True
    checked['Source']='Wang (2023), Fig 4-8, PDF p58 / printed p48; orange DI; independently re-read 2026-11-07'
    checked['Status']=np.where(checked.Within_digitization_allowance,
        'digitized calibration target; thesis rereading within 0.3 t/ha allowance',
        'digitized calibration target; thesis rereading exceeds 0.3 t/ha allowance; retained and flagged')
    write(checked,'F05_Biomass_calibration_pairs.csv')

def pm_eto(d,wind,net='Rn_ERA5_MJ'):
    t=d.Tmean_C.to_numpy();u=d[wind].to_numpy();rn=d[net].to_numpy()
    delta=4098*.6108*np.exp(17.27*t/(t+237.3))/(t+237.3)**2
    gamma=.000665*d.Pressure_kPa.to_numpy()
    return (.408*delta*rn+gamma*900/(t+273)*u*d.VPD_raw_kPa.to_numpy())/(delta+gamma*(1+.34*u))

def eto_and_target_audit(doc):
    env=read('data/paper','Environmental_drivers_used.csv');daily=[];annual=[];targets=[]
    assert all(str(v) in doc[48].get_text() for v in [76,79,78,81])
    for year in YEARS:
        folder=ROOT/f'source/model_inputs/{year}'
        export=pd.read_csv(next(folder.glob('ETO_FILE*')),float_precision='round_trip')
        etob=np.maximum(pm_eto(export,'Wind2m_B_ms'),0)
        etoa=np.maximum(pm_eto(export,'Wind2m_A_ms'),0)
        check('FAO56 ETo B reconstruction from archived components',etob,export.ETo_B_mm,1e-11,Year=year)
        check('FAO56 ETo A reconstruction from archived components',etoa,export.ETo_A_mm,1e-11,Year=year)
        es=.6108*(np.exp(17.27*export.Tmax_C/(export.Tmax_C+237.3))+np.exp(17.27*export.Tmin_C/(export.Tmin_C+237.3)))/2
        ea=.6108*np.exp(17.27*export.Tdew_C/(export.Tdew_C+237.3))
        check('VPD from Tmax Tmin and dewpoint',es-ea,export.VPD_raw_kPa,1e-11,Year=year)
        export['PM_recomputed_B_mm']=etob
        if year==2022:
            check('Optional ETo C reconstruction (not used by model)',np.maximum(pm_eto(export,'Wind2m_B_ms','Rn_reference_MJ'),0),export.ETo_C_mm,1e-11,Year=year)
        s=env[env.Year==year].merge(export,on='Date',validate='one_to_one')
        raw=read('data/observations',f'Climate_{year}.csv')
        date='Date' if 'Date' in raw else 'date'
        raw=raw.rename(columns={date:'Date','ETo_mm':'Uploaded_ETo_mm_d','Precip_mm':'Uploaded_Precip_mm'})
        s=s.merge(raw[['Date','Uploaded_ETo_mm_d','Uploaded_Precip_mm']],on='Date',validate='one_to_one')
        check('Actual forcing uses ETo B on every executed date',s.Reference_ET0_mm_d,s.ETo_B_mm,1e-11,Year=year)
        check('Precipitation agrees with uploaded climate on same dates',s.Precipitation_mm,s.Uploaded_Precip_mm,1e-11,Year=year)
        s['Year']=year;s['Model_minus_uploaded_ETo_mm_d']=s.Reference_ET0_mm_d-s.Uploaded_ETo_mm_d
        daily.append(s)
        annual.append(dict(Year=year,First_executed_date=s.Date.min(),Last_executed_date=s.Date.max(),Days=len(s),
            Precipitation_mm=s.Precipitation_mm.sum(),Uploaded_ETo_mm=s.Uploaded_ETo_mm_d.sum(),
            Used_ETo_B_mm=s.Reference_ET0_mm_d.sum(),Difference_mm=s.Model_minus_uploaded_ETo_mm_d.sum(),
            Max_B_reconstruction_error_mm_d=np.max(np.abs(s.Reference_ET0_mm_d-s.PM_recomputed_B_mm)),
            Uploaded_vs_export_A_max_difference_mm_d=np.max(np.abs(s.Uploaded_ETo_mm_d-s.ETo_A_mm)),
            Day_basis=export.Day_basis.iloc[0],Latitude=export.Latitude.iloc[0],Longitude=export.Longitude.iloc[0]))
        source=(ROOT/f'source/original_code/DI_{year}_MCMC_ONE_CLICK.py').read_text(encoding='utf-8-sig')
        vals={k:float(re.search(r'^'+k+r'\s*=\s*([0-9.]+)',source,re.M)[1]) for k in ['ET_OBS','ES_TARGET','Y13_PUBLISHED','Y13_TARGET']}
        tr=503.0 if year==2022 else vals['ET_OBS']-vals['ES_TARGET']
        targets.append(dict(Year=year,**vals,Tr_literature_reported_mm=dict(zip(YEARS,[586.,558.,549.,503.]))[year],
            Tr_by_ET_minus_Es_mm=vals['ET_OBS']-vals['ES_TARGET'],Tr_used_in_code_mm=tr,
            Published_I_table4_1_mm=dict(zip(YEARS,[445.27,559.76,633.46,404.84]))[year],
            Es_source='Wang (2023), section 3.3.2, printed p39 / PDF p49; reported DI seasonal soil evaporation',
            ET_yield_source='Wang (2023), Table 4-1, printed p53 / PDF p63',
            Tr_role='literature rounded totals at printed p41 / PDF p51; 2019-2021 code uses ET minus Es, 2022 code uses 503.0 mm',
            Es_role='literature-reported seasonal observation, not a new independent measurement by URP'))
    write(pd.concat(daily,ignore_index=True),'ETo_daily_comparison.csv');write(pd.DataFrame(annual),'ETo_annual_comparison.csv')
    write(pd.DataFrame(targets),'Table2_Literature_and_derived_targets.csv')
    return pd.DataFrame(targets).set_index('Year')

def metrics(x,y):
    x=np.asarray(x);y=np.asarray(y);e=y-x
    return 1-np.sum(e*e)/np.sum((x-x.mean())**2),np.sqrt(np.mean(e*e))

def calibration_audit(doc,targets):
    b=read('data/paper','F05_Biomass_calibration_pairs.csv');reread_biomass_bars(doc,b)
    cc=read('data/paper','F02_CC_calibration_pairs.csv');daily=read('data/paper','Calibration_daily_growth.csv')
    lai=pd.read_csv(next((ROOT/'source/model_inputs/2022').glob('FIELD_CC*')),float_precision='round_trip')
    check('All archived LAI rows belong to DI', (lai.Irrigation=='DI').to_numpy(int),np.ones(len(lai)),0)
    lai['Recomputed_CC']=1.005*(1-np.exp(-.6*lai.LAI))**1.2
    check('LAI to CC equation',lai.Field_CC,lai.Recomputed_CC,1e-12)
    trace=cc.merge(lai[['Year','Date','LAI','Field_CC','Recomputed_CC','Irrigation','LAI_Source']],on=['Year','Date'],validate='one_to_one')
    check('Each CC pair matches recovered DI LAI table',trace.CC_observed,trace.Recomputed_CC,1e-12)
    trace['Source_figure']='Wang (2023) Fig4-1; printed p44 / PDF p54'
    trace['Digitization_project_status']='original LAI table recovered; historical pixel/project file not preserved'
    trace['Role']='LAI-derived digitized calibration target, not independent validation'
    write(trace,'CC_LAI_to_daily_trace.csv')
    fit=[]
    for year in YEARS:
        g=daily[daily.Year==year].set_index('Date');c=cc[cc.Year==year];a=b[b.Year==year]
        check('CC daily pairing',c.CC_simulated,g.loc[c.Date,'canopy_cover'],1e-11,Year=year)
        check('Biomass daily pairing',a.B_simulated_t_ha,g.loc[a.Date,'biomass']/100,1e-11,Year=year)
        c2,ce=metrics(c.CC_observed,c.CC_simulated);b2,be=metrics(a.B_observed_t_ha,a.B_simulated_t_ha)
        fit.append(dict(Year=year,CC_N=len(c),CC_R2_cal=c2,CC_RMSE=ce,Biomass_N=len(a),Biomass_R2_cal=b2,Biomass_RMSE_t_ha=be))
    old=read('data/paper','Table3_calibration_performance.csv')
    new=old.merge(pd.DataFrame(fit),on='Year',suffixes=('_archived',''))
    for col in ['CC_R2_cal','CC_RMSE','Biomass_R2_cal','Biomass_RMSE_t_ha']:
        check('Table5 recalculated '+col,new[col],new[col+'_archived'],1e-12)
    write(new,'Table3_calibration_performance.csv')
    regs=[]
    for name,sub in [('All_37_points',b),('Without_2022_27_points',b[b.Year!=2022])]:
        x=sub.B_observed_t_ha.to_numpy();y=sub.B_simulated_t_ha.to_numpy()
        slope=np.dot(x-x.mean(),y-y.mean())/np.sum((x-x.mean())**2);intercept=y.mean()-slope*x.mean();r=np.corrcoef(x,y)[0,1]
        regs.append(dict(Subset=name,N=len(x),Slope=slope,Intercept=intercept,OLS_R2=r*r,Pearson_r=r,RMSE=np.sqrt(np.mean((x-y)**2))))
    write(pd.DataFrame(regs),'Pooled_biomass_regression_sensitivity.csv')
    fresh=read('outputs/derived','Biomass_thesis_pixel_recheck.csv').merge(b[['Year','Date','B_simulated_t_ha']],on=['Year','Date'],validate='one_to_one')
    rows=[]
    for year,s in fresh.groupby('Year'):
        r2,rmse=metrics(s.Reread_t_ha,s.B_simulated_t_ha)
        rows.append(dict(Year=year,N=len(s),Reread_R2_with_frozen_simulation=r2,Reread_RMSE_t_ha=rmse,
            Maximum_reading_difference_t_ha=s.Reread_minus_archived_t_ha.abs().max(),Outside_0p3_allowance=int((~s.Within_digitization_allowance).sum()),
            Role='source-reading sensitivity using the existing simulation; no calibration refit'))
    write(pd.DataFrame(rows),'Biomass_rereading_sensitivity.csv')

def sobol_audit():
    seed_rows=[];ci_rows=[];near=[]
    old=read('data/paper','Sobol_annual_means_and_ranks.csv')
    draws_path=ROOT/'outputs/audit/bootstrap_draws';draws_path.mkdir(exist_ok=True)
    for year in YEARS:
        rng=np.random.default_rng(BOOT_SEED+year);bootstrap=[]
        for seed in [101,202,303]:
            folder=ROOT/f'data/sobol/{year}_seed{seed}'
            design=np.load(folder/'design.npy',allow_pickle=False);response=np.load(folder/'response_matrix.npy',allow_pickle=False)
            assert design.shape==(5120,8) and response.shape==(5120,6)
            assert np.isfinite(design).all() and np.isfinite(response).all()
            spec=json.loads((folder/'space.json').read_text());bounds=np.asarray(spec['bounds'])
            assert np.all(design>=bounds[:,0]) and np.all(design<=bounds[:,1])
            x=design.reshape(512,10,8)
            for k in range(8):
                expected=x[:,0,:].copy();expected[:,k]=x[:,-1,k]
                check('Saltelli A/B hybrid block',x[:,k+1,:],expected,1e-12,Year=year,Seed=seed,Parameter=PARAMS[k])
            archived=pd.read_csv(folder/'indices.csv').set_index(['Output','Parameter'])
            for j,output in enumerate(OUTPUTS):
                y=(response[:,j]-response[:,j].mean())/response[:,j].std()
                a,b=y[::10],y[9::10];ab=np.column_stack([y[(k+1)::10] for k in range(8)])
                variance=np.var(np.r_[a,b]);s1=np.mean(b[:,None]*(ab-a[:,None]),axis=0)/variance
                st=.5*np.mean((a[:,None]-ab)**2,axis=0)/variance
                check('Sobol S1/ST from raw responses',np.c_[s1,st],archived.loc[[(output,p)for p in PARAMS],['S1','ST']],1e-11,Year=year,Seed=seed,Output=output)
                seed_rows.extend(dict(Year=year,Seed=seed,Output=output,Parameter=p,S1=s1[k],ST=st[k])for k,p in enumerate(PARAMS))
                if output=='Y_13pct':
                    ids=rng.integers(0,len(a),size=(RESAMPLES,len(a)))
                    aa,bb,xx=a[ids],b[ids],ab[ids]
                    v=np.var(np.concatenate([aa,bb],axis=1),axis=1)
                    first=np.mean(bb[:,:,None]*(xx-aa[:,:,None]),axis=1)/v[:,None]
                    total=.5*np.mean((aa[:,:,None]-xx)**2,axis=1)/v[:,None]
                    bootstrap.append(np.stack([first,total],axis=1))
        draws=np.mean(bootstrap,axis=0) # independently resample within each scramble; equal weights
        np.savez_compressed(draws_path/f'{year}_yield_bootstrap.npz',draws=draws,seed=np.asarray(BOOT_SEED+year),resamples=np.asarray(RESAMPLES))
        lo,hi=np.quantile(draws,[.025,.975],axis=0)
        annual=pd.DataFrame(seed_rows);annual=annual[(annual.Year==year)&(annual.Output=='Y_13pct')].groupby('Parameter')[['S1','ST']].mean()
        for k,p in enumerate(PARAMS):
            ci_rows.append(dict(Year=year,Parameter=p,S1=annual.loc[p,'S1'],ST=annual.loc[p,'ST'],
                S1_low=lo[0,k],S1_high=hi[0,k],ST_low=lo[1,k],ST_high=hi[1,k],
                Bootstrap_seed=BOOT_SEED+year,Resamples=RESAMPLES,Interval='percentile 95%; paired response blocks'))
        diff=draws[:,1,PARAMS.index('WP_early')]-draws[:,1,PARAMS.index('Kcb')]
        near.append(dict(Year=year,Point_difference_WPearly_minus_Kcb=annual.loc['WP_early','ST']-annual.loc['Kcb','ST'],
            Paired_bootstrap_difference_low=np.quantile(diff,.025),Paired_bootstrap_difference_high=np.quantile(diff,.975),
            Bootstrap_fraction_difference_positive=np.mean(diff>0),Interpretation='numerical resampling frequency, not a field probability or a significance p-value'))
    seeds=pd.DataFrame(seed_rows);write(seeds,'Sobol_recomputed_seed_indices.csv')
    annual=seeds.groupby(['Year','Output','Parameter'],as_index=False).agg(S1_mean=('S1','mean'),ST_mean=('ST','mean'))
    check('Annual Sobol point means',annual.set_index(['Year','Output','Parameter']).sort_index()[['S1_mean','ST_mean']],old.set_index(['Year','Output','Parameter']).sort_index()[['S1_mean','ST_mean']],1e-11)
    annual['ST_rank']=annual.groupby(['Year','Output']).ST_mean.rank(ascending=False,method='min')
    write(annual,'Sobol_annual_means_and_ranks.csv');write(pd.DataFrame(ci_rows),'Yield_Sobol_seeded_percentile_CI.csv');write(pd.DataFrame(near),'Sobol_near_tie_paired_bootstrap.csv')
    four=annual.groupby(['Output','Parameter'],as_index=False).agg(S1_mean=('S1_mean','mean'),ST_mean=('ST_mean','mean'),ST_min=('ST_mean','min'),ST_max=('ST_mean','max'))
    write(four,'Sobol_four_year_means.csv')

def optimization_audit(targets):
    selected=read('data/optimization','Selected_95pct_candidates.csv');gate=[];water=[];decomp=[];budgets=[]
    slots=read('data/optimization','All_selected_schedule_slots.csv')
    stage=slots.groupby(['Year','Control_ID','Stage','Stage_name'],as_index=False).agg(
        Planned_mm=('Planned_mm','sum'),Actual_mm=('Actual_mm','sum'),Positive_events=('Actual_mm',lambda x:int((x>0).sum())),Events_ge_0p1mm=('Actual_mm',lambda x:int((x>=.1).sum())))
    assert (stage.Positive_events<=3).all()
    for r in slots.itertuples():assert r.Eligible_window_start<=r.Date<=r.Eligible_window_end
    oldstage=read('data/optimization','Five_stage_totals_and_event_counts.csv');keys=['Year','Control_ID','Stage'];cols=['Planned_mm','Actual_mm','Positive_events','Events_ge_0p1mm']
    check('Figure14 stage totals and event counts',stage.set_index(keys).sort_index()[cols],oldstage.set_index(keys).sort_index()[cols],1e-10)
    write(stage,'Five_stage_totals_and_event_counts.csv')
    events=slots[(slots.Control_ID=='Selected_95pct')&(slots.Actual_mm>0)].sort_values(['Year','Date'])
    assert len(events)==42
    write(events,'Optimized_every_irrigation_event.csv')
    formal=read('data/optimization','Formal_final_population_fronts.csv')
    for year in YEARS:
        a=selected[selected.Year==year].iloc[0];t=targets.loc[year]
        pubgate=.95*t.Y13_PUBLISHED;internal=.95*t.Y13_TARGET
        assert a.Y_13pct>=pubgate
        gate.append(dict(Year=year,Published_yield=t.Y13_PUBLISHED,Internal_yield_target=t.Y13_TARGET,
            Published_95pct_gate=pubgate,Internal_95pct_gate=internal,Selected_Y13=a.Y_13pct,
            Selected_I_mm=a.Irrigation_mm,Margin_vs_published=a.Y_13pct-pubgate,Margin_vs_internal=a.Y_13pct-internal,
            Pass_published_gate=bool(a.Y_13pct>=pubgate),Pass_internal_gate=bool(a.Y_13pct>=internal)))
        # The formal saved feasible front should use the same published gate.
        f=formal[formal.Year==year]
        assert (f.Y_13pct>=pubgate-1e-10).all()
        scenarios={}
        for tag in ['Original_DI','Selected_95pct']:
            w=read('data/optimization',f'{year}_{tag}_daily_water.csv')
            evap=w.Tr.sum()+w.Es.sum();loss=w.Runoff.sum()+w.DeepPerc.sum()+w.TileDrain.sum()
            initial=w.Profile_initial_of_day_mm.iloc[0];end=w.Profile_final_of_day_mm.iloc[-1]
            ds=end-initial+w.surface_storage.iloc[-1]
            balance=(w.Precipitation+w.IrrDay+w.CR+w.GwIn-w.Tr-w.Es-w.Runoff-w.DeepPerc-w.TileDrain).to_numpy()-np.diff(np.r_[initial,w.Profile_final_of_day_mm.to_numpy()])-np.diff(np.r_[0.,w.surface_storage.to_numpy()])
            check('Daily water balance',balance,np.zeros(len(balance)),1e-8,Year=year,Scenario=tag)
            check('Seasonal water balance',w.IrrDay.sum()+w.Precipitation.sum()+w.CR.sum()+w.GwIn.sum(),evap+loss+ds,1e-8,Year=year,Scenario=tag)
            row=dict(Year=year,Scenario=tag,Irrigation_mm=w.IrrDay.sum(),ET_mm=evap,Loss_mm=loss,
                Initial_storage_mm=initial,End_storage_mm=end,Daily_balance_max_mm=np.abs(balance).max())
            water.append(row);scenarios[tag]=row
            if tag=='Original_DI':
                budgets.append(dict(Year=year,Inflow_mm=w.IrrDay.sum()+w.Precipitation.sum()+w.CR.sum()+w.GwIn.sum(),Outflow_mm=evap+loss,Storage_change_mm=ds,Evapotranspiration_mm=evap))
            else:
                e=events[events.Year==year].groupby('Date').Actual_mm.sum()
                check('Figure13 each executed event date and depth',e,w.set_index('Date').loc[e.index,'IrrDay'],1e-8,Year=year)
                check('Figure13 event sums equal model seasonal irrigation',e.sum(),w.IrrDay.sum(),1e-8,Year=year)
        b,o=scenarios['Original_DI'],scenarios['Selected_95pct'];di=b['Irrigation_mm']-o['Irrigation_mm'];det=b['ET_mm']-o['ET_mm'];ds=b['End_storage_mm']-o['End_storage_mm'];dl=b['Loss_mm']-o['Loss_mm']
        check('Irrigation reduction decomposition',di,det+ds+dl,1e-8,Year=year)
        decomp.append(dict(Year=year,I_reduction_mm=di,ET_reduction_mm=det,Lower_final_storage_mm=ds,Other_loss_reduction_mm=dl,Storage_difference_share_pct=100*ds/di,ET_reduction_pct=100*det/b['ET_mm']))
    write(pd.DataFrame(gate),'Published_vs_internal_yield_gates.csv');write(pd.DataFrame(water),'Daily_water_recomputed_summary.csv');write(pd.DataFrame(decomp),'Water_decomposition_recomputed.csv')
    budget=pd.DataFrame(budgets);cols=['Inflow_mm','Outflow_mm','Storage_change_mm','Evapotranspiration_mm']
    check('Figure8 annual water budgets',budget[cols],read('data/paper','F09_annual_water_budget.csv')[cols],1e-8)
    write(budget,'F09_annual_water_budget.csv')
    # Independently reconstruct final-generation and final-union hypervolumes.
    def nd(d):
        d=d.sort_values(['Irrigation_mm','Y_13pct'],ascending=[True,False]).drop_duplicates(['Irrigation_mm','Y_13pct'])
        keep=[];best=-np.inf
        for i,r in d.iterrows():
            if r.Y_13pct>best:keep.append(i);best=r.Y_13pct
        return d.loc[keep]
    def hv(d,obs,cap):
        p=1.01;value=0.
        for r in nd(d).sort_values('Y_13pct',ascending=False).itertuples():
            x=r.Irrigation_mm/cap
            if x<p:value+=(p-x)*r.Y_13pct/obs;p=x
        return value
    algo=read('data/optimization','Algorithm_comparison.csv').set_index(['Year','Algorithm'])
    history=read('data/optimization','Generation_history.csv');history=history[history.Scope=='formal'];assert len(history)==4000
    caps=read('data/optimization','Four_year_result_comparison.csv').set_index('Year')
    for (year,algorithm),s in formal.groupby(['Year','Algorithm']):
        obs=targets.loc[year,'Y13_PUBLISHED'];cap=caps.loc[year,'Original_I_mm']
        check('Algorithm union hypervolume and minimum irrigation',[hv(s,obs,cap),s.Irrigation_mm.min()],algo.loc[(year,algorithm),['Normalized_union_HV','Minimum_I_mm']],1e-10,Year=year,Algorithm=algorithm)
        for seed,z in s.groupby('Seed'):
            last=history[(history.Year==year)&(history.Algorithm==algorithm)&(history.Seed==seed)&(history.Generation==100)]
            check('Figure15 generation100 hypervolume reconstructed',np.asarray([hv(z,obs,cap)]),last.Hypervolume.to_numpy(),1e-10,Year=year,Algorithm=algorithm,Seed=int(seed))
    replay=read('data/optimization','Selected_full_adapter_replay_checks.csv')
    rows=[]
    for label,sub in [('Four_selected_candidates',replay[replay.Control_ID=='Selected_95pct']),
                      ('Eight_baseline_and_selected_controls',replay[replay.Control_ID.isin(['Original_DI','Selected_95pct'])]),
                      ('All_archived_replayed_controls',replay)]:
        rows.append(dict(Scope=label,N=len(sub),Maximum_native_difference=sub.Maximum_native_difference.max(),Maximum_daily_balance_residual_mm=sub.Daily_balance_max_mm.max(),Unit_note='native difference compares model variables in their own units; water-balance residual is in mm'))
    write(pd.DataFrame(rows),'Replay_error_scope_audit.csv')

def ensure_prepared():
    global _prepared
    if _prepared:return
    DER.mkdir(parents=True,exist_ok=True);AUD.mkdir(parents=True,exist_ok=True)
    hashes=json.loads((ROOT/'INPUT_SHA256.json').read_text(encoding='utf-8'))
    for path,want in hashes.items():
        actual=hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
        if actual!=want:raise ValueError('Source checksum changed: '+path)
    doc=fitz.open(ROOT/'evidence/Wang_2023_Thesis.pdf');crop_source_pages(doc)
    target=eto_and_target_audit(doc);calibration_audit(doc,target);sobol_audit();optimization_audit(target)
    pixels=read('outputs/derived','Biomass_thesis_pixel_recheck.csv')
    (AUD/'NUMERICAL_AUDIT.json').write_text(json.dumps(dict(Status='PASS: numerical reconstruction; source-reading flags reported separately',Checks=CHECKS,Source_files_verified=len(hashes),
        Digitization_flags=pixels[~pixels.Within_digitization_allowance][['Year','Date','Archived_target_t_ha','Reread_t_ha','Reread_minus_archived_t_ha']].to_dict('records'),
        MCMC_rerun=False,Optimization_rerun=False,Figure6_unchanged=True,
        Bootstrap=dict(Seed_rule='20261107 + year',Resamples=RESAMPLES,Interval='2.5/97.5 percentile',Paired_blocks=True,Replaces_historical_plot_intervals=True)),ensure_ascii=False,indent=2,
        default=lambda x:x.item() if isinstance(x,np.generic) else str(x)),encoding='utf-8')
    _prepared=True
    print('Audited source chain and derived statistics complete:',len(CHECKS),'checks',flush=True)

if __name__=='__main__':ensure_prepared()
