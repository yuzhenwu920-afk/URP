"""Shared deterministic styling, paths, bundled fonts and figure provenance.

Do not put model values here. Each figure reads its named numerical inputs.
"""
from pathlib import Path
import os
import sys
import json
import string
import locale
import hashlib
import platform
ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.cache/matplotlib'))
os.environ.setdefault('XDG_CACHE_HOME', str(ROOT / '.cache'))
os.environ.setdefault('MPLBACKEND', 'Agg')
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
try:
    locale.setlocale(locale.LC_TIME, 'C')
except locale.Error:
    pass

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon, Rectangle, Patch
from matplotlib.lines import Line2D

# Prefer only the packaged DejaVu Sans faces, even on a computer with a
# different DejaVu release installed. The pinned Matplotlib font files are
# copied into assets/fonts, so the chosen face is independent of font search.
font_manager.fontManager.ttflist = [
    f for f in font_manager.fontManager.ttflist if f.name != 'DejaVu Sans'
]
for font in sorted((ROOT / 'assets/fonts').glob('*.ttf')):
    font_manager.fontManager.addfont(str(font))

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 10,
    'axes.titlesize': 11, 'axes.labelsize': 10,
    'xtick.labelsize': 9, 'ytick.labelsize': 9, 'legend.fontsize': 9,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.linewidth': .8, 'grid.alpha': .23, 'grid.color': '#AFBBC3',
    'pdf.fonttype': 42, 'svg.fonttype': 'path', 'svg.hashsalt': 'URP-audit-20261107',
    'mathtext.fontset': 'dejavusans', 'hatch.linewidth': .25,
    'savefig.dpi': 450, 'figure.dpi': 100,
})

YEARS = [2019, 2020, 2021, 2022]
COLORS = ['#0072B2', '#D55E00', '#009E73', '#AA4499']
C = YEAR_COLORS = dict(zip(YEARS, COLORS))
PARAMS = ['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
LABELS = ['CCx','CGC','CDC','Senescence','Kcb','WP early','WP late','HI0']
STAGE_COLORS = ['#8DA0CB','#0072B2','#E69F00','#009E73','#AA4499']
SHORT = ['Seedling','Jointing','Heading','Grain filling','Maturity']
OUT = ROOT / 'outputs/figures'
TB = ROOT / 'data/paper'
_current = None
_used = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def begin_figure(number, stem):
    global _current, _used
    from audit_recompute import ensure_prepared
    ensure_prepared()
    _current = (number, stem)
    _used = {}
    if number == 2:
        p = ROOT / 'assets/china_provinces_context.geojson'
        _used[str(p.relative_to(ROOT))] = dict(sha256=sha(p), role='locator geometries')
    OUT.mkdir(parents=True, exist_ok=True)


def read(name):
    # Recomputed tables take precedence over the unchanged archive tables.
    for folder in [ROOT/'outputs/derived', ROOT/'data/paper', ROOT/'data/optimization']:
        p = folder / name
        if p.exists():
            d = pd.read_csv(p, encoding='utf-8-sig', float_precision='round_trip')
            _used[str(p.relative_to(ROOT))] = dict(sha256=sha(p), rows=len(d), columns=list(d.columns))
            return d
    raise FileNotFoundError('Missing verified input: ' + name)


def panel(ax, i, title):
    ax.set_title(f'({string.ascii_lowercase[i]}) {title}', loc='left', weight='bold', pad=8)


def grid(ax):
    ax.grid(True, axis='both', zorder=0)
    ax.set_axisbelow(True)


def save(fig, legacy_name=None):
    if _current is None:
        raise RuntimeError('Call begin_figure before saving.')
    number, stem = _current
    for ext in ['png', 'pdf', 'svg']:
        metadata = {'Software': 'URP audited figure revision 20261107'} if ext == 'png' else (
            {'Creator': 'URP reproducible plotting', 'CreationDate': None, 'ModDate': None}
            if ext == 'pdf' else {'Creator': 'URP reproducible plotting', 'Date': None})
        fig.savefig(OUT/(stem+'.'+ext), dpi=450, bbox_inches='tight',
                    facecolor='white', metadata=metadata)
    from PIL import Image
    with Image.open(OUT/(stem+'.png')) as image:
        pixels = hashlib.sha256(image.convert('RGBA').tobytes()).hexdigest()
        dimensions = list(image.size)
    record = dict(Figure=number, File=stem, Inputs=_used,
                  PNG_pixel_sha256=pixels, Dimensions=dimensions,
                  Python=platform.python_version(), Matplotlib=matplotlib.__version__,
                  NumPy=np.__version__, Platform=platform.platform(),
                  Rendering='Matplotlib Agg; bundled DejaVu Sans; no input PNG used for drawing')
    script = next((ROOT/'figure_scripts').glob(f'figure_{number:02d}_*.py'))
    record['Script'] = str(script.relative_to(ROOT))
    record['Script_SHA256'] = sha(script)
    record['Common_style_SHA256'] = sha(ROOT/'common.py')
    record['Numerical_reconstruction_SHA256'] = sha(ROOT/'audit_recompute.py')
    record['Immutable_source_manifest_SHA256'] = sha(ROOT/'INPUT_SHA256.json')
    (OUT/(stem+'.provenance.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    plt.close(fig)
    print(f'Figure {number:02d}: {stem}.png', flush=True)
