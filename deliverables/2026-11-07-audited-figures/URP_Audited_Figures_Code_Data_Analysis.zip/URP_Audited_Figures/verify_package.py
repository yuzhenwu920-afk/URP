"""Check the frozen inputs, audited statistics and rendered PNG pixels."""
from pathlib import Path
import hashlib,json
from PIL import Image
ROOT=Path(__file__).resolve().parent
def main():
    for file in ['INPUT_SHA256.json','CODE_SHA256.json']:
        for name,want in json.loads((ROOT/file).read_text(encoding='utf-8')).items():
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=want:raise ValueError('Changed file: '+name)
    record=json.loads((ROOT/'EXPECTED_PNG_PIXELS.json').read_text())
    for name,want in record.items():
        with Image.open(ROOT/name) as im:
            got=hashlib.sha256(im.convert('RGBA').tobytes()).hexdigest()
        if got!=want:raise ValueError('PNG pixels differ: '+name+'; check plotting versions and platform')
    report=json.loads((ROOT/'outputs/audit/NUMERICAL_AUDIT.json').read_text())
    assert all(r['Pass']for r in report['Checks'])
    assert len(report['Digitization_flags'])==2
    assert report['Figure6_unchanged']
    print('PASS: immutable inputs and code; 12 figure pixels; numerical checks.',len(report['Checks']))
    print('Source-reading flags remain disclosed:',len(report['Digitization_flags']))
if __name__=='__main__':main()
