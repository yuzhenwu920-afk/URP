"""Figure-specific analysis; empirical values are tied to the guarded inputs."""
FIGURES={
3: dict(title='气象驱动与ETo来源',caption='Figure 3. Daily precipitation and reference evapotranspiration over the actual model execution periods. Orange lines show the ETo-B forcing used by AquaCrop; dashed gray lines show the originally uploaded ETo. Precipitation and ETo use the left and right axes, respectively.',
 paragraphs=[
 '在同一批模型执行日期内，四年模型采用的ETo-B季节合计分别为595.62、632.26、612.93和609.26 mm，原上传气象表中的ETo合计分别为519.30、536.29、519.28和521.94 mm，两组差额为76.32、95.96、93.66和87.32 mm。降水逐日值与上传气象表一致，季节合计分别为177.87、113.46、143.32和151.38 mm。新版图3并列展示两套ETo，季节合计均按实际执行日期计算。',
 '四年ETo-B已由归档的温度、气压、饱和水汽压差、净辐射及2 m风速分量重算，最大逐日差小于3×10⁻¹⁵ mm。日尺度Penman–Monteith计算取土壤热通量G为0，采用小时标量风速平均形成的B组风速。2022年导出文件虽同时含A、B、C三组结果，原模型实际使用的仍为B组。原上传序列与导出A组也有小幅差别，故图中将其标为“原上传ETo”，不直接命名为A组。',
 '上述核验明确了本研究模拟所用大气蒸发需求的数值来源。这里的降水与ETo均为归档气象驱动，本次验证覆盖归档ETo的计算一致性；独立气象站精度评价需要另行对照。原GEE逐日导出及本地重算代码已补齐，历史小时提取脚本尚未找回。'],
 data=['ETo_daily_comparison.csv','ETo_annual_comparison.csv'],change='新增原上传ETo对照；恢复四年导出分量并重算ETo-B；明确实际执行日期和B组口径。'),
4: dict(title='冠层覆盖度校准与LAI来源',caption='Figure 4. Canopy-cover calibration using digitized DI leaf-area-index data. Open circles show CC derived from LAI; colored lines show the existing simulations. Dotted vertical lines indicate the configured senescence onset. Post-onset counts refer to observations with DAP greater than SenescenceCD.',
 paragraphs=[
 '四年48个CC校准点均可与已找回的DI叶面积指数表按年度和日期逐行对应。按CC=1.005[1−exp(−0.6LAI)]¹·²重新换算后，结果与原配对表一致；再与逐日模拟冠层覆盖度配对，复算得到的校准R²为0.9306～0.9932、RMSE为0.0316～0.0596，年度指标保持不变。该证据链使用文献图4-1的DI资料，与带BI标签的遥感辅助文件分开。',
 '模型较好描述了冠层扩展和高覆盖阶段的变化，2022年的误差主要出现在快速增长阶段。按原模型配置的衰老起始时间统计，2019—2022年起始时间之后的CC观测分别仅有2、2、1和2个。新增竖线和样本数标注使晚季资料覆盖程度更加直观，有助于将生长过程拟合与晚季参数的信息量联系起来。',
 '本次已补齐“DI LAI数值—换算CC—日期—模拟值”的48行记录，并附原论文页面。历史LAI取点项目和原取点像素未留存，因此仍将这些点称为文献图数字化后换算的校准资料，而不称为本项目新增田间观测。'],
 data=['CC_LAI_to_daily_trace.csv','Table3_calibration_performance.csv'],change='恢复LAI换算链；注明DI处理；增加衰老时点和晚季观测计数。'),
5: dict(title='年度生物量拟合与原图重读',caption='Figure 5. Existing biomass simulations compared with the original digitized DI calibration targets and a new rereading of the thesis bars. Circles retain the actual calibration targets; open diamonds show the reread bar heights. Both share the same simulated value on each date. Displayed calibration statistics use the original targets.',
 paragraphs=[
 '四年生物量配对点均回查至王尚今学位论文图4-8，即PDF第58页、正文第48页的橙色DI柱状序列。2022年10个日期与图中分类日期标签一致，纵轴为kg/ha，除以1000后统一为t/ha。以柱体顶边而非误差棒顶端重读后，2022年各点与原校准表的最大差为0.0762 t/ha，处理、单位及日期来源由此得到补充。',
 '保留原校准目标时，2022年R²为0.9966、RMSE为0.5562 t/ha；使用本次重读值与同一组冻结模拟值比较，R²为0.9968、RMSE为0.5479 t/ha。因此，该年较小的拟合误差在这次读数复核下基本稳定。四年原目标下的RMSE范围仍为0.5562～1.2520 t/ha。',
 '本次还发现，2019年6月4日、6月12日的重读值分别为1.5439、2.4149 t/ha，原表为1.2、2.0 t/ha，差值0.3439、0.4149 t/ha，超过此前0.3 t/ha的读数容差。新版以空心菱形并列显示重读位置，并在来源表中保留这两个标记。校准目标和模型参数未据此替换；重读值只用于来源敏感性比较。原图误差棒的统计定义未明确，本次没有将其当作测量标准差。'],
 data=['F05_Biomass_calibration_pairs.csv','Biomass_thesis_pixel_recheck.csv','Biomass_rereading_sensitivity.csv'],change='补齐2022年10点的来源、处理、单位、日期和像素记录；并列显示新读数；列出2019年两处读数差异。'),
7: dict(title='四年汇总回归与2022年影响',caption='Figure 7. Pooled biomass regression using the original calibration pairs. Panel (a) includes all 37 points from four years; panel (b) excludes the 10 points from 2022 as a sensitivity check. The latter is not an independent validation experiment. RMSE compares the simulated and digitized values directly.',
 paragraphs=[
 '四年37个生物量配对点的汇总拟合为y=0.9979x+0.2412，OLS R²为0.9892，Pearson相关系数为0.9946，配对RMSE为1.0205 t/ha。斜率接近1，说明模拟值与文献数字化生物量在整个变化范围内保持较一致的幅度关系。',
 '为检验汇总关系是否过度依赖2022年，新增剔除该年10点的敏感性面板。其余27点得到y=1.0070x+0.2784，OLS R²为0.9872，Pearson r为0.9936，配对RMSE为1.1457 t/ha。两组回归均保持较高线性一致性，说明原汇总关系并非仅由2022年决定。图5的R²采用1−SSE/SST评价模拟与目标的一致性，图7标注的OLS R²则反映回归线的解释程度，两者分别报告。'],
 data=['Pooled_biomass_regression_sensitivity.csv','F05_Biomass_calibration_pairs.csv'],change='保留37点主回归；新增剔除2022年的27点敏感性对照；区分配对拟合R²与OLS R²。'),
8: dict(title='年度水量分配',caption='Figure 8. Seasonal inflow, outflow and storage change under the original DI schedules. All components are reconstructed from daily model records. Storage change is final minus initial water storage.',
 paragraphs=[
 '原DI日程下，四年总入流分别为623.14、673.22、776.79和556.22 mm，总出流分别为642.37、611.31、606.83和596.81 mm。2019、2022年出流高于入流，储水分别减少19.23和40.58 mm；2020、2021年则分别增储61.92和169.97 mm。年度差异说明，灌溉与降水既参与当季耗水，也改变季末土壤水状态。',
 '2021年入流最高，而模拟ET为605.14 mm，较大的供水并未同比转化为蒸散耗水。其原日程形成的季末增储，为解释优化方案以较低灌水量维持规定产量水平提供了水量背景。本轮逐日账复算与原图数值一致，图形与主要结果沿用。'],
 data=['F09_annual_water_budget.csv','Daily_water_recomputed_summary.csv'],change='主要图形和数值沿用；复核逐日账与年度入流—出流—储水关系。'),
9: dict(title='多输出Sobol敏感性',caption='Figure 9. Total-effect Sobol indices recomputed from the original design matrices and model responses. Each annual value averages three independent scrambles of 512 base samples. The common input distribution is independent uniform; values are not normalized to sum to one.',
 paragraphs=[
 '采用原始输入矩阵和逐行模型响应复算后，四类输出的Sobol年度点估计与归档表一致。产量主要受WP_late、HI0、WP_early和Kcb影响；生物量以WP_late、WP_early和Kcb为主要敏感参数。ET的Kcb总效应指数为0.762～0.882，最大冠层覆盖度的CCx总效应指数为0.836～0.957，体现了参数在耗水与作物生长计算路径中的不同作用。',
 '四年主要参数层级在点估计上较稳定，但相邻参数的细微次序需结合估计区间解释。新版热图保留相同0～1色标，并将格内数值增加至三位小数；2022年WP_early与Kcb在该显示精度下接近相等，其可分辨程度由图10的成对重抽样结果进一步说明。这里分析的是共同独立均匀范围内的敏感性，未将其称为相关MCMC后验分布下的敏感性。'],
 data=['Sobol_recomputed_seed_indices.csv','Sobol_annual_means_and_ranks.csv'],change='从12组原始设计及响应复算；增加显示精度；弱化对近并列参数的严格排序解释。'),
10: dict(title='产量敏感性区间与近并列参数',caption='Figure 10. First-order and total-effect yield indices with new reproducible 95% numerical bootstrap intervals. Complete A/B/AB response blocks are resampled together within each scramble; three scramble estimates receive equal weights. There are 2,048 replicates, with seed 20261107 + year. Diamonds are descriptive four-year means.',
 paragraphs=[
 '产量总效应指数的四年均值以WP_late最高，为0.396，其后为HI0、WP_early和Kcb，分别为0.206、0.164和0.145。新版保持原始点估计，并使用明确随机种子、完整响应块和2048次重抽样重新计算数值区间。原图历史区间作为归档保留，新区间和抽样规则可由本包直接重建。',
 '2022年WP_early与Kcb的总效应差仅为0.000077；对两者差值进行成对bootstrap后，95%数值区间为[−0.0139,0.0138]。2021年的差值为0.005524，区间为[−0.0081,0.0197]。这两年的细微点排序不足以支持稳定的强弱区分，宜表述为两参数处于相近敏感性层级；晚期WP等较高贡献参数的总体地位仍然清晰。',
 '按未取整值计算，前四项ST均值之和为0.9100207055，三位小数应为0.910。该和含有交互贡献的重复计入，仅作数值核对，不解释为四个参数独立解释了91.0%的产量方差。图中区间反映所给模型与输入范围下的数值估计误差，未混入田间观测误差或参数后验不确定性。'],
 data=['Yield_Sobol_seeded_percentile_CI.csv','Sobol_near_tie_paired_bootstrap.csv','Sobol_four_year_means.csv'],change='用原始响应重建有明确种子的区间；增加WP_early−Kcb的成对差值区间；纠正0.911求和及其解释。'),
11: dict(title='Pareto前沿与产量门槛',caption='Figure 11. Four-year yield–irrigation trade-offs under five-stage NSGA-III scheduling. Labels give rounded irrigation totals for Seedling, Jointing, Heading, Grain filling and Maturity. Open orange circles identify formal selected solutions; dotted lines are 95% of the published DI yields. Full-range fronts come from the supplemental searches.',
 paragraphs=[
 '以发表的DI观测产量为统一门槛基准，四年代表方案的实际灌水量分别为209.83、306.50、264.50和257.47 mm。各年前沿随供水增加先上升、后趋缓，表现出维持规定产量水平与降低季节供水量之间的权衡。红点标签是五个生育期的水量合计，具体逐次日期另见图13和源表。',
 '2021年必须区分发表值15.86 t/ha与内部校准目标15.862 t/ha。正式筛选使用前者，对应95%门槛为15.06700 t/ha；代表方案15.06841458 t/ha在未取整比较下高于门槛0.00141458 t/ha。若改用内部目标，门槛将为15.06890 t/ha，该点会低0.00048542 t/ha。两者属于不同筛选定义，本版统一使用已声明的发表值，未将两种口径混用。',
 '完整曲线与代表方案也采用不同搜索用途：前者来自取消产量门槛的补充搜索，后者按正式五种子最终可行种群并集中的最小灌水量选取。图中展示的是有限搜索得到的模型权衡关系，并保留原DI模型基准作为比较。候选产量允许接近观测值的95%，因此减灌幅度始终与这一产量要求共同报告。'],
 data=['Published_vs_internal_yield_gates.csv','Formal_final_population_fronts.csv','Selected_95pct_candidates.csv','Pareto_display_points.csv'],change='统一发表值门槛并按未取整数值核验；明确全范围搜索与正式代表方案；防止五期标签重叠。'),
12: dict(title='减灌来源与回放误差范围',caption='Figure 12. Water-balance decomposition of irrigation reduction relative to the original DI schedules. The storage term is the difference in simulated end-of-season storage over 0–2.4 m, not measured field storage. Percentages give the storage difference divided by the irrigation reduction.',
 paragraphs=[
 '四年减灌量分别为235.44、253.26、368.97和147.37 mm，其中ET减少38.16、17.04、11.46和27.85 mm；季末模拟剖面储水差为193.14、234.87、356.85和119.50 mm，占相应减灌量的82.03%、92.74%、96.72%和81.09%。新版直接标注该比例的分母为减灌量，并将储水明确写为0～2.4 m剖面的模型结果。',
 '2021年灌水减少368.97 mm，而ET仅减少11.46 mm、即1.89%；主要差额对应较低的季末储水。该结果解释了模型高产平台的水量来源，也表明供水投入下降与蒸散消耗下降具有不同含义。两方案保持相同初始墒情和气象条件，季末水状态则随日程改变；若讨论连续年度应用，还应结合季末储水恢复与深层含水量资料评价。',
 '回放误差应按方案范围报告：四个主候选的最大原单位差为1.136868×10⁻¹³，原DI与主候选合计8个方案的最大值也为1.136868×10⁻¹³；完整回放表包含120个方案，其最大值为2.273737×10⁻¹³。该“原单位差”与逐日水量平衡残差属于不同指标，已分别列入核验表。'],
 data=['Water_decomposition_recomputed.csv','Replay_error_scope_audit.csv','Daily_water_recomputed_summary.csv'],change='明确储水的模拟属性和剖面深度；区分4、8、120个方案的回放统计范围。'),
13: dict(title='逐次灌溉日程',caption='Figure 13. Optimized irrigation dates and actually executed depths in four selected schedules. Stage colors identify the five phenological windows. Exact positive depths include trace amounts; event counts for depths of at least 0.1 mm are reported separately in the tables.',
 paragraphs=[
 '四年合并同日事件后的正水量事件数分别为12、13、9和8，其中达到0.1 mm的事件分别为8、8、3和6。两种计数分别反映数值正值和较明显的供水事件，不改变模型实际执行的季节灌水合计。逐次事件已与同日IrrDay记录和阶段合计核对。',
 '2021年的主要灌水发生在6月15日、6月28日和7月29日，水量分别为92.959、85.822和85.634 mm。完整日程保留其他微量正数，使每次日期、水量、阶段合计与季节总量相互衔接。图形及主要数值沿用，完整42行正水量事件表随包提供。'],
 data=['Optimized_every_irrigation_event.csv','All_selected_schedule_slots.csv'],change='主要图形与数值沿用；核对逐次事件、同日执行量和季节总量。'),
14: dict(title='五生育期水量与次数',caption='Figure 14. Stage irrigation totals and exact positive-depth event counts. Gray bars show the original model DI schedules and colored bars the selected schedules. Up to three optional events are allowed in each stage; stage totals use unrounded executed depths.',
 paragraphs=[
 '五期汇总反映了日期与水量联合调整的年度差异。2019年水量主要配置于苗期85.168 mm和抽穗期119.752 mm；2020年主要分配于苗期、拔节期和灌浆期，分别为108.288、94.704和88.711 mm。2021年拔节期和灌浆期合计分别为178.782、85.634 mm，其余三期约0.084 mm；2022年则以拔节期181.420 mm和灌浆期73.030 mm为主。',
 '上述配置表明，优化并非将原日程各期水量同比例缩减。某些年份的供水时间前移，另一些年份集中于少数阶段；这些结果与所给天气、初始水分及作物参数共同相关。每期允许0～3个事件，微量正数也计入图中n值，实际执行条件下的最小水量和设备能力需与日程一并评价。图14和阶段统计数值保持一致。'],
 data=['Five_stage_totals_and_event_counts.csv','All_selected_schedule_slots.csv'],change='主要图形与数值沿用；核对五期合计、每期次数上限和微量事件口径。'),
15: dict(title='算法搜索过程',caption='Figure 15. Population hypervolume over formal NSGA-III and NSGA-II searches. Lines give five-seed means and shading gives seed minima and maxima, not confidence intervals. Final-generation hypervolumes are independently reconstructed from saved solutions using the same annual normalization.',
 paragraphs=[
 '两算法的种群超体积总体随迭代增加，前期改善较快，后期增幅逐渐缩小；五种子之间仍存在一定离散。图中阴影为种子最小值至最大值范围，反映搜索运行差异，并非统计置信区间。四年两算法最终并集最低灌水量差的绝对值为0.03～1.47 mm，超体积的相对优劣随年份变化。',
 '原始逐代日志中的4000条正式记录已保留，并利用最终代解集复算了各年度、算法和种子的末代超体积。两算法使用相同目标、约束及已披露的共同初值，得到接近的供水—产量权衡关系；这一对照支持所给搜索条件下的数值一致性。图形和主要结论沿用，正文不将其改写为NSGA-III在所有年份均优于NSGA-II。'],
 data=['Generation_history.csv','Formal_final_population_fronts.csv','Algorithm_comparison.csv'],change='主要图形与数值沿用；复核40组末代超体积及最终并集指标，明确阴影含义。'),
}
