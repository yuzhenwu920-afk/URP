"""Second, read-only review of the URP evidence. No model or figure is run.

Usage: python independent_review.py --package PATH --original PATH --output PATH
The earlier full reproduction archive supplies data/mcmc; the latest audited
figure archive supplies the restored daily components and source records.
"""
from pathlib import Path
import argparse, json, hashlib, re, os, importlib.util
import numpy as np
import pandas as pd
from scipy.stats import rankdata, norm
import fitz

P=argparse.ArgumentParser();P.add_argument('--package',type=Path,required=True);P.add_argument('--original',type=Path,required=True);P.add_argument('--output',type=Path,required=True)
ARGS=P.parse_args();A=ARGS.package;O=ARGS.original;OUT=ARGS.output;OUT.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('MPLCONFIGDIR',str(OUT.parent/'.cache/matplotlib'))
os.environ.setdefault('XDG_CACHE_HOME',str(OUT.parent/'.cache'))
import arviz as az
CHECKS=[]

def read(p):return pd.read_csv(p,encoding='utf-8-sig',float_precision='round_trip')
def save(d,name):d.to_csv(OUT/name,index=False,encoding='utf-8-sig',float_format='%.17g')
def compare(name,left,right,tol=1e-10,**context):
    l,r=np.asarray(left,float),np.asarray(right,float);assert l.shape==r.shape,(name,l.shape,r.shape)
    err=float(np.max(np.abs(l-r)))if l.size else 0.;ok=bool(np.isfinite(l).all()and np.isfinite(r).all()and err<=tol)
    CHECKS.append(dict(Check=name,Max_error=err,Tolerance=tol,Pass=ok,**context))
    if not ok:raise ValueError((name,err,tol,context))

def rhat_of(z):
    n=z.shape[1];within=np.mean(np.var(z,axis=1,ddof=1));between=np.var(z.mean(1),ddof=1)
    return np.sqrt(((n-1)/n*within+between)/within)

def rank_z(s):
    rank=rankdata(s.ravel(),method='average');return norm.ppf((rank-.375)/(rank.size+.25)).reshape(s.shape)

def diagnose(chains):
    half=chains.shape[1]//2;s=np.r_[chains[:,:half],chains[:,-half:]]
    z=rank_z(s);fold=rank_z(np.abs(s-np.median(s)))
    # The archived audit explicitly used ArviZ 0.22.0. Its finite-lag ESS
    # implementation differs slightly from the older embedded sampler helper.
    # Keep the declared backend instead of labelling that method difference a
    # change to the original chain. Independently cross-check rank split Rhat.
    rhat=float(az.rhat(chains,method='rank'))
    assert abs(rhat-max(rhat_of(z),rhat_of(fold)))<1e-10
    return rhat,float(az.ess(chains,method='bulk'))

def tau(raw):
    n,walkers,dim=raw.shape;result=[]
    for k in range(dim):
        x=raw[:,:,k]-raw[:,:,k].mean(0)
        f=np.fft.fft(x,n=2*(1<<(n-1).bit_length()),axis=0)
        ac=np.fft.ifft(f*f.conj(),axis=0).real[:n]
        ac/=ac[0];mean=ac.mean(1);sequence=2*np.cumsum(mean)-1
        valid=np.arange(n)<5*sequence;window=int(np.argmin(valid))if np.any(valid)else n-1
        if np.all(valid):window=n-1
        result.append(sequence[window])
    return np.asarray(result)

def chains_review():
    old=read(O/'data/paper/Audit_Parameter_diagnostics.csv').set_index(['Year','Phase','Parameter'])
    params=[];annual=[];groups=[];hashes=[]
    for year in [2019,2020,2021,2022]:
        for phase in [1,2]:
            files=sorted((O/f'data/mcmc/{year}/phase{phase}').glob('*.npz'));raw=[];names=None
            for p in files:
                expected_inputs=json.loads((O/'INPUT_SHA256.json').read_text(encoding='utf-8'))
                digest=hashlib.sha256(p.read_bytes()).hexdigest()
                assert digest==expected_inputs[str(p.relative_to(O))]
                with np.load(p,allow_pickle=False)as z:
                    raw.append(z['history']);contract=json.loads(str(z['contract']));names=contract['names']
                    assert z['history'].shape[0]==2000
                    for source in (A/f'source/model_inputs/{year}').glob('*'):
                        key='data/inputs/'+source.name;want=contract['files'].get(key);actual=hashlib.sha256(source.read_bytes()).hexdigest()
                        assert want==actual,(p.name,year,phase,source.name)
                        hashes.append(dict(Year=year,Phase=phase,Ensemble=p.name,Checkpoint_sha256=digest,Input=source.name,Matches_checkpoint=True,Source_sha256=actual))
            raw=np.stack(raw);taus=np.stack([tau(x)for x in raw]);burn=int(np.ceil(5*taus.max()))
            reference=old.loc[(year,phase)]
            compare('Burn-in rule from full raw chain tau',np.array([burn]),np.array([reference.Burn_in.iloc[0]]),0,Year=year,Phase=phase)
            post=raw[:,burn:];flat=post.reshape(-1,len(names));q=np.quantile(flat,[.025,.975],axis=0)
            rh=np.full((32,len(names)),np.nan);ess=rh.copy()
            if phase==1:
                assert len(files)==4
                for walker in range(32):
                    for k,name in enumerate(names):
                        rh[walker,k],ess[walker,k]=diagnose(post[:,:,walker,k])
                        groups.append(dict(Year=year,Walker_index=walker,Parameter=name,Rhat=rh[walker,k],Bulk_ESS=ess[walker,k]))
            else:assert len(files)==1
            for k,name in enumerate(names):
                ref=reference.loc[name];samples=flat[:,k];low,high=ref.Prior_low,ref.Prior_high;band=.01*(high-low)
                vals=np.array([samples.mean(),q[0,k],q[1,k],np.mean(samples<=low+band),np.mean(samples>=high-band)])
                compare('Raw chain means quantiles and boundary mass',vals,ref[['Mean','P025','P975','Lower_1pct_mass','Upper_1pct_mass']].to_numpy(float),1e-10,Year=year,Phase=phase,Parameter=name)
                if phase==1:
                    compare('Time-preserving matched-walker diagnostics',[rh[:,k].max(),ess[:,k].min()],[ref.Rhat_max,ref.ESS_bulk_min],1e-8,Year=year,Parameter=name)
                params.append(dict(Year=year,Phase=phase,Parameter=name,Independent_ensembles=len(files),Steps=raw.shape[1],Burn_in=burn,
                    Retained_steps=post.shape[1],Mean=vals[0],P025=vals[1],P975=vals[2],Lower_1pct_mass=vals[3],Upper_1pct_mass=vals[4],
                    Tau_max=taus[:,k].max(),Rhat_max=None if phase==2 else rh[:,k].max(),Minimum_matched_group_bulk_ESS=None if phase==2 else ess[:,k].min(),
                    ESS_scope='min across 32 matched-walker groups; not pooled sample ESS'if phase==1 else 'single ensemble; independent-ensemble comparison unavailable'))
            annual.append(dict(Year=year,Phase=phase,Independent_ensembles=len(files),Walkers=raw.shape[2],Steps=raw.shape[1],Burn_in=burn,Retained_steps=post.shape[1],
                Worst_matched_group_Rhat=None if phase==2 else rh.max(),Minimum_matched_group_bulk_ESS=None if phase==2 else ess.min(),
                Maximum_tau=taus.max(),Raw_steps_over_max_tau=raw.shape[1]/taus.max()))
    save(pd.DataFrame(params),'MCMC_parameters_recomputed.csv');save(pd.DataFrame(annual),'MCMC_annual_recomputed.csv');save(pd.DataFrame(groups),'MCMC_all_640_parameter_groups.csv');save(pd.DataFrame(hashes),'Checkpoint_input_hash_matches.csv')
    print('Original MCMC chain diagnostics complete',flush=True)

def forcing_and_sources():
    env=read(A/'data/paper/Environmental_drivers_used.csv');calendar=read(A/'data/paper/Annual_model_calendar.csv').set_index('Year');rows=[]
    for year in [2019,2020,2021,2022]:
        d=read(next((A/f'source/model_inputs/{year}').glob('ETO_FILE*')))
        t=d.Tmean_C;delta=4098*.6108*np.exp(17.27*t/(t+237.3))/(t+237.3)**2;gamma=.000665*d.Pressure_kPa
        def pm(w):return np.maximum((.408*delta*d.Rn_ERA5_MJ+gamma*900/(t+273)*d[w]*d.VPD_raw_kPa)/(delta+gamma*(1+.34*d[w])),0)
        compare('All export EToB rows from PM components',pm('Wind2m_B_ms'),d.ETo_B_mm,1e-11,Year=year)
        compare('All export EToA rows from PM components',pm('Wind2m_A_ms'),d.ETo_A_mm,1e-11,Year=year)
        assert(d.Wind2m_B_ms>=d.Wind2m_A_ms-1e-10).all()
        s=env[env.Year==year].merge(d[['Date','ETo_A_mm','ETo_B_mm']],on='Date',validate='one_to_one');raw=read(A/f'data/observations/Climate_{year}.csv').rename(columns={'date':'Date'})
        raw=raw.rename(columns={'ETo_mm':'Uploaded_ETo_mm','Precip_mm':'Uploaded_Precip_mm'})
        s=s.merge(raw[['Date','Uploaded_ETo_mm','Uploaded_Precip_mm']],on='Date',validate='one_to_one')
        compare('Used daily ETo agrees with B export',s.Reference_ET0_mm_d,s.ETo_B_mm,1e-11,Year=year)
        compare('Used precipitation agrees with uploaded weather',s.Precipitation_mm,s.Uploaded_Precip_mm,1e-11,Year=year)
        compare('Annual forcing calendar',[len(s),s.Reference_ET0_mm_d.sum(),s.Precipitation_mm.sum()],calendar.loc[year,['Calendar_days','Actual_used_ETo_mm','Rain_mm']],1e-9,Year=year)
        rows.append(dict(Year=year,Days=len(s),First_date=s.Date.min(),Last_date=s.Date.max(),Uploaded_ETo=s.Uploaded_ETo_mm.sum(),Export_A_ETo=s.ETo_A_mm.sum(),Used_B_ETo=s.ETo_B_mm.sum(),Used_minus_uploaded=s.Reference_ET0_mm_d.sum()-s.Uploaded_ETo_mm.sum(),B_minus_A=s.ETo_B_mm.sum()-s.ETo_A_mm.sum()))
    save(pd.DataFrame(rows),'ETo_independent_comparison.csv')
    pdf=fitz.open(A/'evidence/Wang_2023_Thesis.pdf')
    for page in [48,50,53,57,62]:(OUT/f'Thesis_PDF_page_{page+1}_verbatim.txt').write_text(pdf[page].get_text(),encoding='utf-8')
    text=pdf[48].get_text();assert '76 mm' in text and '79 mm' in text and '78 mm' in text and '81 mm' in text
    sources=read(A/'outputs/derived/Table2_Literature_and_derived_targets.csv')
    compare('Es targets match explicit thesis sequence',sources.ES_TARGET,[76,79,78,81],0)
    save(sources,'Literature_targets_source_check.csv')
    print('ETo and primary literature sources complete',flush=True)

def observations():
    cc=read(A/'data/paper/F02_CC_calibration_pairs.csv');b=read(A/'data/paper/F05_Biomass_calibration_pairs.csv');cal=read(A/'data/paper/Calibration_daily_growth.csv')
    lai=read(next((A/'source/model_inputs/2022').glob('FIELD_CC*')))
    assert len(cc)==48 and len(b)==37 and(lai.Irrigation=='DI').all()
    z=lai.merge(cc,on=['Year','Date'],validate='one_to_one')
    compare('48 LAI-derived CC values',1.005*(1-np.exp(-.6*z.LAI))**1.2,z.CC_observed,1e-12)
    rows=[]
    for year in [2019,2020,2021,2022]:
        base=read(A/f'data/optimization/{year}_Original_DI_daily_growth.csv').set_index('Date');s=cal[cal.Year==year].set_index('Date')
        compare('Calibration and optimization baseline use same daily canopy',s.canopy_cover,base.loc[s.index,'canopy_cover'],1e-12,Year=year)
        compare('Calibration and optimization baseline use same daily biomass',s.biomass,base.loc[s.index,'biomass'],1e-10,Year=year)
        c=cc[cc.Year==year];v=b[b.Year==year]
        for label,d,obs,sim in [('CC',c,c.CC_observed,c.CC_simulated),('Biomass',v,v.B_observed_t_ha,v.B_simulated_t_ha)]:
            diff=sim.to_numpy()-obs.to_numpy();r2=1-np.sum(diff**2)/np.sum((obs-obs.mean())**2);rmse=np.sqrt(np.mean(diff**2))
            rows.append(dict(Year=year,Variable=label,N=len(d),R2=r2,RMSE=rmse))
    save(pd.DataFrame(rows),'Calibration_metrics_independent.csv')
    # Inspect both schema generations rather than treating frozen blank fields
    # as absence of the newer source record.
    fresh=read(A/'outputs/derived/F05_Biomass_calibration_pairs.csv');source=read(A/'outputs/derived/Biomass_thesis_pixel_recheck.csv')
    s=fresh[fresh.Year==2022];src=source[source.Year==2022];assert len(s)==len(src)==10
    assert(s.Treatment=='DI').all()and s.Included.all()and s.Source.notna().all()
    for c in ['Axis_top_px_recheck','Axis_zero_px_recheck','Bar_top_px_recheck','ROI_x0_px','ROI_x1_px']:assert s[c].notna().all()
    rows=[]
    for c in ['Treatment','Included','Source','Axis_top_px','Axis_top_px_recheck','Axis_zero_px','Axis_zero_px_recheck','Bar_top_px','Bar_top_px_recheck','ROI_x0_px','ROI_x1_px']:
        rows.append(dict(Column=c,Rows=10,Missing_count=int(s[c].isna().sum()),Role='legacy coordinate field'if c in ['Axis_top_px','Axis_zero_px','Bar_top_px']else'current or rereading record'))
    save(pd.DataFrame(rows),'2022_biomass_source_schema.csv');save(source,'Biomass_original_vs_rereading.csv')
    unified=s[['Year','Date','Treatment','Included','B_observed_t_ha','B_simulated_t_ha','Reread_t_ha','Sigma_assumed','Source','PDF_page','Printed_page','Figure','Render_scale','Crop_x0_pdf_pt','Crop_y0_pdf_pt',
               'Axis_top_px_recheck','Axis_zero_px_recheck','Bar_top_px_recheck','ROI_x0_px','ROI_x1_px','Recheck_tolerance_t_ha']].copy()
    unified=unified.rename(columns={'Axis_top_px_recheck':'Reread_axis_top_px','Axis_zero_px_recheck':'Reread_axis_zero_px','Bar_top_px_recheck':'Reread_bar_top_px'})
    unified['Pixel_record_role']='2026-11-07 independent rereading; not recovered historical digitization pixels'
    save(unified,'2022_DI_biomass_unified_source_record.csv')
    regressions=[]
    for label,part in [('All37',b),('Without2022_27',b[b.Year!=2022])]:
        x=part.B_observed_t_ha.to_numpy();y=part.B_simulated_t_ha.to_numpy();slope=np.dot(x-x.mean(),y-y.mean())/np.sum((x-x.mean())**2);r=np.corrcoef(x,y)[0,1]
        regressions.append(dict(Subset=label,N=len(x),Slope=slope,Intercept=y.mean()-slope*x.mean(),R2=r*r,Pearson_r=r,Pair_RMSE=np.sqrt(np.mean((x-y)**2))))
    save(pd.DataFrame(regressions),'Pooled_regression_independent.csv')
    print('Observation pairing and source schema complete',flush=True)

def sobol():
    outputs=['Y_13pct','B_t_ha','Tr_mm','Es_mm','ET_mm','MaxCC'];rows=[];hashrows=[]
    decoder=Path(__file__).resolve().parent/'read_complete_results.py'
    module_spec=importlib.util.spec_from_file_location('lossless_decoder',decoder);module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
    for folder in sorted((A/'data/sobol').iterdir()):
        if not folder.is_dir():continue
        info=json.loads((folder/'run.json').read_text());year=int(folder.name[:4]);seed=int(folder.name.split('seed')[1]);space=json.loads((folder/'space.json').read_text());names=space['names']
        x=np.load(folder/'design.npy',allow_pickle=False);y=np.load(folder/'response_matrix.npy',allow_pickle=False)
        assert x.shape==(5120,8)and y.shape==(5120,6)
        for file,key in [('design.npy','design_sha256'),('indices.csv','indices_sha256')]:
            want=info[key];actual=hashlib.sha256((folder/file).read_bytes()).hexdigest();assert actual==want
            hashrows.append(dict(Year=year,Seed=seed,File=file,Matches_run_record=True,SHA256=actual))
        marker=json.loads((Path(__file__).resolve().parent/'sobol_lossless_markers'/folder.name/'LOSSLESS_REPACK.json').read_text())
        # responses_sha256 hashes responses.jsonl, not response_matrix.npy.
        assert marker['source_responses_sha256']==info['responses_sha256'] and marker['response_rows']==5120
        columns=module.load_columns(folder/'all_response_columns.npz')
        assert np.array_equal(columns.row_id.to_numpy(),np.arange(5120))
        compare('Full response matrix vs decoded lossless journal columns',y,columns[outputs].to_numpy(),0,Year=year,Seed=seed)
        npy_sha=hashlib.sha256((folder/'response_matrix.npy').read_bytes()).hexdigest()
        assert npy_sha==json.loads((A/'INPUT_SHA256.json').read_text())[str((folder/'response_matrix.npy').relative_to(A))]
        hashrows.append(dict(Year=year,Seed=seed,File='responses.jsonl (source journal)',Matches_run_record=True,SHA256=marker['source_responses_sha256'],
            Note='source journal hash verified against lossless-repack marker; numeric columns independently decoded'))
        xx=x.reshape(-1,10,8)
        for k in range(8):
            want=xx[:,0,:].copy();want[:,k]=xx[:,-1,k];compare('Sobol hybrid input columns',xx[:,k+1],want,1e-12,Year=year,Seed=seed,Parameter=names[k])
        old=read(folder/'indices.csv').set_index(['Output','Parameter'])
        for k,label in enumerate(outputs):
            values=(y[:,k]-y[:,k].mean())/y[:,k].std();blocks=values.reshape(-1,10);a=blocks[:,0];bb=blocks[:,-1];hybrid=blocks[:,1:-1]
            variance=np.var(np.r_[a,bb]);s1=np.mean(bb[:,None]*(hybrid-a[:,None]),0)/variance;st=np.mean((a[:,None]-hybrid)**2,0)/(2*variance)
            compare('Sobol point indices independent calculation',np.c_[s1,st],old.loc[[(label,p)for p in names],['S1','ST']],1e-11,Year=year,Seed=seed,Output=label)
            rows.extend(dict(Year=year,Seed=seed,Output=label,Parameter=p,S1=s1[j],ST=st[j])for j,p in enumerate(names))
    table=pd.DataFrame(rows);annual=table.groupby(['Year','Output','Parameter'],as_index=False)[['S1','ST']].mean();save(annual,'Sobol_independent_annual.csv');save(pd.DataFrame(hashrows),'Sobol_run_hash_matches.csv')
    ci=read(A/'outputs/derived/Yield_Sobol_seeded_percentile_CI.csv');near=[]
    for year in [2019,2020,2021,2022]:
        with np.load(A/f'outputs/audit/bootstrap_draws/{year}_yield_bootstrap.npz',allow_pickle=False)as z:
            draws=z['draws'];seed=int(z['seed']);n=int(z['resamples'])
        assert seed==20261107+year and n==2048 and draws.shape==(2048,2,8)
        q=np.quantile(draws,[.025,.975],axis=0);t=ci[ci.Year==year].set_index('Parameter').loc[names]
        compare('New percentile intervals match saved bootstrap draws',np.column_stack([q[0,0],q[1,0],q[0,1],q[1,1]]),t[['S1_low','S1_high','ST_low','ST_high']],1e-12,Year=year)
        delta=draws[:,1,names.index('WP_early')]-draws[:,1,names.index('Kcb')]
        vals=t.loc['WP_early','ST']-t.loc['Kcb','ST']
        near.append(dict(Year=year,Point_difference=vals,Paired_low=np.quantile(delta,.025),Paired_high=np.quantile(delta,.975)))
        if year==2022:
            # Recreate every 2022 bootstrap draw from original response rows,
            # not merely from the saved interval endpoints.
            rng=np.random.default_rng(20261107+year);parts=[]
            for seed0 in [101,202,303]:
                yy=np.load(A/f'data/sobol/{year}_seed{seed0}/response_matrix.npy',allow_pickle=False)[:,0]
                yy=(yy-yy.mean())/yy.std();blocks=yy.reshape(512,10)
                ids=rng.integers(0,512,size=(2048,512));sample=blocks[ids]
                aa=sample[:,:,0];bb=sample[:,:,-1];ab=sample[:,:,1:-1]
                var=np.var(np.concatenate([aa,bb],axis=1),axis=1)
                one=np.mean(bb[:,:,None]*(ab-aa[:,:,None]),axis=1)/var[:,None]
                total=np.mean((aa[:,:,None]-ab)**2,axis=1)/(2*var[:,None])
                parts.append(np.stack([one,total],axis=1))
            compare('2022 all 2048 bootstrap draws recreated from raw response rows',np.mean(parts,axis=0),draws,1e-12)
    save(pd.DataFrame(near),'Sobol_near_ties_independent.csv')
    means=annual[annual.Output=='Y_13pct'].groupby('Parameter').ST.mean();total=means.loc[['WP_late','HI0','WP_early','Kcb']].sum()
    (OUT/'Sobol_top_four_ST_sum.txt').write_text(f'{total:.17g}\nNot a unique explained-variance share.\n',encoding='utf-8')
    print('Original Sobol designs responses and new CI checks complete',flush=True)

def water_and_gates():
    t=read(A/'outputs/derived/Table2_Literature_and_derived_targets.csv').set_index('Year');chosen=read(A/'data/optimization/Selected_95pct_candidates.csv').set_index('Year');final=read(A/'data/optimization/Formal_final_population_fronts.csv');out=[];water=[];flux=[]
    for year in [2019,2020,2021,2022]:
        obs=t.loc[year,'Y13_PUBLISHED'];internal=t.loc[year,'Y13_TARGET'];y=chosen.loc[year,'Y_13pct'];gate=.95*obs
        assert y>=gate and(final[final.Year==year].Y_13pct>=gate-1e-10).all()
        out.append(dict(Year=year,Published_gate=gate,Internal_gate=.95*internal,Candidate_yield=y,Margin_published=y-gate,Margin_internal=y-.95*internal))
        terms={}
        for tag in ['Original_DI','Selected_95pct']:
            d=read(A/f'data/optimization/{year}_{tag}_daily_water.csv');initial=d.Profile_initial_of_day_mm.iloc[0];end=d.Profile_final_of_day_mm.iloc[-1]
            lhs=d.Precipitation.sum()+d.IrrDay.sum()+d.CR.sum()+d.GwIn.sum();et=d.Tr.sum()+d.Es.sum();loss=d.Runoff.sum()+d.DeepPerc.sum()+d.TileDrain.sum();ds=end-initial+d.surface_storage.iloc[-1]
            compare('Independent seasonal water balance',lhs,et+loss+ds,1e-8,Year=year,Control=tag)
            terms[tag]=dict(I=d.IrrDay.sum(),ET=et,S=end,Loss=loss,Initial=initial)
            if tag=='Original_DI':
                flux.append(dict(Year=year,ET_target=t.loc[year,'ET_OBS'],ET_model=et,ET_RE_pct=100*(et/t.loc[year,'ET_OBS']-1),
                    Es_target=t.loc[year,'ES_TARGET'],Es_model=d.Es.sum(),Es_RE_pct=100*(d.Es.sum()/t.loc[year,'ES_TARGET']-1),
                    Tr_code_target=t.loc[year,'Tr_used_in_code_mm'],Tr_model=d.Tr.sum(),Tr_RE_pct=100*(d.Tr.sum()/t.loc[year,'Tr_used_in_code_mm']-1)))
        b,o=terms['Original_DI'],terms['Selected_95pct'];di=b['I']-o['I'];det=b['ET']-o['ET'];ds=b['S']-o['S'];dl=b['Loss']-o['Loss']
        compare('Independent irrigation decomposition',di,det+ds+dl,1e-8,Year=year)
        water.append(dict(Year=year,Delta_I=di,Delta_ET=det,Delta_end_storage=ds,Delta_other_loss=dl,Storage_share=100*ds/di,Baseline_initial=b['Initial'],Baseline_final=b['S'],Selected_final=o['S']))
    save(pd.DataFrame(out),'Yield_gate_independent.csv');save(pd.DataFrame(water),'Water_decomposition_independent.csv')
    save(pd.DataFrame(flux),'Observed_targets_vs_frozen_model_fluxes.csv')
    replay=read(A/'data/optimization/Selected_full_adapter_replay_checks.csv');scopes=[]
    for label,part in [('Four_selected',replay[replay.Control_ID=='Selected_95pct']),('Eight_DI_and_selected',replay[replay.Control_ID.isin(['Selected_95pct','Original_DI'])]),('Complete_archive',replay)]:
        scopes.append(dict(Scope=label,N=len(part),Native_max_difference=part.Maximum_native_difference.max(),Daily_balance_max_mm=part.Daily_balance_max_mm.max()))
    save(pd.DataFrame(scopes),'Replay_scope_independent.csv')
    print('Yield definitions and water balance complete',flush=True)

def main():
    chains_review();forcing_and_sources();observations();sobol();water_and_gates()
    save(pd.DataFrame(CHECKS),'NUMERICAL_CHECKS.csv')
    summary=dict(Status='PASS for numerical reconstruction, not blanket scientific validation',Checks=len(CHECKS),All_pass=all(r['Pass']for r in CHECKS),MCMC_rerun=False,Figure_modified=False,Old_package_modified=False)
    (OUT/'REVIEW_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(summary,flush=True)
if __name__=='__main__':main()
