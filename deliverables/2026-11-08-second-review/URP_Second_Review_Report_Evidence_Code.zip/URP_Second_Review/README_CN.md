# URP 二次复核交付（2026-11-08）

先看 `delivery/URP_Second_Review_Findings_CN.docx`（或同名PDF），对照 `delivery/URP_Second_Review_Evidence.xlsx`。本包是复核补充，原图、模型及原校准目标均未修改，未重新运行MCMC或优化。

## 主要结论

- 图6采样精度问题真实存在。第一阶段最差匹配组Rhat约1.122–1.181；组内最低bulk ESS约17.79–25.34，这不是合并全部样本的ESS。第二阶段各仅一个独立ensemble。均值和区间算术相符，不等于分布采样达标。
- Es文献来源已核清，正文39页明确报告76、79、78、81 mm。旧“近似重建”标签应改正；Tr文献值与代码相减目标分列。2019/2022模拟Es偏差分别约+27.94%/−17.47%，是另需报告的过程拟合结果。
- 2022 DI生物量十点可从原论文图对应；新重读坐标与旧字段分开保存。`2022_DI_biomass_unified_source_record.csv`将有效来源整理在一表，不能称为找回了历史取点工程。2019两个早期读数仍需确认。
- ETo B组分量计算和历史模型输入哈希相符；原始小时GEE提取脚本与独立气象站精度检验仍需补齐。
- Sobol原始数值响应及设计齐全；点估计已重算。新bootstrap与历史随机区间分开，2021/2022近邻排名差异的区间跨0。未取整四项ST和为0.9100207055。
- 2021优化候选符合发表产量15.86 t/ha对应的95%门槛。水量回放和减灌分解相符；深剖面储水为模型量。

## 文件结构

- `delivery/`：5页中文复核报告Word/PDF、11工作表Excel、逐项判断CSV。
- `evidence/`：287项检查记录、原链重算指标、气象/Es/生物量/CC/Sobol/门槛/水量复核表，以及原论文有关页文字和两张页面图像。
- `independent_review.py`：独立只读核验脚本，读取已有链、响应与逐日记录，不调用AquaCrop运行，不画图。
- `read_complete_results.py`：无损响应解码工具；`sobol_lossless_markers/`记录原JSONL日志哈希与列压缩的关系。
- `build_review_report.py`：根据 evidence 生成Word和Excel。PDF另由LibreOffice转换。
- `requirements.txt`：本次实际使用版本，Python 3.12.14；`DELIVERY_QA.json`和`SHA256SUMS.txt`提供环境、范围与校验信息。

## 在PyCharm重做独立数值核验

本补充包不重复装入已交付的原始大文件。先将以下两个既有包解压：

1. `URP_Audited_Figures_Code_Data_Analysis.zip`，根目录 `URP_Audited_Figures`，2026-11-07版本。
2. `URP_PyCharm_All_Figures_Tables_Reproduction.zip`，根目录 `URP_Paper_Figure_Reproduction`，含20份MCMC原始检查点。

用Python 3.12环境安装 `python -m pip install -r requirements.txt` 后，在本包根目录运行（路径按本机实际位置替换）：

```text
python independent_review.py --package "D:/URP/URP_Audited_Figures" --original "D:/URP/URP_Paper_Figure_Reproduction" --output evidence
python build_review_report.py
```

第一条只读取两个旧包，写入本包 evidence；第二条写入本包 delivery。ArviZ版本固定为0.22.0，与归档审计一致；其他ESS实现的有限滞后处理可能有细小方法差异。新增独立重读不能恢复缺失的历史LAI取点项目，核验代码不会自动改动观测目标。

注意：run.json的responses_sha256对应原responses.jsonl字节，不应拿它与response_matrix.npy字节SHA直接比较。脚本另核设计/指数/NPY文件哈希，并解码无损列验证完整数值相同。

## 既有数据包链接（固定提交）

- https://raw.githubusercontent.com/yuzhenwu920-afk/URP/d18d15d41d7007f4880d86191e5845d687276913/deliverables/2026-11-07-audited-figures/URP_Audited_Figures_Code_Data_Analysis.zip
- https://raw.githubusercontent.com/yuzhenwu920-afk/URP/b0de404a450b0a402f8c1d65771824d5442bb5c7/deliverables/2026-11-07-paper-figure-reproduction/URP_PyCharm_All_Figures_Tables_Reproduction.zip

本次确认的是可读取资料的来源对应及数值一致性。所有数值检查通过不等于所有科学问题已解决；报告逐项列出仍需补充的证据与解释范围。
