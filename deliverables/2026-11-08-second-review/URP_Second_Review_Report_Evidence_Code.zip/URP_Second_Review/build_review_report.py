from pathlib import Path
import json,csv
import pandas as pd
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent;E=ROOT/'evidence';D=ROOT/'delivery';D.mkdir(exist_ok=True)
FINDINGS=[
('图3：ETo','计算链已补证；精度检验分开','四年B组导出可从气象分量复算，且输入文件哈希与原MCMC合同一致。原GEE小时提取脚本、独立站点精度对照仍未补齐。'),
('图5、7：生物量','2022来源可对应；2019有读数分歧','2022十点与论文图4-8的DI日期、单位及柱高相符；原RMSE可复算。2019两个早期点与新重读差约0.34、0.41 t/ha，保留原目标并列示。'),
('图4：LAI与CC','算术正确；追溯仍不完整','48行LAI换算、日期配对和指标正确。历史取点像素/项目仍缺；来源为DI文献图，不以BI遥感文件替代。'),
('图6：参数区间','真实的采样精度问题','原始20份链复算与归档一致；四年第一阶段未达预设诊断目标。第二阶段各仅一个独立ensemble。分位数可算对，分布精度仍需分别评价。'),
('图9、10：Sobol','原始数值齐全；近排序解释需保留限制','61,440行响应与12套设计可复算指数。2022新区间从原始响应重新生成并核对；旧区间随机状态未恢复。WP_early与Kcb的近排序不宜作强解释。'),
('图11：产量门槛','定义问题；发表值口径达标','优化代码和最终可行解使用95%发表观测产量。2021年门槛15.06700、候选15.06841458 t/ha；内部目标对应另一门槛。'),
('图12：水量与回放','数值相符；统计范围应明确','4个候选和8个基准/候选的最大原单位差均为1.14e−13；全部120行回放为2.27e−13。储水差属于模拟0–2.4 m剖面。'),
('表2：Es与Tr来源','Es原疑点需更正；另有拟合偏差','论文正文第39页明确报告76、79、78、81 mm。旧“近似重建”标签应更正为文献报告值；Tr代码目标分列。2019、2022年Es模拟偏差应另行报告。'),
('图8、13、14、15','未发现具体数值错误','逐日账、事件合计及末代超体积已有相符记录。图15的逐代曲线由日志汇总，现有交付缺逐代种群快照，不把末代核验扩大为所有代原始种群重算。'),
]

def p(doc,text,size=10.5,bold=False):
    x=doc.add_paragraph();x.paragraph_format.space_after=Pt(6);x.paragraph_format.line_spacing=1.22
    r=x.add_run(text);r.font.name='Times New Roman';r.font.size=Pt(size);r.font.bold=bold;r._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'SimSun');return x

def table(doc,head,rows,size=9,widths=None):
    t=doc.add_table(rows=1,cols=len(head))
    for c,s in zip(t.rows[0].cells,head):c.text=str(s)
    for row in rows:
        for c,s in zip(t.add_row().cells,row):c.text=str(s)
    if widths:
        t.autofit=False
        for col,w in zip(t.columns,widths):col.width=Cm(w)
        for row in t.rows:
            for c,w in zip(row.cells,widths):c.width=Cm(w)
    for j,row in enumerate(t.rows):
        pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        if j==0:pr.append(OxmlElement('w:tblHeader'))
        for c in row.cells:
            borders=OxmlElement('w:tcBorders')
            for side in ['top','left','bottom','right']:
                e=OxmlElement('w:'+side);e.set(qn('w:val'),'nil');borders.append(e)
            for side,size0 in ([('top','10'),('bottom','5')]if j==0 else [('bottom','10')]if j==len(t.rows)-1 else []):
                b=borders.find(qn('w:'+side));b.set(qn('w:val'),'single');b.set(qn('w:sz'),size0)
            c._tc.get_or_add_tcPr().append(borders)
            for para in c.paragraphs:
                para.paragraph_format.space_after=Pt(4)
                for r in para.runs:r.font.name='Times New Roman';r.font.size=Pt(size);r.font.bold=j==0;r._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'SimSun')
    return t

def main():
    d=Document();sec=d.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=sec.right_margin=Cm(1.8);sec.top_margin=sec.bottom_margin=Cm(1.8)
    for name in ['Title','Heading 1','Heading 2']:
        st=d.styles[name];st.font.name='Times New Roman';st.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'SimHei');st.font.color.rgb=RGBColor.from_string('244A58')
    d.add_heading('URP二次复核：问题是否仍然存在',0)
    p(d,'2026年11月8日交付｜数值复核完成于11月7日｜对象：最新版资料及四年原始MCMC链',10)
    p(d,'结论：部分旧疑点已补证，部分问题仍真实存在。本轮数值重算相符，不等于采样诊断达标或田间效果已验证。原图和模型均未改动，也未新增MCMC或优化。')
    table(d,['对象','本轮判断','核验依据与解释'],FINDINGS,9,widths=[2.7,4.1,10.6])
    d.add_page_break();d.add_heading('1　MCMC：数值区间算对，采样精度问题仍在',1)
    a=pd.read_csv(E/'MCMC_annual_recomputed.csv');g=pd.read_csv(E/'MCMC_all_640_parameter_groups.csv');rows=[]
    for r in a[a.Phase==1].itertuples():
        s=g[g.Year==r.Year]
        rows.append([int(r.Year),int(r.Burn_in),int(r.Retained_steps),f'{r.Worst_matched_group_Rhat:.6f}',f'{r.Minimum_matched_group_bulk_ESS:.2f}',f'{s.Rhat.median():.6f}'])
    table(d,['Year','Burn-in','Retained steps','Worst Rhat','Min group ESS','Median group Rhat'],rows)
    p(d,'每年第一阶段为4个独立ensemble、每个32个walkers、2000步。本轮重新计算原始链的自相关时间与ceil(5×max τ)预热截取，重算32组同编号walker跨独立ensemble的秩归一化分裂Rhat和bulk ESS，并与归档核对。采用原审计同版ArviZ 0.22.0。上表ESS是这些组的最小值，不是所有存储样本的总ESS，32个相关组也没有相加。')
    p(d,'四年的中位数组Rhat仍高于1.01，因此结论并非只来自少数极端组。第一阶段链长约为最大τ的25.38～31.55倍，也未达原50τ经验参考。第二阶段每年仅一个独立ensemble，本轮重算其均值和分位数，但没有把耦合walkers当成独立重复来补出跨ensemble的Rhat。')
    p(d,'均值、2.5%和97.5%分位数与归档相符，图6的算术未发现错误；这些数值宜称为保留样本的经验区间。参数未越出先验支持范围，同时存在局部边界集中：2019、2020年CCx在上界1%邻近带的质量为22.14%、23.06%，2020、2021年WP_early在下界1%邻近带为11.43%、23.65%。结果应按具体分布报告，而不笼统表述为完全无边界问题或已证明无偏。')
    d.add_heading('2　Es来源已明确，分量拟合另有偏差',1)
    p(d,'王尚今论文正文第39页（PDF第49页）明确写出DI总土壤蒸发量76、79、78、81 mm，并说明微型蒸渗仪观测及水汽闭合、数据校准处理。它们可标为文献报告的季节观测值；将其一概称作无原始出处的“近似重建”不准确。正文第41页另报告Tr为586、558、549、503 mm。代码前三年使用ET−Es，2022年使用503.0 mm，故Tr目标来源仍应分列。')
    flux=pd.read_csv(E/'Observed_targets_vs_frozen_model_fluxes.csv')
    table(d,['Year','Es literature','Es model','Es RE (%)','ET RE (%)','Tr RE (%)'],[[int(r.Year),f'{r.Es_target:.2f}',f'{r.Es_model:.2f}',f'{r.Es_RE_pct:+.2f}',f'{r.ET_RE_pct:+.2f}',f'{r.Tr_RE_pct:+.2f}']for r in flux.itertuples()])
    p(d,'本轮新增确认：2019年Es模拟97.23 mm，较76 mm高21.23 mm（27.94%）；2022年模拟66.85 mm，较81 mm低14.15 mm（−17.47%）。这反映冻结参数下的耗水分量拟合偏差，应在结果中与总体ET和生长指标同时报告。两年Es绝对偏差约为代码假定15 mm误差尺度的1.42倍和0.94倍，解释时同时保留绝对量及所用误差权重，避免仅用高R²概括全部过程精度。')
    d.add_page_break();d.add_heading('3　ETo：归档计算可重建，气象精度属于另一层证据',1)
    a=pd.read_csv(E/'ETo_independent_comparison.csv')
    table(d,['Year','Uploaded ETo','Export A','Used B','B − uploaded'],[[int(r.Year),f'{r.Uploaded_ETo:.2f}',f'{r.Export_A_ETo:.2f}',f'{r.Used_B_ETo:.2f}',f'{r.Used_minus_uploaded:.2f}']for r in a.itertuples()])
    p(d,'单位为mm，四年均按实际模型执行日期对齐。B组由导出的温度、净辐射、气压、水汽压差和2 m风速重算，与实际驱动逐日一致。A、B之间的主要定义差别是风速取法；对风速模长取小时平均与对日均风矢量求模不同。原上传序列又不完全等于导出A组，因此不将两者直接混称。')
    p(d,'20份原始MCMC检查点的合同中，气象、ETo、LAI和生物量文件哈希与本次读取的文件一致，支持这些B组序列属于原计算输入，而非仅在出图时更换。历史GEE小时提取脚本尚未恢复，独立气象站逐日精度也未在本轮验证。图3应明确“模型采用的ERA5-Land派生驱动”，统计期称为模型执行期。')
    d.add_heading('4　生物量与CC：2022已补证，历史读数记录仍需区分',1)
    p(d,'原论文图4-8（正文第48页/PDF第58页）的2022面板为橙色DI柱。10个日期、kg/ha转t/ha的单位以及柱高可对应，独立重读与原校准目标最大差约0.0762 t/ha。原2022年RMSE=0.5561589 t/ha可复算；四年37点回归与去除2022后的27点回归OLS R²分别为0.989152、0.987217，未显示汇总拟合仅由2022年支撑。')
    p(d,'仍需确认2019年6月4日、6月12日两处读数：原值1.2、2.0 t/ha，新重读约1.544、2.415 t/ha。超出0.3 t/ha的既有读数容差属于需要核对的数字化分歧，并不等同于原始田间数据错误。模型未重拟合，旧目标和新读数继续分列；若最终采纳新值，应同步重估受影响的校准。')
    p(d,'新版F05表仍保留旧Axis_top_px、Axis_zero_px等空栏；本次重读坐标在Axis_top_px_recheck等字段及Biomass_thesis_pixel_recheck.csv。这是表结构容易误读的问题。本轮提供2022_DI_biomass_unified_source_record.csv，将有效来源、使用状态及重读坐标放入单一清晰记录；这些是本次重读坐标，不冒称找回了历史取点项目。')
    p(d,'CC的48行DI LAI→CC换算、按日配对和指标均可重算，且与优化基准使用同一组逐日冠层、生物量模拟，没有发现两套模拟曲线混用。历史LAI取点项目和逐点原像素仍缺，因此该项追溯尚不完整。图5、7的资料参与过校准，统计量描述校准一致性；独立验证需另有未参与拟合的资料。')
    d.add_page_break();d.add_heading('5　Sobol：响应齐全，旧区间与新区间需区分',1)
    p(d,'4年×3次scramble的输入设计共61,440行，8参数混合矩阵结构、原始响应与S1/ST均已重新核对。本轮还将无损逐列响应解码，与response_matrix.npy逐值比较；run.json中的responses_sha256对应原responses.jsonl日志，不能直接拿它当作NPY文件的哈希。附带LOSSLESS_REPACK记录明确这一来源关系。')
    p(d,'2022年的2048组新bootstrap抽样已由原始响应和公开种子重新生成，与新区间一致。WP_early−Kcb的差值为0.000077，成对95%数值区间约[−0.0139,0.0138]；2021年的相应区间也跨0。因此主要参数层级可以描述，微小相邻次序不作可靠区分。新区间不等于恢复了历史随机状态，仍称数值bootstrap区间。')
    p(d,'四个ST均值的未取整和为0.9100207055，保留三位小数应为0.910；先将0.396、0.206、0.164、0.145各自取整再相加会得到0.911。该差异属于取整顺序，按原精度修正即可。总效应含交互贡献，四项之和也不解释为四个参数独立解释的方差份额。')
    d.add_heading('6　优化门槛与回放：定义核清，未发现候选算错',1)
    gate=pd.read_csv(E/'Yield_gate_independent.csv')
    table(d,['Year','Published gate','Internal gate','Candidate Y','Margin vs published'],[[int(r.Year),f'{r.Published_gate:.5f}',f'{r.Internal_gate:.5f}',f'{r.Candidate_yield:.5f}',f'{r.Margin_published:+.6f}']for r in gate.itertuples()])
    p(d,'原优化代码OBS明确为16.55、17.29、15.86、14.08，目标约束采用0.95×OBS，最终可行解也逐一符合该定义。2021年候选对发表门槛高0.00141458 t/ha；相对内部目标门槛则低0.00048542 t/ha。内部目标并非另一份已证实更精确的实测值，不在筛选中混用。')
    a=pd.read_csv(E/'Replay_scope_independent.csv')
    table(d,['Scope','N','Native max difference'],[[r.Scope,int(r.N),f'{r.Native_max_difference:.6e}']for r in a.itertuples()])
    p(d,'图12的减灌分解与八份逐日账相符。2021年减灌368.97 mm，其中ET只减少11.46 mm，季末储水差356.85 mm来自0–2.4 m模拟剖面。回放差值说明两种模型执行方式的数值一致性；季末储水差的田间实证仍需要对应剖面的观测。')
    p(d,'图8、13、14暂未发现具体数值错误。图15的曲线可按逐代日志重建，已有核验覆盖种子汇总及末代解集超体积；当前五期结果归档没有逐代种群快照。本轮不把这种范围表述为所有代原始种群均已独立重算。')
    d.add_heading('后续优先事项',1)
    for s in ['优先处理MCMC分布采样精度，论文保留真实诊断及经验区间口径，不用均值稳定或高拟合R²替代收敛证据。',
              '补充耗水分量偏差表，确认2019年两个生物量读数；采纳更改时联动相应校准，而不单改散点或统计值。',
              '继续找回LAI历史取点记录和GEE小时提取原脚本；需要逐代HV独立复算时，再补原始种群快照。已补证的Es来源和2022 DI生物量不再重复写成“完全无出处”。']:
        p(d,'• '+s)
    p(d,'原始依据：王尚今（2023）学位论文正文第39、41、44、48、53页；原MCMC检查点及合同；原Sobol设计/无损响应；冻结模型逐日账与五期优化源代码。本轮保留原图、原代码结果及所有原校准目标。',9)
    d.save(D/'URP_Second_Review_Findings_CN.docx')
    pd.DataFrame(FINDINGS,columns=['对象','判断','依据']).to_csv(D/'Review_verdicts_CN.csv',index=False,encoding='utf-8-sig')
    with pd.ExcelWriter(D/'URP_Second_Review_Evidence.xlsx',engine='openpyxl')as writer:
        for src in ['MCMC_annual_recomputed','MCMC_parameters_recomputed','ETo_independent_comparison','Observed_targets_vs_frozen_model_fluxes','2022_DI_biomass_unified_source_record','2022_biomass_source_schema','Pooled_regression_independent','Sobol_near_ties_independent','Yield_gate_independent','Replay_scope_independent','Water_decomposition_independent']:
            pd.read_csv(E/(src+'.csv')).to_excel(writer,sheet_name=src[:31],index=False)
        for ws in writer.book.worksheets:ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
    print('Report and evidence workbook created',flush=True)

if __name__=='__main__':main()
