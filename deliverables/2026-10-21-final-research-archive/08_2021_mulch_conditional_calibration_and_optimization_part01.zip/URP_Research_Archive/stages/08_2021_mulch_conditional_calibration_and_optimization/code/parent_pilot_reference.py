"""User-authorized short-chain experiment: 4 ensembles, 500 steps, 10 walkers.
Phase 2 proceeds conditionally for a PILOT even if formal phase-1 criteria fail.
Formal diagnostic thresholds are retained and never relabeled as passed.
"""
from pathlib import Path
import os,sys,json,hashlib,time,contextlib,traceback
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp
import numpy as np
import pandas as pd
from pilot_engine import ROOT,PROJECT,SOURCE,load,dump
STEPS=500;WALKERS=10;BURN=250;ENSEMBLES=4;SEED=42

def worker(task):
    phase,names,fixed,e=task
    out=ROOT/'runs'/phase;out.mkdir(parents=True,exist_ok=True)
    with (out/f'ensemble_{e+1}.log').open('a',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        t=time.time();driver,m,data,start=load(True,phase+f'_{e+1}')
        lower=np.array([m.PRIOR_BOUNDS[k][0] for k in names]);upper=np.array([m.PRIOR_BOUNDS[k][1] for k in names])
        # Warm compiled kernels once in this process, without changing likelihood.
        m.simulate(data,fixed)
        sampler=sys.modules['_di_2021_sampler']
        cn=dict(Experiment='Zmax_1m_2021_PILOT',Names=names,Fixed=fixed,Bounds=m.PRIOR_BOUNDS,
            Steps=STEPS,Walkers=WALKERS,Ensembles=ENSEMBLES,Seed=SEED,Ensemble=e,
            Zmax_m=1.,Zmin_m=.3,Original_source_SHA256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            Harness_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            Engine_SHA256=hashlib.sha256(Path(__file__).with_name('pilot_engine.py').read_bytes()).hexdigest())
        x,p,a=sampler.run_ensemble(lambda v:m.logprob(v,names,fixed,phase,data),
            np.array([fixed[k] for k in names]),lower,upper,STEPS,WALKERS,
            SEED+m.YEAR*100+e+(100000 if phase=='biomass_yield' else 0),out/f'ensemble_{e+1}.npz',cn,25)
        print('COMPLETE seconds',time.time()-t,flush=True)
        return dict(ensemble=e,seconds=time.time()-t)

def analyze(driver,m,data,phase,names,fixed):
    out=ROOT/'runs'/phase
    xs=[];ps=[];aa=[]
    for e in range(ENSEMBLES):
        with np.load(out/f'ensemble_{e+1}.npz',allow_pickle=False) as f:
            xs.append(f['history']);ps.append(f['logs']);aa.append(f['accepted'])
    raw,logs,accept=np.array(xs),np.array(ps),np.array(aa)
    lower=np.array([m.PRIOR_BOUNDS[k][0] for k in names]);upper=np.array([m.PRIOR_BOUNDS[k][1] for k in names])
    formal=sys.modules['_di_2021_ensemble_pipeline'].analyze(phase,names,raw,logs,accept,lower,upper,out,False)
    retained=raw[:,BURN:];retlogs=logs[:,BURN:]
    idx=np.unravel_index(np.argmax(retlogs),retlogs.shape);best=dict(fixed,**dict(zip(names,map(float,retained[idx]))))
    dg=sys.modules['_di_2021_diagnostics']
    groups=[dg.diagnose(retained[:,:,w,:],names) for w in range(WALKERS)]
    rows=[]
    for j,k in enumerate(names):
        a=retained[:,:,:,j].ravel();lo,hi=m.PRIOR_BOUNDS[k];width=hi-lo
        q=np.quantile(a,[.025,.5,.975]);r=[g[j]['Rhat'] for g in groups];ess=[g[j]['ESS_bulk'] for g in groups];tail=[g[j]['ESS_tail'] for g in groups]
        rows.append(dict(Phase=phase,Parameter=k,Pilot_mean=float(a.mean()),Pilot_SD=float(a.std(ddof=1)),Pilot_q025=q[0],Pilot_median=q[1],Pilot_q975=q[2],
            Pilot_best_sample=best[k],Prior_low=lo,Prior_high=hi,Best_distance_to_lower_fraction=(best[k]-lo)/width,Best_distance_to_upper_fraction=(hi-best[k])/width,
            Best_within_1pct_bound=bool(min(best[k]-lo,hi-best[k])<=.01*width),
            Mass_lower_1pct=float((a<=lo+.01*width).mean()),Mass_upper_1pct=float((a>=hi-.01*width).mean()),
            Mass_lower_5pct=float((a<=lo+.05*width).mean()),Mass_upper_5pct=float((a>=hi-.05*width).mean()),
            Rhat_max_matched_walker_groups=max(r) if all(v is not None for v in r) else None,
            ESS_bulk_min=min(ess),ESS_tail_min=min(tail),Formal_convergence=False,Pilot_burn=250,
            Summary_scope='last 250 steps of short pilot; NOT converged posterior'))
    pd.DataFrame(rows).to_csv(ROOT/'tables'/f'{phase}_pilot_parameter_diagnostics.csv',index=False)
    # Full draw table from original pipeline, plus explicitly identified pilot-retained draws.
    full=pd.read_csv(out/f'mcmc_full_chain_{phase}.csv');full[full.Step>=BURN].to_csv(out/'pilot_retained_draws_last250.csv',index=False)
    values=dict(Phase=phase,Values=best,Selection='Highest sampled log posterior among pilot steps 250..499 (zero based)',
        Highest_log_posterior=float(retlogs[idx]),Converged=False,Formal_diagnostics=phase+'_diagnostics.json',
        Continuation='Second phase continues as user-requested pilot, not as converged sequential inference')
    dump(out/'PILOT_SELECTED_PARAMETERS.json',values)
    np.savez_compressed(out/'pilot_arrays.npz',raw=raw,logs=logs,accepted=accept)
    return best

def main():
    dump(ROOT/'runs/RUN_STATUS.json',dict(State='RUNNING_PHASE1',Steps=STEPS,Walkers=WALKERS,Independent_ensembles=4,Converged=False))
    driver,m,data,start=load(True,'coordinator')
    priors={k:dict(Bounds=m.PRIOR_BOUNDS[k],Distribution='truncated_normal' if k in m.NORMAL_PRIORS else 'uniform',
        Mean=data['center'].get(k) if k in m.NORMAL_PRIORS else None,SD=m.PRIOR_SD.get(k) if k in m.NORMAL_PRIORS else None) for k in m.ALL_NAMES}
    dump(ROOT/'verification/EXPERIMENT_CONFIG.json',dict(Year=2021,Zmax_m=1.,Zmin_m=.3,MulchPct=75.,fMulch=0.,
        Steps=STEPS,Walkers=WALKERS,Ensembles=4,Pilot_burn=250,Original_source=str(SOURCE),Priors=priors,
        Original_formal_minimum_steps=2000,Original_formal_gate_bypassed_for_user_requested_pilot=True,
        Tr_target=m.TR_TARGET,Es_target=m.ES_TARGET,ET_observed=m.ET_OBS,Y13_likelihood_target=m.Y13_TARGET,Y13_published=m.Y13_PUBLISHED,
        Sigmas=dict(CC=m.SIGMA_CC,Tr=m.SIGMA_TR,Es=m.SIGMA_ES,Ydry=m.SIGMA_Y),Observed_irrigation_mm=float(data['schedule'].Depth.sum()),
        Scope='conditional two-stage calibration; not joint 8D posterior; observations reused for fitting are not validation'))
    for phase,names in [('canopy_transpiration',m.PHASE1_NAMES),('biomass_yield',m.PHASE2_NAMES)]:
        fixed=start
        with ProcessPoolExecutor(max_workers=4,mp_context=mp.get_context('spawn')) as pool:
            for result in pool.map(worker,[(phase,names,fixed,e) for e in range(ENSEMBLES)]):print(phase,result,flush=True)
        start=analyze(driver,m,data,phase,names,fixed)
        dump(ROOT/'runs/RUN_STATUS.json',dict(State='RUNNING_PHASE2' if phase=='canopy_transpiration' else 'PILOT_SAMPLING_COMPLETE',
            Complete=phase=='biomass_yield',Formal_convergence=False,Steps=STEPS,Walkers=WALKERS,Independent_ensembles=4))
        print('PHASE COMPLETE',phase,start,flush=True)
    dump(ROOT/'tables/SELECTED_PILOT_PARAMETERS.json',start)

if __name__=='__main__':
    try:main()
    except BaseException as exc:
        dump(ROOT/'runs/RUN_STATUS.json',dict(State='FAILED',Error=str(exc),Formal_convergence=False));raise
