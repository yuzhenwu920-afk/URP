"""Current documentation and provenance after successful actual computation."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
import platform
import pandas as pd

ROOT=Path(__file__).resolve().parent;REPO=Path('/workspace/URP');PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED'
sys.path.insert(0,str(PROJECT))
from model_adapter import load_study,RealModel,read,write,sha,versions


def main():
    study=load_study();model=RealModel(study);run=PROJECT/'output_real_20261019'
    status=read(run/'EXPERIMENT_STATUS.json');assert status['status']=='COMPLETE'
    for name,digest in status['frozen_input_hashes'].items():assert sha(PROJECT/name)==digest
    audit=ROOT/'delivery_audit';audit.mkdir(exist_ok=True)
    for name in ['NUMERICAL_EQUIVALENCE.json','WORKFLOW_TEST_VALIDATION.json','SAMPLING_BOUNDS_FIX.json',
        'WORKFLOW_TESTS.log','ENVIRONMENT_REPLAY.log','SOBOL_FINAL_CHECKS.log']:
        shutil.copyfile(ROOT/name,audit/name)
    shutil.copytree(ROOT/'executed_sources',audit/'executed_at_run_start',dirs_exist_ok=True)
    for name in ['run_four_year_experiment.py','model_adapter.py','validate_candidates.py','plot_results.py']:
        shutil.copyfile(PROJECT/name,audit/name)
    intake=read(ROOT/'replacement_sources/source_intake_report.json')
    write(audit/'NEW_ANNUAL_SOURCE_INTAKE.json',intake)
    write(audit/'RUNTIME_SOURCE_UPDATES.json',{
        'executed_phaseB_and_phaseC_match_run_start_hashes':True,
        'post_start_sampling_bound_fix':'Adds clipping for tighter synthetic bounds; 2,000 actual-space samples checked bitwise unchanged.',
        'post_start_Sobol_reporting_fix':'Only the Next_action text changes after N512 rank ties; indices and estimators unchanged.',
        'late_loaded_validation_source':'Wilson endpoints clamped to theoretical [0,1] and empirical-pool MC interpretation documented.',
        'late_loaded_plot_source':'Improved fonts, year palette and five-seed bands; no numeric effect.',
        'current_source_sha256':{n:sha(PROJECT/n) for n in ['phaseB_sobol.py','phaseC_nsga3.py','validate_candidates.py','plot_results.py']}})
    for p in ['EXPERIMENT_STATUS.json','RUN_SOURCE_MANIFEST.json','SOBOL_EXPANSION_DECISION.json','NESTED_DESIGN_REUSE.json']:
        shutil.copyfile(run/p,audit/p)
    write(audit/'FROZEN_MCMC_UNCHANGED.json',{'passed':True,'hashes':status['frozen_input_hashes'],'original_MCMC_not_rerun':True})
    write(PROJECT/'ANALYSIS_ENVIRONMENT.json',{'python':sys.version,'platform':platform.platform(),'versions':versions(),'validated_by':'20 workflow checks, four baselines and 28 equation comparisons'})
    write(PROJECT/'SOFTWARE_VALIDATION.json',{'tests_run':20,'passed':True,'synthetic_tests_not_crop_results':True,
        'four_original_baselines_reproduced':True,'early_harvest_calendar_test_passed':True,'actual_experiment_complete':True,
        'numerical_comparison':read(ROOT/'NUMERICAL_EQUIVALENCE.json'),'evidence':'verification/WORKFLOW_TESTS.log'})
    write(PROJECT/'RUN_READINESS.json',{'available_years':[2019,2020,2021,2022],'all_original_inputs_and_sources_connected':True,
        'Sobol_and_optimization_computed':True,'MCMC_frozen':True,'science_limitations':'MCMC strict diagnostics, no independent field validation, no original terminal-storage gate'})
    current=(PROJECT/'.gitignore').read_text()
    for line in ['output_real/','output_real_20261019/','actual_publication_20261019/']:
        if line not in current.splitlines():current+=line+'\n'
    (PROJECT/'.gitignore').write_text(current)
    (PROJECT/'README.md').write_text('''# 四年真实Sobol与NSGA-III工程

2019、2020、2021、2022原年度源码和基础输入均已接入；四年Y13/Tr/Es/ET基准复现。20项工程检查通过，28个原方程/加速对照案例最大差约1.14e-13。原MCMC冻结，严格诊断限制未被下游计算消除。

正式实验已完成：Sobol N512×3种子，最终61,440行真实响应；NSGA-III与同预算NSGA-II各100个体×100代×5种子×4年，总400,000次评估、4,000代完整种群。23/24项Sobol筛查通过，2022产量WP early/Kcb第三、四名近似并列。当前全部八参数保留，未据该名次删参。

## 一键复跑

推荐Python3.12及根requirements。勿直接运行real_model/model_YYYY/中的原年度OneClick入口，它们默认启动MCMC。

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 NUMBA_NUM_THREADS=1 python run_four_year_experiment.py --workers 4 --out /workspace/new_four_year_run
```

正式入口run_four_year_experiment.py显式分开Sobol数值审查和确定性优化，保留2022的微小排序不确定性。原DI_PHASE3_ONE_CLICK.py为兼容入口，其all模式仍保留严格Sobol筛查拦截；需要独立运行时可选择--phase sobol或--phase optimization。

Sobol为公共独立均匀范围，不是相关后验Sobol。提前成熟/死亡时保留实际收获产量，后续土壤水量核算至原日历截止日，维持覆膜并停止收获后灌水。记录实际收获日与取消量。所有响应检查逐日水量守恒，不删失败点、不填零。

优化变量是四个有序灌溉窗口总量，原日期和窗口内原比例固定，不是SMT或灌期优化。目标min(-Y13,I实际)，门槛为I≤原DI、Y13≥95%发表观测；初始化和修复同时限制计划总量预算。五种子同预算NSGA-II为对照，候选按ε门槛内最低I选择，不称几何膝点。

## 查看与复建图文

包内图表索引.html与figures含32组当前四年图；其中18组校准背景（流程/气象已更新）及14组新增真实结果。PNG、PDF、Word和Excel可独立使用。Word主文包含方法解释、实际数值表、原校准图与新增图及逐图说明。

完整/运行/工程ZIP的complete_runs包含全部设计、响应和各代X/F/G/CV的无损数据。运行python read_complete_results.py archive.npz --csv result.csv可导出完整响应；Python读取用load_columns，浮点精度未降低。原大矩阵的CSV文本仅是二进制的重复表达，未重复存放。

在包含完整运行记录的交付目录中可复建新图：

```bash
python publish_actual_results.py --run ../complete_runs --out ../recreated_publication
python -m pip install -r publication_tools/requirements_publication.txt
# Word可编辑公式转换需要Pandoc；当前环境已验证。
python publication_tools/build_actual_paper.py
python publication_tools/build_result_workbook.py
```

旧regenerate_four_year_figures.py仅用于历史18组校准背景重绘；当前新增Sobol/优化图请使用publish_actual_results.py。模型使用进程并行，避免线程共享原年度全局补丁。完整计算较长，先检查状态和现有进程，勿重复启动。已完成优化种子可校验后复用；中断种子应保留原件并在新目录重跑，不伪称精确续跑。

## 科学范围

条件扰动按阶段一/阶段二分别整行抽128组，固定另一组中心，不拼成联合后验。Wilson区间只覆盖给定经验样本池的重采样MC误差。主候选未约束季末土壤储水；新增同储水条件筛查只是在已评估点中选点并回代，不是带新约束重新优化。灌水节省不能全部写成耗水节省或多年可持续效益。细节见SCIENCE_REVIEW.md。

real_model各年度原manifest与data保持原件；frozen_inputs存放冻结数组、中心与原配对输出。其他旧日期说明为历史审查记录，不覆盖本轮当前结果。
''',encoding='utf-8')
    for name in ['build_actual_paper.py','build_result_workbook.py']:
        text=(ROOT/name).read_text().replace("PROJECT=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')",'PROJECT=Path(__file__).resolve().parents[1]')
        (PROJECT/'publication_tools'/name).write_text(text)
    for name in ['read_complete_results.py','verify_all_actual_results.py','write_interactive_index.py']:
        shutil.copyfile(ROOT/name,PROJECT/'publication_tools'/name)
    write(audit/'CURRENT_SOURCE_FILE_HASHES.json',{'files':[{ 'file':p.relative_to(PROJECT).as_posix(),'sha256':sha(p)}
        for p in sorted(PROJECT.rglob('*.py')) if not any(n.startswith('output') for n in p.relative_to(PROJECT).parts)]})
    print('Current source/docs and provenance finalized',flush=True)


if __name__=='__main__':main()
