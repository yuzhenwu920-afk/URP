"""Rebuild the six existing delivery URLs from one verified four-year result set."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
import os

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/URP');PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED'
PUBLICATION=PROJECT/'actual_publication_20261019';RUN=ROOT/'compact_results'
STAGE=ROOT/'staged_six';AUDIT=ROOT/'delivery_audit'
DEST=REPO/'deliverables/2026-10-19-actual-results'
YEARS=[2019,2020,2021,2022]
PATHS=[
 ('full',REPO/'deliverables/URP_full_package.zip'),
 ('run',REPO/'deliverables/URP_run_results.zip'),
 ('figures',REPO/'deliverables/URP_figures.zip'),
 ('update',REPO/'deliverables/2026-10-16/URP_update_20261016.zip'),
 ('execution',REPO/'deliverables/2026-10-16-execution-ready/URP_execution_ready_20261016.zip'),
 ('engineering',REPO/'deliverables/2026-10-16-sobol-optimization/URP_Sobol_Optimization_Updated.zip')]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path,value):path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2))
def copy(source,dest):dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
def tree(source,dest,ignore=None):shutil.copytree(source,dest,dirs_exist_ok=True,ignore=ignore)


def copy_engine(dest):
    names=['__pycache__','.cache','.git','output_revised','output_real','output_real_20261019',
        'actual_publication_20261019','four_year_figures','history_20261017','MANIFEST.json','SHA256SUMS.txt','图表索引.html']
    # Keep each frozen annual manifest: source/data hash checks use them.
    def ignore(folder,entries):
        skip=[]
        for n in entries:
            if n in ['__pycache__','.cache','.git']:skip.append(n)
            elif Path(folder)==PROJECT and n in names:skip.append(n)
        return skip
    tree(PROJECT,dest,ignore=ignore)
    (dest/'FIGURES_LOCATION.md').write_text('本包的当前32组四年图统一位于../figures；源参数与MCMC冻结数组在frozen_inputs。正式一键入口为run_four_year_experiment.py，原年度MCMC脚本仅作源模型，勿误点重新采样。\n')


def make_figure_set(dest):
    old=Path('/workspace/urp_review/artifacts/figures')
    for p in old.iterdir():
        if p.suffix in ['.png','.pdf']:copy(p,dest/p.name)
    for p in (PUBLICATION/'figures').iterdir():
        if p.suffix in ['.png','.pdf']:copy(p,dest/p.name)
    old_entries=read('/workspace/urp_review/artifacts/figure_captions.json')
    entries={Path(x['file']).stem:dict(name=Path(x['file']).stem,title=x['title'],caption=x['caption'],years=YEARS,
        source='frozen four-year calibration evidence',font_minimum_pt=x['min_font_pt']) for x in old_entries}
    for entry in read(PUBLICATION/'FIGURE_REGISTRY.json')['figures']:entries[entry['name']]=entry
    assert len(entries)==32
    files=[]
    for name,entry in entries.items():
        for suffix in ['png','pdf']:
            p=dest/f'{name}.{suffix}';assert p.exists()
            files.append({'file':p.name,'sha256':sha(p),'years':YEARS,'minimum_source_font_pt':entry['font_minimum_pt']})
    return list(entries.values()),files


def make_publication(dest):
    tree(PUBLICATION,dest,ignore=shutil.ignore_patterns('figures','__pycache__'))


def make_readme(folder,kind,engine):
    text=f'''# URP四年真实Sobol与NSGA-III结果

本包为2026-10-19启动的完整实验交付。覆盖2019、2020、2021、2022；原MCMC保持冻结。旧下载文件名中的日期保留以兼容原链接。

- Sobol：N=512×3种子×4年，61,440行最终设计全部获得真实模型响应；N128结果及精确前缀复用证据也保留。
- 优化：NSGA-III与同预算NSGA-II，各100个体×100代×5种子×4年，合计400,000次评估与4,000代完整种群记录。
- 图件：32组当前四年PNG/PDF，统一蓝/橙/绿/紫；包括原18组校准背景和14组新增真实敏感性/优化结果。F01流程及F10气象已更新。
- 论文：插入新增图与原校准图的Word，配套PDF、正文Markdown与Excel结果工作簿。各表与图片以文件名可互相追溯。

## 阅读顺序

1. 打开图表索引.html看图；publication中的Word包含模型解释、正文示例、结果表和逐图说明。
2. publication/tables与Excel为可阅读结果表；完整逐次响应及各代X/F/G/CV在complete_runs（完整/运行/工程包）。无损列文件可用read_complete_results.py还原为DataFrame或CSV。
3. formal_project为四年源码、气象/土壤/观测、冻结参数与复跑入口（完整/执行/工程包）；先读其README。

## 结果应怎样理解

Sobol输入为声明的公共独立均匀范围，不是相关MCMC后验。24个年份×输出中23个通过预设筛查；2022产量中WP early与Kcb贡献接近，第三/四名互换，保留排序不确定性。

优化固定年度参数中心，目标为min(−Y13,I实际)，约束I不超原DI、Y13不低于发表观测95%。四个有序窗口只调整水量，原日期与组内比例不变，不是SMT或灌期优化。主候选是ε约束内最低灌水量，不是几何膝点。

候选各参数组128次整行条件扰动不构成八维联合后验；原MCMC严格诊断限制仍保留。未设置季末储水下限，灌水减少须与耗水减少和季末储水变化一同解释。详细问题与完善方向见SCIENCE_REVIEW.md。

包类别：{kind}。引擎标识：{engine}。

所有数值完整性、四年覆盖与文件哈希见verification、FIGURE_COVERAGE_AND_STYLE.json和MANIFEST.json。历史代理试验不作为本包正式结果。
'''
    (folder/'README_先看这里.md').write_text(text,encoding='utf-8')


def manifest(folder):
    entries=[]
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.name not in ['MANIFEST.json','SHA256SUMS.txt']:
            entries.append({'file':p.relative_to(folder).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    write(folder/'MANIFEST.json',entries)
    (folder/'SHA256SUMS.txt').write_text(''.join(f"{e['sha256']}  {e['file']}\n" for e in entries))
    return entries


def archive(folder,path):
    entries=manifest(folder);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.pending.zip')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file():z.write(p,folder.name+'/'+p.relative_to(folder).as_posix())
    with zipfile.ZipFile(temp) as z:
        assert z.testzip() is None
        for e in entries:
            assert hashlib.sha256(z.read(folder.name+'/'+e['file'])).hexdigest()==e['sha256']
    assert temp.stat().st_size<99*1024**2,(path.name,temp.stat().st_size/1024**2)
    temp.replace(path)
    return {'path':path.relative_to(REPO).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path),
        'manifest_files':len(entries),'CRC':'PASS','all_file_hashes':'PASS','four_year_figure_groups':32}


def main():
    result=read(RUN/'ALL_RESULTS_VERIFICATION.json');assert result['status']=='PASS'
    status=read(RUN/'EXPERIMENT_STATUS.json');assert status['status']=='COMPLETE'
    if STAGE.exists():shutil.rmtree(STAGE)
    STAGE.mkdir();DEST.mkdir(parents=True,exist_ok=True)
    canonical=STAGE/'canonical_figures';entries,figure_files=make_figure_set(canonical)
    coverage={'years':YEARS,'groups':32,'PNG_dpi_new':320,'minimum_font_pt_new':11,
        'palette':{'2019':'#0072B2','2020':'#D55E00','2021':'#009E73','2022':'#A85AA0'},'files':figure_files}
    record=[]
    for kind,path in PATHS:
        folder=STAGE/path.stem;folder.mkdir()
        tree(canonical,folder/'figures')
        write(folder/'FIGURE_COVERAGE_AND_STYLE.json',coverage);write(folder/'FIGURE_CAPTIONS.json',entries)
        tree(AUDIT,folder/'verification')
        copy(ROOT/'SCIENCE_REVIEW.md',folder/'SCIENCE_REVIEW.md')
        if kind!='figures':make_publication(folder/'publication')
        if kind in ['full','run','engineering']:tree(RUN,folder/'complete_runs')
        if kind in ['full','execution','engineering']:copy_engine(folder/'formal_project')
        if kind=='run':
            for name in ['verified_phase_specific_draws.npz','combined_central_parameter_vectors.csv']:
                copy(PROJECT/'frozen_inputs'/name,folder/'frozen_parameters'/name)
        # The figure-only archive includes concise sensitivity/optimization tables.
        if kind=='figures':tree(PUBLICATION/'tables',folder/'tables')
        make_readme(folder,kind,status['engine'])
        from write_interactive_index import make_index
        make_index(folder,entries,PUBLICATION/'tables')
        item=archive(folder,path);record.append(item);print(path.name,round(item['bytes']/1024**2,2),'MiB',flush=True)
    write(DEST/'SIX_PACKAGE_VERIFICATION.json',{'status':'PASS','experiment':status,'all_results_audit':result,
        'all_six_updated':True,'same_figures_in_all_six':True,'archives':record})
    write(DEST/'FIGURE_COVERAGE_AND_STYLE.json',coverage)
    for name in ['URP_Sobol_NSGAIII_paper_with_actual_results.docx','URP_Sobol_NSGAIII_paper_with_actual_results.pdf',
                 'URP_Sobol_NSGAIII_paper_with_actual_results.md','URP_Sobol_NSGAIII_results_tables.xlsx']:
        copy(PUBLICATION/name,DEST/name)
    for name in ['R02_Sobol_Yield_CI.png','R03_Actual_Pareto_fronts.png']:copy(PUBLICATION/'figures'/name,DEST/name)
    copy(ROOT/'SCIENCE_REVIEW.md',DEST/'SCIENCE_REVIEW.md')
    (DEST/'SHA256SUMS.txt').write_text(''.join(f"{x['sha256']}  {x['path']}\n" for x in record))
    print('SIX ARCHIVES VERIFIED',flush=True)


if __name__=='__main__':main()
