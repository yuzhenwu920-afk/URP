
"""emcee ensembles with atomic, exact-RNG NumPy checkpoints (no pickle/HDF)."""
import json,os
from pathlib import Path
import numpy as np
import emcee

def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
    os.replace(temp,path)

def encode_rng(state):
    return json.dumps([state[0],state[1].tolist(),int(state[2]),int(state[3]),float(state[4])])

def decode_rng(value):
    x=json.loads(value)
    return (x[0],np.array(x[1],dtype=np.uint32),x[2],x[3],x[4])

def run_ensemble(logp,start,lower,upper,steps,walkers,seed,path,contract,checkpoint_every=25):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    lower=np.asarray(lower,float);upper=np.asarray(upper,float);dim=len(lower)
    if walkers<2*dim: raise ValueError('emcee needs at least 2*dimension walkers')
    encoded=json.dumps(contract,sort_keys=True,allow_nan=False)
    if path.exists():
        with np.load(path,allow_pickle=False) as f:
            if str(f['contract'].item())!=encoded: raise RuntimeError('Checkpoint contract mismatch; use a new output directory')
            x=f['position'];lp=f['logp'];rng=decode_rng(str(f['rng_state'].item()))
            hist=list(f['history']);logs=list(f['logs']);accepted=list(f['accepted'])
        actual=np.array([logp(v) for v in x])
        if not np.isfinite(actual).all() or not np.allclose(actual,lp,atol=1e-8,rtol=0):
            raise RuntimeError('Checkpoint log posterior cannot be reproduced')
    else:
        random=np.random.RandomState(seed);coords=[];probs=[]
        for _ in range(100000):
            v=np.asarray(start)+random.normal(0,.06,dim)*(upper-lower)
            if np.any(v<lower) or np.any(v>upper): continue
            p=logp(v)
            if np.isfinite(p): coords.append(v);probs.append(p)
            if len(coords)==walkers: break
        else: raise RuntimeError('Cannot initialize finite walkers')
        x=np.array(coords);lp=np.array(probs);rng=random.get_state();hist=[];logs=[];accepted=[]
    def save():
        temp=path.with_suffix('.npz.tmp')
        with open(temp,'wb') as f:
            np.savez_compressed(f,position=x,logp=lp,history=np.array(hist).reshape(-1,walkers,dim),
                logs=np.array(logs).reshape(-1,walkers),accepted=np.array(accepted,bool).reshape(-1,walkers),
                contract=encoded,rng_state=encode_rng(rng))
            f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
    if len(hist)>steps: raise RuntimeError('Requested steps are shorter than checkpoint')
    if not path.exists(): save()
    if len(hist)==steps: return np.array(hist),np.array(logs),np.array(accepted)
    sampler=emcee.EnsembleSampler(walkers,dim,logp)
    state=emcee.State(x,log_prob=lp,random_state=rng)
    for state in sampler.sample(state,iterations=steps-len(hist),store=False):
        accepted.append(np.any(state.coords!=x,axis=1))
        x=state.coords.copy();lp=state.log_prob.copy();rng=state.random_state
        hist.append(x.copy());logs.append(lp.copy())
        if len(hist)%checkpoint_every==0:
            save();print(path.name,'step',len(hist),'/',steps,flush=True)
    save()
    return np.array(hist),np.array(logs),np.array(accepted)

