
import inspect
import numpy as np
AuditError = RuntimeError

def harvest_index_observer(original, context, records):
    """Audit HI0 preservation and the explicit HImult cap in harvest_index."""
    signature = inspect.signature(original)

    def wrapper(*args, **kwargs):
        bound = signature.bind(*args, **kwargs)
        v = bound.arguments
        required = ['Crop', 'InitCond', 'growing_season']
        if any((k not in v for k in required)):
            raise AuditError(f'harvest_index接口变化，实际签名={signature}')
        crop = v['Crop']
        cond = v['InitCond']
        hi0_before = float(crop.HI0)
        result = original(*args, **kwargs)
        f_pre = float(getattr(result, 'f_pre', np.nan))
        f_post = float(getattr(result, 'f_post', np.nan))
        hmult_raw = f_pre * f_post
        hmult_cap = 1 + float(crop.dHI0) / 100
        hit = int(getattr(result, 'dap', 0)) - int(getattr(result, 'delayed_cds', 0)) - int(crop.HIstartCD) - 1
        cap_branch_applicable = bool(v['growing_season'] and getattr(result, 'yield_form', False) and (hit >= 0) and (int(crop.CropType) in (2, 3)))
        values = np.asarray([hi0_before, float(crop.HI0), float(getattr(result, 'harvest_index', np.nan)), float(getattr(result, 'harvest_index_adj', np.nan)), f_pre, f_post], float)
        records.append(dict(Case=context['case'], Date=context['date'], HI0_before=hi0_before, HI0_after=float(crop.HI0), HI_ref=float(getattr(result, 'hi_ref', np.nan)), HI_after=float(getattr(result, 'harvest_index', np.nan)), HI_adj_after=float(getattr(result, 'harvest_index_adj', np.nan)), f_pre=f_pre, f_post=f_post, f_pol=float(getattr(result, 'f_pol', np.nan)), HImult_raw=hmult_raw, HImult_cap=hmult_cap, HImult_cap_branch_applicable=cap_branch_applicable, HImult_cap_triggered=bool(cap_branch_applicable and hmult_raw > hmult_cap + 1e-12), Nonfinite_state=bool(not np.isfinite(values).all()), HI_out_of_physical_range=bool(np.any(values[:4] < -1e-12) or np.any(values[:4] > 1 + 1e-12))))
        return result
    return wrapper

def pollination_observer(original, context, records):
    """Reconstruct the uncapped f_pol update and report the exact >1 cap."""
    signature = inspect.signature(original)

    def wrapper(*args, **kwargs):
        bound = signature.bind(*args, **kwargs)
        v = bound.arguments
        required = ['NewCond_CC', 'NewCond_Fpol', 'Crop_FloweringCD', 'Crop_CCmin', 'Crop_exc', 'Ksw', 'Kst', 'HIt']
        if any((k not in v for k in required)):
            raise AuditError(f'HIadj_pollination接口变化，实际签名={signature}')
        hit = float(v['HIt'])
        flower = float(v['Crop_FloweringCD'])
        if hit <= 0:
            frac = 0.0
        else:

            def flowering_fraction(t):
                if t <= 0:
                    return 0.0
                pct = min(100.0, 100 * t / flower)
                value = 0.00558 * np.exp(0.63 * np.log(pct)) - 0.000969 * pct - 0.00383
                return max(0.0, float(value))
            f1 = flowering_fraction(hit - 1)
            f2 = flowering_fraction(hit)
            frac = 0.0 if abs(f1 - f2) < 1e-07 else 100 * ((f1 + f2) / 2) / flower
        if float(v['NewCond_CC']) < float(v['Crop_CCmin']):
            increment = 0.0
        else:
            ksw = v['Ksw']
            kst = v['Kst']
            increment = min(float(ksw.pol), float(kst.PolC), float(kst.PolH)) * frac * (1 + float(v['Crop_exc']) / 100)
        raw = float(v['NewCond_Fpol']) + increment
        result = original(*args, **kwargs)
        records.append(dict(Case=context['case'], Date=context['date'], HIt=hit, f_pol_before=float(v['NewCond_Fpol']), increment_raw=increment, f_pol_uncapped=raw, f_pol_after=float(result), Pollination_cap_triggered=bool(raw > 1 + 1e-12)))
        return result
    return wrapper

