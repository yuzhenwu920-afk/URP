
"""Audited conditional grouped MCMC. Default: preflight only; no sampling."""
from pathlib import Path
import argparse,importlib.util,importlib.metadata,importlib,inspect,json,hashlib,os
import numpy as np
import pandas as pd
from _di_2021_sampler import atomic_json
from _di_2021_ensemble_pipeline import run_phase
from _di_2021_diagnostics import diagnose
from _di_2021_audit_hooks import harvest_index_observer,pollination_observer

ROOT=Path(__file__).resolve().parent
KEYS=['Y_dry','Tr_mm','Es_mm','B_last','CC_RMSE']
LIMITATIONS=[
    'Grouped conditional inference: phase 2 conditions on phase-1 sampled MAP; not an 8-parameter joint posterior.',
    '2019-2021 effective WP Uniform(10,40) is a declared working prior, NOT a literature-validated physiological prior.',
    '2019-2021 HI0 stays within [0.35,0.60]; boundary posterior mass must be reported, not silently eliminated.',
    'Digitized biomass has assumed sigma, not measured SD, and is not independent validation.',
    'Zero irrigation is an unvalidated counterfactual under locked initial water and fixed-calendar WP switch; no target loss percentage.',
    '2019 Es bias and phase-1 parameter boundaries remain model limitations.',
    '2020 primary: 152 simulated days through Sep18; 151-day alternative is separately provided.',
    'SenescenceCD remains continuous in the prior and is rounded to integer days by the engine, as in the audited baseline.'
]

def compare_initial(actual,reference):
    if any(not np.isfinite(actual[k]) or abs(actual[k]-reference[k])>1e-8 for k in KEYS):
        raise RuntimeError('MCMC initial-point reproduction failed')

def load(case,out):
    folder=ROOT/'data'
    m=_embedded_module('model',folder/'model.py')
    m.OUTPUT_DIR=out/'input_audit';m.OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
    data=m.load_inputs();m.prepare_soil(data)
    point=json.loads((folder/'start.json').read_text())
    if case!='2022':
        m.PRIOR_BOUNDS.update(WP_early=(10.,40.),WP_late=(10.,40.),HI0=(.35,.60))
        m.NORMAL_PRIORS={'CDC_CD','SenescenceCD'}
        data['center'].update(WP_early=25.,WP_late=25.) # irrelevant to these uniform priors
    assert m.PHASE2_NAMES==['WP_early','WP_late','HI0']
    assert len(m.DATES)==(152 if case=='2020' else 151 if case in ['2019','2020_151d'] else 148)
    return m,data,point,folder

def internal_audit(m,data,point,mode,out):
    step=importlib.import_module('aquacrop.timestep.run_single_timestep')
    hi=importlib.import_module('aquacrop.solution.harvest_index')
    original=step.harvest_index;opol=hi.HIadj_pollination
    signature=inspect.signature(original);records=[];poll=[];context={'case':mode,'date':None}
    observed=harvest_index_observer(original,context,records)
    def call(*args,**kwargs):
        v=signature.bind(*args,**kwargs).arguments
        context['date']=str((m.PLANT+pd.Timedelta(days=int(v['InitCond'].dap)-1)).date())
        result=observed(*args,**kwargs)
        c=v['Crop'];records[-1]['Effective_WP']=float(c.WP*c.fCO2)
        records[-1]['PlantPop']=float(c.PlantPop)
        return result
    try:
        step.harvest_index=call;hi.HIadj_pollination=pollination_observer(opol,context,poll)
        result=m.simulate(data,point,mode)
    finally:
        step.harvest_index=original;hi.HIadj_pollination=opol
    h=pd.DataFrame(records);p=pd.DataFrame(poll)
    m.require(len(h)==len(m.DATES) and len(p)>0,'HI audit calls incomplete')
    m.require(pd.DatetimeIndex(pd.to_datetime(h.Date)).equals(m.DATES),'HI audit date mismatch')
    m.require(np.isfinite(h.select_dtypes(include=[np.number]).to_numpy()).all(),'Nonfinite HI internal state')
    m.require(np.isfinite(p.select_dtypes(include=[np.number]).to_numpy()).all(),'Nonfinite pollination state')
    clipped=not (np.allclose(h.HI0_before,point['HI0'],atol=1e-12,rtol=0) and np.allclose(h.HI0_after,point['HI0'],atol=1e-12,rtol=0))
    m.require(not clipped and not h.HI_out_of_physical_range.any(),'HI clipping or nonphysical state')
    expected=np.where(pd.to_datetime(h.Date)<m.SWITCH,point['WP_early'],point['WP_late'])
    m.require(np.allclose(h.Effective_WP,expected,atol=1e-9,rtol=0),'Effective WP daily mismatch')
    m.require(np.allclose(h.PlantPop,79365.),'Density mismatch')
    m.require(result[0]['Max_daily_balance_residual_mm']<1e-8,'Water balance failed')
    out.mkdir(parents=True,exist_ok=True);h.to_csv(out/(mode+'_HI_daily.csv'),index=False);p.to_csv(out/(mode+'_pollination.csv'),index=False)
    return result,dict(Calls=len(h),Pollination_calls=len(p),Input_clipped=clipped,
        HI_out_of_range=bool(h.HI_out_of_physical_range.any()),HImult_cap_days=int(h.HImult_cap_triggered.sum()),
        Pollination_cap_days=int(p.Pollination_cap_triggered.sum()),Effective_WP_daily_verified=bool(np.allclose(h.Effective_WP,expected,atol=1e-9,rtol=0)))

def preflight(m,data,point,folder,out):
    m.require(not data.get('bio_error') and not data['bio'].empty,
        data.get('bio_error') or 'MISSING_BIOMASS_CALIBRATION_DATA')
    data['start']=point
    data['start_boundary_flags']=[k+' starts within 1% of a prior bound' for k in m.ALL_NAMES
        if min(point[k]-m.PRIOR_BOUNDS[k][0],m.PRIOR_BOUNDS[k][1]-point[k])<=.01*(m.PRIOR_BOUNDS[k][1]-m.PRIOR_BOUNDS[k][0])]
    process_status,flags=m.pre_run(data)
    m.require(process_status!='FAIL','Pre-run scientific/physical hard failure: '+str(flags))
    m.frozen_regression(data)
    expected=json.loads((folder/'expected_initial.json').read_text())
    di,hi=internal_audit(m,data,point,'DI',out/'preflight')
    zero,zh=internal_audit(m,data,point,'zero',out/'preflight')
    if abs(di[0]['Es_mm']/m.ES_TARGET-1)>.15:
        flags.append('Es differs from digitized target by more than 15%; retained model limitation')
        process_status='REVIEW'
    if abs(di[0]['Y_13pct']/m.Y13_PUBLISHED-1)>.015:
        flags.append('Yield error exceeds 1.5%; retained discrepancy, not a hard sampling target')
        process_status='REVIEW'
    compare_initial(di[0],expected)
    compare_initial(m.simulate(data,point,'DI')[0],expected)
    bad=dict(expected,Y_dry=expected['Y_dry']+.01);negative=False
    try: compare_initial(di[0],bad)
    except RuntimeError: negative=True
    m.require(negative,'Fail-fast negative test failed')
    # Fixed-WP HI endpoints must leave the water/canopy/biomass unchanged.
    for value in m.PRIOR_BOUNDS['HI0']:
        s=m.simulate(data,dict(point,HI0=value),'DI')[0]
        for key in ['B_last','CC_RMSE','Tr_mm','Es_mm','ET_mm']:
            m.require(abs(s[key]-di[0][key])<1e-8,'HI profile invariance failed: '+key)
    prior={k:dict(low=m.PRIOR_BOUNDS[k][0],high=m.PRIOR_BOUNDS[k][1],
                 distribution='truncated_normal' if k in m.NORMAL_PRIORS else 'uniform',
                 center=data['center'][k] if k in m.NORMAL_PRIORS else None,
                 sd=m.PRIOR_SD[k] if k in m.NORMAL_PRIORS else None) for k in m.ALL_NAMES}
    report=dict(TECHNICAL_READY=True,Process_status=process_status,Process_flags=flags,Scientific_status='CONDITIONAL_MODEL_WITH_DECLARED_LIMITATIONS',
        Scientific_limitations=LIMITATIONS,Default_sampling=False,Negative_test_rejected=negative,
        Initial_DI=di[0],Initial_zero=zero[0],HI_audit=hi,Zero_HI_audit=zh,Switch=str(m.SWITCH.date()),
        Dates=[str(m.DATES[0].date()),str(m.DATES[-1].date())],Days=len(m.DATES),Priors=prior,
        Source_precision_note='Legacy internal yield targets retained, not claimed as newly observed precision')
    atomic_json(out/'preflight.json',report)
    return report

def contract(case,m,data,names,fixed,phase,args):
    files={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()
           for p in (ROOT/'data').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    files[Path(__file__).name]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return dict(case=case,phase=phase,names=names,fixed=fixed,priors=m.PRIOR_BOUNDS,
        normal_priors=sorted(m.NORMAL_PRIORS),prior_sd=m.PRIOR_SD,center=data['center'],
        sigmas=[m.SIGMA_CC,m.SIGMA_TR,m.SIGMA_ES,m.SIGMA_Y],targets=[m.TR_TARGET,m.ES_TARGET,m.YDRY_TARGET],
        seed=args.seed,ensembles=4,walkers=args.walkers,mode='SMOKE_NOT_INFERENCE' if args.smoke else 'sampling',
        switch=str(m.SWITCH),files=files,versions={k:importlib.metadata.version(k) for k in ['aquacrop','numpy','pandas','scipy','emcee']})

def predictive(m,data,p1,p2,c1,c2,args,out):
    rng=np.random.default_rng(args.seed+700)
    predictions=[];biomass=[];canopies=[]
    for i in range(args.ppc):
        # Phase 2 is conditional on the stage-1 MAP; do not invent a joint posterior.
        c=rng.integers(4);t=rng.integers(c2.shape[1]);v=dict(p2,**dict(zip(m.PHASE2_NAMES,c2[c,t])))
        s,g,_,_=m.simulate(data,v,'DI');z=m.simulate(data,v,'zero')[0];biomass.append(g.Biomass_t_ha.to_numpy())
        c=rng.integers(4);t=rng.integers(c1.shape[1]);v1=dict(p1,**dict(zip(m.PHASE1_NAMES,c1[c,t])))
        w,cg,_,_=m.simulate(data,v1,'DI');canopies.append(cg.canopy_cover.to_numpy())
        predictions.append(dict(draw=i,Conditional_Y13=s['Y_13pct'],Conditional_zero_Y13=z['Y_13pct'],
            Conditional_loss_pct=100*(1-z['Y_13pct']/s['Y_13pct']),Phase1_Tr=w['Tr_mm'],Phase1_Es=w['Es_mm'],Phase1_ET=w['ET_mm']))
    pd.DataFrame(predictions).to_csv(out/'conditional_predictive_draws.csv',index=False)
    for name,array in [('conditional_biomass',biomass),('phase1_canopy',canopies)]:
        q=np.quantile(array,[.025,.5,.975],axis=0)
        pd.DataFrame(dict(Date=m.DATES,Q025=q[0],Median=q[1],Q975=q[2])).to_csv(out/(name+'_bands.csv'),index=False)
    atomic_json(out/'predictive_scope.json',dict(Description='Parameter-induced model prediction intervals; no observation noise added. Not independent validation.',
        Phase1='CC/Tr/Es vary with phase-1 posterior',Phase2='B/yield/zero loss conditional on phase-1 sampled MAP',
        No_first_stage_uncertainty_propagation=True,Zero_irrigation_validated=False))

def main(case,default_output=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sample',action='store_true');p.add_argument('--accept-limitations',action='store_true')
    p.add_argument('--smoke',action='store_true',help='Two-step execution test only, never posterior inference')
    p.add_argument('--steps',type=int,default=2000,help='Total steps per independent emcee ensemble per phase; increase to resume')
    p.add_argument('--seed',type=int,default=42);p.add_argument('--checkpoint-every',type=int,default=25)
    p.add_argument('--ppc',type=int,default=100);p.add_argument('--output',type=Path)
    args=p.parse_args();args.walkers=32
    if args.smoke: args.steps=2;args.walkers=12;args.ppc=0
    if args.steps<2 or args.checkpoint_every<1 or args.ppc<0: p.error('Invalid settings')
    sampling=args.sample or args.smoke
    if sampling and not args.accept_limitations: p.error('Sampling requires --accept-limitations; see ACCOUNT_LEDGER.md')
    base=Path(default_output) if default_output else ROOT/f'MCMC_Article_Results_{case[:4]}'/f'DI_{case}'
    out=(args.output or base/('smoke' if args.smoke else 'sampling' if args.sample else 'preflight')).resolve()
    out.mkdir(parents=True,exist_ok=True);lock=out/'.run.lock'
    try: fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError: raise SystemExit('Output locked: confirm no active process before removing a stale .run.lock')
    os.write(fd,str(os.getpid()).encode());os.close(fd)
    try:
        atomic_json(out/'run_status.json',dict(State='PREFLIGHT_RUNNING',Complete=False,Smoke=args.smoke))
        m,data,point,folder=load(case,out);status=preflight(m,data,point,folder,out)
        print(case,'TECHNICAL PREFLIGHT PASSED; scientific limitations retained',flush=True)
        if not sampling:
            atomic_json(out/'run_status.json',dict(State='PREFLIGHT_COMPLETE',Complete=False,Technical_ready=True,Sampling_started=False));return
        atomic_json(out/'run_status.json',dict(State='RUNNING',Complete=False,Smoke=args.smoke,Limitations=LIMITATIONS))
        def phase(fixed,names,label,cached=False):
            actual=m.simulate(data,fixed,'DI')[0]
            reference=json.loads((folder/'expected_initial.json').read_text()) if label=='canopy_transpiration' else json.loads((out/'phase1_handoff.json').read_text())['initial_metrics']
            compare_initial(actual,reference)
            atomic_json(out/(label+'_initial_point.json'),dict(values=fixed,metrics=actual))
            cn=contract(case,m,data,names,fixed,label,args)
            return run_phase(m,data,fixed,names,label,args,out,cn,cached)
        handoff=out/'phase1_handoff.json'
        if handoff.exists():
            saved=json.loads(handoff.read_text())
            current=contract(case,m,data,m.PHASE1_NAMES,point,'canopy_transpiration',args)
            if saved['contract']!=json.loads(json.dumps(current)): raise RuntimeError('Frozen phase-1 contract mismatch')
            for rel,h in saved['hashes'].items():
                if hashlib.sha256((out/rel).read_bytes()).hexdigest()!=h: raise RuntimeError('Frozen phase-1 evidence changed')
            p1=phase(point,m.PHASE1_NAMES,'canopy_transpiration',cached=True)
            if p1['values']!=saved['values']: raise RuntimeError('Frozen phase-1 MAP changed')
            print('Reusing frozen phase 1; extension only advances phase 2.',flush=True)
        else:
            p1=phase(point,m.PHASE1_NAMES,'canopy_transpiration')
        if not p1['converged'] and not args.smoke:
            atomic_json(out/'run_status.json',dict(State='EXTEND_PHASE1',Complete=False,Phase1_converged=False))
            print('Chain length/convergence insufficient. Increase --steps with identical output/seed. Phase 2 NOT started.');return
        if not handoff.exists():
            evidence=sorted((out/'checkpoints/canopy_transpiration').glob('ensemble_*.npz'))
            atomic_json(handoff,dict(values=p1['values'],converged=p1['converged'],
                initial_metrics=m.simulate(data,p1['values'],'DI')[0],
                contract=contract(case,m,data,m.PHASE1_NAMES,point,'canopy_transpiration',args),
                hashes={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in evidence}))
        if not args.smoke: pd.DataFrame([p1['values']]).to_csv(out/'phase1_MAP_point.csv',index=False)
        p2=phase(p1['values'],m.PHASE2_NAMES,'biomass_yield')
        if p2['converged']:
            pd.DataFrame([p2['values']]).to_csv(out/'grouped_MAP_point.csv',index=False)
            m.OUTPUT_DIR=out;m.NWALKERS=4*args.walkers
            m.postprocess(data,p1,p2)
            # Correct legacy presentation metadata; numerical model is unchanged.
            metadata=pd.read_csv(out/'run_metadata.csv').set_index('Setting')['Value'].to_dict()
            metadata.update(WP_structure='two-stage effective WP for ALL years; experimental structural modification',
                checkpoint_policy='Atomic NPZ including full chain, log posterior, MT19937 state, contract',
                walkers_per_ensemble=args.walkers,independent_ensembles=4,
                inference='Sequential grouped conditional MCMC; not joint 8D posterior',
                Zero_irrigation_validated=False,Limitations=json.dumps(LIMITATIONS))
            pd.DataFrame(metadata.items(),columns=['Setting','Value']).to_csv(out/'run_metadata.csv',index=False)
            if (out/'MAP_biomass_calibration.png').exists():
                (out/'MAP_biomass_validation.png').write_bytes((out/'MAP_biomass_calibration.png').read_bytes())
            if args.ppc: predictive(m,data,p1['values'],p2['values'],p1['retained'],p2['retained'],args,out)
        atomic_json(out/'run_status.json',dict(State='SMOKE_COMPLETE' if args.smoke else 'COMPLETE' if p2['converged'] else 'EXTEND_PHASE2',
            Complete=bool(p1['converged'] and p2['converged']),Smoke=args.smoke,
            Phase1_converged=p1['converged'],Phase2_converged=p2['converged'],
            Joint_8D_posterior=False,Zero_irrigation_validated=False,Scientific_limitations=LIMITATIONS))
        print(case,'SMOKE_COMPLETE' if args.smoke else 'CONVERGED' if p2['converged'] else 'EXTEND_PHASE2',flush=True)
    except BaseException as exc:
        atomic_json(out/'run_status.json',dict(State='INTERRUPTED' if isinstance(exc,KeyboardInterrupt) else 'FAILED',
            Complete=False,Error=str(exc),Checkpoint_note='Last atomically committed checkpoint preserved'))
        raise
    finally: lock.unlink(missing_ok=True)

if __name__=='__main__': raise SystemExit('Use annual DI_YYYY_MCMC_Article_Final_v2.py')

