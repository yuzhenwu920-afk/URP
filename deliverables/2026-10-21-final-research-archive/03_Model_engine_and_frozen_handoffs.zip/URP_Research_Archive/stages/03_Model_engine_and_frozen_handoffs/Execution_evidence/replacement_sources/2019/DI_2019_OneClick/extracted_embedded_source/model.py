
# -*- coding: utf-8 -*-
# ============================================================================
# >>>>>>>>>>>>>>>>>>>>>>> USER INPUT / OUTPUT PATHS <<<<<<<<<<<<<<<<<<<<<<<<<<<
# ============================================================================
from pathlib import Path
# 【需要你接入的文件 1】研究数据根目录（已有文件，仅读取）
ROOT = Path('C:\\Users\\Lenovo\\Desktop\\竞赛科研\\科研\\URP')
# 【需要你接入的文件 2】本年度气象；禁止缺日插值或替代
WEATHER_FILE = Path(__file__).resolve().parent / 'inputs' / 'WEATHER_FILE_DI_Climate_2019_FINAL.csv'
# 【需要你接入的文件 3】正式 Field LAI-derived CC
FIELD_CC_FILE = Path(__file__).resolve().parent / 'inputs' / 'FIELD_CC_FILE_DI_2019_2022_FIELD_LAI_CC_LOCKED.csv'
# 【需要你接入的文件 4】锁定初始水（含层顶、层底）
INITIAL_WATER_FILE = Path(__file__).resolve().parent / 'inputs' / 'INITIAL_WATER_FILE_DI_2019_2022_AquaCrop_InitialWater_FIELD_LOCKED.csv'
# 【需要你接入的文件 5】RS 辅助检查，绝不进入 likelihood
RS_CC_FILE = Path(__file__).resolve().parent / 'inputs' / 'RS_CC_FILE_Maize-2019-main.csv'
# 【近似校准数据】图4-8数字化DI地上干生物量；Sigma_assumed不是实测SD
BIOMASS_FILE = Path(__file__).resolve().parent / 'inputs' / 'BIOMASS_FILE_DI_2019_biomass_digitized.csv'
# 【需要你接入的文件 7】2022 冻结初始点，随包提供；其他年份不用
INITIAL_POINT_FILE = Path(__file__).resolve().parent / 'inputs' / 'INITIAL_POINT_FILE_mcmc_initial_point.csv'
# 【需要你接入的文件 8】2019 年逐小时标量风速纠偏 ETo，缺失即停止
ETO_FILE = Path(__file__).resolve().parent / 'inputs' / 'ETO_FILE_DI_2019_ETo_B_Audited_Daily.csv'
# 【需要你接入的文件 11】同次 GEE 导出的 2022 control，用于验证同一纠偏算法
ETO_CONTROL_FILE = Path(__file__).resolve().parent / 'inputs' / 'ETO_CONTROL_FILE_DI_2022_ETo_B_Audited_Daily.csv'
# 【随包冻结参照】不可用新 control 覆盖它
FROZEN_2022_ETO_FILE = Path(__file__).resolve().parent / 'inputs' / 'FROZEN_2022_ETO_FILE_DI_2022_ETo_Geometry_Daily.csv'
# 【需要你接入的文件 9】2022 READY 证据
READINESS_FILE = Path(__file__).resolve().parent / 'inputs' / 'READINESS_FILE_pre_mcmc_readiness.json'
# 【需要你接入的文件 10】2022 历史 MAP，仅结构复现，不能作为 prior center
HISTORICAL_MAP_FILE = Path(__file__).resolve().parent / 'inputs' / 'HISTORICAL_MAP_FILE_historical_2022_grouped_MAP_point.csv'
# 【需要你接入的文件 12】本次确定性第一阶段起点；仅用于初始化，绝不是 posterior/prior center
PHASE1_START_POINT_FILE = Path(__file__).resolve().parent / 'inputs' / 'PHASE1_START_POINT_FILE_phase1_deterministic_start_2019.csv'
# 【结果路径】与旧科研结果分开，默认脚本同目录；--output 可覆盖
OUTPUT_DIR = Path(__file__).resolve().parent / 'MCMC_Article_Results_2019' / 'DI_2019'
# 灌溉逐次表、播收边界与物候来自原项目 YEAR_CONFIG；在下方明列，不另猜路径。
# 默认只做 PRE-RUN；正式采样需要 --formal，REVIEW 默认中止。
# ============================================================================
YEAR = 2019
CFG = {'plant': '2019-04-18', 'harvest': '2019-09-16', 'maturity_cd': 151, 'histart_cd': 83, 'yield_t_ha': 16.552, 'late_cc': '2019-09-01', 'irrigation': [('2019-06-06', 64.62), ('2019-06-18', 67.71), ('2019-07-06', 63.35), ('2019-07-18', 58.18), ('2019-07-27', 62.17), ('2019-08-10', 63.18), ('2019-08-23', 30.02), ('2019-08-26', 36.04)]}
ET_OBS = 661.45
ES_TARGET = 76.0
Y13_PUBLISHED = 16.55
Y13_TARGET = 16.552
IRR_PUBLISHED = 445.27

"""Shared build source. Each delivered annual script includes a full copy."""
import argparse
import copy
import hashlib
import importlib
import importlib.metadata
import inspect
import json
import os
import sys
import time
import numpy as np
import pandas as pd
from aquacrop import AquaCropModel, Soil, Crop, InitialWaterContent, IrrigationManagement, FieldMngt

NWALKERS = 32
NSTEPS = 2000
STOP_BEFORE_FORMAL_MCMC_ON_REVIEW = True
RANDOM_SEED = 42
ETO_AUDIT_REVIEW = []
SIGMA_CC, SIGMA_ES, SIGMA_Y = .05, 15., .67*.87
PHASE1_NAMES = ['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb']
PHASE2_NAMES = ['WP_early','WP_late','HI0']
ALL_NAMES = PHASE1_NAMES + PHASE2_NAMES
PRIOR_BOUNDS = dict(CCx=(.60,.99), CGC_CD=(.08,.16), CDC_CD=(.03,.12),
                    SenescenceCD=(115.,145.), Kcb=(1.05,1.60), WP=(28.,40.),
                    WP_early=(10.,22.), WP_late=(20.,38.), HI0=(.35,.50 if YEAR==2022 else .60))
PRIOR_SD = dict(CCx=.05, CGC_CD=.015, CDC_CD=.025, SenescenceCD=10., Kcb=.10,
                WP=4., WP_early=3., WP_late=4., HI0=.03)
# 2019–2021: Kcb uses a uniform prior on unchanged [1.05,1.60] bounds.
# Default Kcb=1.05 is not an observation and no longer supplies a Gaussian penalty.
NORMAL_PRIORS = set(ALL_NAMES) if YEAR==2022 else {'CDC_CD','SenescenceCD'}
PLANT = pd.Timestamp(CFG['plant'])
HARVEST = pd.Timestamp(CFG['harvest'])
DATES = pd.date_range(PLANT, HARVEST-pd.Timedelta(days=1))
SWITCH = PLANT + pd.Timedelta(days=CFG['histart_cd'])
TR_TARGET = 503. if YEAR==2022 else ET_OBS-ES_TARGET
SIGMA_TR = .1*TR_TARGET
YDRY_TARGET = Y13_TARGET*.87
ROLES = dict(inference='sequential grouped Bayesian calibration; Phase 2 conditional on Phase 1 MAP',
             field='calibration evidence; not independent validation',
             biomass='digitized approximate calibration evidence; not independent validation',
             yield_role='calibration/model-data agreement',
             rs='auxiliary remote-sensing temporal reference with source/treatment-label uncertainty',
             zero='zero-irrigation counterfactual under the locked/observed initial soil-water condition')

class AuditError(RuntimeError):
    pass

class CandidateInvalid(ValueError):
    """Only expected candidate failures become -inf; input/API errors propagate."""

def require(ok, message):
    if not ok:
        raise AuditError(message)

def read_csv(path, columns):
    require(path.is_file(), f'MISSING_INPUT: {path}')
    d=pd.read_csv(path, encoding='utf-8-sig')
    require(set(columns)<=set(d.columns), f'{path}: missing columns {set(columns)-set(d.columns)}')
    return d

def finite(a, label):
    require(np.isfinite(np.asarray(a, dtype=float)).all(), f'NaN/Inf: {label}')

def unique_dates(d, column='Date'):
    d[column]=pd.to_datetime(d[column], errors='raise').dt.normalize()
    require(not d[column].isna().any() and not d[column].duplicated().any(), f'Missing/duplicate {column}')
    return d.sort_values(column).reset_index(drop=True)

def save_csv(d, path):
    """Atomic replacement: completed evidence survives interrupted postprocessing."""
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    d.to_csv(tmp,index=False,encoding='utf-8-sig')
    os.replace(tmp,path)

def save_json(d,path):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2,default=str,allow_nan=False),encoding='utf-8')
    os.replace(tmp,path)

def load_inputs():
    raw=read_csv(WEATHER_FILE,[])
    date='Date' if 'Date' in raw else 'date'
    mapping=dict(Tmin_C='MinTemp',Tmax_C='MaxTemp',Precip_mm='Precipitation',ETo_mm='ReferenceET')
    w=raw.rename(columns={**mapping,date:'Date'})
    require(set(['Date','MinTemp','MaxTemp','Precipitation','ReferenceET'])<=set(w), 'Weather schema')
    # AquaCrop 3.1.0 converts weather to a positional NumPy array: Date must be last.
    w=unique_dates(w[['MinTemp','MaxTemp','Precipitation','ReferenceET','Date']].copy())
    for c in ['MinTemp','MaxTemp','Precipitation','ReferenceET']: w[c]=pd.to_numeric(w[c],errors='raise')
    if YEAR==2022:
        e=unique_dates(read_csv(ETO_FILE,['Date','ETo_B_mm']))
        w['ReferenceET']=w.Date.map(e.set_index('Date').ETo_B_mm)
    else:
        w=read_audited_eto_b(w)
    finite(w[['MinTemp','MaxTemp','Precipitation','ReferenceET']], 'weather')
    require((w.MinTemp<=w.MaxTemp).all() and (w.Precipitation>=0).all() and (w.ReferenceET>=0).all(), 'Weather physical QC')
    expected=pd.date_range(f'{YEAR}-01-01', f'{YEAR}-12-31')
    require(pd.DatetimeIndex(w.Date).equals(expected), 'Weather dates incomplete or extraneous; no interpolation')
    f=read_csv(FIELD_CC_FILE,['Year','Date','LAI','Field_CC','Irrigation'])
    f=f[pd.to_numeric(f.Year,errors='raise')==YEAR].copy()
    require(len(f)>=5 and f.Irrigation.eq('DI').all(),'Field CC year/treatment mismatch')
    f=unique_dates(f)
    finite(f[['LAI','Field_CC']], 'Field CC')
    require(np.allclose(f.Field_CC,1.005*(1-np.exp(-.6*f.LAI))**1.2,atol=1e-10),'Field CC/LAI formula mismatch')
    require(f.Date.isin(DATES).all() and f.Field_CC.between(0,1).all(),'Field CC dates/range')
    f=f[['Date','Field_CC']].rename(columns={'Field_CC':'Observed_CC'})
    f['Weight']=np.where(f.Date>=pd.Timestamp(CFG['late_cc']),.5,1.)
    p=read_csv(INITIAL_WATER_FILE,['Year','Treatment','Planting_Date','Depth_top_m','Depth_bottom_m','Depth_mid_m','Initial_theta_m3m3'])
    p=p[(pd.to_numeric(p.Year,errors='raise')==YEAR)&p.Treatment.eq('DI')].copy().sort_values('Depth_top_m')
    require(len(p)>0 and pd.to_datetime(p.Planting_Date).eq(PLANT).all(),'Initial water year/planting mismatch')
    finite(p[['Depth_top_m','Depth_bottom_m','Depth_mid_m','Initial_theta_m3m3']], 'initial water')
    a=p.Depth_top_m.to_numpy(float); b=p.Depth_bottom_m.to_numpy(float)
    require(np.all(b>a) and np.isclose(a[0],0) and np.isclose(b[-1],2.4) and np.allclose(a[1:],b[:-1]),'Initial profile has gaps/overlap; needs exact 0–2.4m coverage')
    require(np.allclose(p.Depth_mid_m,(a+b)/2),'Initial profile midpoints mismatch')
    rs=read_csv(RS_CC_FILE,['CCquad'])
    rc='Date' if 'Date' in rs else 'date'
    rs=unique_dates(rs.rename(columns={rc:'Date'}))
    rs['RS_CC']=pd.to_numeric(rs.CCquad,errors='raise')/100
    finite(rs.RS_CC,'RS CC'); require(rs.RS_CC.between(0,1).all(),'RS CC range')
    rsmeta={k:'|'.join(map(str,rs[k].dropna().unique())) for k in ['Year','CropType','IrriMetho'] if k in rs}
    bio=pd.DataFrame(columns=['Date','Observed_B_t_ha','Sigma_assumed'])
    bio_error=''
    if BIOMASS_FILE.is_file():
        b=read_csv(BIOMASS_FILE,['Date','Observed_B_t_ha','Sigma_assumed'])
        if len(b):
            b=unique_dates(b)
            if YEAR!=2022:
                require({'Year','Treatment','Source'}<=set(b),'Biomass requires Year,Treatment,Source')
                require(b.Year.eq(YEAR).all() and b.Treatment.eq('DI').all() and b.Source.fillna('').str.strip().ne('').all(),'Biomass provenance/year/treatment')
            finite(b[['Observed_B_t_ha','Sigma_assumed']],'biomass')
            require(b.Date.isin(DATES).all() and (b.Observed_B_t_ha>=0).all() and (b.Sigma_assumed>0).all(),'Biomass dates/units/uncertainty')
            anchor=PLANT+pd.Timedelta(days=CFG['histart_cd'])
            require(len(b)>=3 and (b.Date<anchor).any() and (b.Date>=anchor).any(),'INSUFFICIENT_BIOMASS_CALIBRATION_DATA: >=3 dates spanning HIstart required')
            bio=b
    if bio.empty:
        bio_error=f'MISSING_BIOMASS_CALIBRATION_DATA: {YEAR}; {BIOMASS_FILE}; missing season-specific dates and aboveground dry biomass t/ha; thesis Fig 4-8'
    schedule=unique_dates(pd.DataFrame(CFG['irrigation'],columns=['Date','Depth']))
    finite(schedule.Depth,'irrigation')
    require(schedule.Date.isin(DATES).all() and (schedule.Depth>0).all(),'Irrigation date/depth')
    delta=float(schedule.Depth.sum()-IRR_PUBLISHED)
    require(abs(delta-(.01 if YEAR==2021 else 0))<1e-8,'Irrigation schedule differs from published annual contract')
    if YEAR==2022:
        t=read_csv(INITIAL_POINT_FILE,['Parameter','Value'])
        require(not t.Parameter.duplicated().any() and set(ALL_NAMES)<=set(t.Parameter),'Frozen center schema')
        center={k:float(t.set_index('Parameter').Value[k]) for k in ALL_NAMES}
        r=json.loads(READINESS_FILE.read_text(encoding='utf-8-sig'))
        require(r.get('READY') is True,'Frozen readiness is not READY=true')
    else:
        center=dict(CCx=.90,CGC_CD=.120,CDC_CD=.070,SenescenceCD=132.,WP=33.7,HI0=.45,Kcb=1.05)
        require(np.isclose(Crop('Maize',planting_date=PLANT.strftime('%m/%d')).Kcb,1.05),'Installed Maize Kcb default changed')
    finite(list(center.values()),'parameter center')
    require(all(PRIOR_BOUNDS[k][0]<=v<=PRIOR_BOUNDS[k][1] for k,v in center.items()),'Center outside prior')
    return dict(weather=w,field=f,profile=p,rs=rs,rsmeta=rsmeta,bio=bio,bio_error=bio_error,schedule=schedule,center=center)

SOIL_LAYERS=[(.10,29.70,10.64),(.10,30.81,10.52),(.20,19.43,12.32),(.20,13.22,16.20),(.20,10.38,14.75),(.20,11.81,11.66)]

def base_soil():
    s=Soil('custom',dz=[.1]*10)
    for thickness,sand,clay in SOIL_LAYERS:
        s.add_layer_from_texture(thickness=thickness,Sand=sand,Clay=clay,OrgMat=2.,penetrability=100)
    s.fill_nan()
    return s

def crop_for(v):
    c=Crop('Maize',planting_date=PLANT.strftime('%m/%d'),harvest_date=HARVEST.strftime('%m/%d'))
    for k in ['CCx','CGC_CD','CDC_CD','Kcb','HI0']: setattr(c,k,float(v[k]))
    c.SenescenceCD=int(round(v['SenescenceCD']))
    c.MaturityCD=CFG['maturity_cd']; c.HIstartCD=CFG['histart_cd']
    for k in ['CGC','CDC','Senescence','Maturity','HIstart']:
        if hasattr(c,k): setattr(c,k,getattr(c,k+'_CD' if k in ['CGC','CDC'] else k+'CD'))
    c.WP=20.
    c.PlantPop=79365.; c.CC0=c.SeedSize*c.PlantPop*1e-8
    return c

def field_management():
    return FieldMngt(mulches=True,mulch_pct=75.,f_mulch=0.,bunds=False,curve_number_adj=False,sr_inhb=False)

def irrigation(data,mode):
    if mode=='zero': return IrrigationManagement(irrigation_method=0)
    require(mode=='DI','Unknown irrigation mode')
    s=data['schedule']
    return IrrigationManagement(irrigation_method=3,Schedule=s.copy(),MaxIrr=float(s.Depth.max()+.1),MaxIrrSeason=float(s.Depth.sum()+.1),WetSurf=100.,AppEff=100.)

def make_model(data,v,soil,iw,mode):
    return AquaCropModel(sim_start_time=PLANT.strftime('%Y/%m/%d'),sim_end_time=f'{YEAR}/12/31',
        weather_df=data['weather'].copy(),soil=soil,crop=crop_for(v),initial_water_content=iw,
        irrigation_management=irrigation(data,mode),field_management=field_management())

def prepare_soil(data):
    template=base_soil(); src=template.profile.copy(deep=True)
    p=data['profile']
    if YEAR==2022:
        # Exact frozen legacy initialization; the engine's existing interpolation is
        # retained ONLY for 2022 structural reproduction, not to fill missing data.
        iw=InitialWaterContent(wc_type='Num',method='Depth',depth_layer=p.Depth_mid_m.tolist(),value=p.Initial_theta_m3m3.tolist())
        legacy=make_model(data,data['center'],template,iw,'DI'); legacy._initialize()
        old=legacy._param_struct.Soil.profile
        widths=old.dz.to_numpy(float); bottom=np.cumsum(widths); top=bottom-widths
        theta=np.asarray(legacy._init_cond.th,float)
    else:
        top=p.Depth_top_m.to_numpy(float); bottom=p.Depth_bottom_m.to_numpy(float)
        theta=p.Initial_theta_m3m3.to_numpy(float); widths=bottom-top
    newbot=np.round(np.arange(1,25)*.1,10); newtop=newbot-.1; mid=(newbot+newtop)/2
    overlap=np.maximum(0,np.minimum(newbot[:,None],bottom)-np.maximum(newtop[:,None],top))
    require(np.allclose(overlap.sum(axis=1),.1,atol=1e-10),'Initial water coverage incomplete')
    mapped=overlap@theta/.1
    require(np.isclose(np.sum(mapped*.1),np.sum(theta*widths),atol=1e-10,rtol=0),'Nonconservative water mapping')
    idx=np.minimum(np.searchsorted(np.cumsum(src.dz.to_numpy(float)),mid),len(src)-1)
    s=base_soil(); frame=src.iloc[idx].copy().reset_index(drop=True)
    for k,val in dict(Comp=np.arange(24),dz=np.full(24,.1),dzsum=newbot,zBot=newbot,z_top=newtop,zMid=mid).items(): frame[k]=val
    s.profile=frame; s.nComp=24; s.nLayer=int(frame.Layer.max()); s.zSoil=2.4; s.fill_nan()
    require(((mapped>=frame.th_dry.to_numpy()-1e-10)&(mapped<=frame.th_s.to_numpy()+1e-10)).all(),'Initial theta outside dry/saturation; no clipping')
    data['soil']=s; data['theta']=mapped; data['mid']=mid

def evap_wrapper(original):
    sig=inspect.signature(original)
    def call(*args,**kwargs):
        b=sig.bind(*args,**kwargs)
        require({'NewCond_CCadj','NewCond_CC'}<=set(b.arguments),'soil_evaporation API changed')
        b.arguments['NewCond_CCadj']=float(b.arguments['NewCond_CC'])
        return original(*b.args,**b.kwargs)
    return call

def effective_wp(full,target):
    lo,hi=0.,60.
    for _ in range(80):
        m=(lo+hi)/2; f=1+np.clip((40-m)/20,0,1)*(full-1)
        if m*f<target: lo=m
        else: hi=m
    wp=(lo+hi)/2; f=float(1+np.clip((40-wp)/20,0,1)*(full-1))
    require(np.isclose(wp*f,target,atol=1e-9),'WP inversion failed')
    return wp,f

def simulate(data,v,mode='DI'):
    theta=data['theta']; soil=copy.deepcopy(data['soil'])
    iw=InitialWaterContent(wc_type='Num',method='Depth',depth_layer=data['mid'].tolist(),value=theta.tolist())
    m=make_model(data,v,soil,iw,mode)
    mod=importlib.import_module('aquacrop.timestep.run_single_timestep')
    original=mod.soil_evaporation; mod.soil_evaporation=evap_wrapper(original)
    storage=[]; surface=[]
    try:
        m._initialize()
        require(len(m._init_cond.th)==24 and np.allclose(m._param_struct.Soil.Profile.dz,.1,atol=1e-12),'Corrected grid changed')
        require(np.allclose(m._init_cond.th,theta,atol=1e-10,rtol=0),'soil initialization mismatch')
        require(np.isclose(m._param_struct.Soil.zSoil,2.4),'Soil depth changed')
        sc=m._param_struct.Seasonal_Crop_List[0]; full=float(sc.fCO2)
        require(np.isclose(sc.PlantPop,79365.) and np.isclose(sc.CC0,sc.SeedSize*79365.*1e-8),'Field density/CC0 lost at runtime')
        if True: require(np.isclose(sc.WP,20.) and np.isclose(sc.WPy,100.),'Frozen WP state changed')
        storage.append(float(np.sum(m._init_cond.th)*100)); surface.append(float(m._init_cond.surface_storage))
        dry=soil.profile.th_dry.to_numpy(float); sat=soil.profile.th_s.to_numpy(float)
        n=0
        while not m._clock_struct.model_is_finished:
            date=pd.Timestamp(m._clock_struct.step_start_time)
            if n>=len(DATES) or date!=DATES[n]: raise CandidateInvalid('season dates incomplete: premature/late termination')
            if True:
                sc=m._param_struct.Seasonal_Crop_List[0]
                target=v['WP_early'] if date<SWITCH else v['WP_late']
                sc.WP,sc.fCO2=effective_wp(full,target)
            m.run_model(num_steps=1,initialize_model=False,process_outputs=False)
            th=np.asarray(m._init_cond.th,float); finite(th,'daily theta')
            require(np.all(th>=dry-1e-8) and np.all(th<=sat+1e-8),'soil water outside dry/saturation limits')
            storage.append(float(np.sum(th)*100)); surface.append(float(m._init_cond.surface_storage))
            if True:
                sc=m._param_struct.Seasonal_Crop_List[0]
                require(np.isclose(sc.WP*sc.fCO2,target,atol=1e-9),'Effective WP lost after daily step')
            n+=1
        if n!=len(DATES): raise CandidateInvalid(f'season dates incomplete: {n}/{len(DATES)}')
    finally:
        mod.soil_evaporation=original
    f=m._outputs.water_flux.iloc[:n].copy()
    required=['time_step_counter','Tr','Es','IrrDay','DeepPerc','Runoff','CR','GwIn']
    require(set(required)<=set(f),'Flux API changed; missing required components')
    finite(f[required],'daily flux')
    require(np.array_equal(f.time_step_counter.to_numpy(),np.arange(n)),'Flux date counter mismatch')
    f['Date']=DATES; f['ET']=f.Tr+f.Es
    # TileDrain absent in AquaCrop 3.1.0 with disabled tile drainage is a structural zero.
    if 'TileDrain' not in f: f['TileDrain']=0.
    finite(f.TileDrain,'TileDrain')
    rain=data['weather'].set_index('Date').loc[DATES,'Precipitation'].to_numpy(float)
    wb=rain+f.IrrDay.to_numpy()+f.CR.to_numpy()+f.GwIn.to_numpy()-f.Tr.to_numpy()-f.Es.to_numpy()-f.DeepPerc.to_numpy()-f.Runoff.to_numpy()-f.TileDrain.to_numpy()-np.diff(storage)-np.diff(surface)
    finite(wb,'daily water balance')
    require(np.max(np.abs(wb))<=1e-4 and abs(wb.sum())<=1e-4,'water balance residual >1e-4 mm')
    stats=m._outputs.final_stats
    require(len(stats)==1 and pd.Timestamp(stats.iloc[0]['Harvest Date (YYYY/MM/DD)'])==HARVEST,'Harvest boundary mismatch')
    y=float(stats.iloc[0]['Dry yield (tonne/ha)']); irr=float(stats.iloc[0]['Seasonal irrigation (mm)'])
    targetirr=float(data['schedule'].Depth.sum()) if mode=='DI' else 0.
    require(abs(irr-targetirr)<1e-7 and abs(f.IrrDay.sum()-targetirr)<1e-7,'DI/zero irrigation mismatch')
    expectedirr=data['schedule'].set_index('Date').Depth.reindex(DATES,fill_value=0).to_numpy() if mode=='DI' else np.zeros(n)
    require(np.allclose(f.IrrDay,expectedirr,atol=1e-7,rtol=0),'Daily irrigation differs from schedule')
    g=m._outputs.crop_growth.iloc[:n].copy()
    finite(g[['dap','canopy_cover','biomass','harvest_index_adj','DryYield']],'growth')
    require(np.array_equal(g.dap.to_numpy(),np.arange(1,n+1)),'Growth dates incomplete')
    g['Date']=DATES; g['Biomass_t_ha']=g.biomass/100
    cc=data['field'].merge(g[['Date','canopy_cover']],on='Date',how='left',validate='one_to_one')
    bio=data['bio'].merge(g[['Date','Biomass_t_ha']],on='Date',how='left',validate='one_to_one')
    finite(cc.canopy_cover,'CC match')
    if len(bio): finite(bio.Biomass_t_ha,'Biomass match')
    active=g[g.DryYield>0]; last=active.iloc[-1] if len(active) else g.iloc[-1]
    s=dict(Y_dry=y,Y_13pct=y/.87,Irrigation_mm=irr,Rain_mm=float(rain.sum()),
           Tr_mm=float(f.Tr.sum()),Es_mm=float(f.Es.sum()),ET_mm=float(f.ET.sum()),
           DeepPerc_mm=float(f.DeepPerc.sum()),Runoff_mm=float(f.Runoff.sum()),
           CR_mm=float(f.CR.sum()),GwIn_mm=float(f.GwIn.sum()),TileDrain_mm=float(f.TileDrain.sum()),
           Profile_initial_mm=storage[0],Profile_final_mm=storage[-1],Profile_depletion_mm=storage[0]-storage[-1],
           Surface_initial_mm=surface[0],Surface_final_mm=surface[-1],
           Water_balance_residual_mm=float(wb.sum()),Max_daily_balance_residual_mm=float(np.max(np.abs(wb))),
           MaxCC=float(g.canopy_cover.max()),HI_last=float(last.harvest_index_adj),B_last=float(last.Biomass_t_ha),
           CC_RMSE=float(np.sqrt(np.mean((cc.canopy_cover-cc.Observed_CC)**2))))
    finite(list(s.values()),'model summary')
    require(y>=0 and (f[['Tr','Es','ET']].to_numpy()>=-1e-10).all(),'Negative yield/flux')
    if len(bio):
        s['B_RMSE']=float(np.sqrt(np.mean((bio.Biomass_t_ha-bio.Observed_B_t_ha)**2)))
    return s,g,cc,bio

def compare_scenarios(di,zero):
    require(zero['Y_13pct']<=di['Y_13pct']+1e-8,'zero-irrigation yield > DI yield')
    loss=100*(di['Y_13pct']-zero['Y_13pct'])/di['Y_13pct'] if di['Y_13pct']>0 else 0.
    flags=list(ETO_AUDIT_REVIEW)
    if abs(100*(di['ET_mm']/ET_OBS-1))>15: flags.append('DI ET relative error >15%')
    if loss<25: flags.append('zero-irrigation yield loss <25%')
    if loss>90: flags.append('zero-irrigation yield loss >90%')
    budget=zero['Rain_mm']+zero['Profile_depletion_mm']+zero['Surface_initial_mm']-zero['Surface_final_mm']
    if zero['ET_mm']>budget+1e-4: flags.append('zero ET exceeds rainfall + soil/surface depletion; inspect other inflows')
    for mode,s in [('DI',di),('zero',zero)]:
        if not .4<=s['MaxCC']<=1: flags.append(f'{mode} MaxCC outside declared red-flag range [0.4,1]')
        if not .2<=s['HI_last']<=.65: flags.append(f'{mode} HI outside declared red-flag range [0.2,0.65]')
    return ('REVIEW' if flags else 'PASS'),flags,loss

def pre_run(data):
    print(f'\nPRE-RUN STRUCTURAL CHECK — {YEAR}',flush=True)
    results={}; errors=[]
    for mode in ['DI','zero']:
        try:
            s,*_=simulate(data,data.get('start',data['center']),mode); results[mode]=s
            print('\n'+('DI:' if mode=='DI' else 'ZERO IRRIGATION:'),flush=True)
            for k,v in s.items(): print(f'    {k}: {v:.10g}')
        except (AuditError,CandidateInvalid) as e:
            errors.append(f'{mode}: {e}'); print(f'{mode}: FAIL: {e}',flush=True)
    print(f'    Published yield: {Y13_PUBLISHED}; internal yield target: {Y13_TARGET}')
    print(f'    Published irrigation: {IRR_PUBLISHED}; schedule: {data["schedule"].Depth.sum():.2f}')
    print(f'    Tr target: {TR_TARGET}; Es target: {ES_TARGET}; Observed ET: {ET_OBS}')
    status='FAIL'; flags=errors; loss=None
    if not errors:
        try: status,flags,loss=compare_scenarios(results['DI'],results['zero'])
        except AuditError as e: flags=[str(e)]
    if 'DI' in results:
        print(f'    Yield relative error vs published: {100*(results["DI"]["Y_13pct"]/Y13_PUBLISHED-1):+.5f}%')
        print(f'    ET relative error: {100*(results["DI"]["ET_mm"]/ET_OBS-1):+.5f}%')
    if loss is not None:
        print(f'    Yield loss vs DI: {results["DI"]["Y_13pct"]-results["zero"]["Y_13pct"]:.6f} t/ha; {loss:.4f}%')
    if status!='FAIL' and data.get('start_boundary_flags'):
        flags += data['start_boundary_flags']; status='REVIEW'
    print('PRE_RUN_STATUS =',status,'; '.join(flags),flush=True)
    rows=[]
    for mode in ['DI','zero']:
        rows.append(dict(Year=YEAR,Scenario=mode,PRE_RUN_STATUS=status,Flags='; '.join(flags),
                         Phase2_data_status=data['bio_error'] or 'AVAILABLE',Yield_loss_pct=loss,
                         Published_yield=Y13_PUBLISHED,Internal_yield_target=Y13_TARGET,Published_ET=ET_OBS,
                         Tr_target=TR_TARGET,Es_target=ES_TARGET,Published_irrigation=IRR_PUBLISHED,
                         Schedule_irrigation=float(data['schedule'].Depth.sum()),**results.get(mode,{})))
    save_csv(pd.DataFrame(rows),OUTPUT_DIR/'pre_run_summary.csv')
    return status,flags

def frozen_regression(data):
    if YEAR!=2022: return
    s=simulate(data,data['center'],'DI')[0]
    expected=dict(Y_dry=(12.25617778072742,.002),Tr_mm=(525.4468722329179,.002),
                  Es_mm=(73.16250053907443,.002),B_last=(30.5249401326545,.002),CC_RMSE=(.0869466373051667,.0001))
    rows=[]
    for k,(v,tol) in expected.items():
        rows.append(dict(Check='frozen_center_'+k,Actual=s[k],Expected=v,Tolerance=tol,Passed=abs(s[k]-v)<=tol))
    t=read_csv(HISTORICAL_MAP_FILE,ALL_NAMES)
    require(len(t)==1,'Historical MAP must contain one parameter row')
    v={k:float(t.iloc[0][k]) for k in ALL_NAMES}
    di,g,cc,_=simulate(data,v,'DI'); zero=simulate(data,v,'zero')[0]
    r2=metrics(cc.Observed_CC,cc.canopy_cover)['R2']
    loss=100*(1-zero['Y_13pct']/di['Y_13pct'])
    for k,actual,target,tol in [('MAP_Y13',di['Y_13pct'],14.062076,.002),('MAP_Field_R2',r2,.940,.002),
                              ('MAP_Zero_Y13',zero['Y_13pct'],5.763,.005),('MAP_Zero_loss_pct',loss,59.,.1),
                              ('MAP_Zero_water_balance',zero['Water_balance_residual_mm'],0.,1e-4)]:
        rows.append(dict(Check=k,Actual=actual,Expected=target,Tolerance=tol,Passed=abs(actual-target)<=tol))
    tab=pd.DataFrame(rows); save_csv(tab,OUTPUT_DIR/'frozen_2022_reproduction.csv')
    print('\n2022 FROZEN CENTER + HISTORICAL GROUPED-MAP REPRODUCTION\n',tab.to_string(index=False),flush=True)
    require(tab.Passed.all(),'2022 frozen initial-point / historical grouped-MAP reproduction failed')

def logprob(vector,names,fixed,phase,data):
    v=dict(fixed); v.update(zip(names,map(float,vector)))
    prior=0.
    for k in names:
        x=v[k]; lo,hi=PRIOR_BOUNDS[k]
        if not np.isfinite(x) or not lo<=x<=hi: return -np.inf
        if k in NORMAL_PRIORS: prior-=.5*((x-data['center'][k])/PRIOR_SD[k])**2
    try: s,g,cc,bio=simulate(data,v,'DI')
    except CandidateInvalid: return -np.inf
    if phase=='canopy_transpiration':
        ll=-.5*np.sum(cc.Weight*((cc.canopy_cover-cc.Observed_CC)/SIGMA_CC)**2)
        ll-=.5*((s['Tr_mm']-TR_TARGET)/SIGMA_TR)**2+.5*((s['Es_mm']-ES_TARGET)/SIGMA_ES)**2
    else:
        require(len(bio)>0,data['bio_error'] or 'MISSING_BIOMASS_CALIBRATION_DATA')
        ll=-.5*np.sum(((bio.Biomass_t_ha-bio.Observed_B_t_ha)/bio.Sigma_assumed)**2)-.5*((s['Y_dry']-YDRY_TARGET)/SIGMA_Y)**2
    return float(ll+prior)

def signature(data,names,fixed,phase):
    files=[PHASE1_START_POINT_FILE,WEATHER_FILE,FIELD_CC_FILE,INITIAL_WATER_FILE,RS_CC_FILE,BIOMASS_FILE,ETO_FILE,ETO_CONTROL_FILE,FROZEN_2022_ETO_FILE]
    if YEAR==2022: files += [ETO_FILE,INITIAL_POINT_FILE,READINESS_FILE,HISTORICAL_MAP_FILE]
    return dict(Year=YEAR,phase=phase,names=names,fixed=fixed,center=data['center'],CFG=CFG,
                priors=PRIOR_BOUNDS,normal_priors=sorted(NORMAL_PRIORS),prior_sd=PRIOR_SD,
                sigmas=[SIGMA_CC,SIGMA_TR,SIGMA_ES,SIGMA_Y],targets=[TR_TARGET,ES_TARGET,YDRY_TARGET],
                files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
                source=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                versions={k:importlib.metadata.version(k) for k in ['aquacrop','emcee','h5py','numpy','pandas']})

def run_phase(data,phase,names,fixed,total_steps):
    import emcee
    import h5py
    path=OUTPUT_DIR/f'_resume_{phase}.h5'
    contract=signature(data,names,fixed,phase)
    encoded=json.dumps(contract,sort_keys=True,default=str)
    backend=emcee.backends.HDFBackend(str(path))
    if path.exists():
        with h5py.File(path,'r') as h:
            require(h.attrs.get('scientific_contract','')==encoded,'Checkpoint scientific contract changed; use a new output directory. Never reuse mismatched chain.')
        require(backend.shape==(NWALKERS,len(names)),'Backend shape mismatch')
    else:
        backend.reset(NWALKERS,len(names))
        with h5py.File(path,'a') as h: h.attrs['scientific_contract']=encoded
    def lp(x): return logprob(x,names,fixed,phase,data)
    start=None
    if backend.iteration==0:
        rng=np.random.default_rng(RANDOM_SEED+YEAR+(100003 if phase=='biomass_yield' else 0))
        start=[]
        for walker in range(NWALKERS):
            for attempt in range(3000):
                pos=np.array([fixed[k] for k in names])+rng.normal(size=len(names))*.25*np.array([PRIOR_SD[k] for k in names])
                if np.isfinite(lp(pos)): start.append(pos); break
            else: raise AuditError(f'Cannot initialize walker {walker}')
        start=np.asarray(start)
    sampler=emcee.EnsembleSampler(NWALKERS,len(names),lp,backend=backend)
    if backend.iteration==0:
        sampler.random_state=np.random.RandomState(RANDOM_SEED+YEAR+(100003 if phase=='biomass_yield' else 0)).get_state()
    else:
        # Explicitly restore the HDF stored RNG and positions, including after an interrupted run.
        start=backend.get_last_sample()
    remaining=max(0,total_steps-backend.iteration)
    if remaining: sampler.run_mcmc(start,remaining,progress=True)
    return export_phase(backend,phase,names,fixed)

def export_phase(backend,phase,names,fixed):
    """Separated so evidence preservation/failure paths can be tested without sampling."""
    chain=backend.get_chain(); logp=backend.get_log_prob()
    n,nw,nd=chain.shape
    full=pd.DataFrame(chain.reshape(-1,nd),columns=names)
    full.insert(0,'walker',np.tile(np.arange(nw),n)); full.insert(0,'step',np.repeat(np.arange(n),nw))
    full['log_probability']=logp.reshape(-1)
    save_csv(full,OUTPUT_DIR/f'mcmc_full_chain_{phase}.csv')
    last=pd.DataFrame(chain[-1],columns=names); last.insert(0,'walker',np.arange(nw)); last['log_probability']=logp[-1]
    save_csv(last,OUTPUT_DIR/f'last_walker_positions_{phase}.csv')
    # Raw chain + last positions are safe before tau, summary, MAP or figures.
    acceptance=backend.accepted/float(n)
    try:
        tau=np.asarray(backend.get_autocorr_time(tol=0),float)
    except Exception as e:
        save_csv(full.iloc[:0],OUTPUT_DIR/f'mcmc_posterior_after_burnin_{phase}.csv')
        raise AuditError(f'chain length insufficient under paper specification: tau unavailable in {phase}; {e}. Full chain and HDF retained; extend original backend.') from e
    valid=np.isfinite(tau).all() and (tau>0).all()
    burn=int(np.ceil(5*tau.max())) if valid else n
    save_csv(pd.DataFrame(dict(Parameter=names,Tau=tau,Phase=phase,Steps=n,Burn_in=burn)),OUTPUT_DIR/f'_diagnostic_{phase}.csv')
    if not valid or burn>=n:
        # There is no scientifically defined retained posterior under this rule.
        save_csv(full.iloc[:0],OUTPUT_DIR/f'mcmc_posterior_after_burnin_{phase}.csv')
        raise AuditError(f'chain length insufficient under paper specification: {phase}; steps={n}, tau={tau}, burn-in={burn}. HDF retained; extend with --steps N --formal.')
    post=full[full.step>=burn].copy()
    save_csv(post,OUTPUT_DIR/f'mcmc_posterior_after_burnin_{phase}.csv')
    best=post.loc[post.log_probability.idxmax(),names]
    values=dict(fixed); values.update({k:float(best[k]) for k in names})
    summary=[]
    for j,k in enumerate(names):
        a=post[k].to_numpy(); lo,hi=PRIOR_BOUNDS[k]; edge=.01*(hi-lo)
        q=np.percentile(a,[2.5,25,50,75,97.5])
        summary.append(dict(Phase=phase,Parameter=k,Mean=a.mean(),Median=q[2],SD=a.std(ddof=1),
            P2_5=q[0],P25=q[1],P75=q[3],P97_5=q[4],MAP=values[k],Tau=tau[j],Burn_in=burn,
            ESS=(n-burn)*nw/tau[j],Prior_low=lo,Prior_high=hi,
            MAP_near_boundary_1pct=min(values[k]-lo,hi-values[k])<=edge,
            P2_5_near_lower_1pct=q[0]<=lo+edge,P97_5_near_upper_1pct=q[4]>=hi-edge,
            Mass_lower_1pct=float(np.mean(a<=lo+edge)),Mass_upper_1pct=float(np.mean(a>=hi-edge))))
    return dict(phase=phase,names=names,chain=chain,post=post,values=values,summary=pd.DataFrame(summary),burn=burn,acceptance=acceptance)

def metrics(obs,sim):
    from scipy.stats import pearsonr,spearmanr
    a=np.asarray(obs,float); b=np.asarray(sim,float); finite(a,'metric obs'); finite(b,'metric sim')
    require(len(a)>=3 and np.std(a)>0,'Insufficient/constant metric observations')
    return dict(N=len(a),RMSE=float(np.sqrt(np.mean((a-b)**2))),R2=float(1-np.sum((a-b)**2)/np.sum((a-a.mean())**2)),
                Pearson_r=float(pearsonr(a,b).statistic) if np.std(b)>0 else np.nan,
                Spearman_rho=float(spearmanr(a,b).statistic) if np.std(b)>0 else np.nan)

def postprocess(data,p1,p2):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    best=p2['values']; s,g,cc,bio=simulate(data,best,'DI'); z=simulate(data,best,'zero')[0]
    status,flags,loss=compare_scenarios(s,z)
    fm=metrics(cc.Observed_CC,cc.canopy_cover)
    rs=data['rs']; rs=rs[(rs.Date>=PLANT)&(rs.Date<HARVEST)].merge(g[['Date','canopy_cover']],on='Date',how='left',validate='one_to_one')
    finite(rs.canopy_cover,'RS exact-date match')
    rm=metrics(rs.RS_CC,rs.canopy_cover)
    lag=int((rs.loc[rs.canopy_cover.idxmax(),'Date']-rs.loc[rs.RS_CC.idxmax(),'Date']).days)
    rm.update(Peak_lag_days=lag,Timing_consistent_within_16days=abs(lag)<=16,Role=ROLES['rs'],Source_metadata=json.dumps(data['rsmeta']))
    save_csv(cc,OUTPUT_DIR/'MAP_CC_comparison.csv'); save_csv(bio,OUTPUT_DIR/'MAP_biomass_comparison.csv')
    save_csv(pd.DataFrame([{**fm,'Role':ROLES['field']}]),OUTPUT_DIR/'CC_Field_performance_metrics.csv')
    save_csv(pd.DataFrame([rm]),OUTPUT_DIR/'CC_RS_temporal_metrics.csv')
    save_csv(pd.DataFrame([{**z,'Yield_loss_pct':loss,'Role':ROLES['zero']}]),OUTPUT_DIR/'zero_irrigation_summary.csv')
    save_csv(pd.DataFrame([{**s,'Published_yield':Y13_PUBLISHED,'Internal_target':Y13_TARGET,
        'Yield_error_pct':100*(s['Y_13pct']/Y13_PUBLISHED-1),'ET_observed':ET_OBS,
        'ET_error_pct':100*(s['ET_mm']/ET_OBS-1),'Tr_target':TR_TARGET,'Es_target':ES_TARGET,
        'Published_irrigation':IRR_PUBLISHED,'Schedule_minus_published_mm':float(data['schedule'].Depth.sum()-IRR_PUBLISHED),
        'Field_R2':fm['R2'],'Zero_Y13':z['Y_13pct'],'Zero_loss_pct':loss,'Process_status':status,
        'Process_flags':'; '.join(flags),'Inference':ROLES['inference']}]),OUTPUT_DIR/'MAP_validation_summary.csv')
    summary=pd.concat([p1['summary'],p2['summary']],ignore_index=True)
    save_csv(summary,OUTPUT_DIR/'posterior_parameter_summary.csv'); save_csv(summary,OUTPUT_DIR/'parameter_estimates.csv')
    save_csv(summary[['Phase','Parameter','Tau','Burn_in','ESS']],OUTPUT_DIR/'autocorrelation_time_summary.csv')
    save_csv(pd.concat([pd.DataFrame(dict(Phase=p['phase'],Walker=np.arange(NWALKERS),Acceptance_fraction=p['acceptance'])) for p in [p1,p2]]),OUTPUT_DIR/'acceptance_diagnostic.csv')
    def figsave(name):
        plt.tight_layout(); plt.savefig(OUTPUT_DIR/name,dpi=250,bbox_inches='tight'); plt.close()
    for field in [True,False]:
        plt.figure(figsize=(9,5)); plt.plot(g.Date,g.canopy_cover,label='AquaCrop MAP')
        if field: plt.scatter(cc.Date,cc.Observed_CC,label='Field CC (calibration)')
        plt.scatter(rs.Date,rs.RS_CC,marker='x',label='RS auxiliary'); plt.xlim(PLANT,HARVEST); plt.ylim(0,1)
        plt.ylabel('Canopy cover'); plt.legend()
        label=f"RS temporal r={rm['Pearson_r']:.3f}, rho={rm['Spearman_rho']:.3f}"
        if field: label=f"Field R2={fm['R2']:.3f}, RMSE={fm['RMSE']:.3f}, r={fm['Pearson_r']:.3f}\n"+label
        plt.title(label); figsave('MAP_CC_validation.png' if field else 'MAP_CC_RS_temporal_validation.png')
    plt.figure(figsize=(8,5)); plt.plot(g.Date,g.Biomass_t_ha,label='MAP')
    plt.errorbar(bio.Date,bio.Observed_B_t_ha,yerr=bio.Sigma_assumed,fmt='o',label='Digitized approximate biomass calibration')
    plt.ylabel('Aboveground dry biomass (t/ha)'); plt.legend(); figsave('MAP_biomass_calibration.png')
    for name,labels,vals in [('MAP_yield_observed_vs_simulated.png',['Published','Internal target','Grouped MAP'],[Y13_PUBLISHED,Y13_TARGET,s['Y_13pct']]),
                             ('Yield_DI_vs_ZeroIrrigation.png',['DI','Zero irrigation'],[s['Y_13pct'],z['Y_13pct']])]:
        plt.figure(figsize=(7,5)); plt.bar(labels,vals); plt.ylabel('Yield at 13% moisture (t/ha)'); figsave(name)
    for p in [p1,p2]:
        for j,k in enumerate(p['names']):
            plt.figure(figsize=(9,4)); plt.plot(p['chain'][:,:,j],alpha=.25); plt.axvline(p['burn'],color='k',ls='--'); plt.ylabel(k); plt.xlabel('Step'); figsave(f'trace_{k}.png')
            plt.figure(figsize=(6,4)); plt.hist(p['post'][k],bins=40); plt.xlabel(k); figsave(f'posterior_{k}.png')
        corr=p['post'][p['names']].corr()
        save_csv(corr.rename_axis('Parameter').reset_index(),OUTPUT_DIR/f'posterior_correlation_{p["phase"]}.csv')
    metadata={**ROLES,'YEAR':YEAR,'walkers':NWALKERS,'phase1_steps':len(p1['chain']),'phase2_steps':len(p2['chain']),
        'biomass_source':str(BIOMASS_FILE),'initial_water_source':str(INITIAL_WATER_FILE),'RS_metadata':json.dumps(data['rsmeta']),
        'soil_grid':'24 x 0.1m','mulch_pct':75,'f_mulch':0,'WP_structure':'two-stage effective' if YEAR==2022 else 'single annual WP',
        'phenology_caveat':'HIstartCD provisional anchor','Es_sigma_assumed_mm':SIGMA_ES,'Tr_sigma_assumed_mm':SIGMA_TR,
        'initial_water_caveat':'0–1m approximate figure reconstruction; deep ERA5-Land retained',
        'post_MAP_process_status':status,'post_MAP_process_flags':'; '.join(flags),'checkpoint_policy':'HDF retained for extension and reproducibility'}
    save_csv(pd.DataFrame(metadata.items(),columns=['Setting','Value']),OUTPUT_DIR/'run_metadata.csv')
    for p in [p1,p2]:
        diagnostic=OUTPUT_DIR/f'_diagnostic_{p["phase"]}.csv'
        if diagnostic.exists(): diagnostic.unlink()  # Superseded by combined successful diagnostics.
    # HDF deliberately retained even on success; all requested outputs already safe.
    print(f'Completed {YEAR}; MAP process status={status}; {flags}',flush=True)

def main(argv=None):
    parser=argparse.ArgumentParser(description=ROLES['inference'])
    parser.add_argument('--formal',action='store_true',help='Explicit opt-in; default only PRE-RUN')
    parser.add_argument('--steps',type=int,default=NSTEPS,help='Total steps per phase, including existing HDF iterations')
    parser.add_argument('--output',type=Path,default=None,help='Override result directory without editing scientific configuration')
    args=parser.parse_args(argv)
    global OUTPUT_DIR
    if args.output is not None: OUTPUT_DIR=args.output.resolve()
    OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
    require(args.steps>=NSTEPS,'Formal specification requires >=2000 steps per phase')
    data=load_inputs(); load_phase1_start(data); prepare_soil(data)
    print(f'DATA AVAILABILITY AUDIT {YEAR}: Field={len(data["field"])}, biomass={len(data["bio"])}, Phase2={data["bio_error"] or "AVAILABLE"}',flush=True)
    status,flags=pre_run(data)
    if status=='FAIL': raise AuditError('PRE_RUN_STATUS = FAIL; '+ '; '.join(flags))
    frozen_regression(data)
    if data['bio_error']:
        print(data['bio_error'],flush=True)
        if args.formal: raise AuditError(data['bio_error'])
    if not args.formal:
        print('PRE-RUN only completed. No MCMC performed.',flush=True); return
    require(not data['bio_error'],data['bio_error'])
    raise AuditError('APPROXIMATE_BIOMASS_REVIEW_REQUIRED: inspect phase2 diagnostic, bounds and uncertainty sensitivity before formal MCMC')
    if status=='REVIEW' and STOP_BEFORE_FORMAL_MCMC_ON_REVIEW:
        raise AuditError('STOP_BEFORE_FORMAL_MCMC_ON_REVIEW=True; manual review required before changing this switch')
    try: import emcee, h5py
    except ImportError as e: raise AuditError('Formal sampling requires emcee and h5py; no checkpoint fallback allowed') from e
    p1=run_phase(data,'canopy_transpiration',PHASE1_NAMES,dict(data.get('start',data['center'])),args.steps)
    save_csv(pd.DataFrame([p1['values']]),OUTPUT_DIR/'phase1_MAP_point.csv')
    simulate(data,p1['values'],'DI')  # Fresh full MAP run before phase 2
    p2=run_phase(data,'biomass_yield',PHASE2_NAMES,p1['values'],args.steps)
    save_csv(pd.DataFrame([p2['values']]),OUTPUT_DIR/'grouped_MAP_point.csv')
    postprocess(data,p1,p2)

def read_audited_eto_b(weather):
    """Read annual ERA5-Land B export; independently recompute ETo, never fit a scale."""
    required=['Date','Tmin_C','Tmax_C','Tmean_C','Tdew_C','Pressure_kPa','Precip_mm',
              'Rn_ERA5_MJ','Wind2m_A_ms','Wind2m_B_ms','ETo_A_raw','ETo_B_raw','ETo_A_mm','ETo_B_mm',
              'Hourly_image_count','Hourly_valid_count','Hourly_vs_daily_vector_ms','Day_basis',
              'Wind_method','Latitude','Longitude','Daily_source','Hourly_source']
    require(ETO_FILE.is_file(),f'MISSING_AUDITED_ETO_B: {YEAR}; {ETO_FILE}. Run Export_DI_2019_2022_ETo_B_GEE.js; do not scale old ETo or copy 2022 weather.')
    e=unique_dates(read_csv(ETO_FILE,required))
    require(pd.DatetimeIndex(e.Date).equals(pd.DatetimeIndex(weather.Date)),'Audited ETo year/date coverage mismatch')
    numeric=[c for c in required if c not in ['Date','Day_basis','Wind_method','Daily_source','Hourly_source']]
    for c in numeric: e[c]=pd.to_numeric(e[c],errors='raise')
    finite(e[numeric],'audited ETo source')
    require(e.Day_basis.eq('UTC').all() and e.Wind_method.eq('ERA5LAND_UTC_SCALAR_WIND_B_v1').all(),'ETo day basis/method mismatch')
    require(e.Daily_source.eq('ECMWF/ERA5_LAND/DAILY_AGGR').all() and e.Hourly_source.eq('ECMWF/ERA5_LAND/HOURLY').all(),'ETo source dataset mismatch')
    require(e.Hourly_image_count.eq(24).all() and e.Hourly_valid_count.eq(24).all(),'Hourly wind incomplete; no daily interpolation allowed')
    require(np.allclose(e.Longitude,102.87597633340303,atol=1e-9,rtol=0) and np.allclose(e.Latitude,37.82250517046916,atol=1e-9,rtol=0),'ETo geometry differs from frozen 2022 extraction')
    require((e.Wind2m_A_ms>=0).all() and (e.Wind2m_B_ms>=e.Wind2m_A_ms-1e-7).all(),'Wind scalar/vector consistency failed')
    require(e.Hourly_vs_daily_vector_ms.abs().max()<1e-6,'Hourly/daily wind-vector mismatch')
    require((e.Pressure_kPa>0).all() and (e.Tmin_C<=e.Tmax_C).all(),'ETo pressure/temperature QC')
    for ec,wc in [('Tmin_C','MinTemp'),('Tmax_C','MaxTemp'),('Precip_mm','Precipitation')]:
        require(np.allclose(e[ec],weather[wc],atol=1e-6,rtol=0),f'Original weather vs audited ETo source mismatch: {ec}; stop instead of overwriting temperatures/rainfall')
    def esat(t): return .6108*np.exp(17.27*t/(t+237.3))
    delta=4098*esat(e.Tmean_C)/(e.Tmean_C+237.3)**2
    gamma=.000665*e.Pressure_kPa
    vpd=np.maximum(0,(esat(e.Tmax_C)+esat(e.Tmin_C))/2-esat(e.Tdew_C))
    for tag in ['A','B']:
        wind=e[f'Wind2m_{tag}_ms']
        reconstructed=(.408*delta*e.Rn_ERA5_MJ+gamma*900/(e.Tmean_C+273)*wind*vpd)/(delta+gamma*(1+.34*wind))
        require(np.allclose(reconstructed,e[f'ETo_{tag}_raw'],atol=1e-7,rtol=0),f'ETo {tag} equation reconstruction failed')
        require(np.allclose(np.maximum(reconstructed,0),e[f'ETo_{tag}_mm'],atol=1e-7,rtol=0),f'ETo {tag} clipping convention mismatch')
    # Rebuild 2022 with the SAME export script; this isolates source/geometry drift.
    require(ETO_CONTROL_FILE.is_file(),f'MISSING_2022_ETO_CONTROL: {ETO_CONTROL_FILE}; export the 2022 control too')
    ctrl=unique_dates(read_csv(ETO_CONTROL_FILE,['Date','ETo_B_mm','Tmin_C','Tmax_C','Precip_mm','Hourly_valid_count','Hourly_image_count']))
    frozen=unique_dates(read_csv(FROZEN_2022_ETO_FILE,['Date','ETo_B_mm','Tmin_C','Tmax_C','Precip_mm']))
    require(pd.DatetimeIndex(ctrl.Date).equals(pd.DatetimeIndex(frozen.Date)),'2022 ETo control date mismatch')
    finite(ctrl[['ETo_B_mm','Tmin_C','Tmax_C','Precip_mm','Hourly_valid_count','Hourly_image_count']],'2022 control')
    require(ctrl.Hourly_valid_count.eq(24).all() and ctrl.Hourly_image_count.eq(24).all(),'2022 control hourly coverage')
    for c in ['ETo_B_mm','Tmin_C','Tmax_C','Precip_mm']:
        require(np.allclose(ctrl[c],frozen[c],atol=1e-6,rtol=0),f'2022 ETo control cannot reproduce frozen {c}; inspect source/geometry, do not relax tolerance silently')
    season=weather.Date.isin(DATES)
    old=float(weather.loc[season,'ReferenceET'].sum()); a=float(e.loc[season,'ETo_A_mm'].sum()); b=float(e.loc[season,'ETo_B_mm'].sum())
    source_delta=100*(a/old-1) if old>0 else float('inf')
    global ETO_AUDIT_REVIEW
    ETO_AUDIT_REVIEW=[]
    # Declared attribution check, not a calibrated correction factor.
    if abs(source_delta)>2:
        ETO_AUDIT_REVIEW.append('ETo A differs from legacy seasonal ETo by >2%; source attribution needs review')
    audit=dict(Year=YEAR,Old_ETo_mm=old,A_ETo_mm=a,B_ETo_mm=b,A_vs_old_pct=source_delta,
               B_minus_A_mm=b-a,Method='hourly scalar-wind correction only',Control2022='PASS',
               Source_review='; '.join(ETO_AUDIT_REVIEW))
    save_csv(pd.DataFrame([audit]),OUTPUT_DIR/'ETo_source_audit.csv')
    print('ETO SOURCE AUDIT:',audit,flush=True)
    result=weather.copy(); result['ReferenceET']=e.ETo_B_mm.to_numpy(float)
    return result



def load_phase1_start(data):
    tab=read_csv(PHASE1_START_POINT_FILE,PHASE1_NAMES)
    require(len(tab)==1,'Phase-1 deterministic start must have one row')
    values=dict(data['center'])
    for k in PHASE1_NAMES:
        v=float(tab.iloc[0][k]); lo,hi=PRIOR_BOUNDS[k]
        require(np.isfinite(v) and lo<=v<=hi,'Phase-1 start outside bounds: '+k)
        values[k]=v
    data['start']=values
    data['start_boundary_flags']=[k+' deterministic start within 1% of prior boundary'
        for k in PHASE1_NAMES if min(values[k]-PRIOR_BOUNDS[k][0],PRIOR_BOUNDS[k][1]-values[k])
        <=.01*(PRIOR_BOUNDS[k][1]-PRIOR_BOUNDS[k][0])]
    print('Using deterministic Phase-1 starting point, NOT a posterior/prior center:',values,flush=True)

if __name__=='__main__':
    raise SystemExit('Use DI_YYYY_MCMC.py in the package root; this is a model engine, not a sampling entry point.')

