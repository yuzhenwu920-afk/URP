
"""Rank-normalized folded split Rhat and split bulk/tail ESS.
Definitions: https://mc-stan.org/docs/reference-manual/analysis.html
ESS uses Geyer positive, monotone paired autocorrelations; conservatively capped
at actual draws (no antithetic ESS bonus). Chains here are INDEPENDENT chains.
"""
import numpy as np
from scipy.stats import rankdata,norm

def split(x):
    half=x.shape[1]//2
    return np.concatenate([x[:,:half],x[:,-half:]],axis=0)

def ranks(x):
    r=rankdata(x.ravel(),method='average')
    return norm.ppf((r-.375)/(len(r)+.25)).reshape(x.shape)

def basic_rhat(x):
    n=x.shape[1];W=np.mean(np.var(x,axis=1,ddof=1))
    if W<=0: return float('inf')
    varplus=(n-1)/n*W+np.var(x.mean(axis=1),ddof=1)
    return float(np.sqrt(varplus/W))

def ess(x):
    m,n=x.shape
    W=np.mean(np.var(x,axis=1,ddof=1))
    vp=(n-1)/n*W+np.var(x.mean(axis=1),ddof=1)
    if not np.isfinite(vp) or vp<=0: return 0.
    centered=x-x.mean(axis=1,keepdims=True)
    size=1<<(2*n-1).bit_length()
    f=np.fft.rfft(centered,n=size,axis=1)
    acov=np.fft.irfft(f*np.conjugate(f),n=size,axis=1)[:,:n]/n
    rho=1-(W-acov.mean(axis=0))/vp;rho[0]=1.
    pairs=[]
    for lag in range(0,n-1,2):
        pair=float(rho[lag]+rho[lag+1])
        if pair<0: break
        pairs.append(min(pair,pairs[-1]) if pairs else pair)
    tau=max(1.,-1+2*sum(pairs))
    return float(m*n/tau)

def diagnose(chains,names):
    # chains shape: independent chain, retained draw, parameter
    reports=[]
    for j,name in enumerate(names):
        x=np.asarray(chains[:,:,j],float)
        valid=x.shape[0]>=4 and x.shape[1]>=8 and np.isfinite(x).all()
        if valid:
            s=split(x);z=ranks(s)
            r=max(basic_rhat(z),basic_rhat(ranks(np.abs(s-np.median(s)))))
            bulk=ess(z);ql,qh=np.quantile(s,[.05,.95]);tail=min(ess((s<=ql).astype(float)),ess((s<=qh).astype(float)))
        else: r=float('inf');bulk=tail=0.
        passed=bool(x.shape[1]>=100 and np.isfinite(r) and r<1.01 and bulk>=400 and tail>=400)
        reports.append(dict(Parameter=name,Rhat=float(r) if np.isfinite(r) else None,ESS_bulk=bulk,ESS_tail=tail,Passed=passed))
    return reports

