
"""Four independent emcee ensembles; coupled walkers are NOT independent chains."""
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
from emcee.autocorr import integrated_time
from _di_2021_sampler import atomic_json,run_ensemble
from _di_2021_diagnostics import diagnose

def analyze(phase,names,raw,logs,accept,lower,upper,out,smoke):
    ensembles,n,walkers,dim=raw.shape
    tables=[]
    for e in range(ensembles):
        t=pd.DataFrame(raw[e].reshape(-1,dim),columns=names)
        t.insert(0,'Walker',np.tile(np.arange(walkers),n));t.insert(0,'Step',np.repeat(np.arange(n),walkers));t.insert(0,'Ensemble',e)
        t['Log_posterior']=logs[e].ravel();t['Accepted']=accept[e].ravel();tables.append(t)
    full=pd.concat(tables,ignore_index=True)
    # Raw draws and final walkers are persisted BEFORE autocorrelation/plotting.
    full.to_csv(out/f'mcmc_full_chain_{phase}.csv',index=False)
    full[full.Step==n-1].to_csv(out/f'last_walker_positions_{phase}.csv',index=False)
    taus=[]
    for e in range(ensembles):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            try: tau=integrated_time(raw[e],tol=0)
            except (ValueError,IndexError): tau=np.full(dim,np.nan)
        taus.append(tau)
    taus=np.array(taus);valid=bool(np.isfinite(taus).all() and (taus>0).all())
    burn=int(np.ceil(5*taus.max())) if valid else None
    usable=burn is not None and burn<n
    post=full[full.Step>=burn].copy() if usable else full.iloc[:0].copy()
    post.to_csv(out/f'mcmc_posterior_after_burnin_{phase}.csv',index=False)
    retained=raw[:,burn:,:,:] if usable else raw[:,:0,:,:]
    # Compare each fixed walker index ACROSS independent ensembles. Never pool
    # walkers from the same ensemble as independent chains for Rhat or ESS.
    groups=[diagnose(retained[:,:,w,:],names) for w in range(walkers)] if usable else []
    rows=[]
    for j,k in enumerate(names):
        values=[g[j] for g in groups]
        rh=[v['Rhat'] for v in values]
        r=max(rh) if rh and all(v is not None for v in rh) else None
        bulk=min(v['ESS_bulk'] for v in values) if values else 0.
        tail=min(v['ESS_tail'] for v in values) if values else 0.
        passed=bool(values and all(v['Passed'] for v in values))
        rows.append(dict(Parameter=k,Rhat_max_across_walker_groups=r,ESS_bulk_min=bulk,ESS_tail_min=tail,Passed=passed))
    tau_trusted=bool(valid and n>=50*taus.max())
    passed=bool(not smoke and n>=2000 and usable and tau_trusted and all(r['Passed'] for r in rows))
    atomic_json(out/f'{phase}_diagnostics.json',dict(Converged=passed,Smoke_test=smoke,
        Burn_in=burn,Rule='ceil(5 * maximum tau across parameters and independent ensembles); NO fixed fallback',
        Tau_by_ensemble=[[float(v) if np.isfinite(v) else None for v in row] for row in taus],
        Tau_estimate_trusted_50tau=tau_trusted,Parameters=rows,
        Acceptance_by_ensemble_walker=accept.mean(axis=1).tolist(),
        Status='CONVERGED' if passed else 'SMOKE_NOT_INFERENCE' if smoke else 'CHAIN_LENGTH_OR_CONVERGENCE_INSUFFICIENT',
        Rhat_scope='Conservative maximum over matched-walker groups across 4 independent ensembles; not 128 independent chains',
        Criteria='>=2000 total steps; Rhat<1.01, bulk/tail ESS>=400 in each group; >=100 retained steps; chain>=50*max(tau)',
        References=['https://emcee.readthedocs.io/en/stable/user/autocorr/','https://mc-stan.org/docs/reference-manual/analysis.html']))
    # Test-only point permits exercising phase 2; never called a posterior MAP.
    eligible=post if len(post) else full if smoke else None
    best={}
    if eligible is not None:
        row=eligible.loc[eligible.Log_posterior.idxmax()];best={k:float(row[k]) for k in names}
    summaries=[]
    if len(post):
        for j,k in enumerate(names):
            v=post[k].to_numpy();q=np.quantile(v,[.025,.25,.5,.75,.975]);edge=.01*(upper[j]-lower[j])
            summaries.append(dict(Phase=phase,Mean=v.mean(),SD=v.std(ddof=1),Median=q[2],
                P2_5=q[0],P25=q[1],P75=q[3],P97_5=q[4],MAP=best[k],Tau=float(taus[:,j].max()),
                Burn_in=burn,ESS=rows[j]['ESS_bulk_min'],Prior_low=lower[j],Prior_high=upper[j],
                MAP_near_boundary_1pct=bool(min(best[k]-lower[j],upper[j]-best[k])<=edge),
                Mass_lower_1pct=float(np.mean(v<=lower[j]+edge)),Mass_upper_1pct=float(np.mean(v>=upper[j]-edge)),**rows[j]))
    summary=pd.DataFrame(summaries)
    summary.to_csv(out/f'{phase}_summary.csv',index=False)
    combined=raw.transpose(1,0,2,3).reshape(n,ensembles*walkers,dim)
    return dict(phase=phase,names=names,best=best,converged=passed,summary=summary,
        chain=combined,post=post,burn=burn,acceptance=accept.mean(axis=1).ravel(),
        retained=retained.reshape(ensembles,-1,dim),smoke=smoke)

def run_phase(m,data,fixed,names,phase,args,out,cn,cached=False):
    lower=np.array([m.PRIOR_BOUNDS[k][0] for k in names]);upper=np.array([m.PRIOR_BOUNDS[k][1] for k in names])
    start=np.array([fixed[k] for k in names]);allx=[];allp=[];alla=[]
    for e in range(4):
        path=out/'checkpoints'/phase/f'ensemble_{e+1}.npz'
        if cached:
            with np.load(path,allow_pickle=False) as f: x=f['history'];p=f['logs'];a=f['accepted']
        else:
            x,p,a=run_ensemble(lambda v:m.logprob(v,names,fixed,phase,data),start,lower,upper,
                args.steps,args.walkers,args.seed+m.YEAR*100+e+(100000 if phase=='biomass_yield' else 0),
                path,dict(cn,ensemble=e),args.checkpoint_every)
        allx.append(x);allp.append(p);alla.append(a)
    result=analyze(phase,names,np.array(allx),np.array(allp),np.array(alla),lower,upper,out,args.smoke)
    result['values']=dict(fixed,**result['best'])
    atomic_json(out/f'{phase}_sampled_MAP.json',dict(values=result['values'] if result['best'] else None,
        Converged=result['converged'],Smoke_test=args.smoke,
        Meaning='Test-only point, NOT posterior MAP' if args.smoke else 'Maximum retained sampled log posterior; not globally optimized MAP'))
    return result

