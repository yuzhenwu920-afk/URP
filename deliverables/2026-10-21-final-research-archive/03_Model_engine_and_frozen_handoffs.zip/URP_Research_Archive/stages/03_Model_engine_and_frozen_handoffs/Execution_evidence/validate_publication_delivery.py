from pathlib import Path
import hashlib,json,shutil,zipfile
from lxml import etree
import fitz,openpyxl

ROOT=Path(__file__).resolve().parent
PUB=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/actual_publication_20261019')
AUDIT=ROOT/'delivery_audit'
name='URP_Sobol_NSGAIII_paper_with_actual_results'
with zipfile.ZipFile(PUB/(name+'.docx')) as z:
    xml=etree.fromstring(z.read('word/document.xml'))
    ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math','w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    math_count=len(xml.findall('.//m:oMath',ns))
    table_count=len(xml.findall('.//w:tbl',ns))
    media_count=len([n for n in z.namelist() if n.startswith('word/media/')])
assert (math_count,table_count,media_count)==(10,15,34)
pdf=fitz.open(PUB/(name+'.pdf'))
pages=[{'page':i+1,'text_characters':len(p.get_text().strip()),'images':len(p.get_image_info())} for i,p in enumerate(pdf)]
assert len(pdf)==44 and sum(p['images'] for p in pages)==34
assert min(p['text_characters'] for p in pages)>=80
for i in [3,17,19,24,25,35]:
    pdf[i].get_pixmap().save(str(ROOT/f'FINAL_PAPER_PAGE_{i+1}.png'))
workbook=openpyxl.load_workbook(PUB/'URP_Sobol_NSGAIII_results_tables.xlsx',read_only=True,data_only=True)
registry=json.loads((PUB/'FIGURE_REGISTRY.json').read_text())
assert len(registry['figures'])==16
assert all(e['years']==[2019,2020,2021,2022] for e in registry['figures'])
assert all(e['font_minimum_pt']>=11 for e in registry['figures'])
result={'status':'PASS','Word_editable_OMML_equations':math_count,'Word_tables':table_count,'Word_embedded_figures':media_count,
        'PDF_pages':len(pdf),'PDF_rendered_images':34,'PDF_blank_or_caption_only_overflow_pages':0,
        'visually_inspected_pages':[4,18,20,25,26,36],
        'actual_and_updated_context_figure_groups':16,'all_actual_figures_include_four_years':True,
        'minimum_actual_figure_source_font_pt':11,'workbook_sheets':workbook.sheetnames,
        'publication_files_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in PUB.iterdir() if f.suffix in ['.docx','.pdf','.xlsx','.md']},
        'PDF_page_checks':pages}
(AUDIT/'PUBLICATION_VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
for n in ['ALL_RESULTS_VERIFICATION.json']:
    shutil.copyfile(ROOT/'compact_results'/n,AUDIT/n)
shutil.copyfile(ROOT/'FORMAL_EXPERIMENT.log',AUDIT/'FORMAL_EXPERIMENT.log')
print(json.dumps({k:v for k,v in result.items() if k not in ['PDF_page_checks','publication_files_sha256','workbook_sheets']},ensure_ascii=False))
