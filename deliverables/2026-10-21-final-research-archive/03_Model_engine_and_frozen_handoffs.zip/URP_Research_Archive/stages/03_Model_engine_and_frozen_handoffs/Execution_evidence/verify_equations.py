from pathlib import Path
import sys,json,time
import numpy as np
sys.path.insert(0,'/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
from model_adapter import *
ROOT=Path(__file__).resolve().parent
mode=sys.argv[1];s=load_study();m=RealModel(s);rng=np.random.default_rng(8123)
records=[]
for year in s['years']:
 spec=m.management_space(year)
 cases=[('center',s['_centers'][year],None)]
 for j in range(3):
  p={k:float(rng.uniform(*s['global_physical_bounds'][k])) for k in NAMES}
  cases.append((f'global_{j}',p,None))
 for j in range(3):
  x=rng.dirichlet(np.ones(4))*spec['upper'][0]*rng.uniform(.1,1.)
  cases.append((f'management_{j}',s['_centers'][year],management(spec,x)))
 for name,p,request in cases:
  t=time.perf_counter();r=m.module.simulate(params=p,year=year,management=request,accelerate=mode=='compiled')
  validate_output(r)
  if request is not None:check_management_response(r,spec,[request['values'][k] for k in spec['names']])
  records.append({'year':year,'case':name,'params':p,'request':request,'output':r,'seconds':time.perf_counter()-t})
  print(mode,year,name,r['Y_13pct'],flush=True)
(ROOT/f'verification_{mode}.json').write_text(json.dumps(records,indent=2))
