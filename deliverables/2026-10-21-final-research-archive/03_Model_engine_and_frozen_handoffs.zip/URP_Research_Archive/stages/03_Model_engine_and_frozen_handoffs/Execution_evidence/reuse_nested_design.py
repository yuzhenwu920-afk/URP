from pathlib import Path
import sys,json
import numpy as np,pandas as pd
sys.path.insert(0,'/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
from model_adapter import *
import phaseB_sobol as B
root=HERE/'output_real_20261019';study=load_study();model=RealModel(study)
expanded=read(root/'SOBOL_EXPANSION_DECISION.json')['expanded_years'];report=[]
for year in expanded:
 for seed in study['sobol']['seeds']:
  old=root/'sobol_global_N128'/f'{year}_seed{seed}';new=root/'sobol_global_N512'/f'{year}_seed{seed}'
  if new.exists():raise RuntimeError('Do not mutate an already started run')
  x=B.sample_sobol.sample(B.make_problem(study,year,'global'),512,calc_second_order=False,scramble=True,seed=seed)
  oldx=np.load(old/'design.npy',allow_pickle=False)
  if not np.array_equal(x[:len(oldx)],oldx):raise RuntimeError('Design is not exactly nested')
  identity=read(old/'run.json')['identity']
  if identity['model']!=model.identity:raise RuntimeError('Engine mismatch')
  identity.update(N=512,expected_calls=5120)
  new.mkdir(parents=True)
  np.save(new/'design.npy',x,allow_pickle=False)
  csv(new/'design.csv',pd.DataFrame(x,columns=NAMES).rename_axis('row_id').reset_index())
  write(new/'space.json',dict(B.make_problem(study,year,'global'),Distribution='independent_uniform',Meaning='physical_global'))
  old_journal=old/'responses.jsonl'
  (new/'responses.jsonl').write_bytes(old_journal.read_bytes())
  source={'source':str(old.relative_to(root)),'response_sha256':sha(old_journal),'exact_nested_rows':len(oldx),'new_rows_to_evaluate':len(x)-len(oldx),'no_interpolation_or_response_approximation':True}
  write(new/'NESTED_REUSE.json',source)
  write(new/'run.json',{'status':'RUNNING','identity':identity,'completed':len(oldx),'design_sha256':sha(new/'design.npy'),'reused_exact_prefix':source})
  report.append({'year':year,'seed':seed,**source})
write(root/'NESTED_DESIGN_REUSE.json',report)
print('Exact nested response rows reused',sum(r['exact_nested_rows'] for r in report),'new calls',sum(r['new_rows_to_evaluate'] for r in report))
