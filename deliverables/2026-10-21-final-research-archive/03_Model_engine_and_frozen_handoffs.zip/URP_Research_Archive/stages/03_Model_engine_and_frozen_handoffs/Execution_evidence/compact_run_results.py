"""Lossless numeric archives of completed original response and population files."""
from pathlib import Path
import json
import hashlib
import shutil
import numpy as np
import pandas as pd
from read_complete_results import calculate,load_columns

PROJECT=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
RUN=PROJECT/'output_real_20261019'
OUT=Path('/workspace/urp_true_runs_20261019/compact_results')


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
def copy(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)


def pack_columns(df,path,extra_descriptors=None):
    arrays={}
    schema={}
    for col in df.columns:
        a=df[col].to_numpy()
        if a.dtype.kind=='O':
            if any(not isinstance(v,str) for v in a):raise ValueError('Unexpected object column '+col)
            a=a.astype(str)
        arrays[col]=a;schema[col]=str(a.dtype)
    descriptors={
        'Y_dry':{'op':'multiply','column':'Y_13pct','value':.87},
        'ET_mm':{'op':'add','a':'Tr_mm','b':'Es_mm'},
        'Planned_irrigation_mm':{'op':'copy','column':'Irrigation_mm'},
        'Profile_final_mm':{'op':'storage'},
        'IWP_kg_m3':{'op':'ratio','scale':100.,'numerator':'Y_13pct','denominator':'Irrigation_mm'},
        'ETWP_kg_m3':{'op':'ratio','scale':100.,'numerator':'Y_13pct','denominator':'ET_mm'}}
    controls=[k for k in df.columns if k.startswith('Window') and k.endswith('_mm')]
    if controls:descriptors['Irrigation_mm']={'op':'sum','columns':controls}
    descriptors.update(extra_descriptors or {})
    encoding={};storage=dict(arrays)
    for col,recipe in descriptors.items():
        if col not in arrays or arrays[col].dtype!=np.float64:continue
        try:pred=np.ascontiguousarray(calculate(recipe,arrays),dtype=np.float64)
        except KeyError:continue
        storage['_xor_'+col]=np.bitwise_xor(arrays[col].view(np.uint64),pred.view(np.uint64))
        del storage[col];encoding[col]=recipe
    storage['_column_names']=np.array(list(df.columns),dtype=str)
    storage['_encoding_json']=np.array(json.dumps(encoding))
    np.savez_compressed(path,**storage)
    restored=load_columns(path)
    for col,a in arrays.items():
        b=restored[col].to_numpy()
        if a.dtype.kind=='U':np.testing.assert_array_equal(b.astype(str),a,strict=True)
        elif a.dtype==np.float64:np.testing.assert_array_equal(b.view(np.uint64),a.view(np.uint64),strict=True)
        else:np.testing.assert_array_equal(b,a,strict=True)
    return schema


def optimization(folder):
    target=OUT/folder.relative_to(RUN);target.mkdir(parents=True,exist_ok=True)
    marker=target/'LOSSLESS_REPACK.json'
    source=folder/'evaluations.csv.gz'
    if not source.exists():return
    source_sha=sha(source)
    if marker.exists() and json.loads(marker.read_text()).get('source_evaluations_sha256')==source_sha and json.loads(marker.read_text()).get('format_version')==4:return
    df=pd.read_csv(source,float_precision='round_trip')
    identity=json.loads((folder/'run.json').read_text())['identity'];cap=float(identity['space']['upper'][0]);gate=float(identity['yield_gate_t_ha'])
    schema=pack_columns(df,target/'all_evaluations_columns.npz',{
        'G_yield':{'op':'scaled_difference','constant':gate,'column':'Y_13pct','divisor':gate/.95},
        'G_irrigation':{'op':'scaled_difference','constant':cap,'column':'Irrigation_mm','divisor':-cap}})
    paths=sorted(folder.glob('generation_*.npz'))
    generations=[];buffers={k:[] for k in ['X','F','G','CV']}
    for p in paths:
        generations.append(int(p.stem.split('_')[-1]))
        with np.load(p,allow_pickle=False) as z:
            for k in buffers:buffers[k].append(z[k])
    stacked={k:np.stack(v) for k,v in buffers.items()}
    stacked['Generation']=np.array(generations,dtype=np.int64)
    np.savez_compressed(target/'all_generations.npz',**stacked)
    with np.load(target/'all_generations.npz',allow_pickle=False) as z:
        for index,p in enumerate(paths):
            with np.load(p,allow_pickle=False) as source_npz:
                for k in buffers:np.testing.assert_array_equal(z[k][index],source_npz[k],strict=True)
    for p in folder.iterdir():
        if p.is_file() and not p.name.startswith('generation_') and p.name!='evaluations.csv.gz':copy(p,target/p.name)
    write(marker,{'status':'ALL_VALUES_VERIFIED_EXACT','format_version':4,'source_evaluations_sha256':source_sha,'evaluation_rows':len(df),
        'evaluation_column_schema':schema,'generation_count':len(paths),'population_arrays':['X','F','G','CV'],
        'source_generation_sha256':{p.name:sha(p) for p in paths},'no_rounding_or_dtype_reduction':True,
        'archive_files':['all_evaluations_columns.npz','all_generations.npz']})
    print('Packed',folder.relative_to(RUN),len(df),'evaluations',flush=True)


def sensitivity(folder):
    target=OUT/folder.relative_to(RUN);target.mkdir(parents=True,exist_ok=True)
    marker=target/'LOSSLESS_REPACK.json';source=folder/'responses.jsonl';source_sha=sha(source)
    if marker.exists() and json.loads(marker.read_text()).get('source_responses_sha256')==source_sha and json.loads(marker.read_text()).get('format_version')==4:return
    records=[json.loads(line) for line in source.read_text().splitlines()]
    rows=[];timings=[];params=[]
    dates=None
    for r in records:
        row={'row_id':r['row_id']};params.append(r['params']);timings.append(r['seconds'])
        for k,v in r['output'].items():
            if k=='irrigation_events':
                current=[{'date':e['date'],'stage':e['stage']} for e in v]
                if dates is None:dates=current
                if current!=dates:raise ValueError('Event date/stage structure varies unexpectedly')
                for j,e in enumerate(v):row[f'actual_event_{j+1}_mm']=e['mm']
            else:row[k]=v
        rows.append(row)
    df=pd.DataFrame(rows);schema=pack_columns(df,target/'all_response_columns.npz')
    np.save(target/'response_seconds.npy',np.asarray(timings),allow_pickle=False)
    np.testing.assert_array_equal(np.array(params),np.load(folder/'design.npy',allow_pickle=False))
    for p in folder.iterdir():
        if p.is_file() and p.name!='responses.jsonl':copy(p,target/p.name)
    write(marker,{'status':'ALL_VALUES_VERIFIED_EXACT','format_version':4,'source_responses_sha256':source_sha,'response_rows':len(df),
        'column_schema':schema,'event_structure':dates,'no_rounding_or_dtype_reduction':True,
        'parameters_match_original_design':True,'archive_files':['all_response_columns.npz','response_seconds.npy']})
    print('Packed',folder.relative_to(RUN),len(df),'responses',flush=True)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    copy(Path(__file__).with_name('read_complete_results.py'),OUT/'read_complete_results.py')
    copy(Path(__file__).with_name('verify_all_actual_results.py'),OUT/'verify_all_actual_results.py')
    for p in sorted(RUN.glob('optimization/*/*/run.json')):
        if json.loads(p.read_text())['status'] in ['COMPLETE','NO_FEASIBLE_SOLUTION']:optimization(p.parent)
    for p in sorted(RUN.glob('sobol_global_N*/*/run.json')):
        if json.loads(p.read_text())['status']=='COMPLETE':sensitivity(p.parent)
    for p in RUN.iterdir():
        if p.is_file():copy(p,OUT/p.name)
        elif p.name in ['baselines','sobol_final']:shutil.copytree(p,OUT/p.name,dirs_exist_ok=True)
    for year in range(2019,2023):
        for p in (RUN/'optimization'/str(year)).glob('*'):
            if p.is_file():copy(p,OUT/p.relative_to(RUN))
    # Binary designs and complete response columns retain every source value;
    # omit the redundant text rendering of the same large matrices.
    for pattern in ['sobol_global_N*/*/design.csv','sobol_global_N*/*/response_matrix.csv']:
        for p in OUT.glob(pattern):p.unlink()
    (OUT/'README.md').write_text('''# 完整计算结果的无损数值封装

原始逐次响应和全部种群数值均保留，没有截断小数、降低精度或删除样本。

Sobol：design.npy为全部八参数设计；all_response_columns.npz逐列保存原JSON响应（各灌水事件量展开为列），LOSSLESS_REPACK.json记录原事件日期/阶段与源文件哈希；response_matrix.npy为六主输出。N128和N512均保留，NESTED_REUSE.json说明完全相同前缀的精确复用。

优化：all_evaluations_columns.npz包含100代内全部新评估的水量账和输出；all_generations.npz包含Generation、X、F、G、CV，每个数组首维是代数。与逐代原件逐位核对通过；固定参数、变量映射、预算和约束见run.json。

读取逐次响应：from read_complete_results import load_columns; df=load_columns(path)。或运行 python read_complete_results.py archive.npz --csv responses.csv。部分浮点列用XOR无损编码压缩，解码后逐位恢复原始float64；这仅是文件存储，不参与科学模型计算，也不近似任何响应。字符串和布尔列保持相应类型。逐代all_generations.npz可直接用np.load读取。

所有COMPLETE均指计算完成；Sobol筛查稳定性另见scramble_checks.csv。MCMC原严格收敛限制没有因本轮计算而解除。
''',encoding='utf-8')
    print('Compact MB',sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())/2**20)


if __name__=='__main__':main()
