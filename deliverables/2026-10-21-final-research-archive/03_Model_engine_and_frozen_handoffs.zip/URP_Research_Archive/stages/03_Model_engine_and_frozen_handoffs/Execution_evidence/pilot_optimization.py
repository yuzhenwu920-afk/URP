from pathlib import Path
import sys
sys.path.insert(0,'/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
from model_adapter import *
import phaseC_nsga3 as C
s=load_study();m=RealModel(s)
C.run_year(m,s,2022,Path('/workspace/urp_true_runs_20261019/optimization_pilot'),generations=2,population=12,seeds=[31],compare=False)
