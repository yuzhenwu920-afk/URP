from pathlib import Path
import sys,json
sys.path.insert(0,'/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
from model_adapter import *
import phaseC_nsga3 as C
s=load_study();m=RealModel(s);rows=[]
root=HERE/'output_real_20261019/optimization'
for year in s['years']:
 selected=C.run_year(m,s,year,root/str(year),compare=False,collect_existing=True)
 point=read(root/str(year)/f'{year}_C1_real_replay.json')['output'];base=read(root/str(year)/f'baseline_{year}.json')['response']
 r=selected.iloc[0]
 row=dict(Year=year,Irrigation_mm=float(r.Irrigation_mm),Y13=float(r.Y13),Water_saving_pct=float(r.Water_saving_pct),ET_reduction_mm=base['ET_mm']-point['ET_mm'],Reduced_soil_storage_mm=base['Profile_final_mm']-point['Profile_final_mm'])
 rows.append(row);print(json.dumps(row),flush=True)
write('/workspace/urp_true_runs_20261019/PRIMARY_NSGA3_READY.json',{'primary_NSGA3_complete':True,'NSGA2_comparison_in_progress':True,'rows':rows})
