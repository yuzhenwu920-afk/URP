from pathlib import Path
import sys,importlib.util,json,time
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent
project=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
centers=pd.read_csv(project/'frozen_inputs/combined_central_parameter_vectors.csv',float_precision='round_trip').set_index('Year')
report={}
for year in (2019,2020,2021):
 folder=ROOT/'replacement_sources'/str(year)/f'DI_{year}_OneClick'
 path=folder/f'DI_{year}_MCMC_ONE_CLICK.py'
 spec=importlib.util.spec_from_file_location(f'annual_{year}',path);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
 for name in ['sampler','diagnostics','audit_hooks','ensemble_pipeline']: driver._embedded_module(name)
 runner=driver._embedded_module('runner')
 model,data,_,_=runner.load(str(year),ROOT/'baseline_reproduction'/str(year))
 point=centers.loc[year].to_dict()
 t=time.perf_counter();summary,g,cc,bio=model.simulate(data,point,'DI')
 report[str(year)]={'summary':summary,'seconds':time.perf_counter()-t}
 print(year,json.dumps(report[str(year)]),flush=True)
 target=ROOT/'baseline_reproduction'/str(year);target.mkdir(parents=True,exist_ok=True)
 g.to_csv(target/'central_daily_growth.csv',index=False);cc.to_csv(target/'cc_pairs.csv',index=False);bio.to_csv(target/'biomass_pairs.csv',index=False)
 (ROOT/'baseline_reproduction/report.json').write_text(json.dumps(report,indent=2))
