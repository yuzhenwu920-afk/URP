from pathlib import Path
import sys,json,traceback
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
PROJECT=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
sys.path.insert(0,str(PROJECT))
from model_adapter import load_study,RealModel,baseline,write,csv
import phaseB_sobol as B
import pandas as pd

def worker(seed):
    study=load_study();model=RealModel(study)
    out=ROOT/'results/sobol_global_N128'/f'2022_seed{seed}'
    result=B.run_track(model,study,2022,128,seed,'global',out)
    return seed,result.to_dict('records')

def main():
    folder=ROOT/'results/sobol_global_N128';folder.mkdir(parents=True,exist_ok=True)
    study=load_study();model=RealModel(study)
    baseline(model,study,2022,folder)
    write(folder/'batch_status.json',{'status':'RUNNING','years':[2022],
        'seeds':study['sobol']['seeds'],'N':128,'total_calls':3840,'workers':3,
        'engine':model.identity,'model':'original 2022 Modified DI AquaCrop; not surrogate'})
    frames=[]
    with ProcessPoolExecutor(max_workers=3) as ex:
        futures={ex.submit(worker,s):s for s in study['sobol']['seeds']}
        for f in as_completed(futures):
            seed,rows=f.result();frames.append(pd.DataFrame(rows))
            print('SEED COMPLETE',seed,flush=True)
    d=pd.concat(frames,ignore_index=True);csv(folder/'sobol_indices.csv',d)
    checks=B.rank_checks(d,study);csv(folder/'scramble_checks.csv',checks)
    csv(folder/'cross_year_key_flags.csv',B.cross_year_key_flags(d,study))
    status='SCREENING_STABLE' if checks.Stable_for_screening.all() else 'REVIEW_OR_EXPAND_N'
    write(folder/'sobol_summary.json',{'status':status,'engine':model.identity,
        'N':128,'years':[2022],'seeds':study['sobol']['seeds'],'track':'global',
        'calls_per_year_per_seed':1280,'real_calls':3840,'second_order':False,
        'ranking':'ST with S1 and 95% bootstrap intervals; input independent physical ranges'})
    from plot_results import plot_sobol
    plot_sobol(d,folder)
    write(folder/'batch_status.json',{'status':'COMPLETE','screening_status':status,'real_calls':3840,'years':[2022]})
    print('BATCH COMPLETE',status,flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:
        (ROOT/'results').mkdir(exist_ok=True)
        write(ROOT/'results/SOBOL_FAILURE.json',{'type':type(e).__name__,'error':str(e)})
        traceback.print_exc();raise
