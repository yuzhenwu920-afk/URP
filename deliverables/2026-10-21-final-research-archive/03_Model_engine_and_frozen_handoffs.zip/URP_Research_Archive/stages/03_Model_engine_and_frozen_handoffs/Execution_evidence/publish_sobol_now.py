from pathlib import Path
import sys,json
import pandas as pd
sys.path.insert(0,'/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
from model_adapter import *
import phaseB_sobol as B
import publish_actual_results as P
root=HERE/'output_real_20261019';study=load_study()
paths=sorted(root.glob('sobol_global_N512/*/indices.csv'))
assert len(paths)==12
x=pd.concat([pd.read_csv(p) for p in paths],ignore_index=True)
checks=B.rank_checks(x,study)
folder=root/'sobol_final';folder.mkdir(exist_ok=True)
csv(folder/'sobol_indices.csv',x);csv(folder/'scramble_checks.csv',checks);csv(folder/'cross_year_key_flags.csv',B.cross_year_key_flags(x,study))
P.sobol_figures(x,Path('/workspace/urp_true_runs_20261019/sobol_preview'),checks)
print(checks.to_string(index=False))
for output in ['Y_13pct','ET_mm']:
 print(output,x[x.Output==output].groupby(['Year','Parameter']).ST.mean().unstack(0).round(3).to_string())
write('/workspace/urp_true_runs_20261019/SOBOL_FIGURE_PREVIEW_REGISTRY.json',P.REGISTRY)
