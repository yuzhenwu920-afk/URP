from pathlib import Path
import json,hashlib,shutil

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/URP');PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED'
DEST=REPO/'deliverables/2026-10-19-actual-results'
data=json.loads((DEST/'SIX_PACKAGE_VERIFICATION.json').read_text())
assert data['status']=='PASS' and data['all_six_updated']
labels=['完整资料包（论文、代码、数据和图件）','完整运行结果包（全部响应和每代种群）','四年高清图件包（PNG、PDF及源表）','复核与论文更新包','模型复跑与执行包','Sobol与NSGA-III完整工程包']
base='https://github.com/yuzhenwu920-afk/URP/raw/refs/heads/delivery/urp-review-20261015/'
links=[]
for label,item in zip(labels,data['archives']):
    links.append(f"- [{label}]({base}{item['path']}) — {item['bytes']/1024**2:.1f} MiB")
intro='''2026-10-20交付：2019、2020、2021、2022四年真实Sobol与NSGA-III实验全部完成，原MCMC冻结。此前“尚未完成”的说明属于历史记录。

Sobol最终N=512、3个独立随机种子，61,440行模型响应；NSGA-III与同预算NSGA-II各100个体×100代×5种子×4年，共400,000次评估和4,000代完整种群。全量数据一致性、水量平衡及六包逐文件哈希检查通过。

六包均含相同的32组四年PNG/PDF图件：18组校准背景（流程与气象已更新）及14组新增真实敏感性/优化结果。新增图字号至少11pt、PNG320dpi，固定蓝/橙/绿/紫年份色。完整、复核、执行及工程包配有44页Word/PDF论文正文与图解、15张结果表、10个可编辑公式和Excel工作簿。
'''
caveat='''Sobol使用声明的公共独立均匀范围；2022产量的第三、四名近似并列，保留数值排序不确定性。优化调整原灌水日期上的四个窗口水量；主候选未设季末储水约束，不能将灌水减少全部解释为耗水减少。论文与SCIENCE_REVIEW详细解释这一问题，并给出追加储水门槛后的事后筛查结果。原MCMC诊断限制和缺少独立田间验证的限制均保留。
'''
downloads='\n'.join(links)
docs='''- [论文Word](URP_Sobol_NSGAIII_paper_with_actual_results.docx)
- [论文PDF](URP_Sobol_NSGAIII_paper_with_actual_results.pdf)
- [Excel结果工作簿](URP_Sobol_NSGAIII_results_tables.xlsx)
- [科学性复核与完善建议](SCIENCE_REVIEW.md)
- [六包完整性验证](SIX_PACKAGE_VERIFICATION.json)
- [四年图件覆盖、字号与哈希](FIGURE_COVERAGE_AND_STYLE.json)
'''
(DEST/'README.md').write_text('# 四年真实Sobol与灌溉优化最终交付\n\n'+intro+'\n## 六包下载\n\n'+downloads+'\n\n旧文件名中的日期保留以兼容原链接，内部均为本轮实际完成结果。GitHub不能预览大ZIP时点击下载箭头或View raw。\n\n## 单独文件\n\n'+docs+'\n## 结果边界\n\n'+caveat,encoding='utf-8')
(REPO/'README.md').write_text('# URP\n\n'+intro+'\n[六包下载、论文Word和Excel结果表](deliverables/2026-10-19-actual-results/) · [直接查看代码](DI_PHASE3_NEXTGEN_UPDATED/)\n\n'+caveat+'\n本次上传位于独立交付分支delivery/urp-review-20261015；main保持原提交。旧日期目录保留对应历史状态。\n',encoding='utf-8')
(REPO/'deliverables/README.md').write_text('# URP当前交付文件\n\n'+intro+'\n## 六包直下载\n\n'+downloads+'\n\n[单独下载Word、PDF、Excel及核验清单](2026-10-19-actual-results/)\n\n'+caveat+'\n文件名保留原日期以兼容旧链接；ZIP内部为本轮四年真实计算结果。历史文件请按原日期目录及提交记录识别。\n',encoding='utf-8')
(REPO/'deliverables/SHA256SUMS.txt').write_text(''.join(f"{x['sha256']}  {Path(x['path']).relative_to('deliverables').as_posix()}\n" for x in data['archives']))
canonical=ROOT/'staged_six/canonical_figures'
shutil.copytree(canonical,PROJECT/'four_year_figures',dirs_exist_ok=True)
shutil.copyfile(DEST/'FIGURE_COVERAGE_AND_STYLE.json',PROJECT/'FIGURE_COVERAGE_AND_STYLE.json')
shutil.copyfile(ROOT/'SCIENCE_REVIEW.md',PROJECT/'SCIENCE_REVIEW.md')
gallery=ROOT/'staged_six/URP_full_package/图表索引.html'
(PROJECT/'图表索引.html').write_text(gallery.read_text().replace('src="figures/','src="four_year_figures/').replace('href="figures/','href="four_year_figures/'),encoding='utf-8')
skip={'__pycache__','.cache','output_revised','output_real','output_real_20261019','actual_publication_20261019'}
entries=[]
for p in sorted(PROJECT.rglob('*')):
    if not p.is_file() or any(part in skip for part in p.relative_to(PROJECT).parts):continue
    if p in [PROJECT/'MANIFEST.json',PROJECT/'SHA256SUMS.txt']:continue
    entries.append(dict(file=p.relative_to(PROJECT).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(PROJECT/'MANIFEST.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
(PROJECT/'SHA256SUMS.txt').write_text(''.join(f"{e['sha256']}  {e['file']}\n" for e in entries))
print('Six current download indexes and canonical figures updated')
