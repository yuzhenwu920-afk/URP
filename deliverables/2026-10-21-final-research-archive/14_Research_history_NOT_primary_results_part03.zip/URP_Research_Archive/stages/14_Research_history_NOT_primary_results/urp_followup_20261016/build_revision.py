"""2026-10-16 follow-up: source audit and deterministic-framework revision."""
from pathlib import Path
import os,sys,json,hashlib,math,shutil,zipfile,inspect,re
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('XDG_CACHE_HOME',str(ROOT/'.cache'))
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import FancyBboxPatch
from PIL import Image
from docx import Document
from pypdf import PdfReader
OLD=Path('/workspace/urp_review/artifacts');DATA=Path('/workspace/urp_review/data')
NEW=ROOT/'alignment_package/URP_Paper_Alignment_Resolution_2026-10-15'
OUT=ROOT/'revision';T=OUT/'tables';F=OUT/'figures'
for q in [OUT,T,F]:q.mkdir(parents=True,exist_ok=True)
NAMES=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
YEARS=[2019,2020,2021,2022]
C=['#176B87','#C3842C','#805CA2','#909DA9'];DARK='#25384A';RED='#B34C47'
captions=[]
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def savecsv(n,d):
    d.to_csv(T/(n+'.csv'),index=False,encoding='utf-8-sig');return d
def mt(d):
    def fmt(v):
        if pd.isna(v):return '—'
        if isinstance(v,(float,np.floating)):return f'{v:.4f}'
        return str(v).replace('|','/').replace('\n',' ')
    return '| '+' | '.join(map(str,d.columns))+' |\n| '+' | '.join(['---']*len(d.columns))+' |\n'+'\n'.join('| '+' | '.join(fmt(v) for v in r)+' |' for r in d.itertuples(index=False,name=None))+'\n'
def audit():
    rows=[]
    for r in rd(NEW/'MANIFEST.json'):
        if 'file' in r:rows.append(dict(File=r['file'],Present=True,Hash_match=sha(NEW/r['file'])==r['sha256']))
        else:rows.append(dict(File='reference PDF: Windows path only',Present=False,Hash_match=None))
    savecsv('manifest_check',pd.DataFrame(rows))
    assert all(r['Hash_match'] for r in rows if r['Present'])
    center=pd.read_csv(NEW/'tables/combined_central_parameter_vectors.csv')
    original=pd.read_csv(OLD/'tables/parameter_intervals_verified.csv')
    comp=center.melt(id_vars='Year',value_vars=NAMES,var_name='Parameter',value_name='Submitted_mean').merge(original[['Year','Parameter','Mean']],on=['Year','Parameter'],how='left')
    comp['Absolute_difference']=abs(comp.Submitted_mean-comp.Mean)
    comp['Evidence']=np.where(comp.Mean.notna(),'original checkpoint verified','new report only; raw checkpoint absent')
    savecsv('central_vector_comparison',comp)
    assert comp.Mean.notna().sum()==29 and comp.Absolute_difference.max()<1e-9
    center['Evidence']=np.where(center.Year==2022,'phase1 verified; phase2 reported only','both phases verified')
    savecsv('central_vectors_with_provenance',center)
    supplied=pd.read_csv(NEW/'tables/paper_aligned_sampling_adequacy.csv')
    diag=pd.read_csv(OLD/'tables/mcmc_diagnostics_recomputed.csv')
    groups=[];detail=[]
    for (y,p),g in supplied.groupby(['Year','Phase']):
        old=diag[(diag.Year==y)&(diag.Phase==p)]
        verified=len(old)==len(g)
        tau=float(g.Tau_max.max());burn=math.ceil(5*tau);steps=2000-burn;ens=4 if p==1 else 1;draws=steps*32*ens
        if verified:assert old.Burn_in.iloc[0]==burn and old.Retained_correlated_draws.iloc[0]==draws
        groups.append(dict(Year=int(y),Phase=int(p),Ensembles=ens,Walkers=32,Raw_steps=2000,Group_max_tau=tau,Integer_group_burn=burn,Retained_steps_per_walker=steps,Retained_correlated_draws=draws,Steps_over_group_tau=2000/tau,Tau_50_length_reference=bool(2000>=50*tau),Raw_checkpoint_available=verified))
        for r in g.itertuples():
            match=old[old.Parameter==r.Parameter]
            detail.append(dict(Year=int(y),Phase=int(p),Parameter=r.Parameter,Submitted_burn=r.Burn_5tau,Submitted_retained_steps=r.Post_burn_steps_by_5tau,Correct_integer_group_burn=burn,Correct_retained_steps=steps,Correct_correlated_draws=draws,Tau_difference_vs_original=r.Tau_max-match.Tau_max.iloc[0] if len(match) else np.nan,Raw_checkpoint_available=verified,Draws_over_tau_is_rank_ESS=False))
    savecsv('sampling_group_summary',pd.DataFrame(groups));savecsv('sampling_table_corrected',pd.DataFrame(detail))
    evidence=pd.read_csv(NEW/'tables/CC_evidence_scope.csv');checks=[]
    for r in evidence.itertuples():
        root=DATA/f'②原始资料包_{r.Year}'
        if r.Dataset.startswith('Field'):
            p=next(root.rglob('DI_2019_2022_FIELD_LAI_CC_LOCKED.csv'));d=pd.read_csv(p);d=d[d.Year==r.Year]
            err=np.max(abs(1.005*(1-np.exp(-.6*d.LAI))**1.2-d.Field_CC))
        else:p=next(root.rglob(f'Maize-{r.Year}_RS_NDVI.csv'));d=pd.read_csv(p);err=np.nan
        checks.append(dict(Year=r.Year,Dataset=r.Dataset,Rows=len(d),Submitted_rows=r.Rows,Rows_match=len(d)==r.Rows,Hash_match=sha(p)==r.SHA256,LAI_CC_max_error=err,Role='calibration' if r.Used_in_likelihood else 'auxiliary, not DI external validation'))
    assert all(r['Rows_match'] and r['Hash_match'] for r in checks)
    savecsv('CC_evidence_rechecked',pd.DataFrame(checks))
    changes=[
      ('S01','采样与Rhat','研究范围可调整，诊断未消失','操作性完成不等于严格收敛；保留补充诊断'),
      ('S02','八维联合后验','确定性设计修正合理','独立范围Sobol和固定中心点优化不需要伪联合后验'),
      ('S03','2022真实阶段二','报告称已补，原始链未交付','3个均值仅新表可读；需原NPZ交叉核验'),
      ('S04','CC证据','文件来源核对通过','可支持校准拟合；RS仍不是DI外部验证'),
      ('S05','真实模型','报告称恢复，执行仍阻塞','新包没有源码或适配器；不能实际运行'),
      ('S06','水生产率','文档公式正确，实现待核','100Y/I正确；未收到新真实适配器代码'),
      ('S07','旧节水率','撤回合理','不恢复旧38%；2.28%等新文字数值仍缺运行响应'),
      ('S08','灌溉日程','假设标签已改，实测仍缺','应称模型基准日程；不称全部实测'),
      ('S09','独立验证','措辞清理，外部验证未完成','允许校准研究，不宣称外部性能已验证'),
      ('S10','真实Sobol/NSGAIII','尚未运行','仅有实施方案，无新设计/响应矩阵或真实优化历史')]
    savecsv('issue_reassessment',pd.DataFrame(changes,columns=['ID','Topic','Status','Action']))
    fit=pd.read_csv(OLD/'tables/paper_calibration_table.csv');fit['证据']='配对输出可复算'
    row={c:np.nan for c in fit.columns};row.update({'年份':2022,'CC样本数':12,'CC_R2':.931,'CC_RMSE':.060,'生物量_R2':.997,'生物量_RMSE':.556,'观测产量':14.08,'模拟产量':14.08,'产量误差_pct':-.02,'证据':'新文档汇总，缺配对输出'})
    fit=pd.concat([fit,pd.DataFrame([row])],ignore_index=True);savecsv('calibration_evidence_tiers',fit)
    savecsv('formal_run_budget',pd.DataFrame([dict(Task='Sobol N128',Years=4,Seeds=3,Calls_per_run=1280,Total_calls=15360),dict(Task='Sobol N512 alternative',Years=4,Seeds=3,Calls_per_run=5120,Total_calls=61440),dict(Task='NSGAIII 100x100',Years=4,Seeds=5,Calls_per_run=10000,Total_calls=200000)]))
    state=dict(date='2026-10-16',central_values_verified=29,central_values_report_only=3,verified_phase1_ensembles=16,verified_phase2_ensembles=3,raw_2022_phase2_present=False,new_package_contains_modified_DI_model=False,reference_PDF_present=False,new_real_Sobol_executed=False,new_real_NSGAIII_executed=False,study_design='deterministic main; conditional perturbations separately')
    (OUT/'RUN_READINESS.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
    return center,comp,pd.DataFrame(groups),diag,fit
def savefig(fig,n,title,note):
    fig.suptitle(title,fontsize=15,fontweight='bold',color=DARK,y=1.025)
    fig.text(.01,-.02,note,fontsize=8.2,color='#526474',va='top')
    for ext in ['png','pdf']:fig.savefig(F/(n+'.'+ext),dpi=300,bbox_inches='tight',pad_inches=.18)
    plt.close(fig);captions.append(dict(file=n+'.png',title=title,caption=note))
def draw(center,comp,g,diag,fit):
    font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';fm.fontManager.addfont(font)
    plt.rcParams.update({'font.family':[fm.FontProperties(fname=font).get_name(),'DejaVu Sans'],'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'axes.titlesize':11,'grid.color':'#E4E9EE','legend.frameon':False,'pdf.fonttype':42})
    fig,ax=plt.subplots(2,4,figsize=(14,7),layout='constrained')
    for i,k in enumerate(NAMES):
        a=ax.flat[i];a.plot(range(4),center[k],color='#A8B4BF',ls='--',lw=1.3)
        for j,y in enumerate(YEARS):a.scatter(j,float(center.loc[center.Year==y,k].iloc[0]),s=55,facecolor='white' if j==3 and i>=5 else C[j],edgecolor=C[j],lw=1.5,zorder=4)
        if i>=5:a.text(.98,.04,'空心：新报告值，缺原链',transform=a.transAxes,ha='right',fontsize=7.5,color=RED)
        a.set(xticks=range(4),xticklabels=YEARS,title=k);a.grid(axis='y')
    savefig(fig,'U01_central_parameters','年度中心参数：确定性下游输入，不是联合后验样本','29个值与原检查点均值一致。2022阶段二3个空心点仅来自新增报告；连线只是年度比较，不作趋势推断。')
    fig,ax=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
    for p,dx,col in [(1,-.17,C[0]),(2,.17,C[2])]:
        s=g[g.Phase==p].sort_values('Year');bars=ax[0].bar(np.arange(4)+dx,s.Retained_steps_per_walker,.3,color=col,label=f'阶段{p}')
        ax[1].plot(range(4),s.Steps_over_group_tau,'o-',color=col,label=f'阶段{p}')
        for j,(b,r) in enumerate(zip(bars,s.itertuples())):
            ax[0].text(b.get_x()+b.get_width()/2,b.get_height()+10,str(r.Retained_steps_per_walker),ha='center',fontsize=8)
            if not r.Raw_checkpoint_available:b.set_facecolor('#E6E9ED');b.set_edgecolor(col);b.set_hatch('///');ax[1].scatter(j,r.Steps_over_group_tau,s=90,facecolor='white',edgecolor=col,zorder=5)
    ax[0].set(ylabel='每walker保留步数',ylim=(0,2050),title='统一截断：ceil(5 × 整组最大τ)')
    ax[1].axhline(50,color=RED,ls='--',lw=1,label='50τ：常用τ估计长度参考');ax[1].set(ylabel='原始步数 / 整组最大τ',ylim=(0,75),title='操作记录与估计可靠性分开')
    for a in ax:a.set(xticks=range(4),xticklabels=YEARS);a.grid(axis='y');a.legend(fontsize=8)
    savefig(fig,'U02_sampling_record','采样记录：操作性完成不等于收敛认证','阶段一各4独立ensemble，阶段二各1个。斜线/空心是2022阶段二报告值，未经原始链核验。5τ是截断规则；相关draw数不等于独立ESS。')
    z=diag[diag.Phase==1].pivot(index='Parameter',columns='Year',values='Rhat_max').reindex(NAMES[:5])
    fig,a=plt.subplots(figsize=(8,4.5),layout='constrained');im=a.imshow(z,cmap='YlOrRd',vmin=1,vmax=1.2,aspect='auto')
    for i in range(5):
        for j in range(4):
            rgba=im.cmap(im.norm(z.iloc[i,j]));lum=.2126*rgba[0]+.7152*rgba[1]+.0722*rgba[2]
            a.text(j,i,f'{z.iloc[i,j]:.3f}',ha='center',va='center',color='white' if lum<.5 else DARK)
    a.set(xticks=range(4),xticklabels=YEARS,yticks=range(5),yticklabels=NAMES[:5]);fig.colorbar(im,ax=a,label='最大秩标准化Rhat')
    savefig(fig,'SF01_rhat_disclosure','补充诊断：第一阶段跨独立ensemble的Rhat','匹配walker索引跨4个独立ensemble分别计算，报告最大值。限定为中心点确定性研究不等于已证明严格后验收敛。')
    field=pd.read_csv(next((DATA/'②原始资料包_2019').rglob('DI_2019_2022_FIELD_LAI_CC_LOCKED.csv')));field.Date=pd.to_datetime(field.Date)
    fig,ax=plt.subplots(2,2,figsize=(12,7),layout='constrained')
    for a,y,col in zip(ax.flat,YEARS,C):
        root=DATA/f'②原始资料包_{y}';start,end=pd.to_datetime(rd(next(root.rglob('preflight.json')))['Dates'])
        x=field[field.Year==y];r=pd.read_csv(next(root.rglob(f'Maize-{y}_RS_NDVI.csv')));r.date=pd.to_datetime(r.date);r=r[r.date.between(start,end)]
        a.plot((x.Date-start).dt.days,x.Field_CC,'o-',color=col,lw=1.7,ms=5,label='DI：LAI转换CC（校准）')
        a.plot((r.date-start).dt.days,r.CCquad/100,'s--',color='#8F9DA9',lw=1,ms=4,label='RS CCquad（时序辅助）')
        a.set(title=f'{y}：'+('RS标签BI' if y<2022 else 'RS处理标签缺失'),xlabel='距模拟起始日 / d',ylabel='CC（0—1）',ylim=(0,1.08));a.grid(axis='y')
    ax[0,0].legend(fontsize=8)
    savefig(fig,'U03_CC_evidence','CC数据流：校准资料与辅助时序对照','RS CCquad从百分数换为0—1。处理不同/未知，只并列展示，不计算DI外部验证R²；来源均为已提供资料，不是本次新增田间观测。')
    fig,ax=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
    for i,y in enumerate(YEARS):
        r=fit[fit['年份']==y].iloc[0];pending=y==2022
        for key,mark in [('CC_R2','o'),('生物量_R2','s')]:ax[0].scatter(i,r[key],s=60,marker=mark,facecolor='white' if pending else C[i],edgecolor=C[i])
        bars=ax[1].bar(i,r['产量误差_pct'],.55,color=C[i])
        if pending:bars[0].set_facecolor('#E6E9ED');bars[0].set_edgecolor(C[i]);bars[0].set_hatch('///')
    ax[0].set(ylabel='R²',ylim=(.9,1.01),title='圆点：CC；方点：生物量')
    for v in [-5,5]:ax[1].axhline(v,color=RED,ls='--',lw=1)
    ax[1].axhline(0,color=DARK,lw=.7);ax[1].set(ylabel='产量相对误差 / %',ylim=(-6,6),title='校准误差，不是优化减产率')
    for a in ax:a.set(xticks=range(4),xticklabels=YEARS);a.grid(axis='y')
    savefig(fig,'U04_calibration_scope','校准表现：按原始证据可复核程度分层','2019—2021配对结果沿用独立复算；2022空心/斜线为文档汇总值，缺阶段二配对输出。±5%是项目约定，不是统计置信区间。')
    fig,a=plt.subplots(figsize=(12,5.8),layout='constrained');a.axis('off');a.set_xlim(0,12);a.set_ylim(0,6)
    boxes=[(.2,4.3,3.4,1.2,'1 冻结真实模型与输入','原Modified DI + 已核验中心点\n基准回算、哈希、实测吞吐量',DARK),(4.2,4.3,3.5,1.2,'2 独立范围Sobol','8参数，N=128/512，3种子\nS1/ST、区间和输出方差',C[0]),(8.3,4.3,3.4,1.2,'3 确定性NSGA-III','固定中心参数，产量/水量双目标\nSMT或阶段水量二选一',C[2]),(.2,1.9,5.3,1.6,'4 候选与物理约束','I≤年度基准；Y≥0.95×观测产量\n灌期、单次水量和水量守恒\nε约束选方案，列邻近备选','#3C8C78'),(6.2,1.9,5.5,1.6,'5 条件扰动单列','分别扰动参数组，保留组内相关\n低分位、达标率、MC误差\n年度专用与跨年推广分开','#3C8C78')]
    for x,y,w,h,t,b,col in boxes:
        a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.08',facecolor=col+'10',edgecolor=col,lw=1.1))
        a.text(x+.15,y+h-.22,t,color=col,weight='bold',fontsize=12,va='top');a.text(x+.15,y+h-.64,b,color=DARK,fontsize=9.5,va='top',linespacing=1.7)
    for x in [3.65,7.78]:a.annotate('',xy=(x+.45,4.9),xytext=(x,4.9),arrowprops=dict(arrowstyle='->',color=DARK,lw=1.5))
    a.text(.2,.7,'状态：框架与中心参数已整理；真实模型和2022原始链待补。此图不是正式运行结果。',color=RED,fontsize=11)
    savefig(fig,'U05_revised_workflow','修订主线：确定性决策，条件扰动单列','不需要伪八维联合后验。独立范围Sobol是响应实验，不是后验归因；正式真实模型的敏感性和优化结果尚未生成。')
    for ext in ['png','pdf']:shutil.copyfile(OLD/'figures'/('F02_calibration_trajectories.'+ext),F/('U06_verified_calibration.'+ext))
    captions.append(dict(file='U06_verified_calibration.png',title='2019—2021校准过程（沿用已核验图）',caption='据已有逐日输出和校准配对表；未重跑原模型，无新增外部验证。'))
    (OUT/'figure_captions.json').write_text(json.dumps(captions,ensure_ascii=False,indent=2))
def fig(n):
    r=next(r for r in captions if r['file'].startswith(n+'_'))
    return f"\n![{r['title']}](figures/{r['file']})\n\n图注：{r['caption']}\n"
def docs(center,comp,g,diag,fit):
    small=g[['Year','Phase','Integer_group_burn','Retained_steps_per_walker','Retained_correlated_draws','Raw_checkpoint_available']].copy()
    small.columns=['年份','阶段','整组burn-in','每walker保留步数','相关draw数','原链可核验']
    issues=pd.read_csv(T/'issue_reassessment.csv')
    report=f'''# URP新增材料复核与变更说明
版本：2026-10-16。对照材料：两份新增Word、论文口径调整ZIP与上一轮真实检查点复算。

## 核心判断
“独立范围Sobol + 固定中心点的确定性双目标优化”是合理的研究设计。该主线不要求先获得八参数联合后验，可以继续实施，不必仅为拼出联合后验而重做MCMC。
同时，操作性完成、后验诊断和证据可读取性应区分。32 walkers、2000步、5tau截断是运行选择，不能单独证明链混合充分。把Rhat放到补充材料不会改变诊断数值。参考论文采用相同方法也不能替代本项目证据；该参考PDF尚未上传。

## 1 本轮实际核验
新增ZIP内9个文件的哈希与MANIFEST一致；参考论文条目只有Windows路径和哈希。32个中心参数中29个与原检查点均值一致，最大差约{comp.Absolute_difference.max():.3g}。2022阶段二3个值13.860064、31.497714、0.401319目前只由新表报告，原NPZ未交付。
本轮没有运行新的真实模型Sobol或NSGA-III。当前交付是数值对照、采样记录修正、CC角色核查、7张图与论文框架更新。

## 2 对10项“已解决”的重新判定
{mt(issues)}
新报告可能描述了另一台机器上已经完成的工作，但当前ZIP没有.py、模型适配器或2022阶段二NPZ，因此不能在本云环境把它们记为执行层已解决。新报告中的2020真实复算、2021保守2.28%节水也没有原始响应表，本轮不将其作为已核验新结果。

## 3 采样表的算术与解释修正
原表逐参数填写5tau、2000−5tau，产生小数步数。实际链采用整组最大tau统一截断，并向上取整。2019阶段一应统一burn=395、每walker保留1605步，4×32×1605=205440个相关draw；不是不同参数各保留不同的小数步数。
{mt(small)}
2022阶段二一行仅为按新报告tau推算的记录，尚未核验原链。相关draw数/tau不能当作秩标准化bulk/tail ESS，尤其不能仅据大量耦合walker样本声称收敛。
如果论文目标是中心点确定性模拟，可以记为“按预设预算完成分组条件采样”，并披露未充分混合、tau和边界影响；不把停止追加采样写成严格收敛证明。
{fig('U02')}
{fig('SF01')}

## 4 CC与校准的证据范围
8条年度/数据集记录的行数和哈希与原文件相符，LAI转CC公式可复算。Field LAI-derived CC支持校准拟合；RS资料2019—2021标记BI，2022缺处理标签，只适合时序辅助，不支持DI外部独立验证。
同数据校准与评价可以在范围清楚的研究中报告，但只反映样本内重现，不证明外推性能。独立验证是否在本研究范围内可以限定，不能把没有独立验证改写成已经验证。
{fig('U03')}

## 5 本次论文修订
主分析改为确定性：Sobol采用预声明的独立均匀物理范围，优化固定年度中心参数，并采用产量/灌水量双目标。阶段一、阶段二的条件扰动单列，保留组内相关结构，不能伪装成完整联合后验。
SMT1—SMT4与阶段水量应二选一。SMT百分比要从实际模块核对含义和触发方向。保留I≤年度基准和Y≥0.95×观测产量，报告相对同模型基准变化，并用100Y/I计算kg/m³水生产率。ε约束选择方案不自动叫几何膝点。
旧代理最终排名、2021旧38%节水不进入新主文。已有代理探索仍保留在上一轮历史包，未删除或冒充真实模型成果。

## 6 真实执行前的缺件与预算
需要：原Modified DI年度源码/适配器及输入；2022阶段二真实2000×32×3检查点与诊断/配对输出；MANIFEST所指参考论文PDF。真实灌溉输入日程与逐日纠偏ETo亦应可追溯。
先实际测基准和扰动点耗时，再定并行与预算。四年N128、三scramble、不算二阶需15360次调用；约100种群×100代×5种子×4年需200000次候选评估，尚不含候选扰动复核。不能没有真实吞吐量就承诺运行时长。
本版本RUN_READINESS.json明确记录：真实模型代码和2022原链本轮未交付；新真实Sobol/NSGA-III未执行。不能用改措辞或改图替代这些运行证据。
'''
    paper=f'''# 滴灌玉米改进AquaCrop的分阶段校准、独立范围敏感性与确定性灌溉优化
## 论文框架修订稿（2026-10-16）
定位：已核验的校准资料与确定性方法框架。正式真实模型Sobol和优化结果尚未生成。条件扰动是补充核验，不声称拥有八维联合后验。

## 摘要草稿
本研究整理2019—2022年滴灌玉米气象、冠层、作物及初始土壤水资料，构建分阶段条件校准与确定性灌溉决策框架。2019—2021已有配对输出可重现较好校准拟合；新增中心参数表中29个值与原始链均值吻合，2022阶段二仍待原始检查点交叉核验。后续拟在真实Modified DI模型中，以独立均匀物理范围开展Sobol响应分析，以年度中心参数驱动双目标NSGA-III，加入灌水、产量及过程物理约束，并单列条件参数扰动。当前证据支持样本内校准重现与内部数值一致性；正式敏感性排序、节水幅度和推广结论须在真实模型新运行后报告。
关键词：滴灌玉米；改进AquaCrop；条件校准；Sobol；确定性优化。

## 1 引言与研究问题
问题主线是如何从可解释的过程校准走向受约束、可执行的管理决策。MCMC、Sobol、NSGA-III是工具组合，本身不构成已证实的创新。
RQ1：分阶段校准后，模型在已有资料上能重现哪些过程？RQ2：指定独立参数范围内，哪些参数贡献输出方差？RQ3：固定年度中心点时，满足产量与水量约束的制度是什么？补充问题：候选在透明的组内条件扰动下是否稳定？
研究区、原始试验和文献来源应补自原始资料，不自行填入坐标、重复次数或试验设计。
{fig('U05')}

## 2 数据及其证据角色
| 数据 | 使用角色 | 限定 |
| --- | --- | --- |
| Field LAI-derived CC | 校准 | 原论文读图LAI再换算，非本次新增实测 |
| RS CCquad | 辅助时序 | BI或处理未知，不是DI外部验证 |
| 生物量、年产量 | 阶段二校准 | 保留读图误差、sigma假设与含水率 |
| Tr、Es | 过程约束 | Es近似；ET不重复作独立似然 |
| 初始土壤水 | 模型输入 | 分层读图/再分析来源需明示 |
| 灌溉日程 | 模型基准 | 不能称全部来自真实分次实测 |
{fig('U03')}

## 3 模型与分阶段条件校准
### 3.1 冻结真实Modified DI实现
区分标准AquaCrop与actual CC蒸发输入、真实MulchPct、两阶段WP和年度HI0的改进实现。正式适配器需返回Y13、B、Tr、Es、ET、灌溉量及逐日/季节水量残差；缺源码时不能声称已调用成功。
建议以标准模型、只改蒸发、只改两阶段WP、两处均改为结构消融对照，使用同一数据划分和预算；此比较尚未执行。样本内R²升高不能单独证明结构优越。
### 3.2 参数组与年度中心点
阶段一θ1=(CCx,CGC_CD,CDC_CD,SenescenceCD,Kcb)，阶段二θ2=(WP_early,WP_late,HI0)条件于阶段一代表点。两组均值拼成中心点是确定性输入，不是八维联合后验抽样。
表1 年度中心点。2022阶段二三个值仍为新报告值；原链待核。
{mt(center[['Year']+NAMES])}
{fig('U01')}
### 3.3 操作记录与诊断
每组32 walkers、2000步；第一阶段4个独立ensemble，第二阶段1个。统一burn=ceil(5×整组最大tau)，所有参数共用整数截断。保留draw数仍含相关性。
{mt(small)}
可以将研究限定为中心点确定性分析，无须宣称联合后验；仍应保留Rhat、ESS、tau估计及参数边界说明。5tau只是截断规则，不是独立的收敛证明。参考PDF尚未上传，当前不宣称已逐条核对其原文。
{fig('U02')}
### 3.4 校准评价
R²=1−SSE/SST；RMSE为均方误差平方根，Bias=mean(模拟−观测)。一年一对产量只报偏差。以同一批资料评价称校准拟合；不冒充外部验证。

## 4 独立范围Sobol的正式实施方案
主分析用8参数独立均匀物理范围，回答预声明空间的响应方差贡献，不是相关后验归因；全均匀试验也不等于原贝叶斯先验密度。物理范围需有文献或农艺来源，局部95%边际范围仅叫后验邻域响应实验。
先N128×3个scramble，必要时升512。不算二阶时调用数N(D+2)=10N；算二阶为18N。四年N128三种子共15360次真实调用，先计时再定预算。
保存输入空间、设计矩阵、逐次响应、S1/ST和bootstrap区间、输出均值方差与单位、失败点和种子。按年度比较排序，不用跨年均值代替年度结果，也不靠裁剪指数或强制排序美化结果。
**结果占位：真实模型尚未执行，暂不填写敏感性指数和正式排名，不沿用旧代理图代替。**

## 5 确定性双目标NSGA-III的正式实施方案
### 5.1 管理变量
方案A为SMT1—SMT4，必须核对真实模块中百分比的定义、方向、根区和触发条件。方案B为四至五阶段水量、日期限定允许窗口。两者二选一；固定日期水量优化不写成日期优化。
### 5.2 目标与约束
固定年度中心参数，min(−Y13,I)。约束I≤年度DI模型基准；Y13≥0.95×文献观测产量；水量、灌期、非负量与守恒合格。同步报告相对同模型基准变化，防止混用观测、初始模拟与中心点模拟。
IWP=100×Y[t/ha]/I[mm]，单位kg/m³；产量统一13%含水率。零灌溉仅反事实，未经实测不得称验证情景。
### 5.3 预算、对照和选解
至少5种子、约100参考方向/种群、100代；双目标100个Das-Dennis方向可由99分割获得，不能照抄三目标配置。记录每代种群、目标和约束；加NSGA-II或参考方向敏感性对照。同年度同尺度使用固定HV参考点。
用ε约束选达产量阈值内最小水量，并列相邻备选；不自动称几何膝点。NSGA-III是算法名，不是只运行三代。约100×100×5×4=200000次候选调用，需先测实际耗时。
**结果占位：真实前沿、最终节水率、推荐日程未生成。旧2021约38%已撤回；新文档2.28%等亦缺原始运行响应，本轮不纳入已核验结论。**

## 6 条件扰动与适用范围
候选需真实模型回代。至少128组扰动是起始预算，仍要评估低分位和达标率的MC误差；样本数本身不保证可靠性。
分别扰动阶段一/固定阶段二中心，以及扰动阶段二整行样本/固定阶段一中心，保留组内相关。此为局部条件实验，不是完整联合传播。报告产量低分位、达标率、水量和守恒；这些概率只对应声明的条件分布，不是田间失收概率。
年度专用制度可逐年描述；推广到未知年份才需要留一年或嵌套跨年验证，不能用同四年既选制度又宣称外部验证。

## 7 现阶段可写的结果
### 7.1 校准表现
2019—2021配对输出可复算；2022只列新文档汇总值，尚未得到本轮配对输出核验。校准误差和优化减产率是不同量。
{mt(fit)}
{fig('U04')}
{fig('U06')}
### 7.2 中心参数一致性
29个中心值与原始保留均值一致。2022阶段二与实际源码仍缺原始可读文件。没有新证据证明所有参数严格多链收敛，应披露中心点近似的限制。
### 7.3 正式敏感性与管理结果
真实运行后再填：年度S1/ST/区间/输出方差，不同种子前沿与HV，基准和候选的产量/水量/IWP/储水变化，物理残差与ε约束方案、相邻备选、条件扰动。当前留空，不以旧代理数值顶替。

## 8 讨论与结论
讨论应区分：校准拟合与识别性，独立范围响应与后验归因，确定性方案与高可靠性，以及年度专用与未知年推广。数据读图、灌溉日程、纠偏ETo和模型结构限制都应明示。
现阶段结论可写：“已形成分阶段条件校准的年度中心参数和可复现记录；独立范围Sobol及受约束确定性优化在逻辑上不依赖伪联合后验，正式数值仍待真实模型执行。”不提前写最终敏感参数、平均节水与推广结论。

## 补充诊断与方法参考
{fig('SF01')}
可核对FAO Irrigation and Drainage Paper 66；Goodman & Weare (2010), DOI 10.2140/camcos.2010.5.65；Vehtari et al. (2021), DOI 10.1214/20-BA1221；Saltelli et al. (2010), DOI 10.1016/j.cpc.2009.09.018；Deb & Jain (2014), DOI 10.1109/TEVC.2013.2281535。
本次具体参照论文仅有Windows路径和哈希，没有PDF原文，正式引用与设置仍待核。
'''
    for n,s in [('URP_20261016_复核与变更说明',report),('URP_20261016_论文框架_确定性主线',paper)]:(OUT/(n+'.md')).write_text(s)
    return report,paper
def export(report,paper):
    sys.path.insert(0,'/workspace/urp_review/src')
    import make_documents as renderer
    renderer.OUT=OUT;renderer.TABLES=T
    # Reuse our own tested renderer, changing only this revision's footer date.
    src=inspect.getsource(renderer.pdf_report).replace('2026-10-15','2026-10-16')
    exec(src,renderer.__dict__)
    for n,s in [('URP_20261016_复核与变更说明',report),('URP_20261016_论文框架_确定性主线',paper)]:
        renderer.pdf_report(s,OUT/(n+'.pdf'));renderer.word_report(n+'.md')
    renderer.workbook()
    workbook=OUT/'URP_20261016_复核结果表.xlsx'
    if workbook.exists():workbook.unlink()
    (OUT/'URP_审查与结果表.xlsx').rename(workbook)
    dest=OUT/'submitted';dest.mkdir(exist_ok=True)
    inputs=[Path('/workspace/attachments/0734e8d4-f3f0-4dfc-bf2f-333f135b623c/四年DI玉米MCMC确定性成果汇编.docx'),Path('/workspace/attachments/653b2f00-d4a7-41c7-8604-96c4896a9d7d/后续Sobol与NSGAIII实施方法.docx'),Path('/workspace/attachments/84bb4458-81d4-48dd-addc-a6cc4139ccbf/URP_Paper_Alignment_Resolution_2026-10-15.zip')]
    for p in inputs:shutil.copyfile(p,dest/p.name)
    shutil.copyfile(Path(__file__),OUT/'build_revision.py')
    (OUT/'README.md').write_text('''# 2026-10-16新增材料复核与论文修订
先读URP_20261016_复核与变更说明.pdf，再使用URP_20261016_论文框架_确定性主线.docx。
本轮主线为确定性研究，不要求伪联合后验。29个中心值已核验，2022阶段二3个值仍是报告值。采样表按整组最大tau向上取整修正。7张图含6张新绘、1张沿用的已核验校准图。
本轮没有执行真实模型Sobol/NSGA-III。新增文件没有交付文字所述恢复的模型源码、2022原始阶段二链，参考PDF亦只有PC路径与哈希。请以RUN_READINESS.json和证据标签为准。
submitted/为本次原件，tables/为来源与数值核查，figures/同时有300dpi PNG和矢量PDF。build_revision.py为新增脚本，在本云环境用/workspace/urp_review/.venv/bin/python运行；依赖原/workspace/urp_review/data和artifacts，不独立包含旧原始数据。
旧交付包和17.7MB真实检查点重建样本保留，不覆盖。MANIFEST.json为本版本逐文件校验清单。
''')
def verify():
    checks={}
    c=pd.read_csv(T/'central_vector_comparison.csv');checks['29_verified_3_report_only']=int(c.Mean.notna().sum())==29 and int(c.Mean.isna().sum())==3
    g=pd.read_csv(T/'sampling_group_summary.csv');checks['integer_truncation']=bool((g.Integer_group_burn%1==0).all() and (g.Retained_correlated_draws==g.Retained_steps_per_walker*g.Walkers*g.Ensembles).all())
    checks['7_verified_groups_1_pending']=int(g.Raw_checkpoint_available.sum())==7
    cc=pd.read_csv(T/'CC_evidence_rechecked.csv');checks['8_CC_source_records']=bool(cc.Rows_match.all() and cc.Hash_match.all())
    checks['7_PNG_7_PDF']=len(list(F.glob('*.png')))==7 and len(list(F.glob('*.pdf')))==7
    for p in F.glob('*.png'):
        with Image.open(p) as im:im.verify()
    pdf=PdfReader(OUT/'URP_20261016_论文框架_确定性主线.pdf');doc=Document(OUT/'URP_20261016_论文框架_确定性主线.docx')
    checks['PDF_7_images']=sum(len(p.images) for p in pdf.pages)==7
    checks['Word_7_images']=len(doc.inline_shapes)==7
    state=rd(OUT/'RUN_READINESS.json');checks['no_fabricated_formal_runs']=not state['new_real_Sobol_executed'] and not state['new_real_NSGAIII_executed']
    assert all(checks.values()),checks
    (OUT/'VALIDATION.json').write_text(json.dumps(dict(status='PASS',checks=checks,paper_pages=len(pdf.pages)),ensure_ascii=False,indent=2))
    manifest=[dict(file=str(p.relative_to(OUT)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='MANIFEST.json']
    (OUT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    archive=ROOT/'URP_update_20261016.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():z.write(p,arcname='URP_update_20261016/'+str(p.relative_to(OUT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for r in manifest:assert hashlib.sha256(z.read('URP_update_20261016/'+r['file'])).hexdigest()==r['sha256']
    print(json.dumps(dict(status='PASS',zip=str(archive),bytes=archive.stat().st_size,paper_pages=len(pdf.pages),figures=len(captions),checks=checks),ensure_ascii=False))
if __name__=='__main__':
    args=audit();print('Evidence audit complete',flush=True)
    draw(*args);print('7 figures complete',flush=True)
    report,paper=docs(*args);export(report,paper);print('Documents exported',flush=True)
    verify()

