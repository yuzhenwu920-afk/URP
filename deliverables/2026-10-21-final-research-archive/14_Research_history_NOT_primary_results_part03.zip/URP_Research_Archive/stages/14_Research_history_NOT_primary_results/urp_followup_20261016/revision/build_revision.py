"""Rebuild current 2026-10-17 Word/PDF from included Markdown and figures."""
from pathlib import Path
import document_renderer as renderer
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    for name in ['URP_20261016_复核与变更说明','URP_20261016_论文框架_确定性主线']:
        renderer.pdf_report((ROOT/(name+'.md')).read_text(encoding='utf-8'),ROOT/(name+'.pdf'))
        renderer.word_report(name+'.md')
    print('Rebuilt current documents; historical generator remains in history/.')
