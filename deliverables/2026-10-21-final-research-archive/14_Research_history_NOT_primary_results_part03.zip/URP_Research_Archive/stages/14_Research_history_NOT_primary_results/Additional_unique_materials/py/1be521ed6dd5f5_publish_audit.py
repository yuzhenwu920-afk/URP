from pathlib import Path
import hashlib
import json
import shutil
import sys
import zipfile

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

ROOT=Path('/workspace/urp_run_20261018')
REPO=Path('/workspace/URP')
OUT=REPO/'deliverables/2026-10-18'
AUDIT=ROOT/'audit'
OUT.mkdir(parents=True,exist_ok=True)

shutil.copytree(AUDIT,OUT,dirs_exist_ok=True)
shutil.copyfile(ROOT/'audit_ready_package.py',OUT/'audit_ready_package.py')
shutil.copyfile(ROOT/'environment_regression.log',OUT/'environment_regression.log')
source=ROOT/'ready/DI_2022_Sobol_NSGA3_READY_PACKAGE_2026-10-17'
(OUT/'submitted').mkdir(exist_ok=True)
original=Path('/workspace/attachments/79649b1b-e3a0-4e1b-8cd2-5f906e50dc88/DI_2022_Sobol_NSGA3_READY_PACKAGE_2026-10-17(1).zip')
shutil.copyfile(original,OUT/'submitted/DI_2022_Sobol_NSGA3_READY_PACKAGE_2026-10-17.zip')
shutil.copyfile(source/'08_provenance/MANIFEST_SHA256.json',OUT/'submitted/ORIGINAL_PACKAGE_MANIFEST.json')
shutil.copyfile(source/'05_downstream_inputs/A18_pre_sobol_gate.json',OUT/'submitted/ORIGINAL_REPORTED_A18_GATE.json')

table=pd.read_csv(REPO/'deliverables/2026-10-16/tables/calibration_evidence_tiers.csv')
metrics=json.loads((OUT/'paired_metrics_2022.json').read_text())
sel=table['年份'].eq(2022)
for field,value in {'CC_R2':metrics['CC']['R2'],'CC_RMSE':metrics['CC']['RMSE'],
                    '生物量_R2':metrics['Biomass']['R2'],'生物量_RMSE':metrics['Biomass']['RMSE'],
                    '生物量样本数':metrics['Biomass']['N'],'证据':'2026-10-18从新增配对表重算；不是模型重跑'}.items():
    table.loc[sel,field]=value
table.to_csv(OUT/'four_year_calibration_with_2022_pairs.csv',index=False,encoding='utf-8-sig')
font=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
font_manager.fontManager.addfont(str(font))
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=str(font)).get_name(),
                     'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,
                     'pdf.fonttype':42,'font.size':11})
fig,axes=plt.subplots(2,2,figsize=(10.5,7.1))
palette=['#8fa5b1']*3+['#207a94']
for ax,key,title in zip(axes.ravel(),['CC_R2','生物量_R2','CC_RMSE','生物量_RMSE'],
                        ['冠层覆盖度 R²','生物量 R²','冠层覆盖度 RMSE','生物量 RMSE（t/ha）']):
    values=table[key].to_numpy();x=np.arange(4)
    ax.bar(x,values,color=palette,width=.6,zorder=3)
    ax.set_xticks(x,table['年份'].astype(str));ax.set_title(title,pad=12)
    ax.set_ylim(0,max(1.12,values.max()*1.2) if key.endswith('R2') else values.max()*1.25)
    ax.grid(axis='y',alpha=.18,zorder=0)
    for j,value in enumerate(values):ax.annotate(f'{value:.4f}',(j,value),xytext=(0,5),textcoords='offset points',ha='center',fontsize=10)
fig.suptitle('2019—2022 年校准对比：2022 配对证据已补齐',fontsize=16,y=.995)
fig.text(.5,.01,'2019—2021 沿用既有核验指标；2022 根据新增配对表重算。均为样本内校准评价。',ha='center',color='#5e6876',fontsize=10)
fig.tight_layout(rect=(0,.045,1,.96))
for ext in ['png','pdf']:fig.savefig(OUT/'figures'/f'F17_four_year_calibration_updated.{ext}',dpi=300,bbox_inches='tight')
plt.close(fig)

audit=json.loads((OUT/'SOURCE_PACKAGE_AUDIT.json').read_text())
missing='\n'.join('- `'+p+'`' for p in audit['missing_original_data_files'])
readme=f'''# 2022 新包核验与配对图更新（2026-10-18）

原2022模型源码已收到，并与阶段二检查点中的源哈希完全一致；12份data原件在新ZIP中全部缺席，其中4份已从旧附件按SHA256精确恢复，仍缺8份。本轮已重算配对指标并重绘2022及四年对比图，真实模型、Sobol和NSGA-III尚未重跑。

## 已完成

- 新包68项清单记录逐一核对通过；再次提交的DI_2022_Phase2.zip与10月17日原件相同。
- 2022阶段一4个检查点和阶段二检查点与冻结样本精确一致，保留行数分别215424和58784；MCMC未重跑。
- CC配对12条：R²={metrics['CC']['R2']:.12f}，RMSE={metrics['CC']['RMSE']:.12f}。
- 生物量配对10条：R²={metrics['Biomass']['R2']:.12f}，RMSE={metrics['Biomass']['RMSE']:.12f} t/ha。
- 配对模拟值均与上传的148天生长序列对应日精确匹配。R²按1−SSE/SST计算，另存Pearson相关平方，二者不混用。
- 新环境18项既有工程检查通过，测试中的合成模型不是作物模型计算结果。

## 模型入口的实际阻塞

原模型已成功导入，调用原始load_inputs()后报MISSING_INPUT：ETO_FILE_DI_2022_ETo_Geometry_Daily.csv。源码明确用该B组ETo替换普通气象中的ETo，因此不能用已有普通ETo代填。

请从原DI_2022_OneClick工程中打包完整data文件夹。缺失清单为：

{missing}

恢复的4份原件是气象、Field CC、锁定初始水、遥感CC，分别与原manifest哈希一致，见model_input_inventory.csv。原manifest未改，缺失的READY、初始点和基准文件未人工造出。配对表不能自动等同于原似然输入文件。

本次新包只包含2022的原模型源码；其A18记录中“4个原模型已恢复”的表述属于原作者报告，不能据此认定本工作区已具备另外三个年度模型。

## 文件

- `URP_2022_Audit_and_Figures_20261018.zip`：核验结果、已恢复的2022源工程、配对数据、两幅PNG/PDF图、论文增补和复算脚本。
- `figures/F16_2022_paired_calibration.png`：2022生长时序及配对散点；`F17_four_year_calibration_updated.png`：四年对比，明确包含2022。
- `paper_addendum_20261018.md/.docx/.pdf`：可并入论文的新增校准证据及当前执行限制。
- `submitted/`：用户新包原件和原始清单/声称的审计门，仅作为来源档案。

这批文件记录当前已完成的复算和缺件，10月17日六包保留其既有版本；完成真实模型计算后再整体更新，避免把配对重绘当作新Sobol或优化结果。
'''
(OUT/'README.md').write_text(readme,encoding='utf-8')
rows='\n'.join('| '+str(int(r['年份']))+' | '+ ' | '.join(f'{r[k]:.6f}' for k in ['CC_R2','CC_RMSE','生物量_R2','生物量_RMSE'])+' |' for _,r in table.iterrows())
paper=f'''# 2022年新增配对证据与论文增补
版本：2026-10-18。模型源代码已核验，原始运行data未齐；本稿基于上传的既有模型输出复算，真实模型、Sobol和优化本轮未重跑。

## 1 可写入校准结果的新增证据
2022年冠层覆盖度含12条观测—模拟配对，生物量含10条配对。按R²=1−SSE/SST复算，冠层R²为0.930617、RMSE为0.059574；生物量R²为0.996650、RMSE为0.556159 t/ha。模拟配对值与148天日生长输出的对应日期一致。这些为样本内校准评价，不是独立验证或新模型运行。
冠层的Pearson相关平方为0.959224，生物量为0.997228，与1−SSE/SST意义不同。每年仅一组年产量配对，单年产量R²不计算。

![2022年冠层、生物量时序与配对图](figures/F16_2022_paired_calibration.png)

图注：曲线和散点源于新提交工作包04_phase2_review中的既有输出与校准观测；本轮重新计算指标并作图。2022年冠层早期存在明显低估，应在讨论中保留。

## 2 四年结果表的更新
2019—2021沿用此前核验指标；2022从文档汇总精度升级为本轮配对复算，生物量样本数补为10。该更新修正10月17日论文中“2022仍缺配对表”的证据状态，不表示本轮重新执行四年作物模型。

| 年份 | CC_R2 | CC_RMSE | 生物量_R2 | 生物量_RMSE_t_ha |
| --- | --- | --- | --- | --- |
{rows}

![四年校准指标，包含2022](figures/F17_four_year_calibration_updated.png)

图注：四年R²按同一定义报告；RMSE保留相应单位。不能用较高生物量拟合优度推断灌溉优化结果已成立。

## 3 原模型复现与后续计算的当前状态
2022原始脚本SHA256为31dc424301d544ca55cbdaf3f68a9b7c265feef2b66f3380f67121232fe954d5，与阶段二科学合同一致。新ZIP漏装其data目录，12份原件中4份已由旧包按哈希恢复，仍缺8份；原模型输入加载首先在B组ETo文件处停止。原清单和原运行合同保留，未生成替代驱动、READY证据或初始参考值。
因此尚不能报告新的真实模型Sobol指数、Pareto前沿、推荐灌水日程或节水率。MCMC保持冻结；四年年度对比表和图均纳入2022。待原始data补齐且基准复现通过，再执行已声明范围的Sobol与固定年度中心的双目标优化及条件扰动核验。
'''
(OUT/'paper_addendum_20261018.md').write_text(paper,encoding='utf-8')
renderer=(Path('/workspace/urp_execution_20261016/document_renderer.py')).read_text().replace('2026-10-17','2026-10-18')
(OUT/'document_renderer.py').write_text(renderer)
sys.path.insert(0,str(OUT))
import document_renderer
document_renderer.pdf_report(paper,OUT/'paper_addendum_20261018.pdf')
document_renderer.word_report('paper_addendum_20261018.md')
with pd.ExcelWriter(OUT/'2022_audit_and_calibration.xlsx',engine='openpyxl') as writer:
    table.to_excel(writer,sheet_name='four_year_calibration',index=False)
    pd.read_csv(OUT/'paired_metrics_2022.csv').to_excel(writer,sheet_name='2022_pairs_metrics',index=False)
    pd.read_csv(OUT/'model_input_inventory.csv').to_excel(writer,sheet_name='input_inventory',index=False)
    pd.read_csv(OUT/'supplied_pairs/CC_pairs.csv').to_excel(writer,sheet_name='CC_pairs_2022',index=False)
    pd.read_csv(OUT/'supplied_pairs/Biomass_pairs.csv').to_excel(writer,sheet_name='biomass_pairs_2022',index=False)
metadata=dict(new_ready_zip_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
              duplicate_phase2_zip_sha256='68185f0020cad22bfad46a55ea276d7205cea553907eaf68f53906144a6dd264',
              date='2026-10-18',software_checks=18,scientific_model_calls=0)
(OUT/'UPLOAD_PROVENANCE.json').write_text(json.dumps(metadata,indent=2))
# The downloadable audit bundle omits the original 26MB upload, which remains separately archived.
bundle=OUT/'URP_2022_Audit_and_Figures_20261018.zip'
entries=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p!=bundle and 'submitted' not in p.relative_to(OUT).parts and '__pycache__' not in p.parts and p.name not in ['MANIFEST.json','SHA256SUMS.txt']:
        entries.append(dict(file=p.relative_to(OUT).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(OUT/'MANIFEST.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for e in entries:z.write(OUT/e['file'],'URP_2022_Update_20261018/'+e['file'])
    z.write(OUT/'MANIFEST.json','URP_2022_Update_20261018/MANIFEST.json')
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    for e in entries:assert hashlib.sha256(z.read('URP_2022_Update_20261018/'+e['file'])).hexdigest()==e['sha256']
(OUT/'SHA256SUMS.txt').write_text(hashlib.sha256(bundle.read_bytes()).hexdigest()+'  '+bundle.name+'\n')
print('Audit bundle',bundle.stat().st_size,'bytes;',len(entries),'files')
