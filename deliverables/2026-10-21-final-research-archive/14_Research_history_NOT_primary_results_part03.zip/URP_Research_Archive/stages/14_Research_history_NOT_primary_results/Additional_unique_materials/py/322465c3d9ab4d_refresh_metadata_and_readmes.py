from pathlib import Path
import json,hashlib,shutil,importlib.metadata
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/URP');PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED'
ART=Path('/workspace/urp_review/artifacts');T=ART/'tables'
REV=Path('/workspace/urp_followup_20261016/revision');PREP=Path('/workspace/urp_execution_20261016')
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def wr(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    audit=rd(ROOT/'PHASE2_2022_VALIDATION.json')
    with np.load(ART/'verified_phase_specific_draws.npz',allow_pickle=False) as z:shapes={k:list(z[k].shape) for k in z.files}
    assert len(shapes)==8
    wr(Path('/workspace/urp_review/NPZ_ARRAY_SHAPES.json'),shapes)
    files=[dict(file=p.relative_to(PROJECT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((PROJECT/'frozen_inputs').rglob('*')) if p.is_file()]
    wr(PROJECT/'FROZEN_INPUTS_MANIFEST.json',dict(date='2026-10-17',existing_seven_arrays_unchanged=True,
        added_array='p2_2022',added_shape=[58784,3],combined_samples_sha256=sha(PROJECT/'frozen_inputs/verified_phase_specific_draws.npz'),
        arrays=shapes,phase2_2022_checkpoint_sha256=audit['checkpoint_sha256'],phase2_smoke_used=False,files=files))
    guidance=rd(PROJECT/'GUIDANCE_SOURCES.json')
    guidance=[x for x in guidance if x['file']!='DI_2022_Phase2.zip']
    guidance.append(dict(file='DI_2022_Phase2.zip',sha256=audit['archive_sha256'],role='2026-10-17 true phase2 supplement'))
    wr(PROJECT/'GUIDANCE_SOURCES.json',guidance)
    findings=pd.read_csv(T/'findings_and_actions.csv')
    findings.loc[findings.ID=='A01','Finding']='历史原代理使用2022构造样本；当前真链已补齐'
    findings.to_csv(T/'findings_and_actions.csv',index=False,encoding='utf-8-sig')
    issues=pd.read_csv(REV/'tables/issue_reassessment.csv')
    for key,values in {'S03':('2022阶段二真链已核验','2000×32×3，burn163，58784行；smoke排除'),
                       'S05':('收到衔接脚本，原模型仍缺','衔接脚本依赖外部DI_2022_MCMC_ONE_CLICK.py与原data'),
                       'S10':('正式模型运行仍未执行','本轮更新真实样本/统计/配置；Sobol和优化结果不从历史代理继承')}.items():
        issues.loc[issues.ID==key,'Status']=values[0];issues.loc[issues.ID==key,'Action']=values[1]
    issues.to_csv(REV/'tables/issue_reassessment.csv',index=False,encoding='utf-8-sig')
    manifest=pd.read_csv(REV/'tables/manifest_check.csv');manifest=manifest[manifest.File!='DI_2022_Phase2.zip']
    manifest=pd.concat([manifest,pd.DataFrame([dict(File='DI_2022_Phase2.zip',Present=True,Hash_match=True)])],ignore_index=True)
    manifest.to_csv(REV/'tables/manifest_check.csv',index=False,encoding='utf-8-sig')
    meta=dict(date='2026-10-17',phase2_2022_present=True,phase2_2022_formal_shape=[2000,32,3],
              phase2_2022_retained_rows=58784,central_values_verified=32,verified_checkpoint_records=20,
              existing_7_arrays_unchanged=True,combined_arrays=shapes,new_model_runs=0,
              new_real_Sobol_executed=False,new_real_NSGAIII_executed=False,
              modified_DI_source_present=False,new_wrapper_present=True,smoke_in_statistics=False)
    wr(REV/'VALIDATION.json',meta);wr(ART/'delivery_validation.json',meta)
    wr(ART/'software_versions.json',rd(ROOT/'ANALYSIS_ENVIRONMENT.json'))
    shutil.copyfile(ROOT/'ANALYSIS_ENVIRONMENT.json',PROJECT/'ANALYSIS_ENVIRONMENT.json')
    shutil.copyfile(ROOT/'ANALYSIS_ENVIRONMENT.json',PREP/'ANALYSIS_ENVIRONMENT.json')
    shutil.copyfile(ROOT/'figure_contact_sheet.jpg',ART/'figure_contact_sheet.jpg')
    (PROJECT/'README.md').write_text('''# Sobol与NSGA-III修订工程（2026-10-17，2022第二阶段已补齐）

本版继续按照三份指导材料修订昨天的Sobol和优化，现已接入新补DI_2022_Phase2.zip的真实第二阶段。MCMC不重跑；原7个保留数组逐值不变，统一NPZ新增p2_2022（58784×3），2022中心点数值不变且现已由原链交叉核验。

## 本轮更新

- 正式链2000×32×3，burn=163，每walker保留1837步；2步smoke不进统计。
- 四年8个阶段组、32个中心值均有核验来源。2022阶段一均值与handoff逐值一致，4份源检查点哈希引用匹配既有核验记录。
- 2022的local95范围和阶段二128组整行条件扰动现可读取真样本。缺件保护仍保留，但不会再把正常2022数据误报为缺失。
- 2022基准改为新增JSON精确值：Y13=14.0777828181、Tr=529.9393430560、Es=66.8452930087、ET=596.7846360647；基准比对容差1e-5。
- 诊断、量账、来源和数组形状见frozen_inputs/PHASE2_2022_VALIDATION.json、FROZEN_INPUTS_MANIFEST.json和RUN_READINESS.json。

## 保持的正式分析设置

Sobol为8参数公共全局物理范围中的独立均匀响应实验，N128×3种子，必要时512；保存六输出、S1/ST及bootstrap区间、均值/方差/单位与输入响应矩阵。local95只称邻域响应，不称posterior Sobol，不计算CAI。正式公共范围不因2022链支持较窄而自动改成年度范围。

优化固定年度中心参数，min(-Y13,I)，硬约束I≤年度DI基准、Y13≥0.95×文献观测，另查非负量、灌期与完整量账。优先SMT1—4；不支持时4—5阶段水量。100方向/种群、100代、5种子，与同预算NSGA-II对照；每代保存X/F/G/CV和归一化HV。

推荐为ε门槛内最低灌水量及两个相邻可行备选，无可行解则无推荐。候选真实回代后，阶段一/固定阶段二中心、阶段二整行/固定阶段一中心分别至少128组扰动，报告概率、5%分位、MC误差与水量/通量。不是八维联合后验传播。年度专用制度不宣称未知年通用验证；旧2021约38%节水仍撤回。

## 执行

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python DI_PHASE3_ONE_CLICK.py --phase all --auto-expand
python DI_PHASE3_ONE_CLICK.py --phase sobol --track local95 --years 2022
```

原Modified DI模型的冻结依赖单独恢复。若仅检查已接入的2022范围，可执行：

```bash
python -c "from model_adapter import load_study; from phaseB_sobol import make_problem; print(make_problem(load_study(),2022,'local95'))"
```

## 尚未执行的真实计算

新增9KB脚本是衔接包装器，仍导入外部原项目DI_2022_MCMC_ONE_CLICK.py及data，不包含原模型实现。因此real_model/adapter.py仍需接入原Modified DI；本轮没有生成新的真实模型Sobol、Pareto前沿或节水率，程序不回退旧代理。完成源链核验也不等于已认证收敛或外部验证。

frozen_inputs/DI_2022_Phase2.zip原样保留上传文件，其中smoke仅为原件的一部分；当前程序只用显式正式路径与已核验统一NPZ。2022 R²仍缺配对表支持，原文档值不能称本轮配对重算。新模型JSON是条件均值参数点输出，不是后验预测均值。

测试记录见SOFTWARE_VALIDATION.json。测试使用Ishigami与合成模拟器，优化夹具为20种群、10代、5种子；测试图与前沿不作为作物结果交付。输出默认在output_revised/<UTC时间>；Sobol可按同配置/来源日志续算，优化保留每代快照但不承诺从中间代精确续跑。

包内包含完整修订代码、原始补件、冻结中心点与8个样本数组、源码差异、条件扰动/图表模块和核验清单。真实源码接入后再运行上述正式预算，不能用软件测试填入论文正式结果。
''',encoding='utf-8')
    change=PROJECT/'按三份文件的改动说明.md'
    text=change.read_text();text=text.replace('2022真实阶段二链亦未交付到本环境','2022真实阶段二链已于2026-10-17补齐并核验')
    text=text.replace('这些样本用于','这些样本用于')
    text+='\n\n## 2026-10-17补件更新\n2022正式链已接入，burn163后58784行；中心值不变，来源已核验。local95与阶段二条件扰动现均可读取，不再以缺链阻断2022。真实原模型仍不在包装脚本中，正式Sobol和优化尚未运行。\n'
    change.write_text(text,encoding='utf-8')
    readme='''# 2026-10-17更新：2022真实第二阶段已接入

正式2000×32×3链已核验，统一burn=163后保留58784行。四年32个中心点全部可追溯；原7个数组逐值不变，新增p2_2022。2步smoke排除。

本包的论文、图表、表格、来源与状态已更新；2022参数区间、相关结构、水量账和精确基准已补齐。当前正式方法仍为公共全局独立范围Sobol、固定中心点双目标优化和候选分组条件扰动。

新增包仅含依赖原项目的衔接脚本，不包含其导入的DI_2022_MCMC_ONE_CLICK.py及原data。因此真实模型的新Sobol/NSGA-III尚未运行；历史代理图和旧节水结果不升级为正式结果。2022逐日CC/生物量配对表仍未交付，R²标为文档来源。

文件名中的20261016保留用于原下载链接兼容，正文及核验版本均为2026-10-17。请先读当前README和PHASE2_2022_VALIDATION.json。\n'''
    (REV/'README.md').write_text(readme,encoding='utf-8')
    (PREP/'README.md').write_text(readme+'''\n## 计算准备包内容与复建\n包含精确2022基准、统一8组保留样本、正式链副本与源JSON、15360行公共全局设计、响应检查程序、当前论文/图表与核验。设计只有输入X，尚无真实模型响应Y。\n\n`python build_inputs.py --out new_designs --n 128`从已交付配置检查2022基准并生成新设计；`python build_documents.py`用当前Markdown和图重建Word/PDF（另需reportlab、python-docx、Pillow和Pandoc）。`python verify_delivery.py`检查设计、来源、原链与文档。\n\nreal_model_pipeline.py的prepare/benchmark/run/analyze仍可用；真实适配器缺件时明确失败。2022基准已更新为精确JSON，不再因阶段二缺失而阻止验收。`study_config.json`主空间改为公共全局物理范围，`tables/annual_sampling_domains.csv`仅描述链支持，两者不是同一对象。\n''',encoding='utf-8')
    (Path('/workspace/urp_review')/'README_交付说明.md').write_text(readme+'''\n当前完整报告包在artifacts/给出论文、审查、工作簿、图册和真链统计；formal_project/提供最新Sobol/优化工程。history_20261015/为旧代理工程及旧复现脚本，仅用于审计历史结果，不作为正式入口。\n''',encoding='utf-8')
    (Path('/workspace/urp_review')/'README_RESULTS.md').write_text(readme+'''\n本运行结果包新增的是原始阶段二复核与样本整理，未重新跑原作物模型。artifacts/verified_phase_specific_draws.npz含四年8组真实保留数组，NPZ_ARRAY_SHAPES.json列形状；旧36组Sobol和9次优化仅为2026-10-15代理探索，其日志和图有明确历史标签。\n''',encoding='utf-8')
    for base in [ART,REV,PREP,PROJECT]:
        (base/'UPDATE_20261017.md').write_text('版本2026-10-17：2022真实阶段二已核验并接入；burn163、58784行，中心参数不变；旧7数组不变。原模型新Sobol/优化未执行，原实现仍待接入。\n',encoding='utf-8')
    # Keep the wrapper's dependency clear when a user invokes the formal entrypoint.
    adapter=PROJECT/'real_model/adapter.py';text=adapter.read_text()
    text=text.replace('当前附件未包含原Modified DI源码；须接入冻结原模型，不能使用旧代理代替','2022阶段二包装器和真链已接入；仍缺其导入的原DI_2022_MCMC_ONE_CLICK.py及data，真实模型未接入')
    adapter.write_text(text,encoding='utf-8')
    print('All current readmes and metadata now distinguish present 2022 phase2 from missing original model.')

if __name__=='__main__':main()
