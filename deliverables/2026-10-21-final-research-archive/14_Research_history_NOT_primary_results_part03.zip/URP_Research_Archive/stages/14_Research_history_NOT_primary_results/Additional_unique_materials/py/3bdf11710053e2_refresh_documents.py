"""Synchronize current four-year figures, data, documents and readiness metadata."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,sys
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/URP');ART=Path('/workspace/urp_review/artifacts');T=ART/'tables'
REV=Path('/workspace/urp_followup_20261016/revision');PREP=Path('/workspace/urp_execution_20261016');PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED'
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def wr(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def replace_folder(src,dst):
 if dst.exists():shutil.rmtree(dst)
 shutil.copytree(src,dst)
def mdtable(df):
 def cell(x):
  if pd.isna(x):return '—'
  if isinstance(x,(float,np.floating)):return f'{x:.4f}'
  return str(x)
 return '\n'.join(['| '+' | '.join(map(str,df.columns))+' |','| '+' | '.join(['---']*len(df.columns))+' |']+['| '+' | '.join(cell(x) for x in row)+' |' for row in df.itertuples(index=False,name=None)])

caps=rd(ROOT/'figure_captions.json');assert len(caps)==18 and all(x['years']==[2019,2020,2021,2022] for x in caps)
# Old proxy diagnostics and previous figure layouts are historical records.
if (ART/'figures').exists() and not (ART/'history_20261017/figures').exists():
 shutil.copytree(ART/'figures',ART/'history_20261017/figures',dirs_exist_ok=True)
replace_folder(ROOT/'figures',ART/'figures')
copy(ROOT/'figure_captions.json',ART/'figure_captions.json')
copy(ROOT/'FIGURE_COVERAGE_AND_STYLE.json',ART/'FIGURE_COVERAGE_AND_STYLE.json')
copy(ROOT/'SOURCE_OUTPUT_MANIFEST.csv',T/'four_year_source_output_manifest.csv')
copy('/workspace/URP/deliverables/2026-10-18-data-complete/DATA_COMPLETENESS_AND_REPLAY.json',ART/'MODEL_2022_READINESS.json')

readiness=dict(date='2026-10-18',years=[2019,2020,2021,2022],current_figure_pairs=18,
 current_annual_comparisons_include_all_four_years=True,central_values_verified=32,
 raw_2022_phase2_present=True,phase2_2022_retained_rows=58784,original_model_available_years=[2022],
 original_model_pending_years=[2019,2020,2021],missing_2022_data_files=[],
 original_2022_preflight_passed=True,original_2022_mean_point_replay_passed=True,
 original_2022_fixed_date_management_response_checked=True,
 new_complete_real_model_Sobol_executed=False,new_complete_real_model_NSGAIII_executed=False,
 MCMC_rerun=False,figure_font_minimum_pt=10.5,png_dpi=300,pdf_vector_labels=True)
wr(ART/'RUN_READINESS.json',readiness);wr(PROJECT/'RUN_READINESS.json',readiness)
wr(PROJECT/'ANALYSIS_ENVIRONMENT.json',rd('/workspace/URP/deliverables/2026-10-18-data-complete/VERIFIED_ENVIRONMENT.json'))
log=(ROOT/'engineering_tests.log').read_text();assert 'Ran 19 tests' in log and log.rstrip().endswith('OK')
wr(PROJECT/'SOFTWARE_VALIDATION.json',dict(date='2026-10-18',tests_run=19,passed=True,failures=0,errors=0,skipped=0,
 scope='18 engineering/analytic checks plus one actual 2022 engine baseline-and-management check',details=log,
 original_2022_engine_baseline_verified=True,full_Sobol_experiment_completed=False,full_NSGAIII_experiment_completed=False))
copy(PROJECT/'SOFTWARE_VALIDATION.json',ART/'ENGINEERING_VALIDATION.json')
for name in ['calibration_evidence_tiers','paper_calibration_table','calibration_metrics_recomputed']:
 for folder in [REV/'tables',PREP/'tables']:copy(T/(name+'.csv'),folder/(name+'.csv'))
for folder in [REV,PREP]:
 if (folder/'figures').exists():shutil.rmtree(folder/'figures')
 shutil.copytree(ROOT/'figures',folder/'figures')
 for name in ['figure_captions.json','FIGURE_COVERAGE_AND_STYLE.json']:
  copy(ROOT/name,folder/name)
 for name in ['RUN_READINESS.json','MODEL_2022_READINESS.json']:
  copy(ART/name,folder/name)
 shutil.copytree(ART/'four_year_source_data',folder/'four_year_source_data',dirs_exist_ok=True)
copy(ROOT/'SOURCE_OUTPUT_MANIFEST.csv',REV/'tables/four_year_source_output_manifest.csv')
copy(ROOT/'SOURCE_OUTPUT_MANIFEST.csv',PREP/'tables/four_year_source_output_manifest.csv')
replace_folder(PROJECT/'real_model',PREP/'real_model')
config=rd(PREP/'study_config.json');config['status']='2022_ORIGINAL_ENGINE_CONNECTED_FOUR_YEAR_FIGURES_UPDATED'
config['original_model_available_years']=[2022];config['original_model_pending_years']=[2019,2020,2021]
wr(PREP/'study_config.json',config)
sys.path.insert(0,str(PREP));import real_model_pipeline as pipeline
rebuilt=ROOT/'designs_rebuilt'
if rebuilt.exists():shutil.rmtree(rebuilt)
pipeline.prepare(PREP/'study_config.json',rebuilt,n=128)
for path in (PREP/'designs_N128').glob('*.npy'):
 np.testing.assert_array_equal(np.load(path),np.load(rebuilt/path.name))
replace_folder(rebuilt,PREP/'designs_N128')

# The engineering archive carries exactly the same complete four-year figure set.
overview=PROJECT/'four_year_figures'
replace_folder(ROOT/'figures',overview)
copy(ROOT/'FIGURE_COVERAGE_AND_STYLE.json',PROJECT/'FIGURE_COVERAGE_AND_STYLE.json')
copy(ROOT/'SOURCE_OUTPUT_MANIFEST.csv',PROJECT/'frozen_inputs/YEAR_OUTPUT_PROVENANCE.csv')
inputs=[]
for p in sorted((PROJECT/'frozen_inputs').rglob('*')):
 if p.is_file():inputs.append(dict(file=p.relative_to(PROJECT).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
wr(PROJECT/'FROZEN_INPUTS_MANIFEST.json',dict(date='2026-10-18',MCMC_frozen=True,files=inputs))

cal=pd.read_csv(T/'calibration_evidence_tiers.csv');groups=pd.read_csv(T/'sampling_group_summary.csv')
cc=cal[['年份','CC样本数','CC_R2','CC_RMSE']].copy();cc.columns=['年份','配对数','R2','RMSE']
bio=cal[['年份','生物量样本数','生物量_R2','生物量_RMSE']].copy();bio.columns=['年份','配对数','R2','RMSE_t_ha']
yieldtab=cal[['年份','观测产量','模拟产量','产量误差_pct']].copy()
head=pd.read_csv(T/'observed_yield_gate_headroom.csv')[['Year','Observed_Y13_t_ha','Original_model_baseline_Y13_t_ha','Absolute_95pct_gate_t_ha','Remaining_loss_allowed_pct_of_model_baseline']]
head.columns=['年份','观测产量','模型基准','95%门槛','产量余量_pct']
water=pd.read_csv(T/'water_balance_recomputed.csv');water=water[water.Scenario=='DI'][['Year','Irrigation_mm','Tr_mm','Es_mm','ET_mm','Storage_gain_mm']]
water.columns=['年份','灌水_mm','Tr_mm','Es_mm','ET_mm','储水增加_mm']
by_stem={Path(x['file']).stem:x for x in caps}
def figure(stem):
 x=by_stem[stem]
 return f"\n![{x['title']}](figures/{x['file']})\n\n图注：{x['caption']}\n"
paper=f'''# 滴灌玉米改进 AquaCrop 的分阶段校准、范围敏感性与灌溉决策
## 四年数据与插图论文框架（2026-10-18 更新版）
本稿统一纳入2019、2020、2021、2022。图中四年分别为蓝、橙、绿、紫，字号与图例位置统一。2019—2021基于已核验的原始输出，2022增加了本轮原模型均值点回放；完整真实模型Sobol和优化实验尚未完成，相关结果保留待填。

## 摘要草稿
本研究以2019—2022年DI玉米的气象、冠层、生物量、产量和初始土壤水为基础，构建分阶段条件校准、独立范围敏感性和确定性灌溉决策框架。四年冠层与生物量配对序列均可复算，年度中心输入来自各阶段保留样本均值。2022年原模型与12份data原件已补齐，18项源文件哈希匹配，预审及DI/零灌溉均值点回放通过。后续将按预声明公共独立范围开展Sobol分析，并在固定年度中心点、产量与灌溉硬约束下开展双目标优化及候选条件扰动核验。现有结果属于样本内校准与数值复现，不提前报告正式敏感性排序、推荐制度或节水率。
关键词：滴灌玉米；改进AquaCrop；分阶段条件校准；Sobol；NSGA-III。

## 1 引言与研究问题
研究主线应围绕水分过程校准如何支持受供水与产量限制的管理决策，而不是把算法并列作为创新点。RQ1：四年资料支持哪些过程重现和参数补偿结论？RQ2：预声明独立物理范围下，哪些输入贡献输出方差？RQ3：固定年度中心点时，哪些非支配灌溉制度满足观测产量门槛，其条件参数扰动表现如何？
研究区、试验处理、田间重复数与测量误差仍须按原始论文和记录补齐，不能从拟合图推断试验设计。
{figure('F01_workflow')}

## 2 数据与模型复现
Field LAI转换的CC用于阶段一校准；地上干生物量和年产量用于阶段二条件校准。遥感CC为未进入似然的辅助时序，2019—2021处理为BI、2022标签不全，因此不称DI独立验证。ET=Tr+Es，派生ET核对不重复作为独立似然信息。
2022模型源码SHA256为31dc424301d544ca55cbdaf3f68a9b7c265feef2b66f3380f67121232fe954d5，与原阶段二合同一致；数据文件全部按原哈希核对。实际预审、冻结初始点及历史分组MAP复现通过。在阶段二均值点，本轮重算DI产量14.0777828181 t/ha、ET596.7846360647 mm；DI与零灌溉汇总和原记录差异均低于1.5×10^-14。阶段二均值输出不是后验预测均值。
当前工程已接入2022原模型；2019—2021的原始模型实现仍待接入。四年图表所用原输出与原件来源逐项记录，不能把重绘理解为本轮重新执行另外三年模型。

## 3 冻结分阶段校准与参数
阶段一为CCx、CGC_CD、CDC_CD、SenescenceCD、Kcb，阶段二为WP_early、WP_late、HI0。确定性分析采用年度两组保留样本的均值拼接；不把不同阶段、年度样本拼成八维联合后验。
每年阶段一4个独立ensemble，阶段二1个，每组32 walkers、2000步。采用组内最大τ的5倍向上取整截断；2022阶段二burn=163，保留1837步/每walker、58784行相关样本。原八个保留数组均保持冻结，不重跑MCMC。
严格阶段一Rhat/ESS限制在补充图S01单列，不将耦合walker视作独立链，也不宣称已认证联合收敛。确定性下游流程不因此强制新增联合后验门槛。
{figure('F17_parameter_centers')}
{figure('F07_parameter_intervals')}

## 4 四年校准结果
### 4.1 冠层覆盖度
{mdtable(cc)}
{figure('F02_CC_trajectories')}
### 4.2 地上干生物量
{mdtable(bio)}
{figure('F03_Biomass_trajectories')}
R²按1−SSE/SST计算，与Pearson相关平方分开；RMSE保留对应单位。2022冠层早期低估和2021生物量偏差应如实讨论，不通过平滑、删点或视觉缩放隐藏。四年散点配对图F04/F05另行提供。
### 4.3 年产量与误差
{mdtable(yieldtab)}
每年仅一对年产量，单年产量R²不计算。±5%为项目容许幅度，不是统计置信带。上述指标为校准拟合，不是外部验证。
{figure('F06_calibration_summary')}

## 5 参数补偿与水量过程
2022阶段二WP_late与HI0相关约−0.645；其他年度也存在补偿结构。后续条件扰动应保留同一阶段样本的整行相关，不用边际独立重抽代替。跨年参数差异可能吸收驱动误差、数字化误差及结构差异，不仅代表生理变化。
{figure('F08_phase2_compensation')}
{mdtable(water)}
{figure('F09_water_ledger')}
完整量账包含灌溉、降水、CR、GwIn、ET、径流、深层渗漏、排水以及整个土壤与地表储水变化。季节残差约10^-12mm属于内部守恒证据。2022零灌溉产量5.8495800962 t/ha、相对DI减产约58.45%，仍是未经同地零灌溉观测验证的反事实。

## 6 Sobol 正式实验设计
八参数采用已声明公共物理范围内相互独立的均匀分布：CCx[0.60,0.99]、CGC[0.08,0.16]、CDC[0.03,0.12]、SenescenceCD[115,145]、Kcb[1.05,1.60]、WP early/late[10,40]、HI0[0.35,0.60]。这是指定范围的响应实验，不是原先验密度或条件后验传播，文献/农艺依据仍须在定稿时补全。
先N=128、三个scramble种子101/202/303，不算二阶时每年每种子1280次调用，四年共15360次；排序或区间不稳再扩大N=512。保存六输出Y13、Biomass、Tr、Es、ET、MaxCC，以及S1、ST、bootstrap区间、均值、方差、单位和输入—响应矩阵。常量输出标为归一化指数未定义；失败点不删行、不填零，不强制某参数排名第一。
local95仅作为边际邻域响应补充，不称posterior Sobol或计算CAI。现2022原模型可按工程中的--years 2022入口执行；完整实验尚未完成，本节不填历史代理指数。

## 7 确定性灌溉优化与候选核验
目标为min(-Y13,I)，固定年度中心参数。硬约束I≤年度DI基准、Y13≥0.95×文献观测；并检查非负量、原灌溉窗口和完整水量账。IWP=100Y[t/ha]/I[mm]，单位kg/m³。
{mdtable(head)}
{figure('F13_yield_gate')}
当前已提供2022接口支持原五个日期的阶段水量分配：06-09、06-22、07-03、07-24、08-09。它不提供SMT触发控制，因此采用指导文件允许的五阶段水量方案；该设置优化水量，不声称同时优化灌溉日期。
正式预算为约100个体/参考方向、100代、5种子，并与同预算NSGA-II对照。保存每代X/F/G/CV与统一归一化HV。以ε门槛内最低灌水量选主候选，另列两个相邻可行备选；无可行解时不输出推荐。
候选分别做阶段一扰动/固定阶段二、阶段二整行扰动/固定阶段一，每个可用组至少128行。报告均值、5%分位、观测门槛达标概率、MC误差、I/ET/Tr/Es和守恒。这是条件分布下的核验，不是八维联合传播或田间失收概率。
真实前沿、节水率与推荐日程仍待完整实验；旧代理图不用于本节结论，旧2021约38%节水不恢复。年度专用结果不自动外推为未知年通用制度。

## 8 讨论与定稿安排
讨论区分校准/验证、指定范围敏感性/后验归因、确定性最优/可靠性、年度定制/跨年泛化。保留数字化观测与假定sigma、近似Es目标、B组ETo、部分假定灌溉记录、模型结构与参数补偿等限制。
论文可按“数据与证据角色—冻结校准与基准复现—四年过程与参数—Sobol范围实验—双目标优化与条件核验—局限与适用条件”组织。正式敏感性表、前沿、算法对照和候选管理表在真实运行后插入，不提前填写。
图件当前统一18组PNG/PDF，所有年度比较均包含2019—2022。主图字号不小于10.5pt，年份颜色固定；补充S01保留严格诊断。旧代理探索归入历史目录。

## 参考方向
FAO Irrigation and Drainage Paper 66；Goodman与Weare（2010），DOI 10.2140/camcos.2010.5.65；Vehtari等（2021），DOI 10.1214/20-BA1221；Saltelli等（2010），DOI 10.1016/j.cpc.2009.09.018；Deb与Jain（2014），DOI 10.1109/TEVC.2013.2281535。具体试验资料、参考论文原文和引用页码仍须逐项核对。
'''
report=f'''# URP 六包同步更新与四年图表核验
版本：2026-10-18。范围：六个交付包、2019—2022图件、论文与报告，以及2022原模型接入。

## 1 已完成与执行范围
2022完整data已补齐，18项原模型/资料哈希与原manifest一致；实际预审和阶段二均值点DI/零灌溉回放通过。本次工程进一步接入2022原模型，并用基准重复运行与改变五次灌水量的实测验证接口。MCMC保持冻结，统一文件的8个数组不变。
四年逐日生长和CC/生物量配对输出已逐点核对，全部当前年度图含2019、2020、2021、2022。2019—2021引用原核验输出；2022引用本次均值点回放。完整真实模型Sobol与NSGA-III实验尚未完成，另外三年的原始模型实现仍待接入。

## 2 图形版式与完整性
当前图件为18组300dpi PNG与矢量PDF，固定年份色：2019蓝、2020橙、2021绿、2022紫。标题15pt、面板标题13pt、坐标12pt、刻度11pt、注释不小于10.5pt；图例设置专门留白。分开输出冠层、生物量、配对图和轨迹，避免挤成大拼图。
FIGURE_COVERAGE_AND_STYLE.json逐图列出四年覆盖、字体阈值和文件哈希。旧2022单年轨迹和历史代理图保存在历史记录中，当前图件包不混入这些旧图。均值/区间/相关和水量图中的2022来自真实冻结样本或原模型回放，无插值补位。
{figure('F06_calibration_summary')}

## 3 四年校准配对核对
{mdtable(cc)}
{mdtable(bio)}
2022冠层R²=0.9306170451、RMSE=0.0595741682；生物量R²=0.9966499365、RMSE=0.5561588827 t/ha。2022不再标记“R²仅为文档报告值”。R²按1−SSE/SST计算，逐日输出与配对模拟值对应日期一致。

## 4 模型、水量与参数状态
2022均值点Y13=14.0777828181 t/ha、I=404.84mm、ET=596.7846360647mm，原汇总回放最大差异小于1.5×10^-14。季节量账残差约10^-12mm；单位与干/湿基换算已核验。保产门槛13.376 t/ha，产量余量约4.985%，该余量不等于节水率。
{mdtable(head)}
四年16组阶段一、4组阶段二记录与32个中心值可追溯；阶段二为条件分布，单ensemble不能宣称八维联合收敛。严格阶段一诊断仍单列，未据此强制重跑MCMC。

## 5 六包更新内容
完整报告包：新四年图、论文/报告/工作簿、当前工程及历史审计；运行结果包：冻结样本、四年原输出、2022原模型回放与更新表；图件包：18组当前四年图、源表、图注与覆盖清单；材料复核包：新论文/报告、原件来源与四年表；计算准备包：完整2022接口、四年设计与基准收据、论文/图；工程包：完整2022源码/data、B/C流程、冻结样本、19项检查及四年概览图。
所有包使用同一版当前图和表，文件名保留旧日期以兼容下载地址，内部版本均为2026-10-18。完整正式敏感性与优化结果仍待计算；历史36组代理Sobol及9次代理优化仅留作审计，不能替代真实作物模型结果。

## 6 方法与限制
正式Sobol保持公共独立均匀范围，local95仅作邻域响应；优化固定中心点、两个目标、观测95%保产及灌水上限，候选单列组内条件扰动。2022接口仅支持原五个固定日期的水量分配。数据数字化误差、近似Es、RS处理不一致、原模型结构与采样诊断等限制保留；不声称独立验证、已得到节水推荐或未知年普适制度。
'''

renderer=(PREP/'document_renderer.py').read_text().replace('2026-10-17','2026-10-18').replace("fontSize=7.5,leading=11","fontSize=9,leading=12.5")
for folder in [ART,REV,PREP]:copytext=folder/'document_renderer.py';copytext.write_text(renderer,encoding='utf-8')
def render(folder,stem,text):
 (folder/(stem+'.md')).write_text(text,encoding='utf-8')
 spec=importlib.util.spec_from_file_location('renderer_'+str(abs(hash(str(folder)))),folder/'document_renderer.py')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 module.pdf_report(text,folder/(stem+'.pdf'));module.word_report(stem+'.md')
render(ART,'URP_论文框架_含数据与图',paper);render(ART,'URP_合理性审查报告',report)
render(REV,'URP_20261016_论文框架_确定性主线',paper);render(REV,'URP_20261016_复核与变更说明',report)
render(PREP,'paper_framework_execution_ready',paper);render(PREP,'review_update_20261018',report)
# Remove current-view superseded 2022-missing reports from the preparation folder.
for ext in ['md','docx','pdf']:(PREP/('review_update_20261017.'+ext)).unlink(missing_ok=True)
(PREP/'build_documents.py').write_text('''from pathlib import Path
import document_renderer as renderer
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    for name in ['paper_framework_execution_ready','review_update_20261018']:
        renderer.pdf_report((ROOT/(name+'.md')).read_text(),ROOT/(name+'.pdf'))
        renderer.word_report(name+'.md')
''')

for folder,name in [(ART,'URP_复核结果表.xlsx'),(REV,'URP_20261016_复核结果表.xlsx'),(PREP,'execution_evidence.xlsx')]:
 with pd.ExcelWriter(folder/name,engine='openpyxl') as writer:
  for stem in ['calibration_evidence_tiers','calibration_metrics_recomputed','parameter_intervals_verified','observed_yield_gate_headroom','sampling_group_summary','water_balance_recomputed','four_year_source_output_manifest']:
   pd.read_csv(T/(stem+'.csv')).to_excel(writer,sheet_name=stem[:31],index=False)
html='''<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>URP 四年图册</title><style>body{font-family:system-ui,sans-serif;color:#293844;background:#f2f5f7;max-width:1300px;margin:30px auto;padding:0 20px}h1{font-size:28px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:24px}article{background:white;border-radius:12px;padding:20px}img{width:100%;height:auto}p{font-size:16px;line-height:1.7}a{color:#0072b2}h2{font-size:20px}</style><h1>URP · 2019—2022 四年图册</h1><p>2019 蓝 · 2020 橙 · 2021 绿 · 2022 紫。每张年度图含四年。2022原模型与数据已齐；完整Sobol/优化实验尚未完成。</p><div class="grid">'''
for x in caps:
 html+=f'<article><h2>{x["title"]}</h2><a href="figures/{x["file"]}"><img loading="lazy" src="figures/{x["file"]}" alt="{x["title"]}"></a><p>{x["caption"]}</p><a href="figures/{Path(x["file"]).stem}.pdf">矢量 PDF</a></article>'
html+='</div></html>'
for folder in [ART,REV,PREP]:(folder/'图表索引.html').write_text(html,encoding='utf-8')
(ART/'URP_图表画册.html').write_text(html,encoding='utf-8')
(PROJECT/'图表索引.html').write_text(html.replace('figures/','four_year_figures/'),encoding='utf-8')

project_readme='''# Sobol 与 NSGA-III 工程（2026-10-18，2022 原模型已接入）

MCMC保持冻结，8个年度/阶段样本数组不变。2022原源码及12份data原件已齐，全部哈希核验；实际预审、均值点回放及管理量修改检查通过。其他三年原始模型实现尚待接入，当前可运行年度为2022。

正式范围、目标与预算沿用既有指导：公共独立均匀范围Sobol，N128×3种子，必要时N512；优化固定中心点，min(-Y13,I)，I≤原DI、Y≥95%文献观测，100代×5种子，与同预算NSGA-II对照。2022使用原五个固定灌溉日的水量分配，不声称优化灌期或实现SMT。

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python DI_PHASE3_ONE_CLICK.py --years 2022 --phase sobol --n 128
python DI_PHASE3_ONE_CLICK.py --years 2022 --phase optimization
```

测试19项通过，含真实2022原模型基准重复运行与五次水量修改；合成/Ishigami测试结果不作为作物结果。完整Sobol和优化实验尚未完成。本版图表重绘及基准回放不能作为新敏感性排序、前沿或节水结论。

four_year_figures含完整18组四年PNG/PDF，与图件包逐文件一致，统一蓝/橙/绿/紫，最小字号10.5pt。图表索引.html可浏览。frozen_inputs/year_outputs含四年原始过程及配对表；2022是本次均值点回放，其余三年沿用原输出。源码/data与原manifest原样保留。

候选需真实回代，再对两个参数组分别做至少128行条件扰动，保留组内相关，不构造八维联合后验。严格采样诊断保留为补充。边界只允许机器舍入精度，未增加农艺约束松弛。正式试验结果不回退旧代理。
'''
(PROJECT/'README.md').write_text(project_readme,encoding='utf-8')
(PROJECT/'UPDATE_20261018.md').write_text(report.split('## 3')[0],encoding='utf-8')
for folder in [ART,REV,PREP]:
 (folder/'UPDATE_20261018.md').write_text('2026-10-18：2022源码/data齐全并接入；四年原始输出逐点核对，18组当前图均含2019—2022，字体/配色/布局统一。完整Sobol与优化实验尚未完成。\n',encoding='utf-8')
 (folder/'README.md').write_text('''# URP 四年同步更新（2026-10-18）

本包已同步当前四年图表、数据与论文。18组PNG/PDF均包含2019、2020、2021、2022，固定年份色与字体；图表索引.html可浏览，FIGURE_COVERAGE_AND_STYLE.json可核对。

2022原模型与data已齐，基准和管理量修改实测通过。MCMC冻结；2019—2021沿用原核验输出，原始模型实现尚待接入。完整真实Sobol和NSGA-III实验尚未完成，不从历史代理结果填写正式结论。
''',encoding='utf-8')
(Path('/workspace/urp_review')/'README_交付说明.md').write_text((ART/'README.md').read_text(),encoding='utf-8')
(Path('/workspace/urp_review')/'README_RESULTS.md').write_text((ART/'README.md').read_text()+'\n运行产物含8组冻结数组、四年逐日/配对原输出、2022实测记录与更新表。历史代理输出仅作历史审计。\n',encoding='utf-8')
for folder in [ART,REV,PREP]:
 for name in ['VALIDATION.json','RUN_READINESS.json']:wr(folder/name,readiness)
 print('Updated materials',folder,flush=True)
for folder in [ART,REV,PREP,PROJECT]:
 old=folder/'UPDATE_20261017.md'
 if old.exists():
  target=folder/'history_20261017/UPDATE_20261017.md';target.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(old),target)
prov=rd(PREP/'source_provenance.json')
if isinstance(prov,list):prov={'inherited_sources':prov}
prov['current_date']='2026-10-18';prov['current_original_model_available_years']=[2022]
prov['current_original_model_pending_years']=[2019,2020,2021]
prov['current_2022_model_and_data_complete']=True;wr(PREP/'source_provenance.json',prov)
