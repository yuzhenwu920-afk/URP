"""Rebuild current posterior/ledger figures and label historical proxy figures."""
from pathlib import Path
import os,sys,json
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('XDG_CACHE_HOME',str(ROOT/'.cache'))
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
sys.path.insert(0,'/workspace/urp_review/src')
import make_figures as g
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from PIL import Image,ImageDraw

ART=Path('/workspace/urp_review/artifacts');T=ART/'tables';F=ART/'figures'
REV=Path('/workspace/urp_followup_20261016/revision')
PROJECT=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
NAMES=g.NAMES;YEARS=[2019,2020,2021,2022]
C={2019:'#176B87',2020:'#A8762A',2021:'#805CA2',2022:'#3D8B75'}
DARK='#25384A';RED='#B14D4A';caps=[]
def table(name):return pd.read_csv(T/(name+'.csv'))
def save(fig,name,title,note):
    historical=name[:3] in ['F07','F08','F09','F10','F11','F12','F13']
    if historical:title='历史代理诊断（2026-10-15）：'+title;note='历史数值未重跑，不是本次真实模型结果。'+note
    fig.suptitle(title,fontsize=14,weight='bold',color=DARK,y=1.085)
    fig.text(.01,-.025,note,fontsize=8.3,color='#526474',va='top')
    for ext in ['png','pdf']:fig.savefig(F/(name+'.'+ext),dpi=300,bbox_inches='tight',pad_inches=.17)
    plt.close(fig);caps.append(dict(file=name+'.png',title=title,caption=note,historical_proxy=historical))

def flow():
    fig,a=plt.subplots(figsize=(12,5.7),layout='constrained');a.axis('off');a.set(xlim=(0,12),ylim=(0,6))
    boxes=[(.15,4,3.5,1.5,'冻结校准资料','四年第一阶段16组，第二阶段4组\n2022正式链2000×32×3已核验',C[2019]),
           (4.15,4,3.5,1.5,'中心点与参数组','32个中心值均可追溯\n条件分布，不是八维联合后验',C[2021]),
           (8.15,4,3.5,1.5,'Sobol与确定性优化','全局独立范围，固定中心点双目标\n真实Modified DI执行代码仍缺',RED),
           (.15,1.3,5.4,1.8,'本轮已更新','补入58,784行真实阶段二样本\n区间、相关、水量账和配置已更新\n2步smoke不进入统计',C[2022]),
           (6.15,1.3,5.5,1.8,'仍需真实模型执行','N128×3 seeds；100代×5 seeds\n候选真实回代及分组条件扰动\n不恢复2021旧38%节水结论',C[2020])]
    for x,y,w,h,title,body,col in boxes:
        a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.08',facecolor=col+'10',edgecolor=col,lw=1.2))
        a.text(x+.13,y+h-.2,title,va='top',fontsize=12,weight='bold',color=col)
        a.text(x+.13,y+h-.65,body,va='top',fontsize=9.3,color=DARK,linespacing=1.65)
    for x in [3.7,7.7]:a.annotate('',xy=(x+.4,4.7),xytext=(x,4.7),arrowprops=dict(arrowstyle='->',color=DARK,lw=1.5))
    save(fig,'F01_evidence_chain','2026-10-17研究证据与执行状态','原MCMC未重跑。新包提供衔接脚本与条件链，不包含其导入的原DI_2022_MCMC_ONE_CLICK.py；因此未产生正式真实模型Sobol或优化结果。')

def intervals_and_centers():
    d=table('parameter_intervals_verified')
    fig,axes=plt.subplots(2,4,figsize=(14,7),layout='constrained')
    for a,k in zip(axes.flat,NAMES):
        for r in d[d.Parameter==k].itertuples():
            j=YEARS.index(r.Year)
            a.errorbar(j,r.Median,yerr=[[r.Median-r.P025],[r.P975-r.Median]],fmt='o',c=C[r.Year],capsize=3,lw=2)
            a.hlines([r.Prior_low,r.Prior_high],j-.22,j+.22,color='#A0ACB6',ls=':',lw=.9)
        a.set(title=k,xticks=range(4),xticklabels=YEARS,xlim=(-.5,3.5));a.grid(axis='y',alpha=.5)
    save(fig,'F04_parameter_intervals','四年八参数区间：2022第二阶段已由真实链补齐','点为中位数，线为2.5%—97.5%相关保留样本分位；灰短线为各年链支持。单组阶段二为条件分布，不是认证收敛或联合后验。')
    center=table('central_vectors_with_provenance')
    fig,axes=plt.subplots(2,4,figsize=(14,6.6),layout='constrained')
    for a,k in zip(axes.flat,NAMES):
        a.plot(range(4),center[k],c='#9CAAB5',ls='--',lw=1.2)
        for i,year in enumerate(YEARS):a.scatter(i,center.loc[center.Year==year,k].iloc[0],s=52,c=C[year],zorder=4)
        a.set(title=k,xticks=range(4),xticklabels=YEARS);a.grid(axis='y',alpha=.4)
    save(fig,'U01_central_parameters','32个年度中心值：两阶段保留均值均已交叉核验','中心点数值未因本次补件改变。2022三个阶段二参数从“文档报告值”升级为“原检查点已核验”；连线只作年度比较。')

def compensation_and_trace():
    with np.load(ART/'verified_phase_specific_draws.npz',allow_pickle=False) as z:draws={y:z[f'p2_{y}'] for y in YEARS}
    fig,axes=plt.subplots(2,2,figsize=(10,8),layout='constrained')
    for a,y in zip(axes.flat,YEARS):
        p=draws[y];a.hexbin(p[:,2],p[:,1],gridsize=40,mincnt=1,cmap='Blues',rasterized=True)
        a.set(xlabel='HI0',ylabel='WP_late',title=f'{y} · r={np.corrcoef(p[:,2],p[:,1])[0,1]:.3f}')
    save(fig,'F05_phase2_compensation','四年第二阶段：WP_late与HI0的参数补偿','各图取同一年度真实阶段二的整行保留样本。2022相关系数约−0.645；阶段内相关已保留，不将不同阶段样本拼成八维联合后验。')
    source=ROOT/'DI_2022_Phase2/phase2_conditional_results/checkpoints/biomass_yield/ensemble_1.npz'
    with np.load(source,allow_pickle=False) as z:h=z['history']
    fig,axes=plt.subplots(3,2,figsize=(11.5,8),layout='constrained')
    for j,name in enumerate(NAMES[5:]):
        a,b=axes[j];a.plot(h[:,:,j],c=C[2022],alpha=.12,lw=.55);a.axvline(163,c=RED,ls='--',lw=1)
        a.set(ylabel=name,xlabel='step',title='32个耦合walker轨迹' if j==0 else '')
        x=h[163:,:,j].ravel();b.hist(x,bins=55,density=True,color=C[2022],alpha=.8)
        b.axvline(x.mean(),c=RED,lw=1.3,ls='--');b.set(xlabel=name,ylabel='density',title='58,784行保留样本' if j==0 else '')
    save(fig,'F15_2022_phase2_chain','2022正式第二阶段链：预热段163步，保留1,837步/每walker','仅使用正式2000步检查点，2步smoke排除。5τ截断与τ长度参考不是独立多链收敛认证；未把32个walker当作32条独立链计算Rhat。')

def water():
    w=table('water_balance_recomputed');w=w[w.Scenario=='DI']
    fig,axes=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
    for i,r in enumerate(w.itertuples()):
        for shift,parts in [(-.18,[(r.Irrigation_mm,C[2019],'灌溉'),(r.Rain_mm,'#97C3CF','降水'),(max(-r.Storage_gain_mm,0),'#D8B375','储水消耗')]),
                            (.18,[(r.ET_mm,C[2021],'ET'),(r.Runoff_mm,'#A7B2BB','径流'),(max(r.Storage_gain_mm,0),C[2022],'储水增加')])]:
            bottom=0
            for value,col,label in parts:axes[0].bar(i+shift,value,.31,bottom=bottom,color=col,label=label if i==0 else None);bottom+=value
        axes[0].text(i,850,f'ΔS {r.Storage_gain_mm:+.1f}',ha='center',fontsize=8)
    axes[0].set(xticks=range(4),xticklabels=YEARS,ylabel='seasonal water / mm',ylim=(0,920),title='四年DI：入流、出流与储水变化');axes[0].legend(ncol=2,fontsize=7)
    s=table('surrogate_audit');s=s[s.Year<2022]
    axes[1].bar(range(3),s.Overflow_mm,color=[C[y] for y in s.Year],width=.55)
    axes[1].set(xticks=range(3),xticklabels=s.Year,ylabel='unreported proxy overflow / mm',title='历史代理诊断：未报告溢出通量',ylim=(0,240))
    for a in axes:a.grid(axis='y',alpha=.3);a.set_axisbelow(True)
    save(fig,'F06_water_ledger','四年原模型季节水量账与历史代理缺口分开报告','2022由新增conditional_mean_model.json核算：储水消耗40.58mm，残差约10^-12mm；不代表已重新运行原模型。右侧历史代理数值未重跑。')

def calibration():
    fit=table('calibration_evidence_tiers')
    fig,axes=plt.subplots(1,3,figsize=(13,4.3),layout='constrained')
    for i,row in enumerate(fit.itertuples(index=False,name=None)):
        r=fit.iloc[i];year=int(r['年份'])
        for a,key in [(axes[0],'CC_RMSE'),(axes[1],'生物量_RMSE')]:a.bar(i,r[key],color=C[year],width=.55)
        axes[2].bar(i,r['产量误差_pct'],color=C[year],width=.55)
    for a,title,unit in zip(axes,['CC校准误差','生物量校准误差','产量相对观测偏差'],['RMSE / fraction','RMSE / (t/ha)','relative error / %']):
        a.set(title=title,ylabel=unit,xticks=range(4),xticklabels=YEARS);a.grid(axis='y',alpha=.3);a.set_axisbelow(True)
    axes[2].axhline(0,c=DARK,lw=.7)
    for v in [-5,5]:axes[2].axhline(v,c=RED,ls='--',lw=1)
    save(fig,'F02_calibration_summary','四年校准汇总：2022已补精确均值点模拟输出','2019—2021配对指标沿用原核验；2022 RMSE和产量来自新增模型汇总JSON，未收到其逐日配对表，不能扩写为独立验证。')
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for i,r in fit.iterrows():
        year=int(r['年份'])
        for key,marker in [('CC_R2','o'),('生物量_R2','s')]:axes[0].scatter(i,r[key],marker=marker,s=60,facecolor='white' if year==2022 else C[year],edgecolor=C[year],lw=1.4)
        axes[1].bar(i,r['产量误差_pct'],color=C[year],width=.55)
    axes[0].set(ylabel='R²',title='圆点CC；方点生物量；2022 R²仍为文档值',ylim=(.9,1.01))
    axes[1].set(ylabel='relative yield error / %',title='2022精确产量偏差约−0.0157%',ylim=(-6,6))
    for v in [-5,5]:axes[1].axhline(v,c=RED,ls='--',lw=1)
    for a in axes:a.set(xticks=range(4),xticklabels=YEARS);a.grid(axis='y',alpha=.3)
    save(fig,'U04_calibration_scope','原链已补齐，配对序列证据仍需分别标注','2022空心R²仍为原Word中的汇总值，未从配对表重算；产量偏差与RMSE已更新为新JSON精确值。±5%为项目容许幅度。')

def sampling_and_field():
    d=table('sampling_group_summary')
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for phase,dx,col in [(1,-.17,C[2019]),(2,.17,C[2021])]:
        s=d[d.Phase==phase].sort_values('Year');bars=axes[0].bar(np.arange(4)+dx,s.Retained_steps_per_walker,.3,color=col,label=f'phase {phase}')
        for b,v in zip(bars,s.Retained_steps_per_walker):axes[0].text(b.get_x()+b.get_width()/2,v+10,str(v),ha='center',fontsize=8)
        axes[1].plot(range(4),s.Steps_over_group_tau,'o-',c=col,label=f'phase {phase}')
    axes[0].set(ylabel='retained steps / walker',title='四年8个参数组：原链均已提供',ylim=(0,2050))
    axes[1].axhline(50,c=RED,ls='--',label='50τ length reference');axes[1].set(ylabel='2000 / max τ',title='链长参考与推断认证分开',ylim=(0,75))
    for a in axes:a.set(xticks=range(4),xticklabels=YEARS);a.legend(fontsize=8);a.grid(axis='y',alpha=.3)
    save(fig,'U02_sampling_record','2022阶段二已核验：burn=163，保留58,784行相关样本','不把相关样本行数当独立ESS，不把一个ensemble的32个walker当独立链。MCMC仍作为冻结输入，不因本次补件重跑。')
    inputs=PROJECT/'frozen_inputs/inputs';field=pd.read_csv(inputs/'DI_2019_2022_FIELD_LAI_CC_LOCKED.csv');field.Date=pd.to_datetime(field.Date)
    climate=table('climate_audit').set_index('Year')
    fig,axes=plt.subplots(2,2,figsize=(12,7),layout='constrained')
    for a,year in zip(axes.flat,YEARS):
        start=pd.Timestamp(climate.loc[year,'Start']);end=pd.Timestamp(climate.loc[year,'End'])
        f=field[field.Year==year];rs=pd.read_csv(inputs/f'Maize-{year}-RS_NDVI.csv');rs.date=pd.to_datetime(rs.date);rs=rs[rs.date.between(start,end)]
        a.plot((f.Date-start).dt.days,f.Field_CC,'o-',c=C[year],label='DI field LAI-derived CC')
        a.plot((rs.date-start).dt.days,rs.CCquad/100,'s--',c='#91A0AC',label='RS auxiliary CCquad')
        a.set(title=f'{year} · RS '+('BI' if year<2022 else 'treatment missing'),xlabel='days from simulation start',ylabel='CC fraction',ylim=(0,1.08));a.grid(axis='y',alpha=.3)
    axes[0,0].legend(fontsize=8)
    save(fig,'U03_CC_evidence','CC证据角色未改变：校准资料与RS辅助时序','RS不进入似然，但处理不同/未知，不是DI外部独立验证。2022补阶段二不会改变这项数据边界。')

def headroom_and_domains():
    water=table('water_balance_recomputed');water=water[water.Scenario=='DI'];obs={2019:16.55,2020:17.29,2021:15.86,2022:14.08};rows=[]
    for r in water.itertuples():
        gate=.95*obs[r.Year]
        rows.append(dict(Year=r.Year,Observed_Y13_t_ha=obs[r.Year],Original_model_baseline_Y13_t_ha=r.Y_13pct,
            Absolute_95pct_gate_t_ha=gate,Remaining_loss_allowed_t_ha=r.Y_13pct-gate,
            Remaining_loss_allowed_pct_of_model_baseline=100*(1-gate/r.Y_13pct),
            Baseline_bias_pct_vs_observed=100*(r.Y_13pct/obs[r.Year]-1),Baseline_Irrigation_mm=r.Irrigation_mm,
            Role='provided original-model mean-point output; no new simulation'))
    d=pd.DataFrame(rows);d.to_csv(T/'observed_yield_gate_headroom.csv',index=False,encoding='utf-8-sig')
    fig,axes=plt.subplots(1,2,figsize=(12,4.8),layout='constrained',width_ratios=[1.4,1])
    for i,r in enumerate(d.itertuples()):
        a,b=r.Absolute_95pct_gate_t_ha,r.Original_model_baseline_Y13_t_ha
        axes[0].plot([a,b],[i,i],c=C[r.Year],lw=10,alpha=.2,solid_capstyle='round')
        axes[0].scatter(a,i,marker='|',s=200,c=C[r.Year],lw=2);axes[0].scatter(b,i,c=C[r.Year],s=60)
        axes[0].scatter(r.Observed_Y13_t_ha,i,marker='D',facecolor='white',edgecolor=C[r.Year],s=40)
        axes[0].text(a,i+.15,f'{a:.3f}',ha='center',fontsize=8,color=C[r.Year]);axes[0].text(b,i-.16,f'{b:.3f}',ha='center',fontsize=8,color=C[r.Year])
        v=r.Remaining_loss_allowed_pct_of_model_baseline;axes[1].bar(i,v,color=C[r.Year],width=.55);axes[1].text(i,v+.15,f'{v:.2f}%',ha='center',color=C[r.Year],weight='bold')
    axes[0].set(yticks=range(4),yticklabels=YEARS,xlabel='Y13 / (t/ha)',title='圆点：模型基准；空心菱形：文献观测',ylim=(-.5,3.5));axes[0].invert_yaxis();axes[0].grid(axis='x',alpha=.3)
    axes[1].set(xticks=range(4),xticklabels=YEARS,ylabel='remaining yield loss / % of model baseline',title='Y ≥ 0.95 × 文献观测产量',ylim=(0,7));axes[1].grid(axis='y',alpha=.3);axes[1].set_axisbelow(True)
    save(fig,'E02_yield_gate_headroom','四年保产门槛余量：2022基准现已可核算','2022真实均值点产量14.077783 t/ha；允许减产约4.985%。2021仍仅约0.856%。这些是产量空间余量，不是节水率或置信区间。')
    bd=pd.read_csv('/workspace/urp_execution_20261016/tables/annual_sampling_domains.csv')
    fig,axes=plt.subplots(1,3,figsize=(12,4),layout='constrained')
    for a,name in zip(axes,['WP_early','WP_late','HI0']):
        common=[10,40] if name!='HI0' else [.35,.6]
        a.axvspan(*common,color='#E7EDF1',label='formal global range')
        for i,r in enumerate(bd[bd.Parameter==name].sort_values('Year').itertuples()):
            a.plot([r.Low,r.High],[i,i],c=C[r.Year],lw=6,solid_capstyle='round')
        a.set(title=name,yticks=range(4),yticklabels=YEARS,xlabel='parameter value',ylim=(-.5,3.5));a.invert_yaxis()
    save(fig,'E01_annual_supports','链支持范围与正式全局Sobol范围是不同对象','彩线为各年链支持；灰底为按指导文件预声明的公共全局范围。本版本正式Sobol使用公共独立均匀范围，不以2022较窄链支持替换主分析空间。')

def main():
    # Old figure F02 contains a superseded missing-data footer. Keep its original in git history, not in current figures.
    for ext in ['png','pdf']:(F/f'F02_calibration_trajectories.{ext}').unlink(missing_ok=True)
    g.save=save
    flow();g.diagnostic();intervals_and_centers();compensation_and_trace();water();calibration();sampling_and_field();headroom_and_domains()
    for fn in [g.sobol_figures,g.original_pareto,g.schedule_fig,g.optimization_figs,g.transfer_figure]:fn()
    # Retain the climate panel: its raw-input distinction is still valid and no new climate was supplied.
    original=json.loads((ART/'figure_captions.json').read_text())
    caps.extend([x for x in original if x['file'].startswith('F14_')])
    # Reuse the current flow under the paper's legacy U05 name without changing the underlying image.
    import shutil
    for ext in ['png','pdf']:shutil.copyfile(F/f'F01_evidence_chain.{ext}',F/f'U05_revised_workflow.{ext}')
    caps.append(dict(file='U05_revised_workflow.png',title='更新后的确定性主线与资料状态',caption='2022正式阶段二链已补齐；真实模型原实现仍缺，未运行正式Sobol/NSGA-III。',historical_proxy=False))
    (ART/'figure_captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
    thumbs=[]
    for row in caps:
        im=Image.open(F/row['file']).convert('RGB');im.thumbnail((600,380))
        tile=Image.new('RGB',(630,420),'white');tile.paste(im,((630-im.width)//2,10));ImageDraw.Draw(tile).text((10,400),row['file'],fill=DARK);thumbs.append(tile)
    sheet=Image.new('RGB',(630*3,420*((len(thumbs)+2)//3)),'#EAF0F3')
    for i,im in enumerate(thumbs):sheet.paste(im,((i%3)*630,(i//3)*420))
    sheet.save(ROOT/'figure_contact_sheet.jpg',quality=90)
    print('Rendered current and clearly labeled historical figure pairs:',len(caps))

if __name__=='__main__':main()
