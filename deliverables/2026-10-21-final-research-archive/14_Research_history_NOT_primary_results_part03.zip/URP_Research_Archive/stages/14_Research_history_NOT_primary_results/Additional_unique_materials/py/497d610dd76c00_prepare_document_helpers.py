"""Make the preparation bundle's document/input rebuild helpers portable."""
from pathlib import Path
import inspect,sys
P=Path('/workspace/urp_execution_20261016')
sys.path.insert(0,'/workspace/urp_review/src')
import make_documents as original
header='''from pathlib import Path
import re,subprocess
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image as RLImage,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from PIL import Image
OUT=Path(__file__).resolve().parent
'''
(P/'document_renderer.py').write_text(header+inspect.getsource(original.pdf_report).replace('2026-10-15','2026-10-17')+'\n'+inspect.getsource(original.word_report),encoding='utf-8')
(P/'build_documents.py').write_text('''"""Render the delivered current Markdown and referenced scientific figures."""
from pathlib import Path
import document_renderer as renderer
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    for name in ['paper_framework_execution_ready','review_update_20261017']:
        text=(ROOT/(name+'.md')).read_text(encoding='utf-8')
        renderer.pdf_report(text,ROOT/(name+'.pdf'))
        renderer.word_report(name+'.md')
    print('Rendered current Word/PDF from included Markdown and figures.')
''',encoding='utf-8')
(P/'build_inputs.py').write_text('''"""Check the delivered exact 2022 baseline and generate a fresh global design."""
import argparse
from pathlib import Path
import numpy as np
import real_model_pipeline as pipeline
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--n',type=int,default=128)
    args=parser.parse_args()
    case=pipeline.read(ROOT/'study_config.json')['cases']['2022']
    model=pipeline.read(ROOT/'source_data/conditional_mean_model.json')
    for name,value in case['central_params'].items():
        assert np.isclose(value,model['values'][name],atol=1e-9,rtol=0)
    for name,value in case['baseline_expected'].items():
        key='B_last' if name=='B_t_ha' else name
        assert np.isclose(value,model['DI'][key],atol=1e-9,rtol=0)
    result=pipeline.prepare(ROOT/'study_config.json',args.out,n=args.n)
    print(result['status'],result['total_model_calls_required'])
''',encoding='utf-8')
print('Portable input and document helpers written.')
