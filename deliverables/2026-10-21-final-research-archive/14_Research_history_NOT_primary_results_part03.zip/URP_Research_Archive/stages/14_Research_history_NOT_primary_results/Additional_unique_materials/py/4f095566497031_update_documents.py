"""Rebuild all current Word/PDF reports from the integrated evidence tables."""
from pathlib import Path
import os,sys,json,inspect,shutil,base64,html
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('XDG_CACHE_HOME',str(ROOT/'.cache'))
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
sys.path.insert(0,'/workspace/urp_review/src')
import make_documents as render
import numpy as np
import pandas as pd

ART=Path('/workspace/urp_review/artifacts');T=ART/'tables';F=ART/'figures'
REV=Path('/workspace/urp_followup_20261016/revision')
PREP=Path('/workspace/urp_execution_20261016')
REPO=Path('/workspace/URP');PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED'
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def tb(n):return pd.read_csv(T/(n+'.csv'))
def mt(d):return render.mdtable(d)
CAP=rd(ART/'figure_captions.json')
def fig(prefix):
    row=next(r for r in CAP if r['file'].startswith(prefix+'_'))
    return f"\n![{row['title']}](figures/{row['file']})\n\n图注：{row['caption']}\n"

def build_text():
    audit=rd(ROOT/'PHASE2_2022_VALIDATION.json');post=tb('phase2_2022_parameter_summary')
    params=post[['Parameter','N','Mean','SD','P025','Median','P975']].copy()
    groups=tb('sampling_group_summary')[['Year','Phase','Integer_group_burn','Retained_steps_per_walker','Retained_correlated_draws']]
    groups.columns=['年份','阶段','burn-in','每walker保留步数','相关样本行数']
    centers=tb('central_vectors_with_provenance')[['Year']+render.NAMES]
    fit=tb('calibration_evidence_tiers')
    fitmini=fit[['年份','CC_R2','CC_RMSE','生物量_R2','生物量_RMSE','观测产量','模拟产量','产量误差_pct']]
    water=tb('water_balance_recomputed');di=water[water.Scenario=='DI']
    ledger=di[['Year','Irrigation_mm','Rain_mm','Tr_mm','Es_mm','ET_mm','Storage_gain_mm']].copy()
    ledger.columns=['年份','灌溉_mm','降水_mm','Tr_mm','Es_mm','ET_mm','储水增加_mm']
    head=tb('observed_yield_gate_headroom')[['Year','Observed_Y13_t_ha','Original_model_baseline_Y13_t_ha','Absolute_95pct_gate_t_ha','Remaining_loss_allowed_pct_of_model_baseline']].copy()
    head.columns=['年份','文献观测','模型基准','95%绝对门槛','可减产余量_pct']
    finding=tb('findings_and_actions')
    status={
        'A01':('已补齐当前真链','本轮接入真实2000×32×3检查点，旧1500行构造值仅保留在历史代理记录，不能混入当前数据'),
        'A04':('诊断限制保留','MCMC作为冻结输入；严格诊断置于补充说明，不作为确定性主流程新增门槛，不声称认证收敛'),
        'A05':('主线按指导已调整','年度均值用于确定性分析；两个参数组分别扰动，未构造八维联合后验'),
        'A08':('改为候选后核验','主优化固定中心点；候选分组条件核验概率、低分位和MC误差，不以均值冒充可靠性'),
        'A09':('代码已调整，真实运行待接入','候选每个可用参数组至少128整行样本，2022两个组现均可读取'),
        'A10':('正式定义已修正','公共全局独立均匀范围；local95仅为可选邻域响应，不称后验Sobol'),
        'A11':('当前代码已移除CAI','保留S1、ST、区间、均值、方差与单位，不推断信息吸收率'),
        'A14':('代码已调整，真实运行待接入','100种群/方向、100代、5种子，与同预算NSGA-II比较，每代保存X/F/G/CV'),
        'A19':('当前代码已修正','ε门槛内最低水量及两个邻近备选；无可行解时不输出推荐'),
        'A20':('当前数据按年分组','统一文件有8个年度/阶段数组；新增2022真链，不跨年按样本数混成共同后验')}
    finding['Current_status']='历史诊断仍适用，正式结果需真实模型核验'
    for key,(label,action) in status.items():
        finding.loc[finding.ID==key,'Current_status']=label
        finding.loc[finding.ID==key,'Action']=action
    finding.to_csv(T/'findings_and_actions.csv',index=False,encoding='utf-8-sig')
    report=f'''# URP六包更新与2022第二阶段核验报告
版本：2026-10-17。新增原件：DI_2022_Phase2.zip。更新对象：此前六个GitHub交付压缩包及对应代码、论文、图表。

## 1 本轮结论与范围
2022第二阶段真实检查点已补齐并通过数组、状态、元数据与摘要交叉核验。四年现在有16组阶段一和4组阶段二原链记录；当前统一保留样本文件从7个数组扩为8个。原有7个数组逐值不变，新加入p2_2022为58784×3。
32个年度中心参数均可追溯到原链保留均值，2022三个阶段二中心值与上版文档值一致，因此确定性中心点没有改动；新增的是可核验的分布、相关结构和精确模型汇总。
没有重新运行MCMC，也没有执行正式真实模型Sobol或NSGA-III。新包内的9KB一键脚本明确依赖外部DI_2022_MCMC_ONE_CLICK.py与原data目录；这些原实现仍未交付。本轮不把衔接脚本误当完整模型。

## 2 正式链核验
仅使用phase2_conditional_results/checkpoints/biomass_yield/ensemble_1.npz。phase2_smoke中的2步检查点排除出统计；上传原ZIP原样保留，方便审计。
形状2000×32×3，history与logs均为有限值，position/logp与链末状态一致。accepted数组的平均接受率为{audit['acceptance']:.6f}。四份阶段一检查点的哈希引用与既有核验表一致，固定点与阶段一保留均值逐值相同，包装脚本哈希与contract.wrapper_sha256相符。
积分自相关时间依次为{audit['tau'][0]:.6f}、{audit['tau'][1]:.6f}、{audit['tau'][2]:.6f}；统一burn=ceil(5×maxτ)=163。每walker保留1837步，32×1837=58784行相关样本。2000/maxτ约61.387，满足包内50τ长度参考，但不等于独立多链收敛认证。
{mt(params)}
均值、样本标准差及2.5%/50%/97.5%分位均与新增JSON在数值容差内一致，所有保留参数在各自声明支持内。单ensemble不计算把32个耦合walker当独立链的Rhat；源状态仍为SAMPLING_COMPLETE_REVIEW_REQUIRED，Inference_validated=false。
{fig('F15')}

## 3 模型汇总与水量核算
新增conditional_mean_model.json给出均值参数点的DI和零灌溉输出，不是后验预测均值。本轮重新核对Y_dry=0.87Y13、ET=Tr+Es、完整土壤/地表储水与通量账，未重跑原模拟器。
DI产量为14.0777828181 t/ha，相对文献14.08的误差约−0.01575%；灌水404.84mm，Tr=529.939343mm，Es=66.845293mm，ET=596.784636mm，储水消耗40.582409mm。IWP=100Y/I=3.477370 kg/m³。
零灌溉产量为5.8495800962 t/ha，相对DI损失58.4481%，仍是未经同地实测验证的反事实。季节量账重算残差均约10^-12mm。
2022 CC_RMSE=0.0595741682、生物量RMSE=0.5561588827来自本次JSON；缺少对应逐日及配对表，因此R²=0.931/0.997仍按先前Word报告值标注，不升级为本轮配对复算。
{mt(ledger)}

## 4 六个包同步更新内容
完整报告包：四年参数统计、20组检查点清单、更新论文/审查报告/工作簿/图册、当前工程和原始补件。
运行结果包：新增真实阶段二保留样本、核验日志/表、相关图与当前状态。上版36组Sobol和9次优化仍标为2026-10-15历史代理探索，没有冒充新运行。
图件包：补齐四年区间、阶段二相关、水量与门槛，新增2022轨迹/分布图；历史代理图均有显式历史标题。
新增材料复核包：32个中心值均核验、8组参数组均可追溯；论文/采样表不再写2022原链缺失。
计算准备包：2022基准从四舍五入报告值改为精确JSON，四年全局公共范围设计重新生成并绑定新配置哈希。
Sobol与优化工程包：统一样本新增p2_2022，local95和128组阶段二条件扰动已可读取，新增回归测试；主分析继续遵照三份指导文件，不改为年度链范围默认采样。

## 5 当前研究方案与保留边界
MCMC保持冻结的分阶段条件推断。主Sobol为预声明公共物理范围内独立均匀输入，N128×3个scramble、不算二阶，必要时升N512，报告六输出的S1/ST/区间/均值/方差/单位。local95是可选邻域响应，不叫后验Sobol，不计算CAI。
主优化固定年度中心点，min(-Y13,I)，I≤年度DI基准且Y13≥0.95×文献观测。优先真实SMT1—4；否则4—5阶段水量和明确日期窗口。100方向/种群、100代、5种子，默认同预算NSGA-II对照；候选以ε约束选解，回代并分别用两个参数组至少128行扰动核验。
{mt(head)}
2021产量余量仍仅0.8563%，2022约4.9850%，这些不是节水率。真实模型前沿、最终节水与可执行日程仍没有新计算证据，不能恢复旧2021约38%结论。
旧代理图和CSV只保留历史审计用途；真实2022链补齐不会把原代理的1500个人造输入、旧阈值或旧结果追溯性地变成真实模型分析。

## 6 历史问题的当前状态
{mt(finding[['ID','Finding','Current_status','Action']])}

## 7 版本与复现
原补件ZIP和正式检查点的SHA256、tau、截断、源哈希衔接、旧数组逐值不变性见PHASE2_2022_VALIDATION.json；六个ZIP各自重新计算完整性与文件清单。原分支历史保留旧版，主分支不变。
原模型版本来自检查点contract；本轮分析环境另记ANALYSIS_ENVIRONMENT.json，不能把当前分析环境说成已经精确恢复了原采样环境。各类检查点、软件测试、模型运行和外部验证状态分别记录。
'''
    paper=f'''# 滴灌玉米改进AquaCrop的分阶段校准、全局范围敏感性与确定性灌溉优化
## 论文框架与数据插图更新稿（2026-10-17）
本稿已纳入2022真实第二阶段链及精确均值点输出。MCMC作为冻结输入；正式真实模型Sobol、NSGA-III及最终田间管理结论仍待原模型执行，不提前填写指数或节水幅度。

## 摘要草稿
本研究整理2019—2022年DI玉米气象、冠层、生物量、产量与土壤初始水资料，采用分组分阶段校准，并以年度参数中心点构建独立范围敏感性与确定性灌溉决策框架。现有配对资料支持2019—2021样本内校准评价；2022新补真实条件链包含2000步、32个walker，按5τ统一截断后保留58784行三参数样本，所报告均值和分位可由原始数组重建。四年32个中心值均已交叉核验，季节水量账内部闭合。后续拟在冻结Modified DI模型中开展公共独立均匀范围Sobol和受约束双目标NSGA-III，再单列候选的组内条件扰动。当前证据支持校准重现与数值一致性，正式敏感性排序、节水潜力与推广性须由真实模型新运行检验。
关键词：亏缺灌溉玉米；改进AquaCrop；分阶段条件校准；Sobol；NSGA-III。

## 1 引言与研究问题
研究问题是如何把可解释的作物水分过程校准用于受供水和产量限制的灌溉决策。工具组合本身不构成创新；需要明确新的过程认识或可执行决策依据。
RQ1：既有资料支持哪些样本内过程重现与参数补偿结论？RQ2：在预声明独立物理范围中，哪些参数贡献输出方差？RQ3：固定年度中心点时，满足水量和观测产量门槛的非支配制度是什么？补充问题是这些候选对分组条件参数扰动是否稳定。
研究区坐标、原始田间设计、重复数及测量误差应从原资料补齐，不凭结果图推断试验细节。
{fig('U05')}

## 2 数据、来源与证据角色
| 数据 | 用途 | 范围与限定 |
| --- | --- | --- |
| Field LAI-derived CC | 阶段一校准 | 论文数字化LAI再转换，非本次新增田间观测 |
| RS CCquad | 未进入似然的辅助时序 | 2019—2021为BI、2022处理标签缺失，不称DI外部验证 |
| Tr与Es | 阶段一过程约束 | 保留Es近似目标和数字化误差限定 |
| Biomass与年Yield | 阶段二条件校准 | 生物量与产量不是独立验证；产量为13%含水率 |
| ET | Tr+Es的派生核对 | 不重复作为独立似然信息计权 |
| 气象、土壤与灌溉 | 模型驱动/管理基准 | 纠偏、分层初始水和部分假定分次日程均须追溯 |
{fig('U03')}

## 3 冻结模型与年度中心点
真实Modified DI保留actual CC蒸发、真实MulchPct、两阶段WP和年度HI0。原实现在当前材料中仍缺；新的一键脚本通过外部原项目加载模型，不能独立替代原源码。先对齐原基准点和随机管理点，再开展正式敏感性及优化。
阶段一θ1=(CCx,CGC_CD,CDC_CD,SenescenceCD,Kcb)，阶段二θ2=(WP_early,WP_late,HI0)条件于阶段一均值。两组均值拼接是确定性中心输入，不是八维联合后验样本。
{mt(centers)}
{fig('U01')}
四年第一阶段各4独立ensemble，阶段二各1个。每组32 walkers、2000步，burn=ceil(5×整组最大τ)，同组参数共用整数截断。
{mt(groups)}
2022阶段二均值及区间现已由正式原链核验。源状态为SAMPLING_COMPLETE_REVIEW_REQUIRED；操作性完成不等于已认证严格收敛。原严格Rhat/ESS限制保留为补充诊断，不把耦合walker当独立链，也不为确定性下游流程新增联合后验要求。

## 4 Sobol：公共全局范围的真实模型响应实验
主分析采用公共预声明物理范围内相互独立的均匀分布。该设计回答指定范围下的方差贡献，既不是原MCMC先验密度，也不是条件后验传播；不同年度链支持只作参数结果解释，不自动替换主分析空间。
| 参数 | 全局公共范围 | 说明 |
| --- | --- | --- |
| CCx | 0.60—0.99 | 冠层上限 |
| CGC_CD | 0.08—0.16 | 日历日增长参数 |
| CDC_CD | 0.03—0.12 | 日历日衰减参数 |
| SenescenceCD | 115—145 | 衰老时序 |
| Kcb | 1.05—1.60 | 基础作物系数 |
| WP_early | 10—40 | 模型定义的前期归一化水分生产力 |
| WP_late | 10—40 | 模型定义的后期归一化水分生产力 |
| HI0 | 0.35—0.60 | 参考收获指数 |
范围沿用指导文件及既有工程的公共物理范围，投稿时仍需补农艺/文献依据。local95采用各年度真实保留样本的2.5%—97.5%边际范围，现2022也可读取，但仅叫邻域响应，不叫后验Sobol，不计算CAI。
先N=128、种子101/202/303，不算二阶时每年每种子N(D+2)=1280次；四年共15360次。若排名或区间不稳则升N=512，共61440次完整设计调用。六输出为Y13、Biomass、Tr、Es、ET、MaxCC。
主报告ST，同时报告S1、ST−S1、bootstrap区间、均值、方差、单位及Var(Y)×ST。不裁剪估计、不强制Kcb第一；常量输出标为归一化指数未定义。逐年比较，只有方向和区间足以支持时才称跨年稳健关键参数。
保存输入空间、哈希、种子、矩阵、每点响应、失败与状态；失败点不能删行或填零。**正式真实模型的指数及排名尚未计算，不从历史代理图填入。**

## 5 确定性双目标优化与候选条件核验
固定年度中心参数，min(-Y13,I)。优先真实模块的SMT1—SMT4、0—100%，核对百分比定义、根区、触发方向和窗口；不支持时采用4—5阶段水量与明确日期，两种体系不混合解释。
硬约束为I≤年度DI基准、Y13≥0.95×文献观测产量；同步报告相对同模型基准变化，检查非负水量、事件日期和完整水量账。IWP=100Y[t/ha]/I[mm]，单位kg/m³。
{mt(head)}
{fig('E02')}
2021的模型基准已低估观测约4.18%，因此继续相对模型基准再容许5%减产会放宽真实门槛。2022新精确基准距门槛余量约4.985%，这不是节水率。
NSGA-III采用100个双目标参考方向/种群、100代、5算法种子；默认与同预算NSGA-II比较，按年固定HV参考尺度。保存每代X/F/G/CV、目标、约束和前沿，不因结果不理想而只保留单次运行。
推荐为ε门槛内最低灌水量，并列两个相邻可行备选；无可行解则明确无推荐，不回退最高产量。最终候选必须以同一真实模型回代，不能用绘图插值得到新可行点。
候选分别扰动阶段一/固定阶段二中心、扰动阶段二整行样本/固定阶段一中心，每个可用组至少128行，保留组内相关；2022两个组现均有真实样本。报告均值、5%分位、绝对观测门槛概率、MC误差、灌水/通量/守恒。这是声明分布下的条件核验，不是八维联合传播或田间失收概率。
年度专用方案可逐年优化；若要声称未知年通用制度，需留一年/嵌套检验，不用同四年同时选解和验证。**真实前沿、节水率和推荐日程尚未生成；旧2021约38%仍撤回。**

## 6 现阶段可写入论文的结果
### 6.1 校准指标与证据分层
{mt(fitmini)}
2019—2021的配对评价沿用此前独立复算。2022 RMSE和产量现有精确JSON支持；R²=0.931/0.997仍为Word汇总值，缺少配对序列，不能声称本轮逐点重算。年产量每年一对，不计算单年产量相关系数。±5%是项目容许幅度，不是统计置信带。
{fig('U04')}
### 6.2 参数区间与补偿
{fig('F04')}
{fig('F05')}
2022的WP_late—HI0相关约−0.645，说明阶段二组内仍有补偿结构。该关系来自同一行真实样本，不应通过边际独立重抽打散；也不能凭较窄区间证明因果识别或完整联合后验收敛。
### 6.3 新增真实链及水量账
{fig('F15')}
{mt(ledger)}
{fig('F06')}
四年季节水量残差约10^-12mm是内部守恒证据，不替代真实通量验证。2021储水增加约169.97mm；2022消耗40.58mm。2022零灌溉给出的约58.45%减产仍为未验证反事实。
### 6.4 待真实模型填入的敏感性与管理结果
填写年度S1/ST与区间、输出方差、不同种子前沿和HV、算法对照、基准/候选产量及水量/IWP/储水变化、ε备选、条件概率与低分位。历史代理结果只在审计附录中注明版本和局限，不替代本节。

## 7 讨论、限制与结论边界
讨论应区分样本内校准与外部验证、公共独立范围响应与后验归因、确定性最优与可靠性，以及年度专用与未知年推广。数字化资料、部分假定灌溉、近似Es、纠偏ETo和模型结构误差应透明披露。
本轮可得结论是：四年分阶段原链和年度中心输入已具备完整的可追溯记录；2022条件分布与均值点量账得到交叉核验。正式敏感性和受约束灌溉优化在研究逻辑上不需要虚构八维联合后验，但最终数值仍须真实Modified DI执行。

## 补充材料与方法参考
提交原始/保留数组形状、20组检查点哈希、2022核验记录、参数区间与阶段内相关、严格阶段一诊断、输入空间与执行状态、软件测试及历史代理说明。原模型缺件与参考PDF未提供分别说明，不把软件测试当作作物验证。
参考方向可核对FAO Irrigation and Drainage Paper 66；Goodman与Weare（2010），DOI 10.2140/camcos.2010.5.65；Vehtari等（2021），DOI 10.1214/20-BA1221；Saltelli等（2010），DOI 10.1016/j.cpc.2009.09.018；Deb与Jain（2014），DOI 10.1109/TEVC.2013.2281535。用户参照论文目前仅有路径和哈希，具体原文引用仍待核。
'''
    return report,paper

def main():
    report,paper=build_text()
    render.OUT=ART;render.TABLES=T
    source=inspect.getsource(render.pdf_report).replace('2026-10-15','2026-10-17');exec(source,render.__dict__)
    names={'URP_合理性审查报告':report,'URP_论文框架_含数据与图':paper}
    for name,text in names.items():
        (ART/(name+'.md')).write_text(text,encoding='utf-8')
        render.pdf_report(text,ART/(name+'.pdf'));render.word_report(name+'.md')
    render.workbook()
    cards=[]
    for row in CAP:
        data=base64.b64encode((F/row['file']).read_bytes()).decode()
        cards.append(f"<article><h2>{html.escape(row['title'])}</h2><img src='data:image/png;base64,{data}'><p>{html.escape(row['caption'])}</p></article>")
    (ART/'URP_图表画册.html').write_text("<!doctype html><html lang='zh-CN'><meta charset='utf-8'><title>URP 2026-10-17</title><style>body{max-width:1200px;margin:auto;background:#eef3f6;font-family:system-ui;color:#25384a}article{background:white;margin:24px;padding:24px;border-radius:12px}img{width:100%}p{line-height:1.7}</style><h1>URP 2026-10-17：2022真实阶段二已接入</h1><p>16组阶段一＋4组阶段二；当前真链统计与历史代理图分开标注。未运行正式真实模型Sobol/NSGA-III。</p>"+''.join(cards),encoding='utf-8')
    # One current manuscript/report is synchronized into all document packages.
    for base,targets in [(REV,{'URP_20261016_复核与变更说明':report,'URP_20261016_论文框架_确定性主线':paper}),
                         (PREP,{'paper_framework_execution_ready':paper,'review_update_20261017':report})]:
        (base/'figures').mkdir(exist_ok=True)
        for r in CAP:
            for ext in ['png','pdf']:shutil.copyfile(F/(Path(r['file']).stem+'.'+ext),base/'figures'/(Path(r['file']).stem+'.'+ext))
        for old in ['U06_verified_calibration.png','U06_verified_calibration.pdf']:(base/'figures'/old).unlink(missing_ok=True)
        render.OUT=base
        for name,text in targets.items():
            (base/(name+'.md')).write_text(text,encoding='utf-8');render.pdf_report(text,base/(name+'.pdf'));render.word_report(name+'.md')
        shutil.copyfile(ART/'URP_审查与结果表.xlsx',base/('URP_20261016_复核结果表.xlsx' if base==REV else 'execution_evidence.xlsx'))
        (base/'figure_captions.json').write_text(json.dumps(CAP,ensure_ascii=False,indent=2))
    shutil.copyfile(ROOT/'PHASE2_2022_VALIDATION.json',REV/'PHASE2_2022_VALIDATION.json')
    shutil.copyfile(ROOT/'PHASE2_2022_VALIDATION.json',PREP/'PHASE2_2022_VALIDATION.json')
    for name in ['observed_yield_gate_headroom','phase2_2022_parameter_summary','phase2_2022_correlations']:
        shutil.copyfile(T/(name+'.csv'),REV/'tables'/(name+'.csv'))
        shutil.copyfile(T/(name+'.csv'),PREP/'tables'/(name+'.csv'))
    print('Current report, manuscript, workbook and gallery synchronized to all document packages.')

if __name__=='__main__':main()
