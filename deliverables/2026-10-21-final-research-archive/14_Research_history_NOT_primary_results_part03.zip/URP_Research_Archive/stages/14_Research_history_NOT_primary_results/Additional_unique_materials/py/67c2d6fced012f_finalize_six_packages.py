"""Create the six replacement ZIPs, matching their existing GitHub URLs."""
from pathlib import Path
import json,hashlib,shutil,zipfile,fnmatch,importlib.metadata
import numpy as np

ROOT=Path(__file__).resolve().parent;REPO=Path('/workspace/URP')
OLD=Path('/workspace/urp_review');ART=OLD/'artifacts';REV=Path('/workspace/urp_followup_20261016/revision');PREP=Path('/workspace/urp_execution_20261016')
PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED';STAGE=ROOT/'staged'
SKIP={'.cache','__pycache__','.git','output_revised'}
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def wr(p,x):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def copytree(src,dst):
    def ignore(base,names):return [n for n in names if n in SKIP or n.endswith('.pyc')]
    shutil.copytree(src,dst,dirs_exist_ok=True,ignore=ignore)
def manifest(folder):
    stale={'MANIFEST.json','SHA256SUMS.txt','ARCHIVE_SHA256.txt','delivery_file_manifest.json','RUN_RESULTS_MANIFEST.json'}
    for name in stale:(folder/name).unlink(missing_ok=True)
    entries=[]
    for p in sorted(folder.rglob('*')):
        if p.is_file():entries.append(dict(file=p.relative_to(folder).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
    wr(folder/'MANIFEST.json',entries)
    (folder/'SHA256SUMS.txt').write_text(''.join(e['sha256']+'  '+e['file']+'\n' for e in entries),encoding='utf-8')
    return entries
def archive(folder,path):
    entries=manifest(folder);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp.zip')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file():z.write(p,folder.name+'/'+p.relative_to(folder).as_posix())
    with zipfile.ZipFile(temp) as z:
        assert z.testzip() is None
        for e in entries:assert hashlib.sha256(z.read(folder.name+'/'+e['file'])).hexdigest()==e['sha256']
    assert temp.stat().st_size<100*1024*1024
    temp.replace(path)
    return dict(path=path.relative_to(REPO).as_posix(),bytes=path.stat().st_size,sha256=sha(path),files=len(entries)+2,CRC='PASS')

def main():
    assert rd(PROJECT/'SOFTWARE_VALIDATION.json')['passed']
    assert rd(PROJECT/'SOFTWARE_VALIDATION.json')['tests_run']==18
    assert rd(PREP/'DELIVERY_VALIDATION.json')['missing_2022_phase2_checkpoint'] is False
    if STAGE.exists():shutil.rmtree(STAGE)
    STAGE.mkdir(exist_ok=True)
    # Updated engineering package and public code are byte-identical.
    manifest(PROJECT)
    eng=STAGE/'DI_PHASE3_NEXTGEN_UPDATED';copytree(PROJECT,eng)
    # Comprehensive report: current outputs and formal code; historical proxy code is quarantined.
    full=STAGE/'URP_review';copytree(ART,full/'artifacts')
    for p in (full/'artifacts').glob('*.log'):
        (full/'history_20261015/logs').mkdir(parents=True,exist_ok=True);shutil.move(str(p),full/'history_20261015/logs'/p.name)
    copytree(PROJECT,full/'formal_project')
    copytree(OLD/'data/nextgen/DI_PHASE3_NEXTGEN',full/'history_20261015/DI_PHASE3_NEXTGEN')
    copytree(OLD/'src',full/'history_20261015/reproduction_scripts')
    (full/'history_20261015/README.md').write_text('历史代理工程及2026-10-15复现脚本，仅用于理解旧审计结果。当前正式入口是../formal_project/DI_PHASE3_ONE_CLICK.py，当前真实2022样本不与此处的旧构造输入混用。\n',encoding='utf-8')
    shutil.copyfile(OLD/'README_交付说明.md',full/'README_交付说明.md')
    (full/'src').mkdir(exist_ok=True)
    for n in ['audit_and_integrate.py','draw_updated_figures.py','update_documents.py','refresh_preparation.py','refresh_metadata_and_readmes.py','finalize_six_packages.py']:
        shutil.copyfile(ROOT/n,full/'src'/n)
    (full/'src/README.md').write_text('本轮重建脚本使用原云工作区/workspace/URP、urp_review等布局；对应材料均在本包或其他五包中。当前正式Sobol/优化工程可独立复制，仍须接入原Modified DI实现。历史复现脚本见history_20261015。\n',encoding='utf-8')
    versions=rd(ROOT/'ANALYSIS_ENVIRONMENT.json');(full/'requirements-verified.txt').write_text(''.join(n+'=='+v+'\n' for n,v in versions.items()))
    shutil.copyfile(ROOT/'ANALYSIS_ENVIRONMENT.json',full/'ANALYSIS_ENVIRONMENT.json')
    # Complete executed-results package: current true samples plus explicitly historical proxy artifacts.
    runs=STAGE/'URP_run_results';copytree(ART,runs/'artifacts')
    for p in (runs/'artifacts').glob('*.log'):
        (runs/'history_logs_20261015').mkdir(exist_ok=True);shutil.move(str(p),runs/'history_logs_20261015'/p.name)
    shutil.copyfile(OLD/'README_RESULTS.md',runs/'README_RESULTS.md')
    (runs/'README_交付说明.md').write_text('2026-10-17完整运行产物与真实链补件核验。先读README_RESULTS.md；本包含输出、8组保留样本与本次核验脚本，正式Sobol/优化工程见第六个ZIP。原模型新计算尚未运行。\n',encoding='utf-8')
    shutil.copyfile(OLD/'NPZ_ARRAY_SHAPES.json',runs/'NPZ_ARRAY_SHAPES.json')
    (runs/'src').mkdir(exist_ok=True);shutil.copyfile(ROOT/'audit_and_integrate.py',runs/'src/audit_and_integrate.py')
    shutil.copyfile(ROOT/'ANALYSIS_ENVIRONMENT.json',runs/'ANALYSIS_ENVIRONMENT.json')
    # Figure-only package includes current sources/tables and source labels, without duplicating the huge sample file.
    figs=STAGE/'URP_figures';copytree(ART/'figures',figs)
    shutil.copyfile(ART/'figure_captions.json',figs/'figure_captions.json')
    for n in ['phase2_2022_parameter_summary.csv','phase2_2022_correlations.csv','observed_yield_gate_headroom.csv','parameter_intervals_verified.csv','water_balance_recomputed.csv']:
        (figs/'source_tables').mkdir(exist_ok=True);shutil.copyfile(ART/'tables'/n,figs/'source_tables'/n)
    shutil.copyfile(ROOT/'PHASE2_2022_VALIDATION.json',figs/'PHASE2_2022_VALIDATION.json')
    (figs/'README.md').write_text('2026-10-17：2022真实阶段二已接入。共22幅当前图（300dpi PNG和矢量PDF）；F07—F13明确标记2026-10-15历史代理诊断，未冒充新真实模型结果。新图含四年区间/相关/量账/门槛与F15正式链轨迹。\n',encoding='utf-8')
    upd=STAGE/'URP_update_20261016';copytree(REV,upd)
    prep=STAGE/'URP_execution_ready_20261016';copytree(PREP,prep)
    # Source snapshot is coherent; regeneration scratch or old manifests are not presented as scientific outputs.
    for folder in [full/'artifacts',runs/'artifacts',upd,prep]:
        for name in ['delivery_file_manifest.json','RUN_RESULTS_MANIFEST.json','ARCHIVE_SHA256.txt']:(folder/name).unlink(missing_ok=True)
    targets=[(full,REPO/'deliverables/URP_full_package.zip'),(runs,REPO/'deliverables/URP_run_results.zip'),
             (figs,REPO/'deliverables/URP_figures.zip'),(upd,REPO/'deliverables/2026-10-16/URP_update_20261016.zip'),
             (prep,REPO/'deliverables/2026-10-16-execution-ready/URP_execution_ready_20261016.zip'),
             (eng,REPO/'deliverables/2026-10-16-sobol-optimization/URP_Sobol_Optimization_Updated.zip')]
    records=[]
    for folder,path in targets:
        result=archive(folder,path);records.append(result);print(path.name,result['bytes'],flush=True)
    # Synchronize files visible on GitHub, while retaining their existing download paths.
    d=REPO/'deliverables/2026-10-16'
    names={'URP_20261016_论文框架_确定性主线.docx':'paper_framework_20261016.docx',
           'URP_20261016_论文框架_确定性主线.pdf':'paper_framework_20261016.pdf',
           'URP_20261016_复核与变更说明.pdf':'review_update_20261016.pdf',
           'URP_20261016_复核结果表.xlsx':'evidence_tables_20261016.xlsx',
           'RUN_READINESS.json':'RUN_READINESS.json','VALIDATION.json':'VALIDATION.json',
           'PHASE2_2022_VALIDATION.json':'PHASE2_2022_VALIDATION.json','README.md':'README.md'}
    for src,dest in names.items():shutil.copyfile(REV/src,d/dest)
    for name in ['figures','tables']:
        shutil.rmtree(d/name);copytree(REV/name,d/name)
    d=REPO/'deliverables/2026-10-16-execution-ready'
    keep=d/'URP_execution_ready_20261016.zip'
    for p in list(d.iterdir()):
        if p==keep:continue
        if p.is_dir():shutil.rmtree(p)
        else:p.unlink()
    copytree(prep,d)
    # Engineering archive readme and external integrity hashes.
    (REPO/'deliverables/2026-10-16-sobol-optimization/README.md').write_text('2026-10-17：2022真实第二阶段已接入，正式链2000×32×3，burn163后58784行。MCMC不重跑，旧7数组不变。\n\n[下载完整修订工程](URP_Sobol_Optimization_Updated.zip)；[查看代码](../../DI_PHASE3_NEXTGEN_UPDATED/)。local95和阶段二条件扰动已可读取2022真样本；原模型新Sobol/优化仍未运行，原实现仍缺。\n',encoding='utf-8')
    index=REPO/'deliverables/2026-10-17';index.mkdir(exist_ok=True)
    verification=dict(date='2026-10-17',all_six_archives_rebuilt=True,phase2_2022_retained_rows=58784,
            existing_7_arrays_unchanged=True,checkpoint_records=20,central_values_verified=32,
            software_tests=18,preparation_tests=10,real_model_new_calls=0,archives=records)
    wr(index/'SIX_PACKAGE_VERIFICATION.json',verification)
    (index/'SHA256SUMS.txt').write_text(''.join(x['sha256']+'  '+x['path']+'\n' for x in records))
    for directory in [REPO/'deliverables',REPO/'deliverables/2026-10-16',REPO/'deliverables/2026-10-16-execution-ready',REPO/'deliverables/2026-10-16-sobol-optimization']:
        entries=[x for x in records if (REPO/x['path']).parent==directory]
        (directory/'SHA256SUMS.txt').write_text(''.join(x['sha256']+'  '+Path(x['path']).name+'\n' for x in entries))
    wr(ROOT/'SIX_PACKAGE_VERIFICATION.json',verification)
    print('All six archives rebuilt, CRC and every listed file digest verified.')

if __name__=='__main__':main()
