"""Audit the supplied 2022 phase-2 checkpoint and update all frozen tables.

No uploaded Python is executed; no model or MCMC sampler is run.
"""
from pathlib import Path
import json,hashlib,shutil,importlib.metadata,sys
import numpy as np
import pandas as pd
from emcee.autocorr import integrated_time

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/URP')
PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED'
OLD=Path('/workspace/urp_review')
ART=OLD/'artifacts';T=ART/'tables'
REV=Path('/workspace/urp_followup_20261016/revision')
PREP=Path('/workspace/urp_execution_20261016')
NEW=ROOT/'DI_2022_Phase2';FORMAL=NEW/'phase2_conditional_results'
UPLOAD=Path('/workspace/attachments/806c8536-f478-4159-97e9-52eb1d7b5a0b/DI_2022_Phase2.zip')
NAMES=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def wr(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def frame(p):return pd.read_csv(p,float_precision='round_trip')
def csv(p,v):v.to_csv(p,index=False,encoding='utf-8-sig');return v

def audit():
    p=FORMAL/'checkpoints/biomass_yield/ensemble_1.npz'
    with np.load(p,allow_pickle=False) as z:
        h=z['history'].copy();logs=z['logs'].copy();accepted=z['accepted'].copy()
        contract=json.loads(str(z['contract'].item()))
        assert h.shape==(2000,32,3) and logs.shape==accepted.shape==(2000,32)
        assert np.isfinite(h).all() and np.isfinite(logs).all()
        assert np.array_equal(h[-1],z['position']) and np.array_equal(logs[-1],z['logp'])
        assert accepted.dtype==np.bool_
    assert contract['names']==NAMES[5:] and contract['phase']=='biomass_yield'
    assert contract['case']=='2022' and contract['walkers']==32 and contract['ensembles']==1
    assert contract['wrapper_sha256']==sha(NEW/'DI_2022_PHASE2_ONE_CLICK.py')
    tau=integrated_time(h,tol=0,quiet=True);burn=int(np.ceil(5*tau.max()))
    assert burn==163;post=h[burn:].reshape(-1,3);assert post.shape==(58784,3)
    supplied=rd(FORMAL/'conditional_parameter_summary.json');status=rd(FORMAL/'run_status.json')
    assert status['Sampling_complete'] is True and status['Burn_in']==burn
    assert status['Inference_validated'] is False and status['Joint_posterior'] is False
    np.testing.assert_allclose(tau,status['Tau'],atol=1e-12,rtol=0)
    np.testing.assert_allclose(accepted.mean(0),status['Acceptance_by_walker'],atol=0,rtol=0)
    integrity=frame(T/'checkpoint_integrity.csv')
    assert set(contract['phase1_checkpoint_sha256'].values())==set(integrity[(integrity.Year==2022)&(integrity.Phase==1)].SHA256)
    with np.load(ART/'verified_phase_specific_draws.npz',allow_pickle=False) as z:
        arrays={k:z[k].copy() for k in z.files}
    existing={k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in arrays.items() if k!='p2_2022'}
    p1mean=arrays['p1_2022'].mean(0)
    np.testing.assert_array_equal(p1mean,[contract['fixed'][k] for k in NAMES[:5]])
    rows=[]
    for j,k in enumerate(NAMES[5:]):
        x=post[:,j];lo,hi=contract['priors'][k]
        assert np.all((x>=lo)&(x<=hi))
        np.testing.assert_allclose(x.mean(),supplied[k]['Mean'],atol=1e-12,rtol=0)
        np.testing.assert_allclose(x.std(ddof=1),supplied[k]['SD'],atol=1e-12,rtol=0)
        np.testing.assert_allclose(np.quantile(x,[.025,.5,.975]),supplied[k]['Quantiles_025_50_975'],atol=1e-12,rtol=0)
        rows.append(dict(Year=2022,Phase=2,Parameter=k,N=len(x),Mean=x.mean(),SD=x.std(ddof=1),
                         Median=np.median(x),P025=np.quantile(x,.025),P975=np.quantile(x,.975),
                         Prior_low=lo,Prior_high=hi,Lower_1pct_mass=np.mean(x<lo+.01*(hi-lo)),
                         Upper_1pct_mass=np.mean(x>hi-.01*(hi-lo)),Evidence='checkpoint; conditional single ensemble'))
    arrays['p2_2022']=post
    np.savez_compressed(ART/'verified_phase_specific_draws.npz',**arrays)
    for k,v in arrays.items():
        if k!='p2_2022':assert hashlib.sha256(v.tobytes()).hexdigest()==existing[k]
    shutil.copyfile(ART/'verified_phase_specific_draws.npz',PROJECT/'frozen_inputs/verified_phase_specific_draws.npz')
    shutil.copyfile(ART/'verified_phase_specific_draws.npz',PREP/'verified_phase_specific_draws.npz')
    (PROJECT/'frozen_inputs/DI_2022_Phase2').mkdir(exist_ok=True)
    shutil.copytree(FORMAL,PROJECT/'frozen_inputs/DI_2022_Phase2/phase2_conditional_results',dirs_exist_ok=True)
    shutil.copyfile(NEW/'DI_2022_PHASE2_ONE_CLICK.py',PROJECT/'frozen_inputs/DI_2022_Phase2/DI_2022_PHASE2_ONE_CLICK.py')
    shutil.copyfile(NEW/'使用说明.md',PROJECT/'frozen_inputs/DI_2022_Phase2/使用说明.md')
    shutil.copyfile(UPLOAD,PROJECT/'frozen_inputs/DI_2022_Phase2.zip')
    assert not (PROJECT/'frozen_inputs/DI_2022_Phase2/phase2_smoke').exists()
    diagrows=[dict(Year=2022,Phase=2,Parameter=k,Burn_in=burn,Raw_steps=2000,Retained_steps=2000-burn,
                   Retained_correlated_draws=len(post),Tau_max=float(tau[j]),Steps_over_tau=2000/tau[j],
                   Rhat_max=np.nan,ESS_bulk_min=np.nan,ESS_tail_min=np.nan,Source_Rhat=np.nan,
                   Diagnostic_pass=False) for j,k in enumerate(NAMES[5:])]
    for name,new in [('parameter_intervals_verified',pd.DataFrame(rows)),('mcmc_diagnostics_recomputed',pd.DataFrame(diagrows))]:
        d=frame(T/(name+'.csv'));d=d[~((d.Year==2022)&(d.Phase==2))]
        csv(T/(name+'.csv'),pd.concat([d,new],ignore_index=True).sort_values(['Year','Phase']))
    integrity=integrity[~((integrity.Year==2022)&(integrity.Phase==2))]
    integrity=pd.concat([integrity,pd.DataFrame([dict(Year=2022,Phase=2,
        File='DI_2022_Phase2/phase2_conditional_results/checkpoints/biomass_yield/ensemble_1.npz',
        SHA256=sha(p),Shape=str(h.shape),Finite=True,Endpoint_match=True,Acceptance=float(accepted.mean()))])],ignore_index=True)
    csv(T/'checkpoint_integrity.csv',integrity)
    provenance=frame(T/'merged_sample_provenance.csv')
    mask=(provenance.Year==2022)&(provenance.Phase==2)
    provenance.loc[mask,'Rows']=len(post);provenance.loc[mask,'Compare']='new true 2022 phase2 checkpoint, burn=163'
    provenance.loc[mask,'Match']=True;csv(T/'merged_sample_provenance.csv',provenance)
    # Preserve the old synthetic proxy files as historical inputs; current arrays never read them.
    mean_model=rd(FORMAL/'conditional_mean_model.json')
    for j,k in enumerate(NAMES):
        target=p1mean[j] if j<5 else post[:,j-5].mean()
        np.testing.assert_allclose(mean_model['values'][k],target,atol=1e-12,rtol=0)
    water=frame(T/'water_balance_recomputed.csv');water=water[water.Year!=2022]
    model_checks=[]
    for scenario in ['DI','Zero']:
        s=mean_model[scenario].copy()
        np.testing.assert_allclose(s['ET_mm'],s['Tr_mm']+s['Es_mm'],atol=1e-10,rtol=0)
        np.testing.assert_allclose(.87*s['Y_13pct'],s['Y_dry'],atol=1e-10,rtol=0)
        gain=s['Profile_final_mm']-s['Profile_initial_mm']+s['Surface_final_mm']-s['Surface_initial_mm']
        balance=s['Irrigation_mm']+s['Rain_mm']+s['CR_mm']+s['GwIn_mm']-s['ET_mm']-s['Runoff_mm']-s['DeepPerc_mm']-s['TileDrain_mm']-gain
        assert abs(balance)<1e-8 and abs(s['Water_balance_residual_mm'])<1e-8
        s.update(Year=2022,Scenario=scenario,Recomputed_balance_mm=balance,Storage_gain_mm=gain,
                 IWP_kg_m3=100*s['Y_13pct']/s['Irrigation_mm'] if s['Irrigation_mm'] else np.nan,
                 ETWP_kg_m3=100*s['Y_13pct']/s['ET_mm'])
        water=pd.concat([water,pd.DataFrame([s])],ignore_index=True)
        model_checks.append(dict(Scenario=scenario,Balance_mm=balance,Y13=s['Y_13pct'],IWP_kg_m3=None if not s['Irrigation_mm'] else s['IWP_kg_m3']))
    csv(T/'water_balance_recomputed.csv',water)
    centers=frame(PROJECT/'frozen_inputs/combined_central_parameter_vectors.csv')
    for k in NAMES[5:]:np.testing.assert_allclose(centers.loc[centers.Year==2022,k],post[:,NAMES[5:].index(k)].mean(),atol=1e-12,rtol=0)
    # The point values did not change; only their provenance is strengthened.
    c=frame(REV/'tables/central_vector_comparison.csv')
    for j,k in enumerate(NAMES[5:]):
        m=(c.Year==2022)&(c.Parameter==k);c.loc[m,'Mean']=post[:,j].mean()
        c.loc[m,'Absolute_difference']=abs(c.loc[m,'Submitted_mean']-post[:,j].mean())
        c.loc[m,'Evidence']='new 2022 original checkpoint verified'
    csv(REV/'tables/central_vector_comparison.csv',c);csv(T/'central_vector_comparison.csv',c)
    c=frame(REV/'tables/central_vectors_with_provenance.csv');c['Evidence']='both phases checkpoint verified'
    csv(REV/'tables/central_vectors_with_provenance.csv',c);csv(T/'central_vectors_with_provenance.csv',c)
    for name in ['sampling_group_summary','sampling_table_corrected']:
        d=frame(REV/'tables'/f'{name}.csv');m=(d.Year==2022)&(d.Phase==2)
        d.loc[m,'Raw_checkpoint_available']=True
        if name=='sampling_table_corrected':d.loc[m,'Tau_difference_vs_original']=0.
        csv(REV/'tables'/f'{name}.csv',d);csv(T/f'{name}.csv',d)
    fit=frame(REV/'tables/calibration_evidence_tiers.csv');m=fit['年份']==2022;s=mean_model['DI']
    fit.loc[m,'CC_RMSE']=s['CC_RMSE'];fit.loc[m,'生物量_RMSE']=s['B_RMSE']
    fit.loc[m,'模拟产量']=s['Y_13pct'];fit.loc[m,'产量误差_pct']=100*(s['Y_13pct']/14.08-1)
    fit.loc[m,'证据']='原链与均值点JSON已核；R²仍为文档值，缺配对序列'
    csv(REV/'tables/calibration_evidence_tiers.csv',fit);csv(T/'paper_calibration_table.csv',fit)
    fit.to_csv(T/'calibration_evidence_tiers.csv',index=False,encoding='utf-8-sig')
    groups=frame(REV/'tables/sampling_group_summary.csv');assert groups.Raw_checkpoint_available.all()
    corr=pd.DataFrame(np.corrcoef(post.T),index=NAMES[5:],columns=NAMES[5:]);csv(T/'phase2_2022_correlations.csv',corr.rename_axis('Parameter').reset_index())
    csv(T/'phase2_2022_parameter_summary.csv',pd.DataFrame(rows))
    report=dict(date='2026-10-17',archive_sha256=sha(UPLOAD),checkpoint_sha256=sha(p),
        formal_shape=list(h.shape),smoke_included_in_statistics=False,burn_in=burn,
        retained_steps_per_walker=2000-burn,retained_correlated_rows=len(post),tau=tau.tolist(),
        acceptance=float(accepted.mean()),endpoint_position_and_logp_match=True,
        existing_7_arrays_unchanged=True,existing_array_hashes=existing,
        source_phase1_checkpoint_hashes_matched=4,source_wrapper_hash_match=True,
        central_values_verified=32,raw_phase2_groups_available=4,
        conditional_mean_model_checked=model_checks,
        phase2_WPlate_HI0_correlation=float(corr.loc['WP_late','HI0']),
        source_state=status['State'],inference_validated=False,joint_posterior=False,
        original_model_implementation_in_new_upload=False,
        new_real_model_Sobol_executed=False,new_real_model_NSGAIII_executed=False,
        individual_2022_CC_biomass_pairs_present=False,
        note='Checkpoint and supplied model aggregates checked; no original model rerun or independent validation')
    wr(ROOT/'PHASE2_2022_VALIDATION.json',report);wr(ART/'PHASE2_2022_VALIDATION.json',report)
    shutil.copyfile(ROOT/'PHASE2_2022_VALIDATION.json',PROJECT/'frozen_inputs/PHASE2_2022_VALIDATION.json')
    config=rd(PROJECT/'project_config.json')
    config['baseline_reference']['2022']={k:s[k] for k in ['Y_13pct','Tr_mm','Es_mm','ET_mm']}
    config['baseline_reference']['2022'].update(atol=1e-5,evidence='2022 true phase2 conditional_mean_model.json; aggregate accounting checked; model not rerun')
    config['phase2_2022_checkpoint']='frozen_inputs/DI_2022_Phase2/phase2_conditional_results/checkpoints/biomass_yield/ensemble_1.npz'
    wr(PROJECT/'project_config.json',config)
    state=dict(date='2026-10-17',central_values_verified=32,central_values_report_only=0,
               verified_phase1_ensembles=16,verified_phase2_ensembles=4,raw_2022_phase2_present=True,
               phase2_2022_retained_rows=len(post),modified_DI_wrapper_present=True,
               original_modified_DI_implementation_present=False,reference_PDF_present=False,
               new_real_Sobol_executed=False,new_real_NSGAIII_executed=False,
               study_design='deterministic main; conditional perturbations separately')
    wr(REV/'RUN_READINESS.json',state);wr(PROJECT/'RUN_READINESS.json',state);wr(ART/'RUN_READINESS.json',state)
    (ART/'submitted').mkdir(exist_ok=True);shutil.copyfile(UPLOAD,ART/'submitted/DI_2022_Phase2.zip')
    shutil.copytree(NEW,ART/'submitted/DI_2022_Phase2',dirs_exist_ok=True)
    (REV/'submitted').mkdir(exist_ok=True);shutil.copyfile(UPLOAD,REV/'submitted/DI_2022_Phase2.zip')
    wr(ROOT/'ANALYSIS_ENVIRONMENT.json',{p:importlib.metadata.version(p) for p in ['numpy','pandas','scipy','matplotlib','emcee','arviz','SALib','pymoo','python-docx','reportlab','pypdf']})
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return report

if __name__=='__main__':audit()
