from pathlib import Path
import json,hashlib
import pandas as pd
import numpy as np
import fitz
from PIL import Image

ROOT=Path(__file__).resolve().parent
for folder in [ROOT/'part3_sobol',ROOT/'part4_optimization_diagnostic']:
    reg=json.loads((folder/'FIGURE_REGISTRY.json').read_text());checks=[]
    for entry in reg['figures']:
        assert entry['years']==[2019,2020,2021,2022]
        with fitz.open(folder/'figures'/(entry['name']+'.pdf')) as doc:
            assert len(doc)==1
            for block in doc[0].get_text('dict')['blocks']:
                for line in block.get('lines',[]):
                    for span in line['spans']:
                        x0,y0,x1,y1=span['bbox']
                        assert x0>=-1 and y0>=-1 and x1<=doc[0].rect.width+1 and y1<=doc[0].rect.height+1,(entry['name'],span['text'])
        with Image.open(folder/'figures'/(entry['name']+'.png')) as im:assert min(im.info['dpi'])>599
        checks.append(dict(figure=entry['name'],PDF_text_bounds='PASS',PNG_dpi=600,years=[2019,2020,2021,2022]))
    if 'part3' in folder.name:
        raw=pd.read_csv(folder/'tables/Sobol_all_seed_indices.csv',float_precision='round_trip')
        source=pd.read_csv('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/actual_publication_20261019/tables/Sobol_all_seed_indices.csv',float_precision='round_trip')
        pd.testing.assert_frame_equal(raw,source)
        means=pd.read_csv(folder/'tables/Sobol_four_year_descriptive_means.csv',float_precision='round_trip')
        for metric in ['S1','ST']:
            expected=raw.groupby(['Output','Parameter','Year'])[metric].mean().groupby(['Output','Parameter']).mean()
            actual=means.set_index(['Output','Parameter'])[metric+'_four_year_mean'].sort_index()
            np.testing.assert_allclose(actual,expected.sort_index(),rtol=0,atol=1e-12)
        yield_rows=raw[raw.Output=='Y_13pct']
        assert (yield_rows.ST-yield_rows.ST_conf).min()>-.04 and (yield_rows.ST+yield_rows.ST_conf).max()<.62
        extra=dict(raw_rows=len(raw),four_year_summary_rows=len(means),exact_indices_preserved=True,
            descriptive_mean_verified=True,R02_cat_coc='PENDING_MAPPING')
    else:
        v=json.loads((folder/'FULL_RANGE_VERIFICATION.json').read_text());assert v['status']=='PASS'
        diag=json.loads((folder/'R03_DIAGNOSIS_STATUS.json').read_text());assert diag['status']=='PASS'
        assert diag['original_Pareto_rows_verified']==3986 and diag['R04_English']=='COMPLETE'
        source_base=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/actual_publication_20261019/tables')
        for entry in diag['source_identities']:
            local=folder/entry['local']
            assert hashlib.sha256(local.read_bytes()).hexdigest()==entry['sha256']
            assert local.read_bytes()==(source_base/Path(entry['source']).name).read_bytes()
        c=pd.read_csv(folder/'tables/R04_yield_comparison.csv',float_precision='round_trip')
        t=pd.read_csv(folder/'tables/R03_irrigation_ET_storage_tradeoff.csv',float_precision='round_trip')
        assert c.Year.tolist()==t.Year.tolist()==[2019,2020,2021,2022]
        np.testing.assert_allclose(c.Yield_gate_Y13,.95*c.Observed_Y13,atol=1e-12,rtol=0)
        assert (c.Candidate_Y13>=c.Yield_gate_Y13).all()
        np.testing.assert_allclose(t.Irrigation_reduction_mm,
            t.ET_reduction_mm+t.Lower_final_soil_storage_mm+t.Loss_reduction_mm+
            t.Surface_storage_difference_mm+t.External_inflow_adjustment_mm,atol=1e-8,rtol=0)
        extra=dict(new_search_evaluations_verified=v['new_search_evaluations'],
            original_R03_verdict=diag['original_R03_verdict'],R04_English=diag['R04_English'],
            source_files_identical=len(diag['source_identities']),gated_Pareto_rows_verified=3986,
            irrigation_ET_storage_decomposition='PASS',new_MCMC_runs=0)
    pdf=Path('/tmp')/(folder.name+'_revision_working.pdf')
    if pdf.exists():
        with fitz.open(pdf) as doc:
            assert sum(len(p.get_image_info()) for p in doc)==len(reg['figures'])
            assert all(len(p.get_text().strip())>=40 for p in doc)
            extra.update(working_Word_pages=len(doc),working_Word_figures=len(reg['figures']))
            if 'part4' in folder.name:
                for i,p in enumerate(doc):
                    if p.get_image_info():p.get_pixmap().save('/tmp/PART4_WORD_PAGE_%02d.png'%(i+1))
    result=dict(status='PASS_FOR_COMPLETED_COMPONENTS',checks=checks,**extra)
    (folder/'QUALITY_CHECK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    files=[dict(file=p.relative_to(folder).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        for p in sorted(folder.rglob('*')) if p.is_file() and p.name not in ['MANIFEST.json','REBUILD.log','FULL_RANGE_RUN.log']]
    (folder/'MANIFEST.json').write_text(json.dumps(files,ensure_ascii=False,indent=2))
    print(folder.name,json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False))
