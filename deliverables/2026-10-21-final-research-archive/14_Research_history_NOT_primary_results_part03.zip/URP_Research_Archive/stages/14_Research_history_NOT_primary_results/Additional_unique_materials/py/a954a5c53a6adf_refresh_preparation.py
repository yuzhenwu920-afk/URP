"""Update the former preparation bundle to the now-available phase-2 inputs."""
from pathlib import Path
import json,shutil,sys,importlib.metadata
import numpy as np

ROOT=Path(__file__).resolve().parent
P=Path('/workspace/urp_execution_20261016')
PROJECT=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
ART=Path('/workspace/urp_review/artifacts')
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def wr(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    s=rd(PROJECT/'project_config.json');c=rd(P/'study_config.json')
    ledger_fields=['Irrigation_mm','Rain_mm','CR_mm','GwIn_mm','Runoff_mm','DeepPerc_mm','TileDrain_mm',
                   'Profile_initial_mm','Profile_final_mm','Surface_initial_mm','Surface_final_mm',
                   'Water_balance_residual_mm','Max_daily_balance_residual_mm']
    model=rd(ROOT/'DI_2022_Phase2/phase2_conditional_results/conditional_mean_model.json')
    for year,case in c['cases'].items():
        case['support_bounds']=s['global_physical_bounds']
        case['space_note']='declared common global physical range; not the annual MCMC prior density'
        case['center_evidence']='both phases checkpoint verified'
    d=model['DI'];expected={k:d[k] for k in ['Y_13pct','Y_dry','Tr_mm','Es_mm','ET_mm','MaxCC']+ledger_fields}
    expected['B_t_ha']=d['B_last'];c['cases']['2022']['baseline_expected']=expected
    c['cases']['2022']['baseline_source']='source_data/conditional_mean_model.json; supplied original-model aggregate, not rerun'
    c['status']='TRUE_2022_PHASE2_INTEGRATED_REAL_MODEL_STILL_MISSING'
    c['date_updated']='2026-10-17';wr(P/'study_config.json',c)
    (P/'source_data').mkdir(exist_ok=True)
    for name in ['conditional_mean_model.json','conditional_parameter_summary.json','run_status.json']:
        shutil.copyfile(ROOT/'DI_2022_Phase2/phase2_conditional_results'/name,P/'source_data'/name)
    shutil.copyfile(ROOT/'PHASE2_2022_VALIDATION.json',P/'source_data/PHASE2_2022_VALIDATION.json')
    shutil.copyfile(PROJECT/'frozen_inputs/combined_central_parameter_vectors.csv',P/'source_data/combined_central_parameter_vectors.csv')
    shutil.copyfile(ROOT/'DI_2022_Phase2/phase2_conditional_results/checkpoints/biomass_yield/ensemble_1.npz',P/'source_data/phase2_2022_formal_checkpoint.npz')
    source=rd(P/'source_provenance.json')
    for row in source:
        row['formal_sampling_space']='common global physical ranges in study_config; annual supports are descriptive only'
        if row['year']==2022:
            row['phase2_present']=True;row['phase2_source']='source_data/phase2_2022_formal_checkpoint.npz'
            row['phase2_checkpoint_sha256']=rd(ROOT/'PHASE2_2022_VALIDATION.json')['checkpoint_sha256']
            row['phase2_retained_rows']=58784
    wr(P/'source_provenance.json',source)
    # Regenerate every design because the bound configuration/hash is now updated.
    shutil.rmtree(P/'designs_N128')
    sys.path.insert(0,str(P));import real_model_pipeline as pipeline
    result=pipeline.prepare(P/'study_config.json',P/'designs_N128',n=128)
    assert result['total_model_calls_required']==15360
    (P/'requirements-run.txt').write_text('# Analysis-only versions verified 2026-10-17, original crop engine dependencies separate.\n'+
         '\n'.join(f'{n}=={importlib.metadata.version(n)}' for n in ['numpy','scipy','SALib'])+'\n')
    # Preserve negative tests for generic missing baselines; remove outdated assertions that 2022 must be absent.
    f=P/'verify_delivery.py';text=f.read_text()
    text=text.replace("assert len(refs) == 9 and all", "assert len(refs) >= 9 and all")
    text=text.replace("assert len(word.inline_shapes) == 9 and len(pdf.pages) == 9", "assert len(word.inline_shapes) == len(refs) and len(pdf.pages) >= 5")
    text=text.replace("assert cases['2022']['baseline_expected'] is None", "assert cases['2022']['baseline_expected'] is not None\n    with np.load(ROOT / 'verified_phase_specific_draws.npz', allow_pickle=False) as z:\n        assert z['p2_2022'].shape == (58784, 3)\n        with np.load(ROOT / 'source_data/phase2_2022_formal_checkpoint.npz', allow_pickle=False) as raw:\n            assert np.array_equal(z['p2_2022'], raw['history'][163:].reshape(-1, 3))")
    text=text.replace("'date': '2026-10-16'", "'date': '2026-10-17'")
    text=text.replace("'new_figure_pairs': 2, 'previous_figure_pairs_retained': 7", "'current_figure_pairs': len(list((ROOT / 'figures').glob('*.png')))")
    text=text.replace("'missing_2022_phase2_checkpoint': True", "'missing_2022_phase2_checkpoint': False, 'phase2_2022_retained_rows': 58784")
    f.write_text(text)
    print('Regenerated 12 common-global Sobol designs and updated exact 2022 baseline/configuration.')

if __name__=='__main__':main()
