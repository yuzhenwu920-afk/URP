"""Make readable Excel and Word stage records; deliberately no final ZIP."""
from pathlib import Path
import argparse,json,hashlib
import pandas as pd
from openpyxl.styles import Font,PatternFill,Alignment
from docx import Document
from docx.shared import Cm,Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

ROOT=Path(__file__).resolve().parent


def build(folder,title,notes_name):
    registry=json.loads((folder/'FIGURE_REGISTRY.json').read_text())
    tables=sorted((folder/'tables').glob('*.csv'))
    if (folder/'Zero_DI_replays.csv').exists():tables.append(folder/'Zero_DI_replays.csv')
    if 'part3' in folder.name:
        cfg=json.loads(Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED/project_config.json').read_text())
        common=pd.DataFrame([dict(Parameter=k,Lower=v[0],Upper=v[1],Input_distribution='independent uniform') for k,v in cfg['global_physical_bounds'].items()])
        f=folder/'tables/Sobol_common_input_ranges.csv';common.to_csv(f,index=False);tables.append(f)
    workbook=folder/(folder.name+'_source_tables.xlsx')
    index=[];seen=set()
    with pd.ExcelWriter(workbook,engine='openpyxl') as writer:
        for i,p in enumerate(tables):
            name=p.stem[:31]
            if name in seen:name=p.stem[:27]+f'_{i}'
            seen.add(name)
            d=pd.read_csv(p,float_precision='round_trip')
            if len(d)>10000:continue
            d.to_excel(writer,index=False,sheet_name=name)
            index.append({'Sheet':name,'Rows':len(d),'Canonical_file':p.relative_to(folder).as_posix()})
        pd.DataFrame(index).to_excel(writer,index=False,sheet_name='Index')
        writer.book._sheets.insert(0,writer.book._sheets.pop())
        caps=pd.DataFrame([{k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in x.items()} for x in registry['figures']])
        caps.to_excel(writer,index=False,sheet_name='Figure_captions')
        for ws in writer.book.worksheets:
            ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.showGridLines=False
            ws.row_dimensions[1].height=34
            for cell in ws[1]:
                cell.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='24556B')
                cell.alignment=Alignment(wrap_text=True,vertical='center')
            for column in ws.columns:
                ws.column_dimensions[column[0].column_letter].width=min(45,max(13,max(len(str(c.value or '')) for c in list(column)[:60])+2))
                for cell in list(column)[1:]:
                    cell.font=Font(name='Calibri',size=10)
                    if isinstance(cell.value,float):cell.number_format='0.0000'
                    if cell.row%2==0:cell.fill=PatternFill('solid',fgColor='F0F5F7')
    doc=Document();sec=doc.sections[0]
    sec.left_margin=sec.right_margin=Cm(1.7);sec.top_margin=sec.bottom_margin=Cm(1.6)
    st=doc.styles['Normal'];st.font.name='DejaVu Sans';st.font.size=Pt(10.5)
    st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.add_heading(title,0)
    doc.add_paragraph('阶段修订稿；按用户要求，图片、源数据、表格与说明留待全部部分完成后统一打包。')
    text=(folder/notes_name).read_text()
    for block in text.split('\n\n'):
        block=block.strip()
        if not block:continue
        if block.startswith('# '):continue
        if block.startswith('## '):doc.add_heading(block[3:],1)
        elif block.startswith('### '):doc.add_heading(block[4:],2)
        else:doc.add_paragraph(block)
    if 'part4' in folder.name and (folder/'tables/R04_yield_comparison.csv').exists():
        doc.add_page_break();doc.add_heading('关键数值核对表',1)
        specs=[
            ('四年产量与灌水量减少比例','R04_yield_comparison.csv',
             [('Year','年份',0),('Observed_Y13','观测产量',3),
              ('Model_baseline_Y13','模型基准',3),('Candidate_Y13','候选产量',3),
              ('Yield_change_vs_observed_pct','相对观测变化%',2),
              ('Irrigation_reduction_pct','灌水减少%',2)]),
            ('减灌水与水量去向','R03_irrigation_ET_storage_tradeoff.csv',
             [('Year','年份',0),('Irrigation_reduction_mm','减灌水mm',1),
              ('ET_reduction_pct','ET减少%',2),('Lower_final_soil_storage_mm','季末储水差mm',1),
              ('Candidate_soil_storage_change_mm','候选储水变化mm',1)])]
        for label,filename,columns in specs:
            doc.add_heading(label,2)
            frame=pd.read_csv(folder/'tables'/filename,float_precision='round_trip')
            table=doc.add_table(rows=1,cols=len(columns));table.style='Light Shading Accent 1'
            header=OxmlElement('w:tblHeader');table.rows[0]._tr.get_or_add_trPr().append(header)
            for cell,(_,name,_) in zip(table.rows[0].cells,columns):cell.text=name
            for _,row in frame.iterrows():
                for cell,(key,_,digits) in zip(table.add_row().cells,columns):
                    cell.text=f'{row[key]:.{digits}f}'
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:run.font.size=Pt(9)
        doc.add_paragraph('产量单位为t ha⁻¹。储水差=基准季末−候选季末；候选储水变化=候选季末−本年初始。'
                          '百分比以各自分母计算；灌水减少不等同于ET减少。表内显示值经四舍五入，完整精度在CSV及Excel中保留。')
    for entry in registry['figures']:
        doc.add_page_break();doc.add_heading(entry['title'],1)
        doc.add_picture(str(folder/'figures'/(entry['name']+'.png')),width=Cm(17.2))
        doc.add_paragraph(entry['caption'])
    doc.save(folder/(folder.name+'_revision_working.docx'))
    files=[dict(file=p.relative_to(folder).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(folder.rglob('*'))
        if p.is_file() and p.name not in ['MANIFEST.json','REBUILD.log','FULL_RANGE_RUN.log']]
    (folder/'MANIFEST.json').write_text(json.dumps(files,ensure_ascii=False,indent=2))
    print(title,':',len(index),'source worksheets;',len(registry['figures']),'figure groups',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('part',choices=['3','4']);a=p.parse_args()
    if a.part=='3':build(ROOT/'part3_sobol','第三部分：Sobol敏感性与年度稳定性','PART3_ANALYSIS_NOTES.md')
    else:build(ROOT/'part4_optimization_diagnostic','第四部分：零灌溉与产量—灌溉参照','PART4_ANALYSIS_NOTES.md')
