"""Build all six archives from the same current four-year publication assets."""
from pathlib import Path
import hashlib,json,shutil,zipfile
import numpy as np
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent;REPO=Path('/workspace/URP')
ART=Path('/workspace/urp_review/artifacts');REV=Path('/workspace/urp_followup_20261016/revision')
PREP=Path('/workspace/urp_execution_20261016');PROJECT=REPO/'DI_PHASE3_NEXTGEN_UPDATED';STAGE=ROOT/'staged'
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def wr(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def copytree(a,b):shutil.copytree(a,b,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.cache','.git','output_revised'))
def copy(a,b):b=Path(b);b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
def manifest(folder):
 for name in ['MANIFEST.json','SHA256SUMS.txt','ARCHIVE_SHA256.txt','delivery_file_manifest.json','RUN_RESULTS_MANIFEST.json']:(folder/name).unlink(missing_ok=True)
 entries=[dict(file=p.relative_to(folder).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(folder.rglob('*')) if p.is_file()]
 wr(folder/'MANIFEST.json',entries)
 (folder/'SHA256SUMS.txt').write_text(''.join(x['sha256']+'  '+x['file']+'\n' for x in entries),encoding='utf-8')
 return entries
def archive(folder,path,figure_dir):
 entries=manifest(folder);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp.zip')
 with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,folder.name+'/'+p.relative_to(folder).as_posix())
 with zipfile.ZipFile(temp) as z:
  assert z.testzip() is None
  for e in entries:assert hashlib.sha256(z.read(folder.name+'/'+e['file'])).hexdigest()==e['sha256']
  for e in rd(ROOT/'FIGURE_COVERAGE_AND_STYLE.json')['figures']:
   assert hashlib.sha256(z.read(folder.name+'/'+figure_dir+'/'+e['file'])).hexdigest()==e['sha256']
 assert temp.stat().st_size<100*1024*1024,(path,temp.stat().st_size)
 temp.replace(path)
 result=dict(path=path.relative_to(REPO).as_posix(),bytes=path.stat().st_size,sha256=sha(path),files=len(entries)+2,
             current_figure_pairs=18,years=[2019,2020,2021,2022],figure_directory=folder.name+'/'+figure_dir,CRC='PASS',all_file_digests='PASS')
 print(path.name,result['bytes'],flush=True)
 return result

assert rd(PROJECT/'SOFTWARE_VALIDATION.json')['tests_run']==19 and rd(PROJECT/'SOFTWARE_VALIDATION.json')['passed']
assert rd(PREP/'DELIVERY_VALIDATION.json')['software_tests_passed']==10
assert rd(PREP/'DELIVERY_VALIDATION.json')['real_2022_baseline_benchmark_passed']
style=rd(ROOT/'FIGURE_COVERAGE_AND_STYLE.json');assert style['current_figure_pairs']==18
assert all(x['years']==[2019,2020,2021,2022] for x in style['figures'])
with np.load(PROJECT/'frozen_inputs/verified_phase_specific_draws.npz') as z:
 assert len(z.files)==8 and z['p2_2022'].shape==(58784,3)
 old=rd(PROJECT/'frozen_inputs/PHASE2_2022_VALIDATION.json')
 for k,h in old['existing_array_hashes'].items():assert hashlib.sha256(z[k].tobytes()).hexdigest()==h
 wr(ROOT/'CURRENT_ARRAY_SHAPES.json',{key:list(z[key].shape) for key in z.files})
copy(PREP/'baseline_receipt_2022.json',ART/'model_2022_verification/preparation_baseline_receipt_2022.json')
# Historical Phase2-only audits retain their original source facts and link current readiness.
for p in [ART/'PHASE2_2022_VALIDATION.json',REV/'PHASE2_2022_VALIDATION.json',PREP/'PHASE2_2022_VALIDATION.json',PROJECT/'frozen_inputs/PHASE2_2022_VALIDATION.json']:
 x=rd(p);x['current_2026_10_18_original_model_and_data_complete']=True;x['current_readiness_record']='MODEL_2022_READINESS.json';wr(p,x)
wr(PROJECT/'FROZEN_INPUTS_MANIFEST.json',dict(date='2026-10-18',MCMC_frozen=True,files=[
 dict(file=p.relative_to(PROJECT).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
 for p in sorted((PROJECT/'frozen_inputs').rglob('*')) if p.is_file()]))

if STAGE.exists():shutil.rmtree(STAGE)
STAGE.mkdir()
manifest(PROJECT)
full=STAGE/'URP_review';copytree(ART,full/'artifacts');copytree(PROJECT,full/'formal_project')
# Full report has one canonical figure directory; standalone engineering includes its own identical set.
shutil.rmtree(full/'formal_project/four_year_figures')
(full/'formal_project/图表索引.html').write_text((PROJECT/'图表索引.html').read_text().replace('four_year_figures/','../artifacts/figures/'),encoding='utf-8')
(full/'formal_project/README.md').write_text((PROJECT/'README.md').read_text().replace('four_year_figures','../artifacts/figures'),encoding='utf-8')
(full/'formal_project/FIGURE_LOCATION.md').write_text('全集中的18组当前四年图统一位于../artifacts/figures；独立工程ZIP的four_year_figures包含逐文件相同的图。\n',encoding='utf-8')
manifest(full/'formal_project')
copytree('/workspace/urp_review/data/nextgen/DI_PHASE3_NEXTGEN',full/'history_20261015/DI_PHASE3_NEXTGEN')
copytree('/workspace/urp_review/src',full/'history_20261015/reproduction_scripts')
(full/'history_20261015/README.md').write_text('历史代理代码与审计脚本，不能作为本轮真实模型敏感性/优化结果。当前入口见formal_project，当前图与论文见artifacts。\n',encoding='utf-8')
copy('/workspace/urp_review/README_交付说明.md',full/'README.md')
for script in ['build_four_year_figures.py','refresh_documents.py','rebuild_six_packages.py']:
 copy(ROOT/script,full/'rebuild_scripts'/script)
(full/'rebuild_scripts/README.md').write_text('这些脚本记录当前云工作区的重建路径；原输出和配对源表均随包提供。独立工程的真实模型入口在formal_project，原MCMC冻结。\n',encoding='utf-8')

runs=STAGE/'URP_run_results';copytree(ART,runs/'artifacts')
copy('/workspace/urp_review/README_RESULTS.md',runs/'README.md');copy(ROOT/'CURRENT_ARRAY_SHAPES.json',runs/'NPZ_ARRAY_SHAPES.json')
figs=STAGE/'URP_figures';copytree(ROOT/'figures',figs/'figures')
for name in ['figure_captions.json','FIGURE_COVERAGE_AND_STYLE.json']:copy(ROOT/name,figs/name)
copy(ART/'图表索引.html',figs/'图表索引.html')
for name in ['calibration_metrics_recomputed','calibration_evidence_tiers','parameter_intervals_verified','water_balance_recomputed','observed_yield_gate_headroom','four_year_source_output_manifest']:
 copy(ART/'tables'/(name+'.csv'),figs/'source_tables'/(name+'.csv'))
copytree(ART/'four_year_source_data',figs/'four_year_source_data')
(figs/'README.md').write_text('''# 2019—2022 四年图件（2026-10-18）

当前18组图均含四年，PNG为300dpi，PDF保留矢量文字。年份颜色固定为蓝、橙、绿、紫；最小字号10.5pt，图例有独立留白。双击图表索引.html浏览。

2019—2021使用原核验输出，2022使用本次原模型均值点回放；配对值均逐点匹配原始逐日输出。源表和原输出随包提供。此包不混入历史代理图；完整新Sobol和NSGA-III实验尚未完成。
''',encoding='utf-8')
upd=STAGE/'URP_update_20261016';copytree(REV,upd)
prep=STAGE/'URP_execution_ready_20261016';copytree(PREP,prep)
eng=STAGE/'DI_PHASE3_NEXTGEN_UPDATED';copytree(PROJECT,eng)
targets=[(full,REPO/'deliverables/URP_full_package.zip','artifacts/figures'),
 (runs,REPO/'deliverables/URP_run_results.zip','artifacts/figures'),
 (figs,REPO/'deliverables/URP_figures.zip','figures'),
 (upd,REPO/'deliverables/2026-10-16/URP_update_20261016.zip','figures'),
 (prep,REPO/'deliverables/2026-10-16-execution-ready/URP_execution_ready_20261016.zip','figures'),
 (eng,REPO/'deliverables/2026-10-16-sobol-optimization/URP_Sobol_Optimization_Updated.zip','four_year_figures')]
for folder in [full/'artifacts',runs/'artifacts',upd,prep]:
 for name in ['delivery_file_manifest.json','RUN_RESULTS_MANIFEST.json','ARCHIVE_SHA256.txt']:(folder/name).unlink(missing_ok=True)
records=[archive(folder,path,directory) for folder,path,directory in targets]

# Visible GitHub copies are synchronized with the exact files used in the ZIPs.
d=REPO/'deliverables/2026-10-16'
for name in ['figures','tables','four_year_source_data']:
 if (d/name).exists():shutil.rmtree(d/name)
 copytree(REV/name,d/name)
names={'URP_20261016_论文框架_确定性主线.docx':'paper_framework_20261016.docx','URP_20261016_论文框架_确定性主线.pdf':'paper_framework_20261016.pdf',
 'URP_20261016_论文框架_确定性主线.md':'paper_framework_20261016.md','URP_20261016_复核与变更说明.pdf':'review_update_20261016.pdf',
 'URP_20261016_复核结果表.xlsx':'evidence_tables_20261016.xlsx'}
for a,b in names.items():copy(REV/a,d/b)
for name in ['README.md','RUN_READINESS.json','VALIDATION.json','MODEL_2022_READINESS.json','figure_captions.json','FIGURE_COVERAGE_AND_STYLE.json','图表索引.html']:copy(REV/name,d/name)
d=REPO/'deliverables/2026-10-16-execution-ready';keep=d/'URP_execution_ready_20261016.zip'
for p in list(d.iterdir()):
 if p==keep:continue
 if p.is_dir():shutil.rmtree(p)
 else:p.unlink()
copytree(prep,d)
for path in [REPO/'deliverables/2026-10-16-sobol-optimization/README.md']:
 path.write_text('''# Sobol与优化工程（2026-10-18）

2022原模型及完整data已接入，19项工程检查通过，含真实基准与五次灌水量修改检查。原MCMC冻结；完整Sobol/优化实验尚未完成，另外三年原模型待接入。

工程ZIP含18组当前四年PNG/PDF、四年原输出、源码/data与冻结8组样本，和图件包的当前图逐文件一致。

[下载工程](URP_Sobol_Optimization_Updated.zip) · [查看代码](../../DI_PHASE3_NEXTGEN_UPDATED/)
''',encoding='utf-8')
index=REPO/'deliverables/2026-10-18-four-year-refresh';index.mkdir(exist_ok=True)
report=dict(date='2026-10-18',all_six_archives_updated=True,current_figure_pairs=18,years=[2019,2020,2021,2022],
 figures_identical_across_all_six=True,figure_min_font_pt=10.5,PNG_dpi=300,vector_format='PDF',
 engineering_tests=19,preparation_tests=10,paper_pages=len(PdfReader(ART/'URP_论文框架_含数据与图.pdf').pages),paper_embedded_figures=9,
 model_2022_source_and_data_complete=True,model_2022_baseline_and_management_verified=True,
 new_complete_Sobol_experiment=False,new_complete_NSGAIII_experiment=False,MCMC_frozen=True,archives=records)
wr(index/'SIX_PACKAGE_VERIFICATION.json',report);copy(ROOT/'FIGURE_COVERAGE_AND_STYLE.json',index/'FIGURE_COVERAGE_AND_STYLE.json')
copy(ROOT/'figures/F02_CC_trajectories.png',index/'four_year_CC_preview.png')
(index/'SHA256SUMS.txt').write_text(''.join(x['sha256']+'  '+x['path']+'\n' for x in records))
(index/'README.md').write_text('''# 六包已同步更新：四年图表版（2026-10-18）

18组当前年度图均含2019、2020、2021、2022；固定蓝/橙/绿/紫，最小字号10.5pt，300dpi PNG与矢量PDF，标题和图例留白。六包里的当前图逐文件一致。

- [单独图件](../URP_figures.zip)
- [完整报告、论文与图件](../URP_full_package.zip)
- [完整运行结果](../URP_run_results.zip)
- [材料复核与论文修订](../2026-10-16/URP_update_20261016.zip)
- [计算准备与论文](../2026-10-16-execution-ready/URP_execution_ready_20261016.zip)
- [Sobol与优化工程](../2026-10-16-sobol-optimization/URP_Sobol_Optimization_Updated.zip)

[四年冠层预览](four_year_CC_preview.png) · [六包核验](SIX_PACKAGE_VERIFICATION.json) · [校验码](SHA256SUMS.txt)

本轮完成四年图表重绘、论文与六包同步、2022原模型接入及基准/管理量检查；完整新Sobol/NSGA-III实验尚未完成，2019—2021原模型仍待接入。旧代理图仅留在历史审计中。文件名保留旧日期，内部版本均为2026-10-18。
''',encoding='utf-8')
for directory in [REPO/'deliverables',REPO/'deliverables/2026-10-16',REPO/'deliverables/2026-10-16-execution-ready',REPO/'deliverables/2026-10-16-sobol-optimization']:
 rows=[x for x in records if (REPO/x['path']).parent==directory]
 (directory/'SHA256SUMS.txt').write_text(''.join(x['sha256']+'  '+Path(x['path']).name+'\n' for x in rows))
wr(ROOT/'SIX_PACKAGE_VERIFICATION.json',report)
print('Six archives rebuilt; CRC, every file hash, and all 18 four-year figure pairs verified in every archive.',flush=True)
