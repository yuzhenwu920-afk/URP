"""Layout-only redraws of verified scientific plots for readable A4 Word pages."""
from pathlib import Path
import ast,json,shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch,FancyBboxPatch
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'package/figures_word';OUT.mkdir(exist_ok=True)
ART=Path('/workspace/urp_review/artifacts');T=ROOT/'package/tables'
PROJECT=Path('/workspace/URP/DI_PHASE3_NEXTGEN_UPDATED')
YEARS=[2019,2020,2021,2022]
COLORS={2019:'#0072B2',2020:'#D55E00',2021:'#009E73',2022:'#A85AA0'}
INK='#293844';GRAY='#7B8792';GRID='#E6EBEF'
NAMES=['CCx','CGC_CD','CDC_CD','SenescenceCD','Kcb','WP_early','WP_late','HI0']
TITLES={'CCx':'CCx（比例）','CGC_CD':'CGC（日⁻¹）','CDC_CD':'CDC（日⁻¹）','SenescenceCD':'衰老起始（日历日）',
        'Kcb':'Kcb（无量纲）','WP_early':'WP early（g/m²）','WP_late':'WP late（g/m²）','HI0':'HI0（比例）'}
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font_manager.fontManager.addfont(font)
plt.rcParams.update({'font.family':[font_manager.FontProperties(fname=font).get_name(),'DejaVu Sans'],
    'font.size':10.5,'axes.titlesize':12,'axes.labelsize':10.5,'xtick.labelsize':10.5,'ytick.labelsize':10.5,
    'legend.fontsize':10.5,'legend.frameon':False,'axes.spines.top':False,'axes.spines.right':False,
    'axes.linewidth':.7,'axes.edgecolor':'#84919B','grid.color':GRID,'grid.linewidth':.7,
    'figure.facecolor':'white','savefig.facecolor':'white','axes.unicode_minus':False,'pdf.fonttype':42})
def frame(n):return pd.read_csv(T/(n+'.csv'))
cases={};cal=frame('calibration_evidence_tiers');metrics=frame('calibration_metrics_recomputed');records=[]
for year in YEARS:
    src=ART/'four_year_source_data'/str(year)
    g=pd.read_csv(src/'Daily_growth.csv',parse_dates=['Date'])
    entry={'growth':g}
    for kind in ['CC','Biomass']:
        p=pd.read_csv(src/(kind+'_pairs.csv'),parse_dates=['Date'])
        if 'Included' in p:p=p[p.Included.astype(str).str.lower().eq('true')].copy()
        p=p.rename(columns={'Observed_CC':'CC_observed','canopy_cover':'CC_simulated',
                 'Observed_B_t_ha':'B_observed_t_ha','Biomass_t_ha':'B_simulated_t_ha'})
        sc,gc=('CC_simulated','canopy_cover') if kind=='CC' else ('B_simulated_t_ha','Biomass_t_ha')
        np.testing.assert_allclose(p[sc],g.set_index('Date').loc[p.Date,gc],atol=1e-10,rtol=0)
        entry[kind]=p
    cases[year]=entry

def panel_grid(height=6.6):
    fig,axes=plt.subplots(2,2,figsize=(6.65,6.0),layout='constrained')
    for ax,year in zip(axes.flat,YEARS):
        ax.set_title(str(year),loc='left',color=COLORS[year],fontweight='bold')
        ax.grid(alpha=.75);ax.set_axisbelow(True)
    return fig,axes

def save(fig,name,title,note,years=YEARS,role='current_four_year_evidence'):
    if fig.legends:
        for legend in fig.legends:legend.set_bbox_to_anchor((.5,1.0))
        rows=2 if max(len(x.get_texts()) for x in fig.legends)>4 else 1
        fig.set_layout_engine('constrained',rect=(0,0,1,1-(.70 if rows==2 else .45)/fig.get_figheight()))
    fig.canvas.draw()
    texts=[t for t in fig.findobj(matplotlib.text.Text) if t.get_visible() and t.get_text()]
    assert min(t.get_fontsize() for t in texts)>=10.49
    for ext in ['png','pdf']:fig.savefig(OUT/(name+'.'+ext),dpi=300,bbox_inches='tight',pad_inches=.08)
    records.append({'file':name+'.png','title':title,'years':list(years),'min_source_font_pt':min(t.get_fontsize() for t in texts)})
    plt.close(fig)

# Reuse only the plotting function definitions; source initialization and writes
# are deliberately excluded. Numeric arrays and source figures are unchanged.
tree=ast.parse(Path('/workspace/urp_visual_refresh_20261018/build_four_year_figures.py').read_text())
keep={'scatters','correlations','water','climate_and_roles','trace_panels'}
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and node.name in keep:
        exec(compile(ast.Module(body=[node],type_ignores=[]),'<verified plotting functions>','exec'),globals())

for name in ['midterm_CC_four_years','midterm_biomass_four_years']:
    original=Path('/workspace/urp_midterm_20261019/package/figures')
    target='F02_CC_trajectories' if name.startswith('midterm_CC') else 'F03_Biomass_trajectories'
    for ext in ['png','pdf']:shutil.copyfile(original/(name+'.'+ext),OUT/(target+'.'+ext))
    records.append({'file':target+'.png','years':YEARS,'min_source_font_pt':10,'note':'Reused verified A4 report layout, full original data.'})
scatters('CC');scatters('Biomass');correlations();water();climate_and_roles();trace_panels()

for mode in ['intervals','centers']:
    d=frame('parameter_intervals_verified' if mode=='intervals' else 'central_vectors_with_provenance')
    for half in range(2):
        fig,axes=plt.subplots(2,2,figsize=(6.65,5.6),layout='constrained')
        for ax,k in zip(axes.flat,NAMES[half*4:(half+1)*4]):
            for i,y in enumerate(YEARS):
                if mode=='intervals':
                    r=d[(d.Year==y)&(d.Parameter==k)].iloc[0]
                    ax.errorbar(i,r.Median,yerr=[[r.Median-r.P025],[r.P975-r.Median]],fmt='o',ms=5,
                        c=COLORS[y],capsize=3,lw=1.4)
                else:
                    ax.scatter(i,d.loc[d.Year==y,k].iloc[0],c=COLORS[y],s=35,zorder=4)
            if mode=='centers':ax.plot(range(4),d.sort_values('Year')[k],ls='--',lw=.8,c='#AAB5BD')
            ax.set(title=TITLES[k],xticks=range(4),xticklabels=YEARS,xlim=(-.4,3.4));ax.grid(axis='y');ax.set_axisbelow(True)
        name=('F07_parameter_intervals' if mode=='intervals' else 'F17_parameter_centers')+('_a' if half==0 else '_b')
        save(fig,name,'参数区间' if mode=='intervals' else '年度参数中心','同一源表，分上下组以保留印刷字号。')

(ROOT/'package/WORD_FIGURE_LAYOUTS.json').write_text(json.dumps({'date':'2026-10-19','years':YEARS,
    'note':'Layout-only scientific redraws; no smoothing, invented observations, or new calibration/optimization.',
    'figures':records},ensure_ascii=False,indent=2),encoding='utf-8')
print('Word layouts:',len(records),'verified figure files; originals kept separately.')
