# 全部英文图表与逐图解析

保留此前43组英文图、源表、解析和重绘脚本；本轮新增图位于Final_revision。旧论文骨架与旧说明保留日期，当前最终论文见12号。R02确认来自R02_Sobol_Yield_CI，采用明确S1/ST和bootstrap数值区间，不臆造cat/coc变量。
