# URP全套英文图逐图解析

## 1. F02_CC_trajectories_EN

Figure 2. Simulated daily canopy cover (solid lines) and calibration data (open circles) for (a) 2019, (b) 2020, (c) 2021 and (d) 2022. Days after planting follow the model DAP field. R²cal = 1 − SSE/SST and RMSE are calculated at paired calibration dates; these are in-sample assessments. Lines are trajectories at frozen parameter centers, not posterior predictive means or uncertainty intervals.

解析：共48对；年度校准R²为0.931–0.993，RMSE为0.032–0.060（比例）。2022相对较弱。

边界：田间LAI转换CC属于校准数据；曲线为冻结参数中心的确定性轨迹，不是后验预测均值或区间。

源表：F02_CC_calibration_pairs.csv, Calibration_daily_growth.csv, Calibration_metrics.csv

图像：11_English_figures_tables_and_interpretations/figures/F02_CC_trajectories_EN.png

## 2. F05_Biomass_pairs_EN

Figure 5. Paired observed and simulated aboveground dry biomass in (a) 2019, (b) 2020, (c) 2021 and (d) 2022. The dashed line denotes 1:1 agreement. R²cal = 1 − SSE/SST; RMSE is in t ha⁻¹. The 37 pairs are calibration data, including digitized records with source-specific assumed errors; the plot is not an independent validation.

解析：四年共37对；R²cal为0.969–0.997，RMSE为0.556–1.252 t ha⁻¹。

边界：含数字化生物量及假定误差尺度；所有配对为样本内校准，未构成独立验证。

源表：F05_Biomass_calibration_pairs.csv, Calibration_metrics.csv

图像：11_English_figures_tables_and_interpretations/figures/F05_Biomass_pairs_EN.png

## 3. F07_parameter_intervals_EN

Figure 7. Marginal distributions of retained stage-specific MCMC samples for eight parameters during 2019–2022. Colored points and bars show medians and the 2.5th–97.5th sample percentiles; gray ranges indicate year-specific prior supports. Stage 2 is conditional on the fixed stage 1 handoff. These intervals neither certify convergence nor demonstrate absence of boundary effects. Boundary-band masses are reported separately.

解析：2019/2020 CCx在上界1%支持宽度内的样本质量约22.14%/23.06%；2020/2021早期WP下界附近约11.43%/23.65%。

边界：2.5%–97.5%为相关保留样本的经验分位区间；阶段二条件于阶段一交接点，不是经认证的八维联合后验。

源表：F07_parameter_intervals_and_boundary_mass.csv

图像：11_English_figures_tables_and_interpretations/figures/F07_parameter_intervals_EN.png

## 4. S02_parameter_boundary_mass_EN

Supplementary Figure S2. Percentage of retained draws within the lower or upper 1% of each year-specific prior-support width. The band width is a descriptive diagnostic choice, not a significance threshold. No out-of-support draws is distinct from no concentration near a boundary; substantial near-boundary mass is retained and reported.

解析：上/下界邻近带定义为各年支持宽度的1%；高质量集中见CCx及早期WP。

边界：1%带宽是描述选择，不是显著性阈值；不把无越界等同无边界影响。

源表：F07_parameter_intervals_and_boundary_mass.csv

图像：11_English_figures_tables_and_interpretations/figures/S02_parameter_boundary_mass_EN.png

## 5. S01_MCMC_stage1_diagnostics_EN

Supplementary Figure S1. Existing rank-normalized R-hat and bulk ESS summaries for stage 1, recomputed in the previous source audit. The original strict diagnostic criteria are not met. Retained draw counts are not effective sample sizes. No long-chain extension is performed as part of this figure revision; stage 2 single-ensemble limitations are listed in the sampling table.

解析：既有阶段一未通过原严格R-hat/ESS条件；相关保留样本虽多，有效信息量仍受自相关和ensemble差异影响。

边界：热图只反映已有诊断记录，不是本轮新长链实验。

源表：MCMC_existing_diagnostics.csv, MCMC_existing_sampling_groups.csv

图像：11_English_figures_tables_and_interpretations/figures/S01_MCMC_stage1_diagnostics_EN.png

## 6. F09_annual_water_budget_EN

Figure 9. Annual water-budget components for the calibrated DI baseline during 2019–2022. Inflow is irrigation plus precipitation; capillary and groundwater inputs are zero in these runs. Outflow comprises evapotranspiration, runoff, deep percolation and tile drainage. Storage denotes the absolute end-of-season soil-profile plus surface water storage. Water-balance closure is assessed as inflow − outflow = final storage − initial storage, not as inflow − outflow = final storage. Lines connect annual summaries for comparison and do not represent a statistical trend test.

解析：2021基准季末土壤水约705.7 mm，比初始增加约170.0 mm；其他年度初末变化不同。四年水量残差在数值精度范围内。

边界：年际连线不是趋势检验。土壤剖面总储水不等于作物根系可利用水。

源表：F09_annual_water_budget.csv

图像：11_English_figures_tables_and_interpretations/figures/F09_annual_water_budget_EN.png

## 7. S03_annual_water_storage_change_EN

Supplementary Figure S3. Annual inflow, outflow and signed storage change (ΔS = final − initial storage). The three components satisfy inflow − outflow = ΔS within numerical precision. Positive ΔS indicates net storage gain. This is the change-in-storage companion to the absolute-storage version of Figure 9.

解析：2021基准季末土壤水约705.7 mm，比初始增加约170.0 mm；其他年度初末变化不同。四年水量残差在数值精度范围内。

边界：年际连线不是趋势检验。土壤剖面总储水不等于作物根系可利用水。

源表：F09_annual_water_budget.csv

图像：11_English_figures_tables_and_interpretations/figures/S03_annual_water_storage_change_EN.png

## 8. R01_Sobol_four_outputs_2x2_EN

Figure R1. Total-effect Sobol indices for (a) grain yield at 13% moisture, (b) aboveground dry biomass, (c) seasonal evapotranspiration and (d) maximum canopy cover. Each cell is the mean of three N=512 scrambles within a year, using the same eight independent uniform parameter ranges. One color scale is used throughout. Rank agreement and variation in index magnitude are assessed separately; indices are not normalized to sum to one. Transpiration and soil evaporation are retained in Supplementary Figure S5.

解析：产量以晚期WP和HI0为主；生物量以晚期/早期WP和Kcb为主；ET以Kcb为主；最大CC以CCx为主。四主输出年度均值排序的Kendall W均为1。

边界：只有四个年度模拟情景；2022产量早期WP/Kcb在种子层面近似并列，年度均值相同排序不消除该不确定性。

源表：Sobol_all_seed_indices.csv, Sobol_annual_means_and_ranks.csv

图像：11_English_figures_tables_and_interpretations/figures/R01_Sobol_four_outputs_2x2_EN.png

## 9. S05_Sobol_Tr_Es_EN

Supplementary Figure S5. Annual mean total-effect indices for transpiration and soil evaporation. All six original model outputs are retained in the source tables; these two outputs supplement the four primary-output panels in Figure R1.

解析：Tr平均ST以Kcb约0.578为首；Es以CCx约0.718为首。两者对同一参数的贡献大小不同。

边界：水分分量的ST是不同输出方差的归一化比，不能相加成ET的ST。

源表：Sobol_all_seed_indices.csv, Sobol_annual_means_and_ranks.csv

图像：11_English_figures_tables_and_interpretations/figures/S05_Sobol_Tr_Es_EN.png

## 10. R02_Sobol_Yield_all_years_mean_EN

Figure R2. Four-year yield sensitivity shown together as (a) first-order and (b) total-effect indices. Colored symbols are annual means across three independent scrambles; black diamonds are equal-weight means across the four annual estimates. Gray segments show the annual minimum–maximum range, not confidence intervals. A four-year mean summarizes these simulation contexts and is not a pooled climate-mixture Sobol index or proof of year-invariant sensitivity. Within-year numerical intervals are retained in Supplementary Figure S4.

解析：晚期WP、HI0、早期WP、Kcb的四年ST均值约0.396、0.206、0.164、0.145；晚期WP年度范围约0.353–0.426。

边界：灰线是年际最小—最大范围而非置信区间；先年内平均3个scramble，再四年各1/4加权，不等于混合气候下重新计算Sobol。原图已由用户确认为R02_Sobol_Yield_CI，按S1/ST与数值区间呈现。

源表：Sobol_annual_means_and_ranks.csv, Sobol_four_year_descriptive_means.csv

图像：11_English_figures_tables_and_interpretations/figures/R02_Sobol_Yield_all_years_mean_EN.png

## 11. S04_Sobol_yield_numerical_intervals_EN

Supplementary Figure S4. Total-effect yield indices from three N=512 scrambles per year, with 95% bootstrap half-widths based on 512 resamples. Open diamonds show the within-year scramble mean of S1. The early-WP/Kcb ordering remains numerically uncertain in 2022. This numerical uncertainty is distinct from between-year sensitivity variation. Negative finite-sample S1 values are not set to zero.

解析：N=512、每年3个scramble、512次bootstrap；24项筛查23项通过。2022产量早期WP与Kcb的ST均约0.139，排名随种子互换。

边界：这里的95%区间不是田间产量预测区间，S1有限样本负值不强制改零。

源表：Sobol_all_seed_indices.csv, Sobol_numerical_stability.csv

图像：11_English_figures_tables_and_interpretations/figures/S04_Sobol_yield_numerical_intervals_EN.png

## 12. R03_full_range_diagnostic_2x2_EN

Supplemental full-range diagnostic. Solid lines are nondominated best-found actual model evaluations from three NSGA-III searches per year (80 individuals × 60 generations), using frozen yearly parameter centers and four fixed-date irrigation windows. The original 95% observed-yield gate is removed for these searches; the dotted line is shown only as a reference. Gray dashed curves scale the original event amounts proportionally and are not optimized fronts. Open circles show zero irrigation; stars show original DI model baselines. This conditional model reference is separate from field validation and from the gated main optimization.

解析：移除产量门槛的补充搜索共57,600次；四年零灌溉产量约9.071、6.184、6.140、5.850 t ha⁻¹，均明显低于DI。

边界：仅补充诊断取消95%门槛；仍保留灌水上限，未新增储水约束。没有零灌溉田间验证，也未证明全局最优。

源表：Full_range_best_found_front.csv, Fixed_proportion_dose_response.csv, Zero_irrigation_reference.csv

图像：11_English_figures_tables_and_interpretations/figures/R03_full_range_diagnostic_2x2_EN.png

## 13. N01_Optimized_yield_irrigation_EN

New figure. Best-found full-range yield–irrigation trade-offs from supplemental actual-model NSGA-III searches. Each curve is an upper nondominated envelope, not the response of a single fixed irrigation pattern or a proven global optimum. Zero-irrigation and original DI baselines are shown explicitly. Initial soil water, rainfall, climate and parameter centers remain year specific; terminal storage and per-event delivery limits are not additional constraints in these searches.

解析：移除产量门槛的补充搜索共57,600次；四年零灌溉产量约9.071、6.184、6.140、5.850 t ha⁻¹，均明显低于DI。

边界：仅补充诊断取消95%门槛；仍保留灌水上限，未新增储水约束。没有零灌溉田间验证，也未证明全局最优。

源表：Full_range_best_found_front.csv, Zero_irrigation_reference.csv

图像：11_English_figures_tables_and_interpretations/figures/N01_Optimized_yield_irrigation_EN.png

## 14. R04_right_yield_comparison_EN

Observed yields are the values reported in the source study; DI baseline and selected-candidate yields are simulations at frozen annual parameter centers. Candidates minimize irrigation within the NSGA-III union subject to the DI irrigation cap and Y13 ≥ 0.95 Yobs. Dotted segments mark this deterministic yield constraint, not confidence intervals. Symbols are offset horizontally within each year for readability. Candidate colors consistently denote 2019, 2020, 2021 and 2022. Lower irrigation does not imply an equal reduction in ET; terminal soil storage is reported separately.

解析：四年候选灌水约218.36、312.42、267.30、260.78 mm，较DI减少50.96%、44.19%、57.80%、35.58%。产量接近95%观测门槛。

边界：95%虚线不是置信区间。减少灌水不能直接写为等幅减少ET或无条件节水不减产。

源表：R04_yield_comparison.csv

图像：11_English_figures_tables_and_interpretations/figures/R04_right_yield_comparison_EN.png

## 15. R04_irrigation_yield_comparison_EN

Panel (a): percentages are reductions in applied irrigation relative to the original annual DI schedule, not consumptive-water savings or a demonstrated sustainable water-saving rate. Observed yields are the values reported in the source study; DI baseline and selected-candidate yields are simulations at frozen annual parameter centers. Candidates minimize irrigation within the NSGA-III union subject to the DI irrigation cap and Y13 ≥ 0.95 Yobs. Dotted segments mark this deterministic yield constraint, not confidence intervals. Symbols are offset horizontally within each year for readability. Candidate colors consistently denote 2019, 2020, 2021 and 2022. Lower irrigation does not imply an equal reduction in ET; terminal soil storage is reported separately.

解析：四年候选灌水约218.36、312.42、267.30、260.78 mm，较DI减少50.96%、44.19%、57.80%、35.58%。产量接近95%观测门槛。

边界：95%虚线不是置信区间。减少灌水不能直接写为等幅减少ET或无条件节水不减产。

源表：R04_yield_comparison.csv, R03_irrigation_ET_storage_tradeoff.csv

图像：11_English_figures_tables_and_interpretations/figures/R04_irrigation_yield_comparison_EN.png

## 16. R03_Gated_Pareto_fronts_EN

English reconstruction of the supplied R03 from its canonical 3,986 final feasible Pareto records. Colored points show NSGA-III results; solid and dashed curves are nondominated unions across five seeds for NSGA-III and NSGA-II, respectively (100 individuals × 100 generations per seed). Each panel uses its own zoomed axes and includes only yield-gated feasible points, not the full dose response. Zero-irrigation yields fall below the gate in every year and therefore are absent. Stars are model baselines, not observations. Open circles are minimum-irrigation selections from the gated NSGA-III union, not geometric knee points. Use the separate full-range figure to interpret the omitted low-irrigation region.

解析：3,986条最终可行记录；NSGA-II/III前沿基本重合。2021可行产量约15.067–15.251 t ha⁻¹，独立纵轴截取使曲线显得陡。

边界：零灌溉被产量门槛排除；圈点不是几何膝点。曲线是搜索得到的非支配包络，未证明全局最优。

源表：Original_main_NSGA_all_seed_Pareto_points.csv, R04_yield_comparison.csv

图像：11_English_figures_tables_and_interpretations/figures/R03_Gated_Pareto_fronts_EN.png

## 17. S07_Irrigation_reduction_decomposition_EN

Irrigation reduction equals lower ET plus the difference in final soil storage and lower runoff/drainage, because rainfall, initial soil water, other inflows and changes in surface storage match within each annual baseline–candidate pair. The storage term is the baseline final storage minus candidate final storage. It includes avoided baseline recharge and/or additional depletion and is not wholly attributable to soil-water mining. In 2021, baseline storage increases by about 170.0 mm whereas candidate storage decreases by about 186.7 mm; their 356.7 mm difference accounts for 97.4% of the irrigation reduction. Bars do not demonstrate long-term sustainability; terminal storage was not constrained in the original optimization.

解析：2021少灌366.2 mm，其中ET仅少8.6 mm，季末储水差356.7 mm，解释97.4%的减灌水量；四年储水项占比约83%–97%。

边界：不能把整个储水差都叫土壤水透支；无季末储水限制的单季方案不能保证跨季可持续。

源表：R03_irrigation_ET_storage_tradeoff.csv, Original_main_Water_ledger_baseline_and_candidate.csv

图像：11_English_figures_tables_and_interpretations/figures/S07_Irrigation_reduction_decomposition_EN.png

## 18. Figure1_three_column_EN

Three-column workflow linking original inputs, grouped conditional MCMC calibration, independent-range Sobol analysis, two-objective irrigation optimization and candidate checks. MCMC samples remain frozen and their diagnostic limitations are retained.

解析：四年原模型已接入；MCMC冻结；正式Sobol为N=512×3种子；双算法优化各100个体×100代×5种子。

边界：流程完成不表示采样诊断全部通过，也不表示参数不确定性已在寻优中传播。

源表：

图像：11_English_figures_tables_and_interpretations/figures/Figure1_three_column_EN.png

## 19. Figure1_tree_EN

Alternative tree layout of the same four-year workflow. This is an alternative to the three-column version and should not be inserted twice into the main manuscript.

解析：四年原模型已接入；MCMC冻结；正式Sobol为N=512×3种子；双算法优化各100个体×100代×5种子。

边界：流程完成不表示采样诊断全部通过，也不表示参数不确定性已在寻优中传播。

源表：

图像：11_English_figures_tables_and_interpretations/figures/Figure1_tree_EN.png

## 20. Figure10_environment_EN

Daily reference evapotranspiration and precipitation over the actual model calendar in 2019–2022. Lines and bars retain the exact source dates and values, with consistent axis limits across years. Reference evapotranspiration is distinct from simulated actual crop evapotranspiration.

解析：模型日历合计599天；四年降雨分别约177.9、113.5、143.3、151.4 mm。逐日ETo与降雨保持源值，不插值或按年缩放。

边界：仅四个年度情景；气象差异与参数、初始水差异并存，不能由本图识别单一气候因果效应。

源表：Figure10_daily_environment.csv, Figure10_window_summary.csv

图像：11_English_figures_tables_and_interpretations/figures/Figure10_environment_EN.png

## 21. F03_Biomass_trajectories_EN

Daily aboveground dry biomass at frozen annual parameter centers and the 37 paired calibration observations. These trajectories are deterministic simulations, not posterior predictive means. Errors are in-sample calibration metrics.

解析：四年共37对；R²cal为0.969–0.997，RMSE为0.556–1.252 t ha⁻¹。

边界：含数字化生物量及假定误差尺度；所有配对为样本内校准，未构成独立验证。

源表：Calibration_daily_growth.csv, F05_Biomass_calibration_pairs.csv, Calibration_metrics.csv

图像：11_English_figures_tables_and_interpretations/figures/F03_Biomass_trajectories_EN.png

## 22. F04_CC_pairs_EN

Observed and simulated canopy cover at the same 48 calibration dates. Dashed lines indicate 1:1 agreement. R²cal = 1 − SSE/SST is computed against observations without refitting a regression. This is an alternative display to F02, not independent validation.

解析：共48对；年度校准R²为0.931–0.993，RMSE为0.032–0.060（比例）。2022相对较弱。

边界：田间LAI转换CC属于校准数据；曲线为冻结参数中心的确定性轨迹，不是后验预测均值或区间。

源表：F02_CC_calibration_pairs.csv, Calibration_metrics.csv

图像：11_English_figures_tables_and_interpretations/figures/F04_CC_pairs_EN.png

## 23. F06_calibration_summary_EN

Canopy-cover and biomass RMSE are calculated from paired calibration dates. Grain-yield bias compares the annual model baseline with published observations. The ±5% shaded band is a descriptive project tolerance, not a confidence interval or independent validation.

解析：2022冠层RMSE最高，但生物量RMSE最低；不同输出的拟合优劣不必一致。年度籽粒产量偏差约−4.18%至+0.92%。

边界：±5%灰带是项目容许幅度，不是统计置信区间；年产量每年只有一个观测终值。

源表：F06_calibration_summary_EN.csv, Calibration_metrics.csv, observed_yield_gate_headroom.csv

图像：11_English_figures_tables_and_interpretations/figures/F06_calibration_summary_EN.png

## 24. F08_phase2_compensation_EN

Late WP and HI0 are taken from the same retained stage-2 sample rows. Correlations use every retained row; points are evenly thinned for display. Association indicates conditional parameter compensation and is not a causal relationship or proof of convergence.

解析：HI0与晚期WP的Pearson r依次为-0.871、-0.595、-0.463、-0.645，均呈负相关。

边界：r使用同一行的全部保留样本计算，散点只为显示抽稀；不推断因果，不用该图认证收敛。

源表：F08_phase2_correlation.csv, F08_displayed_same_row_samples.csv

图像：11_English_figures_tables_and_interpretations/figures/F08_phase2_compensation_EN.png

## 25. F14_phase2_trace_WP_early_EN

Only the retained segment of the original stage-2 ensemble is shown. The line is the median across 32 walkers at each step; shading is the 10th–90th walker-percentile range, not a posterior confidence band or an independent-chain convergence certificate.

解析：四年均完整保留；线为每步32个walker的中位数，浅带为10%–90%分位。图从原步号展示，仅保留段有值。

边界：阴影不是参数均值置信区间，也不是独立链间一致性证据；本轮没有延长原链。

源表：F14_F16_phase2_trace_summaries.csv, sampling_group_summary.csv

图像：11_English_figures_tables_and_interpretations/figures/F14_phase2_trace_WP_early_EN.png

## 26. F15_phase2_trace_WP_late_EN

Only the retained segment of the original stage-2 ensemble is shown. The line is the median across 32 walkers at each step; shading is the 10th–90th walker-percentile range, not a posterior confidence band or an independent-chain convergence certificate.

解析：四年均完整保留；线为每步32个walker的中位数，浅带为10%–90%分位。图从原步号展示，仅保留段有值。

边界：阴影不是参数均值置信区间，也不是独立链间一致性证据；本轮没有延长原链。

源表：F14_F16_phase2_trace_summaries.csv, sampling_group_summary.csv

图像：11_English_figures_tables_and_interpretations/figures/F15_phase2_trace_WP_late_EN.png

## 27. F16_phase2_trace_HI0_EN

Only the retained segment of the original stage-2 ensemble is shown. The line is the median across 32 walkers at each step; shading is the 10th–90th walker-percentile range, not a posterior confidence band or an independent-chain convergence certificate.

解析：四年均完整保留；线为每步32个walker的中位数，浅带为10%–90%分位。图从原步号展示，仅保留段有值。

边界：阴影不是参数均值置信区间，也不是独立链间一致性证据；本轮没有延长原链。

源表：F14_F16_phase2_trace_summaries.csv, sampling_group_summary.csv

图像：11_English_figures_tables_and_interpretations/figures/F16_phase2_trace_HI0_EN.png

## 28. F17_parameter_centers_EN

Arithmetic means of retained stage-specific parameter samples used as deterministic annual centers. Stage 2 is conditional on the stage-1 handoff; these eight values do not define a certified joint posterior mean. Connecting lines aid annual comparison without establishing temporal trends.

解析：晚期WP中心依次为30.58、25.85、21.94、31.50 g m⁻²；各年中心与原冻结文件一致。

边界：拼接阶段均值不构成完整联合后验的数学均值；年度虚线只是视觉连接。

源表：central_vectors_with_provenance.csv

图像：11_English_figures_tables_and_interpretations/figures/F17_parameter_centers_EN.png

## 29. F11_CC_evidence_roles_EN

The field LAI-derived DI canopy-cover series enters calibration. Remote-sensing CCquad is converted from percent to fraction and shown only as auxiliary evidence. The 2019–2021 remote-sensing records refer to BI and the 2022 treatment metadata are incomplete; none is relabeled as independent DI validation.

解析：田间DI序列用于校准；遥感未入似然，2019–2021为BI标签，2022处理标签不完整。

边界：遥感CCquad由百分数转比例；横轴为模型起点后的日数，不能混用未经核实的物候日期。

源表：F11_evidence_series_EN.csv

图像：11_English_figures_tables_and_interpretations/figures/F11_CC_evidence_roles_EN.png

## 30. F12_sampling_record_EN

Each original ensemble used 32 walkers and 2,000 raw steps. Stage 1 has four ensembles per year and stage 2 has one. The dashed 50-IAT line is only a length reference, not proof of convergence; correlated retained-row counts must not be reported as effective sample sizes.

解析：原ensemble均为32 walkers、2,000步；阶段一每年4个ensemble，阶段二每年1个；阶段一长度不足50τ参考。

边界：walker不等于独立链；保留行数不等于ESS。阶段二不能仅因超过50τ就宣称完成严格收敛诊断。

源表：sampling_group_summary.csv, MCMC_existing_diagnostics.csv

图像：11_English_figures_tables_and_interpretations/figures/F12_sampling_record_EN.png

## 31. F09_water_ledger_EN

English version of the original two-column water ledger, retained as a supplementary alternative to the annual three-line F09. Inflow plus depletion equals outflow plus storage gain. Net storage change is final minus initial storage, not the absolute final storage.

解析：2021基准季末土壤水约705.7 mm，比初始增加约170.0 mm；其他年度初末变化不同。四年水量残差在数值精度范围内。

边界：年际连线不是趋势检验。土壤剖面总储水不等于作物根系可利用水。

源表：F09_annual_water_budget.csv

图像：11_English_figures_tables_and_interpretations/figures/F09_water_ledger_EN.png

## 32. F13_yield_gate_EN

English reconstruction of the original F13 yield-gate figure. The gate is 95% of published observed grain yield. Headroom is the allowable yield decrease relative to the model baseline, not an irrigation-saving rate. This does not assign meanings to the unresolved labels Y_catmul and Y_tot.

解析：2021模型基准约15.197，95%观测门槛15.067 t ha⁻¹，相对模型基准可下降余量仅约0.86%。

边界：这是原F13门槛图英文化，尚未把Y_catmul或Y_tot映射为任何未经确认的列；N02另给明确变量名的回归图。

源表：observed_yield_gate_headroom.csv

图像：11_English_figures_tables_and_interpretations/figures/F13_yield_gate_EN.png

## 33. R01_Sobol_ST_Y_13pct_EN

Annual mean total-effect sensitivity for grain yield at 13% moisture, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

解析：四年等权ST描述均值前三位：WP_late 0.396；HI0 0.206；WP_early 0.164。

边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

源表：Sobol_all_seed_indices.csv

图像：11_English_figures_tables_and_interpretations/figures/R01_Sobol_ST_Y_13pct_EN.png

## 34. R01_Sobol_ST_B_t_ha_EN

Annual mean total-effect sensitivity for aboveground dry biomass, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

解析：四年等权ST描述均值前三位：WP_late 0.503；WP_early 0.207；Kcb 0.180。

边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

源表：Sobol_all_seed_indices.csv

图像：11_English_figures_tables_and_interpretations/figures/R01_Sobol_ST_B_t_ha_EN.png

## 35. R01_Sobol_ST_Tr_mm_EN

Annual mean total-effect sensitivity for seasonal transpiration, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

解析：四年等权ST描述均值前三位：Kcb 0.578；CCx 0.227；CGC_CD 0.180。

边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

源表：Sobol_all_seed_indices.csv

图像：11_English_figures_tables_and_interpretations/figures/R01_Sobol_ST_Tr_mm_EN.png

## 36. R01_Sobol_ST_Es_mm_EN

Annual mean total-effect sensitivity for seasonal soil evaporation, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

解析：四年等权ST描述均值前三位：CCx 0.718；CGC_CD 0.267；SenescenceCD 0.022。

边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

源表：Sobol_all_seed_indices.csv

图像：11_English_figures_tables_and_interpretations/figures/R01_Sobol_ST_Es_mm_EN.png

## 37. R01_Sobol_ST_ET_mm_EN

Annual mean total-effect sensitivity for seasonal evapotranspiration, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

解析：四年等权ST描述均值前三位：Kcb 0.837；CGC_CD 0.102；CCx 0.059。

边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

源表：Sobol_all_seed_indices.csv

图像：11_English_figures_tables_and_interpretations/figures/R01_Sobol_ST_ET_mm_EN.png

## 38. R01_Sobol_ST_MaxCC_EN

Annual mean total-effect sensitivity for maximum canopy cover, averaged over three independent N=512 scrambles. All years use the same eight independent uniform parameter ranges and the same 0–1 color scale. Values are not normalized to sum to one. This individual panel is an alternative to the combined R01/S05 displays.

解析：四年等权ST描述均值前三位：CCx 0.911；CGC_CD 0.097；Kcb 0.001。

边界：这是公共独立均匀范围的Sobol，不是相关MCMC后验敏感性；ST不要求加和为1。本图是合并图的单输出备选。

源表：Sobol_all_seed_indices.csv

图像：11_English_figures_tables_and_interpretations/figures/R01_Sobol_ST_MaxCC_EN.png

## 39. R05_Actual_irrigation_schedules_EN

Actual event amounts are compared at original annual irrigation dates. Decisions redistribute totals across four ordered windows while preserving baseline proportions within each window. No irrigation dates are optimized. Planned amounts canceled after crop termination are retained separately in the source table.

解析：原事件数为8、8、7、5；2020主候选单次最大量约179.9 mm。日期固定，调整的是窗口总水量及相应事件水量。

边界：原始逐次记录才是实际用水，提前结束后取消的计划水量另列；需核实设施和入渗能力才能实施。

源表：NSGA_event_schedules.csv

图像：11_English_figures_tables_and_interpretations/figures/R05_Actual_irrigation_schedules_EN.png

## 40. R06_Seeded_convergence_EN

Each algorithm used 100 individuals × 100 generations × five seeds per year. Curves show seed medians and shading shows minimum–maximum seed ranges, not confidence intervals. Hypervolume uses annual observed yield and DI irrigation for normalization and reference point [0, 1.01]. Compare algorithms within a year; convergence histories do not prove a global optimum.

解析：40次搜索共400,000次评估、4,000代记录；逐年并集HV相对差异绝对值小于0.07%，没有NSGA-III明显优越性的证据。

边界：阴影是5种子最小—最大范围，不是置信区间。不同年份HV归一化背景不同，不横向排名算法性能。

源表：NSGA_convergence_history.csv, NSGA_algorithm_comparison.csv

图像：11_English_figures_tables_and_interpretations/figures/R06_Seeded_convergence_EN.png

## 41. R07_Conditional_candidate_checks_EN

Each group uses 128 whole-row draws from one retained stage-specific sample pool while fixing the other group at its center. Left intervals describe Monte Carlo sampling uncertainty conditional on that empirical pool, not field failure probability or original MCMC uncertainty. These are not joint eight-parameter posterior draws; 128 perturbations are not 128 effective posterior samples. Right dotted marks are deterministic yield gates.

解析：四个主候选的组内门槛达标比例约0.281–0.555，Q05均低于相应门槛；仅中心点达标不代表扰动后高达标率。

边界：每次只扰动一个阶段并固定另一个；Wilson区间仅描述给定经验池的重采样误差，不是田间失败概率，未含原链和模型结构误差。

源表：NSGA_conditional_validation.csv, NSGA_main_candidates.csv

图像：11_English_figures_tables_and_interpretations/figures/R07_Conditional_candidate_checks_EN.png

## 42. R09_Terminal_storage_screening_EN

Dark bars are minimum-irrigation points among already evaluated feasible solutions satisfying final storage at least equal to the original DI baseline; selected points were replayed. This is post hoc filtering, not a new storage-constrained optimization or proof of infeasibility/optimality. The baseline final storage is a sensitivity scenario, not an established agronomic sustainability target.

解析：事后筛选要求季末储水不低于DI时，既有点中四年减灌比例约8.75%、0.56%、0.23%、7.01%，明显小于原主候选。

边界：原DI季末值不自动等于合理可持续标准；未找到既有点不等于证明不可行。

源表：Terminal_storage_screening.csv, NSGA_main_candidates.csv, Water_ledger_baseline_and_candidate.csv

图像：11_English_figures_tables_and_interpretations/figures/R09_Terminal_storage_screening_EN.png

## 43. N02_Biomass_regression_EN

Additional regression using all 37 biomass calibration pairs from 2019–2022. X is simulated and Y is observed aboveground dry biomass, explicitly named rather than mapped to unresolved Y_catmul/Y_tot labels. OLS R² is calculated after fitting an intercept and differs from the 1:1 calibration R² used in F05. Pearson r describes association. Pooling repeated observations across years can inflate apparent agreement; no independent-observation p-value or validation claim is made.

解析：37对数据的OLS R²=0.9892，Pearson r=0.9946；横轴模拟生物量，纵轴观测生物量。

边界：含年内重复日期和跨年合并效应，未给独立样本显著性推断；OLS R²与F05的1:1校准R²不同。未擅自解释Y_catmul/Y_tot。

源表：F05_Biomass_calibration_pairs.csv, N02_Biomass_regression_summary.csv

图像：11_English_figures_tables_and_interpretations/figures/N02_Biomass_regression_EN.png

## 44. F13_Pooled_biomass_regression_EN

Pooled four-year biomass regression, using all 37 calibration pairs. Observed biomass is on the horizontal axis and simulated biomass on the vertical axis. The solid line is an ordinary least-squares fit; the dashed line is 1:1. OLS R² and Pearson r describe association, not independent validation; repeated dates occur within years. Digitized biomass retains its source uncertainty.

解析：四年37个生物量配对；横轴观测、纵轴模拟，OLS与1:1关系分开。R²和Pearson r反映配对关联，不是独立验证。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：F05_Biomass_calibration_pairs.csv, Pooled_biomass_OLS_summary.csv

图像：11_English_figures_tables_and_interpretations/Final_revision/figures/F13_Pooled_biomass_regression_EN.png

## 45. R02_Sobol_Yield_CI_Four_years_and_mean_EN

Yield sensitivity across 2019–2022. Colored symbols are means over three independently scrambled N=512 Saltelli designs. Error bars are approximate 95% numerical bootstrap intervals for that three-scramble mean, obtained by independently resampling complete A/AB/B base blocks within each scramble (512 resamples; normal half-width 1.96 SD). Diamonds are equal-weight four-year means; gray segments show the across-year minimum–maximum, not a confidence interval. These are independent-uniform-input Sobol estimates, not correlated-posterior indices or field predictive intervals.

解析：四年S1/ST及数值bootstrap区间合并，保留四年等权均值和年际范围；完整响应块重采样，无新增模型调用。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：Sobol_all_seed_indices.csv, R02_annual_scramble_mean_bootstrap.csv, R02_complete_block_bootstrap_replicates.npz

图像：11_English_figures_tables_and_interpretations/Final_revision/figures/R02_Sobol_Yield_CI_Four_years_and_mean_EN.png

## 46. R03_Pareto_four_years_annotated_EN

Four-year full-range, best-found NSGA-III Pareto envelopes. Blue dashed curves join nondominated archived solutions; red dots highlight exact evaluated controls. Labels give rounded allocations (W1, W2, W3, W4; mm), in fixed irrigation-date windows, not soil-moisture thresholds. Stars are original DI model baselines. The 95% observed-yield line is a reference only: it was removed as a constraint for this supplemental full-range search (3 seeds × 80 individuals × 60 generations per year; 57,600 evaluations in total). Four-year historical settings are Zmax=2.30 m and fMulch=0, with 75% cover. The original 400,000-evaluation gated experiment is separate. Curves are finite-search envelopes, not proven optima or independently validated field responses.

解析：按示例的蓝虚线、红点和四窗口水量标签整理。采用四年历史参数的全范围补充搜索，不能混称根深1m重校准或正式有门槛搜索。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：Full_range_best_found_front.csv, Pareto_display_points.csv

图像：11_English_figures_tables_and_interpretations/Final_revision/figures/R03_Pareto_four_years_annotated_EN.png

## 47. R03_Pareto_2019_annotated_EN

Four-year full-range, best-found NSGA-III Pareto envelopes. Blue dashed curves join nondominated archived solutions; red dots highlight exact evaluated controls. Labels give rounded allocations (W1, W2, W3, W4; mm), in fixed irrigation-date windows, not soil-moisture thresholds. Stars are original DI model baselines. The 95% observed-yield line is a reference only: it was removed as a constraint for this supplemental full-range search (3 seeds × 80 individuals × 60 generations per year; 57,600 evaluations in total). Four-year historical settings are Zmax=2.30 m and fMulch=0, with 75% cover. The original 400,000-evaluation gated experiment is separate. Curves are finite-search envelopes, not proven optima or independently validated field responses.

解析：按示例的蓝虚线、红点和四窗口水量标签整理。采用四年历史参数的全范围补充搜索，不能混称根深1m重校准或正式有门槛搜索。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：Pareto_display_points.csv

图像：11_English_figures_tables_and_interpretations/Final_revision/figures/R03_Pareto_2019_annotated_EN.png

## 48. R03_Pareto_2020_annotated_EN

Four-year full-range, best-found NSGA-III Pareto envelopes. Blue dashed curves join nondominated archived solutions; red dots highlight exact evaluated controls. Labels give rounded allocations (W1, W2, W3, W4; mm), in fixed irrigation-date windows, not soil-moisture thresholds. Stars are original DI model baselines. The 95% observed-yield line is a reference only: it was removed as a constraint for this supplemental full-range search (3 seeds × 80 individuals × 60 generations per year; 57,600 evaluations in total). Four-year historical settings are Zmax=2.30 m and fMulch=0, with 75% cover. The original 400,000-evaluation gated experiment is separate. Curves are finite-search envelopes, not proven optima or independently validated field responses.

解析：按示例的蓝虚线、红点和四窗口水量标签整理。采用四年历史参数的全范围补充搜索，不能混称根深1m重校准或正式有门槛搜索。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：Pareto_display_points.csv

图像：11_English_figures_tables_and_interpretations/Final_revision/figures/R03_Pareto_2020_annotated_EN.png

## 49. R03_Pareto_2021_annotated_EN

Four-year full-range, best-found NSGA-III Pareto envelopes. Blue dashed curves join nondominated archived solutions; red dots highlight exact evaluated controls. Labels give rounded allocations (W1, W2, W3, W4; mm), in fixed irrigation-date windows, not soil-moisture thresholds. Stars are original DI model baselines. The 95% observed-yield line is a reference only: it was removed as a constraint for this supplemental full-range search (3 seeds × 80 individuals × 60 generations per year; 57,600 evaluations in total). Four-year historical settings are Zmax=2.30 m and fMulch=0, with 75% cover. The original 400,000-evaluation gated experiment is separate. Curves are finite-search envelopes, not proven optima or independently validated field responses.

解析：按示例的蓝虚线、红点和四窗口水量标签整理。采用四年历史参数的全范围补充搜索，不能混称根深1m重校准或正式有门槛搜索。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：Pareto_display_points.csv

图像：11_English_figures_tables_and_interpretations/Final_revision/figures/R03_Pareto_2021_annotated_EN.png

## 50. R03_Pareto_2022_annotated_EN

Four-year full-range, best-found NSGA-III Pareto envelopes. Blue dashed curves join nondominated archived solutions; red dots highlight exact evaluated controls. Labels give rounded allocations (W1, W2, W3, W4; mm), in fixed irrigation-date windows, not soil-moisture thresholds. Stars are original DI model baselines. The 95% observed-yield line is a reference only: it was removed as a constraint for this supplemental full-range search (3 seeds × 80 individuals × 60 generations per year; 57,600 evaluations in total). Four-year historical settings are Zmax=2.30 m and fMulch=0, with 75% cover. The original 400,000-evaluation gated experiment is separate. Curves are finite-search envelopes, not proven optima or independently validated field responses.

解析：按示例的蓝虚线、红点和四窗口水量标签整理。采用四年历史参数的全范围补充搜索，不能混称根深1m重校准或正式有门槛搜索。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：Pareto_display_points.csv

图像：11_English_figures_tables_and_interpretations/Final_revision/figures/R03_Pareto_2022_annotated_EN.png

## 51. R1_01_Four_year_yield_irrigation

Four-year best-found yield–irrigation trade-offs with maximum root depth 1 m. See the associated source tables and stage report for precise definitions.

解析：用户要求的四年合并产量—灌水量图。空心圆为零灌水，星号为1m根深下原DI日程的模型回放，空心方框为文献DI观测产量。

边界：折线连接实际评价得到的非支配点；不是固定比例减灌曲线，也不证明全局最优。原MCMC参数冻结，未在1m根深下重校准。

源表：Root1m_best_found_front.csv, Baseline_and_zero_replays.csv, Thesis_DI_observed_summary.csv

图像：06_Structural_and_root_depth_diagnostics/Root1m_frozen_4year_trial/figures/R1_01_Four_year_yield_irrigation.png

## 52. R1_02_Pareto_fronts_2x2

Four-year NSGA-III Pareto fronts under a 1 m maximum root depth. See the associated source tables and stage report for precise definitions.

解析：用户要求的四年2×2帕累托图，灰点为实际搜索记录的显示抽样，彩色前沿取各年全部五种子、所有代的实际评价并集；星号为1m模型原DI日程，空心圆为零灌水。

边界：模型优化只有产量与实际灌水量两个目标。95%产量线仅作参照，未用于截断搜索；显示抽样不影响前沿计算。

源表：Root1m_best_found_front.csv, Actual_evaluation_file_index.csv, Thesis_DI_observed_summary.csv

图像：06_Structural_and_root_depth_diagnostics/Root1m_frozen_4year_trial/figures/R1_02_Pareto_fronts_2x2.png

## 53. R1_03_Root_depth_and_allocation

Root-depth effects separated from irrigation-allocation effects. See the associated source tables and stage report for precise definitions.

解析：两条比例减灌曲线采用完全相同的日期、窗口比例和总量，仅改变根深；与新1m前沿的差别反映重新分配灌水的收益。

边界：固定比例路径不是优化前沿；此图不把旧2.3m不同搜索预算的前沿当成严格配对实验。

源表：Root1m_best_found_front.csv, Paired_fixed_proportion_response.csv

图像：06_Structural_and_root_depth_diagnostics/Root1m_frozen_4year_trial/figures/R1_03_Root_depth_and_allocation.png

## 54. R1_04_Matched_yield_and_observations

Matched-model-yield irrigation reductions and observed-yield comparison. See the associated source tables and stage report for precise definitions.

解析：左图以1m根深下原DI模型产量为相同目标，右图单列文献实测与模型最高找到产量，避免把同模型产量说成同实测产量。

边界：减灌比例仍可能包含土壤耗储；未设置季末储水约束，不能直接等同耗水减少或田间推荐节水率。

源表：Selected_root1m_front_points.csv, Four_year_root1m_summary.csv, Thesis_DI_observed_summary.csv

图像：06_Structural_and_root_depth_diagnostics/Root1m_frozen_4year_trial/figures/R1_04_Matched_yield_and_observations.png

## 55. R1_05_Selected_irrigation_schedules

Actual event schedules at matched 1 m DI model yield. See the associated source tables and stage report for precise definitions.

解析：保留文献原DI灌水日期，比较原水量与新候选实际执行量；四个优化窗口内的原事件比例保持不变。

边界：原执行上限不是设备极限，本根深单因素试验未新加硬件事件限制；大单次量的现场可实施性仍需核实。

源表：Selected_actual_event_schedules.csv, Thesis_DI_irrigation_events.csv

图像：06_Structural_and_root_depth_diagnostics/Root1m_frozen_4year_trial/figures/R1_05_Selected_irrigation_schedules.png

## 56. R1_06_Seeded_convergence

Five-seed convergence records for the root-depth experiment. See the associated source tables and stage report for precise definitions.

解析：展示五种子各代种群超体积、种子中位数与范围，数据来自完整100代记录。

边界：阴影不是置信区间；当前种群指标可波动，指标稳定也不证明全局最优。前沿计算另保留所有已评价非支配点。

源表：Convergence_all_seeds.csv, Seed_stability_summary.csv

图像：06_Structural_and_root_depth_diagnostics/Root1m_frozen_4year_trial/figures/R1_06_Seeded_convergence.png

## 57. P01_CC_fit_2021_root1m

2021 canopy-cover fit with maximum root depth fixed at 1 m. See the associated source tables and stage report for precise definitions.

解析：左图将原起点和新校准试跑的逐日CC与田间LAI换算CC配对；右图展示实测与模拟的一致性，并列出RMSE、拟合R²和Pearson r。

边界：CC是校准资料而非独立验证；未把短链分布当作正式可信区间。拟合R²=1−SSE/SST，与Pearson r²不同。

源表：Phase2_pilot_CC_fitted_pairs.csv, Phase2_pilot_daily_growth.csv, Fit_metrics.csv

图像：07_2021_root1m_pilots/Calibration/figures/P01_CC_fit_2021_root1m.png

## 58. P02_Yield_and_biomass

Yield agreement and conditional biomass fit for the 2021 pilot. See the associated source tables and stage report for precise definitions.

解析：左图比较1m根深下原起点与两阶段试跑最终参数的产量，并以文献15.86t/ha标出差异；右图给出条件阶段二的生物量拟合。

边界：产量进入阶段二似然，属于样本内拟合；生物量误差条是原代码假设sigma，不是实测标准差。原内部产量靶值15.862t/ha与论文显示精度15.86同时保留。

源表：Yield_and_water_comparison.csv, Phase2_pilot_Biomass_fitted_pairs.csv

图像：07_2021_root1m_pilots/Calibration/figures/P02_Yield_and_biomass.png

## 59. P03_Parameter_boundary_screen

Parameter-boundary screening of eight calibrated pilot parameters. See the associated source tables and stage report for precise definitions.

解析：八个面板横轴完整显示先验范围；两侧淡橙色为各1%边界带，橙线为选中的短链样本点；角标给出边界带内样本质量。

边界：分布来自未确认收敛的短链，不能凭图宣称无撞墙。需同时查看选点距离、1%/5%边界质量、跨组Rhat与ESS；SenescenceCD在引擎内按原代码取整。

源表：All_parameter_boundary_and_mixing_checks.csv, runs/*/pilot_retained_draws_last250.csv

图像：07_2021_root1m_pilots/Calibration/figures/P03_Parameter_boundary_screen.png

## 60. P04_MCMC_trace_and_mixing

Short-chain traces and matched-walker mixing diagnostics. See the associated source tables and stage report for precise definitions.

解析：淡线为各walker，粗线为同组walker均值；四种颜色为独立ensemble，灰区为试跑摘要排除的前250步。标题给出跨独立组匹配walker诊断的保守Rhat与ESS。

边界：同组walker相互耦合，未当成独立链。500步不满足原2000步正式要求；即便拟合好也不能自动认定收敛。

源表：runs/canopy_transpiration/pilot_arrays.npz, runs/biomass_yield/pilot_arrays.npz, All_parameter_boundary_and_mixing_checks.csv

图像：07_2021_root1m_pilots/Calibration/figures/P04_MCMC_trace_and_mixing.png

## 61. P05_Yield_irrigation_0_to_actual

2021 yield–irrigation curve from zero to the actual DI amount. See the associated source tables and stage report for precise definitions.

解析：采用本轮新校准参数逐点计算201个水量水平；灌水日期和原逐次比例不变，横轴用引擎实际执行量，严格从0到633.47mm，终点与新拟合DI回放一致。

边界：此图是固定比例剂量响应，不是NSGA-III帕累托前沿；零灌水仍有初始土壤水与143.32mm季节降雨，所以不强制零产量。低水量尚无独立田间验证。

源表：Yield_irrigation_curve_0_to_observed.csv, Yield_irrigation_curve_actual_event_amounts.csv

图像：07_2021_root1m_pilots/Calibration/figures/P05_Yield_irrigation_0_to_actual.png

## 62. N21_01_Pareto_front

2021 NSGA-III yield–irrigation Pareto front with soil-storage audit. See the associated source tables and stage report for precise definitions.

解析：以全部30,000次实际优化评价的非支配并集构成前沿；灰点为显示抽样，虚线为原DI同比例减灌响应。前沿颜色代表季末0—1m储水，星号与方框分开表示原DI模型和文献实测。

边界：二维目标为产量最大与实际灌水最少，颜色只是审计量，不是第三目标。前沿不强行延长到633.47mm，被支配的原DI仍保留参照。固定参数来自未正式收敛的短链；未设置产量门槛或新增储水约束。

源表：NSGA3_best_found_front.csv, All_NSGA3_evaluations.csv.gz, Baseline_and_zero.csv, sources/Proportional_DI_response.csv

图像：07_2021_root1m_pilots/NSGA3/figures/N21_01_Pareto_front.png

## 63. N21_02_Storage_qualification

Soil-storage qualification and its effect on the evaluated trade-off. See the associated source tables and stage report for precise definitions.

解析：蓝线是未附加储水约束的主前沿；橙线从所有已评价候选中筛出季末0—1m储水不低于原DI者，再取非支配点。右图单独展示储水，避免把根层耗储当作无代价节水。

边界：原DI季末储水是同模型比较基准，允许0.01mm报告精度容差，不是新增实测阈值。橙线不是另一次带约束NSGA-III的优化结果，也不证明已充分搜索该子域；候选集合与主前沿可能不同。

源表：NSGA3_best_found_front.csv, Storage_qualified_evaluated_subset_front.csv, Selected_front_solutions.csv

图像：07_2021_root1m_pilots/NSGA3/figures/N21_02_Storage_qualification.png

## 64. N21_03_Seed_stability

Three-seed front agreement and NSGA-III search progress. See the associated source tables and stage report for precise definitions.

解析：三个独立随机种子各运行100个体、100代；左图比较各自全部评价的非支配前沿，右图为每代当前种群的归一化超体积。

边界：种子差异不是统计置信区间；种群超体积稳定也不证明全局最优。前沿并集使用所有代记录，不只取最后一代。

源表：Seed_stability.csv, Generation_history_all_seeds.csv, runs/seed*/all_evaluated_front.csv

图像：07_2021_root1m_pilots/NSGA3/figures/N21_03_Seed_stability.png

## 65. W01_Water_stress_and_canopy

Water stress and canopy responses under five irrigation amounts. See the associated source tables and stage report for precise definitions.

解析：前三面板分别显示冠层扩展、气孔和衰老的模型缺水胁迫系数；1表示不受该项缺水限制，越低胁迫越强。第四面板给出冠层响应，实测CC仅对应原DI条件。细灰竖线是原灌水日期。

边界：读取真实函数调用；气孔面板使用本版本蒸腾实际采用的sto_lin。扩展只显示模型扩展期且非种子保护期，气孔只显示潜在蒸腾大于零的日子，衰老只显示非保护期且仍有绿冠层的日子。断线不补成无胁迫；系数不等于独立观测或百分比减产。

源表：All_scenarios_daily.csv, Scenario_water_and_stress_summary.csv, I*_stress_function_calls.csv

图像：07_2021_root1m_pilots/Water_audit/figures/W01_Water_stress_and_canopy.png

## 66. W02_Root_domain_and_deep_storage

Root-domain storage and water retained below the maximum root depth. See the associated source tables and stage report for precise definitions.

解析：上图统一采用0—1m固定土层储水，横向比较各灌水情景，虚线为模型田持水量与萎蔫点对应储水；下图单列1—2.4m储水的相对初值变化，避免把根区以下存水当作根系可用水。

边界：日期是日末状态对应的次日零时，含4月27日模拟前初值。根深动态增长，0—1m固定层不等于幼苗期实际可达根域。FC/WP来自原质地转换；初值来自近似重建。深层没有根系直接取水，底边界位于2.4m。

源表：All_scenarios_daily.csv, Initial_water_hydraulic_source_audit.csv, Scenario_water_and_stress_summary.csv

图像：07_2021_root1m_pilots/Water_audit/figures/W02_Root_domain_and_deep_storage.png

## 67. F01_DI_canopy_biomass_fits

Canopy and biomass fits after conditional recalibration. See the associated source tables and stage report for precise definitions.

解析：三种fMulch分别重校准两阶段参数。比较冠层与生物量的残差，同时查看产量偏差；不能仅因产量接近而判定物理结构正确。

边界：圆点是原DI校准数据，生物量与部分CC来自原项目数字化或换算；这是条件拟合，不是独立验证。

源表：fm*_CC_pairs.csv, fm*_Biomass_pairs.csv, fm*_DI_growth.csv, Calibration_fit_metrics.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/F01_DI_canopy_biomass_fits.png

## 68. F02_DI_yield_Es_Tr_ET

DI yield and seasonal water-flux fits. See the associated source tables and stage report for precise definitions.

解析：充分灌溉下产量可能接近，但Es、Tr、ET未必同时接近原目标；用共同目标和相同误差权重比较，而非挑选节水幅度符合预期的情景。

边界：Es=78mm是原项目近似重建的校准目标，Tr由ET减Es得到，并非新增加的独立实测。不同目标并不相互独立。

源表：Calibrated_DI_fit_summary.csv, Descriptive_fit_residual_scores.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/F02_DI_yield_Es_Tr_ET.png

## 69. T01_Yield_irrigation_comparison

Proportional irrigation responses across three mulch structures. See the associated source tables and stage report for precise definitions.

解析：每条线用该地膜情景各自重校准的参数，按原DI日程比例缩放灌水；比较0、300、350、400及633.47mm的产量与储水，不强制曲线在400mm转折。

边界：这些是单个短链选定参数的剂量响应，既非优化前沿，也没有传播参数后验不确定性；零灌溉允许降雨和初始储水。历史f0只作旧结果对照。

源表：All_proportional_responses.csv, Exact_300_350_400_response_checks.csv, Historical_f0_proportional_response.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/T01_Yield_irrigation_comparison.png

## 70. F03_MCMC_walls_and_mixing

Parameter bounds and short-chain mixing diagnostics. See the associated source tables and stage report for precise definitions.

解析：检查选定点距先验上下界、边界附近样本占比、Rhat和ESS。拟合良好并不代表参数可辨识；WP或HI0贴边时应优先复核先验与模型结构。

边界：500步仅为用户指定的调试试验。保留段分位数不是收敛后验区间，正式原流程最少2000步等门槛未通过，不可把12万保存状态称为独立有效样本。

源表：All_MCMC_parameter_diagnostics.csv, calibration/*/*/Pilot_arrays.npz

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/F03_MCMC_walls_and_mixing.png

## 71. T02_fm050_Water_stress_canopy

Water-stress and canopy responses, fMulch=0.50. See the associated source tables and stage report for precise definitions.

解析：前三面板分别追溯扩展、气孔、衰老的缺水限制，第四面板显示CC。重点查看316.74与400mm是否在关键时期维持蒸腾以及冠层。

边界：显示实际函数调用；气孔使用本版本实际作用于Tr的sto_lin。按过程适用时间掩膜，断线不填成1。DI观测圆点仅对应633.47mm，不能直接验证缺水情景。

源表：fm050_I*_daily.csv, fm050_I*_stress_function_calls.csv, All_stress_storage_summaries.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/T02_fm050_Water_stress_canopy.png

## 72. S01_fm050_Soil_water_storage

Root and deep soil storage, fMulch=0.50. See the associated source tables and stage report for precise definitions.

解析：把根区储水与根区以下储水分开，检查少灌是否靠多消耗土壤水维持产量。季末储水差异是一次性节水与持续管理方案区别的重要依据。

边界：水力剖面仍为原2.4m；根系最大1m，1m以下没有直接根系吸水。初始含水率来自原近似重建，未经新增独立校正。

源表：fm050_I*_daily.csv, All_stress_storage_summaries.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/S01_fm050_Soil_water_storage.png

## 73. T02_fm075_Water_stress_canopy

Water-stress and canopy responses, fMulch=0.75. See the associated source tables and stage report for precise definitions.

解析：前三面板分别追溯扩展、气孔、衰老的缺水限制，第四面板显示CC。重点查看316.74与400mm是否在关键时期维持蒸腾以及冠层。

边界：显示实际函数调用；气孔使用本版本实际作用于Tr的sto_lin。按过程适用时间掩膜，断线不填成1。DI观测圆点仅对应633.47mm，不能直接验证缺水情景。

源表：fm075_I*_daily.csv, fm075_I*_stress_function_calls.csv, All_stress_storage_summaries.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/T02_fm075_Water_stress_canopy.png

## 74. S01_fm075_Soil_water_storage

Root and deep soil storage, fMulch=0.75. See the associated source tables and stage report for precise definitions.

解析：把根区储水与根区以下储水分开，检查少灌是否靠多消耗土壤水维持产量。季末储水差异是一次性节水与持续管理方案区别的重要依据。

边界：水力剖面仍为原2.4m；根系最大1m，1m以下没有直接根系吸水。初始含水率来自原近似重建，未经新增独立校正。

源表：fm075_I*_daily.csv, All_stress_storage_summaries.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/S01_fm075_Soil_water_storage.png

## 75. T02_fm085_Water_stress_canopy

Water-stress and canopy responses, fMulch=0.85. See the associated source tables and stage report for precise definitions.

解析：前三面板分别追溯扩展、气孔、衰老的缺水限制，第四面板显示CC。重点查看316.74与400mm是否在关键时期维持蒸腾以及冠层。

边界：显示实际函数调用；气孔使用本版本实际作用于Tr的sto_lin。按过程适用时间掩膜，断线不填成1。DI观测圆点仅对应633.47mm，不能直接验证缺水情景。

源表：fm085_I*_daily.csv, fm085_I*_stress_function_calls.csv, All_stress_storage_summaries.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/T02_fm085_Water_stress_canopy.png

## 76. S01_fm085_Soil_water_storage

Root and deep soil storage, fMulch=0.85. See the associated source tables and stage report for precise definitions.

解析：把根区储水与根区以下储水分开，检查少灌是否靠多消耗土壤水维持产量。季末储水差异是一次性节水与持续管理方案区别的重要依据。

边界：水力剖面仍为原2.4m；根系最大1m，1m以下没有直接根系吸水。初始含水率来自原近似重建，未经新增独立校正。

源表：fm085_I*_daily.csv, All_stress_storage_summaries.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/S01_fm085_Soil_water_storage.png

## 77. T03_all_NSGA3_front

NSGA-III best-found yield–irrigation front, all. See the associated source tables and stage report for precise definitions.

解析：实线来自实际评估候选的非支配集合，点虚线是原比例日程。用共同的实测产量和95%实测产量参照比较，另报告各情景自己的DI基线，避免因基线变差而显得更省水。

边界：两个目标：产量最大化、实际季灌水最小化；四个固定时间窗分配量。无强制400mm下界、无产量门槛、未加入季末储水约束。有限搜索不是已证明的全局最优，也不是田间验证。

源表：All_scenario_NSGA3_fronts.csv, Selected_front_comparisons.csv, All_proportional_responses.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/T03_all_NSGA3_front.png

## 78. T03_fm050_NSGA3_front

NSGA-III best-found yield–irrigation front, fm050. See the associated source tables and stage report for precise definitions.

解析：实线来自实际评估候选的非支配集合，点虚线是原比例日程。用共同的实测产量和95%实测产量参照比较，另报告各情景自己的DI基线，避免因基线变差而显得更省水。

边界：两个目标：产量最大化、实际季灌水最小化；四个固定时间窗分配量。无强制400mm下界、无产量门槛、未加入季末储水约束。有限搜索不是已证明的全局最优，也不是田间验证。

源表：All_scenario_NSGA3_fronts.csv, Selected_front_comparisons.csv, All_proportional_responses.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/T03_fm050_NSGA3_front.png

## 79. T03_fm075_NSGA3_front

NSGA-III best-found yield–irrigation front, fm075. See the associated source tables and stage report for precise definitions.

解析：实线来自实际评估候选的非支配集合，点虚线是原比例日程。用共同的实测产量和95%实测产量参照比较，另报告各情景自己的DI基线，避免因基线变差而显得更省水。

边界：两个目标：产量最大化、实际季灌水最小化；四个固定时间窗分配量。无强制400mm下界、无产量门槛、未加入季末储水约束。有限搜索不是已证明的全局最优，也不是田间验证。

源表：All_scenario_NSGA3_fronts.csv, Selected_front_comparisons.csv, All_proportional_responses.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/T03_fm075_NSGA3_front.png

## 80. T03_fm085_NSGA3_front

NSGA-III best-found yield–irrigation front, fm085. See the associated source tables and stage report for precise definitions.

解析：实线来自实际评估候选的非支配集合，点虚线是原比例日程。用共同的实测产量和95%实测产量参照比较，另报告各情景自己的DI基线，避免因基线变差而显得更省水。

边界：两个目标：产量最大化、实际季灌水最小化；四个固定时间窗分配量。无强制400mm下界、无产量门槛、未加入季末储水约束。有限搜索不是已证明的全局最优，也不是田间验证。

源表：All_scenario_NSGA3_fronts.csv, Selected_front_comparisons.csv, All_proportional_responses.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/T03_fm085_NSGA3_front.png

## 81. D01_400mm_cross_structure

Stress, canopy and storage at a shared 400 mm schedule. See the associated source tables and stage report for precise definitions.

解析：固定灌溉总量与日程为400mm，横向比较地膜结构及其条件重校准的联合作用；观察胁迫、CC和储水的变化能否解释平台移动。

边界：每个情景参数不同，因而不是固定参数的纯fMulch导数。原DI的CC观测不叠加到400mm面板，避免误当缺水验证。

源表：fm*_I400_daily.csv, Selected_parameters_all_scenarios.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/D01_400mm_cross_structure.png

## 82. D02_Storage_qualified_subset

Effect of post-filtering for comparable terminal root-zone storage. See the associated source tables and stage report for precise definitions.

解析：按各自DI季末0—1m储水后筛选，查看主前沿少灌的收益有多少依赖额外耗储；原DI产量线只用于同一面板比较，三情景仍应另用共同实测门槛。

边界：紫虚线只来自主搜索已经评估过的合格候选，并非另一次充分的储水约束搜索；0.01mm是报告精度容差，不是实测阈值。

源表：All_storage_qualified_subset_fronts.csv, Selected_front_comparisons.csv, Optimization_scenario_summary.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/D02_Storage_qualified_subset.png

## 83. D03_Applied_water_reduction_partition

Water-balance partition of reducing irrigation from633.47 to400 mm. See the associated source tables and stage report for precise definitions.

解析：在相同参数、天气和初值下，从633.47减到400mm少灌233.47mm，ET几乎不变；主要差额表现为季末土壤存水减少，尤其1m根层以下。这个质量守恒分解比只讨论地膜系数更能解释模型平台。

边界：季末根层以下存水不是可直接被根系利用的水；分量来自冻结模型而非实测去向。改变土壤域、水力参数或初值可能改变分配，不能直接把深层存水差叫田间浪费。

源表：Irrigation_reduction_partition_400mm.csv, Exact_300_350_400_response_checks.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/D03_Applied_water_reduction_partition.png

## 84. D04_Optimized_vs_same_amount_schedule

Why allocation improves the best-found front. See the associated source tables and stage report for precise definitions.

解析：在相同地膜结构和同一实际灌水总量下，对照优化分配与原比例分配，追溯气孔胁迫、冠层以及季末储水。灰线为原DI；同时检查四个日历窗口账本和七次事件水量。

边界：优化保持原日期，改变四个窗口总量，并非优化灌溉日期。95%目标候选与原DI不是同产量的实测田间对照；日历会计窗口也不是重新识别的生育阶段。

源表：Optimized_candidate_stress_summaries.csv, fm*_Opt95_daily.csv, fm*_PropSameOpt95_daily.csv, Calendar_window_water_stress_ledger.csv, Selected_event_schedules.csv

图像：08_2021_mulch_conditional_calibration_and_optimization/figures/D04_Optimized_vs_same_amount_schedule.png

## 85. D01_Water_accounting_four_years

Apparent irrigation reductions and soil-storage accounting. See the associated source tables and stage report for precise definitions.

解析：2020/2021年季末储水差解释灌水减少量的93.3%/97.4%；原DI增储而C1耗储。

边界：季末储水差不是全部来自初始深层水；该图不证明盆地尺度净节水。

源表：Water_reduction_accounting.csv

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D01_Water_accounting_four_years.png

## 86. D02_Daily_storage_canopy_stress

Daily water storage, canopy and stomatal response. See the associated source tables and stage report for precise definitions.

解析：C1的主要差异出现在季末储水；冠层峰值接近，模型开花窗口内授粉胁迫系数接近1。

边界：灰色窗为模型日历开花窗口，并非独立田间物候观测；K=1表示该项水分胁迫未触发。

源表：All_daily_traces.csv.gz, Canopy_stress_diagnostics.csv

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D02_Daily_storage_canopy_stress.png

## 87. D03_Layer_moisture_and_roots

Soil moisture redistribution and modeled root depth. See the associated source tables and stage report for precise definitions.

解析：深层在原DI中有显著补蓄；C1减轻补蓄，同时降低表层含水。

边界：色标为田间持水量与萎蔫点之间的相对可利用水，不是饱和度；色标截在0与1.2；深层土壤性质与初始水仍需现场证据。

源表：All_layer_traces.csv.gz, All_daily_traces.csv.gz

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D03_Layer_moisture_and_roots.png

## 88. D04_Period_water_budgets

Water allocation over model calendar periods. See the associated source tables and stage report for precise definitions.

解析：2020年C1几乎全部灌水前置，生殖期依赖储水；2021年原DI后期灌水相当一部分留在土壤。

边界：五个诊断日历时期与四个优化决策窗口不同；不得直接解释成五次田间灌水。

源表：Period_water_canopy_stress.csv

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D04_Period_water_budgets.png

## 89. D05_Event_allocation_and_original_setting

Actual irrigation events and the original per-event setting. See the associated source tables and stage report for precise definitions.

解析：原接口随候选调大MaxIrr，2020年C1单次约180mm超过原日程执行设置84.88mm。

边界：用户已确认原MaxIrr是保障实测日程执行的数值上限，并非设备极限；固定原上限只是受控诊断，不能凭此认定原接口错误。

源表：Actual_event_schedules_DI_C1.csv, Original_configuration.csv

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D05_Event_allocation_and_original_setting.png

## 90. D06_Root_depth_hypothesis_test

Root-depth sensitivity of fixed irrigation schedules. See the associated source tables and stage report for precise definitions.

解析：原DI拟合良好并不能保证亏缺灌溉外推合理；2020年C1对2.3m根深假设非常敏感。

边界：缩短根深仅是单因素诊断，未重校准；不能选一个更悲观根深充当真实根深。

源表：Root_depth_hypothesis_test.csv

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D06_Root_depth_hypothesis_test.png

## 91. D07_Depth_uptake_and_storage_change

Depth-resolved uptake and net soil-water storage change. See the associated source tables and stage report for precise definitions.

解析：2020年C1在1m以下取水152.8mm，但深层季净储水仍增加22.2mm；不能把深层取水量全部认定为开采初始水。

边界：逐层取水由原引擎蒸腾步骤前后含水差直接记录；未做雨水、灌水、初始水示踪。

源表：Depth_uptake_and_net_storage.csv

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D07_Depth_uptake_and_storage_change.png

## 92. D08_Constrained_search_comparison

Diagnostic constrained searches and soil-water carryover. See the associated source tables and stage report for precise definitions.

解析：控制原单次灌水设置后，若不允许消耗初始储水，2020/2021年最少灌水候选的降幅收敛至12.4%/27.4%。

边界：每年每策略两种子×64个体×50代；黑短线表示种子候选，不是置信区间。仍采用95%观测产量门槛，实际ET可响应变化。

源表：Constrained_best_found_candidates.csv, Constrained_seed_candidates.csv

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D08_Constrained_search_comparison.png

## 93. D09_Equal_ET_diagnostics

Equal actual-ET comparisons with fixed per-event settings. See the associated source tables and stage report for precise definitions.

解析：将季节实际ET精确匹配原DI后，兼顾季末不低于初始储水的诊断点降幅为11.1%/26.8%；保持原DI季末储水时回到原DI。

边界：这些是经模型求根得到的可行对照点，不是新的最小灌水全局最优；只匹配季总ET，不强制每日ET轨迹相同。

源表：Equal_ET_fixed_management_diagnostics.csv

图像：06_Structural_and_root_depth_diagnostics/Mechanism_audit/figures/D09_Equal_ET_diagnostics.png

## 94. P01_Daily_precipitation_4years_EN

Blue bars show uploaded GEE inputs; orange bars are approximate reconstructions of thesis Figure 2-2 (PDF p. 22). Pale shading denotes the published DI crop period. Broken rainfall axes in the source for 2021 and 2022 were reconstructed piecewise. Dates have a ±1-day graphic-reading uncertainty; bars below the resolution limit may be missed. These are not raw daily gauge data.

解析：核对GEE与论文图近似降水，区分原始观测、图数字化和模型水量输入。固定参数替换用于检验驱动敏感性，未重新优化。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：09_Rainfall_and_data_provenance_audit/figures/P01_Daily_precipitation_4years_EN.png

## 95. P02_Cumulative_precipitation_4years_EN

Cumulative rainfall uses each published DI sowing–harvest period, inclusive of harvest day. Open diamonds indicate the rounded seasonal precipitation inputs reported in WHCNS water balance Table 5-13, not an independently provided daily gauge series. The original AquaCrop endpoint differs by one day in 2019, 2021 and 2022; those original calendars were retained in model replays.

解析：核对GEE与论文图近似降水，区分原始观测、图数字化和模型水量输入。固定参数替换用于检验驱动敏感性，未重新优化。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：09_Rainfall_and_data_provenance_audit/figures/P02_Cumulative_precipitation_4years_EN.png

## 96. P03_Existing_candidates_rainfall_sensitivity_EN

Yield changes are relative to the original GEE forcing. Parameters, irrigation controls, initial soil water and all non-precipitation forcings are fixed. Historical models use maximum root depth 2.30 m and fMulch = 0. Treatments separate changes in total precipitation, graphic timing and intensity distribution, and synthetic redistribution of trace precipitation. These are backtests of existing candidates, not reoptimized Pareto fronts.

解析：核对GEE与论文图近似降水，区分原始观测、图数字化和模型水量输入。固定参数替换用于检验驱动敏感性，未重新优化。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：09_Rainfall_and_data_provenance_audit/figures/P03_Existing_candidates_rainfall_sensitivity_EN.png

## 97. P04_2021_fixed_schedule_rainfall_checks_EN

Each panel uses its own previously selected conditional pilot parameters at maximum root depth 1.00 m. Six evaluated proportional irrigation levels are 0, 300, 350, 400, 500 and 633.47 mm; connecting lines guide the eye and are not a new continuous optimization. Rainfall changes only; fMulch and all other inputs remain fixed within a panel. These 500-step pilot fits have not established posterior convergence. The 350-mm modeled plateau persists under the tested rainfall alternatives.

解析：核对GEE与论文图近似降水，区分原始观测、图数字化和模型水量输入。固定参数替换用于检验驱动敏感性，未重新优化。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：09_Rainfall_and_data_provenance_audit/figures/P04_2021_fixed_schedule_rainfall_checks_EN.png

## 98. S01_Four_year_minimum_irrigation_EN

GA denotes real-coded genetic algorithm, GSA generalized simulated annealing, and DE differential evolution; NSGA-II is used with one objective. Each method minimizes actual irrigation subject to a prescribed Y13 threshold. Curves show median threshold minima from its own complete sweep archive; bands span three seeds and are not confidence intervals. Open circles show actual modeled zero-irrigation yield. The star is the DI model baseline. Historical NSGA-III is an external archive with a different evaluation budget. Lines join discrete tested requirements; they do not establish global optimality.

解析：比较给定产量门槛下的最小实际灌水；算法预算、三个种子和档案规则按英文图注解释。数值一致不代表物理或田间验证。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：10_Single_objective_multi_algorithm_validation/figures/S01_Four_year_minimum_irrigation_EN.png

## 99. S02_2021_three_fMulch_minimum_irrigation_EN

The three panels use different previously selected conditional parameter sets at fMulch 0.50, 0.75 and 0.85; this is not a parameter-fixed one-factor mulch experiment. Maximum root depth is 1.00 m. The original GEE weather, initial soil water, original event dates and four irrigation windows are retained. No terminal-storage floor is added. The 500-step parent fits have not demonstrated posterior convergence. Other plotting conventions follow S01.

解析：比较给定产量门槛下的最小实际灌水；算法预算、三个种子和档案规则按英文图注解释。数值一致不代表物理或田间验证。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：10_Single_objective_multi_algorithm_validation/figures/S02_2021_three_fMulch_minimum_irrigation_EN.png

## 100. S03_2021_actual_yield_irrigation_EN

Markers are actual evaluated solutions, selected as the lowest-irrigation feasible candidate over three seeds for each method and requirement. The y-axis is achieved model yield, whereas S01–S02 show required yield. No missing or failed thresholds are imputed. The prior proportional response changes all original event amounts by a common factor; optimized solutions redistribute amounts among four windows. The historical NSGA-III front uses a different search budget.

解析：比较给定产量门槛下的最小实际灌水；算法预算、三个种子和档案规则按英文图注解释。数值一致不代表物理或田间验证。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：10_Single_objective_multi_algorithm_validation/figures/S03_2021_actual_yield_irrigation_EN.png

## 101. S04_95pct_yield_algorithm_comparison_EN

Each colored marker is the minimum feasible irrigation in one method/seed archive, including the equal 384-query continuation at this requirement. Three seeds are displayed separately. Dark ticks show historical NSGA-III archive minima, which are references rather than equal-budget competitors. The requirement is 95% of the observed yield level, not a 95% probability of success.

解析：比较给定产量门槛下的最小实际灌水；算法预算、三个种子和档案规则按英文图注解释。数值一致不代表物理或田间验证。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：10_Single_objective_multi_algorithm_validation/figures/S04_95pct_yield_algorithm_comparison_EN.png

## 102. S05_2021_convergence_EN

Lines show the median incumbent feasible irrigation across three seeds during the 384-query independent run; shading spans the seed minimum and maximum. Setup initial populations contain the DI baseline, ensuring a feasible anchor at this requirement. The later equally budgeted 384-query continuation is reported separately. Convergence here assesses numerical search, not correctness of the model water-stress response.

解析：比较给定产量门槛下的最小实际灌水；算法预算、三个种子和档案规则按英文图注解释。数值一致不代表物理或田间验证。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：10_Single_objective_multi_algorithm_validation/figures/S05_2021_convergence_EN.png

## 103. S06_Irrigation_reduction_water_budget_EN

For each model, the lowest-irrigation 95%-yield candidate found across the four methods and three seeds is compared with its own DI baseline. The storage term is the complete hydrological profile at the common calendar endpoint, not the root zone alone. Other differences close the accounting for runoff, drainage, groundwater and surface-storage terms. Irrigation reductions must not be interpreted as equal reductions in ET or as validated sustainable field savings.

解析：比较给定产量门槛下的最小实际灌水；算法预算、三个种子和档案规则按英文图注解释。数值一致不代表物理或田间验证。

边界：须按本阶段的模型设置、参数和统计口径解释；候选不是经过独立田间验证的灌溉定额。

源表：

图像：10_Single_objective_multi_algorithm_validation/figures/S06_Irrigation_reduction_water_budget_EN.png
