# -*- coding: utf-8 -*-
"""交付前最终检验 (self-check).

逐项核对: 模块可导入 / 标定系数 / 四年年度校验值 / 输出文件齐全 / 图件有效 /
独立验证指标。全部通过则打印 PASS。
"""
from __future__ import annotations

import json
import struct
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
OUT = HERE / "output"
sys.path.insert(0, str(HERE))

FAIL = []


def check(name: str, ok: bool, detail: str = ""):
    tag = "PASS" if ok else "FAIL"
    if not ok:
        FAIL.append(name)
    print(f"  [{tag}] {name}" + (f"  — {detail}" if detail else ""))


def png_ok(p: Path) -> bool:
    """校验 PNG 头与 IEND 尾."""
    try:
        b = p.read_bytes()
        return b[:8] == b"\x89PNG\r\n\x1a\n" and b[-8:-4] == b"IEND"
    except Exception:
        return False


print("=" * 92)
print("交付前最终检验")
print("=" * 92)

# ---------- 1. 模块导入 ----------
print("\n【1】模块可导入")
try:
    import real_forcing
    import aquacrop_surrogate as A
    check("real_forcing / aquacrop_surrogate 导入", True)
except Exception as e:
    check("real_forcing / aquacrop_surrogate 导入", False, str(e))
    raise SystemExit(1)
for m in ["phaseA_merge_posterior", "phaseB_sobol", "phaseC_nsga3", "phaseD_timeseries"]:
    try:
        __import__(m)
        check(f"{m} 导入", True)
    except Exception as e:
        check(f"{m} 导入", False, str(e))

# ---------- 2. 驱动与年度校验值 ----------
print("\n【2】四年年度校验值 (真实气象驱动)")
ds = real_forcing.year_summary()
ok_all = True
for _, r in ds.iterrows():
    if pd.notna(r.ETo_audit_B):
        ok_e = abs(r.ETo_corrected - r.ETo_audit_B) < 0.05
        ok_r = abs(r.Rain - r.Rain_audit) < 0.5
        ok_all &= bool(ok_e and ok_r)
        check(f"{int(r.Year)} ETo/降水 匹配 audit", bool(ok_e and ok_r),
              f"ETo {r.ETo_corrected:.3f} vs {r.ETo_audit_B:.3f}; 降水 {r.Rain:.3f} vs {r.Rain_audit:.3f}")
    else:
        check(f"{int(r.Year)} 降水匹配 (ETo 无 audit)", abs(r.Rain - r.Rain_audit) < 0.5,
              f"降水 {r.Rain:.3f} vs {r.Rain_audit:.3f}; ETo {r.ETo_corrected:.2f} (三年均值因子)")

# ---------- 3. 标定系数 ----------
print("\n【3】四分量标定系数")
A.calibrate_all()
for y in (2019, 2020, 2021, 2022):
    c = A.CALIB[y]
    kb_ok = 0.85 <= c["k_B"] <= 1.10
    check(f"{y} k_B 在合理区间 (0.85–1.10)", kb_ok, f"k_B={c['k_B']:.4f}")

# ---------- 4. 独立验证指标 ----------
print("\n【4】独立验证指标")
val = pd.read_csv(OUT / "validation_report.csv")
cc = val[val.Section == "2_冠层"]
pred = val[val.Metric == "Y13_pred_err_pct"]
if len(cc):
    r2_min = cc[cc.Metric == "CC_R2"].Value.min()
    check("冠层 R² 最小值 ≥ 0.90", r2_min >= 0.90, f"min R² = {r2_min:.4f}")
if len(pred):
    e_max = pred.Value.abs().max()
    check("产量预测最大误差 ≤ 15%", e_max <= 15, f"max |err| = {e_max:.2f}%")

# ---------- 5. 输出文件齐全 ----------
print("\n【5】输出文件齐全")
need = ["sobol_indices.csv", "sobol_CAI.csv", "sobol_summary.json",
        "pareto_front.csv", "pareto_knee_solutions.csv", "optimal_irrigation_schedule.csv",
        "nsga3_summary.json", "D1_parameter_drift.csv", "D3_transfer_matrix.csv",
        "D_timeseries_summary.json", "merged_posterior.npz", "metrics_table.csv",
        "validation_report.csv", "validation_report.md"]
for f in need:
    check(f"output/{f}", (OUT / f).exists())

figs = sorted(OUT.glob("fig_*.png"))
check(f"图件数量 = 10 (实际 {len(figs)})", len(figs) == 10)
for f in figs:
    ok = png_ok(f)
    check(f"  {f.name}", ok, f"{f.stat().st_size/1024:.0f} KB" if ok else "PNG 结构损坏")

# ---------- 6. 报告与数据一致 ----------
print("\n【6】报告与数据一致")
try:
    s = json.loads((OUT / "sobol_summary.json").read_text(encoding="utf-8"))
    top = max(s["Top_ST_bayes_Y13"], key=s["Top_ST_bayes_Y13"].get)
    check("Sobol 首位参数 = Kcb", top == "Kcb", f"实际首位 = {top}")
    kn = pd.read_csv(OUT / "pareto_knee_solutions.csv")
    check("膝点表 4 行 (四年)", len(kn) == 4, f"实际 {len(kn)} 行")
    check("膝点平均节水在 15–30% 区间",
          15 <= kn.Water_saving_pct.mean() <= 30, f"平均 {kn.Water_saving_pct.mean():.1f}%")
except Exception as e:
    check("报告一致性核对", False, str(e))

# ---------- 汇总 ----------
print("\n" + "=" * 92)
if FAIL:
    print(f"检验未通过: {len(FAIL)} 项失败")
    for f in FAIL:
        print("  -", f)
else:
    print("★ 全部检验通过 (PASS)")
print("=" * 92)
