# -*- coding: utf-8 -*-
"""
Annual DI maize PRE‑MCMC prior predictive diagnostic.
This is NOT a full MCMC calibration. It audits the reconstructed inputs,
runs the common initialization center, then draws random samples from the intended
7‑parameter MCMC priors to verify that the observed annual Yield / CC / seasonal Es
are structurally reachable.

Initial water:
- 0‑1 m: thesis Fig. 3‑9 / Fig. 3‑10 approximate field‑constrained profile
- >1 m: ERA5‑Land
"""
import os
import numpy as np
import pandas as pd

from aquacrop import (
    AquaCropModel, Soil, Crop, InitialWaterContent,
    IrrigationManagement, FieldMngt,
)

YEAR = 2021
PLANT_DATE = pd.Timestamp("2021-04-27")
HARVEST_DATE = pd.Timestamp("2021-09-22")
MATURITY_CD = 148
HISTART_CD = 77
LATE_CC_START = pd.Timestamp("2021-08-21")
OBS_YIELD = 15.862
OBS_ES = 78.0

IRRIGATION_EVENTS = [
    ('2021-06-13', 93.11),
    ('2021-06-30', 86.91),
    ('2021-07-09', 84.57),
    ('2021-07-20', 76.6),
    ('2021-07-30', 114.8),
    ('2021-08-11', 89.54),
    ('2021-08-23', 87.94)
]

# ======================【适配你的电脑全部绝对路径】======================
ROOT = r"C:\Users\WWYYZZ\Desktop\sobol\2021"
OUTPUT_DIR = os.path.join(ROOT, f"PRE_MCMC_PRIOR_DIAGNOSTIC_{YEAR}")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 初始水分csv，放在sobol根目录
INITIAL_WATER_FILE = r"C:\Users\WWYYZZ\Desktop\sobol\DI_2019_2022_AquaCrop_InitialWater_FIELD_LOCKED.csv"

# 气象、CC观测文件：放在sobol\2021文件夹
WEATHER_CANDIDATES = [
    r"C:\Users\WWYYZZ\Desktop\sobol\2021\DI_Climate_2021_FINAL.csv",
]
CC_CANDIDATES = [
    r"C:\Users\WWYYZZ\Desktop\sobol\2021\Maize-2021-main.csv",
]
# ============================================================================

MULCH_PCT = 75.0
WET_SURF = 100.0
APP_EFF = 100.0

RANDOM_SEED = 42 + YEAR
N_PRIOR_SAMPLES = 120

PARAM_KEYS = ["CCx","CGC_CD","CDC_CD","SenescenceCD","WP","HI0","f_mulch"]
PARAM_RANGES = {
    "CCx": (0.60,0.90),
    "CGC_CD": (0.08,0.16),
    "CDC_CD": (0.03,0.12),
    "SenescenceCD": (115.0,145.0),
    "WP": (28.0,40.0),
    "HI0": (0.40,0.60),
    "f_mulch": (0.30,0.70),
}
INIT_CENTER = {
    "CCx":0.78, "CGC_CD":0.120, "CDC_CD":0.070,
    "SenescenceCD":132.0, "WP":33.7, "HI0":0.50, "f_mulch":0.46,
}

SOIL_LAYERS = [
    (0.10,29.70,10.64),(0.10,30.81,10.52),(0.20,19.43,12.32),
    (0.20,13.22,16.20),(0.20,10.38,14.75),(0.20,11.81,11.66),
]
ORG_MAT = 2.0


def first_existing(paths):
    for p in paths:
        if os.path.exists(p):
            return p
    raise FileNotFoundError("None found:\n" + "\n".join(paths))


def find_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def safe_sum(df, candidates):
    c = find_col(df, candidates)
    if c is None:
        return np.nan
    return float(pd.to_numeric(df[c], errors="coerce").fillna(0).sum())


def read_weather():
    path = first_existing(WEATHER_CANDIDATES)
    raw = pd.read_csv(path, encoding="utf-8-sig")
    raw.columns = [str(c).strip() for c in raw.columns]
    dcol = "Date" if "Date" in raw.columns else "date"

    w = pd.DataFrame({
        "MinTemp": pd.to_numeric(raw["Tmin_C"], errors="raise").astype(float),
        "MaxTemp": pd.to_numeric(raw["Tmax_C"], errors="raise").astype(float),
        "Precipitation": pd.to_numeric(raw["Precip_mm"], errors="raise").astype(float),
        "ReferenceET": pd.to_numeric(raw["ETo_mm"], errors="raise").astype(float),
        "Date": pd.to_datetime(raw[dcol], errors="raise"),
    })
    # Current AquaCrop version requires Date last.
    w = w[["MinTemp","MaxTemp","Precipitation","ReferenceET","Date"]]
    w = w.sort_values("Date").drop_duplicates("Date").reset_index(drop=True)
    return w, path


def read_cc():
    path = first_existing(CC_CANDIDATES)
    raw = pd.read_csv(path, encoding="utf-8-sig")
    raw.columns = [str(c).strip() for c in raw.columns]
    dcol = "date" if "date" in raw.columns else "Date"
    if "CCquad" not in raw.columns:
        raise ValueError("CC file must contain CCquad.")

    obs = pd.DataFrame({
        "Date": pd.to_datetime(raw[dcol], errors="coerce"),
        "Observed_CC": pd.to_numeric(raw["CCquad"], errors="coerce")/100.0,
    }).dropna()
    obs["Date"] = obs["Date"].dt.normalize()
    obs = obs[
        (obs["Date"] >= PLANT_DATE) & (obs["Date"] <= HARVEST_DATE) &
        (obs["Observed_CC"] >= 0) & (obs["Observed_CC"] <= 1)
    ].copy()
    obs = obs.groupby("Date",as_index=False)["Observed_CC"].mean().sort_values("Date")
    obs["Weight"] = 1.0
    obs.loc[obs["Date"] >= LATE_CC_START,"Weight"] = 0.50
    return obs.reset_index(drop=True), path


def read_initial_water():
    df = pd.read_csv(INITIAL_WATER_FILE, encoding="utf-8-sig")
    sub = df[df["Year"].astype(int)==YEAR].copy().sort_values("Depth_top_m")
    if len(sub) != 10:
        raise ValueError(f"Expected 10 initial‑water rows, got {len(sub)}")
    return sub.reset_index(drop=True)


def build_soil():
    soil = Soil("custom", dz=[0.1]*10)
    for th,sand,clay in SOIL_LAYERS:
        soil.add_layer_from_texture(
            thickness=th, Sand=sand, Clay=clay,
            OrgMat=ORG_MAT, penetrability=100
        )
    return soil


def build_initial(profile):
    return InitialWaterContent(
        wc_type="Num", method="Depth",
        depth_layer=profile["Depth_mid_m"].astype(float).tolist(),
        value=profile["Initial_theta_m3m3"].astype(float).tolist(),
    )


def build_irrigation():
    schedule = pd.DataFrame(IRRIGATION_EVENTS, columns=["Date","Depth"])
    schedule["Date"] = pd.to_datetime(schedule["Date"])
    schedule["Depth"] = schedule["Depth"].astype(float)
    total = float(schedule["Depth"].sum())
    irr = IrrigationManagement(
        irrigation_method=3, Schedule=schedule.copy(),
        MaxIrr=float(schedule["Depth"].max()+0.1),
        MaxIrrSeason=float(total+0.1),
        WetSurf=WET_SURF, AppEff=APP_EFF,
    )
    return irr, schedule, total


def build_crop(p):
    crop = Crop(
        "Maize",
        planting_date=PLANT_DATE.strftime("%m/%d"),
        harvest_date=HARVEST_DATE.strftime("%m/%d"),
    )
    crop.CCx = float(p["CCx"])
    crop.CGC_CD = float(p["CGC_CD"])
    crop.CDC_CD = float(p["CDC_CD"])
    crop.SenescenceCD = int(round(p["SenescenceCD"]))
    crop.MaturityCD = int(MATURITY_CD)
    crop.HIstartCD = int(HISTART_CD)
    crop.WP = float(p["WP"])
    crop.HI0 = float(p["HI0"])

    if hasattr(crop,"CGC"): crop.CGC = float(p["CGC_CD"])
    if hasattr(crop,"CDC"): crop.CDC = float(p["CDC_CD"])
    if hasattr(crop,"Senescence"): crop.Senescence = int(round(p["SenescenceCD"]))
    if hasattr(crop,"Maturity"): crop.Maturity = int(MATURITY_CD)
    if hasattr(crop,"HIstart"): crop.HIstart = int(HISTART_CD)
    return crop


def build_field(fmulch):
    return FieldMngt(
        mulches=True, mulch_pct=MULCH_PCT, f_mulch=float(fmulch),
        bunds=False, curve_number_adj=False, sr_inhb=False,
    )


def run_model(weather, profile, obs, p):
    irrigation,_,expected_iw = build_irrigation()
    model = AquaCropModel(
        sim_start_time=f"{YEAR}/01/01",
        sim_end_time=f"{YEAR}/12/31",
        weather_df=weather.copy(),
        soil=build_soil(),
        crop=build_crop(p),
        initial_water_content=build_initial(profile),
        irrigation_management=irrigation,
        field_management=build_field(p["f_mulch"]),
    )
    model.run_model(till_termination=True)

    stats = model._outputs.final_stats.copy()
    growth = model._outputs.crop_growth.copy()
    flux = model._outputs.water_flux.copy()

    y = float(stats["Dry yield (tonne/ha)"].iloc[-1])
    iw = float(stats["Seasonal irrigation (mm)"].iloc[-1])

    dap = pd.to_numeric(growth["dap"],errors="coerce").to_numpy()
    cc = pd.to_numeric(growth["canopy_cover"],errors="coerce").to_numpy()
    valid = np.isfinite(dap)&np.isfinite(cc)&(dap>0)
    dap = dap[valid].astype(int)
    cc = cc[valid].astype(float)

    dates = np.datetime64(PLANT_DATE.date()) + (dap-1).astype("timedelta64[D]")
    lookup = {d:c for d,c in zip(dates,cc)}

    obs_dates = obs["Date"].to_numpy(dtype="datetime64[D]")
    obs_cc = obs["Observed_CC"].to_numpy(float)
    weights = obs["Weight"].to_numpy(float)
    sim_cc = np.array([lookup.get(d,np.nan) for d in obs_dates],dtype=float)

    if np.any(~np.isfinite(sim_cc)):
        raise ValueError("Could not match all observed CC dates.")

    resid = sim_cc - obs_cc
    rmse = float(np.sqrt(np.mean(resid**2)))
    wrmse = float(np.sqrt(np.sum(weights*resid**2)/np.sum(weights)))

    es = safe_sum(flux,["Es","Soil evaporation"])
    tr = safe_sum(flux,["Tr","Transpiration"])
    trpot = safe_sum(flux,["TrPot","TrPot_NS","Potential transpiration"])

    row = {k:float(p[k]) for k in PARAM_KEYS}
    row.update({
        "Yield_t_ha":y,
        "Yield_error_pct":(y-OBS_YIELD)/OBS_YIELD*100.0,
        "CC_RMSE":rmse,
        "CC_weighted_RMSE":wrmse,
        "Observed_peak_CC":float(np.max(obs_cc)),
        "Sim_peak_CC":float(np.max(cc)),
        "Es_mm":es,
        "Es_error_mm":es-OBS_ES,
        "Tr_mm":tr,
        "TrPot_mm":trpot,
        "Irrigation_mm":iw,
        "Irrigation_expected_mm":expected_iw,
    })
    return row


def draw_prior(rng):
    return {
        k:rng.uniform(lo,hi)
        for k,(lo,hi) in PARAM_RANGES.items()
    }


def main():
    weather,wpath = read_weather()
    obs,cpath = read_cc()
    profile = read_initial_water()
    _,schedule,irr_total = build_irrigation()

    initial_water_mm = float(
        np.sum(
            profile["Initial_theta_m3m3"].astype(float).to_numpy() *
            profile["Thickness_m"].astype(float).to_numpy() * 1000
        )
    )

    print("="*100)
    print(f"{YEAR} DI — PRE‑MCMC PRIOR / INPUT DIAGNOSTIC")
    print("="*100)
    print("Weather:",wpath)
    print("CC:",cpath)
    print(f"Initial water: {initial_water_mm:.2f} mm")
    print(f"Observed Yield: {OBS_YIELD:.3f} t/ha")
    print(f"Observed Es: {OBS_ES:.1f} mm")
    print(f"Irrigation: {irr_total:.2f} mm in {len(schedule)} events")
    print(f"CC observations: {len(obs)}")

    print("\nINIT_CENTER TEST")
    init = run_model(weather,profile,obs,INIT_CENTER)
    pd.DataFrame([init]).to_csv(
        os.path.join(OUTPUT_DIR,"INIT_CENTER_result.csv"),
        index=False,encoding="utf-8-sig"
    )
    for k in [
        "Yield_t_ha","Yield_error_pct","CC_RMSE","CC_weighted_RMSE",
        "Observed_peak_CC","Sim_peak_CC","Es_mm","Es_error_mm",
        "Tr_mm","TrPot_mm","Irrigation_mm"
    ]:
        print(f"{k:24s}: {init[k]:.6f}")

    print("\nPRIOR PREDICTIVE ENSEMBLE")
    rng = np.random.default_rng(RANDOM_SEED)
    rows = []
    for i in range(1,N_PRIOR_SAMPLES+1):
        p = draw_prior(rng)
        try:
            row = run_model(weather,profile,obs,p)
            row["Run"] = i
            row["Status"] = "OK"
        except Exception as e:
            row = {"Run":i,"Status":"FAILED","Error":repr(e),**p}
        rows.append(row)
        if i%20==0 or i==N_PRIOR_SAMPLES:
            print(f"Completed {i}/{N_PRIOR_SAMPLES}")

    df = pd.DataFrame(rows)
    df.to_csv(
        os.path.join(OUTPUT_DIR,"prior_predictive_all.csv"),
        index=False,encoding="utf-8-sig"
    )
    ok = df[df["Status"]=="OK"].copy()
    if ok.empty:
        raise RuntimeError("All prior predictive runs failed.")

    metrics = [
        "Yield_t_ha","CC_RMSE","CC_weighted_RMSE",
        "Sim_peak_CC","Es_mm","Tr_mm","TrPot_mm"
    ]
    summary = []
    for m in metrics:
        v = pd.to_numeric(ok[m],errors="coerce").dropna().to_numpy()
        summary.append({
            "Metric":m,"N":len(v),"Min":np.min(v),
            "P2.5":np.percentile(v,2.5),"Median":np.median(v),
            "P97.5":np.percentile(v,97.5),"Max":np.max(v)
        })
    summary = pd.DataFrame(summary)
    summary.to_csv(
        os.path.join(OUTPUT_DIR,"prior_predictive_summary.csv"),
        index=False,encoding="utf-8-sig"
    )

    ylo,yhi = np.percentile(ok["Yield_t_ha"],[2.5,97.5])
    elo,ehi = np.percentile(ok["Es_mm"],[2.5,97.5])

    print("\nPRIOR PREDICTIVE SUMMARY")
    print(summary.round(5).to_string(index=False))
    print(
        f"\nObserved Yield {OBS_YIELD:.3f} inside 95% prior‑predictive "
        f"[{ylo:.3f},{yhi:.3f}]? {ylo <= OBS_YIELD <= yhi}"
    )
    print(
        f"Observed Es {OBS_ES:.1f} inside 95% prior‑predictive "
        f"[{elo:.2f},{ehi:.2f}]? {elo <= OBS_ES <= ehi}"
    )

    top = ok.sort_values(["CC_weighted_RMSE","CC_RMSE"]).head(20)
    top.to_csv(
        os.path.join(OUTPUT_DIR,"TOP20_prior_samples_by_CC.csv"),
        index=False,encoding="utf-8-sig"
    )
    print("\nTOP 10 PRIOR SAMPLES BY WEIGHTED CC RMSE")
    print(
        top[PARAM_KEYS+["Yield_t_ha","CC_weighted_RMSE","Sim_peak_CC","Es_mm","Tr_mm"]]
        .head(10).round(6).to_string(index=False)
    )


if __name__ == "__main__":
    main()
