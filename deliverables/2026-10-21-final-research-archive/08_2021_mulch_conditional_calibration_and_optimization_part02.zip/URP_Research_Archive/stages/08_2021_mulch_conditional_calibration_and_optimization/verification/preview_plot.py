from pathlib import Path
p=Path('code/plot_comparison.py');s=p.read_text();s=s[:s.index('    # Theme 3:')]
s=s.replace("fronts=read('All_scenario_NSGA3_fronts');sel=read('Selected_front_comparisons')",'fronts=pd.DataFrame();sel=pd.DataFrame()')
s+="\n    print('PREVIEW DONE',len(REG),flush=True)\n\nmain()\n"
exec(compile(s,str(p),'exec'))
