const loadData = require("../../lib/data.js");
const PingguRouter = require("../../lib/router.js");

const stages = [
  ["92.17%", 406, 0], ["92.91%", 394, 3411],
  ["93.53%", 384, 6249], ["94.12%", 368, 8903],
];
const colors = {
  background: "#edf3f4", district: "#fbfcfa", boundary: "#577581",
  roads: "#a6b8be", facilities: "#458394", origin: "#0e6b73",
  target: "#d36a42", route: "#146c9c", connector: "#bf702f",
  existing: "#dfe9eb", added: "#267375", gap: "#edc9a6", isolated: "#746c86",
};
const span = (x) => x < 1000 ? Math.round(x) + " 米" : (x / 1000).toFixed(2) + " 公里";
function bounds(points) {
  const min = [Infinity, Infinity], max = [-Infinity, -Infinity];
  for (const [x, y] of points) {
    min[0] = Math.min(min[0], x); min[1] = Math.min(min[1], y);
    max[0] = Math.max(max[0], x); max[1] = Math.max(max[1], y);
  }
  return [...min, ...max];
}
function clamp(value, lower, upper) { return Math.max(lower, Math.min(upper, value)); }

Page({
  data: {
    mode: "route", distance: 1000, stage: 0, stageLabels: ["现状", "补 1 处", "补 2 处", "补 3 处"],
    heat: false, coverage: "92.17%", scenarioSummary: "现状未覆盖 406 格，其中 40 格模型无路径。",
    hasOrigin: false, originTag: "", active: 0, results: [], message: "正在加载研究路网…",
    attention: false, scaleLabel: "N ↑",
  },

  onReady() {
    try {
      this.networkData = loadData();
      this.router = new PingguRouter(this.networkData);
      const rings = [].concat(...this.networkData.district);
      this.extent = bounds([].concat(...rings));
    } catch (error) {
      this.setData({ message: "研究路网加载失败，请重新打开小程序。", attention: true });
      console.error(error);
      return;
    }
    this.openMap();
  },

  onResize() { if (this.router) this.openMap(); },
  onPageScroll(event) { this.scrollY = event.scrollTop; },
  onShareAppMessage() {
    return { title: "平谷就医地图 · 查附近基层医疗点", path: "/pages/index/index" };
  },

  openMap() {
    wx.createSelectorQuery().in(this).select("#map")
      .fields({ node: true, size: true, rect: true }).exec((nodes) => {
      const found = nodes && nodes[0];
      if (!found || !found.node || !found.width || !found.height) {
        this.setData({ message: "地图无法初始化，请检查微信版本。", attention: true });
        return;
      }
      this.canvas = found.node;
      const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
      this.ratio = Math.min(info.pixelRatio || 1, 2);
      this.canvas.width = Math.round(found.width * this.ratio);
      this.canvas.height = Math.round(found.height * this.ratio);
      this.context = this.canvas.getContext("2d");
      this.view = { width: found.width, height: found.height, left: found.left || 0,
        pageTop: (found.top || 0) + (this.scrollY || 0), centre: [0, 0], px: 1 };
      const image = this.canvas.createImage();
      this.heatImage = null;
      this.heatUnavailable = false;
      image.onload = () => { this.heatImage = image; this.requestDraw(); };
      image.onerror = () => { this.heatUnavailable = true; };
      image.src = "/assets/heat.png";
      this.fit(this.extent);
      if (!this.initialized) {
        this.initialized = true;
        this.search(this.networkData.demo, "sample");
      }
      this.requestDraw();
    });
  },

  fit(box) {
    if (!this.view) return;
    const [left,bottom,right,top] = box;
    const v = this.view;
    v.centre = [(left + right) / 2, (bottom + top) / 2];
    v.px = Math.min((v.width - 42) / Math.max(280,right-left),
                    (v.height - 53) / Math.max(280,top-bottom));
    this.requestDraw();
  },

  screen([x,y]) {
    const v = this.view;
    return [v.width / 2 + (x - v.centre[0]) * v.px,
            v.height / 2 - (y - v.centre[1]) * v.px];
  },
  world([x,y]) {
    const v = this.view;
    return [v.centre[0] + (x - v.width / 2) / v.px,
            v.centre[1] - (y - v.height / 2) / v.px];
  },
  scaleAround(factor, point) {
    const fixed = this.world(point);
    const v = this.view;
    v.px = clamp(v.px * factor, .003, 1.5);
    const moved = this.world(point);
    v.centre[0] += fixed[0] - moved[0];
    v.centre[1] += fixed[1] - moved[1];
    this.requestDraw();
  },
  zoomMap(event) {
    if (!this.view) return;
    const action = event.currentTarget.dataset.zoom;
    if (action === "reset") this.fit(this.extent);
    else this.scaleAround(action === "in" ? 1.35 : 1 / 1.35,
                          [this.view.width / 2, this.view.height / 2]);
  },

  local(touch) {
    if (Number.isFinite(touch.x) && Number.isFinite(touch.y)) return [touch.x,touch.y];
    const v = this.view;
    return [touch.clientX - v.left, touch.clientY - v.pageTop + (this.scrollY || 0)];
  },
  touchStart(event) {
    if (!this.view || !event.touches.length) return;
    this.gesture = { start: this.local(event.touches[0]), drag:false, pinch:0 };
    this.gesture.last = this.gesture.start;
    if (event.touches.length > 1) this.gesture.drag = true;
  },
  touchMove(event) {
    if (!this.gesture || !event.touches.length) return;
    const p = this.local(event.touches[0]), g = this.gesture;
    if (event.touches.length > 1) {
      const q = this.local(event.touches[1]);
      const length = Math.hypot(p[0]-q[0],p[1]-q[1]);
      if (g.pinch > 0 && length > 0) this.scaleAround(length/g.pinch,[(p[0]+q[0])/2,(p[1]+q[1])/2]);
      g.pinch = length; g.drag = true; g.last = p; return;
    }
    if (g.pinch) { g.last = p; g.pinch = 0; return; }
    if (!g.drag && Math.hypot(p[0]-g.start[0],p[1]-g.start[1]) > 5) g.drag = true;
    if (g.drag) {
      this.view.centre[0] -= (p[0] - g.last[0]) / this.view.px;
      this.view.centre[1] += (p[1] - g.last[1]) / this.view.px;
      g.last = p;
      this.requestDraw();
    }
  },
  touchEnd(event) {
    if (!this.gesture || event.touches.length) return;
    const first = event.changedTouches[0];
    if (first && !this.gesture.drag && this.data.mode === "route") {
      this.search(this.world(this.local(first)), "map");
    }
    this.gesture = null;
  },
  touchCancel() { this.gesture = null; },

  search(point, kind) {
    if (!this.router) return;
    this.origin = point;
    this.originKind = kind;
    const result = this.router.search(point, this.data.distance);
    this.routes = result.routes;
    let message = result.error;
    if (!message) {
      message = result.fallback ? "范围内无可达设施。下方是超出范围的最近结果。"
        : span(this.data.distance) + "以内，显示最近 " + result.routes.length + " 家。";
    }
    this.setData({
      hasOrigin: true, originTag: kind === "sample" ? "示例起点 · 大华山镇" : "地图选点",
      attention: Boolean(result.error || result.fallback), message, active: 0,
      results: result.routes.map(r => ({
        id: r.facility[0], name: r.facility[1], kind: r.facility[2], total: span(r.total),
        road: span(r.road), access: span(r.initial + r.final),
      })),
    });
    this.requestDraw();
  },
  changeDistance(event) {
    const distance = Number(event.currentTarget.dataset.distance);
    this.setData({ distance }, () => {
      if (this.origin) this.search(this.origin, this.originKind);
    });
  },
  showExample() {
    if (!this.networkData) return;
    this.search(this.networkData.demo, "sample");
    this.fitRoute(this.routes[0]);
  },
  clearRoute() {
    this.origin = null; this.routes = [];
    this.setData({hasOrigin:false,originTag:"",results:[],active:0,attention:false,
                  message:"轻点地图选起点，或查看大华山镇示例。"});
    this.requestDraw();
  },
  chooseResult(event) {
    const index = Number(event.currentTarget.dataset.index);
    this.setData({ active:index });
    this.fitRoute(this.routes[index]);
  },
  fitRoute(route) {
    if (!route) return;
    const viewPoints = [route.origin,route.facility[3]];
    for (const segment of route.segments) viewPoints.push(...segment);
    const [a,b,c,d] = bounds(viewPoints);
    this.fit([a-90,b-90,c+90,d+90]);
  },

  switchMode(event) {
    const mode = event.currentTarget.dataset.mode;
    this.setData({ mode });
    if (this.extent) this.fit(this.extent);
  },
  changeStage(event) {
    this.scenario(Number(event.currentTarget.dataset.stage),false);
  },
  toggleHeat() {
    if (!this.data.heat && !this.heatImage) {
      wx.showToast({ title: this.heatUnavailable ? "热点图无法读取" : "热点图正在载入", icon:"none" });
      return;
    }
    this.scenario(this.data.heat ? this.data.stage : 3,!this.data.heat);
  },
  scenario(stage, heat) {
    const [coverage, remaining, gain] = stages[stage];
    const scenarioSummary = stage ? "剩余 " + remaining + " 格 · 累计新增人口权重约 " + gain
      : "现状未覆盖 " + remaining + " 格，其中 40 格模型无路径。";
    this.setData({stage,heat,coverage,scenarioSummary});
    this.requestDraw();
  },

  requestDraw() {
    if (!this.canvas || this.paintRequested) return;
    this.paintRequested = true;
    const paint = () => { this.paintRequested = false; this.draw(); };
    if (this.canvas.requestAnimationFrame) this.canvas.requestAnimationFrame(paint);
    else wx.nextTick(paint);
  },
  trace(points, closed) {
    if (!points.length) return;
    const ctx = this.context;
    ctx.moveTo(...this.screen(points[0]));
    for(let i=1; i<points.length; i++) ctx.lineTo(...this.screen(points[i]));
    if (closed) ctx.closePath();
  },
  tracePolys(polys) {
    for (const polygon of polys) for (const ring of polygon) this.trace(ring,true);
  },
  stroke(color,width) {
    this.context.strokeStyle=color; this.context.lineWidth=width; this.context.stroke();
  },
  fill(color) { this.context.fillStyle=color; this.context.fill(); },
  dot(point,r,color) {
    const [x,y]=this.screen(point), ctx=this.context;
    if(x < -10 || y < -10 || x > this.view.width+10 || y > this.view.height+10) return;
    ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);
    this.fill(color);this.stroke("#fff",1.2);
  },
  draw() {
    const ctx = this.context, data = this.networkData, v = this.view;
    if (!ctx || !data) return;
    ctx.setTransform(this.ratio,0,0,this.ratio,0,0);
    ctx.fillStyle=colors.background;ctx.fillRect(0,0,v.width,v.height);
    ctx.beginPath();this.tracePolys(data.district);this.fill(colors.district);
    if(this.data.mode==="route") {
      ctx.beginPath();
      for(const road of data.roads)this.trace(road,false);
      this.stroke(colors.roads,v.px>.045?.85:.48);
    } else if(this.data.heat && this.heatImage) {
      const [a,b,c,d]=data.heat;
      const [x,y]=this.screen([a,d]);
      ctx.drawImage(this.heatImage,x,y,(c-a)*v.px,(d-b)*v.px);
    } else {
      const bins = {existing:[],added:[],gap:[],isolated:[]};
      for(const [stage,isolated,polys] of data.grids) {
        const key=stage===0 ? "existing" : stage>0 && stage<=this.data.stage ? "added" : isolated ? "isolated" : "gap";
        bins[key].push(polys);
      }
      for(const [key,group] of Object.entries(bins)) {
        ctx.beginPath();
        for(const polys of group)this.tracePolys(polys);
        this.fill(colors[key]);
      }
    }
    ctx.beginPath();
    for(const town of data.towns)this.tracePolys(town[1]);
    this.stroke("#819a9d",.65);
    ctx.beginPath();this.tracePolys(data.district);this.stroke(colors.boundary,1);
    if(this.data.mode==="route")this.drawRoutes();
    else this.drawCandidates();
    const metres=[10000,5000,2000,1000,500,200,100,50,20].find(n=>n*v.px<=75) || 20;
    const scaleWidth=metres*v.px, scaleY=v.height-12;
    ctx.beginPath();ctx.moveTo(18,scaleY);ctx.lineTo(18+scaleWidth,scaleY);this.stroke("#405968",1.5);
    const scaleLabel = "N ↑　" + (metres>=1000 ? metres/1000+" km" : metres+" m");
    if(this.data.scaleLabel!==scaleLabel)this.setData({scaleLabel});
  },
  drawRoutes() {
    for(const f of this.networkData.facilities)this.dot(f[3],2.5,colors.facilities);
    const route=this.routes && this.routes[this.data.active];
    if(route) {
      const ctx=this.context;
      ctx.beginPath();
      for(const seg of route.segments)this.trace(seg,false);
      ctx.lineCap="round";ctx.lineJoin="round";
      this.stroke("#fff",7);this.stroke(colors.route,4);
      ctx.setLineDash([5,4]);ctx.beginPath();
      if(route.initial>0)this.trace([route.origin,route.snapped],false);
      if(route.final>0)this.trace([route.facility[4],route.facility[3]],false);
      this.stroke(colors.connector,2.3);ctx.setLineDash([]);
      this.dot(route.facility[3],6.5,colors.target);
    }
    if(this.origin)this.dot(this.origin,5.5,colors.origin);
  },
  drawCandidates() {
    const ctx=this.context;
    for(const [number,,,,p] of this.networkData.candidates) {
      this.dot(p,9,number<=this.data.stage?"#174f60":"#6d7f88");
      const [x,y]=this.screen(p);
      ctx.textAlign="center";ctx.textBaseline="middle";ctx.font="bold 11px sans-serif";
      ctx.fillStyle="#fff";ctx.fillText(String(number),x,y+.5);
    }
  },
});
