# 平谷区基层医疗可达性与补点规划

本包统一采用白底、深蓝标题、细边框和蓝色分级。地图以既有 1 km 网格、最短路网距离和模拟补点结果重绘。投影汇报用 PPTX，另有 PDF 预览。

## 打开成果

- `presentation/pinggu_medical_access_report.pptx` 是 10 页汇报，标题、指标、图例和正文可编辑。地图使用包内导出的高清图件。
- `maps/` 提供 7 张 PNG 和 PDF，包括乡镇 3 km、乡镇 1 km、全区 1 km 网格、三个候选点和热点。两个名称含 1 km 的成果分别是 **1 km 路网阈值的乡镇统计**和**1 km 分析网格的全区方案图**，后者仍采用 3 km 路网阈值。
- `maps/frames/` 是同一视野下现状到补 3 处的四个重绘帧。
- `database/pinggu_medical_access.qgz` 是可移动的 QGIS 工程。解压完整 ZIP 后打开，保留同目录 GPKG 和 TIF 的相对位置。
- `database/pinggu_medical_access.gpkg` 是 SQLite/OGC GeoPackage 数据库，含 13 个空间矢量层、2 个核密度栅格及 3 张属性表。原始 10 m TCC10 参考裁剪和核密度 GeoTIFF 同目录存放，QML 提供一致的前后色标。
- `sources/source_catalog.csv` 说明来源、年份、用途、已归档位置及缺件。原上传资料及可获得的外部参考包见 `sources/`，用于复核的原始交付和中间数据见 `work/`。
- `code/` 包含数据库、QGIS 工程、地图、热点分析及 PPT 生成代码。`archive/` 保留此前可取得的正式导出和旧版制图脚本。

## 数据库索引

| 表名或图层名 | 内容 |
|---|---|
| `district_boundary`、`towns_osm_reference`、`town_access` | 平谷区界、OSM 参考乡镇面、实际用于统计的 18 个乡镇 |
| `grid_1km`、`demand_network_points`、`baseline_grid_access` | 1 km 原始网格、需求点路网结果、基线最短路网距离 |
| `facilities_all`、`facilities_primary`、`roads_osm`、`road_nodes` | 医疗设施、基层设施、分段道路、节点 |
| `scenario_grid_1km`、`candidate_sites`、`no_model_path_grid` | 网格覆盖状态、三个候选点、40 个无路径网格 |
| `kde_before`、`kde_after` | 同一像元和掩膜的补点前后核密度，保留浮点值 |
| `scenario_summary`、`source_catalog`、`method_parameters` | 阶段结果、来源归档清单、方法参数 |

主要矢量和核密度采用 EPSG:32650。TCC10 保留来源的 EPSG:4548。QGIS 自动按工程坐标系显示。

## 复核与再生成

在包含本 README 的目录下运行。数据库已有结果时，先将现有 GPKG 移到备份位置再重建。前三个绘图步骤需要 GDAL Python、NumPy 和 Matplotlib。QGIS 工程需用含 PyQGIS 的 Python，PPT 需 python-pptx 和 Pillow。

```text
python code/build_database.py
python code/draw_maps.py
python code/build_presentation.py
python code/build_qgis_project.py
```

执行地图脚本前需安装支持中文的字体。如果系统已有 CJK 字体但 Matplotlib 未识别，可把常规和粗体的 OTF 文件路径通过环境变量 `PINGGU_CJK_FONTS` 传入，按操作系统的路径分隔符连接。可选脚本 `code/build_hotspots.py` 独立重算核密度并输出到 `rebuilt_hotspots/`。`work/` 中的早期采集脚本有原环境和数据依赖，主要用于追溯来源。

## 结果口径

- 全区权重 457,000。基线 633 格覆盖，覆盖率 92.17%。补 1、2、3 处后依次为 92.91%、93.53%、94.12%。
- 三处边际新增分别为 12、10、16 格，共 38 格，未覆盖人口权重相对减少 24.9%。补点后仍有 328 格超过 3 km 和 40 格模型无路径。
- 乡镇覆盖率按相交面积分摊。空间边界的未分配余量保留在原始乡镇 CSV，未计作一个乡镇。
- 热点以 1 km 网格内代表点的未覆盖人口权重构建。高斯核标准差 1.5 km，100 m 是制图像元。热点峰值在王辛庄镇附近。
- 模拟图用于筛查。实际通行、居民点和机构服务能力需核查。道路与主分析区界含 OpenStreetMap 数据，© OpenStreetMap contributors。TCC10 来源和授权见 `sources/TCC10_说明.md`。

## 待补文件

已收到的 B 组包内有处理后网格、道路和 POI。原始北京 POI CSV、原始 OSM PBF 和全国 WorldPop TIF 未随包上传。已从此前 GitHub 归档找回 TCC10 原值参考裁剪。原 Windows QGIS 工程、旧 PNG 和原电脑中的 DEM、坡度、TCC10 二次裁剪及地形汇总仍缺原件，不能逐文件还原。现有关键图均基于已归档数据重绘。
