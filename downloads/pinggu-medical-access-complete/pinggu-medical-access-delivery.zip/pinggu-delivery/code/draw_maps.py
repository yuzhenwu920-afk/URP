"""Generate the coordinated atlas and its four animation keyframes."""
from itertools import chain
import os
from pathlib import Path
import sqlite3

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager, patheffects
from matplotlib.collections import LineCollection, PatchCollection
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import PathPatch, Rectangle
from matplotlib.path import Path as PlotPath
import numpy as np
from osgeo import gdal, ogr

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "maps"
DB_PATH = ROOT / "database/pinggu_medical_access.gpkg"
for file in os.getenv("PINGGU_CJK_FONTS", "").split(os.pathsep):
    if file:
        font_manager.fontManager.addfont(file)
wanted = ("Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans CJK JP", "SimHei")
installed = set(font.name for font in font_manager.fontManager.ttflist)
font = next((name for name in wanted if name in installed), None)
if font is None:
    raise RuntimeError("Install a Chinese font or set PINGGU_CJK_FONTS.")
plt.rcParams.update({"font.family":font, "pdf.fonttype":42, "axes.unicode_minus":False})
ogr.UseExceptions()
gdal.UseExceptions()
INK, MID, RULE = "#15395a", "#486481", "#b9c6d2"
BLUE = ("#dcebf6", "#a2cade", "#458fb8", "#145695")
BASE, NEW, GAP, HATCH = "#e7edf2", "#216eab", "#a9c9df", "#527399"
SITE, PEAK = "#1b3d5d", "#874b72"
DB = ogr.Open(str(DB_PATH))
with sqlite3.connect(DB_PATH) as con:
    summary = {row[0]:row[1:] for row in con.execute(
        "SELECT stage, covered_cells, coverage_pct, remaining_cells, remaining_weight FROM scenario_summary"
    )}

def records(layer, fields, where=None):
    layer = DB.GetLayerByName(layer)
    layer.SetAttributeFilter(where)
    return [(row.GetGeometryRef().Clone(), *(row[k] for k in fields)) for row in layer]

district = records("district_boundary", [])
towns = records("town_access", ["name", "pct_1km", "pct_3km"])
grids = records("scenario_grid_1km", ["gid", "stage", "map_class", "pop_cal", "net_dist_m"])
points = sorted(records("candidate_sites", ["stage", "gid", "town", "new_cells", "new_pop_weight"]),
                key=lambda row: row[1])
fac = records("facilities_primary", ["name"], "in_bnd=1")
roads = records("roads_osm", ["highway"], "highway IN ('motorway','trunk','primary','secondary','tertiary')")
assert len(towns)==18 and len(grids)==1039 and len(points)==3
outline = district[0][0]

def iter_lines(geom):
    if geom.GetGeometryName() in {"LINESTRING", "LINEARRING"}:
        yield np.array(geom.GetPoints())[:, :2]
    else:
        for i in range(geom.GetGeometryCount()):
            yield from iter_lines(geom.GetGeometryRef(i))

def polygon_patch(geom):
    vertices, codes = [], []
    for ring in iter_lines(geom):
        vertices.extend(ring)
        codes.extend([PlotPath.MOVETO, *([PlotPath.LINETO] * (len(ring)-2)), PlotPath.CLOSEPOLY])
    return PathPatch(PlotPath(np.asarray(vertices), codes))

def env(geom, pad=0):
    a,b,c,d = geom.GetEnvelope()
    return a-pad,b+pad,c-pad,d+pad

def draw_lines(ax, geometries, color, width, z, alpha=1):
    segments = list(chain.from_iterable(iter_lines(g) for g in geometries))
    ax.add_collection(LineCollection(segments, colors=color, linewidths=width, alpha=alpha, zorder=z))

def base(title, subtitle, frame=True):
    fig = plt.figure(figsize=(14, 9.5), facecolor="white")
    fig.text(.5,.942,title,ha="center",fontsize=30,weight="bold",color=INK)
    fig.text(.5,.888,subtitle,ha="center",fontsize=16,color=MID)
    if frame:
        fig.add_artist(Rectangle((.057,.10),.886,.747,fill=False,
                                 linewidth=.9,edgecolor=RULE,transform=fig.transFigure))
    return fig

def map_axes(fig, extent, loc=(.09,.137,.73,.682)):
    ax = fig.add_axes(loc)
    a,b,c,d = extent
    ax.set_xlim(a,b)
    ax.set_ylim(c,d)
    ax.set_aspect("equal")
    ax.axis("off")
    return ax

def north_scale(ax, metres):
    ax.annotate("", xy=(.964,.96), xytext=(.964,.907), xycoords="axes fraction",
                arrowprops={"arrowstyle":"-|>", "color":INK, "lw":1.2})
    ax.text(.964,.966,"N",ha="center", va="bottom",transform=ax.transAxes,fontsize=11,color=INK)
    a,b = ax.get_xlim()
    c,d = ax.get_ylim()
    x,y = a+.035*(b-a),c+.033*(d-c)
    ax.plot([x,x+metres],[y,y],color=INK,lw=2.2,zorder=12)
    ax.text(x+metres*.5,y+.012*(d-c),f"{metres/1000:g} km",ha="center",fontsize=11,color=INK,zorder=12)

def point(ax, geom, number, size=300):
    x,y = geom.GetX(),geom.GetY()
    ax.scatter(x,y,s=size,color=SITE,edgecolor="white",linewidth=1.5,zorder=10)
    ax.text(x,y,str(number),ha="center",va="center",color="white",fontsize=12,weight="bold",zorder=11)

def note(fig, value):
    fig.text(.5,.055,value,ha="center",color=MID,fontsize=11)

def lines_panel(fig, x, y, heading, rows):
    fig.text(x,y,heading,fontsize=15,weight="bold",color=INK)
    for n,value in enumerate(rows,1):
        fig.text(x,y-.044*n,value,fontsize=12,color=MID)

def legend(fig, items, box=(.765,.13,.155,.21)):
    x,y,w,h = box
    fig.add_artist(Rectangle((x,y),w,h,facecolor="white",edgecolor=RULE,linewidth=.75,
                             transform=fig.transFigure))
    step = (.8*h)/len(items)
    for i,(color,label,pattern) in enumerate(items):
        h0 = y+h*.87-i*step
        fig.add_artist(Rectangle((x+.012,h0-.016),.021,.020,
                      facecolor=color,edgecolor=HATCH if pattern else color,hatch=pattern,
                      linewidth=.45,transform=fig.transFigure))
        fig.text(x+.042,h0-.006,label,color=INK,fontsize=11,va="center")

def save(fig, stem, pdf=True):
    out = OUT / stem
    out.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(out.with_suffix(".png"),dpi=240,facecolor="white")
    if pdf:
        fig.savefig(out.with_suffix(".pdf"),dpi=240,facecolor="white")
    plt.close(fig)

for threshold, column, limits, filename in (
    (3,3,(60,70,80,90,100),"01_town_3km"),
    (1,2,(0,20,40,60,80,100),"01b_town_1km"),
):
    ramp = BLUE if threshold==3 else ("#eef5fa",*BLUE)
    fig=base("平谷区各乡镇基层医疗服务可达性",f"{threshold} km 路网距离人口权重覆盖率")
    ax=map_axes(fig,env(outline,1000),(.103,.135,.74,.689))
    for row in towns:
        geom,name,*_=row
        value=row[column]  # fields: geometry, name, pct_1km, pct_3km
        assert isinstance(value, (int,float)) and limits[0]-1e-5 <= value <= 100+1e-5, (name,value)
        index=int(np.clip(np.searchsorted(limits[1:-1], value, side="right"),0,len(ramp)-1))
        patch=polygon_patch(geom)
        patch.set(facecolor=ramp[index],edgecolor="#ffffff",linewidth=.65)
        ax.add_patch(patch)
        label_geom=geom.PointOnSurface()
        x,y=label_geom.GetX(),label_geom.GetY()
        shifts={"兴谷街道":(800,340),"滨河街道":(1150,-50),"平谷镇":(-940,-650),
                "大兴庄镇":(-350,220),"山东庄镇":(0,280)}
        dx,dy=shifts.get(name,(0,0))
        if name in shifts:
            ax.plot([x,x+dx],[y,y+dy],color="#436486",lw=.6,zorder=3)
        ax.text(x+dx,y+dy,name,ha="center",va="center",fontsize=11,color=INK,zorder=4,
                path_effects=[patheffects.withStroke(linewidth=2.6,foreground="white")])
    north_scale(ax,5000)
    categories = [(color, f"{lo}–<{hi}%" if hi<100 else f"{lo}–100%",None)
                  for color,lo,hi in zip(ramp,limits,limits[1:])]
    legend(fig,categories,(.778,.126,.143,.19))
    note(fig,"乡镇边界约 2020 年 · 网格人口按相交面积分摊 · v0 试算")
    save(fig,filename)

key=[(BASE,"现状 3 km 内覆盖",None),(NEW,"补点新增覆盖",None),
     (GAP,"仍超过 3 km",None),("#eff4f8","模型无路径","////")]
def coverage_map(ax, stage, local=False):
    style = {BASE:[], NEW:[], GAP:[], HATCH:[]}
    for geom,gid,opened,klass,_,_ in grids:
        color = BASE if opened==0 else NEW if 0<opened<=stage else (
            HATCH if klass=="no_model_path" else GAP
        )
        if local and 0<opened<stage:
            color=BASE
        style[color].append(polygon_patch(geom))
    for color,patches in style.items():
        ax.add_collection(PatchCollection(patches,facecolor="#eff4f8" if color==HATCH else color,
                          edgecolor=HATCH if color==HATCH else ("#ffffff" if local else "none"),
                          linewidth=.18 if local else 0,hatch="////" if color==HATCH else None,zorder=1))
    draw_lines(ax,[outline],INK,.85,4)
    if local:
        draw_lines(ax,[r[0] for r in roads],"#344f6a",.49,3,.53)
        xy=[(g.GetX(),g.GetY()) for g,_ in fac]
        ax.scatter(*np.array(xy).T,s=27,color=INK,edgecolor="white",linewidth=.6,zorder=7,clip_on=True)
    else:
        draw_lines(ax,[g for g,*_ in towns],"#ffffff",.75,3,.9)
    for geom,index,*_ in points:
        if (local and index==stage) or (not local and index<=stage):
            point(ax,geom,index)

def overview(stage, filename, pdf=True):
    title="平谷区基层医疗 1 km 网格补点总图"
    if not pdf:
        title=f"平谷区基层医疗覆盖情景 · {'现状' if not stage else f'累计补 {stage} 处'}"
    fig=base(title,"3 km 最短路网距离 · 1 km 人口网格")
    ax=map_axes(fig,env(outline,1300),(.085,.14,.64,.677))
    coverage_map(ax,stage)
    north_scale(ax,5000)
    cells,pct,gap,weight=summary[stage]
    fig.text(.728,.750,f"{pct:.2f}%",fontsize=34,color=INK,weight="bold")
    lines_panel(fig,.728,.682,"人口权重覆盖率",[
        f"覆盖 {cells} 格，仍缺口 {gap} 格",
        f"新增覆盖 {cells-summary[0][0]} 格",
        "40 格模型无路径",
    ])
    legend(fig,key,(.717,.158,.204,.21))
    note(fig,"人口权重按 45.7 万校准 · 分步模拟为顺序边际收益 · v0 试算")
    save(fig,filename,pdf)

overview(3,"02_grid_1km")
for stage in range(4):
    overview(stage,f"frames/frame_{stage:02}",False)

focus={
  1:("查找现有卫生室及可利用用房","比较定点服务与定期巡诊"),
  2:("核实进村道路及季节性通行","确认巡诊车辆可达地点"),
  3:("复核边缘居民点的实际路线","核实现有医疗点的服务能力"),
}
for geom,stage,gid,town,count,weight in points:
    affected=[g for g,_,s,*_ in grids if s==stage]
    assert len(affected)==count
    distance=next(row[5] for row in grids if row[1]==gid)/1000
    extents=list(map(env,affected))
    extent=(min(x[0] for x in extents)-850,max(x[1] for x in extents)+850,
            min(x[2] for x in extents)-850,max(x[3] for x in extents)+850)
    fig=base(f"{town}基层医疗补点方案",f"候选点 {stage} · 3 km 路网覆盖试算与现场核查")
    ax=map_axes(fig,extent,(.074,.139,.592,.670))
    coverage_map(ax,stage,True)
    north_scale(ax,1000)
    inset=map_axes(fig,env(outline,1000),(.774,.577,.114,.203))
    inset.add_patch(polygon_patch(outline))
    inset.patches[-1].set(facecolor="#dcebf6",edgecolor="#6d9cbf",linewidth=.7)
    a,b,c,d=extent
    inset.add_patch(Rectangle((a,c),b-a,d-c,fill=False,edgecolor=PEAK,lw=1.3))
    fig.text(.831,.791,"平谷区定位",ha="center",fontsize=11,color=MID)
    fig.text(.678,.773,f"+{count} 格",fontsize=28,weight="bold",color=INK)
    fig.text(.678,.717,f"≈ {weight:,.0f}",fontsize=21,weight="bold",color=INK)
    fig.text(.678,.677,"新增覆盖人口权重",fontsize=11,color=MID)
    fig.text(.678,.632,f"{distance:.2f} km",fontsize=19,weight="bold",color=INK)
    fig.text(.678,.594,"候选格现状路网距离",fontsize=11,color=MID)
    lines_panel(fig,.678,.534,"现场优先核查",focus[stage])
    legend(fig,[(BASE,"本阶段前已覆盖",None),(NEW,"本次模拟新增",None),(GAP,"本阶段未覆盖",None),
                key[3],(INK,"现有基层医疗点",None)],(.678,.137,.235,.236))
    note(fig,f"候选网格 gid {gid} · 道路及居民点实际情况待现场核查 · v0 试算")
    save(fig,f"0{stage+2}_candidate_{stage}")

tif=gdal.Open(str(ROOT/"database/pinggu_gap_kde_after.tif"))
arr=tif.ReadAsArray()
masked=np.ma.masked_equal(arr,-9999)
x,dx,_,y,_,dy=tif.GetGeoTransform()
b=(x,x+tif.RasterXSize*dx,y+tif.RasterYSize*dy,y)
xs=x+(np.arange(tif.RasterXSize)+.5)*dx
ys=y+(np.arange(tif.RasterYSize)+.5)*dy
peak=np.unravel_index(masked.argmax(),arr.shape)
px,py=xs[peak[1]],ys[peak[0]]
fig=base("平谷区基层医疗服务缺口热点","三处补点后的未覆盖人口权重核密度")
ax=map_axes(fig,env(outline,1100),(.083,.194,.64,.628))
ramp=LinearSegmentedColormap.from_list("coverage_density",
    ["#f1f5fa","#c7deed","#7ab1ce","#367cae","#235685","#292d59"])
hm=ax.imshow(masked,extent=b,origin="upper",cmap=ramp,vmin=0,vmax=150)
ax.contour(xs,ys,masked,[30,60,90,120],colors="#ffffff",alpha=.72,linewidths=.65,zorder=3)
draw_lines(ax,[g for g,*_ in towns],"#455f80",.55,4,.65)
draw_lines(ax,[g for g,*_ in roads],"#335368",.3,2,.45)
draw_lines(ax,[outline],INK,.8,5)
for geom,stage,*_ in points:
    point(ax,geom,stage,230)
ax.scatter(px,py,marker="D",s=135,edgecolor="white",linewidth=1.2,color=PEAK,zorder=11)
north_scale(ax,5000)
cax=fig.add_axes([.174,.156,.455,.022])
cb=fig.colorbar(hm,cax=cax,orientation="horizontal",ticks=[0,30,60,90,120,150])
cb.outline.set_visible(False)
cb.ax.tick_params(labelsize=10,colors=MID)
fig.text(.174,.119,"未覆盖人口权重／km²",fontsize=10,color=MID)
fig.text(.718,.747,"26,893",fontsize=34,weight="bold",color=INK)
lines_panel(fig,.718,.677,"补点后仍未覆盖",["人口权重 · 368 个网格","较现状减少 24.9%"])
fig.text(.718,.493,"王辛庄镇附近",fontsize=19,weight="bold",color=PEAK)
lines_panel(fig,.718,.435,"◆ 剩余密度峰值",["核对居民点及实际进村路线","40 个无路径网格单独核查"])
note(fig,"1 km 输入格网 · 1.5 km 高斯核 · 100 m 制图像元 · 细线为乡镇界及主要道路")
save(fig,"06_gap_hotspots")
