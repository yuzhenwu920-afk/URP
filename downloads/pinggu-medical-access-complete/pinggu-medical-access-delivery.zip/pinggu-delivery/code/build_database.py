"""Build the portable spatial database from the archived project inputs."""
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3

import numpy as np
from osgeo import gdal, ogr, osr

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
DB = ROOT / "database/pinggu_medical_access.gpkg"
ogr.UseExceptions()
gdal.UseExceptions()
if DB.exists():
    raise SystemExit("Database already exists. Move it aside to rebuild.")
sources = {
    "b": "pinggu-audit/pinggu_b_delivery_v0.gpkg",
    "access": "pinggu-coverage-audit/accessibility_grid_v0_20261119_152921.gpkg",
    "snap": "pinggu-accessibility-audit/accessibility_v0_20261119_152113_977136.gpkg",
    "town": "pinggu-towns/pinggu_town_coverage_provisional.gpkg",
}
objects = {key: ogr.Open(str(WORK / rel)) for key, rel in sources.items()}
db = ogr.GetDriverByName("GPKG").CreateDataSource(str(DB))
layers = [
    ("b", "boundary", "district_boundary", "平谷区裁剪边界"),
    ("b", "towns", "towns_osm_reference", "随原包交付的 OSM 参考乡镇面"),
    ("b", "grid_1km", "grid_1km", "原始 1 km 需求网格"),
    ("b", "facilities", "facilities_all", "清洗后医疗设施"),
    ("b", "facilities_primary", "facilities_primary", "基层设施，保留 in_bnd 字段"),
    ("b", "roads", "roads_osm", "OSM 裁剪和拓扑分段道路"),
    ("b", "nodes", "road_nodes", "OSM 路网拓扑节点"),
    ("snap", "accessibility_v0", "demand_network_points", "1 km 需求点及最短路网距离"),
    ("access", "accessibility_grid_v0", "baseline_grid_access", "基线最短路网距离及分类"),
    ("town", "town_coverage", "town_access", "18 个乡镇人口权重覆盖率"),
]
for group, original, name, note in layers:
    src = objects[group].GetLayerByName(original)
    out = db.CopyLayer(src, name, options=[f"DESCRIPTION={note}"])
    assert out.GetFeatureCount() == src.GetFeatureCount(), name

scenario = json.loads((WORK / "pinggu-planning/scenarios.json").read_text())
status_by_gid = {feature["properties"]["gid"]: feature["properties"]
                 for feature in scenario["cells"]["features"]}
base = db.GetLayerByName("baseline_grid_access")
access = db.CopyLayer(base, "scenario_grid_1km")
access.CreateField(ogr.FieldDefn("stage", ogr.OFTInteger))
access.CreateField(ogr.FieldDefn("map_class", ogr.OFTString))
states = {}
access.StartTransaction()
for row in access:
    gid = row["gid"]
    state = status_by_gid[gid]
    stage = state["s"]
    klass = "baseline_covered" if stage == 0 else (
        "new_coverage" if stage > 0 else "no_model_path" if state["d"] is None else "over_3km"
    )
    states[klass] = states.get(klass, 0) + 1
    row.SetField("stage", stage)
    row.SetField("map_class", klass)
    access.SetFeature(row)
access.CommitTransaction()
assert states == {"baseline_covered":633, "new_coverage":38, "over_3km":328, "no_model_path":40}
access.SetAttributeFilter("map_class='no_model_path'")
assert db.CopyLayer(access, "no_model_path_grid").GetFeatureCount() == 40
access.SetAttributeFilter(None)

srs = base.GetSpatialRef().Clone()
wgs84 = osr.SpatialReference()
wgs84.ImportFromEPSG(4326)
wgs84.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
transform = osr.CoordinateTransformation(wgs84, srs)
sites = db.CreateLayer("candidate_sites", srs=srs, geom_type=ogr.wkbPoint)
for name, field_type in [("stage",ogr.OFTInteger), ("gid",ogr.OFTInteger), ("town",ogr.OFTString),
                         ("new_cells",ogr.OFTInteger), ("new_pop_weight",ogr.OFTReal)]:
    sites.CreateField(ogr.FieldDefn(name,field_type))
for site in scenario["sites"]:
    row = ogr.Feature(sites.GetLayerDefn())
    for key, value in {"stage":site["stage"], "gid":site["gid"],"town":site["town"],
                       "new_cells":site["n"],"new_pop_weight":site["pop"]}.items():
        row.SetField(key,value)
    x,y,_ = transform.TransformPoint(*site["coordinates"])
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint_2D(x,y)
    row.SetGeometry(point)
    sites.CreateFeature(row)
assert sites.GetFeatureCount() == 3
src = out = base = access = sites = row = db = None

# Retain original GeoTIFFs and expose identical lossless KDE tiles inside the GeoPackage.
for phase in ("before","after"):
    raw = DB.parent / f"pinggu_gap_kde_{phase}.tif"
    copy = gdal.Translate(str(DB), str(raw), format="GPKG",
                         creationOptions=["APPEND_SUBDATASET=YES", f"RASTER_TABLE=kde_{phase}",
                                          "TILE_FORMAT=TIFF", "PRECISION=0", "GRID_CELL_ENCODING=grid-value-is-center"])
    copy = None
    dataset = gdal.Open(f"GPKG:{DB}:kde_{phase}")
    original = gdal.Open(str(raw))
    np.testing.assert_array_equal(dataset.ReadAsArray(), original.ReadAsArray())
    dataset = original = None

stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%fZ")
catalogue = ROOT / "sources/source_catalog.csv"
with sqlite3.connect(DB) as con:
    con.execute("CREATE INDEX idx_baseline_gid ON baseline_grid_access(gid)")
    con.execute("CREATE UNIQUE INDEX idx_scenario_gid ON scenario_grid_1km(gid)")
    con.execute("""CREATE TABLE source_catalog (
        id INTEGER PRIMARY KEY, source_key TEXT UNIQUE, name TEXT, use_in_project TEXT,
        vintage TEXT, status TEXT, archive_path TEXT, reference TEXT, notes TEXT
    )""")
    with catalogue.open(encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            con.execute("INSERT INTO source_catalog VALUES (NULL,?,?,?,?,?,?,?,?)",
                        tuple(row[k] for k in ("key","name","use","vintage","status","path","reference","notes")))
    con.execute("""CREATE TABLE scenario_summary (
        stage INTEGER PRIMARY KEY, covered_cells INTEGER, covered_weight REAL,
        coverage_pct REAL, remaining_cells INTEGER, remaining_weight REAL)""")
    for row in scenario["rollout"]:
        weight = row["population"]
        con.execute("INSERT INTO scenario_summary VALUES (?,?,?,?,?,?)",
                    (row["stage"],row["n"],weight,100*weight/scenario["total"],
                     len(status_by_gid)-row["n"],scenario["total"]-weight))
    con.execute("""CREATE TABLE method_parameters (
        id INTEGER PRIMARY KEY, key TEXT UNIQUE, value TEXT, unit TEXT, meaning TEXT)""")
    con.executemany("INSERT INTO method_parameters VALUES (NULL,?,?,?,?)", [
        ("threshold","3000","m","最短路网距离阈值"),
        ("grid","1000","m","人口需求网格"),
        ("calibrated_weight","457000","人口权重","平谷区统一统计分母"),
        ("isolated_grids","40","格","模型中无到现有基层设施路径"),
        ("kde_sigma","1500","m","高斯核标准差"),
        ("kde_pixel","100","m","制图像元"),
        ("town_allocation","intersection_area","","交叠面积分摊，余量保留在原 CSV"),
    ])
    for table, description in (("source_catalog","数据来源及归档状态"),
                               ("scenario_summary","0–3 点的累计覆盖及剩余规模"),
                               ("method_parameters","统计和制图参数")):
        con.execute("""INSERT INTO gpkg_contents
            (table_name,data_type,identifier,description,last_change,srs_id)
            VALUES (?,'attributes',?,?,?,NULL)""",(table,table,description,stamp))
    assert con.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    print(con.execute("SELECT data_type,count(*) FROM gpkg_contents GROUP BY data_type").fetchall())
    print(con.execute("SELECT stage, covered_cells, round(coverage_pct,2) FROM scenario_summary").fetchall())
