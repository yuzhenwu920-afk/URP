import json
from math import ceil, floor, fsum, pi
from pathlib import Path

from matplotlib import font_manager, pyplot as plt
import os
from matplotlib.collections import LineCollection
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyBboxPatch, Rectangle
import numpy as np
from osgeo import gdal, ogr, osr

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
OUT = ROOT / "rebuilt_hotspots"
OUT.mkdir(exist_ok=True)
PIXEL = 100
SIGMA = 1500
INK, MUTED, PAPER = "#162b38", "#435966", "#f8f7f3"
TEAL, AMBER, WINE = "#176f6b", "#d8784d", "#602343"
NODATA = -9999
gdal.UseExceptions()

scenario = json.loads((WORK / "pinggu-planning/scenarios.json").read_text())
by_gid = {row["properties"]["gid"]: row["properties"] for row in scenario["cells"]["features"]}
delivery = ogr.Open(str(WORK / "pinggu-audit/pinggu_b_delivery_v0.gpkg"))
grid = delivery.GetLayerByName("grid_1km")
boundary = delivery.GetLayerByName("boundary")
roads = delivery.GetLayerByName("roads")
town_source = ogr.Open(str(WORK / "pinggu-towns/pinggu_town_coverage_provisional.gpkg"))
towns = town_source.GetLayerByName("town_coverage")
srs = grid.GetSpatialRef().Clone()
assert srs.GetAuthorityCode(None) == "32650" and towns.GetSpatialRef().IsSame(srs)
ll = osr.SpatialReference()
ll.ImportFromEPSG(4326)
ll.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
transform = osr.CoordinateTransformation(ll, srs)

xmin, xmax, ymin, ymax = boundary.GetExtent()
xmin, ymin = (floor(v / PIXEL) * PIXEL for v in (xmin, ymin))
xmax, ymax = (ceil(v / PIXEL) * PIXEL for v in (xmax, ymax))
xs = np.arange(xmin + PIXEL / 2, xmax, PIXEL)
ys = np.arange(ymax - PIXEL / 2, ymin, -PIXEL)
shape = (len(ys), len(xs))
geotransform = (xmin, PIXEL, 0, ymax, 0, -PIXEL)
bounds = (xmin, xmax, ymin, ymax)
raster = gdal.GetDriverByName("MEM").Create("", len(xs), len(ys), 1, gdal.GDT_Byte)
raster.SetGeoTransform(geotransform)
raster.SetProjection(srs.ExportToWkt())
gdal.RasterizeLayer(raster, [1], boundary, burn_values=[1])
mask = raster.ReadAsArray().astype(bool)

before, after = np.zeros(shape), np.zeros(shape)
before_values, after_values, isolated = [], [], []
for row in grid:
    state = by_gid[row["gid"]]
    if state["s"] == 0:
        continue
    center = row.GetGeometryRef().PointOnSurface()
    x, y = center.GetX(), center.GetY()
    weight = float(row["pop_cal"])
    before_values.append(weight)
    if state["s"] == -1:
        after_values.append(weight)
    if state["d"] is None:
        isolated.append((x, y))
    # Exact isotropic Gaussian at the raster cell centers, truncated at 4 sigma.
    i = np.flatnonzero(np.abs(ys - y) <= 4 * SIGMA)
    j = np.flatnonzero(np.abs(xs - x) <= 4 * SIGMA)
    dist2 = (ys[i, None] - y) ** 2 + (xs[None, j] - x) ** 2
    density = weight * 1e6 / (2 * pi * SIGMA ** 2) * np.exp(-dist2 / (2 * SIGMA ** 2))
    density[dist2 > (4 * SIGMA) ** 2] = 0
    before[np.ix_(i, j)] += density
    if state["s"] == -1:
        after[np.ix_(i, j)] += density

assert len(before_values) == 406 and len(after_values) == 368 and len(isolated) == 40
assert np.all(before >= after - 1e-10)
assert round(fsum(before_values) - fsum(after_values)) == 8903


def save_raster(name, data, description):
    path = OUT / name
    tif = gdal.GetDriverByName("GTiff").Create(
        str(path), len(xs), len(ys), 1, gdal.GDT_Float32, options=["COMPRESS=DEFLATE", "PREDICTOR=3"]
    )
    tif.SetGeoTransform(geotransform)
    tif.SetProjection(srs.ExportToWkt())
    tif.SetMetadata({"MODEL": "population_weighted_gaussian", "SIGMA_M": str(SIGMA),
                     "INPUT_GRID_M": "1000", "PIXEL_M": str(PIXEL),
                     "POINT_REPRESENTATION": "point on surface", "MASK": "Pinggu district"})
    band = tif.GetRasterBand(1)
    band.SetNoDataValue(NODATA)
    band.SetDescription(description)
    band.SetUnitType("population weight per square kilometre")
    band.WriteArray(np.where(mask, data, NODATA).astype("float32"))
    tif.FlushCache()
    band = tif = None
    check = gdal.Open(str(path))
    valid = check.ReadAsArray()
    assert check.GetRasterBand(1).GetNoDataValue() == NODATA
    assert np.array_equal(valid != NODATA, mask)
    assert np.allclose(valid[mask], data[mask], atol=0.0001)


save_raster("pinggu_gap_kde_before.tif", before, "Baseline unmet population weight density")
save_raster("pinggu_gap_kde_after.tif", after, "Residual unmet population weight density after three sites")


def lines(geom):
    if geom.GetGeometryName() in {"LINESTRING", "LINEARRING"}:
        return [np.asarray(geom.GetPoints())[:, :2]]
    return [line for i in range(geom.GetGeometryCount()) for line in lines(geom.GetGeometryRef(i))]


town_vectors = []
town_shapes = []
for feature in towns:
    geom = feature.GetGeometryRef()
    town_vectors.extend(lines(geom))
    town_shapes.append((feature["name"], geom.Clone()))
district = [line for feature in boundary for line in lines(feature.GetGeometryRef())]
major_roads = []
for row in roads:
    if row["highway"] in {"motorway", "trunk", "primary", "secondary"}:
        major_roads.extend(lines(row.GetGeometryRef()))

peak = np.unravel_index(np.argmax(np.where(mask, after, -1)), after.shape)
peak_xy = (xs[peak[1]], ys[peak[0]])
peak_point = ogr.Geometry(ogr.wkbPoint)
peak_point.AddPoint_2D(*peak_xy)
peak_town, peak_shape = min(town_shapes, key=lambda pair: pair[1].Distance(peak_point))
assert peak_shape.Distance(peak_point) == 0
peak_town = peak_town.replace("地区办事处", "地区").replace("街道办事处", "街道")

for file in os.environ.get("PINGGU_CJK_FONTS", "").split(os.pathsep):
    if file:
        font_manager.fontManager.addfont(file)
plt.rcParams.update({
    "font.family": "Noto Sans CJK SC", "font.size": 13,
    "axes.unicode_minus": False, "pdf.fonttype": 42,
})
ramp = LinearSegmentedColormap.from_list("gap", [
    (0, "#f1eeec"), (.18, "#f4d1a4"), (.38, "#ef9460"),
    (.60, "#d55b55"), (.80, "#9d3850"), (1, "#4b2145"),
])
fig = plt.figure(figsize=(15.4, 10), facecolor=PAPER)
header = fig.add_axes([0, .845, 1, .155])
header.set_facecolor(INK)
header.set_xticks([])
header.set_yticks([])
for spine in header.spines.values():
    spine.set_visible(False)
header.add_patch(Rectangle((.036, .25), .004, .52, color="#83C4AC", transform=header.transAxes))
header.text(.052, .67, "平谷区基层医疗服务缺口热点", color="#ffffff", fontsize=34,
            weight="bold", va="center")
header.text(.053, .28, "三处补点后的未覆盖人口权重核密度", color="#dbe9e7", fontsize=17, va="center")
header.text(.954, .32, "北京市平谷区", color="#dbe9e7", fontsize=15, ha="right")

ax = fig.add_axes([.050, .184, .576, .636])
limit = ceil(np.max(after[mask]) / 30) * 30
data = np.ma.masked_where(~mask, after)
heat = ax.imshow(data, extent=bounds, origin="upper", cmap=ramp, vmin=0, vmax=limit,
                 interpolation="antialiased", zorder=1)
ax.add_collection(LineCollection(major_roads, colors="#3a5967", linewidths=.45, alpha=.40, zorder=2))
ax.add_collection(LineCollection(town_vectors, colors="#304850", linewidths=.58, alpha=.55, zorder=3))
levels = [v for v in np.linspace(0, limit, 6)[1:-1] if v < data.max()]
if levels:
    ax.contour(xs, ys, data, levels=levels, colors="#fff8ed", linewidths=.68, alpha=.7, zorder=4)
ax.add_collection(LineCollection(district, colors=INK, linewidths=1.25, alpha=.9, zorder=5))
sites = [site for site in scenario["sites"]]
for site in sites:
    x, y, _ = transform.TransformPoint(*site["coordinates"])
    ax.scatter(x, y, s=345, c=TEAL, linewidths=2.1, edgecolors="#ffffff", zorder=6)
    ax.text(x, y, str(site["stage"]), color="white", weight="bold", fontsize=13,
            ha="center", va="center", zorder=7)
ax.scatter(*peak_xy, s=175, marker="D", color=WINE, linewidths=1.8, edgecolor="white", zorder=7)
ax.set(aspect="equal", xlim=(xmin-1200, xmax+1200), ylim=(ymin-1100, ymax+1000))
ax.axis("off")
arrow = dict(arrowstyle="-|>", color=INK, linewidth=1.5, mutation_scale=17)
ax.annotate("", xy=(.953,.974), xytext=(.953,.925), xycoords="axes fraction", arrowprops=arrow)
ax.text(.953, .979, "N", transform=ax.transAxes, ha="center", va="bottom",
        fontsize=13, color=INK, weight="bold")
x0, y0 = xmin + 350, ymin - 350
ax.plot([x0, x0 + 5000], [y0, y0], color=INK, linewidth=3, zorder=8)
ax.text(x0 + 2500, y0 + 260, "5 km", color=INK, ha="center", fontsize=12)

caption = fig.text
caption(.069, .154, "未覆盖人口权重密度", weight="bold", fontsize=15, color=INK)
caption(.625, .154, "人口权重／km²", fontsize=12, color=MUTED, ha="right")
cax = fig.add_axes([.069, .116, .556, .025])
colorbar = fig.colorbar(heat, cax=cax, orientation="horizontal",
                         ticks=np.linspace(0, limit, 6))
colorbar.outline.set_visible(False)
colorbar.ax.tick_params(labelsize=11, colors=MUTED, length=3)
caption(.069, .062, "●", color=TEAL, fontsize=15)
caption(.087, .063, "模拟候选点", color=MUTED, fontsize=12)
caption(.183, .062, "◆", color=WINE, fontsize=13)
caption(.201, .063, "剩余密度峰值", color=MUTED, fontsize=12)
caption(.320, .063, "细线为乡镇界和主要道路", color=MUTED, fontsize=12)
caption(.069, .028, "输入为 1 km 人口网格 · 高斯核 σ = 1.5 km · 制图像元 100 m · 乡镇边界约 2020 年",
        fontsize=10.5, color=MUTED)

panel = fig.add_axes([.665, .079, .294, .723])
panel.set_xticks([])
panel.set_yticks([])
panel.set_facecolor("#ffffff")
for spine in panel.spines.values():
    spine.set_visible(False)


def panel_text(y, text, size=14, color=INK, weight="normal", x=.075):
    return panel.text(x, y, text, transform=panel.transAxes, va="center",
                      fontsize=size, color=color, weight=weight)


start, end = fsum(before_values), fsum(after_values)
reduction = 100 * (start - end) / start
panel_text(.926, "补点后仍未覆盖", 17, weight="bold")
panel_text(.837, f"{end:,.0f}", 41, WINE, "bold")
panel_text(.766, f"人口权重 · {len(after_values)} 个网格", 15, MUTED)
panel_text(.694, "与现状相比", 15, weight="bold")
for y, value, label, color in [(.636, start, "现状", "#aabfc5"), (.570, end, "补点后", TEAL)]:
    panel.add_patch(Rectangle((.26,y-.014), .45 * value/start, .025, color=color,
                               transform=panel.transAxes))
    panel_text(y, label, 12)
    panel_text(y, f"{value:,.0f}", 13, x=.75)
panel_text(.506, f"未覆盖人口权重减少 {reduction:.1f}%", 14, TEAL, "bold")
panel.plot([.075,.925],[.451,.451],color="#dce4e4",lw=1,transform=panel.transAxes)
panel_text(.397, "下一步去哪里核查", 17, weight="bold")
panel_text(.335, f"热点峰值位于{peak_town}附近", 15, WINE, "bold")
panel_text(.278, "核对高值网格对应的居民点、", 13, MUTED)
panel_text(.238, "现有医疗点与实际进村路线。", 13, MUTED)
panel.add_patch(FancyBboxPatch((.074,.063), .85,.115, boxstyle="round,pad=.012,rounding_size=.01",
                               linewidth=0, facecolor="#f4edf0", transform=panel.transAxes))
panel_text(.137, "40 个网格在模型中无路径", 14, WINE, "bold", x=.105)
panel_text(.093, "按路网连通问题单独核查。", 12.5, MUTED, x=.105)

fig.savefig(OUT / "pinggu_gap_hotspots.png", dpi=300, facecolor=PAPER)
fig.savefig(OUT / "pinggu_gap_hotspots.pdf", facecolor=PAPER)
plt.close(fig)
print(f"Baseline {start:.3f}; residual {end:.3f}; peak {peak_town} {after[peak]:.2f}; scale 0–{limit}")
