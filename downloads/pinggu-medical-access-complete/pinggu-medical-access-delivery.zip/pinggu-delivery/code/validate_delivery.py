"""Check results, deliverable counts, independent raster copies, and archive paths."""
import csv
from pathlib import Path
import sqlite3
from zipfile import ZipFile

from PIL import Image

root = Path(__file__).resolve().parents[1]
db = root / 'database/pinggu_medical_access.gpkg'
with sqlite3.connect(db) as con:
    assert con.execute('PRAGMA integrity_check').fetchone() == ('ok',)
    assert dict(con.execute('SELECT data_type,count(*) FROM gpkg_contents GROUP BY data_type')) == {
        '2d-gridded-coverage':2, 'attributes':3, 'features':13
    }
    assert con.execute('SELECT count(*) FROM town_access').fetchone()[0] == 18
    assert dict(con.execute('SELECT map_class,count(*) FROM scenario_grid_1km GROUP BY map_class')) == {
        'baseline_covered':633, 'new_coverage':38, 'no_model_path':40, 'over_3km':328
    }
    assert con.execute('SELECT stage,new_cells FROM candidate_sites ORDER BY stage').fetchall() == [(1,12),(2,10),(3,16)]
    assert con.execute('SELECT round(coverage_pct,2) FROM scenario_summary ORDER BY stage').fetchall() == [(92.17,),(92.91,),(93.53,),(94.12,)]
with (root/'sources/source_catalog.csv').open(encoding='utf-8-sig') as f:
    assert all((root/item['path']).is_file() for item in csv.DictReader(f) if item['path'])
for folder, pattern, count in [('maps','*.png',7),('maps','*.pdf',7),('maps/frames','*.png',4)]:
    files = list((root/folder).glob(pattern))
    assert len(files) == count
    if pattern == '*.png':
        for path in files:
            with Image.open(path) as image:
                assert image.width >= 3000
                image.verify()
ppt = root/'presentation/pinggu_medical_access_report.pptx'
with ZipFile(ppt) as z:
    assert z.testzip() is None
    assert len([n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]) == 10
print('Validated 7 map pairs, 4 frames, 10 slides, source files and GeoPackage layer counts.')
