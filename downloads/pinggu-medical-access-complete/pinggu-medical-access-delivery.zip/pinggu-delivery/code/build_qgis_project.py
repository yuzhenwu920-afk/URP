"""Build a portable QGIS project that reads the packaged database and rasters."""
from pathlib import Path

from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    Qgis, QgsApplication, QgsCategorizedSymbolRenderer, QgsColorRampShader,
    QgsCoordinateReferenceSystem, QgsFillSymbol, QgsGraduatedSymbolRenderer,
    QgsLineSymbol, QgsMarkerSymbol, QgsPalLayerSettings, QgsProject, QgsRasterLayer,
    QgsRasterShader, QgsRectangle, QgsRendererCategory, QgsRendererRange,
    QgsSingleBandPseudoColorRenderer, QgsSingleSymbolRenderer, QgsTextBufferSettings,
    QgsTextFormat, QgsVectorLayer, QgsVectorLayerSimpleLabeling,
)

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "database"
PKG = DATA / "pinggu_medical_access.gpkg"

def build():
    project = QgsProject.instance()
    project.clear()
    project.setFileName(str(DATA / "pinggu_medical_access.qgz"))
    project.setFilePathStorage(Qgis.FilePathType.Relative)
    project.setCrs(QgsCoordinateReferenceSystem("EPSG:32650"))
    root = project.layerTreeRoot()

    def vector(name, title):
        layer = QgsVectorLayer(f"{PKG}|layername={name}", title, "ogr")
        if not layer.isValid():
            raise RuntimeError(f"无法打开数据库图层 {name}")
        return layer

    def fill(color, outline="none", style="solid"):
        params = {"color":color, "style":style}
        if outline == "none":
            params["outline_style"] = "no"
        else:
            params.update({"outline_color":outline,"outline_width":"0.20"})
        return QgsFillSymbol.createSimple(params)

    def labels(layer, field, size, color, buffered=False):
        pal = QgsPalLayerSettings()
        pal.fieldName = field
        format = QgsTextFormat()
        format.setFont(QFont("Microsoft YaHei"))
        format.setSize(size)
        format.setColor(QColor(color))
        if buffered:
            buffer = QgsTextBufferSettings()
            buffer.setEnabled(True)
            buffer.setSize(.8)
            buffer.setColor(QColor("#ffffff"))
            format.setBuffer(buffer)
        else:
            pal.placement = Qgis.LabelPlacement.OverPoint
        pal.setFormat(format)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        layer.setLabelsEnabled(True)

    def add(group, layer, active=False):
        project.addMapLayer(layer, False)
        node = group.addLayer(layer)
        node.setItemVisibilityChecked(active)
        return node

    g = root.addGroup("补点结果 · 1 km 网格")
    sites = vector("candidate_sites","三个模拟候选点")
    sites.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
        "color":"#15395a", "outline_color":"#ffffff", "outline_width":"0.45", "size":"7.2"
    })))
    labels(sites,"stage",11,"#ffffff")
    add(g,sites,True)
    district = vector("district_boundary","平谷区界 · OSM")
    district.setRenderer(QgsSingleSymbolRenderer(fill("#15395a","#15395a","no")))
    add(g,district,True)
    scenario = vector("scenario_grid_1km","1 km 网格 · 三处补点后")
    classes=[
        ("baseline_covered","#e7edf2","现状覆盖","solid"),
        ("new_coverage","#216eab","模拟新增","solid"),
        ("over_3km","#a9c9df","仍超 3 km","solid"),
        ("no_model_path","#527399","模型无路径","b_diagonal"),
    ]
    scenario.setRenderer(QgsCategorizedSymbolRenderer("map_class",[
        QgsRendererCategory(key,fill(color,style=style),label) for key,color,label,style in classes
    ]))
    add(g,scenario,True)
    add(g,vector("no_model_path_grid","40 个模型无路径网格"))
    add(g,vector("baseline_grid_access","现状 1 / 3 / 5 km 路网距离"))

    g = root.addGroup("乡镇覆盖率")
    for scenario_name,field,thresholds,colors in [
        ("乡镇 · 3 km 覆盖率","pct_3km",(60,70,80,90,100),("#dcebf6","#a2cade","#458fb8","#145695")),
        ("乡镇 · 1 km 覆盖率","pct_1km",(0,20,40,60,80,100),("#eef5fa","#dcebf6","#a2cade","#458fb8","#145695")),
    ]:
        town = vector("town_access",scenario_name)
        town.setRenderer(QgsGraduatedSymbolRenderer(field,[
            QgsRendererRange(lo,hi,fill(color,"#ffffff"),f"{lo}–{hi}%")
            for lo,hi,color in zip(thresholds,thresholds[1:],colors)
        ]))
        labels(town,"name",10,"#15395a",True)
        add(g,town)

    g = root.addGroup("服务缺口核密度")
    for phase, title in [("after","补点后未覆盖人口权重核密度"),("before","现状未覆盖人口权重核密度")]:
        path = DATA / f"pinggu_gap_kde_{phase}.tif"
        raster = QgsRasterLayer(str(path),title)
        if not raster.isValid():
            raise RuntimeError(f"无法打开 {path}")
        crs = QgsColorRampShader()
        crs.setColorRampType(QgsColorRampShader.Interpolated)
        crs.setMinimumValue(0)
        crs.setMaximumValue(250)
        palette=[(0,"#f1f5fa"),(30,"#c7deed"),(60,"#7ab1ce"),(90,"#367cae"),
                 (120,"#235685"),(150,"#292d59"),(250,"#121a37")]
        crs.setColorRampItemList([QgsColorRampShader.ColorRampItem(v,QColor(c),str(v)) for v,c in palette])
        shader = QgsRasterShader(0,250)
        shader.setRasterShaderFunction(crs)
        renderer = QgsSingleBandPseudoColorRenderer(raster.dataProvider(),1,shader)
        renderer.setClassificationMin(0)
        renderer.setClassificationMax(250)
        raster.setRenderer(renderer)
        message, ok = raster.saveNamedStyle(str(path.with_suffix(".qml")))
        if not ok:
            raise RuntimeError(message)
        add(g,raster)

    g = root.addGroup("参考数据")
    fac = vector("facilities_primary","基层医疗点")
    fac.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
        "color":"#15395a","outline_color":"#ffffff","size":"2.4"
    })))
    add(g,fac)
    roads = vector("roads_osm","OSM 路网")
    roads.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple({
        "line_color":"#58768f","line_width":".16"
    })))
    add(g,roads)
    for name,title in [("facilities_all","全部医疗设施"),("road_nodes","路网节点"),
                        ("grid_1km","原始 1 km 人口网格"),("towns_osm_reference","交付包 OSM 乡镇面"),
                        ("demand_network_points","需求点与路网距离"),
                        ("scenario_summary","补点阶段汇总"),("source_catalog","数据来源"),
                        ("method_parameters","方法参数")]:
        add(g,vector(name,title))
    add(g,QgsRasterLayer(str(DATA/"pinggu_tcc10_2024_raw_10m.tif"),"TCC10 原值参考裁剪"))

    extent = QgsRectangle(district.extent())
    extent.scale(1.10)
    from qgis.core import QgsReferencedRectangle
    project.viewSettings().setDefaultViewExtent(QgsReferencedRectangle(extent,project.crs()))
    for group in root.children():
        group.setExpanded(group.name().startswith("补点结果"))
    if not project.write():
        raise RuntimeError("QGIS 工程保存失败。")
    return len(project.mapLayers())


if __name__ == "__main__":
    app = QgsApplication([],False)
    app.initQgis()
    count = build()
    check = QgsProject()
    assert check.read(str(DATA / "pinggu_medical_access.qgz"))
    assert len(check.mapLayers()) == count and all(l.isValid() for l in check.mapLayers().values())
    print(f"QGIS reopened {count} valid layers.", flush=True)
