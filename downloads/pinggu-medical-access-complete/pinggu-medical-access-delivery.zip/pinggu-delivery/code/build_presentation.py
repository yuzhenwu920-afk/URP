"""Create the editable presentation from the coordinated atlas figures."""
from io import BytesIO
from pathlib import Path

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "presentation"
MAPS = ROOT / "maps"
INK, MID, BLUE = "#15395a", "#46637c", "#216eab"
RULE, LIGHT, WHITE = "#c5d4df", "#edf4f9", "#ffffff"
FONT = "Microsoft YaHei"

prs=Presentation()
prs.slide_width=Inches(13.333)
prs.slide_height=Inches(7.5)


def rgb(code):
    return RGBColor.from_string(code.removeprefix("#").upper())


def rect(s,x,y,w,h,fill,line=None):
    box=s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    box.fill.solid()
    box.fill.fore_color.rgb=rgb(fill)
    if line:
        box.line.color.rgb=rgb(line)
        box.line.width=Pt(.8)
    else:
        box.line.fill.background()
    return box


def text(s,value,x,y,w,h,size=22,bold=False,color=INK,align=None):
    shape=s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame=shape.text_frame
    frame.clear()
    frame.word_wrap=True
    frame.margin_left=frame.margin_right=frame.margin_top=frame.margin_bottom=0
    frame.vertical_anchor=MSO_ANCHOR.TOP
    for index,line in enumerate(value.split("\n")):
        p=frame.paragraphs[0] if index==0 else frame.add_paragraph()
        if align is not None:
            p.alignment=align
        p.space_after=Pt(4)
        p.line_spacing=1.12
        run=p.add_run()
        run.text=line
        run.font.name=FONT
        run.font.size=Pt(size)
        run.font.bold=bold
        run.font.color.rgb=rgb(color)
    return shape


def picture(s,stem,box,crop=(0,0,1,1)):
    image=Image.open(MAPS/f"{stem}.png").convert("RGB")
    im=image.crop(tuple(round(v*n) for v,n in zip(crop,(*image.size,*image.size))))
    stream=BytesIO()
    im.save(stream,format="PNG",optimize=True)
    stream.seek(0)
    x,y,w,h=box
    scale=min(w/im.width,h/im.height)
    ww,hh=im.width*scale,im.height*scale
    s.shapes.add_picture(stream, Inches(x+(w-ww)/2), Inches(y+(h-hh)/2),
                         width=Inches(ww),height=Inches(hh))


def page(title, subtitle):
    s=prs.slides.add_slide(prs.slide_layouts[6])
    s.background.fill.solid()
    s.background.fill.fore_color.rgb=rgb(WHITE)
    rect(s,.55,.53,.07,.73,BLUE)
    text(s,title,.76,.43,11.98,.61,30,True)
    text(s,subtitle,.78,1.12,11.85,.32,15,color=MID)
    rect(s,.60,1.59,12.13,.014,RULE)
    rect(s,.60,7.03,12.13,.014,RULE)
    text(s,"平谷基层医疗服务可达性 · v0 试算",.63,7.12,7,.25,10,color=MID)
    text(s,f"{len(prs.slides):02}",12.2,7.1,.5,.28,11,True,color=MID,align=PP_ALIGN.RIGHT)
    return s


def panel(s,x,y,w,h):
    rect(s,x,y,w,h,LIGHT)
    rect(s,x,y,.045,h,BLUE)


def chips(s, labels, y=6.53):
    positions=[.87,2.78,4.67,6.57]
    for (label,color),x in zip(labels,positions):
        rect(s,x,y+.03,.16,.16,color)
        text(s,label,x+.23,y,1.66,.3,12,color=MID)


def side(s,number,label,body1,body2,foot=None):
    panel(s,8.97,1.91,3.64,4.76)
    text(s,number,9.21,2.16,3.2,.87,44,True,color=BLUE)
    text(s,label,9.24,3.02,3.08,.61,18,True)
    rect(s,9.24,3.70,3.08,.013,RULE)
    text(s,body1,9.24,3.90,3.06,.85,19,color=INK)
    text(s,body2,9.24,4.88,3.06,.93,19,color=INK)
    if foot:
        text(s,foot,9.24,6.01,3.02,.49,13,color=MID)


s=prs.slides.add_slide(prs.slide_layouts[6])
s.background.fill.solid()
s.background.fill.fore_color.rgb=rgb(WHITE)
rect(s,.67,.88,.08,2.55,BLUE)
text(s,"平谷区基层医疗\n可达性与补点规划",.92,.87,7.5,2.28,42,True)
text(s,"1 km 人口网格 × 3 km 路网距离",.95,3.26,7.0,.47,21,color=MID)
picture(s,"02_grid_1km",(7.09,.77,5.66,4.75),(.14,.18,.70,.855))
rect(s,.94,5.42,11.44,.014,RULE)
for x,number,label in [(1.0,"92.17%","现状覆盖率"),(4.78,"94.12%","三处补点后"),(8.53,"8,903","模拟新增覆盖权重")]:
    text(s,number,x,5.73,3.36,.62,35,True,color=BLUE)
    text(s,label,x,6.47,3.3,.34,15,color=MID)

s=page("研究口径和计算流程","覆盖率按人口权重计算，以到最近基层医疗点的最短路网距离分级。")
for i,(title,body,x) in enumerate([
    ("需求","1,039 个需求网格\n人口权重校准至 45.7 万",.74),
    ("供给","161 个区内基层医疗点\n设施位置来自清洗后 POI",4.81),
    ("路网","OSM 道路拓扑\n计算 1 / 3 / 5 km 累计覆盖",8.87),
],1):
    panel(s,x,2.18,3.73,2.54)
    text(s,f"0{i}",x+.19,2.39,.68,.41,21,True,color=BLUE)
    text(s,title,x+.19,2.91,3.05,.4,24,True)
    text(s,body,x+.19,3.52,3.25,.94,17,color=MID)
text(s,"候选点按每一步新增覆盖人口权重排序。",.91,5.24,11.6,.55,23,True)
text(s,"道路方向、等待时间、机构容量和现场可用性仍需进一步核查。",.94,6.06,11.7,.46,18,color=MID)

s=page("乡镇 3 km 覆盖有明显差异","乡镇覆盖率由网格人口权重按交叠面积分摊得到。")
picture(s,"01_town_3km",(.66,1.69,8.0,4.98),(.19,.164,.761,.865))
chips(s,[("60%–<70%","#dcebf6"),("70%–<80%","#a2cade"),("80%–<90%","#458fb8"),("90%–100%","#145695")])
side(s,"92.17%","全区人口权重覆盖率","熊儿寨乡 60.8%\n黄松峪乡 67.4%","部分城区乡镇和街道接近或达到 100%。","乡镇边界约 2020 年。")

s=page("1 km 网格显示覆盖缺口在哪里","按候选点顺序逐步增加服务点，青蓝色显示模拟新增覆盖。")
picture(s,"02_grid_1km",(.67,1.74,7.97,4.83),(.135,.16,.70,.858))
chips(s,[("现状覆盖","#e7edf2"),("模拟新增","#216eab"),("仍超 3 km","#a9c9df"),("模型无路径","#527399")])
side(s,"+38 格","三处补点的累计新增覆盖","92.17% → 94.12%","仍有 328 格超 3 km，另有 40 格模型无路径。","网格大小 1 km，覆盖阈值 3 km。")

site_rows=[
    (1,"峪口镇","03_candidate_1","12 格","3,411","3.90 km","优先核实现有卫生室和可利用用房。","比较定点服务与定期巡诊。"),
    (2,"镇罗营镇","04_candidate_2","10 格","2,838","5.17 km","核实进村道路和季节性通行。","确认巡诊车辆能到达的服务点。"),
    (3,"金海湖镇","05_candidate_3","16 格","2,654","5.94 km","复核边缘居民点的实际就医路线。","核实现有医疗点的服务能力。"),
]
for stage,town,stem,count,weight,distance,first,second in site_rows:
    s=page(f"补点 {stage} · {town}","局部图保留道路和现有基层医疗点，展示这一阶段新增覆盖的网格。")
    picture(s,stem,(.65,1.74,8.0,4.83),(.073,.176,.665,.861))
    chips(s,[("本阶段前已覆盖","#e7edf2"),("本次模拟新增","#216eab"),("本阶段未覆盖","#a9c9df"),("候选点与医疗点","#15395a")])
    side(s,count,f"新增人口权重约 {weight}",first,second,f"候选格现状路网距离约 {distance}。")

s=page("补点后仍需关注王辛庄镇附近","核密度图显示未覆盖人口权重在空间上的集中程度。")
picture(s,"06_gap_hotspots",(.62,1.73,8.1,4.96),(.118,.163,.691,.879))
side(s,"26,893","补点后未覆盖人口权重","较现状减少 24.9%。","峰值附近先核对居民点、现有医疗点和进村路线。","1.5 km 高斯核，100 m 制图像元。")

s=page("从地图转到现场核查","先验证数据与实际通行，再决定服务方式。")
for i,(heading,detail) in enumerate([
    ("核实候选点能否落地","确认场地、卫生室、道路和开放条件，比较固定服务点与定期巡诊。"),
    ("复核剩余人口热点","核对高值网格里的实际居民点，验证模型中的到医路线。"),
    ("单独排查 40 个无路径网格","区别路网漏线、节点接入误差与真实通行障碍，再决定补线或服务方式。"),
],1):
    y=2.03+(i-1)*1.48
    rect(s,.90,y,.62,.58,BLUE)
    text(s,str(i),.99,y+.047,.44,.48,22,True,color=WHITE,align=PP_ALIGN.CENTER)
    text(s,heading,1.72,y+.02,10.58,.47,24,True)
    text(s,detail,1.73,y+.61,10.58,.48,18,color=MID)

s=page("数据归档与复核","数据库、地图、源数据说明和生成代码随课题一并交付。")
for i,(heading,detail,x) in enumerate([
    ("核心空间数据","1 km 网格、区界、18 个乡镇\nOSM 路网、设施、候选点和核密度",.77),
    ("可追溯结果","覆盖汇总、数据来源、模型参数\n图件 PNG/PDF 及可编辑汇报 PPT",4.83),
    ("待补原件","原 Windows 工程和裁剪地形栅格\n原始 POI、OSM、WorldPop 文件",8.90),
]):
    panel(s,x,2.2,3.64,2.52)
    text(s,heading,x+.2,2.53,3.24,.45,21,True)
    text(s,detail,x+.2,3.29,3.18,1.05,15,color=MID)
text(s,"打开 pinggu_medical_access.qgz 查看 GIS 图层。",.92,5.52,11.65,.59,22,True)
text(s,"数据口径、版本以及原件是否已收到，详见来源清单。",.95,6.23,11.66,.43,16,color=MID)

path=OUT/"pinggu_medical_access_report.pptx"
prs.save(path)
assert len(Presentation(path).slides)==10
