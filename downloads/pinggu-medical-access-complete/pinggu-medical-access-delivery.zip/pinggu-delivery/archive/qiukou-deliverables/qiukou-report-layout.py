from datetime import datetime
from math import fsum
from pathlib import Path
from tempfile import mkdtemp

from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    QgsFillSymbol, QgsLayoutExporter, QgsLayoutItemLabel, QgsLayoutItemMap,
    QgsLayoutItemMapOverview, QgsLayoutItemScaleBar, QgsLayoutItemShape,
    QgsLayoutPoint, QgsLayoutSize, QgsMapLayerStyle, QgsPrintLayout, QgsProject,
    QgsRectangle, QgsSingleSymbolRenderer, QgsUnitTypes,
)


def make_report():
    project = QgsProject.instance()
    options = sorted(
        (item for item in project.layoutManager().layouts()
         if item.name().startswith("峪口镇候选点1_现场核查图")),
        key=lambda item: item.name(),
    )
    if not options:
        raise RuntimeError("找不到已生成的峪口镇现场核查图布局。")
    maps = [item for item in options[-1].items() if isinstance(item, QgsLayoutItemMap)]
    if len(maps) != 1 or len(maps[0].layers()) != 4:
        raise RuntimeError("原布局应包含一张主图及候选点、医疗点、道路、核验网格四层。")
    old_map = maps[0]
    candidate, facilities, roads, grid = old_map.layers()
    benefit = list(grid.getFeatures('"sim_cand" = 1 AND "cls4" = \'模拟新增覆盖\''))
    target = next((f for f in benefit if int(f["gid"]) == 140), None)
    if len(benefit) != 12 or target is None:
        raise RuntimeError("候选点 1 的 12 个受益网格核对失败。")
    pop = fsum(float(f["pop_cal"]) for f in benefit)
    km = float(target["net_dist_m"]) / 1000

    parent = Path(grid.source().split("|", 1)[0]).parent
    output = Path(mkdtemp(prefix="report_", dir=parent))
    ink, muted, paper = "#172F42", "#4D6470", "#F7F7F3"
    teal, brick, border = "#478F83", "#AE4438", "#D7E0DE"

    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.pageCollection().pages()[0].setPageSize(QgsLayoutSize(320, 204))
    layout.setName("峪口镇候选点1_规划汇报版 " + datetime.now().strftime("%Y%m%d %H%M%S"))

    def place(item, x, y, w, h):
        layout.addLayoutItem(item)
        item.attemptMove(QgsLayoutPoint(x, y))
        item.attemptResize(QgsLayoutSize(w, h))
        return item

    def text(value, x, y, w, h, size=10, color=ink, bold=False):
        item = QgsLayoutItemLabel(layout)
        font = QFont("Microsoft YaHei", size)
        font.setBold(bold)
        item.setFont(font)
        item.setFontColor(QColor(color))
        item.setMargin(0)
        item.setText(value)
        return place(item, x, y, w, h)

    def shape(x, y, w, h, color, style="solid", ellipse=False):
        item = QgsLayoutItemShape(layout)
        item.setShapeType(item.Ellipse if ellipse else item.Rectangle)
        item.setSymbol(QgsFillSymbol.createSimple({
            "color": color, "style": style, "outline_style": "no",
        }))
        return place(item, x, y, w, h)

    shape(0, 0, 320, 204, paper)
    shape(0, 0, 320, 34, ink)
    shape(12, 7, 1.3, 19, "#83C4AC")
    text("峪口镇基层医疗补点方案", 17, 6, 230, 13, 23, "#FFFFFF", True)
    text("候选点 1 · 3 km 路网覆盖试算与现场核查", 17, 22, 230, 6, 10, "#DCE9E8")
    text("北京市平谷区", 268, 14, 43, 8, 12, "#DCE9E8")

    main = place(QgsLayoutItemMap(layout), 12, 42, 188, 133)
    main.setCrs(old_map.crs())
    main.setLayers(old_map.layers())
    main.setKeepLayerSet(True)
    main.zoomToExtent(old_map.extent())
    main.setFrameEnabled(True)
    main.setFrameStrokeColor(QColor(border))

    shape(12, 176, 188, 11, "#FFFFFF")
    items = [
        ("现状覆盖", "#E4E7E9", "solid", 15),
        ("模拟新增", teal, "solid", 46),
        ("仍超 3 km", "#DDB9A6", "solid", 77),
        ("模型无路径", "#8E6453", "b_diagonal", 109),
        ("现有医疗点", "#173651", "solid", 145),
        ("候选点", brick, "solid", 176),
    ]
    for label, color, style, x in items:
        if label == "候选点":
            text("◆", x - 0.2, 178.6, 4, 6, 9, brick)
        else:
            shape(x, 180, 2.8, 2.8, color, style, label == "现有医疗点")
        text(label, x + 4, 178.5, 30, 6, 8)

    scale = QgsLayoutItemScaleBar(layout)
    scale.setStyle("Single Box")
    scale.setLinkedMap(main)
    scale.setUnits(QgsUnitTypes.DistanceMeters)
    scale.setUnitsPerSegment(500)
    scale.setNumberOfSegments(2)
    scale.setNumberOfSegmentsLeft(0)
    scale.setUnitLabel("m")
    place(scale, 12, 188, 35, 9)
    text("1 km 人口网格 · 路网距离 · 村庄居民点待核查", 58, 190, 145, 6, 8, muted)

    shape(207, 42, 101, 145, "#FFFFFF")
    text("模拟新增覆盖", 212, 46, 47, 7, 11, ink, True)
    text(f"{len(benefit)} 格", 212, 55, 47, 15, 27, "#25685D", True)
    text(f"{pop:,.0f}  人口权重", 212, 73, 52, 9, 13, ink, True)
    text(f"{km:.2f} km  候选格现状路网距离", 212, 83, 52, 8, 9, muted)

    text("局部图在平谷区的位置", 265, 46, 42, 6, 8, muted)
    overview_map = place(QgsLayoutItemMap(layout), 263, 53, 41, 39)
    overview_map.setCrs(grid.crs())
    overview_map.setLayers([grid])
    overview_map.setKeepLayerSet(True)
    neutral = grid.clone()
    neutral.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
        "color": "#DDE7E4", "outline_style": "no",
    })))
    style = QgsMapLayerStyle()
    style.readFromLayer(neutral)
    overview_map.setLayerStyleOverrides({grid.id(): style.xmlData()})
    overview_map.setKeepLayerStyles(True)
    full = QgsRectangle(grid.extent())
    full.scale(1.10)
    overview_map.zoomToExtent(full)
    overview = QgsLayoutItemMapOverview("局部主图范围", overview_map)
    overview.setLinkedMap(main)
    overview.setFrameSymbol(QgsFillSymbol.createSimple({
        "style": "no", "outline_color": brick, "outline_width": "0.65",
    }))
    overview_map.overviews().addOverview(overview)

    shape(212, 97, 91, 0.35, border)
    text("现场优先核查", 212, 101, 90, 8, 12, ink, True)
    text("01  核实进村道路", 212, 113, 90, 7, 10, ink, True)
    text("逐段确认通行条件和路网连接，复核受益范围。", 212, 121, 90, 7, 9, muted)
    text("02  核实可用场地", 212, 133, 90, 7, 10, ink, True)
    text("查找现有卫生室或公共服务场地，核实开放条件。", 212, 141, 90, 7, 9, muted)
    shape(212, 155, 91, 25, "#EAF2EE")
    text("规划判断", 216, 158, 83, 6, 10, "#25685D", True)
    text("通路和场地具备后，比较固定服务点与定期巡诊。\n覆盖收益为模拟估算，需以现场核查结果复核。",
         216, 166, 83, 11, 8, ink)
    text("候选网格 gid 140", 207, 190, 101, 6, 8, muted)

    exporter = QgsLayoutExporter(layout)
    image = QgsLayoutExporter.ImageExportSettings()
    image.dpi = 260
    png = output / "qiukou_report.png"
    pdf = output / "qiukou_report.pdf"
    results = (
        (png, exporter.exportToImage(str(png), image)),
        (pdf, exporter.exportToPdf(str(pdf), QgsLayoutExporter.PdfExportSettings())),
    )
    for path, result in results:
        if result != QgsLayoutExporter.Success or not path.is_file() or not path.stat().st_size:
            raise RuntimeError(f"导出失败：{path}，返回码 {result}")
    project.layoutManager().addLayout(layout)
    print(f"汇报版 PNG：{png}\n汇报版 PDF：{pdf}")
    return layout


report = make_report()
if "iface" in globals() and iface is not None:
    iface.openLayoutDesigner(report)
