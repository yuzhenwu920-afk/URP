import json
from pathlib import Path
from osgeo import ogr, osr
from itertools import combinations

ogr.UseExceptions()
base = Path('work/pinggu-towns')
townfile = next((base / 'download' / '乡镇').glob('*.geojson'))
towns_json = json.loads(townfile.read_text())
source = ogr.Open('work/pinggu-audit/pinggu_b_delivery_v0.gpkg')
bd_layer = source.GetLayerByName('boundary')
bd_feature = bd_layer.GetNextFeature()
district = bd_feature.GetGeometryRef()
wgs = osr.SpatialReference()
wgs.ImportFromEPSG(4326)
wgs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
utm = bd_layer.GetSpatialRef()
transform = osr.CoordinateTransformation(wgs, utm)
towns = {}
names = {
 '001':'滨河街道','002':'兴谷街道','003':'平谷镇','004':'峪口镇','005':'马坊镇','006':'金海湖镇',
 '101':'东高村镇','102':'山东庄镇','104':'南独乐河镇','105':'大华山镇','106':'夏各庄镇',
 '108':'马昌营镇','110':'王辛庄镇','111':'大兴庄镇','112':'刘家店镇','114':'镇罗营镇',
 '213':'黄松峪乡','214':'熊儿寨乡',
}
assert sorted(f['properties']['code'] for f in towns_json['features']) == sorted('110117'+n+'000' for n in names)
for f in towns_json['features']:
    code = f['properties']['code'][6:9]
    geom = ogr.CreateGeometryFromJson(json.dumps(f['geometry']))
    geom.Transform(transform)
    print(code, names[code], f['properties']['name'], 'valid',geom.IsValid(),'utm area',round(geom.GetArea()/1e6,2))
    if not geom.IsValid():
        geom = geom.MakeValid()
        print('repaired area',round(geom.GetArea()/1e6,3))
    towns[code] = geom
union = None
for g in towns.values():
    union = g if union is None else union.Union(g)
print('District km²: ',district.GetArea()/1e6)
print('Town union km²: ',union.GetArea()/1e6)
print('District covered km²: ',district.Intersection(union).GetArea()/1e6)
print('Town union outside district km²: ',union.Difference(district).GetArea()/1e6)
print('District not covered km²: ',district.Difference(union).GetArea()/1e6)
print('pairwise overlap excess km²: ',(sum(x.GetArea() for x in towns.values())-union.GetArea())/1e6)
for a,b in combinations(towns,2):
    if towns[a].Intersects(towns[b]):
        overlap = towns[a].Intersection(towns[b]).GetArea()
        if overlap>10000:
            print('Overlap > 0.01 km²',a,b,overlap/1e6)

# 分摊每格自身的人口权重和距离分级，边界未覆盖部分记入未分配。
from collections import defaultdict
import csv
path = sorted(Path('work/pinggu-coverage-audit').glob('accessibility_grid_v0_*.gpkg'))[-1]
access = ogr.Open(str(path))
grid = access.GetLayerByName('accessibility_grid_v0')
assert grid.GetSpatialRef().GetAuthorityCode(None)=='32650'
thresholds = (1000,3000,5000)
fields = ['population','pop_1km','pop_3km','pop_5km','pop_unreachable']
result = {code: dict.fromkeys(fields, 0.0) for code in ['rest',*towns]}
boxes = {code: g.GetEnvelope() for code,g in towns.items()}
population = 0.0
for f in grid:
    geom = f.GetGeometryRef()
    area = geom.GetArea()
    assert area > 0
    xmin,xmax,ymin,ymax = geom.GetEnvelope()
    areas = {}
    for code,g in towns.items():
        a,b,c,d = boxes[code]
        if xmin > b or xmax < a or ymin > d or ymax < c:
            continue
        if geom.Intersects(g):
            value = geom.Intersection(g).GetArea()
            if value>0:
                areas[code] = value
    covered = sum(areas.values())
    denominator = max(area,covered)
    shares = {k:v/denominator for k,v in areas.items()}
    shares['rest'] = max(0.0, 1-sum(shares.values()))
    w = f['pop_cal']
    d = f['net_dist_m']
    population += w
    for code,share in shares.items():
        a = result[code]
        allocated = w * share
        a['population'] += allocated
        if d is None or f['status'] == '不可达':
            a['pop_unreachable'] += allocated
        else:
            for limit, field in zip(thresholds,fields[1:]):
                if d<=limit:
                    a[field] += allocated

assert abs(sum(x['population'] for x in result.values()) - population)<1e-6
print('grid population',population)
print('coverage totals',(sum(x['pop_1km'] for x in result.values()),sum(x['pop_3km'] for x in result.values()),sum(x['pop_5km'] for x in result.values()),sum(x['pop_unreachable'] for x in result.values())))
total_rows=[]
for k,a in result.items():
    pop = a['population']
    code = '110117'+k if k!='rest' else ''
    disp = names.get(k,'边界未分配')
    rates = [100*a[f]/pop if pop else 0 for f in fields[1:]]
    total_rows.append((code,disp,*(a[f] for f in fields),*rates))
town_rows = sorted(total_rows[1:],key=lambda row:row[8],reverse=True)
total_rows = town_rows+total_rows[:1]
for row in total_rows:
    print(row[0],row[1],round(row[2],1),*(round(v,2) for v in row[-4:]))
with (base/'pinggu_town_coverage_provisional.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.writer(f)
    writer.writerow(['code','name',*fields,'pct_1km','pct_3km','pct_5km','pct_unreachable'])
    writer.writerows(total_rows)

gpkg = base / 'pinggu_town_coverage_provisional.gpkg'
assert not gpkg.exists()
out=ogr.GetDriverByName('GPKG').CreateDataSource(str(gpkg))
lst=out.CreateLayer('town_coverage',srs=utm,geom_type=ogr.wkbMultiPolygon)
for n in ('code','name'):
    lst.CreateField(ogr.FieldDefn(n,ogr.OFTString))
columns=fields+['pct_1km','pct_3km','pct_5km','pct_unreachable']
for n in columns:
    lst.CreateField(ogr.FieldDefn(n,ogr.OFTReal))
for row in town_rows:
    q=ogr.Feature(lst.GetLayerDefn())
    q.SetField('code',row[0])
    q.SetField('name',row[1])
    for k,v in zip(columns,row[2:]):
        q.SetField(k,v)
    q.SetGeometry(towns[row[0][6:9]])
    lst.CreateFeature(q)
assert lst.GetFeatureCount()==18
out=None
