import json
from concurrent.futures import ThreadPoolExecutor
from http.cookiejar import CookieJar
from pathlib import Path
from urllib.request import build_opener, HTTPCookieProcessor, Request

root=Path('work/pinggu-towns')
base='https://map.ruiduobao.com'
opener=build_opener(HTTPCookieProcessor(CookieJar()))
opener.addheaders=[('User-Agent','Mozilla/5.0'),('Referer',base+'/')]
def fetch(uri):
    return opener.open(base+uri,timeout=25)
with fetch('/get-years') as r:
    print('years',r.read(2500).decode('utf-8'),flush=True)
with fetch('/checkDownloadStatus') as r:
    status=json.load(r)
print('download allowed', not status.get('isBanned') and not status.get('needPassword'),flush=True)
if not status.get('isBanned') and not status.get('needPassword'):
    uri='/downloadCountyBatch/county/110117?format=geojson&year=2023&village=none'
    with fetch(uri) as r:
        raw=r.read(15*1024*1024)
        print('bulk',r.status,r.headers.get('Content-Type'),len(raw),raw[:6],flush=True)
    dest=root/'pinggu_2023_county_towns.zip'
    if raw.startswith(b'PK'):
        dest.write_bytes(raw)
    else:
        print(raw[:1000].decode('utf-8',errors='replace'))
