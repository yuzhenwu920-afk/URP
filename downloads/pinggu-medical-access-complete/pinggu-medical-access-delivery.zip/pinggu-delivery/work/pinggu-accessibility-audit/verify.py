from pathlib import Path
from math import sqrt
from qgis.core import (QgsApplication, QgsVectorLayer, QgsGeometry, QgsSpatialIndex,
                       QgsRectangle, QgsField, QgsFeature)
from qgis.PyQt.QtCore import QVariant
from datetime import datetime
import sys

app = QgsApplication([],False)
app.initQgis()
sys.path.append('/usr/share/qgis/python/plugins')
import processing
from processing.core.Processing import Processing
Processing.initialize()

directory = Path('work/pinggu-accessibility-audit').resolve()
path = str(Path('work/pinggu-audit/pinggu_b_delivery_v0.gpkg').resolve())
roads = QgsVectorLayer(path + '|layername=roads', 'roads', 'ogr')
grid = QgsVectorLayer(path + '|layername=grid_1km', 'grid', 'ogr')
facilities = QgsVectorLayer(path + '|layername=facilities_primary', 'facilities', 'ogr')
for layer in (roads,grid,facilities):
    assert layer.isValid() and layer.crs().authid() == 'EPSG:32650'
road_features = {f.id(): f for f in roads.getFeatures()}
index = QgsSpatialIndex(roads.getFeatures())

def candidate(point, fids):
    return min((res[0], fid, res[1])
               for fid in fids for res in [road_features[fid].geometry().closestSegmentWithContext(point)])

def snap(point):
    d = sqrt(candidate(point,index.nearestNeighbor(point,1))[0]) + 1e-7
    x, y = point.x(), point.y()
    dist2, fid, pt = candidate(point,index.intersects(QgsRectangle(x-d,y-d,x+d,y+d)))
    return sqrt(dist2),fid,pt

def create(layer, kind):
    result = QgsVectorLayer('Point?crs=EPSG:32650', kind, 'memory')
    provider = result.dataProvider()
    provider.addAttributes(list(layer.fields())+[QgsField('snap_dist_m',QVariant.Double),QgsField('road_fid',QVariant.LongLong)])
    result.updateFields()
    features=[]
    for f in layer.getFeatures():
        if kind=='facilities' and f['in_bnd']!=1:
            continue
        geometry = f.geometry().pointOnSurface() if kind=='demand' else f.geometry()
        d, rid, p = snap(geometry.asPoint())
        n = QgsFeature(result.fields())
        n.setAttributes(f.attributes()+[d,rid])
        n.setGeometry(QgsGeometry.fromPointXY(p))
        features.append(n)
    ok,_ = provider.addFeatures(features)
    assert ok
    return result

lookup = {'pinggu_b_delivery_v0 — roads':roads, 'demand_snapped_v0':create(grid,'demand'), 'facilities_snapped_v0':create(facilities,'facilities')}
log = Path('attachments/beee0fad-1ef1-412c-83f5-915ce6f179b3/已粘贴的文本.txt').read_text()
body = log[log.rindex('import math, heapq, statistics, os'):log.rindex('(took 56.1s)')]
body = body[:body.index('out_path = ')] + '''out_path = str(directory / f"accessibility_v0_{datetime.now():%Y%m%d_%H%M%S_%f}.gpkg")
processing.run("native:savefeatures", {"INPUT": vl, "OUTPUT": out_path, "LAYER_NAME": "accessibility_v0"})
saved = QgsVectorLayer(out_path, "accessibility_v0", "ogr")
assert saved.isValid()
assert saved.featureCount() == 1039
''' + body[body.index('# ---------------- 5.'):]

scope = dict(get_layer=lookup.__getitem__, directory=directory, datetime=datetime, processing=processing)
exec(compile(body, '<reviewed graph code>', 'exec'), scope)
assert len(scope['reach'])+len(scope['unreach']) == 1039
assert abs(scope['pop_all']-457000)<.001
print('checked',scope['saved'].featureCount())
