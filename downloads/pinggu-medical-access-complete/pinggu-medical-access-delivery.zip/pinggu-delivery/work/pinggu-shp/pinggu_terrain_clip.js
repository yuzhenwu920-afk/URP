// 平谷区基层医疗可达性｜按区界裁剪
var boundary = ee.FeatureCollection(
  'projects/my-project-3-503409/assets/pinggu_boundary_v0'
);
var region = boundary.geometry(1);
var prefix = 'pinggu_osm_v0';
var driveFolder = 'Pinggu_GEE';
var crs = 'EPSG:32650';
var transform = [30, 0, 0, 0, -30, 0];
var nodata = -9999;

// 先在 30 米 UTM 格网上重采样 DEM，再用相邻像元计算坡度。
var demUtm = ee.Image('NASA/NASADEM_HGT/001')
  .select('elevation')
  .toFloat()
  .resample('bilinear')
  .reproject({crs: crs, crsTransform: transform});
var elevation = demUtm.rename('elev_m').clip(region);
var slope = ee.Terrain.slope(demUtm).rename('slope_deg').clip(region);

Map.centerObject(region, 10);
Map.addLayer(elevation, {
  min: 0, max: 1300, palette: ['eaf4db', 'a3bb78', '9c6949', 'f5f4ee']
}, '高程（m）');
Map.addLayer(slope, {
  min: 0, max: 45, palette: ['fff7bc', 'fec44f', 'd95f0e', '7f0000']
}, '坡度（°）');

Map.addLayer(boundary.style({
  color: '00FFFF', fillColor: '00000000', width: 2
}), {}, '平谷区界');
print('区界要素数', boundary.size());
print('范围面积（km²）', region.area({maxError: 1, proj: crs}).divide(1e6));
print('高程、坡度的最小值／最大值／有效像元数',
  elevation.addBands(slope).reduceRegion({
    reducer: ee.Reducer.minMax().combine({
      reducer2: ee.Reducer.count(), sharedInputs: true
    }),
    geometry: region,
    crs: crs,
    crsTransform: transform,
    maxPixels: 1e8,
    tileScale: 2
  })
);

function exportTif(image, suffix) {
  var name = prefix + '_' + suffix + '_30m';
  Export.image.toDrive({
    image: image.toFloat().unmask({value: nodata, sameFootprint: false}),
    description: name,
    folder: driveFolder,
    fileNamePrefix: name,
    region: region,
    crs: crs,
    crsTransform: transform,
    maxPixels: 1e8,
    fileFormat: 'GeoTIFF',
    formatOptions: {cloudOptimized: true, noData: nodata}
  });
}

exportTif(elevation, 'dem_m');
exportTif(slope, 'slope_deg');
