from collections import defaultdict
from pathlib import Path
import json

from qgis.core import (
    QgsApplication, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsGeometry, QgsProject, QgsVectorLayer,
)

folder = Path(__file__).parent
app = QgsApplication([], False)
app.initQgis()
project = QgsProject.instance()
data = json.loads((folder / 'scenarios.json').read_text())
base = folder.parent / 'pinggu-audit' / 'pinggu_b_delivery_v0.gpkg'
layer = QgsVectorLayer(str(base) + '|layername=grid_1km', 'grid', 'ogr')
assert layer.isValid()
transform = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem('EPSG:4326'), project)
records = {f['properties']['gid']: f['properties'] for f in data.pop('cells')['features']}
groups = defaultdict(list)
isolated = []
for feature in layer.getFeatures():
    row = records[int(feature['gid'])]
    geom = feature.geometry()
    assert geom.isGeosValid()
    groups[row['s']].append(geom)
    if row['d'] is None:
        assert row['s'] == -1
        isolated.append(geom)
assert {k: len(v) for k, v in groups.items()} == {-1: 368, 0: 633, 1: 12, 2: 10, 3: 16}
assert len(isolated) == 40

def dissolve(geometries, code):
    geom = QgsGeometry.unaryUnion(geometries)
    assert not geom.isEmpty() and geom.isGeosValid(), code
    source_area = sum(g.area() for g in geometries)
    assert abs(geom.area() - source_area) < 0.02, (code, geom.area() - source_area)
    geom.transform(transform)
    return {'type': 'Feature', 'properties': {'s': code}, 'geometry': json.loads(geom.asJson(7))}

data['zones'] = [dissolve(groups[k], k) for k in sorted(groups)]
data['disconnected'] = dissolve(isolated, 'isolated')
data['isolated_n'] = len(isolated)
(folder / 'planning-map-data.json').write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
print('Verified category geometry area and counts', {k: len(v) for k, v in groups.items()})
