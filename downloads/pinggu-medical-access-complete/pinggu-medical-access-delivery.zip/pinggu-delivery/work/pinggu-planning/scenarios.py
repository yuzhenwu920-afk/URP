from collections import defaultdict
from heapq import heappop, heappush
import json
from math import fsum, isfinite, sqrt
from pathlib import Path

from qgis.core import (QgsApplication, QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, QgsGeometry, QgsProject,
                       QgsRectangle, QgsSpatialIndex, QgsVectorLayer, QgsWkbTypes)

app = QgsApplication([], False)
app.initQgis()
project = QgsProject.instance()
base = Path('work/pinggu-audit/pinggu_b_delivery_v0.gpkg').resolve()
scratch = Path('work/pinggu-planning')

def load(uri, name):
    layer = QgsVectorLayer(str(uri), name, 'ogr')
    assert layer.isValid(), uri
    return layer

roads = load(str(base) + '|layername=roads', 'roads')
grid = load(str(base) + '|layername=grid_1km', 'grid')
facilities = load(str(base) + '|layername=facilities_primary', 'facilities')
boundary = load(str(base) + '|layername=boundary', 'boundary')
towns = load(Path('work/pinggu-towns/pinggu_town_coverage_provisional.gpkg').resolve(), 'towns')
baseline = load(sorted(Path('work/pinggu-accessibility-audit').glob('*.gpkg'))[-1].resolve(), 'baseline')
assert all(l.crs().authid() == 'EPSG:32650' for l in (roads, grid, facilities, boundary, towns, baseline))

geoms = {f.id(): f.geometry() for f in roads.getFeatures()}
highways = {f.id(): str(f['highway']) for f in roads.getFeatures()}
index = QgsSpatialIndex(roads.getFeatures())
eligible_highways = {'residential','living_street','unclassified','service','tertiary','secondary','primary'}

def nearest(point):
    def minimum(ids):
        found = []
        for fid in ids:
            dist_sq, closest, _, _ = geoms[fid].closestSegmentWithContext(point)
            found.append((dist_sq, fid, closest))
        return min(found, key=lambda r: (r[0], r[1]))

    dist_sq, _, _ = minimum(index.nearestNeighbor(point, 1))
    radius = sqrt(dist_sq) + 1e-6
    x, y = point.x(), point.y()
    return minimum(index.intersects(QgsRectangle(x-radius, y-radius, x+radius, y+radius)))

def point_to_road(geom):
    _, road, point = nearest(geom.asPoint())
    return road, QgsGeometry.fromPointXY(point)

def coordinate_node(p):
    return ('r', round(p.x(), 3), round(p.y(), 3))

pop, points, point_roads, polygons = {}, {}, {}, {}
attachments = defaultdict(list)
for f in grid.getFeatures():
    gid = int(f['gid'])
    pop[gid] = float(f['pop_cal'])
    polygons[gid] = f.geometry()
    road, snapped = point_to_road(f.geometry().pointOnSurface())
    attachments[road].append((('d',gid), snapped))
    points[gid] = snapped
    point_roads[gid] = highways[road]

fac_nodes = []
for f in facilities.getFeatures():
    if f['in_bnd'] != 1:
        continue
    road, snapped = point_to_road(f.geometry())
    node = ('f', f.id())
    fac_nodes.append(node)
    attachments[road].append((node, snapped))
assert len(fac_nodes) == 161

edges = defaultdict(list)
for road, geom in geoms.items():
    assert not geom.isMultipart()
    vertices = geom.asPolyline()
    length = geom.length()
    route = [(0.0,coordinate_node(vertices[0]))]
    for node, pt in attachments[road]:
        distance = geom.lineLocatePoint(pt)
        assert distance >= 0
        route.append((min(distance, length),node))
    route.append((length,coordinate_node(vertices[-1])))
    route.sort(key=lambda r:r[0])
    for (d0, u), (d1, v) in zip(route,route[1:]):
        edges[u].append((v,d1-d0))
        edges[v].append((u,d1-d0))

def shortest(sources, limit=float('inf')):
    distances = {n: 0.0 for n in sources}
    heap = [(0.0,n) for n in sources]
    heap.sort()
    while heap:
        cost, u = heappop(heap)
        if cost > distances[u]:
            continue
        for v, length in edges[u]:
            next_cost = cost + length
            if next_cost <= limit and next_cost < distances.get(v,float('inf')):
                distances[v] = next_cost
                heappush(heap,(next_cost,v))
    return distances

dist = shortest(fac_nodes)
baseline_rows = {int(f['gid']): f['net_dist_m'] for f in baseline.getFeatures()}
for gid in pop:
    d = dist.get(('d',gid))
    b = baseline_rows[gid]
    if d is None:
        assert str(b) == 'NULL'
    else:
        assert abs(d-float(b)) < 1e-5, (gid, d,b)

cutoff = 3000
base_covered = {gid for gid in pop if dist.get(('d',gid),float('inf')) <= cutoff}
unmet = set(pop).difference(base_covered)
candidate_gids = [gid for gid in sorted(unmet) if point_roads[gid] in eligible_highways]
assert candidate_gids
candidate_cells = {c: {node[1] for node in shortest([('d',c)],cutoff) if node[0]=='d' and node[1] in unmet}
                   for c in candidate_gids}
district_coverage = []
def population(gids):
    return fsum(pop[g] for g in gids)
district_coverage.append({'stage':0,'population':population(base_covered),'n':len(base_covered)})

def place(geom):
    for f in towns.getFeatures():
        if f.geometry().intersects(geom):
            return f['name']
    return '区界附近'

isolated = {gid for gid in unmet if ('d',gid) not in dist}
priority = max(candidate_cells, key=lambda gid: (population(candidate_cells[gid] & isolated),
                                                 population(candidate_cells[gid]), -gid))
priority_gain = candidate_cells[priority]
priority_case = {'town':place(points[priority]),'gid':priority,'pop':population(priority_gain),
                 'isolated_pop':population(priority_gain & isolated),'isolated_n':len(priority_gain & isolated)}
unserved = unmet.copy()
sites = []
stage_for_grid = {gid:0 if gid in base_covered else -1 for gid in pop}
for stage in range(1,4):
    best = max(candidate_cells, key=lambda gid: (population(candidate_cells[gid] & unserved), -gid))
    covered_here = candidate_cells.pop(best) & unserved
    assert covered_here
    unserved -= covered_here
    for gid in covered_here:
        stage_for_grid[gid]=stage
    sites.append({'stage':stage,'gid':best,'town':place(points[best]),'pop':population(covered_here),'n':len(covered_here)})
    district_coverage.append({'stage':stage,'population':population(set(pop)-unserved),'n':len(pop)-len(unserved)})

# Geometry for the geographic visualization. Keep legitimate clipped cell boundaries.
ll = QgsCoordinateReferenceSystem('EPSG:4326')
xform = QgsCoordinateTransform(grid.crs(),ll,project)
def geodata(geom, simplify=0):
    copy = QgsGeometry(geom)
    if simplify:
        copy = copy.simplify(simplify)
    if copy.isEmpty():
        copy = QgsGeometry(geom)
    copy.transform(xform)
    return json.loads(copy.asJson(6))

for s in sites:
    s['coordinates'] = geodata(points[s['gid']])['coordinates']
data = {
    'total':population(pop),'base':len(base_covered),'candidates':len(candidate_gids),
    'unmet':len(unmet),'unmet_pop':population(unmet),'sites':sites,'rollout':district_coverage,'priority_case':priority_case,
    'district': {'type':'FeatureCollection','features':[
        {'type':'Feature','geometry':geodata(f.geometry(),20),'properties':{}} for f in boundary.getFeatures()]},
    'towns': {'type':'FeatureCollection','features':[
        {'type':'Feature','geometry':geodata(f.geometry(),65),'properties':{'name':f['name']}} for f in towns.getFeatures()]},
    'cells': {'type':'FeatureCollection','features':[
        {'type':'Feature','geometry':geodata(polygons[gid],14),
         'properties':{'gid':gid,'s':stage_for_grid[gid], 'p':round(pop[gid],1), 'd':round(dist[('d',gid)]) if ('d',gid) in dist else None}} for gid in sorted(pop)]}}
assert abs(data['total'] - 457000.0) < 1e-6
assert len(unmet) == 406
assert abs(data['unmet_pop'] - 35795.75707426289) < .001
assert data['rollout'][0]['n'] == 633
for s in sites:
    assert s['gid'] in candidate_gids and stage_for_grid[s['gid']] <= s['stage']
(scratch / 'scenarios.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print({k:v for k,v in data.items() if k not in {'district','towns','cells'}})
print('GeoJSON bytes',(scratch/'scenarios.json').stat().st_size)
