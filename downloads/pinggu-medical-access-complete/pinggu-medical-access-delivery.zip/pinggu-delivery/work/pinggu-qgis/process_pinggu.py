from pathlib import Path
from tempfile import mkdtemp

from osgeo import gdal
from qgis.PyQt.QtWidgets import QFileDialog
from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer
import processing


def run_pinggu():
    gpkg, _ = QFileDialog.getOpenFileName(
        None, "选择陈的 GeoPackage", "", "GeoPackage (*.gpkg)"
    )
    if not gpkg:
        return

    files, _ = QFileDialog.getOpenFileNames(
        None, "同时选择三张原始 TIFF", str(Path(gpkg).parent),
        "GeoTIFF (*.tif *.tiff)"
    )
    if len(files) != 3:
        print("请选择三张 TIFF 后重新运行。")
        return

    boundary = QgsVectorLayer(gpkg + "|layername=boundary", "平谷区界", "ogr")
    grid = QgsVectorLayer(gpkg + "|layername=grid_1km", "人口网格", "ogr")
    if (not boundary.isValid() or boundary.featureCount() != 1
            or not grid.isValid() or boundary.crs() != grid.crs()
            or not {"gid", "pop_cal"}.issubset(grid.fields().names())):
        raise ValueError("请选择包含 boundary 和 grid_1km 的陈版 GeoPackage。")

    folder = Path(mkdtemp(prefix="pinggu_qgis_", dir=str(Path(gpkg).parent)))
    layers = []
    for path in files:
        src = gdal.Open(path)
        if src is None or src.RasterCount != 1 or not src.GetProjection():
            raise ValueError("需要带坐标系的单波段 TIFF：" + path)
        band = src.GetRasterBand(1)
        nodata = band.GetNoDataValue()
        if nodata == 0:
            print("源文件将 0 标记为 NoData：", Path(path).name)
        dtype = gdal.GDT_Float64 if band.DataType == gdal.GDT_Float64 else gdal.GDT_Float32
        dest = folder / (Path(path).stem + "_clip.tif")
        if dest.exists():
            raise ValueError("有重名 TIFF：" + path)
        out = gdal.Warp(
            str(dest), src, format="GTiff", cutlineDSName=gpkg,
            cutlineLayer="boundary", cropToCutline=True, resampleAlg="near",
            dstNodata=-9999 if nodata is None else nodata, outputType=dtype,
            creationOptions=["COMPRESS=DEFLATE", "TILED=YES"]
        )
        if out is None:
            raise RuntimeError("裁剪失败：" + path)
        _, dx, _, _, _, dy = out.GetGeoTransform()
        print(dest.name, "像元大小", dx, abs(dy),
              "NoData", out.GetRasterBand(1).GetNoDataValue())
        out = None
        layers.append(QgsRasterLayer(str(dest), dest.stem))

    points_path = str(folder / "demand_points_v0.gpkg")
    processing.run("native:pointonsurface", {
        "INPUT": grid, "ALL_PARTS": False, "OUTPUT": points_path
    })
    points = QgsVectorLayer(points_path, "demand_points_v0", "ogr")
    if not points.isValid() or any(not layer.isValid() for layer in layers):
        raise RuntimeError("成果已写入，但有图层无法加载：" + str(folder))
    features = list(points.getFeatures())
    mask = next(boundary.getFeatures()).geometry()
    print("需求点数", len(features),
          "重复 gid 数", len(features) - len({f["gid"] for f in features}),
          "pop_cal 合计", round(sum(float(f["pop_cal"]) for f in features), 2),
          "区外点数", sum(not mask.intersects(f.geometry()) for f in features))
    QgsProject.instance().addMapLayers(layers + [points])
    print("成果目录", folder)


run_pinggu()
