import math
import os
import tempfile
from pathlib import Path
from unittest.mock import patch
import sys
from osgeo import gdal, osr
from qgis.core import QgsApplication, QgsProject
from qgis.PyQt.QtWidgets import QFileDialog

QgsApplication.setPrefixPath('/usr', True)
app=QgsApplication([], False)
app.initQgis()
sys.path.append('/usr/share/qgis/python/plugins')
from processing.core.Processing import Processing
Processing.initialize()
script=Path('work/pinggu-qgis/process_pinggu.py').read_text()
gpkg=Path('work/pinggu-audit/pinggu_b_delivery_v0.gpkg').resolve()
with tempfile.TemporaryDirectory(dir=str(Path('work/pinggu-qgis').resolve())) as tmp:
 import shutil
 gpkg=Path(shutil.copyfile(gpkg, Path(tmp)/gpkg.name))
 defs=[('dem',30,gdal.GDT_Float32,-9999,543.5,32650),
       ('slope',30,gdal.GDT_Float32,-9999,12.75,32650),
       ('tcc10',10,gdal.GDT_Byte,None,0,4548)]
 files=[]
 for name,scale,dt,nd,value,epsg in defs:
  src=Path(tmp)/(name+'.tif')
  files.append(str(src))
  srs=osr.SpatialReference()
  srs.ImportFromEPSG(epsg)
  d=gdal.GetDriverByName('GTiff').Create(str(src), math.ceil(47000/scale),math.ceil(43000/scale),1,dt)
  d.SetGeoTransform((491007,scale,0,4471008,0,-scale))
  d.SetProjection(srs.ExportToWkt())
  band=d.GetRasterBand(1)
  if nd is not None:
   band.SetNoDataValue(nd)
  band.Fill(value)
  band=None
  d=None
 with patch.object(QFileDialog,'getOpenFileName',return_value=(str(gpkg),'')), patch.object(QFileDialog,'getOpenFileNames',return_value=(files,'')):
  exec(compile(script,'process_pinggu.py','exec'),{})
 output=next(Path(tmp).glob('pinggu_qgis_*'))
 for name,scale,dt,nd,value,epsg in defs:
  src=gdal.Open(str(Path(tmp)/(name+'.tif')))
  out=gdal.Open(str(output/(name+'_clip.tif')))
  assert out.GetGeoTransform()[1::4] == (scale,-scale), out.GetGeoTransform()
  assert out.GetSpatialRef().IsSame(src.GetSpatialRef())
  assert out.GetRasterBand(1).ComputeRasterMinMax(False) == (value,value)
  assert out.GetRasterBand(1).GetNoDataValue() == -9999
  assert out.GetRasterBand(1).ReadAsArray()[0,0] == -9999
  x0, _, _, y0, _, _ = src.GetGeoTransform()
  x1, _, _, y1, _, _ = out.GetGeoTransform()
  assert abs((x1-x0)/scale - round((x1-x0)/scale)) < 1e-7
  assert abs((y1-y0)/scale - round((y1-y0)/scale)) < 1e-7
 points=QgsProject.instance().mapLayersByName('demand_points_v0')[0]
 assert points.featureCount()==1039
 assert abs(sum(float(f['pop_cal']) for f in points.getFeatures())-457000)<.001
 del points
 print("PASS: shape mask, source CRS/grid/pixel values and demand totals", flush=True)
 QgsProject.instance().clear()
os._exit(0)
