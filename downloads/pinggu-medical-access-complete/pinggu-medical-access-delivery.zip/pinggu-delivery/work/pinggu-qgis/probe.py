from pathlib import Path
from osgeo import gdal, osr
import tempfile

srs=osr.SpatialReference()
srs.ImportFromEPSG(32650)
mask=str(Path('work/pinggu-audit/pinggu_b_delivery_v0.gpkg').resolve())
with tempfile.TemporaryDirectory() as temp:
 for scale in (10,30):
  src=f'{temp}/src_{scale}.tif'
  destination=f'{temp}/out_{scale}.tif'
  d=gdal.GetDriverByName('GTiff').Create(src, round(47000/scale),round(43000/scale),1,gdal.GDT_Byte)
  d.SetGeoTransform((491007,scale,0,4471008,0,-scale))
  d.SetProjection(srs.ExportToWkt())
  d.GetRasterBand(1).Fill(0)
  d=None
  out=gdal.Warp(destination,src,format='GTiff',cutlineDSName=mask,
      cutlineLayer='boundary',cropToCutline=True,
      resampleAlg='near',dstNodata=-9999,outputType=gdal.GDT_Float32)
  print('default', scale, out.GetGeoTransform(), out.GetRasterBand(1).GetNoDataValue(),out.GetRasterBand(1).ComputeRasterMinMax(False))
