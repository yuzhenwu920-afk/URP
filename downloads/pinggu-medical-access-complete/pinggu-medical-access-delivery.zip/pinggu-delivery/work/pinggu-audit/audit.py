from collections import Counter, defaultdict
import math, sqlite3, statistics
from osgeo import ogr

ogr.UseExceptions()
path = 'work/pinggu-audit/pinggu_b_delivery_v0.gpkg'
ds = ogr.Open(path)
db = sqlite3.connect('file:' + path + '?mode=ro', uri=True)
db.row_factory = sqlite3.Row
def sql(query):
    for row in db.execute(query):
        print(dict(row))
def features(name):
    return [f.Clone() for f in ds.GetLayerByName(name)]
def geom(f):
    return f.GetGeometryRef()

sql('PRAGMA integrity_check')
sql('SELECT table_name, geometry_type_name, srs_id FROM gpkg_geometry_columns')
for layer in ds:
    empty = invalid = nonsimple = 0
    for f in layer:
        g = geom(f)
        if g is None or g.IsEmpty():
            empty += 1
        else:
            invalid += not g.IsValid()
            nonsimple += g.GetGeometryName() == 'LINESTRING' and not g.IsSimple()
    print(layer.GetName(), 'empty/invalid/nonsimple', empty, invalid, nonsimple)
bd_features = features('boundary')
bd = geom(bd_features[0])
a = 1e6
towns = features('towns')
print('town names', Counter(f['town'] for f in towns))
poly_collection = ogr.Geometry(ogr.wkbMultiPolygon)
for f in towns:
    for i in range(geom(f).GetGeometryCount()):
        poly_collection.AddGeometry(geom(f).GetGeometryRef(i))
union = poly_collection.UnionCascaded()
print('town area/union area/in district/outside/missing km2', sum(geom(f).GetArea() for f in towns)/a, union.GetArea()/a, bd.Intersection(union).GetArea()/a, union.Difference(bd).GetArea()/a, bd.Difference(union).GetArea()/a)
for i,t in enumerate(towns):
    for u in towns[i+1:]:
        if not geom(t).Intersects(geom(u)): continue
        s = geom(t).Intersection(geom(u)).GetArea()/a
        if s > 0.01: print('town overlap', t['town'], t['osm_id'], u['town'], u['osm_id'], s)
for l in ('facilities', 'facilities_primary'):
    sql(f'SELECT level_code, in_bnd, count(*) n, sum(n_merged) source_n FROM {l} GROUP BY level_code, in_bnd')
    outside = [f for f in features(l) if not bd.Intersects(geom(f))]
    print(l, 'real outside', len(outside), [(f['name'], round(bd.Distance(geom(f)))) for f in outside])
    sql(f"SELECT name FROM {l} WHERE is_primary = 1 AND (name LIKE '%医院%' OR name LIKE '%核酸%' OR name LIKE '%疫苗%')")
sql('SELECT count(*) n, count(distinct gid) distinct_gid, count(pop) n_pop, count(pop_w) n_pop_w, count(pop_cal) n_pop_cal, min(frac) min_frac, max(frac) max_frac, sum(frac) sum_frac, min(pop) min_pop, sum(pop < 0) neg_pop, sum(pop_w=0) zero_pop_w, sum(pop_w) pop_w, sum(pop_cal) pop_cal FROM grid_1km')
grid = features('grid_1km')
outside_centroids = [f for f in grid if not geom(f).Intersects(geom(f).Centroid())]
print('grid centroid out of own polygon:', len(outside_centroids), [(f['gid'], round(f['pop_cal'],2)) for f in outside_centroids])
# The source script recovers the source pixel from bounds using floating-point floor division; compare with gid.
x0 = int(bd.GetEnvelope()[0]//1000)*1000
y0 = int(bd.GetEnvelope()[2]//1000)*1000
y_count = math.ceil((bd.GetEnvelope()[3]-y0)/1000)
ymax = y0 + y_count * 1000
mismatches = []
for f in grid:
    minx, _, _, maxy = geom(f).GetEnvelope()
    ix, iy = divmod(f['gid']-1, y_count)
    if (int((minx-x0)//1000), int((ymax-maxy)//1000)) != (ix, y_count-1-iy):
        mismatches.append(f['gid'])
print('population pixel mismatches inferred:', len(mismatches), mismatches[:20])
sql('SELECT count(*) n, sum(length_km) total_km, count(distinct comp_id) components, sum(is_largest) main_n, sum(length_km * is_largest) main_km, sum(highway IS NULL) null_highway, sum(speed IS NULL) null_speed, sum(bridge) bridges, sum(tunnel) tunnels, sum(oneway) one_way FROM roads')
sql('SELECT count(*) n, sum(deg=1) dangling FROM nodes')
roads = features('roads')
def endpoints(g):
    return [(round(g.GetX(i),2),round(g.GetY(i),2)) for i in (0, g.GetPointCount()-1)]
road_ids_by_node = defaultdict(list)
for f in roads:
    for xy in set(endpoints(geom(f))):
        road_ids_by_node[xy].append(f.GetFID())
by_road = {f.GetFID():f for f in roads}
print('nodes joining bridge/tunnel to ground among different road classes', sum(any(f['bridge'] or f['tunnel'] for f in fs) and any(not f['bridge'] and not f['tunnel'] for f in fs) for ids in road_ids_by_node.values() if len(ids) >= 3 for fs in [[by_road[i] for i in ids]] if len({f['highway'] for f in fs}) > 1))
sql('SELECT highway, count(*) n, sum(length_km) km FROM roads WHERE highway IN ("motorway","motorway_link") GROUP BY highway')
fac = features('facilities_primary')
main_roads = [geom(f) for f in roads if f['is_largest']]
def nearest(p):
    return min(g.Distance(p) for g in main_roads)
dist = [nearest(geom(f)) for f in fac]
print('snap to largest road, planar distance m', 'median', statistics.median(dist), 'over 100', sum(x>100 for x in dist), 'over 200', sum(x>200 for x in dist), 'max', max(dist))
print('top5', sorted([(round(x,1), f['name']) for x,f in zip(dist, fac)], reverse=True)[:5])
