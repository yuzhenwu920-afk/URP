# -*- coding: utf-8 -*-
r"""s6_qc: 交付包自检
"""
import os, sys
import geopandas as gpd
from pyogrio import list_layers
sys.stdout.reconfigure(encoding='utf-8')
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
pkg = os.path.join(BASE, 'out', 'pinggu_b_delivery_v0.gpkg')

layers = [r[0] for r in list_layers(pkg)]
print("layers:", layers)
for lyr in layers:
    g = gpd.read_file(pkg, layer=lyr)
    bad = (~g.geometry.is_valid).sum() if g.geom_type.iloc[0] != 'Point' else 0
    empty = g.geometry.is_empty.sum()
    print(f"{lyr:20s} n={len(g):6d} crs={g.crs.to_epsg()} "
          f"geom={g.geom_type.unique().tolist()} invalid={bad} empty={empty}")

bd = gpd.read_file(pkg, layer='boundary').geometry.iloc[0]
fac = gpd.read_file(pkg, layer='facilities')
prim = gpd.read_file(pkg, layer='facilities_primary')
grid = gpd.read_file(pkg, layer='grid_1km')
roads = gpd.read_file(pkg, layer='roads')
towns = gpd.read_file(pkg, layer='towns')

print()
print("boundary area km2 = %.2f" % (bd.area / 1e6))
print("facilities inside = %d / %d" % (fac.within(bd).sum(), len(fac)))
print("primary inside    = %d / %d" % (prim.within(bd).sum(), len(prim)))
print("grid area sum km2 = %.2f" % (grid.area.sum() / 1e6))
print("grid pop_cal sum  = %d" % round(grid['pop_cal'].sum()))
print("roads inside km   = %.1f / %.1f" % (roads.intersection(bd).length.sum() / 1e3, roads.length.sum() / 1e3))
print("towns unique      = %d (rows %d)" % (towns['town'].nunique(), len(towns)))
print("largest comp km   = %.1f" % roads.loc[roads.is_largest == 1, 'length_km'].sum())
print("dup facility names:", fac['name'].duplicated().sum())
print()
print("level counts after merge:")
print(fac.groupby(['level_code', 'level_cn']).size().to_string())
print()
print("grid pop_cal describe:")
print(grid['pop_cal'].describe().round(1).to_string())
print("grid cells with pop_cal>0:", int((grid['pop_cal'] > 0).sum()))