# -*- coding: utf-8 -*-
r"""
s4: 汇总成交付包 pinggu_b/out/pinggu_b_delivery_v0.gpkg
 - 医疗点：裁到区界、同址子点合并（医院/社区站）、字段规范化
 - 网格：人口按七普 457,000 校准
 - 路网：直接转移 roads_clean
"""
import os, sys
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from shapely.strtree import STRtree

sys.stdout.reconfigure(encoding='utf-8')
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUT = os.path.join(BASE, 'out')
CRS = "EPSG:32650"
POP_CENSUS = 457_000

bd = gpd.read_file(os.path.join(OUT, 'pinggu_boundary.gpkg'), layer='boundary')
poly = bd.geometry.iloc[0]

# ---------- 1. 医疗点 ----------
f = gpd.read_file(os.path.join(OUT, 'pinggu_b_v0.gpkg'), layer='med_all')
print(f"[1] 读入医疗点 {len(f)}")
f['in_bnd'] = f.within(poly).astype(int)
near = f.within(poly.buffer(2000))
print(f"    区界内 {int(f['in_bnd'].sum())}，界外 {int((1-f['in_bnd']).sum())}（其中 2 km 外 {int((~near).sum())}，剔除）")
for _, r in f[f['in_bnd'] == 0].iterrows():
    print(f"      界外 {int(r.geometry.distance(poly))} m:", r['name'], r['level_cn'])

f = f[near].copy()

BADS = ('-', '－', '科', '楼', '座', '点', '中心', '部', '室')
def score(n):
    n = str(n)
    s = 0
    if '医院' in n or '卫生院' in n or '社区卫生' in n: s += 3
    if any(t in n for t in ['-', '－']): s -= 2
    if n.endswith(('科', '楼', '座', '点', '中心', '部')): s -= 2
    if n in ('医院', '卫生院', '社区卫生运营服务站'): s -= 3
    return s + len(n) * 0.01

f['_score'] = f['name'].map(score)
f = f.reset_index(drop=True)

# 同址聚类：同 level_code 且 ≤150 m
pts = list(f.geometry)
tree = STRtree(pts)
parent = list(range(len(f)))
def find(a):
    while parent[a] != a:
        parent[a] = parent[parent[a]]; a = parent[a]
    return a
def union(a, b):
    ra, rb = find(a), find(b)
    if ra != rb: parent[rb] = ra

lv = f['level_code'].values
for i, p in enumerate(pts):
    if lv[i] not in (1, 2, 3, 4):   # 诊所/其他医疗 不做同址合并（它们是独立机构）
        continue
    for j in tree.query(p.buffer(150)):
        j = int(j)
        if j <= i or lv[i] != lv[j]:
            continue
        if p.distance(pts[j]) <= 150:
            union(i, j)

f['_grp'] = [find(i) for i in range(len(f))]
print(f"[2] 同址聚类组数 {f['_grp'].nunique()}（原 {len(f)} 个点，合并 {len(f)-f['_grp'].nunique()} 个）")

rows = []
for gid, g in f.groupby('_grp'):
    g = g.sort_values('_score', ascending=False)
    r = g.iloc[0].copy()
    r['n_merged'] = len(g)
    r['alt_names'] = ' | '.join(g['name'].iloc[1:].tolist())
    rows.append(r)
fac = gpd.GeoDataFrame(pd.DataFrame(rows), geometry='geometry', crs=CRS)
fac = fac.sort_values(['level_code', 'name']).reset_index(drop=True)
fac.insert(0, 'fid', fac.index + 1)
fac['is_primary'] = (fac['level_code'].isin([2, 3, 4, 5])).astype(int)
print("[3] 合并后分级：")
print(fac.groupby(['level_code', 'level_cn']).size().to_string())
print(f"    基层医疗（level 2-5）合计 {int(fac['is_primary'].sum())}")

cols = ['fid', 'name', 'cat1', 'cat2', 'level_code', 'level_cn', 'is_primary',
        'n_merged', 'alt_names', 'lon', 'lat', 'src', 'in_bnd', 'geometry']
fac = fac[cols]

# ---------- 2. 网格人口校准 ----------
grid = gpd.read_file(os.path.join(OUT, 'pinggu_boundary.gpkg'), layer='grid_1km')
s = grid['pop_w'].sum()
grid['pop_cal'] = grid['pop_w'] * (POP_CENSUS / s) if s > 0 else np.nan
print(f"[4] 网格 {len(grid)} 个，WorldPop 合计 {s:,.0f}，校准系数 {POP_CENSUS/s:.3f}，"
      f"校准后 {grid['pop_cal'].sum():,.0f}")

# ---------- 3. 路网 ----------
roads = gpd.read_file(os.path.join(OUT, 'roads_clean.gpkg'), layer='roads')
nodes = gpd.read_file(os.path.join(OUT, 'roads_clean.gpkg'), layer='nodes')
towns = gpd.read_file(os.path.join(OUT, 'roads_clean.gpkg'), layer='towns')
print(f"[5] 路网 {len(roads)} 段 / {roads.length_km.sum():.1f} km；结点 {len(nodes)}；乡镇 {towns['town'].nunique()}")

# ---------- 4. 打包 ----------
pkg = os.path.join(OUT, 'pinggu_b_delivery_v0.gpkg')
if os.path.exists(pkg):
    os.remove(pkg)
bd.to_file(pkg, layer='boundary', driver='GPKG')
towns.to_file(pkg, layer='towns', driver='GPKG')
grid.to_file(pkg, layer='grid_1km', driver='GPKG')
fac.to_file(pkg, layer='facilities', driver='GPKG')
fac[fac['is_primary'] == 1].to_file(pkg, layer='facilities_primary', driver='GPKG')
roads.to_file(pkg, layer='roads', driver='GPKG')
nodes.to_file(pkg, layer='nodes', driver='GPKG')
print(f"[6] 写出 {pkg}")

qa = pd.DataFrame({
    'item': ['boundary_km2', 'grid_cells', 'pop_worldpop', 'pop_census',
             'facilities_all', 'facilities_primary', 'roads_km', 'road_components',
             'dangling_nodes'],
    'value': [round(poly.area / 1e6, 2), len(grid), round(s), POP_CENSUS,
              len(fac), int(fac['is_primary'].sum()), round(roads.length_km.sum(), 1),
              int(roads['comp_id'].nunique()), int((nodes['deg'] == 1).sum())]})
qa.to_csv(os.path.join(OUT, 'qa_package.csv'), index=False, encoding='utf-8-sig')
print(qa.to_string(index=False))