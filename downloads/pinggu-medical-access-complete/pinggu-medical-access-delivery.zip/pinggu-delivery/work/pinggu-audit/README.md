# 平谷区医疗可达性 · B 分工数据包（v0 粗数据）

> 生成时间：2026-11-19 13:0x ｜ 用途：**先给 A 测工具链的粗数据**，不是最终成果
> 坐标系：全部图层 **EPSG:32650**（WGS84 / UTM 50N），单位 m
> 主文件：`out/pinggu_b_delivery_v0.gpkg`
> 配套书面说明：`平谷B_交付使用说明.docx`（同目录，另附 PDF 版；逐项讲解每个文件、每个字段、每条口径）

---

## 1. 图层字典

| 图层 | 行数 | 几何 | 用途 | 关键字段 |
|---|---|---|---|---|
| `boundary` | 1 | 面 | 平谷区界，裁剪/统计范围 | `name`；面积 947.22 km² |
| `towns` | 18（17 个不重名，兴谷街道重复） | 面 | 乡镇/街道界，分区统计用 | `town`、`osm_id` |
| `grid_1km` | 1039 | 面 | 1 km 需求网格 | `gid`、`frac`（落在区内的面积 km²）、`pop`（WorldPop 原值）、`pop_w`（×frac）、`pop_cal`（校准到 45.7 万） |
| `facilities` | 389 | 点 | 全部医疗设施 | `fid`、`name`、`cat1/cat2`（原始大类/中类）、`level_code`（1–6）、`level_cn`、`is_primary`、`n_merged`、`alt_names`、`lon/lat`、`in_bnd` |
| `facilities_primary` | 162 | 点 | **基层医疗**（社区卫生站 86 + 卫生院 31 + 村卫生室 7 + 诊所 38） | 同上 |
| `roads` | 11,813 | 线 | OSM 路网，**已在交叉口打断**，可直接建图 | `osm_id`、`name`、`highway`、`cls`、`hier`（1 高速→8 服务路）、`speed`（km/h 经验值）、`oneway`、`bridge`、`tunnel`、`length_km`、`comp_id`、`comp_nodes`、`is_largest` |
| `nodes` | 8,644 | 点 | 路网结点（含度数） | `x`、`y`、`deg`（1=悬空端点） |

校验用的 `qa_package.csv`、`qa_poi.csv`、`qa_roads.txt` 同目录。

---

## 2. 处理口径（会被老师问，务必一致）

**医疗设施分级**：POI 的 `中类` 里**没有**“卫生院/社区卫生服务中心/村卫生室”这一层，所以按**名称**判定：

| level | 含义 | 判定规则（按顺序命中） | 条数 |
|---|---|---|---|
| 1 | 医院（综合/专科/中医） | 名称含 `医院/保健院/防治所` | 31 |
| 2 | 社区卫生服务中心/站 | `社区卫生服务中心`、`社区卫生服务站`、`社区.*服务站` | 86 |
| 3 | 乡镇卫生院 | `卫生院` | 31 |
| 4 | 村卫生室 | `卫生室/村卫生所` | 7 |
| 5 | 诊所/门诊部 | `诊所/门诊部/门诊/医务室/卫生所`，且不含专科词 | 38 |
| 6 | 专科门诊、其他医疗 | 口腔/牙科/中医/康复/整形等，或急救中心/疾控/养生/康复站 | 17 + 179 |

- **基层口径 `is_primary = level 2/3/4/5`**，共 **162** 个点。
- 剔除：`医药销售`（药店 230 条）、`动物医疗`（7 条）。
- **同址合并**：同 level 且相距 ≤150 m 的点合并为 1 个“物理设施”，保留名称最规范的一个（`n_merged` 记合并数，`alt_names` 存被合并名称）。共合并 27 个，主要是同一家大医院的子 POI（`中医医院-按摩科`、`医院-住院部1`、核酸检测点等）。诊所不合并（独立机构）。
- **脱敏说明**：数据源把“社区卫生服务中心”改写成 **“社区卫生运营服务站”**，本包按后者认定为社区卫生服务站，属正常还原。

**人口**：WorldPop 2020 1 km 汇总产品（`chn_ppp_2020_1km_Aggregated.tif`），按网格相交面积折算得 369,695 人；**平谷区七普常住人口 457,000**，差 19%（WorldPop 在中国农村普遍低估），已按 `pop_cal = pop_w × 1.236` 校准。两个字段都保留，**分母建议用 `pop_cal`**。

**路网**：OSM `beijing-latest.osm.pbf`（download.openstreetmap.fr）按 bbox 抽取，只保留可通行等级（剔除 footway/path/steps/cycleway/construction/proposed），裁到区界后用 `unary_union` 在交叉口打断，建网络图求连通分量。打断后的分段属性按「与原 way 重叠长度最大」回挂（不用 `predicate='within'`，否则跨越端点或互相重叠的分段会丢失 highway/speed，实测会漏 1347 段）。

---

## 3. 已知问题（v0 明确没解决）

1. **区界来自 OSM（rel 2988900），不是老师给的官方 2025 行政区划**——面积 947.22 km² vs 官方 948 km²，边界细节（尤其与密云、顺义、河北三河的交界）会有偏差。拿到官方边界后需重跑 `s2`。
2. **乡镇面只有 16 个不重名**：缺 **平谷镇**（OSM 把镇区并进了滨河/兴谷街道），且 **兴谷街道有两个重复 relation**（20256330 / 20256331）。分区统计前必须用老师的乡镇边界替换。
3. **设施没有“规模”字段**（床位/医护数），第17讲的 `Ai = Σ Oj·I(dij≤d*)` 目前只能用**设施计数**代替 `Oj`，属于代理指标，写报告时要说清。
4. **路网悬空端点 1,947 个**（断头路/村道自然末端），最大连通分量覆盖 98.9% 长度；建议 A 只用 `is_largest=1` 做网络分析，其余 1.1% 是碎片（如景区内部路）。
5. 未纳入步行小径/田埂道，山区村庄的实际步行路径可能被低估——如果论文口径是“步行 15 分钟”，后期需要补 `path/footway` 再算一版。
6. 设施点位是 POI 坐标，有 ~50–100 m 的定位误差；平谷城区多家医院相邻，聚类半径 150 m 是经验值，需人工抽查。

---

## 4. 给 A 的接入建议

```python
import geopandas as gpd
pkg = "pinggu_b/out/pinggu_b_delivery_v0.gpkg"
roads = gpd.read_file(pkg, layer="roads")
roads = roads[roads.is_largest == 1]          # 只用最大连通分量
fac   = gpd.read_file(pkg, layer="facilities_primary")
grid  = gpd.read_file(pkg, layer="grid_1km")  # 需求权重用 pop_cal
```

- 路网已是**分段**（交叉口打断），`comp_id` 相同即同一连通片，直接用 `networkx` / `pgRouting` 建图，无需再 split。
- 速度字段 `speed` 是经验值，按出行方式（步行 5 km/h / 车行）自行覆盖。
- 网格 `pop_cal` 已对齐 1 km 整数格，`grid.centroid` 可直接当需求点。
- 若要做 15 min 步行等时圈：`d* = 800–1000 m`（GB 50180-2018、TD/T 1062-2021），用 `roads` 的 `length_km` 做路网距离，不要用欧氏距离。

---

## 5. 复现

```bash
cd pinggu_b
QGIS_PY=../_qgis_py.cmd          # QGIS 3.44.15 自带 python 3.12
$QGIS_PY scripts/s1_poi_clean.py     # POI 清洗分级 -> pinggu_b_v0.gpkg
$QGIS_PY scripts/s2_boundary_grid.py # 区界 + 1km 网格 + 人口
$QGIS_PY scripts/s3_roads.py         # 路网清理 + 拓扑
$QGIS_PY scripts/s4_package.py       # 汇总交付包
$QGIS_PY scripts/s5_map.py           # 自查图
```

原始数据：`data_raw/poi2023_beijing.csv`（北京 POI 2023，679,413 条）、`data_raw/beijing-latest.osm.pbf`（42 MB）、`data_raw/worldpop_chn_2020_1km.tif`（52 MB）。