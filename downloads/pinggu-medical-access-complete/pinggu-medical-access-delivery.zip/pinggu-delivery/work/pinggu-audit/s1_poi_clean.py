# -*- coding: utf-8 -*-
r"""
B 任务 v0：平谷区 POI 清洗与医疗设施分级
输入：C:/Users/Lenovo/Desktop/国土实验/北京市POI数据.csv  (679,413 行，UTF-8-BOM)
输出：pinggu_b/out/pinggu_b_v0.gpkg
      pinggu_b/out/qa_poi.csv
坐标：WGS84 经纬度 -> EPSG:32650 (WGS84 / UTM 50N)
"""
import re, sys, os
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point

sys.stdout.reconfigure(encoding='utf-8')
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
RAW = os.path.join(BASE, 'data_raw')
OUT = os.path.join(BASE, 'out')
os.makedirs(OUT, exist_ok=True)

SRC = os.path.join(RAW, 'poi2023_beijing.csv')
CRS = "EPSG:32650"
BOUNDS = dict(lon=(116.85, 117.55), lat=(39.95, 40.45))  # 平谷区及周边，用于剔除明显错点

COLS = ['名称', '大类', '中类', '经度', '纬度', '区域']

print("[1] 读入 POI ...")
reader = pd.read_csv(SRC, encoding='utf-8-sig', usecols=COLS, chunksize=300000,
                     dtype={'名称': str, '大类': str, '中类': str, '区域': str})
df = pd.concat(list(reader), ignore_index=True)
df.columns = ['name', 'cat1', 'cat2', 'lon', 'lat', 'district']
df['lon'] = pd.to_numeric(df['lon'], errors='coerce')
df['lat'] = pd.to_numeric(df['lat'], errors='coerce')
print(f"    全市 {len(df):,} 条；缺失坐标 {df[['lon','lat']].isna().any(axis=1).sum()}")

pg = df[df['district'] == '平谷区'].copy()
print(f"    平谷区 {len(pg):,} 条")

# --- 坐标合法性 ---
bad = ~(pg['lon'].between(*BOUNDS['lon']) & pg['lat'].between(*BOUNDS['lat']))
print(f"[2] 坐标越界 {bad.sum()} 条（已剔除）")
pg = pg[~bad].copy()

# --- 医疗保健大类 ---
med = pg[pg['cat1'] == '医疗保健'].copy()
print(f"[3] 医疗保健 {len(med)} 条")

# --- 去掉非“设施” ---
NON_FAC = {'医药销售', '动物医疗'}
dropped_nf = med['cat2'].isin(NON_FAC)
print(f"[4] 剔除 药店/动物医疗 {dropped_nf.sum()} 条")
med = med[~dropped_nf].copy()

SPECIALTY = re.compile(r'口腔|牙科|牙病|眼科|视光|视力|整形|美容|医美|正骨|骨伤|康复|体检|检验|影像|透析|中医|肛肠|皮肤|精神|妇幼|肿瘤|骨科|针灸|推拿|理疗|护理院|养老')
HOSPITAL = re.compile(r'医院|保健院|防治所|人民医院|中医院')
COMM = re.compile(r'社区卫生服务中心|社区卫生服务站|社区.*服务站')
TOWN = re.compile(r'卫生院')
VILLAGE = re.compile(r'卫生室|村卫生所')
CLINIC = re.compile(r'诊所|门诊部|门诊|医务室|卫生所')

def classify(name):
    n = str(name)
    if COMM.search(n):  return 2, '社区卫生服务中心/站', 1
    if TOWN.search(n):  return 3, '乡镇卫生院', 1
    if VILLAGE.search(n): return 4, '村卫生室', 1
    if CLINIC.search(n):
        if SPECIALTY.search(n): return 6, '专科门诊（口腔/中医等）', 0
        return 5, '诊所/门诊部', 1
    if HOSPITAL.search(n):
        return 1, '医院（综合/专科/中医）', 0
    return 6, '其他医疗（急救/疾控/养生等）', 0

res = med['name'].map(classify)
med['level_code'] = [r[0] for r in res]
med['level_cn'] = [r[1] for r in res]
med['is_primary'] = [r[2] for r in res]

# --- 去重：同名且 30m 内 ---
med['x'] = med['lon']; med['y'] = med['lat']
dups = 0
keep = []
seen = {}
for idx, r in med.iterrows():
    key = (str(r['name']).strip(), round(r['lon'], 4), round(r['lat'], 4))
    if key in seen:
        dups += 1
        continue
    seen[key] = idx
    keep.append(idx)
med = med.loc[keep].copy()
print(f"[5] 完全重复剔除 {dups} 条")

med = med.reset_index(drop=True)
med.insert(0, 'fid', med.index + 1)
med['src'] = 'POI2023'

print("\n[6] 分级结果：")
stat = med.groupby(['level_code', 'level_cn', 'is_primary']).size().reset_index(name='n')
print(stat.to_string(index=False))
print(f"    基层口径（is_primary=1）合计：{int(med['is_primary'].sum())} 条")

# --- 写出点层 ---
gdf = gpd.GeoDataFrame(
    med[['fid', 'name', 'cat1', 'cat2', 'level_code', 'level_cn', 'is_primary', 'lon', 'lat', 'src']],
    geometry=[Point(xy) for xy in zip(med['lon'], med['lat'])],
    crs="EPSG:4326").to_crs(CRS)

gpkg = os.path.join(OUT, 'pinggu_b_v0.gpkg')
if os.path.exists(gpkg):
    os.remove(gpkg)
gdf.to_file(gpkg, layer='med_all', driver='GPKG')
gdf[gdf['is_primary'] == 1].to_file(gpkg, layer='med_primary', driver='GPKG')
print(f"\n[7] 写出 {gpkg}  layer=med_all({len(gdf)}) / med_primary({int((gdf['is_primary']==1).sum())})")

stat.to_csv(os.path.join(OUT, 'qa_poi.csv'), index=False, encoding='utf-8-sig')
print("    统计表 qa_poi.csv")