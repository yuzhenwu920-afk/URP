# -*- coding: utf-8 -*-
r"""s5: 质检用总览图（不对外，仅供自查）
"""
import os, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import geopandas as gpd
import numpy as np
from matplotlib.colors import LogNorm

sys.stdout.reconfigure(encoding='utf-8')
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUT = os.path.join(BASE, 'out')
pkg = os.path.join(OUT, 'pinggu_b_delivery_v0.gpkg')

bd = gpd.read_file(pkg, layer='boundary')
grid = gpd.read_file(pkg, layer='grid_1km')
fac = gpd.read_file(pkg, layer='facilities')
roads = gpd.read_file(pkg, layer='roads')
towns = gpd.read_file(pkg, layer='towns')

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei']
plt.rcParams['axes.unicode_minus'] = False

fig, axes = plt.subplots(1, 3, figsize=(21, 8))

ax = axes[0]
grid.plot(ax=ax, column='pop_cal', cmap='YlOrRd', legend=True,
          legend_kwds={'label': '人口 (人/km²)', 'shrink': 0.7},
          norm=LogNorm(vmin=1, vmax=max(1, grid['pop_cal'].max())))
bd.boundary.plot(ax=ax, color='k', lw=1)
ax.set_title('① 1km 网格人口（校准后）')
ax.set_axis_off()

ax = axes[1]
bd.plot(ax=ax, color='#f2f2f2', edgecolor='k', lw=1)
roads.plot(ax=ax, color='#999999', lw=0.3)
colors = {1: '#d62728', 2: '#1f77b4', 3: '#2ca02c', 4: '#9467bd', 5: '#ff7f0e', 6: '#bbbbbb'}
for lv, c in colors.items():
    s = fac[fac['level_code'] == lv]
    if len(s):
        s.plot(ax=ax, color=c, markersize=14 if lv <= 2 else 9, label=f'L{lv} ({len(s)})')
ax.legend(loc='lower left', fontsize=8, framealpha=0.9)
ax.set_title('② 医疗设施与路网')
ax.set_axis_off()

ax = axes[2]
prim = fac[fac['is_primary'] == 1]
grid.centroid.plot(ax=ax, color='#dddddd', markersize=3)
bd.plot(ax=ax, color='none', edgecolor='k', lw=1)
towns.plot(ax=ax, color='none', edgecolor='#777777', lw=0.5, ls='--')
prim.plot(ax=ax, color='#c0392b', markersize=16, marker='^')
for _, t in towns.iterrows():
    c = t.geometry.representative_point()
    ax.annotate(t['town'], (c.x, c.y), fontsize=6, ha='center', color='#333333')
ax.set_title(f'③ 基层医疗点 {len(prim)} 个 / 乡镇界')
ax.set_axis_off()

plt.tight_layout()
png = os.path.join(OUT, 'qcheck_overview.png')
plt.savefig(png, dpi=130, bbox_inches='tight')
print("saved", png)
print("grid pop max", grid['pop_cal'].max())