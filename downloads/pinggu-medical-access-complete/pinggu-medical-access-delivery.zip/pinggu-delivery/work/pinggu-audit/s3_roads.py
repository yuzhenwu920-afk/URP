# -*- coding: utf-8 -*-
r"""
s3: OSM 路网清理
 - 只保留平谷区界内的可通行道路
 - 分级归一（含 oneway / bridge / tunnel 解析）
 - 结点合并（unary_union 打断相交处）+ 连通分量标记
输出: pinggu_b/out/roads_clean.gpkg  layers: roads, nodes, towns
"""
import os, sys, re, json
import numpy as np
import pandas as pd
import shapely
import geopandas as gpd
import networkx as nx
from shapely.ops import unary_union, linemerge
from shapely.geometry import Point, LineString, MultiLineString

sys.stdout.reconfigure(encoding='utf-8')
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUT, RAW = os.path.join(BASE, 'out'), os.path.join(BASE, 'data_raw')
CRS = "EPSG:32650"

DROP = {'proposed', 'construction', 'footway', 'steps', 'cycleway', 'path', 'services', 'corridor', 'elevator'}
KEEP = {'motorway', 'trunk', 'primary', 'secondary', 'tertiary', 'unclassified',
        'residential', 'service', 'living_street', 'track', 'road',
        'motorway_link', 'trunk_link', 'primary_link', 'secondary_link', 'tertiary_link'}
SPEED = {'motorway': 100, 'trunk': 80, 'primary': 60, 'secondary': 50, 'tertiary': 40,
         'unclassified': 30, 'residential': 20, 'living_street': 10, 'service': 10,
         'track': 10, 'road': 20,
         'motorway_link': 60, 'trunk_link': 50, 'primary_link': 40, 'secondary_link': 30,
         'tertiary_link': 30}
HIER = {'motorway': 1, 'trunk': 2, 'primary': 3, 'secondary': 4, 'tertiary': 5,
        'unclassified': 6, 'residential': 6, 'living_street': 7, 'service': 8,
        'track': 8, 'road': 6,
        'motorway_link': 3, 'trunk_link': 3, 'primary_link': 4, 'secondary_link': 5,
        'tertiary_link': 5}

print("[1] 读取 ...")
rd = gpd.read_file(os.path.join(OUT, 'roads.gpkg'), layer='roads_raw')
bd = gpd.read_file(os.path.join(OUT, 'pinggu_boundary.gpkg'), layer='boundary')
ad = gpd.read_file(os.path.join(OUT, 'admin.gpkg'), layer='admin_raw')
print(f"    roads {len(rd)} / boundary {len(bd)} / admin {len(ad)}")

# --- 乡镇：只留落在平谷区内的 ---
ad['inter_area'] = ad.geometry.intersection(bd.geometry.iloc[0]).area
towns = ad[(ad['admin_level'] == '8') & (ad['inter_area'] / ad.area > 0.5)].copy()
towns['town'] = towns['name'].fillna('')
print(f"[2] 平谷区乡镇面 {len(towns)}: {', '.join(towns['town'])}")
towns = towns[['town', 'osm_id', 'geometry']]

# --- 路网筛选 ---
rd = rd[rd['highway'].isin(KEEP)].copy()
print(f"[3] 保留可通行等级后 {len(rd)} 条")

def parse_other(s):
    d = {}
    if isinstance(s, str):
        for kv in s.split(','):
            if '=>' in kv:
                k, v = kv.split('=>', 1)
                d[k.strip().strip('"')] = v.strip().strip('"')
    return d

rd['other'] = rd['other_tags'].map(parse_other)
rd['oneway'] = rd['other'].map(lambda d: 1 if d.get('oneway') in ('yes', 'true', '1', '-1') else 0)
rd['bridge'] = rd['other'].map(lambda d: 1 if d.get('bridge') else 0)
rd['tunnel'] = rd['other'].map(lambda d: 1 if d.get('tunnel') else 0)
rd['cls'] = rd['highway'].map(lambda h: 'link' if h.endswith('_link') else ('track' if h == 'track' else h))
rd['speed'] = rd['highway'].map(lambda h: SPEED.get(h, 20))
rd['hier'] = rd['highway'].map(lambda h: HIER.get(h, 6))

rd = rd[rd.geometry.notna() & ~rd.geometry.is_empty].copy()
rd['geometry'] = rd.geometry.apply(lambda g: linemerge(g) if g.geom_type == 'MultiLineString' else g)
rd = rd[rd.geometry.geom_type == 'LineString'].copy()

# --- 裁到区界 ---
poly = bd.geometry.iloc[0]
rd['geometry'] = rd.geometry.intersection(poly)
rd = rd[~rd.geometry.is_empty & rd.geometry.notna()].copy()
rd['length_km'] = rd.length / 1000
rd = rd[rd['length_km'] > 0.001].copy()
print(f"[4] 裁剪到区界后 {len(rd)} 条，总长 {rd['length_km'].sum():.1f} km")

# --- 结点合并 + 连通分量 ---
print("[5] 构建拓扑 ...")
merged = unary_union(list(rd.geometry))
segs = list(merged.geoms) if merged.geom_type == 'MultiLineString' else [merged]
segs = [s for s in segs if s.geom_type == 'LineString' and s.length > 0]

def key(p, nd=2):
    return (round(p[0], nd), round(p[1], nd))

G = nx.Graph()
for s in segs:
    a, b = key(s.coords[0]), key(s.coords[-1])
    G.add_edge(a, b, weight=s.length)
print(f"   结点 {G.number_of_nodes():,} 边 {G.number_of_edges():,}")

comps = sorted(nx.connected_components(G), key=len, reverse=True)
sizes = [len(c) for c in comps]
print(f"   连通分量 {len(comps)} 个，最大 {sizes[0]} 结点，其次 {sizes[1:6]}")
node_comp = {}
for i, c in enumerate(comps):
    for n in c:
        node_comp[n] = (i, sizes[i])
seg_gdf = gpd.GeoDataFrame(geometry=segs, crs=CRS)
seg_gdf['length_km'] = seg_gdf.length / 1000
seg_gdf['comp_id'] = [node_comp.get(key(s.coords[0]), (-1, 0))[0] for s in segs]
seg_gdf['comp_nodes'] = [node_comp.get(key(s.coords[0]), (-1, 0))[1] for s in segs]
seg_gdf['is_largest'] = (seg_gdf['comp_id'] == 0).astype(int)
tot = seg_gdf['length_km'].sum()
lg = seg_gdf.loc[seg_gdf['is_largest'] == 1, 'length_km'].sum()
print(f"   分段 {len(seg_gdf)} 条，总长 {tot:.1f} km；最大连通分量 {lg:.1f} km（{100*lg/tot:.1f}%）")

# 属性回挂：打断后的分段可能跨越原 way 的端点，且 unary_union 会把重叠的道路并成
# 一段，因此不能用 predicate='within'（会漏挂，实测 1347 段 / 535 km 属性为空）。
# 改为：取与分段相交且重叠长度最大的那条 way 的属性。
seg_gdf = seg_gdf.reset_index(drop=True)
attrs = rd[['osm_id', 'name', 'highway', 'cls', 'hier', 'speed', 'oneway',
            'bridge', 'tunnel', 'geometry']].reset_index(drop=True)
attrs['wid'] = range(len(attrs))
right = gpd.GeoDataFrame(attrs.drop(columns=['geometry']),
                         geometry=attrs['geometry'].values, crs=CRS)
left = gpd.GeoDataFrame({'sid': range(len(seg_gdf))},
                        geometry=seg_gdf.geometry.values, crs=CRS)
cand = gpd.sjoin(left, right, how='inner', predicate='intersects')[['sid', 'wid']]
cand['ov'] = shapely.length(shapely.intersection(
    left.geometry.values[cand['sid'].values],
    right.geometry.values[cand['wid'].values]))
best = cand.sort_values('ov', ascending=False).drop_duplicates('sid').set_index('sid')
roads_out = seg_gdf.join(best['wid'])
attr_lut = right.drop(columns=['geometry']).set_index('wid')
roads_out = roads_out.join(attr_lut, on='wid')
n_null = int(roads_out['highway'].isna().sum())
print(f"   属性回挂完成，未匹配分段 {n_null}")
roads_out = roads_out.drop(columns=['wid'])
roads_out = roads_out[['osm_id', 'name', 'highway', 'cls', 'hier', 'speed', 'oneway',
                       'bridge', 'tunnel', 'length_km', 'comp_id', 'comp_nodes',
                       'is_largest', 'geometry']]
roads_out.to_file(os.path.join(OUT, 'roads_clean.gpkg'), layer='roads', driver='GPKG')

nodes_df = pd.DataFrame([{'x': k[0], 'y': k[1], 'deg': d} for k, d in G.degree()])
nodes = gpd.GeoDataFrame(nodes_df,
                         geometry=[Point(r.x, r.y) for r in nodes_df.itertuples()], crs=CRS)
nodes.to_file(os.path.join(OUT, 'roads_clean.gpkg'), layer='nodes', driver='GPKG')
towns.to_file(os.path.join(OUT, 'roads_clean.gpkg'), layer='towns', driver='GPKG')
print(f"[6] 写出 roads_clean.gpkg: roads={len(roads_out)} nodes={len(nodes)} towns={len(towns)}")

print("\n等级汇总：")
print(roads_out.groupby('cls').agg(n=('osm_id', 'size'), km=('length_km', 'sum')).round(1).to_string())
print(f"\n悬空端点（deg=1）: {(nodes['deg']==1).sum()}  孤立结点（deg=0）: {(nodes['deg']==0).sum()}")

with open(os.path.join(OUT, 'qa_roads.txt'), 'w', encoding='utf-8') as f:
    f.write(f"roads={len(roads_out)} total_km={roads_out.length_km.sum():.1f}\n")
    f.write(f"components={len(comps)} largest_nodes={sizes[0]} sizes_top5={sizes[:5]}\n")
    f.write(f"dangling={int((nodes['deg']==1).sum())}\n")
    f.write(roads_out.groupby('cls').agg(n=('osm_id', 'size'), km=('length_km', 'sum')).round(2).to_csv())
print("    qa_roads.txt")