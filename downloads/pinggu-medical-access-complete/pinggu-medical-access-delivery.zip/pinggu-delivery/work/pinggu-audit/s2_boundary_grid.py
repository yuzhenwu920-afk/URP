# -*- coding: utf-8 -*-
r"""
s2: 由 OSM 关系几何组装平谷区边界 -> 建 1km 渔网 -> 落人口
输入: pinggu_b/data_raw/pinggu_boundary_osm.json (Overpass rel 2988900 out geom)
      pinggu_b/data_raw/worldpop_chn_2020_1km.tif
输出: pinggu_b/out/pinggu_boundary.gpkg (layers: boundary, grid_1km)
"""
import json, os, sys, glob
import numpy as np
import geopandas as gpd
from shapely.geometry import Polygon, LineString, MultiLineString, shape
from shapely.ops import linemerge, polygonize, unary_union
from shapely.validation import make_valid

sys.stdout.reconfigure(encoding='utf-8')
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
RAW, OUT = os.path.join(BASE, 'data_raw'), os.path.join(BASE, 'out')
os.makedirs(OUT, exist_ok=True)
CRS = "EPSG:32650"

j = json.load(open(os.path.join(RAW, 'pinggu_boundary_osm.json'), encoding='utf-8'))
rel = j['elements'][0]
print("relation:", rel['id'], rel.get('tags', {}).get('name'))

outer, inner = [], []
for m in rel['members']:
    if m['type'] != 'way' or 'geometry' not in m:
        continue
    coords = [(p['lon'], p['lat']) for p in m['geometry']]
    if len(coords) < 2:
        continue
    (outer if m.get('role') != 'inner' else inner).append(LineString(coords))
print(f"outer ways {len(outer)}, inner ways {len(inner)}")

merged = unary_union(outer)
polys = list(polygonize(merged))
print("polygonize ->", len(polys), "polygons")
poly = unary_union(polys)
if inner:
    poly = poly.difference(unary_union(inner))
poly = make_valid(poly)
print("geom type:", poly.geom_type, "valid:", poly.is_valid)

bd = gpd.GeoDataFrame({'name': ['平谷区'], 'src': ['OSM rel 2988900']}, geometry=[poly], crs="EPSG:4326")
bd_m = bd.to_crs(CRS)
print(f"面积(投影后) = {bd_m.area.iloc[0]/1e6:.2f} km²  [官方约 948 km²]")
print("bounds lonlat:", bd.total_bounds.round(4))

# --- 1km 网格 ---
minx, miny, maxx, maxy = bd_m.total_bounds
x0 = np.floor(minx / 1000) * 1000
y0 = np.floor(miny / 1000) * 1000
xs = np.arange(x0, maxx + 1000, 1000)
ys = np.arange(y0, maxy + 1000, 1000)
print(f"网格范围 {len(xs)-1} x {len(ys)-1}")

cells = []
for i in range(len(xs) - 1):
    for k in range(len(ys) - 1):
        cells.append(Polygon([(xs[i], ys[k]), (xs[i+1], ys[k]), (xs[i+1], ys[k+1]), (xs[i], ys[k+1])]))
grid = gpd.GeoDataFrame({'gid': np.arange(1, len(cells) + 1)}, geometry=cells, crs=CRS)
grid['cell_km2'] = 1.0
inter = gpd.overlay(grid, bd_m[['geometry']], how='intersection', keep_geom_type=True)
inter['frac'] = inter.area / 1e6   # km²
inter = inter[inter['frac'] > 0.01].copy()
inter['pop'] = np.nan
inter['pop_w'] = np.nan
print(f"落在区内的网格 {len(inter)} 个，面积合计 {inter['frac'].sum():.1f} km²")

# --- 人口 ---
tif = os.path.join(RAW, 'worldpop_chn_2020_1km.tif')
try:
    if os.path.exists(tif) and os.path.getsize(tif) >= 52_000_000:
        from osgeo import gdal
        gdal.UseExceptions()
        ds = gdal.Warp('', tif, format='MEM', dstSRS=CRS, resampleAlg='near',
                       outputBounds=(x0, y0, xs[-1], ys[-1]), xRes=1000, yRes=1000)
        arr = ds.ReadAsArray().astype('float64')
        print("warped array", arr.shape, "sum(全bbox)=", np.nansum(arr))
        vals = []
        for _, r in inter.iterrows():
            minx_, miny_, maxx_, maxy_ = r.geometry.bounds
            col = int((minx_ - x0) // 1000)
            row = int((ys[-1] - maxy_) // 1000)
            v = arr[row, col] if (0 <= row < arr.shape[0] and 0 <= col < arr.shape[1]) else np.nan
            vals.append(v)
        inter['pop'] = vals
        inter['pop_w'] = inter['pop'] * inter['frac']   # 按落在区内的面积比例折算
        inter.loc[inter['pop_w'] < 0, 'pop_w'] = 0
        print(f"区内人口合计 ≈ {np.nansum(inter['pop_w']):,.0f}  [平谷常住人口约 45.7 万]")
    else:
        print("!! WorldPop 尚未下载完成，pop 字段留空")
except Exception as e:
    print("!! 人口步骤失败：", type(e).__name__, e)

out = os.path.join(OUT, 'pinggu_boundary.gpkg')
if os.path.exists(out):
    os.remove(out)
bd_m.to_file(out, layer='boundary', driver='GPKG')
inter[['gid', 'frac', 'pop', 'pop_w', 'geometry']].to_file(out, layer='grid_1km', driver='GPKG')
print("写出", out)