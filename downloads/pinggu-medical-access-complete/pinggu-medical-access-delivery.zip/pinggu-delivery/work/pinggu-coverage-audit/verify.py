import csv
from pathlib import Path
from qgis.core import QgsApplication, QgsVectorLayer, QgsProject, QgsVariantUtils
from osgeo import ogr

root=Path('work/pinggu-coverage-audit').resolve()
log=Path('attachments/7f52cdac-22bf-4448-b5d0-5c3c00772212/已粘贴的文本.txt').read_text()
body=log[log.rindex('import os, datetime, csv'):log.rindex('(took 38.0s)')]
body=body.replace('os.path.join(os.path.expanduser("~"), "Desktop", "pinggu_delivery")','str(root)')
body=body.replace('    if d is None:', '    if QgsVariantUtils.isNull(d):')
body=body.replace('    c = cls_of(status, net)', '''    net, status, near_fac, dem_snap, fac_snap = (
        None if QgsVariantUtils.isNull(x) else x
        for x in (net, status, near_fac, dem_snap, fac_snap)
    )
    c = cls_of(status, net)''')
body=body.replace('    sel = [(p, d) for p, d, c in items if d is not None and d <= th]','    sel = [(p, d) for p, d, c in items if c != C5 and d is not None and d <= th]')
body=body.replace('# ================= 2.', '''if sa != sg or len(sa) != len(acc_gids) or len(sg) != len(grid_gids):
    raise ValueError('gid 不唯一或未一一对应')

# ================= 2.''',1)
before=body.index('with open(csv_path, "w"')
after=body.index('\nlayer =',before)
body=body[:before]+'''if res[0] != QgsVectorFileWriter.NoError:
    raise RuntimeError(res[1])
summary = QgsVectorLayer("None", "coverage_summary", "memory")
summary.dataProvider().addAttributes([QgsField(h, QVariant.String) for h in table[0]])
summary.updateFields()
features = []
for row in table[1:]:
    f = QgsFeature(summary.fields())
    f.setAttributes([str(cell) for cell in row])
    features.append(f)
ok, _ = summary.dataProvider().addFeatures(features)
assert ok
csv_opts = QgsVectorFileWriter.SaveVectorOptions()
csv_opts.driverName = "CSV"
csv_opts.fileEncoding = "UTF-8"
csv_opts.layerOptions = ["WRITE_BOM=YES"]
csv_res = QgsVectorFileWriter.writeAsVectorFormatV3(summary, csv_path,
        QgsProject.instance().transformContext(), csv_opts)
if csv_res[0] != QgsVectorFileWriter.NoError:
    raise RuntimeError(csv_res[1])
''' + body[after:]
app=QgsApplication([],False)
app.initQgis()
gfile=Path('work/pinggu-audit/pinggu_b_delivery_v0.gpkg').resolve()
afile=sorted(Path('work/pinggu-accessibility-audit').glob('accessibility_v0_*.gpkg'))[-1].resolve()
layers={'grid_1km':QgsVectorLayer(str(gfile)+'|layername=grid_1km','grid_1km','ogr'),
        'accessibility_v0':QgsVectorLayer(str(afile),'accessibility_v0','ogr')}
assert all(l.isValid() for l in layers.values())
scope=dict(get_layer=layers.__getitem__, root=root, QgsVariantUtils=QgsVariantUtils)
exec(compile(body,'<coverage script>', 'exec'),scope)
assert scope['layer'].featureCount()==1039
with open(scope['csv_path'],encoding='utf-8-sig',newline='') as fh:
    rows=list(csv.reader(fh))
assert len(rows)==7
assert rows[1][1:] == ['170','242762.4','53.12%']
assert rows[5][1:] == ['40','2738.5','0.60%']
assert scope['layer'].renderer().classAttribute() == 'dist_class'
print('Verified file, CSV and classified layer')
