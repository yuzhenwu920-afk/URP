from pathlib import Path
from statistics import median
from math import sqrt
from qgis.core import QgsApplication, QgsVectorLayer, QgsSpatialIndex, QgsGeometry, QgsRectangle

app = QgsApplication([], False)
app.initQgis()
path = str(Path('work/pinggu-audit/pinggu_b_delivery_v0.gpkg').resolve())
roads = QgsVectorLayer(path + '|layername=roads', 'roads', 'ogr')
grid = QgsVectorLayer(path + '|layername=grid_1km', 'grid', 'ogr')
facilities = QgsVectorLayer(path + '|layername=facilities_primary', 'facilities', 'ogr')
for layer in (roads,grid,facilities):
    assert layer.isValid() and layer.crs().authid() == 'EPSG:32650'
road_features = {f.id(): f for f in roads.getFeatures()}
bounds_index = QgsSpatialIndex(roads.getFeatures())
exact_index = QgsSpatialIndex(roads.getFeatures(), flags=QgsSpatialIndex.FlagStoreFeatureGeometries)
def nearest(p, ids):
    return min((sqrt(road_features[fid].geometry().closestSegmentWithContext(p)[0]), fid) for fid in ids)
def exact(p):
    seed_dist, seed_fid = nearest(p, bounds_index.nearestNeighbor(p, 1))
    d = seed_dist + 1e-7
    box = QgsRectangle(p.x() - d, p.y() - d, p.x() + d, p.y() + d)
    return nearest(p, bounds_index.intersects(box))

def check(name, items):
    rows = [(f, nearest(p.asPoint(), bounds_index.nearestNeighbor(p.asPoint(), 10)), exact(p.asPoint()), nearest(p.asPoint(), exact_index.nearestNeighbor(p.asPoint(), 1))) for f,p in items]
    print(name)
    for column in (1,2,3):
        dists = [r[column][0] for r in rows]
        print('index', column, 'count/median/ > 100 /max', len(dists), median(dists), sum(d>100 for d in dists), max(dists))
    changed = [r for r in rows if abs(r[1][0]-r[2][0]) > 1e-7]
    print('distance discrepancies',len(changed), 'max',max((r[1][0]-r[2][0] for r in changed),default=0))
    print('point overload discrepancy count',sum(abs(r[3][0] - r[2][0]) > 1e-7 for r in rows))
    if changed:
        print([(f['gid'] if name=='demand' else f['name'], old, true) for f,old,true,_ in sorted(changed,key=lambda r:r[1][0]-r[2][0],reverse=True)[:4]])
    for column in (1,2):
        excluded = [r for r in rows if road_features[r[column][1]]['is_largest'] != 1]
        print(column,'outside largest',len(excluded))
        if name=='demand':
            print(column,'population over 100', sum(r[0]['pop_cal'] for r in rows if r[column][0]>100))
            print(column,'outside largest pop',sum(r[0]['pop_cal'] for r in excluded))
    if name=='facilities':
        print('far facilities',[(r[0]['name'], round(r[2][0], 1)) for r in sorted(rows,key=lambda r:r[2][0],reverse=True)[:4]])
check('demand',((f,f.geometry().pointOnSurface()) for f in grid.getFeatures()))
check('facilities',((f,f.geometry()) for f in facilities.getFeatures() if f['in_bnd'] == 1))
