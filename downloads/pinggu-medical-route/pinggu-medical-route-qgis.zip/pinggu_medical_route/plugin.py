"""QGIS dock, map tool and temporary route overlays."""
from pathlib import Path

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QAction, QComboBox, QDockWidget, QFileDialog, QHBoxLayout, QHeaderView,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)
from qgis.core import (
    QgsCoordinateTransform, QgsFillSymbol, QgsGeometry, QgsLineSymbol, QgsMarkerSymbol,
    QgsProject, QgsRectangle, QgsSingleSymbolRenderer, QgsWkbTypes,
)
from qgis.gui import QgsMapToolEmitPoint, QgsRubberBand

from .network import Network, RoutingError


class PingguRoutePlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dock = None

    def initGui(self):
        self.action = QAction("平谷医疗最短路", self.iface.mainWindow())
        self.action.triggered.connect(self.open)
        self.iface.addPluginToMenu("平谷医疗最短路", self.action)
        self.iface.addToolBarIcon(self.action)

    def open(self):
        if self.dock is None:
            self.dock = RouteDock(self.iface)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
            filename = QgsProject.instance().fileName()
            if filename:
                path = Path(filename).parent / "pinggu_medical_access.gpkg"
                if path.is_file():
                    self.dock.load(path)
        self.dock.show()
        self.dock.raise_()

    def unload(self):
        if self.dock is not None:
            self.dock.release_map_tool()
            self.dock.remove_bands()
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
        if self.action is not None:
            self.iface.removePluginMenu("平谷医疗最短路", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action.deleteLater()
            self.action = None


class RouteDock(QDockWidget):
    def __init__(self, iface):
        super().__init__("平谷医疗最短路", iface.mainWindow())
        self.setObjectName("PingguMedicalRoute")
        self.canvas = iface.mapCanvas()
        self.project = QgsProject.instance()
        self.network = None
        self.origin = None
        self.routes = []
        self.previous_tool = None
        self.tool = QgsMapToolEmitPoint(self.canvas)
        self.tool.canvasClicked.connect(self.pick_origin)

        panel = QWidget(self)
        layout = QVBoxLayout(panel)
        self.setWidget(panel)
        self.data_label = QLabel("请选择交付包中的数据库。")
        self.data_label.setTextFormat(Qt.PlainText)
        self.data_label.setWordWrap(True)
        layout.addWidget(self.data_label)

        controls = QHBoxLayout()
        choose = QPushButton("选择数据库…")
        choose.clicked.connect(self.choose_database)
        controls.addWidget(choose)
        self.start = QPushButton("在地图选起点")
        self.start.setEnabled(False)
        self.start.clicked.connect(self.activate_map_tool)
        controls.addWidget(self.start)
        layout.addLayout(controls)

        limits = QHBoxLayout()
        limits.addWidget(QLabel("路线估算距离"))
        self.limit = QComboBox()
        self.limit.addItem("500 米以内", 500)
        self.limit.addItem("1 公里以内", 1000)
        self.limit.setCurrentIndex(1)
        self.limit.currentIndexChanged.connect(self.refresh)
        limits.addWidget(self.limit)
        layout.addLayout(limits)

        self.status = QLabel("加载数据库后，在地图上单击出发位置。")
        self.status.setTextFormat(Qt.PlainText)
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["基层医疗设施", "估算总距离", "路网段"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for column in (1, 2):
            self.table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.currentCellChanged.connect(self.draw_selection)
        layout.addWidget(self.table)

        action_row = QHBoxLayout()
        self.zoom = QPushButton("缩放到路线")
        self.zoom.setEnabled(False)
        self.zoom.clicked.connect(self.zoom_to_route)
        action_row.addWidget(self.zoom)
        clear = QPushButton("清除结果")
        clear.clicked.connect(self.clear)
        action_row.addWidget(clear)
        layout.addLayout(action_row)

        note = QLabel("蓝色实线为道路，橙色虚线为两端直线接入估算。"
                      "范围按两者合计筛选。路网按双向研究口径试算，"
                      "请核实入口、通行和机构状态。")
        note.setWordWrap(True)
        layout.addWidget(note)
        self.setMinimumWidth(360)
        self.bands = [
            self.band(QgsWkbTypes.LineGeometry, "#1b61ae", 5),
            self.band(QgsWkbTypes.LineGeometry, "#c46638", 3, Qt.DashLine),
            self.band(QgsWkbTypes.PointGeometry, "#14826d", 9),
            self.band(QgsWkbTypes.PointGeometry, "#b84348", 10),
        ]

    def band(self, geometry_type, color, width, style=Qt.SolidLine):
        band = QgsRubberBand(self.canvas, geometry_type)
        band.setColor(QColor(color))
        band.setWidth(width)
        band.setLineStyle(style)
        return band

    def reset_bands(self):
        for band, kind in zip(self.bands, (QgsWkbTypes.LineGeometry, QgsWkbTypes.LineGeometry,
                                           QgsWkbTypes.PointGeometry, QgsWkbTypes.PointGeometry)):
            band.reset(kind)

    def remove_bands(self):
        for band in self.bands:
            self.canvas.scene().removeItem(band)
        self.bands = []

    def closeEvent(self, event):
        self.release_map_tool()
        self.reset_bands()
        super().closeEvent(event)

    def showEvent(self, event):
        super().showEvent(event)
        self.draw_selection(self.table.currentRow())

    def choose_database(self):
        directory = self.network.path if self.network else str(Path.home())
        path, _ = QFileDialog.getOpenFileName(
            self, "选择 pinggu_medical_access.gpkg", directory, "GeoPackage (*.gpkg)"
        )
        if path:
            self.load(path)

    def load(self, path):
        try:
            network = Network(path)
        except RoutingError as exc:
            self.status.setText(str(exc))
            return
        self.release_map_tool()
        self.clear()
        self.network = network
        self.start.setEnabled(True)
        self.data_label.setText(f"{Path(path).name} · {len(network.facilities)} 个区内基层医疗设施")
        self.status.setText("点击「在地图选起点」，在平谷区内单击。")
        if not self.canvas.layers():
            self.add_reference_layers()

    def add_reference_layers(self):
        self.project.setCrs(self.network.crs)
        self.canvas.setDestinationCrs(self.network.crs)
        district = self.network.layer("district_boundary", "平谷区界")
        district.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
            "color":"#f3f7f9", "outline_color":"#738ca1", "outline_width":"0.25",
        })))
        roads = self.network.layer("roads_osm", "道路")
        roads.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple({
            "line_color":"#8799a7", "line_width":"0.13",
        })))
        clinics = self.network.layer("facilities_primary", "基层医疗设施")
        clinics.setSubsetString('"in_bnd"=1')
        clinics.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
            "color":"#15395a", "outline_color":"#ffffff", "size":"2",
        })))
        for layer in (district, roads, clinics):
            self.project.addMapLayer(layer)
        extent = QgsRectangle(district.extent())
        extent.scale(1.12)
        self.canvas.setExtent(extent)
        self.canvas.refresh()

    def activate_map_tool(self):
        if self.canvas.mapTool() != self.tool:
            self.previous_tool = self.canvas.mapTool()
            self.canvas.setMapTool(self.tool)
        self.status.setText("请在地图上左键单击出发位置。右键取消。")

    def release_map_tool(self):
        if self.canvas.mapTool() == self.tool:
            if self.previous_tool is not None:
                self.canvas.setMapTool(self.previous_tool)
            else:
                self.canvas.unsetMapTool(self.tool)
        self.previous_tool = None

    def pick_origin(self, pos, button):
        self.release_map_tool()
        if button != Qt.LeftButton:
            self.status.setText("已取消选点。")
            return
        transform = QgsCoordinateTransform(self.canvas.mapSettings().destinationCrs(),
                                           self.network.crs, self.project)
        self.origin = transform.transform(pos)
        self.refresh()

    def clear(self):
        self.origin = None
        self.routes = []
        self.table.setRowCount(0)
        self.zoom.setEnabled(False)
        self.reset_bands()
        if self.network is not None:
            self.status.setText("点击「在地图选起点」，继续查找。")

    def refresh(self, *_):
        if self.origin is None:
            return
        self.routes = []
        self.table.setRowCount(0)
        self.reset_bands()
        self.zoom.setEnabled(False)
        n = self.limit.currentData()
        try:
            result = self.network.search(self.origin, n)
        except RoutingError as exc:
            self.status.setText(str(exc))
            return

        self.routes = list(result.routes)
        if self.routes:
            prefix = "显示最近的 " if len(self.routes) == 3 else "找到 "
            self.status.setText(f"{n:,} 米以内，{prefix}{len(self.routes)} 个可达设施。")
        elif result.nearest_outside:
            self.routes = [result.nearest_outside]
            self.status.setText(f"{n:,} 米以内无可达设施。下方显示超出范围的最近设施。")
        else:
            self.status.setText("在当前研究路网中找不到通往设施的路径。")
            self.bands[2].setToGeometry(QgsGeometry.fromPointXY(self.origin), self.network.crs)
            return

        self.table.setRowCount(len(self.routes))
        for row, route in enumerate(self.routes):
            shown_distance = self.format_metres(route.distance)
            if not result.routes:
                shown_distance += " · 超范围"
            connector = route.connector_distance
            columns = [f"{route.facility.name}\n{route.facility.category}",
                       shown_distance,
                       self.format_metres(route.road_distance)]
            for col, value in enumerate(columns):
                item = QTableWidgetItem(value)
                item.setToolTip(f"两端直线接入约 {connector:.0f} 米")
                self.table.setItem(row, col, item)
        self.table.resizeRowsToContents()
        self.table.setCurrentCell(0, 0)
        self.draw_selection(0)
        self.zoom_to_route()

    @staticmethod
    def format_metres(distance):
        return f"{distance:.0f} m" if distance < 1000 else f"{distance / 1000:.2f} km"

    def draw_selection(self, row, *_):
        if not self.bands or row < 0 or row >= len(self.routes):
            return
        self.reset_bands()
        route = self.routes[row]
        crs = self.network.crs
        geometry = self.network.route_geometry(route)
        if not geometry.isEmpty():
            self.bands[0].setToGeometry(geometry, crs)
        if route.connector_distance > 0.001:
            pairs = [[a,b] for a,b in ((route.origin, route.access.point),
                                      (route.facility.access.point, route.facility.point))
                     if a.distance(b) > 0.001]
            self.bands[1].setToGeometry(QgsGeometry.fromMultiPolylineXY(pairs), crs)
        self.bands[2].setToGeometry(QgsGeometry.fromPointXY(route.origin), crs)
        self.bands[3].setToGeometry(QgsGeometry.fromPointXY(route.facility.point), crs)
        self.zoom.setEnabled(True)

    def zoom_to_route(self):
        row = self.table.currentRow()
        if not 0 <= row < len(self.routes):
            return
        route = self.routes[row]
        extent = QgsRectangle(route.origin, route.facility.point)
        geometry = self.network.route_geometry(route)
        if not geometry.isEmpty():
            extent.combineExtentWith(geometry.boundingBox())
        extent.grow(max(80, extent.width() * 0.08, extent.height() * 0.08))
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        transform = QgsCoordinateTransform(self.network.crs, canvas_crs, self.project)
        self.canvas.setExtent(transform.transformBoundingBox(extent))
        self.canvas.refresh()
