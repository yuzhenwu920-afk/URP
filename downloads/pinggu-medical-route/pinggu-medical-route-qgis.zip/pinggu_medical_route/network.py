"""Shortest-distance routing on the segmented Pinggu research road network."""
from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass
from heapq import heappop, heappush
from pathlib import Path

from qgis.core import (
    QgsFeature, QgsGeometry, QgsPointXY, QgsRectangle, QgsSpatialIndex, QgsVectorLayer, QgsWkbTypes,
)


@dataclass(frozen=True)
class Access:
    road: int
    position: float
    point: QgsPointXY
    gap: float


@dataclass(frozen=True)
class Facility:
    fid: int
    name: str
    category: str
    point: QgsPointXY
    access: Access


@dataclass(frozen=True)
class Route:
    facility: Facility
    road_distance: float
    origin: QgsPointXY
    access: Access
    parts: tuple

    @property
    def connector_distance(self):
        if self.origin.distance(self.facility.point) < 0.001:
            return 0.0
        return self.access.gap + self.facility.access.gap

    @property
    def distance(self):
        return self.road_distance + self.connector_distance


@dataclass(frozen=True)
class Search:
    routes: tuple
    nearest_outside: Route | None
    origin_access: Access


class RoutingError(ValueError):
    """An input or data limitation that can be reported to the user."""


class Network:
    def __init__(self, path):
        self.path = str(Path(path).resolve())
        roads = self.layer("roads_osm")
        facilities = self.layer("facilities_primary")
        boundary = self.layer("district_boundary")
        self.crs = roads.crs()
        if self.crs.authid() != "EPSG:32650" or any(
            layer.crs() != self.crs for layer in (facilities, boundary)
        ):
            raise RoutingError("数据库路网、设施和区界应使用 EPSG:32650。")
        if not {"in_bnd","name","level_cn"}.issubset(facilities.fields().names()):
            raise RoutingError("基层医疗图层缺少范围、名称或类别字段。")
        self.boundary = QgsGeometry.unaryUnion([feature.geometry() for feature in boundary.getFeatures()])
        if self.boundary.isEmpty():
            raise RoutingError("数据库中的平谷区界为空。")
        self.index = QgsSpatialIndex(QgsSpatialIndex.FlagStoreFeatureGeometries)
        self.geometries = {}
        self.lengths = {}
        for feature in roads.getFeatures():
            geom = feature.geometry()
            if geom.isEmpty():
                continue
            if QgsWkbTypes.flatType(geom.wkbType()) != QgsWkbTypes.LineString:
                raise RoutingError("路网应为已分段的单部件线。")
            length = geom.length()
            if length <= 0:
                continue
            fid = feature.id()
            self.lengths[fid] = length
            self.geometries[fid] = geom
            indexed = QgsFeature(fid)
            indexed.setGeometry(geom)
            self.index.addFeature(indexed)
        if not self.geometries:
            raise RoutingError("数据库没有可用道路。")

        self.edges = defaultdict(list)
        self.stops = {}
        self.facilities = {}
        attachments = defaultdict(list)
        for record in facilities.getFeatures():
            if record["in_bnd"] != 1 or record.geometry().isEmpty():
                continue
            if QgsWkbTypes.flatType(record.geometry().wkbType()) != QgsWkbTypes.Point:
                raise RoutingError("基层医疗设施应为点图层。")
            fid = record.id()
            name = str(record["name"] or "").strip()
            if name in ("", "NULL"):
                name = f"基层医疗点 {fid}"
            poi = record.geometry().asPoint()
            snap = self.snap(poi)
            facility = Facility(fid, name, str(record["level_cn"]), poi, snap)
            self.facilities[fid] = facility
            attachments[snap.road].append((snap.position, ("poi", fid)))
        if not self.facilities:
            raise RoutingError("数据库没有区内基层医疗设施。")
        for road, geometry in self.geometries.items():
            curve = geometry.constGet()
            stops = [
                (0.0, self._junction(curve.startPoint())),
                *sorted(attachments[road]),
                (self.lengths[road], self._junction(curve.endPoint())),
            ]
            self.stops[road] = (tuple(d for d, _ in stops), tuple(n for _, n in stops))
            for (left, u), (right, v) in zip(stops, stops[1:]):
                self.edges[u].append((v, right - left, (road, left, right)))
                self.edges[v].append((u, right - left, (road, right, left)))
        self.facilities_at_node = {("poi", key): value for key, value in self.facilities.items()}

    def layer(self, layer_name, title=None):
        layer = QgsVectorLayer(f"{self.path}|layername={layer_name}", title or layer_name, "ogr")
        if not layer.isValid():
            raise RoutingError(f"数据库缺少有效图层：{layer_name}")
        return layer

    @staticmethod
    def _junction(point):
        # Match the millimetre-rounded junctions used in the original study.
        return ("end", round(point.x(), 3), round(point.y(), 3))

    def snap(self, point):
        ids = self.index.nearestNeighbor(point, 1)
        if not ids:
            raise RoutingError("找不到可连接的道路。")
        def closest(road_ids):
            candidates = ((self.geometries[fid].closestSegmentWithContext(point), fid)
                          for fid in road_ids)
            return min(candidates, key=lambda item: (item[0][0], item[1]))

        provisional, _ = closest(ids)
        radius = provisional[0] ** 0.5 + 1e-6
        x, y = point.x(), point.y()
        nearby = self.index.intersects(QgsRectangle(x - radius, y - radius, x + radius, y + radius))
        result, fid = closest(nearby)
        _, projected, _, _ = result
        geometry = self.geometries[fid]
        position = geometry.lineLocatePoint(QgsGeometry.fromPointXY(projected))
        if position < 0:
            raise RoutingError("无法把点定位到最近路段。")
        return Access(fid, min(position, self.lengths[fid]), projected, point.distance(projected))

    def search(self, origin, limit, count=3):
        if limit <= 0 or count < 1:
            raise RoutingError("距离阈值或结果数量无效。")
        if not self.boundary.intersects(QgsGeometry.fromPointXY(origin)):
            raise RoutingError("请选择平谷区研究边界内的起点。")
        access = self.snap(origin)
        at_location = [f for f in self.facilities.values() if origin.distance(f.point) < 0.001]
        if access.gap > 200 and at_location:
            route = Route(at_location[0], 0.0, origin, access, ())
            return Search((route,), None, access)
        if access.gap > 200:
            raise RoutingError(f"起点离最近路段约 {access.gap:.0f} 米，超过试算接入上限（200 米）。"
                               "请在附近实际可通行的道路入口重新选点。")
        positions, nodes = self.stops[access.road]
        index = bisect_right(positions, access.position)
        distances, previous, heap = {}, {}, []
        for i in {max(0, index - 1), min(index, len(nodes) - 1)}:
            node = nodes[i]
            cost = abs(positions[i] - access.position)
            if cost < distances.get(node, float("inf")):
                distances[node] = cost
                previous[node] = (None, (access.road, access.position, positions[i]))
                heappush(heap, (cost, node))

        direct_routes = [Route(f, 0.0, origin, access, ()) for f in at_location]
        direct_ids = {r.facility.fid for r in direct_routes}
        if len(direct_routes) >= count:
            return Search(tuple(direct_routes[:count]), None, access)
        remaining = count - len(direct_routes)
        ranked = []
        while heap:
            cost, u = heappop(heap)
            if cost != distances[u]:
                continue
            if len(ranked) >= remaining and cost + access.gap > ranked[remaining - 1][0]:
                break
            facility = self.facilities_at_node.get(u)
            if facility is not None and facility.fid not in direct_ids:
                ranked.append((cost + access.gap + facility.access.gap, facility.fid, u, cost))
                ranked.sort()
            for v, distance, part in self.edges[u]:
                next_cost = cost + distance
                if next_cost < distances.get(v, float("inf")):
                    distances[v] = next_cost
                    previous[v] = (u, part)
                    heappush(heap, (next_cost, v))

        def route(entry):
            _, fid, node, cost = entry
            parts = []
            while node is not None:
                node, part = previous[node]
                if abs(part[1] - part[2]) > 1e-7:
                    parts.append(part)
            return Route(self.facilities[fid], cost, origin, access, tuple(reversed(parts)))

        inside = tuple(direct_routes + [route(entry) for entry in ranked[:remaining] if entry[0] <= limit + 1e-8])
        outside = route(ranked[0]) if not inside and ranked else None
        return Search(inside, outside, access)

    def route_geometry(self, route):
        """Return the travelled portions of the centerlines, with all intermediate vertices."""
        lines = []
        for road, start, end in route.parts:
            line = self.geometries[road].constGet().curveSubstring(min(start, end), max(start, end))
            if start > end:
                line = line.reversed()
            lines.append([QgsPointXY(point) for point in line.vertices()])
        return QgsGeometry.fromMultiPolylineXY(lines) if lines else QgsGeometry()
