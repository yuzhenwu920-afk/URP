def classFactory(iface):
    from .plugin import PingguRoutePlugin
    return PingguRoutePlugin(iface)
