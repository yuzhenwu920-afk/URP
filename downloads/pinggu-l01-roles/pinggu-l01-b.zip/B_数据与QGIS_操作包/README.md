# B 同学 · 数据与QGIS

先打开 `B_数据与QGIS_操作手册.docx`，按上面顺序操作。先填数据，再按 Word 跑 QGIS。可先用 data/demo 原样测试。

包内模拟数据为 demo-v1，正式数据按小组审核版替换。相同版本下，各分包的 web 文件一致。

配套目录：`code/`、`data/`、`docs/`、`templates/`、`web/`。
