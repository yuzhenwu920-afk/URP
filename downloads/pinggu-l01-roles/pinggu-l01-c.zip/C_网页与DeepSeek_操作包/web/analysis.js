"use strict";

window.PingguAnalysis = (() => {
  const EPS = 1e-9;

  function fit(points) {
    if (points.length < 2) return null;
    const n = points.length;
    const xMean = points.reduce((sum, point) => sum + point.x, 0) / n;
    const yMean = points.reduce((sum, point) => sum + point.y, 0) / n;
    const xx = points.reduce((sum, point) => sum + (point.x - xMean) ** 2, 0);
    if (xx <= EPS) return null;
    const xy = points.reduce((sum, point) => sum + (point.x - xMean) * (point.y - yMean), 0);
    const slope = xy / xx;
    const intercept = yMean - slope * xMean;
    const total = points.reduce((sum, point) => sum + (point.y - yMean) ** 2, 0);
    const residual = points.reduce((sum, point) => sum + (point.y - intercept - slope * point.x) ** 2, 0);
    if (![slope, intercept, total, residual].every(Number.isFinite)) return null;
    return {slope, intercept, n, r2: total <= EPS ? null : 1 - residual / total,
      min: Math.min(...points.map(point => point.x)), max: Math.max(...points.map(point => point.x))};
  }

  function crossing(a, b) {
    const slopeDifference = a.slope - b.slope;
    if (Math.abs(slopeDifference) <= EPS) {
      return {kind: Math.abs(a.intercept - b.intercept) <= EPS ? "coincident" : "parallel"};
    }
    const x = (b.intercept - a.intercept) / slopeDifference;
    const y = a.intercept + a.slope * x;
    const inRange = x >= Math.max(0, a.min, b.min) - EPS && x <= Math.min(a.max, b.max) + EPS;
    return {kind: "point", x, y, inRange};
  }

  function envelope(lines) {
    if (lines.length < 2) return [];
    const start = Math.max(0, ...lines.map(line => line.min));
    const end = Math.min(...lines.map(line => line.max));
    if (end - start <= EPS) return [];
    const breaks = [start, end];
    lines.forEach((line, i) => lines.slice(i + 1).forEach(other => {
      const point = crossing(line, other);
      if (point.kind === "point" && point.x > start + EPS && point.x < end - EPS) breaks.push(point.x);
    }));
    breaks.sort((a, b) => a - b);
    const intervals = [];
    for (let index = 1; index < breaks.length; index += 1) {
      const from = breaks[index - 1];
      const to = breaks[index];
      if (to - from <= EPS) continue;
      const midpoint = (from + to) / 2;
      const values = lines.map(line => line.intercept + line.slope * midpoint);
      const max = Math.max(...values);
      const winners = lines.filter((_, i) => Math.abs(values[i] - max) <= EPS)
        .map(line => line.label).join(" / ");
      const previous = intervals[intervals.length - 1];
      if (previous && previous.winners === winners) previous.to = to;
      else intervals.push({from, to, winners});
    }
    return intervals;
  }

  return {fit, crossing, envelope};
})();
