// B 完成实测数据验收后，由 build_qgis.py 生成替换。
