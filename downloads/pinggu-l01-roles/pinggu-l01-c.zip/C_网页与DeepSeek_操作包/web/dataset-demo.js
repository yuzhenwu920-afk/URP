window.PINGGU_DATASETS["demo"] = {
  "version": "demo-v1",
  "kind": "demo",
  "year": "2025",
  "crs": "EPSG:4548",
  "snap_limit_m": 150,
  "qgis_version": "3.40.6-Bratislava",
  "markets": [
    {
      "id": "dahuashan",
      "label": "大华山市场（模拟位置）",
      "lon": "116.917805452",
      "lat": "40.184333508",
      "source": "模拟"
    },
    {
      "id": "newtown",
      "label": "平谷新城（模拟位置）",
      "lon": "117.129179852",
      "lat": "40.193296517",
      "source": "模拟"
    }
  ],
  "crops": {
    "peach": "大桃",
    "grain": "粮食",
    "berry": "草莓",
    "nut": "干果"
  },
  "rows": [
    {
      "id": "peach-05",
      "town": "模拟样点 05",
      "crop": "peach",
      "source": "模拟规则生成",
      "net_yuan_mu": 950.0,
      "lon": 116.976515833,
      "lat": 40.184360304,
      "distances": {
        "dahuashan": {
          "straight_km": 5.0,
          "road_km": 7.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 13.0384,
          "road_km": 14.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "peach-10",
      "town": "模拟样点 10",
      "crop": "peach",
      "source": "模拟规则生成",
      "net_yuan_mu": 700.0,
      "lon": 117.035226249,
      "lat": 40.184357326,
      "distances": {
        "dahuashan": {
          "straight_km": 10.0,
          "road_km": 12.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 8.0623,
          "road_km": 9.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "peach-15",
      "town": "模拟样点 15",
      "crop": "peach",
      "source": "模拟规则生成",
      "net_yuan_mu": 450.0,
      "lon": 117.093936612,
      "lat": 40.184324576,
      "distances": {
        "dahuashan": {
          "straight_km": 15.0,
          "road_km": 17.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 3.1623,
          "road_km": 4.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "peach-20",
      "town": "模拟样点 20",
      "crop": "peach",
      "source": "模拟规则生成",
      "net_yuan_mu": 200.0,
      "lon": 117.152646836,
      "lat": 40.184262054,
      "distances": {
        "dahuashan": {
          "straight_km": 20.0,
          "road_km": 22.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 2.2361,
          "road_km": 3.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "peach-25",
      "town": "模拟样点 25",
      "crop": "peach",
      "source": "模拟规则生成",
      "net_yuan_mu": -50.0,
      "lon": 117.211356832,
      "lat": 40.18416976,
      "distances": {
        "dahuashan": {
          "straight_km": 25.0,
          "road_km": 27.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 7.0711,
          "road_km": 8.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "grain-05",
      "town": "模拟样点 05",
      "crop": "grain",
      "source": "模拟规则生成",
      "net_yuan_mu": 550.0,
      "lon": 116.976515833,
      "lat": 40.184360304,
      "distances": {
        "dahuashan": {
          "straight_km": 5.0,
          "road_km": 7.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 13.0384,
          "road_km": 14.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "grain-10",
      "town": "模拟样点 10",
      "crop": "grain",
      "source": "模拟规则生成",
      "net_yuan_mu": 500.0,
      "lon": 117.035226249,
      "lat": 40.184357326,
      "distances": {
        "dahuashan": {
          "straight_km": 10.0,
          "road_km": 12.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 8.0623,
          "road_km": 9.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "grain-15",
      "town": "模拟样点 15",
      "crop": "grain",
      "source": "模拟规则生成",
      "net_yuan_mu": 450.0,
      "lon": 117.093936612,
      "lat": 40.184324576,
      "distances": {
        "dahuashan": {
          "straight_km": 15.0,
          "road_km": 17.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 3.1623,
          "road_km": 4.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "grain-20",
      "town": "模拟样点 20",
      "crop": "grain",
      "source": "模拟规则生成",
      "net_yuan_mu": 400.0,
      "lon": 117.152646836,
      "lat": 40.184262054,
      "distances": {
        "dahuashan": {
          "straight_km": 20.0,
          "road_km": 22.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 2.2361,
          "road_km": 3.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "grain-25",
      "town": "模拟样点 25",
      "crop": "grain",
      "source": "模拟规则生成",
      "net_yuan_mu": 350.0,
      "lon": 117.211356832,
      "lat": 40.18416976,
      "distances": {
        "dahuashan": {
          "straight_km": 25.0,
          "road_km": 27.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 7.0711,
          "road_km": 8.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "berry-05",
      "town": "模拟样点 05",
      "crop": "berry",
      "source": "模拟规则生成",
      "net_yuan_mu": 975.0,
      "lon": 116.976515833,
      "lat": 40.184360304,
      "distances": {
        "dahuashan": {
          "straight_km": 5.0,
          "road_km": 7.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 13.0384,
          "road_km": 14.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "berry-10",
      "town": "模拟样点 10",
      "crop": "berry",
      "source": "模拟规则生成",
      "net_yuan_mu": 450.0,
      "lon": 117.035226249,
      "lat": 40.184357326,
      "distances": {
        "dahuashan": {
          "straight_km": 10.0,
          "road_km": 12.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 8.0623,
          "road_km": 9.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "berry-15",
      "town": "模拟样点 15",
      "crop": "berry",
      "source": "模拟规则生成",
      "net_yuan_mu": -75.0,
      "lon": 117.093936612,
      "lat": 40.184324576,
      "distances": {
        "dahuashan": {
          "straight_km": 15.0,
          "road_km": 17.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 3.1623,
          "road_km": 4.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "berry-20",
      "town": "模拟样点 20",
      "crop": "berry",
      "source": "模拟规则生成",
      "net_yuan_mu": -600.0,
      "lon": 117.152646836,
      "lat": 40.184262054,
      "distances": {
        "dahuashan": {
          "straight_km": 20.0,
          "road_km": 22.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 2.2361,
          "road_km": 3.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "berry-25",
      "town": "模拟样点 25",
      "crop": "berry",
      "source": "模拟规则生成",
      "net_yuan_mu": -1125.0,
      "lon": 117.211356832,
      "lat": 40.18416976,
      "distances": {
        "dahuashan": {
          "straight_km": 25.0,
          "road_km": 27.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 7.0711,
          "road_km": 8.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "nut-05",
      "town": "模拟样点 05",
      "crop": "nut",
      "source": "模拟规则生成",
      "net_yuan_mu": 660.0,
      "lon": 116.976515833,
      "lat": 40.184360304,
      "distances": {
        "dahuashan": {
          "straight_km": 5.0,
          "road_km": 7.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 13.0384,
          "road_km": 14.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "nut-10",
      "town": "模拟样点 10",
      "crop": "nut",
      "source": "模拟规则生成",
      "net_yuan_mu": 560.0,
      "lon": 117.035226249,
      "lat": 40.184357326,
      "distances": {
        "dahuashan": {
          "straight_km": 10.0,
          "road_km": 12.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 8.0623,
          "road_km": 9.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "nut-15",
      "town": "模拟样点 15",
      "crop": "nut",
      "source": "模拟规则生成",
      "net_yuan_mu": 460.0,
      "lon": 117.093936612,
      "lat": 40.184324576,
      "distances": {
        "dahuashan": {
          "straight_km": 15.0,
          "road_km": 17.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 3.1623,
          "road_km": 4.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "nut-20",
      "town": "模拟样点 20",
      "crop": "nut",
      "source": "模拟规则生成",
      "net_yuan_mu": 360.0,
      "lon": 117.152646836,
      "lat": 40.184262054,
      "distances": {
        "dahuashan": {
          "straight_km": 20.0,
          "road_km": 22.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 2.2361,
          "road_km": 3.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "nut-25",
      "town": "模拟样点 25",
      "crop": "nut",
      "source": "模拟规则生成",
      "net_yuan_mu": 260.0,
      "lon": 117.211356832,
      "lat": 40.18416976,
      "distances": {
        "dahuashan": {
          "straight_km": 25.0,
          "road_km": 27.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 7.0711,
          "road_km": 8.0,
          "status": "可达"
        }
      }
    },
    {
      "id": "DEMO-X",
      "town": "模拟样点 12",
      "crop": "peach",
      "source": "模拟异常练习",
      "net_yuan_mu": 1200.0,
      "lon": 117.058710405,
      "lat": 40.184347799,
      "distances": {
        "dahuashan": {
          "straight_km": 12.0,
          "road_km": 14.0,
          "status": "可达"
        },
        "newtown": {
          "straight_km": 6.0828,
          "road_km": 7.0,
          "status": "可达"
        }
      }
    }
  ]
};
