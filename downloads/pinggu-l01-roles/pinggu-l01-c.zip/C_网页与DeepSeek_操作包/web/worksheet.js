"use strict";

const sources = window.PINGGU_DATASETS;
const select = document.getElementById("worksheet-dataset");
for (const [key, value] of Object.entries(sources)) {
  select.add(new Option(value.version, key));
}
const requestedDataset = new URLSearchParams(location.search).get("dataset");
if (requestedDataset && Object.hasOwn(sources, requestedDataset)) select.value = requestedDataset;

function showWorksheet() {
  const data = sources[select.value];
  document.getElementById("lab-link").href = "L01.html?dataset=" + encodeURIComponent(select.value);
  document.getElementById("worksheet-version").textContent =
    (data.kind === "demo" ? "模拟数据" : "实测数据") + " ｜ " + data.version + " ｜ " + data.year;
  const body = document.getElementById("worksheet-rows");
  body.replaceChildren();
  const examples = ["peach", "grain"].flatMap(crop => data.rows.filter(row => row.crop === crop).slice(0, 3));
  for (const row of examples) {
    const line = body.insertRow();
    const distance = row.distances.dahuashan;
    for (const value of [row.id, data.crops[row.crop], distance.straight_km, distance.road_km,
                        row.net_yuan_mu]) {
      line.insertCell().textContent = value ?? "—";
    }
  }
}

select.addEventListener("change", showWorksheet);
document.getElementById("print").addEventListener("click", () => window.print());
showWorksheet();
