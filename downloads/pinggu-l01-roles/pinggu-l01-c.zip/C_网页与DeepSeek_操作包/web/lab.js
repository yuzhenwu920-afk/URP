"use strict";

const $ = id => document.getElementById(id);
const datasets = window.PINGGU_DATASETS;
const {fit, crossing, envelope} = window.PingguAnalysis;
const colors = {peach: "#a54332", grain: "#315f49", berry: "#884776", nut: "#6a522e"};
const excluded = new Set();
const edits = new Map();
const format = (number, digits = 2) => Number.isFinite(number) ? number.toFixed(digits) : "—";

function options(select, entries) {
  select.replaceChildren(...entries.map(([value, label]) => new Option(label, value)));
}

function addRow(body, cells) {
  const row = body.insertRow();
  for (const value of cells) {
    const cell = row.insertCell();
    if (value instanceof Node) cell.append(value);
    else cell.textContent = value;
  }
}

function draw(series) {
  const canvas = $("plot");
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  const density = window.devicePixelRatio || 1;
  canvas.width = width * density;
  canvas.height = height * density;
  const ctx = canvas.getContext("2d");
  ctx.scale(density, density);
  const points = series.flatMap(group => group.all);
  if (!points.length) {
    ctx.fillStyle = "#506058";
    ctx.font = "14px system-ui";
    ctx.fillText("当前条件下没有可绘制的样本。", 12, 30);
    return;
  }
  const left = 65, right = width - 16, top = 28, bottom = height - 42;
  const xMax = Math.max(1, ...points.map(point => point.x)) * 1.04;
  const fittedEnds = series.flatMap(({line}) => line ?
    [line.intercept + line.slope * line.min, line.intercept + line.slope * line.max] : []);
  const values = points.map(point => point.y).concat(fittedEnds, 0);
  const low = Math.min(...values), high = Math.max(...values);
  const span = Math.max(1, high - low);
  const yMin = low - span * .06, yMax = high + span * .06;
  const xTo = val => left + val / xMax * (right - left);
  const yTo = val => bottom - (val - yMin) / (yMax - yMin) * (bottom - top);
  ctx.font = "12px system-ui";
  ctx.fillStyle = "#506058";
  ctx.fillText("元/亩", 8, 16);
  ctx.fillText("公里", right - 24, height - 5);
  for (let index = 0; index <= 4; index += 1) {
    const value = yMin + (yMax - yMin) * index / 4;
    const y = yTo(value);
    ctx.strokeStyle = "#e1e4dd";
    ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(right, y); ctx.stroke();
    ctx.textAlign = "right";
    ctx.fillText(format(value, 0), left - 7, y + 4);
    const distance = xMax * index / 4;
    ctx.textAlign = index === 4 ? "right" : "center";
    ctx.fillText(format(distance, 1), xTo(distance), bottom + 18);
  }
  for (const {crop, all, line} of series) {
    ctx.strokeStyle = colors[crop];
    ctx.fillStyle = colors[crop];
    if (line) {
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(xTo(line.min), yTo(line.intercept + line.slope * line.min));
      ctx.lineTo(xTo(line.max), yTo(line.intercept + line.slope * line.max));
      ctx.stroke();
    }
    all.forEach(point => {
      ctx.beginPath();
      ctx.arc(xTo(point.x), yTo(point.y), 4, 0, 2 * Math.PI);
      if (excluded.has(point.id)) ctx.stroke();
      else ctx.fill();
    });
  }
}

function refresh(rebuildSamples) {
  const data = datasets[$("dataset").value];
  const market = $("market").value;
  const metric = $("metric").value;
  const cropIds = $("crop-mode").value === "core" ? ["peach", "grain"] : Object.keys(data.crops);
  const activeRows = data.rows.filter(row => cropIds.includes(row.crop));
  const missing = activeRows.filter(row => !Number.isFinite(row.distances[market][metric])).length;
  $("provenance").textContent = (data.kind === "demo" ? "模拟数据 · 地点、路网与收益均为教学样例" :
    "实测数据 · 请核对来源记录") + " ｜ " + data.version + " ｜ " + data.year +
    " ｜ 距离缺失 " + missing + " 条";
  const series = cropIds.map(crop => {
    const all = activeRows.filter(row => row.crop === crop && Number.isFinite(row.distances[market][metric]))
      .map(row => ({id: row.id, x: row.distances[market][metric],
        y: edits.get(row.id) ?? row.net_yuan_mu}));
    return {crop, all, full: fit(all), line: fit(all.filter(point => !excluded.has(point.id)))};
  });

  $("legend").replaceChildren(...cropIds.map(crop => {
    const item = document.createElement("span");
    const mark = document.createElement("i");
    mark.style.background = colors[crop];
    item.append(mark, data.crops[crop]);
    return item;
  }));
  const fitTable = $("fits");
  fitTable.replaceChildren();
  for (const {crop, all, line, full} of series) {
    const used = all.filter(point => !excluded.has(point.id)).length;
    addRow(fitTable, [data.crops[crop], used + " / " + all.length, format(line?.intercept),
      format(line?.slope), format(line?.r2, 3), format(full?.r2, 3)]);
  }

  const peach = series.find(group => group.crop === "peach")?.line;
  const grain = series.find(group => group.crop === "grain")?.line;
  let crossingText = "样本不足或距离没有变化，暂时无法计算大桃与粮食交点。";
  if (peach && grain) {
    const result = crossing(peach, grain);
    if (result.kind === "coincident") crossingText = "大桃和粮食拟合线重合，无唯一分界。";
    if (result.kind === "parallel") crossingText = "大桃和粮食拟合线平行，无交点。";
    if (result.kind === "point") {
      crossingText = "大桃与粮食交点：" + format(result.x) + " 公里，" + format(result.y) +
        " 元/亩。" + (result.inRange ? "" : " 超出共同观测范围，属于外推。");
    }
  }
  $("intersection").textContent = crossingText;
  const lines = series.filter(group => group.line).map(group => ({...group.line, label: data.crops[group.crop]}));
  const bands = envelope(lines);
  $("intervals").textContent = bands.length ? "共同观测范围内的最高拟合收益：" + bands
    .map(band => format(band.from) + "–" + format(band.to) + " 公里 " + band.winners).join("；") :
    "当前可拟合的作物没有可比较的共同距离区间。";

  if (rebuildSamples) {
    const samples = $("samples");
    samples.replaceChildren();
    for (const row of activeRows) {
      const distance = row.distances[market][metric];
      const use = document.createElement("input");
      use.type = "checkbox";
      use.dataset.id = row.id;
      use.checked = !excluded.has(row.id) && Number.isFinite(distance);
      use.disabled = !Number.isFinite(distance);
      use.setAttribute("aria-label", "纳入 " + row.id);
      const net = document.createElement("input");
      net.type = "number";
      net.step = "any";
      net.dataset.id = row.id;
      net.value = edits.get(row.id) ?? row.net_yuan_mu;
      net.setAttribute("aria-label", row.id + " 净收益");
      const residual = document.createElement("span");
      residual.dataset.residual = row.id;
      addRow(samples, [use, row.id, row.town, data.crops[row.crop],
        Number.isFinite(distance) ? format(distance, 3) : row.distances[market].status,
        net, residual, row.source]);
    }
  }
  const byId = new Map();
  for (const {all, line} of series) {
    for (const point of all) byId.set(point.id, line ? point.y - line.intercept - line.slope * point.x : null);
  }
  for (const node of $("samples").querySelectorAll("[data-residual]")) {
    node.textContent = format(byId.get(node.dataset.residual));
  }
  draw(series);
}

function loadDataset() {
  excluded.clear();
  edits.clear();
  const data = datasets[$("dataset").value];
  options($("market"), data.markets.map(item => [item.id, item.label]));
  $("metric").value = "straight_km";
  $("crop-mode").value = "core";
  const print = document.querySelector(".hero a");
  print.href = "L01_print.html?dataset=" + encodeURIComponent($("dataset").value);
  refresh(true);
}

options($("dataset"), Object.entries(datasets).map(([key, data]) =>
  [key, (data.kind === "demo" ? "模拟" : "实测") + " · " + data.version]));
const requested = new URLSearchParams(location.search).get("dataset");
if (requested && Object.hasOwn(datasets, requested)) $("dataset").value = requested;
$("dataset").addEventListener("change", loadDataset);
for (const id of ["market", "metric", "crop-mode"]) $(id).addEventListener("change", () => refresh(true));
$("reset").addEventListener("click", () => { excluded.clear(); edits.clear(); refresh(true); });
$("samples").addEventListener("change", event => {
  const input = event.target;
  const id = input.dataset.id;
  if (!id) return;
  if (input.type === "checkbox") {
    if (input.checked) excluded.delete(id);
    else excluded.add(id);
  } else {
    const value = input.valueAsNumber;
    const original = datasets[$("dataset").value].rows.find(row => row.id === id).net_yuan_mu;
    if (!Number.isFinite(value) || Math.abs(value) > 1e9) input.value = edits.get(id) ?? original;
    else edits.set(id, value);
  }
  refresh(false);
});
window.addEventListener("resize", () => refresh(false));
loadDataset();
