"""Normalize an Overpass Turbo GeoJSON export into routing input."""
import argparse
import json
from pathlib import Path

HIGHWAYS = {
    "motorway", "trunk", "primary", "secondary", "tertiary", "unclassified", "residential",
    "service", "living_street", "motorway_link", "trunk_link", "primary_link", "secondary_link",
    "tertiary_link",
}
RESTRICTED = {"no", "private", "agricultural", "forestry"}


def normalize(document):
    if document.get("type") != "FeatureCollection":
        raise ValueError("请使用 Overpass Turbo 导出的 GeoJSON FeatureCollection")
    features = []
    for feature in document["features"]:
        tags = feature.get("properties") or {}
        tags = tags.get("tags", tags)
        geometry = feature.get("geometry")
        if not geometry or geometry.get("type") not in {"LineString", "MultiLineString"}:
            continue
        if tags.get("highway") not in HIGHWAYS or tags.get("area") == "yes":
            continue
        access = next(
            (tags[key] for key in ("motorcar", "motor_vehicle", "vehicle", "access") if key in tags),
            None,
        )
        if access in RESTRICTED or tags.get("service") in {"driveway", "parking_aisle"}:
            continue
        oneway = str(tags.get("oneway:motor_vehicle", tags.get("oneway", ""))).lower()
        if oneway in {"reversible", "alternating"}:
            continue
        if oneway in {"-1", "reverse"}:
            direction = "R"
        elif oneway in {"yes", "true", "1"} or (
            not oneway and (tags.get("junction") in {"roundabout", "circular"}
                            or tags.get("highway") in {"motorway", "motorway_link"})
        ):
            direction = "F"
        else:
            direction = "B"
        features.append({
            "type": "Feature", "geometry": geometry,
            "properties": {"direction": direction, "highway": tags["highway"],
                           "osm_id": str(feature.get("id", tags.get("@id", "")))},
        })
    if not features:
        raise ValueError("筛选后没有可用道路，检查导出格式和 highway 标签")
    return {"type": "FeatureCollection", "features": features}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.source.resolve() == args.output.resolve():
        parser.error("输入和输出路径必须不同")
    result = normalize(json.loads(args.source.read_text(encoding="utf-8-sig")))
    args.output.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    print(f"保留 {len(result['features'])} 条道路")
