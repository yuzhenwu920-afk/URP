"""Regenerate synthetic fixtures, using a projected grid with exact distances."""
import csv
import json

from build_qgis import CRS, ROOT, ensure_qgis
from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY, QgsProject


def write_csv(path, columns, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        out = csv.writer(handle)
        out.writerow(columns)
        out.writerows(rows)


if __name__ == "__main__":
    app = ensure_qgis()
    folder = ROOT / "data" / "demo"
    transform = QgsCoordinateTransform(QgsCoordinateReferenceSystem(CRS),
                                       QgsCoordinateReferenceSystem("EPSG:4326"),
                                       QgsProject.instance())

    def lonlat(dx, dy=0):
        p = transform.transform(QgsPointXY(493000 + dx, 4450000 + dy))
        return round(p.x(), 9), round(p.y(), 9)

    write_csv(folder / "markets.csv", ["id", "label", "lon", "lat", "source"], [
        ["dahuashan", "大华山市场（模拟位置）", *lonlat(0), "模拟"],
        ["newtown", "平谷新城（模拟位置）", *lonlat(18000, 1000), "模拟"],
    ])
    patterns = {"peach": (1200, 50, 850, 5), "grain": (600, 10, 550, 2.4),
                "berry": (1500, 105, 600, 9), "nut": (760, 20, 400, 5)}
    rows = []
    for crop, (intercept, rate, harvest, price) in patterns.items():
        for d in (5, 10, 15, 20, 25):
            net = intercept - rate * d
            production = round(harvest * price - intercept - 50, 2)
            rows.append([f"{crop}-{d:02}", f"模拟样点 {d:02}", crop, "2025", *lonlat(d * 1000),
                         harvest, price, production, 50 + rate * d, "模拟规则生成"])
    rows.append(["DEMO-X", "模拟样点 12", "peach", "2025", *lonlat(12000),
                 850, 5, 3000, 50, "模拟异常练习"])
    write_csv(folder / "observations.csv",
              ["id", "town", "crop", "year", "lon", "lat", "yield_kg_mu", "price_yuan_kg",
               "production_yuan_mu", "logistics_yuan_mu", "source"], rows)

    positions = [0, 5000, 10000, 12000, 15000, 18000, 20000, 25000]
    edges = [[lonlat(x, 1000) for x in positions]]
    edges.extend([lonlat(x), lonlat(x, 1000)] for x in positions if x != 18000)
    features = [{"type": "Feature", "properties": {"direction": "B"},
                 "geometry": {"type": "LineString", "coordinates": edge}} for edge in edges]
    (folder / "roads.geojson").write_text(
        json.dumps({"type": "FeatureCollection", "features": features}, indent=2), encoding="utf-8"
    )
