"""Ask DeepSeek for a structured request, then run QGIS on local inputs."""
import argparse
import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

MARKETS = ("dahuashan", "newtown")
METRICS = ("straight_km", "road_km")
TOOL = {
    "type": "function",
    "function": {
        "name": "calculate_distances",
        "description": "计算平谷课堂样本到一个中心的距离。dahuashan=大华山市场，newtown=平谷新城。",
        "parameters": {
            "type": "object",
            "properties": {
                "market": {"type": "string", "enum": list(MARKETS)},
                "metric": {"type": "string", "enum": list(METRICS)},
            },
            "required": ["market", "metric"],
            "additionalProperties": False,
        },
    },
}


def validate_call(name, arguments):
    if name != TOOL["function"]["name"] or not isinstance(arguments, dict):
        raise ValueError("工具调用无效")
    if (set(arguments) != {"market", "metric"} or arguments["market"] not in MARKETS
            or arguments["metric"] not in METRICS):
        raise ValueError("工具参数无效")
    return arguments


def call_deepseek(prompt):
    key = os.environ.get("DEEPSEEK_API_KEY")
    model = os.environ.get("DEEPSEEK_MODEL")
    if not key or not model:
        raise ValueError("先设置 DEEPSEEK_API_KEY 和 DEEPSEEK_MODEL")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "根据用户请求提交一次距离计算。缺少市场或距离类型时先请求澄清。"},
            {"role": "user", "content": prompt},
        ],
        "tools": [TOOL],
        "thinking": {"type": "disabled"},
        "stream": False,
    }
    request = Request(
        "https://api.deepseek.com/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    try:
        with urlopen(request, timeout=45) as response:
            message = json.load(response)["choices"][0]["message"]
    except HTTPError as exc:
        raise ValueError(f"DeepSeek API 返回 HTTP {exc.code}，检查模型名、密钥、余额或限流") from None
    except URLError as exc:
        raise ValueError(f"DeepSeek API 连接失败：{exc.reason}") from None
    calls = message.get("tool_calls") or []
    if not calls:
        raise ValueError("DeepSeek 未提交计算请求。请明确写出市场和直线/路网距离")
    if len(calls) != 1:
        raise ValueError("一次只处理一个市场与距离指标")
    function = calls[0]["function"]
    return validate_call(function["name"], json.loads(function["arguments"]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=("demo", "real"), default="demo")
    parser.add_argument("--version")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--prompt", help="调用 DeepSeek API")
    group.add_argument("--offline", nargs=2, metavar=("MARKET", "METRIC"),
                       help="直接提交相同的结构化参数")
    args = parser.parse_args()
    if args.profile == "real" and not args.version:
        parser.error("真实数据运行需填写 --version")
    version = args.version or "demo-v1"
    try:
        if args.offline:
            market, metric = args.offline
            call = validate_call("calculate_distances", {"market": market, "metric": metric})
        else:
            call = call_deepseek(args.prompt)
        from build_qgis import ROOT, ensure_qgis, make_dataset
        app = ensure_qgis()
        market, metric = call["market"], call["metric"]
        dataset = make_dataset(ROOT / "data" / args.profile, version,
                               "demo" if args.profile == "demo" else "observed",
                               market_ids=(market,), route=metric == "road_km")
        rows = [{"id": row["id"], "km": row["distances"][market][metric],
                 "status": "已计算" if metric == "straight_km" else row["distances"][market]["status"]}
                for row in dataset["rows"]]
        print(json.dumps({"profile": args.profile, "version": dataset["version"],
                          "call": call, "unit": "km", "rows": rows}, ensure_ascii=False, indent=2))
    except (ValueError, OSError, KeyError, IndexError) as exc:
        parser.exit(1, f"计算失败：{exc}\n")


if __name__ == "__main__":
    main()
