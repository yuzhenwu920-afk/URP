"""Build the classroom dataset with QGIS Processing. Also usable via runpy in QGIS."""
import argparse
import csv
import json
import re
import sys
from math import isfinite
from pathlib import Path
from tempfile import NamedTemporaryFile

from qgis.core import (
    Qgis, QgsApplication, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsPointXY, QgsProcessingContext, QgsProcessingException, QgsProject,
    QgsVectorLayer, QgsWkbTypes,
)

ROOT = Path(__file__).resolve().parents[1]
MARKETS = ("dahuashan", "newtown")
CRS = "EPSG:4548"
SNAP_LIMIT_M = 150
CROPS = {"peach": "大桃", "grain": "粮食", "berry": "草莓", "nut": "干果"}


def read_rows(path, fields):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = set(fields) - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"{path.name} 缺列 {sorted(missing)}")
        rows = [{key: (row[key] or "").strip() for key in fields} for row in reader]
    if not rows or any(not value for row in rows for value in row.values()):
        raise ValueError(f"{path.name} 需要至少一条完整记录")
    ids = [row["id"] for row in rows]
    if len(set(ids)) != len(ids):
        raise ValueError(f"{path.name} 存在重复 ID")
    return rows


def number(row, field):
    value = float(row[field])
    if not isfinite(value):
        raise ValueError(f"{row['id']} 的 {field} 必须为有限数值")
    return value


def point(row, transform):
    x, y = number(row, "lon"), number(row, "lat")
    if not (115.4 <= x <= 117.6 and 39.4 <= y <= 41.1):
        raise ValueError(f"{row['id']} 坐标超出北京范围，请检查经纬度顺序和坐标系")
    return transform.transform(QgsPointXY(x, y))


def processing_module():
    plugin_path = str(Path(QgsApplication.pkgDataPath()) / "python" / "plugins")
    if plugin_path not in sys.path:
        sys.path.insert(0, plugin_path)
    from processing import run
    from processing.core.Processing import Processing
    registry = QgsApplication.processingRegistry()
    algorithm_id = "native:shortestpathpointtopoint"
    if registry.algorithmById(algorithm_id) is None:
        Processing.initialize()
    algorithm = registry.algorithmById(algorithm_id)
    if algorithm is None or algorithm.parameterDefinition("POINT_TOLERANCE") is None:
        raise ValueError("当前 QGIS 缺少带端点接入限制的最短路径算法")
    return run


def make_dataset(source, version, kind, market_ids=MARKETS, route=True):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,39}", version):
        raise ValueError("版本号须为 1–40 位英数字或 ._-，首字符为英数字")
    if kind not in ("demo", "observed") or not market_ids or set(market_ids) - set(MARKETS):
        raise ValueError("数据类别或市场 ID 无效")
    project = QgsProject.instance()
    crs = QgsCoordinateReferenceSystem(CRS)
    transform = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"), crs, project)
    run = processing_module() if route else None
    context = QgsProcessingContext()
    context.setProject(project)
    context.setEllipsoid("NONE")
    markets = read_rows(source / "markets.csv", ("id", "label", "lon", "lat", "source"))
    if {row["id"] for row in markets} != set(MARKETS):
        raise ValueError("markets.csv 必须含 dahuashan 和 newtown 两个中心")
    markets = [row for row in markets if row["id"] in market_ids]

    roads = None
    if route:
        roads = QgsVectorLayer(str(source / "roads.geojson"), "roads", "ogr")
        if (not roads.isValid() or not roads.crs().isValid() or not roads.featureCount()
                or roads.geometryType() != QgsWkbTypes.LineGeometry
                or "direction" not in roads.fields().names()):
            raise ValueError("roads.geojson 须为含 direction 字段的有效线图层")
        if any(str(feature["direction"]) not in {"F", "R", "B"} for feature in roads.getFeatures()):
            raise ValueError("道路 direction 只接受 F、R、B")
        roads = run("native:reprojectlayer", {
            "INPUT": roads, "TARGET_CRS": crs, "OUTPUT": "memory:"
        }, context=context)["OUTPUT"]

    fields = ("id", "town", "crop", "year", "lon", "lat", "yield_kg_mu",
              "price_yuan_kg", "production_yuan_mu", "logistics_yuan_mu", "source")
    observations = read_rows(source / "observations.csv", fields)
    years = {row["year"] for row in observations}
    if len(years) != 1 or not re.fullmatch(r"20\d{2}", next(iter(years))):
        raise ValueError("一次发布须使用同一四位观测年份")
    rows = []
    for observation in observations:
        if observation["crop"] not in CROPS:
            raise ValueError(f"{observation['id']} 的 crop 无效")
        origin = point(observation, transform)
        values = [number(observation, field) for field in fields[6:10]]
        if any(value < 0 for value in values):
            raise ValueError(f"{observation['id']} 的亩产、价格和成本须为非负数")
        yield_kg, price, production, logistics = values
        net = yield_kg * price - production - logistics
        if not isfinite(net):
            raise ValueError(f"{observation['id']} 的亩净收益溢出")
        rows.append({
            "id": observation["id"], "town": observation["town"], "crop": observation["crop"],
            "source": observation["source"], "net_yuan_mu": round(net, 2),
            "lon": number(observation, "lon"), "lat": number(observation, "lat"),
            "origin": origin, "distances": {},
        })

    for market in markets:
        target = point(market, transform)
        for row in rows:
            origin = row["origin"]
            straight = origin.distance(target) / 1000
            distance = {"straight_km": round(straight, 4), "road_km": None, "status": "未计算"}
            if route:
                try:
                    result = run("native:shortestpathpointtopoint", {
                        "INPUT": roads, "STRATEGY": 0, "DIRECTION_FIELD": "direction",
                        "VALUE_FORWARD": "F", "VALUE_BACKWARD": "R", "VALUE_BOTH": "B",
                        "POINT_TOLERANCE": SNAP_LIMIT_M, "TOLERANCE": 0,
                        "START_POINT": f"{origin.x()},{origin.y()} [{CRS}]",
                        "END_POINT": f"{target.x()},{target.y()} [{CRS}]",
                        "OUTPUT": "memory:",
                    }, context=context)
                    road = float(result["TRAVEL_COST"]) / 1000
                    distance.update(road_km=round(road, 4), status="可达")
                except QgsProcessingException as exc:
                    distance["status"] = "路网计算失败"
                    print(f"{row['id']} → {market['id']}: {exc}", file=sys.stderr)
            row["distances"][market["id"]] = distance

    for row in rows:
        del row["origin"]
    return {
        "version": version, "kind": kind, "year": next(iter(years)), "crs": CRS,
        "snap_limit_m": SNAP_LIMIT_M, "qgis_version": Qgis.QGIS_VERSION,
        "markets": markets, "crops": CROPS, "rows": rows,
    }


def publish(profile, version):
    if profile not in ("demo", "real"):
        raise ValueError("profile 仅接受 demo 或 real")
    source = ROOT / "data" / profile
    dataset = make_dataset(source, version, "demo" if profile == "demo" else "observed")
    data = json.dumps(dataset, ensure_ascii=False, allow_nan=False, indent=2)
    output = ROOT / "web" / f"dataset-{profile}.js"
    with NamedTemporaryFile(mode="w", encoding="utf-8", dir=output.parent, delete=False) as handle:
        handle.write(f"window.PINGGU_DATASETS[{json.dumps(profile)}] = {data};\n")
    temporary = Path(handle.name)
    try:
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    print(f"{dataset['version']} | {len(dataset['rows'])} 条 | {output}")
    return dataset


def ensure_qgis():
    if QgsApplication.instance() is not None:
        return QgsApplication.instance()
    app = QgsApplication([], False)
    app.initQgis()
    return app


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--profile", choices=("demo", "real"), required=True)
    cli.add_argument("--version", required=True)
    args = cli.parse_args()
    application = ensure_qgis()
    publish(args.profile, args.version)
