# C 同学 · 网页与DeepSeek

先打开 `C_网页与DeepSeek_操作手册.docx`，按上面顺序操作。先跑网页和离线参数，再做真实 API 验收。

包内模拟数据为 demo-v1，正式数据按小组审核版替换。相同版本下，各分包的 web 文件一致。

配套目录：`code/`、`data/`、`docs/`、`templates/`、`web/`。
