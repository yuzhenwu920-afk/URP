# E 同学 · 操作单与试讲

先打开 `E_操作单与试讲_操作手册.docx`，按上面顺序操作。slides 中有可编辑 Word 实验单和 A4 PDF。

包内模拟数据为 demo-v1，正式数据按小组审核版替换。相同版本下，各分包的 web 文件一致。

配套目录：`docs/`、`slides/`、`templates/`、`web/`。
