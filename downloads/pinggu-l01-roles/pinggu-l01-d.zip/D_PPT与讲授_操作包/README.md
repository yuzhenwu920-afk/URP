# D 同学 · PPT与讲授

先打开 `D_PPT与讲授_操作手册.docx`，按上面顺序操作。打开 slides 下的 PPTX，并按 Word 更换地图和引用。

包内模拟数据为 demo-v1，正式数据按小组审核版替换。相同版本下，各分包的 web 文件一致。

配套目录：`docs/`、`slides/`、`templates/`、`web/`。
